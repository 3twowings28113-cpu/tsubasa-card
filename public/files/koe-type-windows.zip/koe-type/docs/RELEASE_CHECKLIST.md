# 公開前のチェックリスト

最終更新 2026-10-05。印：`[x]` 済み / `[ ]` 未 / `[-]` 見送り（理由つき）

**このリストがすべて埋まるまで公開（push）しない。**
公開そのものは利用者が行う。koe-type の開発を手伝う AI は push しない。

---

## 1. 個人データ

- [x] `python tools/privacy_check.py` が通る（いまのファイル）
- [x] `python tools/privacy_check.py --history` が通る（**全コミット**）
- [x] `config.json` `dictionary.txt` `data/` `logs/` `models/` `engines/`
      `bench/audio/` `bench/private/` `bench/eval/` `bench/fleurs/`
      が `.gitignore` 済み
- [x] 固有名詞の一覧（`tools/private_words.txt`）が gitignore 済み
- [x] 見本の辞書（`dictionary.sample.txt`）に個人の語が入っていない
- [ ] 公開直前にもう一度 `--history` を通す（コミットのたびに増えるため）

## 2. ライセンス

- [x] 本体は MIT（`LICENSE`）
- [x] `vendor/transcribe_cpp/` に MIT の全文を同梱し、出どころを
      `vendor/README.md` に書いた
- [x] モデルごとのライセンスを `catalog.py` と設定画面に出している
  - SenseVoice Small → FunASR Model License v1.1（Apache ではない）
  - Whisper large-v3-turbo → Apache-2.0
  - Moonshine Base 日本語 → MIT
- [x] ランタイムのライセンス（transcribe.cpp / FunASR / whisper.cpp = MIT）
- [x] `THIRD_PARTY_NOTICES.md` を transcribe.cpp と FLEURS まで更新
- [ ] FunASR Model License v1.1 の全文を読み、再配布の可否を確かめる
      （モデルはリポジトリに入れず利用者がダウンロードする形なので、
      おそらく問題ないが、文面を自分の目で確認すること）

## 3. 動くこと

- [x] `python tools/selftest.py` 50/50
- [x] `python tools/mock_e2e.py` 10/10（本物のキーを 1 回も送らない）
- [x] `python tools/robust_test.py` 10/10
- [x] `python tools/jatext_test.py` 69/69
- [x] `python tools/overlap_test.py` 24/24（二重入力）
- [x] `python tools/click_test.py` 23/23（クリックの見張り・入力の遅れも実測）
- [x] `python tools/overlay_test.py` 29/29（録音中の帯）
- [x] `python tools/state_test.py` 10/10（状態の移り方）
- [x] `python tools/onboarding_test.py` 37/37（初回の案内）
- [x] `python tools/soak_test.py`（長時間ランダム。数字は `docs/REPORT.md`）
- [x] `python tools/live_check.py`（本物として動いているアプリを外から確認）
- [x] `python tools/latency_test.py` 予算内 4/4（話しながら）
- [x] `python tools/latency_test.py --load cpu` 予算内 4/4
- [x] `python tools/doctor.py` でエラー 0
- [ ] **立ち会いテスト**（`python tools/manual_e2e.py --i-am-watching`）
      14 項目を、利用者が自分で通す
- [ ] 常駐アプリを新しい版に入れ替えて、半日ふつうに使ってみる

## 4. 文書

- [x] `README.md`（日本語）
- [x] `README.en.md`（英語）
- [x] `docs/PRODUCT_SPEC.md`（目指す姿と合格基準）
- [x] `docs/COMPATIBILITY.md`（環境・状況の表）
- [x] `docs/GLOSSARY.md`（言葉づかいの決まり）
- [x] `docs/DECISIONS.md`（迷ったところと、決めた理由）
- [x] `docs/WORKLOG.md`（作業の記録）
- [x] `docs/FAQ.md`（よくある質問）
- [x] `docs/TROUBLESHOOTING.md`（困ったとき）
- [x] `docs/PRIVACY.md`（何を保存し、何を送らないか）
- [x] `CHANGELOG.md`
- [x] `CONTRIBUTING.md`（手を入れる人向け。3 つの決まり）
- [x] `SECURITY.md`（脆弱性の知らせ方）
- [x] `docs/DISTRIBUTION.md`（署名・Store・winget の費用と手順）
- [x] `.github/ISSUE_TEMPLATE/`（不具合・要望）と PR のひな形
- [ ] README のスクリーンショットを、いまの画面に撮り直す
- [ ] README に「使っている様子」の GIF を入れる

## 5. 配布

- [x] 配布用 zip を作る手順（`tools/make_dist.py`）
- [x] **Python が入っていない人向け**：署名済み Python を同梱した
      持ち運べる版（`tools/make_portable.py`）。31.2MB。
      バイナリ 38 個すべて署名あり。**新しい未署名 exe を作らない**
- [x] 管理者権限なしで入る（`tools/install.py`：スタートメニューと
      `HKCU\...\Run` だけ）
- [x] `.github/workflows/ci.yml`（push と PR でテスト）
- [x] `.github/workflows/release.yml`（タグで zip と SHA256 を作り、
      Releases に下書き）
- [ ] 新しくきれいな Windows で、zip から入れて動かす
      （**別の PC が要るので未実施**）
- [x] 初回起動でモデルとエンジンを取得する流れを、実際に空のフォルダで試した
      （展開 → 起動 → モデルがないので設定画面が開く → 例外 0 件）
- [x] アンインストール（`tools/uninstall.py`。データを残すか選べる。
      ジャンクションの先にある本物のファイルは消さない）
- [-] コード署名。**いまの配り方なら要らない**（同梱の Python が
      PSF の署名つきで、koe-type 自身は .py のソース）。
      どうしても付けたい場合は **SignPath Foundation が無料**。
      条件と手順は `docs/DISTRIBUTION.md`。**公開してからでないと
      申し込めない**（「すでに公開されていること」が条件）

## 6. 公開の体裁

- [x] `docs/social-preview.png`（1280×640）
- [x] アプリのアイコン（.ico 8 サイズ × 2 種）
- [ ] GitHub の説明文（1 行）とトピック
      （案：「Windows 用の日本語音声入力。完全オフライン・完全無料。
      Ctrl+Space で話すだけ」／ トピック：`speech-to-text` `japanese`
      `windows` `offline` `dictation` `python` `whisper` `sensevoice`）
- [ ] リリースノート（何が変わったか）
- [-] winget へのマニフェスト提出（**公開後**。費用 0 円・手順は
      `docs/DISTRIBUTION.md`）
- [-] Microsoft Store（**公開後**。登録料 0 円だが MSIX が要る）

---

## 公開してはいけないもの（念のため）

- 録音した音声、文字起こしの履歴、個人の辞書
- `C:\Users\<名前>` を含む絶対パス
- メールアドレス
- モデルやエンジンのバイナリ（大きすぎるし、ライセンス上も配布しない）
- `bench/private/` の正解テキスト（利用者の発話内容そのもの）
