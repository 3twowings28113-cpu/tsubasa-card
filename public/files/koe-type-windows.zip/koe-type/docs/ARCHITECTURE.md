# koe-type の作り（設計書）

このファイルは「**初めてこのリポジトリを触る AI・開発者**が、どこに何があり、
どう動き、どこを直せばよいか」を 1 本で分かるようにするためのもの。
作業の決まりは `AGENTS.md`（＝`CLAUDE.md`）、いまの状況は `docs/HANDOFF.md`、
開発の流れは `docs/DEV_HISTORY.md`、なぜそう決めたかは `docs/DECISIONS.md`。

---

## 1. ひとことで

Windows の常駐アプリ。2 つの機能を持つ。

| 機能 | 何をするか | 入口 |
|---|---|---|
| **音声入力** | 録音キー（既定 Ctrl+Space）で話す → 話しながら、いま文字カーソルのある欄に文字が入る。完全オフライン | `app/main.py` の `Controller` |
| **クリップボード履歴** | Alt+V でコピーの履歴・自分のグループ・最近のファイルを一覧 → 選んで貼る／ドラッグで渡す | `app/clipwin.py` の `ClipService` |
| **文章変換** | 変換（翻訳・敬語・要約…）を選んで話す → 変換して入力。Alt+R で一覧から選べる | `app/transform.py`・`app/recipes.py` |

**Python 標準ライブラリ＋ctypes＋Windows 標準の DLL だけ**で書いている
（pip のパッケージは 1 つも使わない。Smart App Control で未署名の DLL が
止められるため）。画面は 2 種類：

- 常駐の小さな窓（録音中の帯・クリップボードの一覧）は **Win32 の窓に
  GDI / GDI+ で直接描く**（速く出すため）
- 設定画面は **Edge のアプリモード**で HTML を出す（127.0.0.1 の小さな
  サーバーと合言葉つき）

---

## 2. スレッドと流れ

```
main スレッド  MainLoop（80ms ごとの _tick）… 状態の見張り・帯の状態・設定の再読込
win スレッド   WinThread … RegisterHotKey（録音・Esc・Enter）・トレイ・帯の窓・画面の見張り
audio          Recorder（winmm の waveIn）… マイク。区間が切れたら work へ
control        _control_loop … ショートカット・トレイ・台本の「操作」を順に処理
worker         _worker_loop … 文字起こし（エンジン）と貼り付け。1 本だけ＝順番が入れ替わらない
stream-N       話しながらモードの聞き直し
clickwatch     録音中だけ GetAsyncKeyState でクリックを見る（フックではない）
clip           ClipService … クリップボードの見張り・Alt+V/Alt+R・一覧の窓
clip-store     コピーされたものの保存（PNG への変換など重い仕事）
recent-files   「ダウンロード」タブ用に、最近のファイルを探す
hot-reloader   app/ の変更を通知で待ち、待機中に自分を起動し直す（開発用）
settings-http  設定画面のサーバー（開いているときだけ）
guardian       **別プロセス**。本体の心拍が止まったら起動し直す（1 つだけ）
```

### 音声入力の 1 回（話しながらモード）

1. win スレッドが `WM_HOTKEY` を受ける → `control` に `hotkey_down` を投げる
2. `_start_recording`：**前面の窓を `target_hwnd`（入れる先）として覚える**、
   録音を始め、録音中だけ Enter・Esc を登録する
3. audio → `vad.SegmentCutter` が区間を切る → `_enqueue` → work キューへ
4. 話しながら：`stream` スレッドが少しずつ聞き直し、`streaming.Agreement` が
   「何回聞いても同じ」部分を確定 → TEXT として worker へ
5. worker：`_transcribe` → 整形（`textproc` / `jatext`：句読点・つなぎ言葉・
   辞書）→ 履歴へ保存（**貼る前に**保存＝失っても戻せる）→ `_type`
6. `_type` → `inject.paste_text`：クリップボードに置き → **本当に入ったか
   確かめて** Ctrl+V（ターミナルは Ctrl+Shift+V）→ 元の中身に戻す
   - 入れる先の窓から離れていたら：設定 `away_text` が「戻ったら入れる」
     なら **取っておき**（`_hold`）、元の窓に戻ったら入れる（`_flush_held`）。
     3 分戻らなければクリップボードへ（`_expire_held`）
7. 録音キーをもう一度 → `_stop_recording` → 残りを入れる → 待機

### クリップボード履歴

- `AddClipboardFormatListener`（メッセージ専用の窓）で変化を**知らせてもらう**
  → 80ms 待って（形式がそろうのを待つ）`clipdata.read` → clip-store で保存
- 記録しないもの：パスワード管理アプリの「記録しないで」の印、
  koe-type 自身が一時的に置いたもの（`inject.note_own_write` の番号）、
  記録しないアプリ
- Alt+V → `_show`：**録音中なら先に音声入力を済ませる**（`_finish_voice`）→
  前面の窓を貼り先として覚える → 一覧を前に出す
- もう一度 Alt+V → 次のタブ（履歴 → グループ… → ダウンロード → 履歴）
- 貼る（`_paste`）：中身を置く → **貼り先を前に戻してから自分を隠す** →
  前に戻ったのを確かめて Ctrl+V
- Alt+R → 同じ窓を「レシピ一覧」として出す（`mode = "recipe"`）→ 選ぶと
  元の窓に戻してから `custom_action_down` を投げる（＝その変換で録音）

---

## 3. ファイルの地図

### 本体（音声入力）

| ファイル | 役割 |
|---|---|
| `main.py` | `Controller`。全体のまとめ役。録音の開始・停止・貼り付け・見張り・設定の反映。**最初に読む** |
| `mainloop.py` | tkinter の代わりの小さな繰り返し（after / quit / mainloop） |
| `winthread.py` | Win32 のメッセージループ・RegisterHotKey の付け外し・トレイのメニュー・帯のタイマー |
| `inputwatch.py` | RegisterHotKey と SetWinEventHook の薄い包み。冒頭に「なぜフックを使わないか」 |
| `mousewatch.py` | 録音中だけクリックを見る（GetAsyncKeyState を読むだけ） |
| `audio.py` | マイク（winmm waveIn）。先読み（プリロール）・偽マイク（試験用） |
| `vad.py` | 無音の切れ目で区間を切る |
| `streaming.py` | 話しながらモードの「確定」の判定（二重入力を防ぐ） |
| `engines.py` / `resident.py` | 文字起こしエンジン。`resident` はモデルを常駐させる版 |
| `catalog.py` / `downloads.py` / `fetch.py` / `hardware.py` | モデルの一覧・取得・この PC に合うモデル選び |
| `textproc.py` / `jatext.py` / `spelling.py` | 文字の整え方（辞書・句読点・つなぎ言葉・数字・英語のつづり） |
| `transform.py` | 文章変換（翻訳・敬語・要約…）。API キーがあれば Gemini、なければオフラインの簡易変換 |
| `inject.py` | 入力欄へ文字を入れる（貼り付け・直接入力）。**から打ちなら何も送らない** |
| `overlay.py` | 録音中の帯（3 つの形・大きさ・録音中の色）。半透明の窓に GDI+ |
| `history.py` | 文字起こしの履歴（sqlite） |
| `sysaudio.py` | 効果音・録音中の消音 |
| `health.py` / `guardian.py` / `selfcheck.py` / `diagnostics.py` | 心拍・見張り役（別プロセス）・動作チェック・診断情報 |
| `reloader.py` | app/ が変わったら待機中に起動し直す（開発用。変更通知で待つ） |
| `autostart.py` / `autoupdate.py` / `updates.py` | 自動起動・更新の確認と入れ替え |
| `priority.py` | 待機中は処理の優先度を下げる |
| `configstore.py` / `schema.py` | 設定の読み書き。**項目は schema.py に 1 か所で定義**（画面は自動で作られる） |
| `i18n.py` | 画面に出す言葉（日本語・英語）。`t("key", 名前=値)`。**差し込み名に `key` は使えない**（t の第 1 引数とぶつかる） |
| `websettings.py` + `web/` | 設定画面（サーバーとページ） |
| `firstrun.py` | 初回の案内（6 画面） |
| `dryrun.py` / `testdrive.py` | 試験用：から打ち（何も送らず記録だけ）と台本 |

### クリップボード履歴・文章変換の一覧

| ファイル | 役割 |
|---|---|
| `clipwin.py` | `ClipService`。スレッド・窓・見張り・貼る・ドラッグ・設定画面からの頼み（`api`）。モード `clip` / `recipe` |
| `clipmodel.py` | 一覧の中身と操作の決まり（キー → `Command`）。Win32 を知らない＝試験しやすい |
| `clipview.py` | 一覧の見た目（配置・描画・当たり判定） |
| `clipgfx.py` | 描く道具（文字は GDI、図形と画像は GDI+）と画像の変換 |
| `clipdata.py` | クリップボードの読み書き（HGLOBAL の形式だけ） |
| `clipstore.py` | 保存（`data/clips.db`・`data/clips/*.png`）。秘密は DPAPI |
| `clipdrag.py` | ドラッグで渡す（SHCreateDataObject ＋ SHDoDragDrop） |
| `recentfiles.py` | 「ダウンロード」タブ：最近のファイルを探す（クラウドだけのファイルは読まない） |
| `recipes.py` | 文章変換のレシピ一覧の中身と見た目 |

### 試験（`tools/`）

**どれも本物のキー・クリック・クリップボードの書き込みを使わない**
（`KOE_TYPE_DRY_RUN=1`）。利用者のデータには触らない（`KOE_TYPE_HOME` を
使い捨てのフォルダに）。

| 試験 | 中身 |
|---|---|
| `selftest.py` | 単体 75 項目 |
| `clip_test.py` | クリップボード・レシピ・ダウンロードの単体〜本体の通し（約 200 項目）。`--shots` で一覧の画像 |
| `clip_e2e.py` | アプリ本体ごと台本でクリップボードを動かす |
| `mock_e2e.py` | 音声入力の端から端（12 項目。`-k 名前` で絞れる） |
| `state_test.py` / `robust_test.py` / `click_test.py` / `overlay_test.py` / `jatext_test.py` / `overlap_test.py` ほか | 状態の移り方・壊れた設定・クリック・帯・日本語・二重入力 |
| `soak_test.py` | 長時間（**帯が画面に出る。利用者が PC の前にいるときは回さない**） |
| `settings_shots.py` | 設定画面の画像（Edge のヘッドレス）。`--only clipboard` |
| `overlay_options.py` | 帯の画像（形・状態・色） |
| `manual_e2e.py` | **本物のキーを送る唯一の試験。利用者が立ち会うときだけ。AI は動かさない** |
| `privacy_check.py` | コミット前に必ず。メールアドレスの形の文字列も止める |
| `live_check.py` / `restart_live.py` | 常駐アプリを外から確かめる／待機中に起動し直す |

---

## 4. 守っている決まり（壊すと実害が出たもの）

| 決まり | なぜ（実際に起きたこと） |
|---|---|
| 低レベルのフック（WH_KEYBOARD_LL / WH_MOUSE_LL）を使わない | GIL 待ちで PC 全体の入力が止まり、再起動が要った |
| 自動試験で本物のキーを送らない | 3 回、試験の文字が利用者の LINE・Vivaldi に入った |
| CF_BITMAP など GDI のハンドルの形式に GlobalLock しない | ヒープが壊れてアプリが即死した |
| 貼る前に「本当にクリップボードが変わったか」を確かめる | 前のコピーが貼られた |
| `_tick` の次の予約は必ず finally で | 自動停止のあと繰り返しが止まり、帯が消えず Ctrl+Space も効かなくなった |
| RegisterHotKey の付け外しは登録したスレッドで | よそのスレッドから外しても外れなかった |
| 窓の種類（RegisterClass）の名前は本体ごとに変える | 2 つ目の ClipService の知らせが 1 つ目に届いた（片付けた関数を呼べば落ちる） |
| `t()` の差し込み名に `key` を使わない | `t(key, **fmt)` とぶつかり TypeError（2 回起きた） |
| `dryrun.record()` の項目名に `kind` を使わない | 同じ理由 |
| 設定画面の `runAction(name, extra)` は extra を先に、name を後に | extra の `name` が操作名を上書きし「グループを作る」が効かなかった |
| `winthread.parse_hotkey` は読めないキーを Ctrl+Space に置き換える | 録音キー以外では `clipwin.parse_key`（読めなければ 0）を使う |
| 録音中にクリップボードの一覧を出す前に、音声入力を済ませる | 録音中は Enter・Esc を音声入力が預かっていて、一覧の Enter でチャットが送られた |
| 「ダウンロード」タブは、試験では本物のフォルダを読まない | 試験の記録に利用者のファイル名が出た |
| OneDrive のクラウドだけのファイルは中身を読まない | 読むとダウンロードが始まる |

---

## 5. よくある変更の仕方

| したいこと | 触る所 |
|---|---|
| 設定項目を足す | `schema.py` に `Item` を 1 つ。初期値は `default`。画面は自動。反映は `main._config_changed`（クリップボードは `clipwin.RECONFIGURE_KEYS`） |
| 画面の言葉を足す | `i18n.py` に ja / en。設定画面の JS から使う言葉は `websettings.Bridge._strings`（`cweb.*` と `clip.kind_*` はまとめて渡る） |
| 設定画面に専用の部品 | `schema.Item(kind="custom", panel="名前")` ＋ `app.js` の `renderItem` の `panels` に関数 |
| 設定画面から本体へ頼む | `app.js` の `runAction("名前", {...})` → `websettings.Bridge.run_action` → `Controller._settings_action`（`clip_*` は `ClipService.api`） |
| ショートカットを足す | 音声入力：`winthread._apply_hotkeys_now`。クリップボード側：`clipwin._register_keys`。**重なりは `ClipService.key_problem` で確かめる** |
| 台本（試験）で操作を足す | `main._control_loop` に event を足す（クリップボードは `_clip_event`） |
| 一覧の見た目 | `clipview.py`（行は `_paint_row` / `row_lines`）。`python tools\clip_test.py --shots` で画像を見て確かめる |

---

## 6. データの置き場所（すべてこの PC の中だけ）

| 何 | どこ |
|---|---|
| 設定 | `config.json` |
| ユーザー辞書 | `dictionary.txt` |
| 文字起こしの履歴・録音 | `data/history.db`・`data/audio/` |
| クリップボード履歴・グループ・画像 | `data/clips.db`・`data/clips/` |
| ログ・心拍 | `logs/koe-type.log`・`logs/guardian.log`・`logs/heartbeat` |
| モデル・エンジン | `models/`・`engines/` |

`KOE_TYPE_HOME` で全部を別の場所へ移せる（試験はこれで使い捨てのフォルダを使う）。
