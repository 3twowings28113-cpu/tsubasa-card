# 引き継ぎ（はじめて読む AI へ）

最終更新 2026-10-11（未明。2 回目の頼み〈グループ作成の不具合・よそを見ているあいだの文字・レシピ一覧・ダウンロード・帯の色・軽量化・レビュー 10 件〉を反映）。

このファイルだけで、**続きから作業できる**ように書いてあります。
まず「1. いまの状況」と「2. 最初に読むもの」を読んでください。

> **`%USERPROFILE%` は、その PC のユーザーフォルダです。**
> 公開するリポジトリに利用者名を残さないため、この書き方にしています。
> PowerShell では `$env:USERPROFILE`、コマンドプロンプトでは
> `%USERPROFILE%` がそのまま使えます。
> いま確かめるなら `echo $env:USERPROFILE`。

---

## 0. いちばん大事な 3 つ（これだけは先に）

1. **自動テストで、本物のキー送信・貼り付け・クリックを一切しない。**
   過去に 3 回、テスト中の合成キー入力が利用者の LINE や Vivaldi に
   入る事故を起こしています。入力は `KOE_TYPE_DRY_RUN=1` で差し替え、
   操作は台本（JSON）で内側から起こします。
2. **スピーカーから音を鳴らさない。** 音声は WAV を直接読み込ませます
   （`KOE_TYPE_FAKE_MIC=<wav>`）。
3. **いま常駐して動いているアプリを壊さない。** 利用者が毎日使っています。
   入れ替えるのは、テストが全部通ったときだけ。

全部のルールは **`AGENTS.md`**（＝`CLAUDE.md`、同じ内容）にあります。

---

## 1. いまの状況（2026-10-11 夕方時点）

| | |
|---|---|
| 版 | **1.4.0**（`app/util.py` の `VERSION`）。**まだ公開していません** |
| **常駐しているのは** | **`%USERPROFILE%\koe-type-dev`** のブランチ **`dev`**。ROADMAP 14.1（設定の案内）および音声入力中のBGM停止防止（`audio_ducking: "off"` の完全維持）を反映済み（`tools/restart_live.py` および `tools/live_check.py` で待機中・正常稼働確認済み） |
| 自動起動の登録 | タスクスケジューラ（`\koe-type`、ログオン時即時起動、非特権）→ `koe-type-dev\koe-type.pyw`（レジストリ Run キーの遅延を解消） |
| 開発に使うフォルダ | **同じ `%USERPROFILE%\koe-type-dev`**（ブランチ `dev`） |
| 安定版（触らない） | `%USERPROFILE%\koe-type`（ブランチ `master`、タグ `v1.3-stable`） |
| 作業ツリー | **きれい（コミット済み。やりかけなし）** |
| 利用者の設定 | `audio_ducking` を「そのまま（off）」、`mute_while_recording` を false に設定済み。控えは `config.json.bak-20261011-music` |

> **なぜ常駐と開発が同じフォルダなのか**
> 立ち会いテストの途中だからです。利用者が新しい版を毎日使いながら
> 確かめています。**`dev` を壊すと、その場で音声入力が使えなくなります。**
> `master` はいつでも戻れる安全網として残してあります。

### 使っているもの

- Python 3.14.4（`C:\Python314`）。**pip パッケージは 1 つも使いません**
- 文字起こし：transcribe.cpp（`engines/`）＋ SenseVoice Small（`models/`）
  — どちらも `.gitignore` 済み。リポジトリには入っていません
- モデルは GPU（Vulkan / Intel Arc 140V）で動き、1 回 0.07 秒

---

## 2. 最初に読むもの（この順番で）

| 順 | ファイル | 何が書いてあるか |
|---|---|---|
| 1 | **`AGENTS.md`** | 作業ルール。**絶対に守るもの** |
| 1.5 | **`docs/ARCHITECTURE.md`** | **全体の作り**（スレッド・ファイルの地図・守っている決まり・よくある変更の仕方） |
| 1.6 | `docs/DEV_HISTORY.md` | 開発の経緯と学んだこと |
| 2 | **`docs/HANDOFF.md`**（これ） | いまの状況と動かし方 |
| 3 | `docs/PRODUCT_SPEC.md` | 目指す姿と「完成の基準」。迷ったらここに照らす |
| 4 | `docs/ROADMAP.md` | やることの一覧。済みは `[x]` |
| 5 | `docs/REPORT.md` | いちばん新しい作業報告（数字つき） |
| 6 | `docs/DECISIONS.md` | **なぜそう決めたか。** 同じ失敗をしないために |
| 7 | `docs/WORKLOG.md` | 作業の記録 |

コードを読むときは、この順が分かりやすいです。

```
app/main.py         全体のまとめ役（Controller）。ここから読む
app/winthread.py    ショートカットとトレイ。メッセージループ
app/inputwatch.py   ★冒頭に「なぜ低レベルのフックを使わないか」
app/overlay.py      録音中の帯（3 案）
app/streaming.py    話しながら入力する「確定」の判定
app/jatext.py       日本語の整え方（句読点・疑問符・数字）
app/vad.py          無音の切れ目で区間を切る
app/schema.py       設定項目の定義（画面は自動生成）
```

---

## 3. テストの動かし方

**すべて、本物のキーを 1 回も送りません。** スピーカーも使いません。
画面がロックされていても通ります。

```powershell
cd $env:USERPROFILE\koe-type-dev

# --- 軽いもの（数秒〜1 分）
python tools\rules_check.py       # AGENTS.md と CLAUDE.md がそろっているか
python tools\selftest.py          # 単体 75 項目
python tools\jatext_test.py       # 日本語の整え方 95 項目
python tools\overlap_test.py      # 二重入力の判定 30 項目
python tools\click_test.py        # クリックの見張り 23 項目（入力の遅れも実測）
python tools\overlay_test.py      # 録音中の帯 31 項目

# --- 重いもの（数分）
python tools\state_test.py        # 録音の開始・停止の組み合わせ 15 通り
python tools\mock_e2e.py          # 端から端まで 11 項目
python tools\robust_test.py       # 壊れた設定・マイクなし等 10 項目
python tools\onboarding_test.py   # 初回の案内 37 項目
python tools\onboarding_test.py --shots   # 画像も撮る
python tools\fresh_install_test.py       # 初めて入れる流れ（取り出し方）
python tools\fresh_install_test.py --network  # 空のフォルダへ本物を落とす

# --- 長いもの（数十分〜数時間）
python tools\soak_test.py --minutes 30    # ランダムにくり返す
python tools\commit_bench.py              # 利用者の実録音で精度を測る

# --- 本物として動いているアプリを外から確かめる（キーは送らない）
python tools\live_check.py

# --- コミット前に必ず
python tools\privacy_check.py
python tools\privacy_check.py --history   # 全コミットの履歴まで
```

### 画像を作る（画面を撮らない＝ロック中でも通る）

```powershell
python tools\overlay_options.py   # 帯の 3 案 × 4 状態 × ライト/ダーク
python tools\settings_shots.py    # 設定画面（Edge のヘッドレス）
python tools\make_gif.py          # 使っている様子の GIF
```

### 配布物を作る

```powershell
python tools\make_dist.py              # 軽い zip（ソースだけ）
python tools\make_portable.py --zip    # 署名済み Python を同梱した版
```

### 絶対に自分で実行しないもの

```
tools\manual_e2e.py     ← 本物のキーを送る。利用者が立ち会うときだけ
```

---

## 4. 常駐アプリの起動し直し方

設定・辞書・履歴は `%USERPROFILE%\koe-type-dev` の中にあります。
**消さないでください。**

### いちばん簡単なやり方（おすすめ）

```powershell
python $env:USERPROFILE\koe-type-dev\tools\restart_live.py
```

**待機中が 20 秒続いたときだけ**入れ替え、最後に `live_check.py` まで
行います。録音の最中には止めません（手で打つと、話している最中の
アプリを止めてしまうことがある。2026-10-05 に実際にやってしまった）。

### 止めてから、起動し直す（手で行うとき）

```powershell
# 1. 見張り役を先に止める（本体だけ止めると、すぐ起動し直されます）
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" |
  Where-Object { $_.CommandLine -like "*guardian*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

# 2. 本体を止める
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe'" |
  Where-Object { $_.CommandLine -like "*koe-type.pyw*" } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

# 3. 起動する（黒い画面を出さない pythonw で）
#    シングルクォートの中では $env: が展開されないので、変数にしてから渡す
$dev = Join-Path $env:USERPROFILE "koe-type-dev"
Start-Process -FilePath "C:\Python314\pythonw.exe" `
  -ArgumentList ('"' + (Join-Path $dev "koe-type.pyw") + '"') `
  -WorkingDirectory $dev

# 4. 本当に生きているか、外から確かめる（キーは送りません）
python $env:USERPROFILE\koe-type-dev\tools\live_check.py
```

`live_check.py` が 26 項目すべて OK なら、使える状態です。

### うまく動かないときに見るもの

```
logs\koe-type.log       アプリの記録（1MB で回ります）
logs\heartbeat          いまの状態（時刻 / state / stopping / ticks）
logs\metrics.jsonl      重かったときの様子
```

### 安全版（v1.3）に戻す

新しい版がどうしても駄目なときだけ。

```powershell
# 上の 1〜2 で止めてから
$safe = Join-Path $env:USERPROFILE "koe-type"
Start-Process -FilePath "C:\Python314\pythonw.exe" `
  -ArgumentList ('"' + (Join-Path $safe "koe-type.pyw") + '"') `
  -WorkingDirectory $safe

# 自動起動も戻す（利用者に確認してから）
cd $env:USERPROFILE\koe-type
python -c "import sys; sys.path.insert(0,'.'); from app import autostart; print(autostart.enable())"
```

---

## 5. 開発の進め方

```powershell
cd $env:USERPROFILE\koe-type-dev       # ブランチ dev
# …直す…
python tools\selftest.py             # 関わるところのテスト
python tools\privacy_check.py
git add -A
git commit -m "..."                  # 日本語で、「何に困っていたか」を書く
```

- **1 項目終えるたびにテストしてコミット**し、`docs/ROADMAP.md` に `[x]`
- 大きめの判断をしたら `docs/DECISIONS.md` に 1 行（**なぜ**を書く）
- 行き詰まったら `docs/WORKLOG.md` に書いて次へ進み、あとで戻る
- **`git push` はしない。** 公開は利用者が行います

### 直したあとに常駐へ反映する

コードを直しただけでは、動いているアプリは古いままです。
**4. の手順で起動し直して**ください。そのあと `live_check.py`。

---

## 6. 次にやること

### 今どこまでできたか（2026-10-06 深夜の立ち会いテストで）

立ち会いテストの 1〜6 番は、10-05 の夜のうちにすべて最終的に OK
（1 帯の形・2 ふつうに話す・3 自動停止・4 送信ボタン・5 はてな・
6 診断情報）。そのあと利用者が離れている間に、ROADMAP 11 節の不具合
（長押しが止まらない・再起動の競合・帯の高 DPI・設定の検索欄など）を
まとめて直し、常駐アプリへ入れ替え済み（詳しくは `docs/REPORT.md`）。

利用者が戻ってから、さらに 3 件の報告があり、**すべて原因を調べて
直し、常駐アプリへ入れ替え済み**（コミット `c0cc1a1`〜`ea64881`）。

1. **設定の窓が「接続が拒否されました」になる**
   → Edge の更新で、起動した `msedge.exe` がすぐ終わるようになった。
   それを「窓が閉じた」と誤認してサーバーを 1 秒で止めていた。
   ページの心拍だけで「開いているか」を判断するよう直した。
2. **話したのに文字にならないことがある**
   → 帯に出す文字の表示・非表示をトレイと設定から切り替えられる
   ようにした（利用者の希望どおり）。
3. **話の最後が文字にならない／句読点「、」が多すぎる**
   → 両方とも原因を特定して直した。詳細は次の節。

### 2026-10-11 未明：2 回目の頼み

- 「グループを作る」が効かない → 設定画面の `runAction` の並べ方を直した
- 音声入力中によそをクリックすると文字が入らない → `away_text`（既定「元の欄に戻ったら入れる」）。`main._hold` / `_watch_held` / `_flush_held` / `_expire_held`
- Alt+R で文章変換のレシピ一覧（`app/recipes.py`、窓は ClipService の `mode="recipe"`）
- 「ダウンロード」タブ（`app/recentfiles.py`、項目は負の id の実ファイル）
- 録音中の色（`overlay_color`、9 色）
- 軽量化：帯のタイマーを隠れているあいだ 0.5 秒に、ホットリロードを変更通知に
- 別エージェントのレビュー 10 件を直し、`tools/clip_test.py` に戻らない確かめを足した
- 既存の試験の古い期待値を直した（click_test の「知らせは 1 回だけ」、mock_e2e の excluded）

### 2026-10-11 クリップボード履歴を足した

- 仕様・作り・試験は **`docs/CLIPBOARD.md`**。本体は `app/clipwin.py`
  （専用スレッド `clip`）。音声入力とは別のスレッドで、失敗しても音声入力は止めない
- 作業は別の worktree **`%USERPROFILE%\koe-type-clip`（ブランチ `clipboard`）**
  で行い、試験が通ってから `dev` へ入れた。dev はホットリロードで再起動するため、
  書きかけを常駐に読ませないようにするため。次も大きな作業は同じやり方がよい
  （`bench\audio` は dev のものをジャンクションで見せる。git には入らない）
- 試験：`python tools\clip_test.py`（`--shots` で一覧の画像）・
  `python tools\clip_e2e.py`・`python tools\settings_shots.py --only clipboard`
- **まだ立ち会いで確かめていない**：ドラッグ、実際の貼り付け、IME の変換窓の
  位置、ふちのドラッグ（`tools/manual_e2e.py` の 15〜22 番）
- ついでに直した：見張り役（guardian）が増え続けていた（46 個たまっていた）／
  「無変換」を録音キーに選ぶと Ctrl+Space に戻っていた

### やりかけのこと（次に着手してほしいこと）

**どれも「やりかけのコード」はありません。** 作業ツリーはきれいです。
ただし、以下は**確認・検証がまだ**なので、続きとして優先してください。

| 項目 | 今の状態 | 次にやること |
| **ユーザー辞書の刷新（タスク5）** | 実装完了。表記のみ登録で類似読みを自動補正、短語保護、Whisperヒント渡し、WebUI連携。CER測定で+8.24%改善確認済み（単体テスト20/20） | 利用者の実録音・実利用での使い勝手確認 |
| **初回の案内「試し書き」確認** | マイク波線画面をやめ、メモ帳風「試し書き」画面（入力検知で「できました」表示、スキップ・マイク選び直し）に変更済み（単体テスト通過） | 利用者が手動で「ここをクリック → Ctrl+Space → 話す → もう一度 Ctrl+Space」で文字が入ることを確認する（AIはキー送信しない） |
| **二重入力の再測定** | `commit_bench.py --mode stream` で測ると、直し前は二重 0 回だったのが、VAD の直し後の測定で二重 3 回に見えた。ただし同じ録音を流し直すと 0 回に戻るものがあり、**聞き直しの間合いが処理速度で変わるため測定自体が揺れている疑いがある**（`docs/DECISIONS.md` 2026-10-06 深夜の節を参照） | 利用者が「今PC使ってないから回して」と言った時間帯に `commit_bench.py --mode stream` を複数回（3〜5 回）流し、二重入力が安定して 0 回かを確認する。GPU を取り合うので勝手に実行しないこと |
| **句読点「少なめ」の作り直し** | `app/jatext.py` の `natural_commas()` で作り直し、`few` を既定にして利用者の設定にも反映済み（テスト `jatext_test.py` は通過、実際の録音でも目視確認済み） | 利用者にしばらく使ってもらい、「残しすぎ／落としすぎ」の実例が出たら `_KEEP_AFTER_WORDS` / `_CLAUSE_ENDS` / `_SPOKEN_HEADS` / `_SPLIT_PAIRS` の語彙を調整する |
| **ログが 1MB で止まる不具合の修正** | `app/util.py` に `_SafeRotatingHandler` を足し、見張り役（guardian）のログを `guardian.log` に分離。単体テストで「別プロセスが開いていても書き続ける」ことを確認済み | 実機で 1MB を超えるまで使い込んで、`koe-type.log.1` への回転と `guardian.log` の両方が実際に機能しているかを確認する |

### そのあと（`docs/ROADMAP.md` の残りから）

**2026-10-11 昼の利用者の頼み：「作っていないものを全部やる」。**
順番と中身は `docs/ROADMAP.md` の「14.」に書いた。いちばん上は
14.1「設定の案内（困りごとを選ぶと、変える設定へ連れていく）」。
モデルは**いまのまま**（13.10 は決着。SenseVoice へは替えない）。

| 番号 | 何を |
|---|---|
| 14.1 | 設定の案内（新しい頼み） |
| 4.4 / 4.5 / 5.3 | アプリごとのプロファイルと、その画面・音声コマンドと辞書の画面 |
| 1.12 / 1.13 | 雑音に強い区間検出／ダッキングを止める |
| 8.8 / 8.9 | 使っている間は重い作業を止める／混んでいる時の速さの試験 |
| 12.12 | ドロップを受けてグループに入れる（IDropTarget） |
| 9.8 / 6.15 / 6.6 | ロック・RDP・全画面などの確認／GIF／自己採点 |
| 6.16・12.11・13.9 | **実機・立ち会いが要る。AI は手順を書くだけで、自分では実行しない** |

### 注意点（このセッションで特に気をつけたこと）

- **利用者は音声入力（koe-type 自身）でメッセージを書くことが多い。**
  聞き取り間違い（「ハード」→「カード」、「苦闘点」→「句読点」）を
  含んだまま届くので、文字どおりではなく意図で読むこと。
- **利用者が PC の前にいる間は、画面に何か表示されるテスト
  （`soak_test.py` など）を走らせない。** 録音中の帯が画面に出て
  紛らわしいと言われた実績がある。離れている時間に回す。
- 常駐アプリの入れ替えは必ず `tools\restart_live.py` を使うこと。
  手で止めると、話している最中のアプリを巻き込んで止めてしまう
  事故が実際に起きている（2026-10-05 夕方）。

### 公開のとき（利用者が行う）

`docs/RELEASE_CHECKLIST.md` と `docs/DISTRIBUTION.md`。
**AI はリポジトリ作成も push もしません。**

---

## 7. つまずきやすいところ

| 症状 | 原因と直し方 |
|---|---|
| テストが本物の設定を書き換える | `app` を読み込む**前に** `KOE_TYPE_HOME` を使い捨てフォルダにする（`app/util.py` は読み込んだ時点で置き場所を決める）。`tools/selftest.py` の冒頭が見本 |
| 帯が消えない／Ctrl+Space が効かない | `_tick()` の繰り返しが止まっていないか。`finally` で必ず次を予約する。`logs/heartbeat` の `ticks` が増えていれば生きている |
| 「停止が終わらない」と出る | 停止の内訳（録り残し 0.4 秒＋合流 1.2 秒）が `stop_timeout_ms`（3 秒）を超えていないか。`tools/state_test.py` が見ている |
| ショートカットが効かなくなる | `RegisterHotKey` は**登録したスレッドのもの**。付け外しは必ず win スレッドで（`WM_SYNC_KEYS` / `WM_VERIFY_KEYS` を投げる） |
| 文字が二重に入る | `app/streaming.py` の `resume_at` / `_drop_repeat`。送り仮名の揺れに注意 |
| PC 全体が重くなる | 低レベルのフックを足していないか。**使ってはいけません**（`app/inputwatch.py` の冒頭） |
| 画像が真っ白／撮れない | Edge のヘッドレスで撮っています。`find_edge()` が見つけられているか |
| 画像が 1 枚も撮れない（Edge 更新後） | `msedge.exe` がすぐ戻るようになった。`tools/edgeshot.py` で、古い画像を消す・専用プロフィール・書き終わりを待つ |
| Python で書き換えると `\\` や `\n` が化ける | Bash の heredoc 経由だと化ける。バックスラッシュを含む書き換えは Edit の道具で |
| 常駐を入れ替えたら利用者の録音が切れた | 手で止めない。`tools/restart_live.py`（待機中が 20 秒続くまで待つ） |
| 「長押しの間だけ」が止まらない | RegisterHotKey は離したことを知らせない。`winthread._poll_release` が押したときだけ見る |
| 設定の窓が「接続が拒否されました」になる | Edge 更新後、起動した `msedge.exe` がすぐ終わる。「窓が閉じた」判定はページの心拍（`page_beat` / `page_alive`）だけで行う。プロセスの生死では判定しない |
| 話の途中で区切られ、後半が消える | `app/vad.py` の雑音の見積もりが**区間の中**でも動いていた。`_in_speech` の間は見積もりを更新しない（直し済み） |
| ログが 1MB を超えると急に記録が止まる | 見張り役（guardian）が本体と同じ `koe-type.log` を開いていると Windows で回せない。`guardian.log` に分離済み（`app/util.py` の `_SafeRotatingHandler`） |

---

## 8. 言葉づかい

`docs/GLOSSARY.md` に、画面に出す言葉の決まりがあります。
「文字起こし」「録音」「区切り」などを、全画面でそろえてください。
コメントも日本語で、**「なぜ」**を書きます。
