# 配り方（調べたことと、決めたこと）

> このファイルは **調べた結果のまとめ**です。申し込みが要るものは
> 「あなたがやること」に手順だけ書いてあります。
> 2026-10-05 時点の調査。値段や条件は変わることがあるので、
> 申し込む前にリンク先で確かめてください。

---

## 1. いちばんの壁：署名のない exe はブロックされる

このプロジェクトの前提は 2 つ。

- 開発機では **Smart App Control が有効**。署名のない exe / dll が
  ファイル単位で、予告なくブロックされる。
- 受け取る人の PC では **SmartScreen** が「よく知らない発行元です」と
  警告を出す。警告を無視して進める人は多くない。

だから **新しい exe を作らない**のが基本方針。
PyInstaller や Nuitka で 1 つの exe にまとめる方法は、

- 署名がないと Smart App Control にブロックされる
- 署名しても「評判」が貯まるまで SmartScreen が警告する
- 中身が 1 つの塊になるので、ウイルス対策ソフトの誤検知も多い

ため、**採らない**。

### 採る方法：署名済みの Python を同梱する

python.org が配っている **Windows embeddable package**（埋め込み用
Python）は、`python.exe` / `pythonw.exe` / `python3xx.dll` が
**Python Software Foundation の署名つき**。これをそのまま同梱すれば、

- 新しい未署名 exe が 1 つも増えない
- 受け取る人の PC に Python が入っていなくても動く
- 管理者権限が要らない（ただ展開するだけ）
- アンインストールはフォルダを消すだけ

という形にできる。koe-type 自身は **Python のソースのまま**配る
（.py / .pyw）。ソースが読めることは、オフラインで動く音声入力に
とって「本当に外へ送っていない」ことの証明にもなる。

> 埋め込み用 Python には tkinter が入っていないが、**koe-type は
> tkinter を使っていない**（2026-10-05 にやめた。ROADMAP 6.14）。
> 繰り返しは `app/mainloop.py`、ファイルを選ぶのは設定画面（ブラウザ）。
> だから埋め込み用 Python をそのまま使える。tcl/tk を同梱しないぶん、
> 持ち運べる版は 31.2MB → 23.9MB に軽くなった。

---

## 2. 無料でコード署名する方法

koe-type は MIT ライセンスのオープンソースなので、**無料の
コード署名**が使える見込みがある。

### SignPath Foundation（第一候補）

オープンソース向けに **EV コード署名証明書・タイムスタンプ・
署名ダッシュボードと記録・GitHub Actions 連携**を**無料**で提供して
いる（Community support）。

条件（2026-10 時点で確認できたもの）

- マルウェアや不要ソフトを含まないこと
- **すべての部品が OSI 承認のオープンソースライセンス**で、
  商用デュアルライセンスでないこと
- 独自・非オープンソースの部品を含まないこと
- 活発に手入れされていること
- **署名したい形ですでに公開されている**こと
- 機能がダウンロードページかストアの説明に書かれていること
- SignPath が発行する証明書を使う場合、**ビルドが完全に自動化**され、
  リポジトリのソースから直接その成果物ができると示せること

koe-type との相性

| 条件 | いまの状態 |
|---|---|
| OSI 承認ライセンス | ✅ MIT |
| 非オープンソースの部品がない | ⚠ **要確認**。transcribe.cpp（MIT）と ggml 系 dll、モデル（SenseVoice）のライセンスを `THIRD_PARTY_NOTICES.md` で洗い直す。モデルは同梱せず利用者がダウンロードする形なので、署名対象には入らない |
| 活発に手入れ | ✅ |
| すでに公開されている | ❌ **まだ公開していない**。先に 1 回リリースする必要がある |
| ビルドの自動化 | ⚠ `.github/workflows/release.yml` を用意済み。SignPath を足すのは公開後 |

**費用：0 円。** 申し込みは公開後。

### ほかに調べたもの

| 方法 | 費用の目安 | 向き不向き |
|---|---|---|
| Azure Trusted Signing | 月 $9.99 程度〜（個人も可。登記から 3 年以上などの条件あり） | 安いが有料。個人の条件が厳しいことがある |
| 商用の OV / EV 証明書 | 年 2〜6 万円（OV）／年 5〜10 万円（EV） | 確実だが有料。EV は SmartScreen の評判が最初から良い |
| 自己署名 | 0 円 | **意味がない。** 受け取る人の PC は信用しない |
| 署名しない | 0 円 | いまの形（署名済み Python ＋ .py のソース）なら、**これでも動く** |

> いまの配り方（署名済み Python ＋ ソース）なら、**署名なしでも
> ブロックされない**。署名は「あると親切」であって、必須ではない。

---

## 3. Microsoft Store

- **登録料は無料**（個人は以前 $19、法人は $99 だったが、どちらも
  撤廃された）。個人はクレジットカードも不要で、Microsoft アカウント・
  本人確認（身分証と自撮り）・基本情報だけで登録できる。
- 長所：SmartScreen の警告が出ない。更新が自動。見つけてもらいやすい。
- 短所：
  - **MSIX にパッケージし直す必要がある**。いまの「フォルダに展開」
    方式とは別物を用意することになる。
  - MSIX は**署名が必須**（Store が署名してくれるので、Store 経由なら
    自分の証明書は不要）。
  - 審査がある。マイクを使うので用途の説明が要る。
  - モデル（1GB 近い）を初回に外からダウンロードする作りが、
    審査でどう扱われるかは**未確認**。

**費用：0 円。手間：中〜大。** 公開して少し落ち着いてからで良い。

## 4. winget

- `microsoft/winget-pkgs` リポジトリに**マニフェストを PR で出す**だけ。
  **開発者登録も費用も不要。** 自動で検証され、ポリシー違反や
  マルウェアでないかが確かめられる。
- `winget install koe-type` で入るようになる。
- 条件：**公開されたダウンロード URL と SHA256** が要る
  （GitHub Releases でよい）。zip 形式にも対応している。
- インストーラ形式のほうが扱いやすいので、
  将来 `install.cmd` を含む zip ではなく、ユーザー単位の
  インストーラ（NSIS など）にすると素直。ただし**未署名 exe が
  増える**ので、いまは見送り。

**費用：0 円。手間：小。** 公開したらすぐ出せる。

---

## 5. いまの配り方（決めたこと）

```
koe-type-1.x.x-windows-x64.zip
├─ koe-type.cmd            ← これを実行すると起動する
├─ install.cmd             ← スタートメニューと自動起動に登録
├─ uninstall.cmd           ← きれいに消す（データを残すか選べる）
├─ README.md / README.en.md / LICENSE / THIRD_PARTY_NOTICES.md
├─ app\ …                  ← koe-type 本体（Python のソース）
├─ tools\ …
└─ runtime\                ← 署名済みの Python（PSF）
   ├─ pythonw.exe          ← 署名あり
   ├─ python314.dll        ← 署名あり
   └─ python314._pth
```

- **管理者権限なし。** `%LOCALAPPDATA%\koe-type` に置く。
- スタートメニューは `%APPDATA%\Microsoft\Windows\Start Menu\Programs`
  にショートカットを作る（ユーザー単位）。
- 自動起動は `HKCU\...\Run` だけ（ユーザー単位。管理者権限は不要）。
- **モデルとエンジンは同梱しない。** ライセンスの都合と、合わせて
  1GB を超えるため。初回の案内でダウンロードする。
- zip と **SHA256** を `tools/make_dist.py` が作る。

作り方

```
python tools\make_portable.py        # 署名済み Python を取ってきて組み立て
python tools\make_dist.py            # zip と SHA256 を作る
```

---

## 6. あなたがやること（申し込みが要るもの）

### A. GitHub に公開する（最初の 1 回）

1. GitHub で新しいリポジトリを作る（`koe-type`、Public、MIT）
2. ローカルで `git remote add origin <URL>` → `git push -u origin main`
3. `python tools\make_dist.py` で zip と SHA256 を作る
4. Releases → 「Draft a new release」→ タグ `v1.4.0` →
   zip と `SHA256SUMS.txt` を添付 → 公開
5. リポジトリの Settings → Social preview に
   `docs/social-preview.png` を設定

> 私（エージェント）は push もリポジトリ作成もしません。

### B. SignPath Foundation に申し込む（公開のあと・任意）

1. <https://signpath.org/apply> から申し込む
2. 書くこと：リポジトリの URL、MIT ライセンス、何をするアプリか、
   すでに Releases があること
3. 通ったら `.github/workflows/release.yml` の
   `# SignPath:` のコメント部分を有効にする
   （`signpath/github-action-submit-signing-request` を使う）
4. 署名された zip を Releases に差し替える

### C. winget に出す（任意）

1. `winget install wingetcreate` （または
   <https://aka.ms/wingetcreate/download>）
2. `wingetcreate new <Releases の zip の URL>`
3. 聞かれるままに答えると manifest ができる → PR が自動で出る
4. 検証が通るとマージされる

### D. Microsoft Store に出す（任意・後回しでよい）

1. <https://partner.microsoft.com/dashboard> で個人として登録（無料）
2. 本人確認（身分証と自撮り）
3. MSIX を作る必要がある → 先に `docs/ROADMAP.md` 6.9 を終わらせる

---

## 7. 残っている心配ごと

| 心配 | いまの状態 |
|---|---|
| 埋め込み用 Python に tkinter がない | **問題なし。** koe-type は tkinter を使っていない（ROADMAP 6.14） |
| 受け取る人の PC の Smart App Control | 署名済み Python ＋ .py のソースなので、ブロックされない見込み。**別の PC では未確認**（`docs/COMPATIBILITY.md`） |
| モデルのダウンロード（1GB 近い） | 初回の案内で、進み具合・途中から再開・壊れていないかの確認つき |
| ユーザー名に日本語・空白、OneDrive の中 | パスの扱いを見直し済み。**実機では未確認**（`docs/COMPATIBILITY.md`） |
| ウイルス対策ソフトの誤検知 | exe を作らないので起きにくいが、**未確認** |

---

## 参考にしたページ

- [SignPath Foundation（オープンソース向け）](https://signpath.org/)
- [SignPath の条件](https://signpath.org/terms)
- [SignPath for Open Source projects](https://about.signpath.io/product/open-source)
- [winget：マニフェストを出す](https://learn.microsoft.com/windows/package-manager/package/repository)
- [Microsoft Store：個人の登録料が無料に](https://blogs.windows.com/windowsdeveloper/)
- [Microsoft Store：法人も無料に（2026-05）](https://blogs.windows.com/windowsdeveloper/2026/05/07/publish-to-microsoft-store-as-a-company-now-with-free-registration-and-faster-onboarding/)
