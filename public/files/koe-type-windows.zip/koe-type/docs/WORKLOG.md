# 作業の記録

新しいものを上に足す。各項目は `docs/ROADMAP.md` の番号と対応。

## 囲み完了時の意図しないブラウザ起動防止と動画再生中音声入力の自動消音対応（2026-10-23）
- ユーザー要望：
  - 「このページが勝手に開いたんだけど、全然機能してなくないですか これ大丈夫」
  - 「あとさニュースピックスの多分だけど普通にそれ以外もそうだと思う動画を流してるので、動画を流して聞いてる時に音声入力するとスピーカーから出る音全部音声入力しちゃう。どういうこと？ それできないようにするの可能？」
- 原因・課題分析：
  1. 画面囲み検索でドラッグを終えてマウスを離した瞬間、`_submit_question("この画像について詳しく解説・検索してください")` が自動的に走っていた。APIキーが未設定の場合、`transform.process_screen_assistant` が Google 検索 URL を返し、`webbrowser.open(url)` が実行されてブラウザが前面に立ち上がってしまっていた。その結果、画面AIオーバーレイが背面に回って操作できず、「囲んだ瞬間に変なページが勝手に開いて全然機能していない」状態になっていた。
  2. NewsPicks や YouTube などの動画を流しながら音声入力（Ctrl+O や Ctrl+Space）した際、PCスピーカーから鳴っている動画音声をマイクが拾ってしまい、動画の台詞まで文字起こしされていた。koe-type には元々録音中のPC音声を消音/低減する `audio_ducking` 機能（`sysaudio.speaker.mute()`）が実装されていたが、設定が `"off"` かつ詳細設定に隠れていたため活用されていなかった。
- 改善内容：
  1. `app/snipping.py`:
     - 囲み完了時に、音声指示があった場合のみ音声処理を実行し、音声指示がなければ勝手にAI問い合わせやブラウザ起動を行わず、囲み枠下の3連ボタン（［🖼️］［📋］［文A］）と右側シートを表示して待機するよう変更。
     - AIワーカー内で明示的な検索アクション（`action_type == "search"`）時以外は勝手にブラウザを開かないよう制限。
  2. `app/schema.py`:
     - `audio_ducking`（録音中のPC音声（動画・音楽）の制御）を基本設定（`advanced=False`）に昇格し、NewsPicks や YouTube などの動画音声をマイクが拾わないようにする仕組みであることを明記。
  3. `config.json`:
     - `"audio_ducking": "mute"` に設定。録音中（話している間）だけスピーカーを自動消音にし、動画の音声をマイクが拾うのを完全に防止。録音終了時に元の音量に自動復帰するよう設定。
- テストと検証：
  - `tools/audio_ducking_test.py`: 全4項目 PASS。
  - `tools/galaxy_and_snipping_test.py`: 全18項目 PASS。
  - `tools/rules_check.py`: ルール完全適合。
  - `tools/privacy_check.py`: 個人データ混入ゼロ確認。



## 画面囲み検索（Galaxy S25 / Google アプリ風）の完全実動化とワンクリックOCR文字コピー・UI刷新（2026-10-23）
- ユーザー要望：
  - 「ギャラクシーみたいな囲って検索みたいなやつそういう機能がさやっぱり全く動いてないんだよね」
  - 「Googleのアプリ入れて似たようなことできるようにしてるんだけど、スクリーンショットを送ってあげたから、これを元にこれができるようにしてくれないかな」
  - 「動いてない理由とか今おかしくなってる記録残ってるはずだから直してほしい」
  - 「画像とかにある文字をこれ簡単に囲っただけでコピーできるみたいなこともできた方が絶対いいと思うし、そういうのも追加してくれないかな。とにかく実際使えるところまで持ってってください」
- 原因・課題分析：
  1. `app/snipping.py` Line 219 の `audio.Recorder(device_name=..., on_chunk=..., preroll_ms=...)` で、`audio.Recorder` がキーワード引数 `device_name` 等を受け取らない仕様（`on_chunk` のみ）だったため、`TypeError: Recorder.__init__() got an unexpected keyword argument 'device_name'` が発生し、マイク起動および画面AIアシスタントの処理が完全にクラッシュしていた（`logs/koe-type.log` に記録あり）。
  2. `clipdata.set_text(...)` という未定義メソッドを呼び出していたため、コピー時に `AttributeError` が発生していた（正しくは `clipdata.write(0, text=...)`）。
  3. 囲み枠の直下にクイックアクションボタン（画像検索・文字コピー・翻訳）が存在せず、囲んだ画像から文字をワンクリックで抽出・コピーする機能がなかった。
  4. 画面レイアウトが画面下部固定のピル型になっており、添付スクリーンショットのような「囲み枠＋直下ボタン」と「右側縦長Googleアプリ風シート」の使いやすいレイアウトになっていなかった。
- 改善内容：
  1. `app/snipping.py`:
     - `_start_listening`: `audio.Recorder(on_chunk=self._on_audio_chunk)` の引数を修正し、`device_name` と `preroll_ms` は属性代入とすることでマイク起動クラッシュを完全解消。
     - 囲み枠の直下左側に、ユーザーのスクリーンショットと一致するカプセル型3連フローティングボタン（🖼️ 画像検索、📋 文字コピー、文A 翻訳）を GDI+ で描画。
     - 📋 文字コピー（`float_ocr` / `btn_ocr`）クリック時：
       - 画像をクリップボードにPNG保存。
       - Gemini / AI に忠実な文字抽出（OCR）を実行。
       - 抽出テキストを `clipdata.write(0, text=ans)` でクリップボードに即座に格納し、「📋 ○文字をコピーしました」と通知。好きなアプリに Ctrl+V で即座に貼り付け可能に。
     - 🖼️ 画像検索（`float_lens` / `btn_search`）クリック時：
       - 囲み画像をクリップボードに保存し、Google画像検索 / Googleレンズを開く。
     - アダプティブレイアウト：囲み枠の右側に十分な余白（380px以上）がある場合、右側に Google アプリ風の縦長シート（幅 400px、高さ最大 540px）を展開。
     - シート内：Google "G" アイコン、何でも質問バー、サムネイル、🎙️ マイクボタン、↑ 送信ボタン、クイックアクションチップ、AI概要、📋 コピー、🔍 検索、⚙️ APIキー設定ボタンを完備。
  2. `app/transform.py`:
     - `process_screen_assistant` に `action_type="ocr"` の処理を追加。解説や前置きを省き、画像内のテキストのみを忠実に出力するプロンプトを配備。
     - APIキー未設定時でも Google 検索 URL 生成や親切な案内文を返すフォールバックを追加。
  3. `app/vision.py`:
     - `capture_dc_png(hdc, x, y, w, h)` を新設。画面DCから直接PNGバイト列を生成してクリップボードに画像として保存可能に。
- テストと検証：
  - `tools/galaxy_and_snipping_test.py`: 全18項目 PASS（成功 18 / 失敗 0）。
  - `tools/vision_test.py`: 全テスト OK。
  - `tools/transform_test.py`: 全テスト OK。
  - `tools/selftest.py`: 全76項目 PASS（成功 76 / 失敗 0）。
  - `tools/rules_check.py`: ルール完全適合。
  - `tools/privacy_check.py`: 個人データ混入ゼロ確認。


- ユーザー要望：
  - 音声入力中に他のアプリを開いてスクロールしたり、チャットアプリの履歴部分をクリックして確認・スクロールした際、入力欄からフォーカスが外れて音声入力終了時に文字が入らない事態を解消したい。
  - 音声入力を開始した入力欄を記憶し、音声入力終了時に自動的に元の入力欄へフォーカスを復帰させて文字を流し込むようにしてほしい。
  - 既存の「他の場所をクリックしたら音声入力を止める仕組み（`stop_on_click`）」等との相性も配慮してほしい。
- 原因・課題分析：
  1. `app/inject.py` の `paste_text` 内で、前面ウィンドウが録音開始時と異なると即座に `window_changed` として貼り付けを諦め、クリップボード退避のみになっていた（別ウィンドウ参照・スクロール時の未入力原因）。
  2. チャットアプリ等の同一ウィンドウ内をクリックして履歴スクロールした場合、前面ウィンドウは同一（`target_hwnd`）だが、キーボードフォーカスがチャット履歴ビュー等に移っているため、Ctrl+V が入力欄に届かず文字が入っていなかった。
- 改善内容：
  1. `app/inject.py`:
     - Win32 API（`GetGUIThreadInfo`, `AttachThreadInput`, `SetForegroundWindow`, `BringWindowToTop`, `SetFocus`, `ShowWindow`）を用いた `get_focus_control(target_window)` および `activate_window(hwnd, focus_ctrl)` を実装。
     - `paste_text` / `type_text` に `target_focus` 引数を追加し、`restore_target=True`（既定）で対象ウィンドウの前面化と元コントロールへのフォーカス復帰を行ってから貼り付けを実行するよう改修。
  2. `app/schema.py`:
     - 新設定 `restore_focus_on_finish`（音声入力終了時に元の入力欄へ自動で戻す / Auto-restore focus to input field on finish）を追加。既定値 `True`、基本設定。
  3. `app/main.py`:
     - `target_focus_hwnd` の保持。録音開始時に最前面ウィンドウだけでなく、フォーカスを持つ子コントロール（入力欄）の HWND も取得・記録。
     - 録音停止（`_stop_recording`）時、`restore_focus_on_finish` が有効なら直ちに `activate_window` を呼んで元の入力欄へフォーカスを復帰。
     - 保留文字（`_flush_held`）の流し込み時にも、元の入力欄へフォーカスを復帰させてから貼り付け。
     - `_watch_held` において、録音停止後の保留文字は 1.5秒（`HELD_STAY`）を待たずに即時流し込むよう最適化。
     - `stop_on_click`（よそクリックで停止）との親和性：よそをクリックして録音が停止した場合でも、確定文字が消えずに元の入力欄へ自動復帰して安全に注入されるようになり、相乗効果を発揮。
- テストと検証：
  - `tools/mouse_click_test.py`: フォーカス自動復帰、`activate_window`、`paste_text`、`_stop_recording` のテストを追加し全5件 PASS。
  - `tools/selftest.py`: 全76項目 PASS。
  - `tools/galaxy_and_snipping_test.py`: 全18項目 PASS。
  - `tools/rules_check.py`: ルール完全適合。
  - `tools/privacy_check.py`: 個人データ混入ゼロ確認。

## Galaxy S25風「かこって検索」の実動化と長押し即時Gemini音声指示UI・本物音声認識の完全統合（2026-10-23 早朝）
- ユーザー要望：
  - 「ショートカット長押しして実際囲って検索みたいなやつができるようになってない。マウスの矢印がプラスボタンみたいになって範囲選択はできるが、選択しても全く動かないし、全然僕が思い描いてたギャラクシー25みたいな感じにボタン長押ししてくるってやっただけでうまいこと動くことが全然できてないからどうにかしてほしい。」
  - 「囲まなくても長押ししたらGeminiがポッと起動して、実際音声を指示してますよ録音中みたいな専用のボタンも新しく作ってほしい。思ってた使用感と全然違うから全部もう1回やってほしい。」
- 原因・課題分析：
  1. 範囲選択後のパイプライン停止: `app/snipping.py` の `WM_LBUTTONUP` ハンドラ内で、選択矩形を保持して `_phase = "selected"` に移行するだけで、AIへの問い合わせもGoogle検索も何も自動実行されていなかった。
  2. GDI+ の型不一致クラッシュ/停止: `_draw_galaxy_panel` 内で Win32 HBITMAP（`self._screen_hbm`）を GDI+ の `GdipDrawImageRectRectI` にそのまま渡しており、GDI+ 内部で引数エラー（`InvalidParameter`）となって描画パイプラインが失敗していた。
  3. 暗転オーバーレイ自体のキャプチャ: `_prepare_thumbnail` が `vision.capture_window_or_screen()` を呼んでいたため、暗転後の最前面ウィンドウ自体をキャプチャし、対象画像が暗黒・暗転していた。
  4. 音声指示のモック化: `_toggle_voice_input` / `_finish_voice_input` が `time.sleep(0.5)` による固定ダミー文字列であり、本物のマイク録音や音声認識エンジン（SenseVoice / Whisper）が全く接続されていなかった。
- 改善内容：
  1. `app/vision.py`:
     - 生画面DC（`hdc_src`）から直接矩形領域を BitBlt して JPEG バイト列を高速・安全に生成する `capture_dc_rect()` を新設。暗転やUIの写り込みを100%防止。
  2. `app/snipping.py`:
     - **囲んだ瞬間の自動AI実行**: マウスで囲んで離した瞬間、即座に選択領域のキャプチャを抽出し、「✨ AI が画像を解析しています...」として自動で Gemini 3.8 Flash に送信・解説を表示する Galaxy S25 完全同等の即応UXを実装。
     - **StretchBlt による確実なプレビュー**: Win32 GDI の `StretchBlt` を使用してサムネイル枠へ安全かつ高速に描画し、GDI+ の型不一致を根絶。
     - **本物のマイク録音・音声認識の統合**: `audio.Recorder` と `engine.transcribe_pcm` を直接接続。起動した瞬間から音声指示を受付可能とし、話した内容をリアルタイムに文字化して Gemini へ送信。
     - **長押し即時起動＆SpeakPulse Gemini専用録音ボタン**:
       - 起動と同時に画面下部に Galaxy S25 / Gemini 風のバーがポップアップ。
       - 赤（`#E0483A`）とシアン（`#388BFD`）が鼓動する二重パルスリング。
       - マイク音量（RMS）にリアルタイム連動して躍動するイコライザー波形アニメーション（30ms タイマー）。
       - 1.8秒の無音検知、またはEnterキー/マイクボタン再クリックによるスムーズな自動送信。
     - クイックアクションチップ（「🔍 Google検索」「✨ AIに質問」「📝 文字抽出」「🌐 翻訳」）および「📋 コピー」ボタンの完全連動。
- テストと検証：
  - `tools/galaxy_and_snipping_test.py`: 全18項目 PASS（キャプチャ、初期状態、音声バッファ、RMS計算、ボタンハンドラ、ショートカット長押しタイマー）。
  - `tools/selftest.py`: 全76項目 PASS。
  - `tools/rules_check.py`: ルール完全適合。
  - `tools/privacy_check.py`: 個人データ混入ゼロ確認。
  - Smart App Control 適合（外部 pip ゼロ、ctypes + 標準ライブラリのみ）。

- ユーザー要望：
  - 客観的にテスト・ゼロから触る視点で、コード・機能をテストしまくって不具合やバグをすべて洗い出し改善する。
  - 設定の UI/UX やデザインの使いづらさを改善する。
  - 音声難民風の古いアイコンを刷新するため、1枚の画像に8〜10個の新しいアプリアイコン候補を生成して提示する。
  - アプリ自体の名前のリブランディング（新名称案）を提案する。
- 原因・課題分析：
  1. `config_features_test.py`: `app/websettings.py` の `run_action` 内でローカルに `from . import schema` していたため、他のアクションで `UnboundLocalError` が発生してクラッシュしていた。
  2. `action_mode_test.py`: `app/main.py` の `_handle_action` 内で `ApiRequiredError` の通知・リターン処理のインデントが誤って `except` の外に出ており、正常実行時でも未定義の `inst_label` を参照して `UnboundLocalError` でクラッシュしていた。
  3. `ai_editor_test.py`: クリップボードの詳細設定（保存件数、日数等）が基本設定に溢れ、基本項目上限（36件）を超過（41件）していた。
  4. `vision_test.py`: 画面AIアシスタントのデフォルトモデルが古い `gemini-2.0-flash` のままで、キー未設定アサーションが一致していなかった。
  5. UI/UX: 「AI・文章変換」画面で長大なプロンプトが常時全文展開され、画面がスクロールだらけで一覧性が著しく低下していた。
- 改善内容：
  1. `app/websettings.py`: `run_action` 内の重複ローカルインポートを削除し、スコープ解決バグを解消。
  2. `app/main.py`: `_handle_action` の例外ハンドラ内インデントを正しく修正し、正常系の変換結果が確実に貼り付けられるよう修正。
  3. `app/schema.py`: クリップボードの詳細数値項目（件数・日数等）を `advanced=True` に整理し、基本設定数を 36 に収め、すっきりした情報設計を実現。
  4. `app/transform.py` & `tools/vision_test.py`: 画面AIアシスタントの既定モデルを最新の `DEFAULT_GEMINI_MODEL` に統一し、テストを更新。
  5. `app/web/app.js` & `app/web/app.css`:
     - AI指示文カードのプロンプト文を初期コンパクト表示（2行プレビュー）化。
     - クリックでスムーズに全文展開、または編集モーダルを開く直感的なアコーディオンUIを新設。
     - カードの縦幅を半減させ、全14種超の変換機能が一目で把握できる高い一覧性を実現。
  6. アイコン画像生成（`generate_image`）:
     - 鮮やかで象徴的なプロダクト系 9選（`app_icon_concepts`）と、洗練されたラグジュアリー・ミニマル系 9選（`minimal_icons_grid`）の計18種類のアイコンデザインを生成。
  7. 新アプリ名提案:
     - 「VoxFlow」「TypeVox」「QuillAI」「SpeakPulse」「KoeMind」等、音声×AI×クリップボード×文章作成の総合ツールにふさわしい新名称 10選を設計。
- テストと検証：
  - `tools/selftest.py`: 全78項目 PASS。
  - `tools/clip_test.py`: 全200項目 PASS。
  - `tools/config_features_test.py`: 全項目 PASS。
  - `tools/action_mode_test.py`: 全4項目 PASS。
  - `tools/ai_editor_test.py`: 全15項目 PASS。
  - `tools/vision_test.py`: 全項目 PASS。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無キー送信（SendInput遮断）・無音厳守。



## Gemini 404解消・自動フォールバック、ユーザー辞書269語拡充、「AI・文章変換」名称刷新（2026-10-22 早朝）
- ユーザー要望：
  - 「ユーザー辞書なんだけどさみんなよく使う言葉だかあるじゃんなんか多分いっぱいあるからさそこら辺調べてさあの大量に追加しといてくれないかな多分特にグーグルと含めてさ、いろいろあるじゃんアプリの名前ジーメールであったりとかなんかそこら辺結構音声入力だとバグりやすいものみたいなやつも含めて ささ入れといて」
  - 「あとまた接続テストうまくいかないからなんかやぱここら辺んすごいバグりやすいからさ全部ちゃんと直しといてくれないかな」
  - 「あと文章変換っていうアプリ名になってるけど、明らかに文章変換だけじゃくいかないからかここら辺いら全れ文章変換アプリ明ら文機特文字変換能 ほ方がいいんじゃないかなと思います」
- 原因・課題分析：
  - API接続テストの 404 エラー: Google Gemini API 公式ドキュメントの調査により、`gemini-2.0-flash` が 2026年6月1日に提供終了（shutdown）していたことが判明。Google サーバーから 404 Not Found が返却されていた。
  - ユーザー辞書の定番語彙: 初期の `dictionary.sample.txt` は約40語のみで、Gmail や Google 各種アプリ、Slack、Notion、AI用語（ChatGPT/Claude等）、開発用語、カタカナ語の音声誤認識に対応しきれていなかった。
  - アプリ内の「文章変換」名称: AI要約・翻訳・校正・プロンプト生成・Galaxy S25風の画面AI機能まで含むにもかかわらず「文章変換」となっており、実態と乖離して分かりづらかった。
- 改善内容：
  1. `app/transform.py`:
     - 既定の Gemini モデルを最新の思考対応モデル `gemini-2.5-flash` に更新。
     - `_GEMINI_FALLBACK_MODELS = ("gemini-2.5-flash", "gemini-3.8-flash", "gemini-3.6-flash", "gemini-1.5-flash")` を定義。
     - `call_gemini` / `call_gemini_multimodal` / `test_api_connection` に 404 自動フォールバック機構を導入。指定モデルが廃止・不在でも推奨モデルへ自動フォールバックして再試行・接続成功させる安全設計を実装。
  2. `app/web/app.js`:
     - Gemini の選択肢を最新世代（2.5 Flash（推奨・最新安定）、3.8 Flash（次世代フラッグシップ）、3.6 Flash、1.5 Flash、1.5 Pro）に更新。
     - 接続テスト結果ボックスで警告（`warning`）がある場合の通知表示を強化。
  3. `dictionary.sample.txt`:
     - 登録単語数を約40語から **269語** へ大幅拡充。
     - Google 関連サービス（Gmail、Google ドライブ、Google スプレッドシート、Google Meet、Google Chrome、Google カレンダー、Google マップ 等）の表記・よみ・誤認識置換を網羅。
     - 定番アプリ・ビジネスツール（Slack、Notion、Zoom、Teams、Discord、LINE、Chatwork、Trello、Figma 等）。
     - 最新 AI・LLM用語（ChatGPT、Claude、Gemini、Copilot、Perplexity、DeepSeek、OpenRouter、プロンプト、RAG、マルチモーダル等）。
     - 開発・エンジニア・クラウド用語（GitHub、VS Code、Docker、Kubernetes、AWS、Azure、Next.js、TypeScript、デプロイ、プルリク等）。
     - 音声入力でカタカナや別漢字に誤認識されやすいビジネス定型語（MTG、アジェンダ、リスケ、スクショ、URL 等）。
  4. `app/schema.py` / `app/i18n.py`:
     - 設定画面カテゴリおよびナビゲーションメニューの名称を「文章変換」から「**AI・文章変換**」（英語: "AI & Actions"）に刷新。説明文も AI やルールによるアクションを含む実態に整合。
     - レシピ選択・一覧関連の文言も「AI・文章変換を選ぶ」等へ統一。
  5. `app/clipwin.py` / `tools/clip_test.py`:
     - タブ順序の `where == "second"` フォールバック処理の整合性を確保し、テストアサーションを更新。
- テストと検証：
  - `tools/selftest.py`: 全78項目 PASS（成功 78 / 失敗 0）。
  - `tools/clip_test.py`: 全200項目 PASS（成功 200 / 失敗 0）。
  - `tools/transform_test.py`: 全項目 PASS。
  - `tools/display_and_dict_test.py`: 全39項目 PASS。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無音・無キー送信（`KOE_TYPE_DRY_RUN=1`）を厳守。



## AI連携モーダルの文字はみ出し解消と接続テスト実行時エラー修正（2026-10-22 早朝）
- ユーザー要望：
  - 「うまくいかないしなんか文字はみ出しちゃってるからさなんかうまいこと直してくれないこれ でも、エアイの鍵のパスワードというかは間違ってないです絶対に」
- 原因・課題分析：
  - ユーザー提供のスクリーンショットを確認したところ、赤色のエラーメッセージとして「✗ エラー: action is not defined」が表示されていた。`openApiKeyDialog` 内で `runAction` ではなく未定義の `action` を呼んでいたため、JavaScript の参照エラーが発生し、接続テスト通信が一切送信されていなかった（ユーザーの API キーが原因ではなく、JS 関数のタイポバグ）。
  - ダイアログ（`.dialog`）の幅が最大 440px と狭く、さらに CSS Grid（`grid-template-columns: repeat(3, 1fr)`）において各タブに `min-width: 0` がなかったため、「Anthropic Claude」などの長い英字テキストでセルの最小固有幅が押し広げられ、ダイアログの右枠を突き破ってはみ出していた。
- 改善内容：
  1. `app/web/app.js`:
     - 接続テストハンドラ内の `action("test_api", ...)` を `runAction("test_api", ...)` へ修正。
     - ダイアログ展開時に `body.classList.add("dialog-wide")` を付与。
  2. `app/web/app.css`:
     - `.dialog.dialog-wide` を新設し、横幅を 560px へ拡大。
     - `.ai-prov-tabs` の各カラムに `minmax(0, 1fr)` を指定。
     - 各タブの `strong` および `.ai-prov-tab-sub` に `overflow: hidden; text-overflow: ellipsis; white-space: nowrap;` を適用。どんな画面幅・テキスト長でも絶対に枠からはみ出さない堅牢なレスポンシブ設計に修正。
- テストと検証：
  - `tools/edgeshot.py` によるヘッドレス撮影（`ai_modal_openrouter.png`）: 560px のゆったりした幅で全タブが美しく収まり、文字のはみ出しが 1px もなく完全に解消されたことを視覚確認。
  - `scratch/test_bridge_action.py`: `run_action("test_api", ...)` によるバックエンドテストの正常稼働を確認。
  - `tools/selftest.py`: 全78項目 PASS（成功 78 / 失敗 0）。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無音・無キー送信（`KOE_TYPE_DRY_RUN=1`）を厳守。



## 複数AIプロバイダー（Gemini/OpenRouter/Claude）完全対応・接続テスト新設・Galaxy S25連携（2026-10-22 深夜）
- ユーザー要望：
  - AIレンズ、声でメールスニペット、タイムマシーンを実装してほしい（考えておいてほしい）。
  - 前に言っていた「Galaxy S25みたいなこと（かこって検索等）」がこのパソコンでもちゃんとできるようになっているか確認したい。
  - APIに関して、Gemini だけでなく OpenRouter などにも接続できた上で、どれにするか自分で切り替えられるようにしてほしい。
  - APIの設定周りがバグったりするので、うまいことちゃんと作り込んでほしい。
- 原因・課題分析：
  - `websettings.py` の `_HIDDEN_TEXT_KEYS` に `ai_provider` が登録されておらず、フロントエンドからプロバイダーを切り替えて保存しようとしても `unknown key: ai_provider` で弾かれ、Gemini に戻ってしまう致命的なバグが存在していた。
  - 設定画面のモーダルが「Gemini API キー設定」専用で固定されており、OpenRouter や Claude の選択肢やキー取得リンク、代表モデル（Claude 3.5 Sonnet, GPT-4o, DeepSeek 等）が選べなかった。
  - APIキーを入力しても正しく接続できるか確認する「接続テスト」機能がなく、レートリミットや無効キーでエラーになっても原因が分からなかった。
  - 既に実装されていた Galaxy S25風のかこって検索（`Ctrl+Alt+J`）が Gemini 専用のマルチモーダル呼び出しになっており、OpenRouter 選択時に連動していなかった。
- 改善内容：
  1. `app/websettings.py`:
     - `_HIDDEN_TEXT_KEYS` に `"ai_provider"` を追加し、フロントからのプロバイダー設定保存を確実に許可。
     - `run_action` に `test_api` ハンドラを追加し、テスト通信を仲介。
  2. `app/transform.py`:
     - `test_api_connection(api_key, provider, model)` を新設。標準ライブラリ（urllib）のみで ping プロンプトを送信し、レイテンシ（ms）計測と HTTP 401/403/404/429 等の具体的エラー理由を日本語で返却。
     - `call_openrouter_multimodal` を新設し、OpenRouter の OpenAI 互換画像フォーマットに対応。
     - `call_llm_multimodal` を新設し、`process_screen_assistant`（Galaxy S25風かこって検索・画面AI）が OpenRouter 利用時でもシームレスに動作するよう統合。
  3. `app/main.py`:
     - `process_screen_assistant` 呼び出し時に `provider=ai_provider` を渡すよう改修。
  4. `app/web/app.js`:
     - API設定モーダルを「AI (LLM) 連携・プロバイダー設定」としてフルリニューアル。
     - Google Gemini / OpenRouter / Anthropic Claude の 3 タブ切り替え。
     - APIキー入力欄（👁パスワード表示切替付き）、各サービスの取得リンク。
     - プロバイダーに応じたモデル自動切り替え＋手動自由入力。
     - 「🔌 接続テストを実行」ボタンを追加し、その場で応答速度やエラーをリアルタイム表示。
     - トップステータスバーに現在のプロバイダー名とモデルを動的表示。
  5. `app/web/app.css`:
     - `.ai-prov-tabs`, `.ai-prov-tab`, `.ai-test-result` 等のモダンなスタイリングを追加。
- テストと検証：
  - バックエンド接続テスト（`scratch/test_api_test.py`）: 全テスト合格。
  - Edge ヘッドレス画像キャプチャ（`ai_modal_openrouter.png`, `shots/ai-dark-wide.png`）: 美しいUIと動作を確認。
  - `tools/selftest.py`: 全78項目 PASS（成功 78 / 失敗 0）。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無音・無キー送信（`KOE_TYPE_DRY_RUN=1`）を厳守。



## クリップボード設定のゼロベース再編とタブ並び替え（ドラッグ＆ドロップ／長押し／上下ボタン）UI実装（2026-10-22 深夜）
- ユーザー要望：
  - クリップボードの種類ごとに分けるタブの並び替えを、ボタンを上下に長押しして動かしたり、直感的な操作でもっとこだわりを持って簡単に並び替えられるようにしてほしい。
  - クリップボード自体の設定が分かりづらすぎるので、全体的にもう少しゼロから見直して使いやすくしてほしい。
- 原因・課題分析：
  - 従来のクリップボード設定は 9 つもの小さなグループに細分化されており、「よく使う・並び順」「ダウンロード」「並び順」と並び順に関する項目が 3 箇所に分散していた。
  - カード内にトグルスイッチがあるのに、カードのすぐ下にも同一設定のトグルスイッチ（`clip_show_frequent` / `clip_downloads`）が重複表示され、散乱・混乱を招いていた。
  - 従来のタブ並び順は固定プリセット4択のラジオボタン形式のみであり、自分の好みの順序（例: 「ダウンロード」を先頭、「自作グループ」を履歴の次など）を自由にカスタマイズできなかった。
- 改善内容：
  1. `app/schema.py`:
     - 散乱していた 9 グループを目的別に 5 つ（＋上級者向け 2 つ）へスッキリ集約・再編：
       ① 基本・ショートカット
       ② タブの種類と並び順（並び替えカード、履歴ソート、固定ピン上、集計期間）
       ③ 一覧の見た目（位置、文字サイズ、プレビュー）
       ④ 定型文・パスワード（自作グループ）
       ⑤ 保存期間・プライバシー（件数、期間、画像保持、除外アプリ、秘密自動クリア）
       ⑥ 貼り付け設定、⑦ データ管理・保守（詳しい設定のみ）
     - 重複していた下部トグル（`clip_show_frequent`, `clip_downloads`）を `advanced=True` に整理し、カード内スイッチに役割を集約。
     - 自由なタブ順序を保持する `clip_tab_order`（デフォルト: `["history", "frequent", "groups", "downloads"]`）を新設。
  2. `app/clipwin.py`:
     - `_tabs()` において、`clip_tab_order` 配列で指定された順序でタブを動的に組み立てるよう改修（未設定時は従来の `clip_tab_order_mode` へフォールバック）。
  3. `app/i18n.py`:
     - `cweb.tab_order_title`, `cweb.tab_order_help`, 各タブのタイトル・説明文、`cweb.tab_cycle_flow`, `cweb.tab_reordered` などの日英対訳を追加。
  4. `app/web/app.js`:
     - タブ並び替え専用パネル `panelClipTabOrder()` を実装。
     - **HTML5 Drag & Drop**: カードを掴んで上下に引っ張りドロップ。
     - **PointerEvents 長押しドラッグ**: 150ms の長押しでカードを掴んで指やマウスで追従ドラッグ（スマホ・タッチ対応）。
     - **▲ / ▼ ボタン**: ワンクリックで隣と位置を入れ替え（端は disabled）。
     - **タブ内トグルスイッチ**: 「よく使う」「ダウンロード」の表示/非表示をカード内で即座に切り替え。
     - **巡回順プレビューバー**: 現在の巡回順をピルタグで可視化（非表示タブは打ち消し線）。
     - 変更時に `setValue("clip_tab_order", ...)` で即座に保存・トースト表示。
  5. `app/web/app.css`:
     - `.clip-tab-card`: ホバー効果、ドラッグ中の浮き上がりシャドウ（`box-shadow: 0 10px 24px`）、ドロップターゲットライン（`border-top/bottom: 2.5px solid var(--accent)`）。
     - `.btn-tab-up`, `.btn-tab-down`: 32px×32px で枠線と背景を持たせ、視認性と押しやすさを大幅改善。
- テストと検証：
  - 単体ロジック検証 (`scratch/test_tab_order_logic.py`): downloads先頭、frequent先頭、非表示時の除外など全アサーション合格。
  - Edge ヘッドレス画像キャプチャ (`clipboard_redesign_full.png`): 整然とした設定画面とカードUIを確認。
  - `tools/selftest.py`: 全78項目 PASS（成功 78 / 失敗 0）。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無音・無キー送信（`KOE_TYPE_DRY_RUN=1`）を厳守。


## 見た目のプレビュー「大きさ」変更の動的連動・アニメーション化と基準ガイド枠の追加（2026-10-22 深夜）
- ユーザー要望：
  - 設定画面の「見た目のプレビュー」で、「大きさ」（小/中/大/特大）を変更してもプレビュー上の見た目が変わっていないように見えるので、ちゃんとリアルタイムに対応させてほしい。
- 原因：
  - 設定画面（`app/web/app.js`）のプレビュー描画関数 `renderOverlayPreviewContent()` において、設定値が切り替わるたびに `widgetWrap.replaceChildren()` で DOM を完全に破棄・再生成していたため、CSS トランジションが一切発火せず、静止したまま描画が置き換わっていた。
  - 従来のスケール倍率（0.86x〜1.48x）では黒背景の広いステージ上において「小」と「中」などの差がわずか数ミリしかなく、変化が知覚しにくかった。
  - 基準となる枠線がなく相対的なサイズ変化が把握しづらかった。
  - 録音色選択（`swatchControl`）からのプレビュー更新コールバック（`afterChange`）も欠落していた。
- 改善内容：
  1. `app/web/app.js`:
     - 形状（design）や文字表示有無が変わらないサイズ・色の変更時は、DOM 要素を破棄せず既存の `.opw-box` を保持したまま `style.transform = scale(${scale})` および `--opw-accent` を直接更新。
     - これにより、CSS の `transition: transform 0.28s cubic-bezier(0.34, 1.56, 0.64, 1)` が確実に発火し、サイズボタンを押した瞬間に弾むように拡大縮小するスムーズな視覚フィードバックを実現。
     - 視覚的メリハリを出すため倍率を明確化（小: 0.76x, 中: 1.0x, 大: 1.30x, 特大: 1.65x）。
     - フッター情報に各形状に応じた概算ピクセル幅（例: 小 274px 〜 特大 594px）をリアルタイム表示。
     - `swatchControl` にも `afterChange` を追加し、カラーパレット選択時も即座にプレビューへ反映。
  2. `app/web/app.css`:
     - `.overlay-preview-stage`: ステージ領域を拡大（`min-height: 150px`）。
     - `.overlay-preview-stage::before`: ステージ中央に「標準サイズ（1.0x）基準ガイド枠」（点線枠）を新設。標準との対比により小のコンパクト感や特大の広がりが直感的に伝わる。
     - `.opw-box`: `will-change: transform;` と滑らかなイージングを設定。
     - `.opw-badge-size`: サイズ変更時にポップアニメーション（`opwBadgePop`）で強調。
- テストと検証：
  - `tools/edgeshot.py` による Edge ヘッドレスでのプレビュー確認（小・中・大・特大でのサイズ変化と基準枠対比を画像検証）。
  - `tools/selftest.py`: 全78項目 PASS（成功 78 / 失敗 0）。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無音・無キー送信（`KOE_TYPE_DRY_RUN=1`）を厳守。

## Enter送信末尾文字の完全校正、最初の一言目のブレ改善、クリップボード頻出タブ＆並び替え（2026-10-22 深夜）
- ユーザー要望：
  - Enterを押して自動送信する際、文末が変な文字（未校正・崩れた文字）になって送信されてしまうのを直してほしい。
  - 最初の一言（「はい」「了解」「確認」等の短い言葉）を話した際のブレや認識精度の悪さを改善してほしい。
  - クリップボード履歴で、直近1週間に頻繁に使われたパスワードや定型文などのアイテムを自動集計・記録する「よく使う」タブを作ってほしい。
  - クリップボード履歴の各タブ（「よく使う」「ダウンロード」「自作グループ」等）の並び順を変更できるようにし、同じショートカット（Tabキー等）で素早く切り替えられるようにしてほしい。
- 改善内容：
  1. `app/main.py`:
     - **Enter送信時 pending 文字の完全校正・辞書置換・文末整形**:
       `_stop_recording()` において、未確定文字列 `self.agreement.pending()` を
       入力キューへ投入する前に `self._clean(pending_text, final=True)` を
       確実に通すよう修正。ユーザー辞書置換、文末の助詞や句読点、半角英数字
       整形を確実に適用してから送信キューへ送るよう徹底。
     - **極小ノイズ PCM の除外**: カッターから flush された 0.15 秒未満の
       極小ノイズ（打鍵音等）が Whisper に渡ってハルシネーション（誤認文字）
       を起こすのを防ぐため、有効長未満の PCM をスキップし pending テキスト
       を活かす安全制御を追加。
     - **VAD カッターの初言パラメータ最適化**:
       `_build_cutter()` の `preroll_ms` を 200ms から 350ms に拡大し、
       発話先頭の子音の立ち上がり（「k」「s」「t」「h」等）の頭切れを解消。
       `merge_short_ms` を 1000ms から 400ms に短縮し、「はい」「了解」
       などの短い一言目が言いよどみと判定されて 1.5 秒滞留・変形する問題を解決。
  2. `app/clipstore.py`:
     - `FREQUENT = -2` を定義。
     - `frequent_items(days=7, min_count=1, limit=60)` メソッドを新設。
       直近7日間に貼り付け等で使用された回数（`use_count`）の多い順、
       同数の場合は最近使用された順にアイテムを取得。
  3. `app/clipwin.py`:
     - `_tabs()` を拡張し、`FREQUENT` タブ（「よく使う」）の表示と、
       設定 `clip_tab_order_mode` によるタブ並び順の動的カスタマイズに対応。
       （`frequent_first`, `downloads_first`, `groups_first`, `frequent_downloads`）
     - `_items(gid)` にて `gid == FREQUENT` のとき `store.frequent_items()` を
       呼び出すよう配線。
  4. `app/schema.py` & `app/i18n.py`:
     - `preroll_ms`（350ms）および `merge_short_ms`（400ms）の既定値を更新。
     - `clip_show_frequent`（「よく使う」タブ表示）、`clip_frequent_days`（集計期間）、
       `clip_tab_order_mode`（タブ並び順）を設定スキーマに追加。
     - 多言語対応ラベル `"clip.tab_frequent"`（「よく使う」 / "Frequent"）を追加。
- テストと検証：
  - `tools/selftest.py`: 全78項目 PASS（成功 78 / 失敗 0）。
  - `tools/rules_check.py`: 厳守ルール完全適合。
  - `tools/privacy_check.py`: 個人情報ゼロ確認。
  - 無音・無キー送信（`KOE_TYPE_DRY_RUN=1`）を厳守。

## 表示機能の大幅進化（新形状・サイズ位置昇格・動的プレビュー・実機テスト）＆初期ユーザー辞書の充実（2026-10-22 深夜）
- ユーザー要望：
  - オーバーレイの形（ピル、波のバー、カード）の種類をもうちょっと増やしてほしい。
  - 選択肢の文字だけだとどういう表示になるかよく分からないので、選択したらリアルタイムに見本が見れるようにしてほしい。
  - サイズや表示位置（カーソルの近くか固定か等）も選べるようにしてほしい。
  - ユーザー辞書に、Gmail, Google, Slack, Discordなど誰もが使うITツール名や日常フレーズ、ChatGPT, Claude, GeminiなどのAI単語を最初から登録しておいてほしい。
- 改善内容：
  1. `app/overlay.py`:
     - **新デザイン2種を追加し全5種へ拡充**:
       - `dot`（コンパクト）：入力欄や作業領域を一切遮らない極小角丸カプセル（LED＋極小波形＋時間）。
       - `caption`（字幕テロップ）：映画やライブ配信の字幕のように横長ですっきり伸び、未確定テキストが大きく流れるモダンデザイン。
     - `_render_dot()`, `_render_caption()` を GDI+ で実装し、整数ピクセル丸めと各テーマ（light/dark）・録音カラー連動に対応。
     - `tools/overlay_options.py` による全61パターンのレンダリング画像生成テストを実施し、全数パス。
  2. `app/schema.py`:
     - `overlay_design`: `dot`（コンパクト）、`caption`（字幕テロップ）を選択肢に追加。
     - `overlay_size`（小・中・大・特大）および `overlay_position`（下の中央・右下・上の中央・カーソルの近く）の2項目を、隠し設定（`advanced=True`）から「基本設定（`advanced=False`）」へ昇格。固定位置とカーソル自動追従の違いを日本語で明記。
     - `overlay_preview`（カスタムパネル）を「表示」タブの最上部に新設。
  3. `app/web/app.js` & `app/web/app.css`:
     - **リアルタイム動的プレビュー (`panelOverlayPreview`)**:
       - 選択されているデザイン（ピル／波のバー／カード／コンパクト／字幕テロップ）、大きさ倍率（0.86x〜1.48x）、録音カラー（9色）、表示位置がリアルタイムに連動するアニメーション付きプレビュー領域を構築。
       - イコライザーバーの音量アニメーション（`@keyframes eqBounce`）を実装。
       - **デスクトップ実機テスト表示ボタン (`test_overlay`)**: クリックすると、実際の画面上に本物のオーバーレイが3秒間アニメーション付きでポップアップし、デスクトップ上で使用感を即座に確認可能。
     - **ユーザー辞書に「✨ 定番・AI単語パックを追加」ボタンを設置**:
       - ワンクリックで最新の必須単語群を辞書へマージ取り込み可能。
  4. 初期ユーザー辞書の充実 (`dictionary.sample.txt`):
     - **AI関連**: ChatGPT, Claude, Gemini, Copilot, Perplexity, LLM, GPT-4o, DeepSeek, Midjourney, Stable Diffusion, プロンプト, 生成AI, トークン等。
     - **定番ITツール**: Gmail, Google, Slack, Discord, YouTube, Twitter/X, Notion, Zoom, GitHub, Dropbox, Chrome, Safari, Edge, Windows, Mac, iPhone, Android, Excel, Word, PowerPoint, Google Drive等。
     - **ビジネス・PC操作頻出フレーズ**: 「よろしくお願いいたします」「お疲れ様です」「ご確認のほどよろしくお願いいたします」「承知いたしました」「かしこまりました」「取り急ぎご連絡まで」「共有いただきありがとうございます」「スクリーンショット」「リポジトリ」「プルリクエスト」「ログイン」「再起動」等。
  5. `tools/display_and_dict_test.py`:
     - 新デザイン定義、GDI+描画、サイズ・位置の設定属性、辞書パックインポート、重複防止、実機テストディスパッチを網羅した自動テストを新設し、全39項目PASS。
- 効果：
  - オーバーレイの見た目・サイズ・位置を迷うことなくリアルタイムに確認・調整でき、画面の邪魔にならない極小表示から大画面向けの字幕表示まで用途に合わせた最適な表示を選択可能になった。
  - パソコン操作やビジネスチャットで頻出するツール名・語句やAI用語が、最初から完璧な大文字小文字・正式名称でストレスフリーに入力できるようになった。

## Enter送信時の未確定文字完全フラッシュ＆使用感プリセット新設（2026-10-21 深夜）
- ユーザー要望：
  - Enterを押した時に残っている文字が全部入ってからEnterが送信される仕組みが機能していないので修正してほしい。
  - 設定項目が多くて組み合わせで不具合が出たり迷ったりするので、「こういう使用感にしたい人はこれ」というおすすめプリセットを設定画面で選べるようにしてほしい。
- 改善内容：
  1. `app/main.py`:
     - **未確定文字破棄バグの解消**: `one_round()` 内の `if not self._stream_alive(session): return` を削除。録音停止キー（Enter等）が押された瞬間に認識スレッドから上がってきた最新テキストを破棄せず、`Agreement` へ確実に反映するよう改善。
     - **停止時 pending 文字列の強制フラッシュ**: `_stop_recording()` にて、音声末尾が無音等で `cutter.flush()` が空の場合でも、`self.agreement.pending()` に残存している未確定テキストを即座に `(TEXT, ...)` としてワーカーキューへ投入。
     - **Enter送信ディレイの十分な確保**: `_worker_loop()` 内の `SUBMIT` 処理において、テキスト貼り付けが対象アプリの DOM や UI に反映される前の Enter 送信空振りを防ぐため、最低ディレイを 150ms（既定 200ms）に拡大。
  2. `app/schema.py`:
     - **用途別 4 大おすすめプリセット定義 (`PRESETS`)**:
       - 💬 **チャット・SNS即時送信** (人気): Enterで即送信、待ち220ms、入力欄外クリックで停止、句点なし
       - 📝 **長文執筆・レポート作成** (執筆): Enter誤送信オフ、クリック停止なし、文末句点あり
       - 💻 **プログラミング・CLI** (開発): 直接キー入力、クリップボード非経由、句点なし、半角英数重視
       - 🔰 **初心者・安心スタンダード** (標準): どこでもクリック停止、失敗時クリップボードバックアップ、スマート句点
     - `enter_delay_ms` の既定値を 120ms → 200ms、選択肢を (100, 200, 400) に更新。
     - `general` カテゴリ最上部に `preset_selector` を追加。
  3. `app/websettings.py` & `app/web/app.js` & `app/web/app.css`:
     - フロントエンドへ `STATE.presets` を公開し、ワンクリックで設定を一括書き換える `apply_preset` アクションを配線。
     - 設定画面「一般」タブの最上部に、用途・特徴タグ・現在適用中バッジを備えたプレミアムなプリセットカード UI を実装。
     - `i18n.py` に `presets.current`, `presets.is_active`, `presets.apply` を追加。
  4. `tools/preset_and_submit_test.py`:
     - プリセット定義、設定一括適用、および停止時の `pending()` フラッシュの挙動を検証する自動テストを新規作成し、全項目 PASS。
- 効果：
  - 話し終わりに素早く Enter を押しても、話した文字が 1 文字も欠落せず入力欄へ完全に流し込まれてから送信キーが叩かれるようになった。
  - チャット、執筆、コーディングなど利用者の用途に応じた最適な設定の組み合わせを、ワンクリックで安全・確実に切り替え可能になった。

## 文章変換レシピ画面の二段階カテゴリタブ新設・スクロール不要UI化（2026-10-21 夜）
- ユーザー要望：
  - 機能が多くなって縦スクロールしないといけない状態になっている。
  - スクロールは気づきにくく面倒なので、普段のAPIによる文章作成と便利ツールを二段階に切り替えられるようにしたい。
  - 同じショートカット連打ではなく、一番上のあたりにメニュー（タブ）が出ていて、それをクリックして切り替えられるUIにしてほしい。
- 改善内容：
  - `app/i18n.py`:
    - タブ用文言 `recipe.cat_all` ("すべて" / "All"), `recipe.cat_text` ("文章作成・AI" / "AI Writing"), `recipe.cat_tools` ("ツール・計算" / "Tools & Calc"), フッターヒント `recipe.hint_category` ("カテゴリ切替" / "switch tab") を追加。
  - `app/recipes.py`:
    - `CATEGORIES`: ("all", "text", "tools") を定義。
    - `Recipe.category`: 所属カテゴリ（"text" / "tools"）を保持。
    - `categorize_recipe()`: レシピIDから文章作成系とツール系（スマート計算、画面アシスタント等）を自動分類。
    - `RecipeModel`: `set_category_index()`, `next_category()`, カテゴリ別の絞り込み表示、Tab / Shift+Tab キーおよびテキスト未入力時の左右矢印キーによるカテゴリ巡回を実装。
    - `RecipeLayout` & `RecipeView`: タイトル直下にタブバー領域（`lay.tab_bar` / `lay.tabs`）を配置し、アクティブタブにはアクセント下線バーを描画。マウスクリック判定（`hit()` で `("tab", index)`）を実装。
  - `app/clipwin.py`:
    - `_on_up()` 内で `what == "tab"` を処理し、マウスクリックで瞬時にカテゴリ切り替え＆再描画されるよう配線。
  - `tools/clip_test.py`:
    - Tabキーによるカテゴリ巡回、カテゴリ絞り込み、およびマウスクリックによるタブ切り替えの自動テストを追加。全200項目PASS。
- 効果：
  - 各カテゴリに絞り込まれることで項目数が5〜7件に収まり、縦スクロールバーが完全に消え、1画面内で全機能が一目瞭然に。
  - 1〜9の数字キーでの一発選択が常に快適に機能。

## 文章変換の根本不具合改善・全機能テスト網羅検証・競合先進5大キラー機能の追加（2026-10-21 未明）
- ユーザー要望：
  - 文章変換がうまくいっていない時が多いので、再度全機能をテストし、おかしい点がないか徹底的に検証・改善してほしい。
  - 就寝中のため音声をスピーカーから出さない方針を厳守すること。
  - 競合（Superwhisper, Whisperメモ, Notion AI等）にある便利機能や、競合にないkoe-type独自の革新的な機能を許可なく自律的に追加し、内容を詳細に報告すること。
- 不具合の原因究明と改善：
  1. `app/main.py`:
     - **Whisper直接翻訳の優先バグ解消**: `api_key and not is_offline`（クラウドLLM利用可能時）でもWhisperの直接翻訳（`task="translate"`）が走ってしまい、粗い直訳英文が生成されていた問題を修正。高品質な日本語文字起こしを行ってからクラウドLLMに渡すことで、文脈に忠実で流暢な英文入力を実現。
     - **Controller `_action_name` 欠落バグ修正**: アクションモードやカスタム指示キーから起動した際に `act_name = self._action_name(action)` で `AttributeError` が発生する潜在バグを特定し、`_action_name(self, action: str) -> str` を実装。
     - **クリップボード自動参照の統合**: `inject.clipboard_text()` を自動取得し、変換エンジン `transform.transform_text(..., clipboard_text=cb_text)` へ渡すよう配線。
  2. `app/transform.py`:
     - **AI出力自動クレンジング `clean_ai_output`**: クラウドLLMが返すマークダウンコードブロック（```...```）、定型的な前置き挨拶（「承知いたしました」「はい、作成した〜」）、外側引用符（"...", '...', 「...」）を完全除去し、100%純粋な本文のみを入力欄へ送信。
     - **プロンプトマクロ `{clipboard}`**: プロンプトテンプレート内の `{clipboard}` をコピー済みテキストに置換する `fill_prompt` を実装。
     - **敬語・ビジネス敬語オフライン変換ルールの40件超大幅拡充**: 「〜なきゃ」「〜しないと」「〜たいな」「〜かも」「〜はずだ」「わかりました」「質問があります」「どうですか」などの口語表現を自然な敬語へ変換するルールを追加。
  3. `app/inject.py`:
     - `_dryrun_clipboard` を導入し、から打ちモード下で `set_clipboard_text` と `clipboard_text` が安全・ハーメチックに連動するよう改善。
- 競合機能・koe-type独自キラー機能の追加：
  1. `reply_generator` (返信文ジェネレーター: コピーした相手のメッセージを参照し、音声で話した要件・トーンに沿った自然な返信文を即座に作成)
  2. `meeting_minutes` (議事録・ミーティング要約: 会議・メモ音声を決定事項・保留・ネクストアクションに構造化)
  3. `proofread` (文章推敲・校正: 誤字脱字・てにをは・助詞重複・ら抜き言葉を検出してリライト)
  4. `standardize` (標準語・公用文化: 口語や方言・ネットスラングをビジネス・公用文へ変換)
  5. `brainstorm` (アイデア・企画骨子化: 散らかった思考からコアコンセプト・施策案・効果を抽出)
  - オンラインLLMプロンプトおよび完全オフラインフォールバック関数を双方実装。
  - `app/schema.py` のプリセットおよび `app/i18n.py` の多言語表示に対応。
- 全機能テストの完全網羅（無音・無キー送信の厳守）：
  - `tools/selftest.py`（78項目 PASS）
  - `tools/transform_test.py`（13項目 PASS）
  - `tools/ai_editor_test.py`（15項目 PASS）
  - `tools/dictionary_test.py`（20項目 PASS）
  - `tools/spelling_test.py`（ALL PASS）
  - `tools/jatext_test.py`（117項目 PASS）
  - `tools/pipeline_test.py`（14項目 PASS）
  - `tools/action_mode_test.py`（4項目 PASS）
  - `tools/undo_command_test.py`（ALL PASS）
  - `tools/config_features_test.py`（ALL PASS）
  - `tools/privacy_features_test.py`（ALL PASS）
  - `tools/sound_features_test.py`（6項目 PASS）
  - `tools/language_feature_test.py`（ALL PASS）
  - `tools/history_feature_test.py`（12項目 PASS）
  - `tools/senior_accessibility_test.py`（ALL PASS）
  - `tools/audio_ducking_test.py`（4項目 PASS）
  - `tools/mouse_click_test.py`（4項目 PASS）
  - `tools/cursor_overlay_test.py`（6項目 PASS）
  - `tools/tray_test.py`（21項目 PASS）
  - `tools/overlay_test.py`（31項目 PASS）
  - `tools/fresh_install_test.py`（6項目 PASS）
  - `tools/guide_test.py`（ALL PASS）
  - `tools/onboarding_test.py`（37項目 PASS）
  - `tools/clip_test.py`（195項目 PASS）
  - `tools/clip_e2e.py`（8項目 PASS）
  - `tools/mock_e2e.py`（12/12 全シナリオ合格）
  - `tools/state_test.py`（15/15 全シナリオ合格）
  - `tools/rules_check.py`（PASS）
  - `tools/privacy_check.py`（PASS）

## 全ファイル点検・バグ修正・処理軽量化・同音・同訓異義語の文脈自動補正機能の追加（2026-10-20 夕方）
- ユーザー要望：
  - 全ファイルを一度確認し、バグの発生防止、無駄なファイルや重くなっている原因を精査して軽量化・改良する。
  - 前後の文脈から同訓異義語や同音異義語の誤変換が起きないようにする機能を追加する。
- バグ修正：
  1. `app/schema.py`:
     - `action_hotkey` の既定値が `"ctrl+shift+space"`（常駐 Handy との競合禁止ルール違反）になっていたのを `""`（未設定）に修正。
  2. `tools/doctor.py` & `app/selfcheck.py`:
     - マイク名（インテル®等）に含まれる特殊商標マーク `®` が日本の Windows 標準コンソール（CP932）で `UnicodeEncodeError` クラッシュを引き起こす不具合を修正。
  3. `tools/clip_test.py`:
     - レシピ一覧テストで先頭 `normal` 追加に伴う件数期待値（`1 + len(enabled)`）および数字キー選択の不整合を修正し、195/195 全件 PASS。
  4. `app/main.py`:
     - レシピで選んだ `active_action` が入力完了後も残り続け、次回以降の通常録音が予期せず変換モードになる不具合を修正（`_handle_action` を `try ... finally` で囲み、`_cancel` でも確実にクリア）。
- 不要ファイルの削除と処理の超高速化（軽量化）：
  1. Windows 専用アプリに混入していた不要な未追跡 macOS ファイル（`app/mac_support.py`, `run.command`）を削除。
  2. `app/spelling.py`:
     - 毎回呼び出し時に 60×20=1200 回 `re.sub` を動的コンパイルしながら回していたボトルネックを、モジュールロード時の事前コンパイル結合正規表現（`_LETTER_THEN_DIGIT_RE` 等）に集約し、1200回ループから4回の事前コンパイル置換へと劇的軽量化・高速化。
- 同訓異義語・同音異義語の文脈自動補正エンジンの追加：
  1. `app/spelling.py` に `correct_homophones(text: str) -> str` および事前コンパイル済みルール群 `_HOMOPHONE_RULES` を実装。
     - 暑い/熱い/厚い、収める/納める/治める/修める、着く/就く/付く、止める/泊める/留める、測る/量る/計る/図る/謀る、写す/映す/移す、越える/超える、機械/機会、対象/対照/対称、回答/解答/解凍、意外/以外、移動/異動、制作/製作/政策、創造/想像、過程/仮定/家庭、意志/意思、確定/画定などを網羅。
     - 連体修飾・連用修飾・助詞挟み（「機械を操作する」「熱いお茶」「暑い夏」「収めるべき成果」等）に対応し、元の助詞を壊さず高精度かつ誤爆のない補正を実現。
  2. `app/jatext.py`:
     - `Options` に `fix_homophones: bool = True` を追加し、`format_text` 内で自動呼び出し。
  3. `app/schema.py`:
     - 「文字の整形」グループに `fix_homophones` 設定項目を追加（UIからオン/オフ可能）。
  4. `app/main.py`:
     - `_ja_options()` に配線。
  5. `tools/spelling_test.py`:
     - 同音異義語・同訓異義語の文脈補正テストケースを追加し、全件 PASS を確認。

## クリップボード履歴のダウンロードタブからAIチャット等へのドラッグ＆ドロップ不具合修正（2026-10-15 夕方）
- ユーザー要望：
  - クリップボードのダウンロードファイルがドラッグ＆ドロップできない。AIチャット（Claude / ChatGPT 等）に落としたいのに落とせない。
- 原因分析：
  - `app/clipwin.py` の `_drag` メソッドにおいて、ダウンロードタブの項目（DB未保存・負の仮想ID）に対して `self.store.payload(clip.id)` を呼んでいたため、DB照会が常に空行となり `payload is None` で即座にリターンされ、ドラッグ処理自体が開始されていなかった。
  - `app/clipdrag.py` の `SHDoDragDrop` において、`dwOKEffects` に `DROPEFFECT_COPY` のみを許可していたため、ターゲット側が複数のドロップ効果（MOVE/LINK含む）の提示を期待するアプリ（ブラウザやElectron系アプリ等）でドロップが受け付けられない可能性があった。
  - クリップボード窓が最前面（`WS_EX_TOPMOST`）にある状態でドラッグ中、マウスがクリップボード窓の上にあると背後のウィンドウ（AIチャット等）へ直接ドロップできない状態だった。
- 改善内容：
  1. `app/clipwin.py`:
     - `_drag` で `self.store.payload(clip.id)` の代わりに `self._payload(clip.id)` を使用。ダウンロードファイルの仮想ID（負のID）に対しても実体ファイルパスを含む `Payload` が正しく取得され、ドラッグが開始されるように修正。
     - ドラッグ中にクリップボード窓へ `WS_EX_TRANSPARENT` 属性を一時付与。マウスが窓の四角形の上にあっても背後のブラウザやAIチャット画面が透過してドロップターゲットとなり、自然に落とせるよう改善。
     - `dryrun`（から打ちモード）での `clip_drag` 記録をサポート（自動テスト検証用）。
  2. `app/clipdrag.py`:
     - `SHDoDragDrop` の `dwOKEffects` を `DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK` に拡充し、あらゆるターゲットアプリで確実にドロップを受け入れられるように改善。
  3. テスト検証（`tools/clip_test.py`）:
     - セクション19（「ダウンロード」タブ）に、ダウンロードファイルを実際にドラッグして実体ファイルパスが正しく渡されることを検証する自動テスト項目を追加し PASS を確認。

## アルファベット頭字語・略語（USJ, HDMI, PC, FDE 等）の網羅的自動変換と混在パターンの解決（2026-10-12 深夜）
- ユーザー要望：
  - USJ や FDE、PC、HDMI など、日常やビジネス・IT で使う多種多様なアルファベットの単語・略語を発話したときに、カタカナや中途半端な混在表記にならず、確実に大文字アルファベットとして反映されるようにしてほしい。
- 改善内容：
  1. 包括的頭字語テーブルの大幅拡充（`app/spelling.py`）:
     - `_ACRONYMS` に、ユーザー指定の `USJ`, `HDMI`, `PC`, `FDE` をはじめ、`Wi-Fi`, `SaaS`, `PaaS`, `IaaS`, `ATM`, `ETC`, `GPS`, `QR`, `JR`, `NHK`, `FAQ`, `Q&A`, `KPI`, `KGI`, `BtoB`, `BtoC`, `CtoC`, `D2C`, `CSV`, `XML`, `YAML`, `OK`, `NG`, `DM`, `CM`, `VIP`, `SOS`, `UFO`, `DNA`, `GDP`, `CLI`, `GUI`, `TS`, `DP`, `DVI`, `VGA`, `LTE`, `5G`, `4G`, `OJT`, `PoC`, `MVP`, `CEO`, `CTO`, `CFO` 等、日常・IT・ビジネスの主要略語を網羅的に追加。
  2. 英字＋カタカナ読み混在パターンの自動正規化（`app/spelling.py`）:
     - 音声認識モデルが一部だけ英字で出力したパターン（例: `Hディーエムアイ` $\to$ `HDMI`、`UエスJ` $\to$ `USJ`、`Pシーで` $\to$ `PCで`、`FディーE` $\to$ `FDE`、`IディーE` $\to$ `IDE`、`SエヌS` $\to$ `SNS`）を、英字アンカーからトークンを前方消費する `_consume_forward_tokens` および先行トークン結合により、自動で完全なアルファベットに正規化。
     - 「HDMIケーブル」のように直後にカタカナが続く一般単語の途中を誤破壊しない境界チェックを実装。
     - 助詞の「に」「し」「ご」と誤爆しないよう、英字直後の数字変換辞書を `_SAFE_SUFFIX_DIGIT_READINGS` に分離（「USJに行く」が「USJ2行く」になる誤爆を防止）。
     - 中黒区切りの英字（例: `H・DMI` $\to$ `HDMI`、`U・S・J` $\to$ `USJ`）の自動結合を実装。
  3. 音声認識エンジンへのベースヒント注入（`app/main.py`）:
     - Whisper 等の `supports_hints` なモデルに対し、頻出アルファベット頭字語（USJ, HDMI, FDE, PC, IDE, Wi-Fi, API, URL, CPU, GPU, SSD, USB, AI, AWS, GCP, SNS, QR, SaaS 等）をベースプロンプトヒントとして常時渡すよう `_hints()` を強化。認識段階でのアルファベット化率を底上げ。
  4. テスト検証（`tools/spelling_test.py`）:
     - ユーザー指定の USJ, HDMI, PC, FDE, Wi-Fi, SaaS および混在パターン（Hディーエムアイ, UエスJ, Pシーで）を網羅したテストケースを追加し、全件 PASS を確認。


## 「IDE」「Antigravity IDE」の誤認識（FDE / USJ / アイディーいー等）救済機能の追加（2026-10-12 深夜）
- ユーザー要望：
  - 「アンチグラビティーIDE」というときの「IDE」がFDEやUSJ、そのままの「アイディーいー」になってしまって上手く入らないのを、確実に「IDE」で入るようにしてほしい。
- 原因分析：
  - `app/spelling.py` の頭字語辞書 `_ACRONYMS` に `ID` や `FDE` は存在したが `IDE` が未登録だった。
  - 音声認識モデル（SenseVoice / Whisper）が「アンチグラビティ IDE」の「ティ IDE」を音響的に「FDE」や「USJ」と誤認識しやすかった。
  - `_COMPILED_ACRONYMS` がパターン長でソートされておらず、「アイディーイー」が「ID」+「イー」等に誤分解されるリスクがあった。
- 改善内容：
  - `app/spelling.py`:
    - `_ACRONYMS` に `IDE`（「アイディーイー」「あいでぃーいー」「アイディーいー」等）を正式追加。
    - パターン長降順でソートしてコンパイルするよう修正（`IDE` が `ID` に横取りされないよう保証）。
    - 文脈救済正規表現 `_ANTIGRAVITY_IDE_RE` を導入。「アンチグラビティ」「アンチグラビティー」「Antigravity」に後続する `FDE`, `USJ`, `アイディーいー` などの誤認識パターンを自動で `IDE` に正規化。
    - 開発環境・エディタ文脈での誤認識救済 `_DEV_CONTEXT_IDE_RE` も追加。
  - `tools/spelling_test.py`:
    - 単体での「IDE」変換および「アンチグラビティFDE / USJ」等の自動補正テストケースを追加し全件 PASS。


## 自由指示文章作成（その場指示・何でも作成）アクションの追加（2026-10-11 深夜）
- ユーザー要望：
  - 既存のテンプレート（敬語、英語翻訳、要約など）で対応できないときに、起動して自分が作ってほしいような完全に自分が言った通りの文章をその場で作って入力欄に入れてくれる機能がほしい。
- 改善内容：
  - `app/schema.py`:
    - `_DEFAULT_CUSTOM_INSTRUCTIONS` の先頭に新アクション `instruct`（自由指示で文章作成）を追加（`api_required: True`）。
    - レシピ選択メニュー（`Alt+R` / `Ctrl+Shift+W`）の先頭に即座に表示され、ショートカットキー割り当ても可能。
  - `app/transform.py`:
    - `clean_action == "instruct"` 用の専用プロンプトを実装。発話内容をユーザーからの指示・要望として受容し、前置きや解説なしで完成した文章・回答そのものを直接生成して入力欄に挿入。
    - API 必須（未設定時は安全に通知して中断）。
  - `tools/transform_test.py`:
    - `instruct` の API 必須性および動作検証を追加し全件 PASS。


## 話者フォーカス（他人の声・環境雑音の遮断）機能の追加（2026-10-11 深夜）
- ユーザー要望：
  - 一人が喋る時にその人以外の声が入った時に、その声を拾わないようにしたい。
  - 最も軽量・高精度で、Mac / Windows 問わずどのパソコンでも安定して機能するものにしたい。任意に設定できるようにしたい。
- 改善内容：
  - `app/vad.py`:
    - `SegmentCutter` に `speaker_focus`（off / normal / strong）を導入。
    - 外部ライブラリを一切使わず、Python 標準のミリ秒単位 RMS とピーク相対エネルギー判定により、口元の主話者以外の遠くの話し声や相づちを CPU 負荷 0% で無音カットする仕組みを実装。
  - `app/transform.py`:
    - `speaker_focus != "off"` の際、クラウド AI（Gemini / Claude / OpenRouter）のシステムプロンプトに「話者分離と第三者発話の除去」ルールを自動付加。ローカルをすり抜けた大きな声も AI 文脈理解で完全除去。
  - `app/schema.py`:
    - 「音声」タブの「入力」グループに `speaker_focus` 項目を追加（オフ / 標準 / 強力）。設定画面 UI から即座に任意変更可能。
  - `app/main.py`:
    - `_build_cutter` および `_handle_action` で設定値を適用。
  - `tools/transform_test.py`:
    - 音響判定およびプロンプト修飾のテストを追加し全件 PASS を確認。


## 複数 API プロバイダー（Claude/OpenRouter/Gemini）対応・AIプロンプト作成・内部プロンプト品質強化（2026-10-11 夜）
- ユーザー要望：
  1. Gemini 以外に Claude や OpenRouter などの API に接続できるようにしてほしい。
  2. 話した内容から AI（ChatGPT/Claude等）への指示文（プロンプト）を作ってそのまま入力欄に入れられるようにしてほしい。
  3. 自分でカスタマイズした文章を入れる機能は、API キーがないと動かないようにしてほしい。
  4. 内部プロンプトをもっとしっかり作り込んでほしい。
- 改善内容：
  - `app/transform.py`:
    - `detect_provider(provider, api_key, model)` で Gemini / Claude / OpenRouter を判別。
    - 標準ライブラリ（`urllib.request`）のみで `call_claude`（Anthropic Messages API）および `call_openrouter`（OpenRouter Chat Completions API）を実装。
    - `ApiRequiredError` を新設。ユーザー定義カスタム指示や AI プロンプト作成等において、API キー未設定またはオフライン時はローカルフォールバックせず安全に入力を中断。
    - 翻訳（`translate_en`）、敬語（`polite`, `professional`）、要約（`summary`）、タスク整理（`task_list`）、Slack報告（`slack_report`）、ターミナル生成（`terminal_helper`）等の内部システムプロンプトをプロ仕様に全面強化。
  - `app/schema.py`:
    - `_DEFAULT_CUSTOM_INSTRUCTIONS` に新アクション `prompt_creator`（AIプロンプト作成）を追加（`api_required: True`）。
    - 既存プリセットプロンプトを高品質版に刷新。設定デフォルトに `"ai_provider": "auto"` を追加。
  - `app/main.py`:
    - `_handle_action` で `ai_provider` 設定を渡すように更新。
    - `ApiRequiredError` をキャッチし、ユーザーに分かりやすいトースト通知（「○○」には API キーの設定が必要です）を表示して安全に入力を中断。
  - `app/web/app.js`:
    - 設定画面の API キー設定モーダルを改修。Gemini / Claude / OpenRouter の選択、各サービスのキー取得リンク、プレースホルダー、主要モデルの切り替えに対応。
    - 連携状態バッジをプロバイダー別に動的表示。
  - `tools/transform_test.py`:
    - プロバイダー自動判別、モック通信、`ApiRequiredError` 発火、プロンプト作成のテストを追加し全件 PASS を確認。


## 2 回目の頼み：不具合・よそを見ているあいだ・レシピ・ダウンロード・色・軽さ（2026-10-11 未明）
- 頼み：①「＋グループを作る」で名前を入れても作られない ②最近ダウンロードしたファイル（OneDrive もローカルも）を見てドラッグで渡したい ③全体のバグを見て直す ④ほかの AI に引き継げる資料 ⑤録音中の帯の色を選びたい ⑥重いなら軽く ⑦キー 1 つで変換のレシピ一覧 → 選んで録音 → もう一度で変換 ⑧音声入力中によそをスクロール・クリックすると文字が入らない（クリックで止める設定とうまくかみ合う形で）
- ①の原因：`runAction` が `{ name, ...extra }` で、extra の `name`（グループ名）が操作名を上書き → 本体で「知らない操作」。並べ方を逆にし、欄の名前も `group_name` に
- ⑧の調べ：ログでは「録音中にクリックされたので止めます」が 10-07 だけで 28 回。止めたあとの文字はクリップボードへ逃がしていた。→ 「止めるか」は今の設定のまま、文字は元の欄の分として取っておき、戻ったら入れる。送信ボタンなど同じ窓の中のクリックは、空の欄に入る事故を防ぐため従来どおりクリップボードへ
- ⑥の計測：待機中 CPU は 1 コアの約 2%、メモリ約 1GB（ほとんどが Whisper large-v3-turbo）。帯のタイマー（常に 20 回/秒）とホットリロード（1.5 秒ごとの全ファイル走査）を直した。モデルの選び直しは利用者に任せる
- ③：別エージェントにクリップボードまわりを読んでもらい、10 件を直した（いちばん重いのは「録音中に一覧を開くと Enter で送信されてしまう」）。直したことが戻らない確かめを `clip_test.py` に足した
- 既存の試験の古い期待値：click_test（止めたときだけ知らせを打ち切る 10-08 の変更に未追従）
- 立ち会いで確かめてほしいこと：よその窓をクリック → 戻ったら入る／Alt+R → 選ぶ → 話す → 録音キーで変換／ダウンロードのドラッグ
- 常駐へ反映：03:27 に dev を `f5cf45e` へ早送り（待機中を確かめてから）。ホットリロードで起動し直し、「クリップボード履歴を用意しました（見張り中）」・警告なし・見張り役 1 つ。live_check は 24/25（落ちたのは以前からの「1 回の認識 0.4 秒以内」＝Whisper 0.95 秒）

## クリップボード履歴を足した（2026-10-11）
- 利用者の頼み：設定したショートカットで過去にコピーした文章や画像をすぐ貼れる・画像はドラッグ＆ドロップ・並び順などを細かく設定・同じキーをもう一度押すと自分で作ったグループ（パスワード・メールアドレスなど）・グループの追加や削除と中身の設定・履歴からグループへ簡単に移す・出す場所と大きさも変えられる。いまの Ditto が使いにくいので、こだわってほしい。
- 作り：`app/clipwin.py`（本体・専用スレッド）・`clipmodel.py`（操作の決まり）・`clipview.py`（見た目）・`clipgfx.py`（描く道具と画像）・`clipdata.py`（読み書き）・`clipstore.py`（保存）・`clipdrag.py`（ドラッグ）。詳しくは `docs/CLIPBOARD.md`。
- 常駐中の dev はホットリロードで再起動するため、別の worktree `koe-type-clip`（ブランチ clipboard）で作り、試験がすべて通ってから dev へ入れた。
- 試験：`tools/clip_test.py`（単体〜本体の通し、本物のクリップボードとキーは使わない）・`tools/clip_e2e.py`（アプリ本体ごと台本で）・`tools/settings_shots.py --only clipboard`。`tools/selftest.py` のカテゴリ数を 9 に。
- ついでに見つけて直したもの：
  - 見張り役（guardian）が、起動のたびに 1 つずつ増えて 46 個たまっていた → 名前つきの鍵で 1 つだけに
  - 設定のおすすめボタン「無変換」「変換」を録音キーに選んでも、winthread がキーの名前を知らず Ctrl+Space に戻っていた → `hotkeys.SPECIAL_KEYS` を読むように
- 立ち会いで確かめてほしいこと：`tools/manual_e2e.py` の 15〜22 番（ドラッグ、実際の貼り付け、IME の変換窓の位置、ふちのドラッグ）。
- 反映（2026-10-11 02:05）：dev へ早送りで取り込み、ホットリロードで常駐が再起動。起動ログで「クリップボード履歴を用意しました（見張り中）」、ショートカットの登録失敗なし。古い見張り役 46 個を止め、新しい版の 1 個だけにした。
- live_check は 24/25。落ちた 1 つは「1 回の認識が 0.4 秒以内」で、利用者が選んでいる Whisper large-v3-turbo の起動直後の 1 回目（1.1 秒）。10-10 の起動でも毎回 1.0〜1.8 秒で、今回の変更とは関係ない（基準は SenseVoice 向け）。直すなら live_check の基準をモデルごとにする。

## 新モデル対応アーキテクチャと自動アップデート機能（2026-10-08）
- ユーザー要望：「アプリとして展開していくとして新しいモデルとか出たときに対応できるようになってる？ 自動でアップデートされるようにしたいな」
- 改善内容：
  - `app/catalog.py`：
    - `scan_local_models()`：`models/` ディレクトリに置かれた未登録の GGUF ファイルを自動スキャンし、カスタムモデルとして即座にカタログ登録・使用可能に。
    - `update_remote_catalog()`：GitHub 上のモデル定義カタログ（`models.json`）を動的にフェッチ・マージする仕組みを実装。アプリ本体のバイナリ更新なしで新モデルが設定画面に自動追加される。
  - `app/autoupdate.py`：バックグラウンドで最新モデルカタログ取得と本体の新版確認（自動適用または通知）を行う見張り役 `AutoUpdater` を新設。
  - `app/updates.py` & `app/websettings.py` & `app/web/app.js`：
    - ワンクリックでの自動アップデート（ダウンロード、SHA256検証、バックアップ、入替、再起動）を実装。
  - `app/schema.py`：「新しい版とモデル」グループを整理し、`auto_update_mode`（通知 / 自動更新 / オフ）と `auto_update_catalog` を追加。
  - `tools/auto_update_feature_test.py` を作成し、ローカルモデル検出・リモートカタログマージ・バージョン判定の動作を検証。

## クリップボード保存の選択と直接入力方式の追加（2026-10-08）
- ユーザー要望：「クリップボードに保存されるのやめてほしいな（これも人によって選択できるように）」
- 原因と課題：
  - 中断時やウィンドウ移動時、貼り付け不可時に `inject.set_clipboard_text` でクリップボードに自動保存される挙動（`_spill` / `paste_text`）があった。
  - 通常入力でも Ctrl+V 貼り付け経由のため、クリップボードの内容が一瞬書き換わり、画像コピー時など復元に失敗して文字が残ることがあった。
- 改善内容：
  - `app/schema.py`：「一般」タブに「文字の入力とクリップボード」グループを追加。
    - `save_to_clipboard`（クリップボードへの保存）：「入力できなかった時だけ保存（既定）」/「一切保存しない（履歴のみに記録）」/「常に保存する」。
    - `paste_method`（文字の入力方式）：「クリップボード貼り付け（高速・既定）」/「直接キー入力（クリップボードを使わない）」。
  - `app/inject.py`：SendInput の `KEYEVENTF_UNICODE` を用いた直接文字入力 `type_text` を実装。クリップボードAPIを1度も呼ばずに文字を直接送信可能に。また `copy_on_fallback` 引数でクリップボードへの退避をスキップ可能に。
  - `app/main.py`：`_spill` や `_type` で `save_to_clipboard` 設定を参照し、"never" の場合はクリップボードを一切触らず「残りは履歴に保存しました」と通知。
  - `tools/clipboard_opt_test.py` を作成し、dryrun モードでクリップボード保存スキップ・直接入力が正しく動くことを検証。

## クリック時の動作設定とドラッグ選択上書き入力への対応（2026-10-08）
- ユーザー要望：「文字起こしして上手くいってないところをカーソルで青く選択してそのまま音声入力で上書きしたいが、クリックすると切れるため選択できるようにしたい」
- 原因：`stop_on_click` が「音声」タブの詳細設定に隠れており、既定値が `"any"`（どこを押しても停止）だった。
- 改善内容：
  - `app/schema.py`：`stop_on_click` を「一般」タブのショートカット直下に移動し、`advanced=False`（基本設定で常時表示）に変更。
    - 選択肢：「止めない（文字を選択して上書きできる）」(`"off"`)、「入力欄の外を押したら止める（選択・上書き可能）」(`"outside"`)、「どこを押しても止める」(`"any"`)。
    - 既定値を `"outside"` に変更し、入力欄内のクリックやドラッグ選択で録音が切れずにそのまま話して上書きできるようにした。
  - `app/main.py`：`_on_click` で録音継続時、直前入力との結合用スペースをリセットし、選択上書き時に先頭に余計なスペースが入らないように配慮。
  - `HotReloader` の `is_idle_fn` バグ修正およびタスクスケジューラのバッテリー駆動設定更新。

## 0.1–0.3 土台（2026-10-04）
- CLAUDE.md の先頭に「自動テストで本物のキーを送らない」を明記。
  過去3回の事故（LINE / Vivaldi へ文字が入った）を繰り返さないため。
- `v1.3-stable` タグを打ち、`../koe-type-dev`（ブランチ `dev`）で作業を開始。
  常駐中の本体フォルダは、合格基準を満たすまで触らない。
- `models` / `engines` / `bench/audio` は本体フォルダへのジャンクション
  （管理者権限が要らない）。`config.json` `dictionary.txt` `data/` は
  worktree 側で新しく作られるので、利用者のものは汚れない。

## 0.4–0.6 / 1.3–1.8 / 1.10 安全な土台と信頼性（2026-10-04）

### 自動テストから本物のキーを完全に取り除いた
- `app/dryrun.py`：`KOE_TYPE_DRY_RUN=1` で SendInput もクリップボードの
  書き換えも**1回も行わない**。代わりに「何を入れるはずだったか」を
  `logs/dryrun.jsonl` に記録する。
- `app/testdrive.py`：`KOE_TYPE_TEST_SCRIPT` の台本で、ショートカットを
  押したのと同じ操作を内側から起こす。本物のキーを送る必要がなくなった。
  から打ちモードでないと動かない安全弁つき。
- `app/util.py`：`KOE_TYPE_HOME` で設定・辞書・履歴・ログの置き場所を
  移せるようにした。テストは一時フォルダを使い、**利用者のデータに触らない**。
- から打ちモードでは**キーフックを張らない**。常駐中の本物のアプリと
  Ctrl+Space や Esc を取り合わないため。多重起動の鍵も別名にした。
- `tools/mock_e2e.py`（新）：アプリ本体をそのまま動かす通し検証 7 本。
  キーは1回も送らない。画面がロックされていても動く。
- `tools/live_test.py` → `tools/manual_e2e.py` に改名し、**本物のキーを
  送る唯一のテスト**として隔離。合言葉 `--i-am-watching` がないと動かず、
  Claude Code の中から呼ばれた場合も実行を拒む。手順 14 項目を内蔵。
- `tools/selftest.py`：クリップボードの検査を、利用者の中身を預かって
  必ず返す形に直した（終わったあと空にしていたのをやめた）。
- `tools/privacy_check.py --history`：`git rev-list --objects --all` で
  **全コミットの中身**を調べる。一度入れたものは消しても履歴から取れるため。

### 見つけて直した重大な不具合：画像をコピーしていると即死する
`snapshot_clipboard()` が、クリップボードの**すべての**形式に
`GlobalSize` / `GlobalLock` を使っていた。画像（CF_BITMAP）やメタファイルは
GDI のハンドルでメモリブロックではないため、でたらめな大きさが返り、
`string_at` がヒープを壊して**プロセスが即死**していた
（STATUS_HEAP_CORRUPTION / 0xC0000374）。

- 再現：何か画像をコピーしてから音声入力する。5 回中 3〜4 回落ちた。
- 直し方：GDI の形式を名前で除き、さらに `GlobalFlags` が
  `GMEM_INVALID_HANDLE` を返すハンドルは触らない。
  戻せない形式があったことは記録に残す。
- 直したあと、同じテストを 5 回連続で通した（5/5 合格）。

これは**常駐中の 1.3 でも起きていた**。画像をコピーしたあとで
音声入力して落ちたことがあるなら、原因はこれ。

### 信頼性
- 1.1 出だし：`mic_preroll_ms`（既定 1 秒）。マイクを開いたままにして
  直近の音を輪っかに置き、録音開始時に先に流し込む。保存も文字起こしも
  しない。待っている間は 20ms 間隔にして CPU をほぼ使わない。
- 1.2 語尾：`post_roll_ms`（既定 0.4 秒）。止めたあとも少し録り続ける。
- 1.3 入力より**先に**履歴へ保存する。貼れなくても文字は残る。
- 1.4 中止した録音も捨てずに文字起こしして、履歴に「中止」の印つきで残す
  （入力はしない）。`SegmentCutter.drain()` を追加。
- 1.5 クリップボードに置いたあと**読み返して一致を確かめてから** Ctrl+V。
  3 回まで試す。
- 1.6 ターミナル（Windows Terminal / conhost / mintty など）では
  Ctrl+Shift+V に自動で切り替える。`paste_method` で固定もできる。
- 1.7 録音を始めた窓を覚えておき、貼る時に別の窓へ移っていたら
  **貼らずにコピー**して「コピーしました（Ctrl+V で貼れます）」と出す。
  相手が管理者権限で動いていて入力できない場合も同じ。
- 1.8 トレイに「最後の結果をもう一度入れる」を追加。
- 1.10 マイクの見張り（2 秒ごと）。3 秒以上音が来ない、または
  waveInAddBuffer が失敗したら、閉じて開き直す。
  スリープ復帰・マイクの抜き差し・既定マイクの変更に備える。

### 残っている課題
- **速さが基準に届いていない。** いまのエンジンは呼ぶたびに別プロセスを
  起こしてモデルを読み直すので、3.5 秒の音に 1.1〜1.4 秒かかる
  （5 秒換算 1.5〜1.9 秒、基準は 1.5 秒以内）。
  「話しながら」で最初の文字が出るまで約 5.2 秒（基準 1.5 秒）。
  → 項目 2.5（モデルの常駐）が最優先。

## 3.1–3.5 日本語ファーストの整え方（2026-10-04）

`app/jatext.py` を新設。検査は `tools/jatext_test.py`（47 項目、全部合格）。
**やりすぎて意味を変えていないか**を重点的に確かめている。

- 3.1 句読点の量：つけない／少なめ／標準／多め。
  「少なめ」は近すぎる読点だけを落とす。「多め」は助詞のうしろで、
  前後に十分な長さがある所にだけ読点を足す（文末の直前には足さない）。
  どちらも**話した言葉そのものは変えない**（検査で確認している）。
  記号は全角にそろえるが、`1,200` `3.14` `example.com` は壊さない。
  全角の句読点にしたあとの半角空白はのみ込む（「晴れ、 明後日」を直す）。
- 3.2 英数字の半角そろえ／日本語と英単語の間の空白（既定は空けない）／
  漢数字を数字にする（既定はオフ）。
  数字の前後には空白を入れない（「午前 10 時」ではなく「午前10時」）。
  漢数字は「一つ」「一番」「十分」などの言い回しを残す。
  残す語の判定は位置の重なりで見るので、「三十二人」は 32人 になる
  （「二人」に引っぱられない）。
- 3.3 つなぎ言葉の一覧を設定で編集できる。消すのは**語の前後が句読点か
  文の端のときだけ**なので、「なんかしらの理由で」の「なんか」は残る。
- 3.4 言い直し（「AじゃなくてB」→ B）。**既定はオフ**。
  「冗談じゃなくて本当です」まで縮めてしまうため。
- 3.5 日本語の音声コマンド：改行／段落／まる／てん／かっこ／送って／取り消し。
  **その区間がコマンドそのものだった時だけ**反応する。
  「まるいテーブルを買いました」の「まる」には反応しない（検査済み）。
  話しながらモードですでに文字を入れていた区間は、コマンドにしない
  （入れた文字は書き換えない決まりなので、二重に入ってしまう）。
  「取り消し」は受け取るが、まだ実装していないので帯で知らせる（7.2）。

設定の移行：古い `punctuation`（真偽）は `punctuation_density` へ
自動で読み替える（false → "none"）。

## 2.1 評価用の音声（2026-10-04）

`tools/make_eval.py`（新）。スピーカーは使わず、ファイルだけで作る。

- 雑音を**その場で合成**して混ぜる。3 種 × SN比 3 段（20 / 10 / 5 dB）。
  ・ピンクノイズ（空調・ざわめき）
  ・カフェのような話し声（帯域を揺らして 6 人ぶん重ねる）
  ・キーボードの打鍵（短い衝撃音の連打）
  SN比は**声の大きさ（上位 3 割の平均）**を基準に合わせる。
  無音まで含めて測ると SN比がずれるため。
- IT 用語の文 16 本を Windows の読み上げ声でファイルへ書き出した
  （プルリクエスト・デプロイ・nullポインタ・UTF-8 など。
  数字・否定・時刻も混ぜてある）。
- 無音 1 本と、雑音だけ 3 本（**1文字も出さないこと**の確認用）。
  雑音だけの分は、人の声と同じくらいの大きさまで上げてある。

合計 164 本 + 正解テキスト 160 件。`bench/eval/` に置き、.gitignore 済み。

## エンジンの速さの内訳（2026-10-04 実測）

同じ無音の WAV を長さだけ変えて測った（3 回の最小値、キャッシュ温）。

| 音の長さ | vulkan 版 | cpu 版 |
|---|---|---|
| 1 秒 | 0.669s | 0.669s |
| 3 秒 | 0.616s | 0.756s |
| 5 秒 | 0.681s | 0.832s |
| 8 秒 | 0.779s | **4.614s** |
| 20 秒 | 1.228s | 5.551s |
| 30 秒 | 1.160s | 6.540s |

**分かったこと：0.6 秒ほどが丸ごう固定費**（プロセス起動とモデル読み込み）。
実際の計算は 30 秒の音でも 0.5 秒ほどしかかかっていない。
つまり**速さの壁は計算ではなく、毎回モデルを読み直していること**。
これを無くせば、3.5 秒の音の処理が 1.1 秒 → 0.1 秒ほどになる。

同時に走らせた場合（3.67 秒の音）
- 1 本だけ：0.880s
- 2 本同時：全体 1.154s（1 件あたり 0.58s）
- 3 本同時：全体 1.420s（1 件あたり 0.47s）

→ 常駐化ができない場合でも、2〜3 本を重ねれば「話しながら」の
候補が 0.5 秒ごとに出るので、最初の文字 1.5 秒以内に手が届く。

## 8.1–8.7 / 2.2–2.7 モデルを常駐させ、速さの予算を満たした（2026-10-04 深夜）

### いちばん大きな成果：速さの予算を両方とも満たした

| 測るもの | 目標 | 前（外部プロセス） | 今（常駐） |
|---|---|---|---|
| 最初の文字まで | 1.5 秒以内 | **5.2 秒**（ほぼ出ない） | **平均 1.16s / 最大 1.36s** → 4/4 合格 |
| 話し終わってから | 0.5 秒以内 | 計測不能 | **平均 0.01s / 最大 0.30s** → 4/4 合格 |
| CPU 7 本を埋めた状態 | 同じ | − | **最初 最大 1.45s / 語尾 最大 0.09s** → 4/4 合格 |
| 入った文字の誤り率 | − | − | 平均 0.033（実音声 4 本） |

`tools/latency_test.py` で測る（キーは1回も送らない）。

### transcribe.cpp を ctypes で読み、モデルを常駐させた（8.1 / 2.2 / 2.5）

**Smart App Control は transcribe.cpp の DLL 13 個すべてを通した**（実機で確認）。
`ggml-base` `ggml-cpu-icelake` `ggml` `ggml-vulkan` `transcribe` のいずれも
`ctypes.WinDLL` で読めた。Vulkan も Intel Arc 140V を見つけて動いた。

- `app/resident.py`（新）：モデルをメモリに置いたまま使う。
  読み込みは別スレッド（本体を止めない）。**既定では外さない。**
  DLL が読めない PC では、これまでの exe 方式へ自動で落ちる。
- `vendor/transcribe_cpp/`：PyPI の `transcribe-cpp` 0.3.0（**MIT の純 Python
  5 ファイル**）をそのまま同梱。pip は使わない（インストールするものが
  何もないので、ファイルを置くだけで動く）。出どころとライセンスは
  `vendor/README.md` に書いた。構造体の大きさを起動時に DLL へ問い合わせて
  照合する仕組みが入っているので、版の食い違いで黙ってメモリが壊れることがない。
- PCM をそのまま渡せるので、**一時 WAV を書く手間もなくなった。**

#### 1 回あたりの時間（この PC / Intel Arc 140V / Vulkan / 4.5 秒の音）

| モデル | 読み込み | 1 回 | 5 秒換算 | 備考 |
|---|---|---|---|---|
| SenseVoice Small（常駐） | 0.56s | **0.122s** | 0.166s | ★既定にした |
| Moonshine Base 日本語（常駐） | 0.14s | 0.224s | 0.307s | 77MB |
| Whisper large-v3-turbo（常駐） | 1.44s | 1.266s | 1.739s | 精度は上 |
| SenseVoice Small（外部プロセス） | − | 0.62s | 0.85s | 前の方式 |

**0.62 秒 → 0.122 秒（5 倍速）。** 固定費（プロセス起動とモデル読み込み）が
消えた分がそのまま効いた。

### モデルの選び直し（2.3 / 2.4）

transcribe.cpp のカタログ（`catalog.db`）から、日本語が測られている
20 モデルを比べた。FLEURS 日本語の誤り率と、Vulkan での速さの両方で見る。

**Fun-ASR-MLT-Nano-2512（CER 2.32%）は採用しない。** 理由：
- **Vulkan では結果が壊れる。** 8 本すべてで「1 トークンの繰り返し」になり
  文字が出なかった（`OutputRepetition`）。モデルも音声も正しく、
  **CPU なら完璧な結果が出る**ので、Vulkan のカーネル側の問題。
- CPU では正しいが **4.5 秒の音に 6.8 秒**かかる。速さの予算に届かない。
- 速さを精度より優先する、という方針（H 節）にあてはまらない。

**SenseVoice Small の常駐版を既定にした。** 精度は今までと同じ（変えていない）
まま、1 回が 5 倍速くなり、速さの予算を満たせるようになった。
Whisper large-v3-turbo の常駐版（CER 4.82%）は「精度優先」の選択肢として
カタログに残す。古い PC 向けに Moonshine Base 日本語（77MB）も入れた。

既存の設定は自動で移る（`sensevoice-small` → `sensevoice-resident`）。

### 「話しながら」が実際に働くようになった（2.6 / 2.7）

前は、聞き直すたびに結果が「とも？→とそれ。→トソ令母の…」と
ひらがな／カタカナ／漢字の間で揺れ、**2 回一致では 1 文字も確定できなかった**。

- **一致回数を 2 回から 3 回に増やした**（`stream_agree_rounds`、既定 3）。
  1 回が 0.1 秒なので、3 回でも 0.3 秒しか増えない。
  実測の揺れを再現したテストで、2 回だと誤って「と総令」を入れてしまい、
  3 回なら入れないことを確認した（入れた文字は直せないので、ここは慎重に）。
- 聞き直しを**何本か重ねて走らせる**ようにした（`stream_workers`、既定 2）。
  結果は頼んだ順に返らないので、**音の長さで順番を守る**
  （自分より長い音の結果が届いていたら捨てる）。
- 聞き直す間隔の既定を 600ms → **350ms** にした。実測で最初の文字が
  1.58s → 1.16s になり、誤り率は変わらなかった（0.033）。

### 間に合わない時に速いモデルへ逃げる（8.3 / 8.4 / 8.6 / 8.7）

- 処理が「音の長さ × 0.6」を超えることが 3 回続いたら、
  軽いモデルへ切り替えて帯に小さく知らせる（`auto_fast_model`、既定オン）。
  設定そのものは書き換えないので、落ち着いたら元に戻せる。
- エンジンが 3 回続けて失敗したら、外部プロセス方式へ切り替える。
- 古い聞き直しの結果は捨てる（音の長さで判定）ので、遅れが積み上がらない。
- 実機のログで、外部プロセス方式の遅さを検知して常駐版へ自動で移り、
  そのまま 0.08〜0.10 秒で回り続けることを確認した。

### 中止（Esc）の意味をはっきりさせた

話しながらモードでは、Esc を押す前に入った文字は**残る**。
入れた文字は書き換えない決まり（設計の柱 5）なので、消すことはできない。
帯の文言を「中止しました（入力済みの分は残ります）」に分けた。
テストも 2 本に分けた。
- `cancel`：区切りが来る前に中止 → **1 文字も入らない**
- `cancel_stream`：入力後に中止 → **それ以降は 1 文字も入らない**

### 保留

- Vulkan の GPU を埋めた状態での計測（H8 の残り半分）。
- `ggml` がバックエンドを読み込む時の 4 行だけ、ログ引き取りの前に
  標準出力へ出る。コンソールのない常駐アプリでは行き場がないので害はないが、
  気持ちは悪い。上流に設定の口がないので保留。

## 9.x / 10.x 壊れないことと、人に渡せる形（2026-10-04 深夜〜明け方）

### 壊れないことの確認（9.1〜9.13）

`tools/robust_test.py`（新）で 10 項目。実機で作れない状況は**差し替え**で
作り出す。どの場合も「落ちない・固まらない・文字を失わない・日本語で
状況と次にすることを知らせる」を見る。**10/10 合格。**

| 作り出した状況 | 結果 |
|---|---|
| 設定ファイルが途中で切れている | 退避して初期値で起動。帯でも知らせる |
| 設定ファイルが空 | 同上 |
| 辞書の文字コードが違う | 退避して空で起動 |
| 履歴データベースが壊れている | **文字起こしは続く**（文字を失わない） |
| モデルのファイルがない | 日本語で知らせ、受け皿のモデルへ |
| モデルのファイルが壊れている | 落ちない。切り替えの記録が残る |
| 常駐エンジンがない PC | 外部プロセス方式へ自動で落ちて、文字は入る |
| マイクがない | 落ちない。動作チェックが直し方を出す |
| 2 つ同時に起動 | 2 つ目は静かに終わる |
| 40 秒の録音 | 遅れが積み上がらない（入力の間隔は最大 1.4 秒） |

差し替えのための環境変数（**から打ちモードと同じく、検証専用**）
`KOE_TYPE_NO_RESIDENT` / `KOE_TYPE_NO_MIC` / `KOE_TYPE_MODEL_DIR` /
`KOE_TYPE_ENGINE_DIR`。最後の 2 つは、持ち運び版の置き場所にも使える。

結果は `docs/COMPATIBILITY.md` に表でまとめた。
**未確認のまま残っているもの**：高 DPI・4K・複数モニター、
リモートデスクトップ、全画面のゲーム、省電力モードでの速さ。
実機がないと確かめられないので、正直に「未確認」と書いてある。

### 別エージェントによる UI レビュー（10.2 / E2）

「初めて使う人」の目線で設定画面 28 枚を見てもらった。
**まず指摘されたのが、スクリーンショットがページの上半分しか
写っていなかったこと**（窓の高さ 760px で撮っていた）。
つまり E1「全画面を画像化」が実は満たせていなかった。紙の高さを
2400px にして撮り直した。

主な指摘と、直したもの

| 指摘 | 直し方 |
|---|---|
| 「アプリ」が技術的な一覧 12 行で始まる | 1 行にたたんだ。問題のある行だけ出し、「くわしく見る」で全部 |
| 「Python の版」「窓の出ない起動」「貼り付けの準備（6 種類）」 | 受け取った人に意味がないので出さない |
| 「精度 ●●●●○ 2.0%」が「精度 2%」と読める | 「文字誤り率 2.0%」とラベルを付けた |
| マイク名が途中で切れている | 31 文字で切れるので末尾に … を付ける |
| 「だめ 0」が子供っぽい | 「エラー 0」に |
| 初回から「もう一度調べる」 | 初回は「調べる」 |
| 情報行が「注意」に数えられている | 参考は件数に入れない |
| 「起動の固定費」「一致回数」「同時に聞き直す本数」「1区間」 | ふつうの日本語に置き換え |
| 単語ヒントが既定オンなのに既定モデルでは効かない | 灰色にして、その場に理由を出す仕組みを作った |
| モデル名の「（常駐）」が意味不明 | 外した |
| 英語側に「every 0.6 s」が残っていた | 直した |

レビューで**褒められた点**（変えないこと）：生のミリ秒が 1 つもない、
マイクの感度が数字ではなく言葉、Windows 11 ネイティブの見た目、
アイコンが 1 ファミリー、ダークモードが本物、狭い窓でも崩れない、
「変更は自動で保存されます」の常設フッタ、プライバシーの説明を
該当項目の真下に置いていること。

### 長い音で文字を失う問題（9.2 の副産物）

FLEURS 日本語 200 本で測ったところ、**SenseVoice が 22 本（11%）で
記号しか返していなかった**。どれも 11 秒を超える音。
そのまま捨てると話した内容がまるごと消えるので、
**空だったら半分に割って聞き直し、重なりを除いてつなぐ**ようにした。

- 文字誤り率 17.96% → **12.28%**
- 空になった 22 本のうち、ほとんどを取り戻した
- あわせて「ひと区切りの最長」の既定を 15 秒 → 10 秒に
  （モデルの得意な長さに合わせる）

空を除いた 178 本での誤り率は **7.82%** で、公開値の 7.63% とほぼ一致。
つまりモデルの実力はそのままで、**長い音の扱いだけが弱点**だった。

### 文書（10.1 / 10.4）

- `docs/GLOSSARY.md`：言葉づかいの決まり。同じものを 2 通りで呼ばない。
  使う言葉／使わない言葉の対応表、書き方の決まり、
  画面に出してはいけないもの。
- `docs/COMPATIBILITY.md`：環境 19 種・状況 17 種の表。
  「実機／テスト／設計／未確認」の 4 段階で正直に書く。
- `docs/RELEASE_CHECKLIST.md`：公開前の 6 分野。
  コード署名は有料なので見送り（理由つきで記録）。

### 自分の失敗 2 件

1. **`tools/resident_bench.py` に利用者の固有名詞を直接書いてしまった。**
   `privacy_check --history` が見つけてくれた。辞書から読むように直し、
   3 つのコミットを 1 つにまとめ直して履歴からも消した。
   （`dev` は手元だけのブランチで、公開していないのでやり直せた）
2. **テストが設定キーを間違えていた。** `input_timing` と書いていたが
   正しくは `input_mode`。そのため「文ごと」モードのテストが、
   ずっと「話しながら」モードを動かしていた。直したところ、
   文ごとモードの実力が分かった（最初の文字 4.35 秒・語尾 0.23 秒）。
   **「話しながら」が既定なのは正しい**と、数字で確かめられた。

## 仕上げ（2026-10-04 明け方）

- `tools/endurance_test.py`：待機中の CPU **0.76%**、100 回くり返して
  メモリの増加 **0.0 KB/回**（1 回 0.115 秒）。基準 C5 / C6 / 8.10 を満たした。
  はじめ ctypes の宣言が足りず「0.00% / 0.0MB」という嘘の値が出ていた。
  argtypes / restype を書いていないと 64bit のハンドルが切り詰められて
  呼び出しが黙って失敗する、というこのプロジェクトで何度も踏んだ罠。
- 利用者向けの文書：`CHANGELOG.md` `docs/FAQ.md`
  `docs/TROUBLESHOOTING.md` `docs/PRIVACY.md`、そして `docs/REPORT.md`。
- README を実測値に合わせて更新し、テストの節を書き直した。
- 常駐しているアプリの利用ログから、物音に中国語を返して入力していた実例が
  見つかったので、幻覚の除外を 2 つ足した（`docs/DECISIONS.md` に詳細）。

### 最後に通したテスト

| | 結果 |
|---|---|
| `tools/selftest.py` | 50/50 |
| `tools/mock_e2e.py` | 8/8 |
| `tools/robust_test.py` | 10/10 |
| `tools/jatext_test.py` | 47/47 |
| `tools/latency_test.py` | 4/4（通常）/ 4/4（CPU 混雑） |
| `tools/endurance_test.py` | 2/2 |
| `tools/doctor.py` | 問題なし 12 / 注意 0 / エラー 0 |
| `tools/privacy_check.py --history` | 通過 |

**常駐しているアプリは触っていない。** `master` は `d66157b`（v1.3-stable）の
まま、作業ツリーもきれい。切り替え方は `docs/REPORT.md` の ⑤ に書いた。

## 6.5 / 10.3 配布のしかた（2026-10-04 明け方）

`tools/make_dist.py`（新）。**0.39MB / 114 ファイル**の zip ができる。

- 入れるもの：コード、設定画面、見本の辞書、アイコン、文書、検証用の道具
- **入れないもの**：モデル、エンジン、利用者の設定・辞書・履歴・ログ、
  評価用の音声、個人の固有名詞の一覧、**本物のキーを送るテスト**
- 作る前に「入ってはいけないもの」を調べ、見つかったら zip を作らない
  （拡張子・ファイル名・8MB 超えの 3 つで判定）
- `START-HERE.txt` を同梱。ファイル名は ASCII にした
  （日本語の名前は、展開に使う道具によって文字化けする。実際に Git Bash の
  unzip で確認した）

**空のフォルダに展開して、新しい PC のふりをして起動した。**
モデルもエンジンもない状態で、

- 落ちずに起動する
- モデルがないので、設定画面が自動で開いて案内する
- ログに例外が 1 件もない

ことを確認した。この確認で不具合が 1 つ見つかった。
エンジンの置き場所が本体フォルダの外にあると、
案内の文言を組み立てる `relative_to` が例外を投げていた（捕まえてはいた）。
直した。

版を **1.2.0** に上げた。

## アンインストールと、ライセンス表記（2026-10-04 明け方）

- `tools/uninstall.py`（新）。消すもの・残すものを勝手に決めず、必ず聞く。
  自動起動の登録だけを外し、**Windows のほかの設定には触らない**。
  管理者権限は要らない。
  **ジャンクション（別の場所への入口）を見分ける。**
  この作業用フォルダでは `models` と `engines` が常駐アプリへの
  ジャンクションなので、見分けずに `rmtree` すると
  **動いているアプリのモデル 4GB を消してしまう**ところだった。
  入口だけを外し、先にある本物のファイルには触らないようにした。
- `app/autostart.is_enabled()` を足した（登録されているか調べるだけ）。
- `THIRD_PARTY_NOTICES.md` に、同梱した `vendor/transcribe_cpp`（MIT）、
  transcribe.cpp のランタイム（MIT）、評価に使った FLEURS（CC-BY-4.0、
  リポジトリにも配布物にも入れていない）を足した。

## 2 回目の UI レビューを反映（2026-10-04 朝）

別のエージェントに、直したあとの画面をもう一度見てもらった。
**8 項目の修正はすべて反映されていた**が、そのうち 1 つが新しい問題を
生んでいた。

### 自分が作ってしまった問題

1. **モデル名から「（常駐）」を外したら、同じ名前が 2 つずつ並んだ。**
   「SenseVoice Small 文字誤り率 12.3%」の下に
   「SenseVoice Small 文字誤り率 2.0%」。同じ名前・違う数字・違うライセンス。
   → 古いほうを「（旧方式）」にして、説明も
   「上と同じモデルですが、使うたびに読み込むので 5 倍遅くなります」に。
2. **「精度 ●●●●●」の点と「文字誤り率 4.8%」が矛盾していた。**
   点は手で決めた値で、誤り率と連動していなかった
   （点が多いほうが誤り率も高い、という並びができていた）。
   → **点をやめて、数字だけにした。**
3. **つなぎ言葉の入力欄が、明るい画面で黒く、暗い画面で白く出ていた。**
   class を付けずに `<input>` を置いたので、ページの配色ではなく
   OS の配色で描かれていた。
4. **「消すつなぎ言葉」「使えるコマンド」の見出しが消えていた。**
   `kind == "custom"` の項目は、見出しを出す前に return していた。
5. **音声コマンドのスイッチに「HTMLSp」という文字が出ていた。**
   `el()` の第 3 引数は HTML の文字列なのに、DOM を渡していたので
   `[object HTMLSpanElement]` が描かれていた。

### そのほか直したもの

- 履歴が 0 件でも「すべて削除」が押せた → 押せなくした。
  「コピー」の強調色をやめ、「すべて削除」を危険色にした
  （いちばん危ない操作が、いちばん安全に見えていた）。
- 辞書が空のとき、列の見出し（誤認識／正しい表記）が出ていなかった。
  「左に」「右に」と書いてあるのに、左右が画面に存在しなかった。
- 効かない設定を薄くしていただけだったので、**Tab + Space で触れた**。
  本当に `disabled` にした。
- 補助の文字が薄すぎた（明るい画面で 3.45:1）。`--text-3` を濃くした。
- 行の縦そろえを上にした（説明が長い行だけコントロールが浮いていた）。
- アプリ画面のフッタに絶対パス（利用者名入り）が出ていた → 消した。
- 用語集（`docs/GLOSSARY.md`）に沿って **25 か所**言い換えた。
  常駐 / 帯 / フォーカス / 除外アプリ / このツール / 区間 / 文ごと /
  容量 / 既定のマイク。**画面に残っている禁止語は 0 件**
  （設定項目と表示文字列を機械的に調べて確認）。
- スクリーンショットの紙の高さが足りず、文字起こしのページの下 3 分の 1
  （音声コマンドの表など）が写っていなかった → 3600px にした。

### 速さの測り直し

既定のモデルが**常駐版になっていなかった**ことが分かった。
`schema.py` の隠し既定値に `"model": "sensevoice-small"` と直接書いてあり、
`catalog.DEFAULT_MODEL` を常駐版に変えても、新しい利用者には
古いほうが選ばれていた。これまでの速さは「遅いと判定されて自動で
切り替わった結果」だった。直して測り直した。

| 条件 | 最初の文字 | 語尾まで | 判定 |
|---|---|---|---|
| ふつう（8 本） | 平均 1.22s / 最大 1.49s | 平均 -0.07s / 最大 0.37s | **8/8 合格** |
| CPU 2 本を使用中 | 平均 1.25s / 最大 1.50s | 最大 0.21s | **4/4 合格** |
| CPU 4 本を使用中（半分） | 平均 1.28s / 最大 1.47s | 最大 0.14s | **4/4 合格** |
| CPU 7 本を使用中（8 本中） | 平均 3.94s | 平均 0.83s | **0/6 不合格** |

**CPU 7 本の結果は、検証のしかたの限界**でもある。この検証は WAV を
Python のスレッドで流し込むので、CPU が埋まるとその流し込み自体が
止まる。本物のマイクは OS が音を溜めてくれるので、ここまで悪くはならない
（文字起こし 1 回の時間は、負荷の有無にかかわらず 0.10 秒で変わらなかった）。
正直に「8 分の 7 を埋めた状態では測れていない」と書く。

### 終了時に文字を失わないようにした

負荷をかけた検証で、**終わる時に残りの文字起こしが捨てられている**ことに
気づいた。履歴への保存は文字起こしのあとなので、処理前に終わると
音も文字も残らない。終了前に最大 6 秒だけ待って片づけるようにした。

## 細かい手直し（2026-10-04 朝）

- プリセットのボタンが「ちょうど一致」でしか光らず、途中の数にすると
  **どれも選ばれていない＝壊れて見えて**いた。いちばん近いものを光らせる
  （離れすぎているときは、どれも光らせない＝自分で決めた値）。
- モデルの「配布元」が、ライセンスの文書へ飛んでいた（ライセンスは
  すぐ上に別の欄がある）。配布元そのものへ飛ぶようにした。
- ショートカットの説明に「右のボタンを押してから使いたいキーを押すと、
  変えられます」を足した（押せると分からなかった）。
- 既存のテストを通し直した。
  `tools/pipeline_test.py` が **11/14 → 14/14**。
  落ちていた 3 つは速さの判定で、5 秒換算 1.51〜1.94 秒だったものが
  **0.14〜0.17 秒**になった。
  `tools/tray_test.py` 9/9。

## 立ち会いテストの NG を直す（2026-10-04 昼）

### NG1 聞こえていたのに文字が入らない（Gemini で発覚）

ログを調べたところ、**Gemini 固有ではなかった**。
エンジンが**空文字を返す**ことがあり、今日の利用中に **47 回**起きていた。
Gemini のときは、確定した区間すべてが空だった。

いちばん困るのは、**話しながらの途中では正しく聞き取れていた**こと。

```
12:24:07,921 認識 0.080s: 今日の大阪の天気を教えてくれない。   ← 聞こえている
12:24:08,002 認識 0.072s:                                  ← 確定は空
12:24:08,002 入力する文字がありません: ''                     ← 捨てた
```

手当て 2 つ。

1. 空が返ってきたら、**長さをほんの少し変えてもう一度聞く**
   （0.2 秒・0.4 秒の無音を足して試す。1 回 0.07 秒なので安い）
2. それでも空なら、**その発話でいちばんよく聞こえた結果**を使う

きれいな検証用の音声では再現しなかった（43 通りの長さで 0 件）。
利用者の実際の声・部屋の音に依存する。だから**録音の保存を有効にした**。

### NG2 録音が止まらない

送信ボタンをマウスで押しても録音が続き、21 秒・34 秒と回っていた。
そのあいだに話した内容が、思わぬ場所に入るおそれがある。

- **マウスでクリックしたら止める**（Windows 標準の Win+H と同じ動き）。
  `app/mousewatch.py` を新設。
- **入力先のウィンドウが変わったら止める**。
- **10 秒静かだったら止める**（設定で変更・オフ可）。
- **録音中は枠を赤く太く描く**（止まっていないことに気づけるように）。

#### クリックを受け止めて、あとで通す

送信ボタンをそのまま通すと、**最後のひと言が抜けたまま送信**されてしまう。
そこで、クリックを**いったん受け止め**、残りの文字を入れ終わってから
**改めて送る**。

**ここは失敗するとクリックが消えて操作できなくなる**ので、安全弁を厚くした。

| 守ること | どうやって |
|---|---|
| 録音中しか受け止めない | それ以外は素通し |
| 1 回の録音につき 1 クリック | 受け止めたら見張りを解く |
| **必ず通す** | 見張り役が締め切り（0.6 秒）で強制的に送る |
| 管理者のアプリでは受け止めない | 送り直せないので、受け止めると消える |
| 自分の窓は対象外 | 録音中の表示・設定画面 |
| 自分が送ったクリックを拾い直さない | 目印（dwExtraInfo）で見分ける |

`tools/click_test.py`（新）で **19 項目**。本物のクリックは 1 回も送らない。
**「本体が固まっても締め切りで通る」**ことも確かめた（0.31 秒で通った）。

間に合わなかった分は、入力せずに**クリップボードへ逃がし**、
帯で「残りはクリップボードに入れました」と知らせる。

### 枠線を描く処理の間違い

`_rounded_outline` は、外側と内側の角丸の差を塗るつもりで書かれていたが、
**実際には外側を塗りつぶしているだけ**だった（内側のパスは作って捨てていた）。
淡い色だったので今まで気づかなかった。ペンで線を引く形に直した。

### 録音の保存

利用者の求めにより、**既定でオンにした**。
`history_audio_days`（既定 14 日）を過ぎた録音は自動で消す。
起動時と 1 時間ごとに掃除する。文字の記録は残る。

### 自動起動の登録を書き換えてしまった件

`tools/tray_test.py` が**本物のアプリを起動する**作りで、起動時に
自動起動の登録を書き換えていた。そのため、朝 PC を使い始めたときに
**検証用のフォルダのほうが常駐アプリとして起動**してしまった。

`KOE_TYPE_NO_AUTOSTART=1` の安全弁を入れ、tray_test から渡すようにした。

## 緊急対応：PC 全体が重くなった件（2026-10-04 夜）

### 何が起きたか

録音中にクリックを受け止める機能を入れた直後、**利用者の PC 全体が重くなり、
マウスのカーソルまでカクついた**。そのあと Ctrl+Space が効かなくなり、
タスクトレイのアイコンも消え、利用者は PC の再起動を余儀なくされた。

ログは、クリックを受け止めた行で**ぴたりと止まっていた**。

```
18:43:22,645 [win] クリックを受け止めました（1336, -125）。残りの文字を入れてから通します
          ← ここで記録が完全に止まる（次の行は再起動後）
```

「通しました」も、締め切りの警告も出ていない。**プロセス全体が固まった。**

### 原因

**低レベルのフックを Python のプロセスで持ったこと。**

`WH_MOUSE_LL` / `WH_KEYBOARD_LL` のコールバックは、動く前に
**GIL（Python の実行権）を取る**必要がある。文字起こしのスレッドが
GIL を持っているあいだ、コールバックは待たされる。
そのあいだ **Windows は PC 全体のキー・マウス入力を止めて待つ**。
待ちすぎると Windows がフックを黙って外す。

さらに、そのコールバックの中で**やってはいけないこと**を重ねていた。

| やっていたこと | なぜ悪いか |
|---|---|
| `OpenProcess` / `OpenProcessToken` | 数ミリ秒〜数十ミリ秒かかる OS 呼び出し |
| `WindowFromPoint` | 同じく OS 呼び出し |
| **スレッドを新しく作る** | いちばん重い。フックの中ですることではない |
| 設定を読む・キューに積む | Python のロックを取る |

### 直したこと：入力の流れに割り込まない方法だけを使う

`app/inputwatch.py` を新設し、**低レベルのフックを全部やめた**。

| 見たいもの | 前 | 後 | なぜ安全か |
|---|---|---|---|
| Ctrl+Space | `WH_KEYBOARD_LL` | **`RegisterHotKey`** | OS が押された時だけ `WM_HOTKEY` を投げる。こちらが遅くても他のアプリは止まらない |
| 録音中の Enter / Esc | 同上 | **`RegisterHotKey`（録音中だけ登録）** | 録音していない間は登録しないので、ふだんの Enter / Esc に一切触れない |
| 入力先の変化 | `WH_MOUSE_LL` | **`SetWinEventHook`（`WINEVENT_OUTOFCONTEXT`）** | 出来事をメッセージで受け取るだけ。送り手は待たない |

**クリックを受け止めて待つ仕組みは、二度と使わない。**
送信ボタンで言葉の最後が欠ける問題は、文字を入れるのを速くすることで防ぐ。

長押しモード（押しているあいだだけ録音）はフックが要るため、
いまは押すたびの切り替えとして扱う（作り直すまで使えない）。

### 軽さの見張りと、止まらない仕組み

- `app/health.py`：1 秒に 1 回だけ、OS に数字を聞く。
  **書き出すのは印をつけた時だけ**（記録のせいで重くならないように）。
  このアプリの CPU・メモリ、PC 全体の CPU、文字起こし 1 回の時間、
  処理待ちの件数、ショートカットが生きているか、心拍。
- 重いと判断したら記録に印をつけ、ログに残す。
- **ショートカットの登録が外れていないか 30 秒ごとに確かめ**、
  外れていたら付け直して帯で知らせる。
- トレイに「**いま重かった（記録を残す）**」を追加。
- `app/guardian.py`：**別のプロセス**で心拍を見張り、
  止まっていたら起動し直す。暴走よけ（最短 60 秒おき・最大 5 回）つき。
  心拍を書かない古い版が動いているときは、何もしない。

### 負荷試験

`tools/stress_test.py`（新）。**本物のキーもクリックも 1 回も送らない。**

いちばん見たいのは「**ほかのアプリの邪魔をしていないか**」。
`GetLastInputInfo` / `GetCursorPos` は入力まわりのロックを通るので、
**入力の流れが詰まっていると返りが遅くなる**。これを物差しにした。

3 分 / 30 回の結果

| | 待機中 | 録音をくり返す間 |
|---|---|---|
| 入力の遅れ（中央値） | 0.026 ms | **0.025 ms** |
| 入力の遅れ（最大） | 0.136 ms | 0.413 ms |
| 20 ms を超えた回数 | − | **0 / 9060** |

落ちた 0 回、ショートカットが外れた 0 回、録音 30/30 回。
**待機中と区別がつかない。**

### NG3（聞き間違い）の原因と手当て

実際のログで、聞き直しが **180ms おき**だったことが分かった。
「3 回続けて一致」しても、音は **0.36 秒**しか増えていない。
モデルが迷っている最中に確定していた。

```
12:26:37.397  台湾エージント。
12:26:37.579  台湾 エージ に とってる。
12:26:37.758  （空）
12:26:37.939  （空）
12:26:38.105  台湾 エージン とって どういう 会社？
12:26:38.284  台湾 エージンに とって どういう 解釈？
12:26:38.467  台湾 エージンに とってどういう 会社かを。 → 確定「台湾エー」
```

**「回数」ではなく「音がどれだけ増えたか」で判断する**ようにした
（`stream_agree_span_ms`）。実際のログの並びで確かめた結果。

| 必要な音の増え方 | 誤って入った文字 |
|---|---|
| 0ms（前） | 「台湾 エー」 |
| 300ms | 「台湾 エー」 |
| **400ms** | **なし** |
| 800ms | なし |

速さとの釣り合いを測り直し、**同時 2 本 / 間隔 450ms / 音の増え方 400ms**
に決めた。

| 設定 | 最初の文字 | 予算内 |
|---|---|---|
| 間隔 350ms / 増え方 0ms（前） | 平均 1.19s | 4/4（誤りが入る） |
| 間隔 350ms / 増え方 800ms | 平均 3.74s | 0/4 |
| 間隔 450ms / 増え方 400ms（**採用**） | **平均 1.38s / 最大 1.65s** | **7/8** |

誤り率は 2.05% のまま変わらなかった。

### 作り直したあとに見つけた不具合（実際に動かして発覚）

自動テストは通ったが、**本物として起動したら 2 つ壊れていた**。
から打ちモードではショートカットを登録しないので、テストでは出なかった。

1. `_start_guardian` で `Path` を import し忘れていた。
2. **ショートカットの確認を別のスレッドからやっていた。**
   `RegisterHotKey` は登録したスレッドのものなので、別のスレッドから
   付け外しすると失敗する。30 秒ごとの見張りが、**自分で登録を壊していた**
   （「ショートカットの登録が外れました」が出て、Ctrl+Space が効かなくなった）。
   → 確認そのものを win スレッドへ頼む形に直した。

**教訓**：ショートカットの登録は、から打ちモードでは動かないので
自動テストで守れない。本物として起動して確かめる手順が要る。

### 負荷試験の結果

ログが 1MB で回るので、回った分も数えるように直した
（数え落として「半分しか動いていない」と誤解した）。

| | 25 分（CPU 半分を使用中） | 4 分（同上） |
|---|---|---|
| 録音の開始／停止 | 290 回 | 330 回 |
| 落ちた・固まった | **0** | **0** |
| ショートカットが外れた | **0** | **0** |
| 入力の遅れ（待機中・中央値） | 0.026 ms | 0.022 ms |
| 入力の遅れ（録音中・中央値） | **0.029 ms** | **0.028 ms** |
| 入力の遅れ（録音中・最大） | 13.4 ms | 27.5 ms |
| 20 ms を超えた回数 | **0 / 73,640** | 1 / 12,000 |
| このアプリの CPU（最大） | 40 % | 40 % |
| メモリ（最大） | 402 MB | 402 MB |
| 処理待ち（最大） | 1 件 | 2 件 |

**入力の遅れは、待機中と区別がつかない。** 以前はここが詰まって
カーソルがカクついていた。

### NG3（聞き間違い）の比較

読み上げ声で作った、実際に間違えた 5 文で比べた。

| モデル | CER | 1 件 |
|---|---|---|
| **SenseVoice Small（いま使っている）** | **0.0235** | **0.10s** |
| Whisper large-v3-turbo | 0.0235 | 1.24s |
| Moonshine Base 日本語 | 0.1088 | 0.11s |

**きれいな音声なら、いまのモデルが 5 文とも正しく聞き取れた**
（「サイバーエージェント」も「天気」も）。Whisper に替えても結果は同じで、
12 倍遅くなるだけだった。

つまり**モデルを替えても直らない**。原因は、話している最中に
**早すぎる確定をしていた**こと（上記）。
「話しながら」で通して確かめたところ、両方とも正しく入った。

残る「午前十時」→「午前10時」は、聞き間違いではなく数字の書き方。
設定の「漢数字を数字にする」と逆向きの整形なので、
必要なら設定で変えられる。

## 2026-10-05（続き）立ち会いテスト 項目4 の NG を直す

直したもの

| NG | 原因 | 直し方 |
|---|---|---|
| 自動停止のあと帯が消えず Ctrl+Space も効かない | `_tick` が `try` の中で `return` し、画面の繰り返しが終わっていた | `finally` で必ず次の回を予約。停止は control スレッドへ渡す。「止める途中」を 3 秒で強制復帰 |
| 同上（ショートカット） | 確認が「持っている分の付け直し」だけで、外れたまま戻らない経路があった | 毎回あるべき姿から組み立て直す。確認を 2 秒ごとに |
| Claude の送信ボタンで止まらない | 同じ窓の中のクリックは画面の見張りでは分からない | 録音中だけ `GetAsyncKeyState` を読む見張りを追加（受け止めない） |
| 「。」が文の途中に入る | モデルが区切りごとに付ける | `full_stops`（既定は付けない／最後だけ／モデルのまま） |
| 「改行」コマンド | — | Enter は送らず貼り付け。既定オフ |

自動テスト（すべて合格）

- `tools/state_test.py` **新規** 10/10（状態の移り方）
- `tools/click_test.py` 書き直し 23/23（入力の遅れの実測つき）
- `tools/jatext_test.py` 66/66
- `tools/mock_e2e.py` 8/8 ／ `tools/robust_test.py` 10/10
- `tools/selftest.py` 50/50 ／ `privacy_check` 問題なし

## 2026-10-05（続き2）項目4 の 4 つの指摘を直す

| 指摘 | 原因 | 直し方 |
|---|---|---|
| 「テスト？」「隣りの？」 | 疑問の語尾に「の」を入れていた | 既定を「付けない」に。語尾の「の」も外した |
| 「隣りの？隣の客は…」 | 言いよどみで 0.96 秒の区切りができ、断片が先に入った | 短い区切りは次につなげる（`merge_short_ms`）。`resume_at` を表記の揺れに強くし、最後に重なりを必ず落とす |
| 「柿食う客 → かき食う曲」 | 区切り全体を聞いても同じ間違い（モデルの聞き取り） | 確定のしかたを 3 通り実測して比べ、`stream` のままが最良と確認。`preview` も選べるように実装 |
| 「ベストテスト今日の天気は」 | 「。」を付けないため | `join_separator`（既定は空白） |

### 実測（利用者の録音 125 秒 / 区切り 35 個を 7 本につなぎ直し）

| やり方 | 誤り率 | 二重入力 | 1文字目 |
|---|---|---|---|
| stream（既定） | 3.6% | 0 | 2.10s |
| preview / phrase | 4.1% | 0 | 2.08s |
| stream（昔） | 6.0% | 0 | 2.06s |
| preview（昔） | 6.4% | 0 | 1.88s |

自動テスト（すべて合格）

- `tools/overlap_test.py` **新規** 24/24（重なりの判定）
- `tools/commit_bench.py` **新規**（確定のしかたの比較）
- `tools/mock_e2e.py` 10/10（`preview`・`join` を追加）
- `tools/jatext_test.py` 69/69 ／ `tools/state_test.py` 10/10
- `tools/click_test.py` 23/23 ／ `tools/robust_test.py` 10/10
- `tools/selftest.py` 50/50 ／ `privacy_check` 問題なし

### 立ち会いテストの確認（ログ）

- 03:17:12.709 録音開始 → 03:17:23.914「10 秒静かだったので録音を止めます」
  → 03:17:24.315 録音停止。**自動停止は働いた（11.2 秒）**
- 03:17:30.519 録音開始（停止から 6.2 秒後）。**押してすぐ始まった**
- 「待機の状態へ戻します」「停止が…終わらない」は 0 回（強制復帰なし）

## 2026-10-05（続き3）録音中の帯を作り直す

- お知らせの長さを 1.0 / 2.2 / 3.5 秒の 3 段階に。終わったら帯ごと消す
- 帯を 3 案（カード・波のバー・ピル）にし、設定の「表示」で選べるように
- 既定は **カード**。中くらいでも高さ 56px（以前は 36px）
- 状態は色と形の両方（丸・四角・チェック）
- 声に合わせた波、未確定の文字（17px・2 行）、操作のヒント、経過時間
- 出入りに短い動き。「アニメーションを減らす」設定なら動かさない
- 複数モニターでは、入力しているウィンドウと同じ画面に出す
- つなぎ目を「区切りごと」に入れるよう直した（同じ録音の中でも入る）

自動テスト（すべて合格）

- `tools/overlay_test.py` **新規** 29/29（画面を撮らないのでロック中でも通る）
- `tools/overlay_options.py` **新規**（3 案 × 4 状態 × ライト／ダークの画像）
- `tools/mock_e2e.py` 10/10 ／ `tools/state_test.py` 10/10
- `tools/overlap_test.py` 24/24 ／ `tools/jatext_test.py` 69/69
- `tools/click_test.py` 23/23 ／ `tools/robust_test.py` 10/10
- `tools/selftest.py` 50/50 ／ `privacy_check` 問題なし

## 2026-10-05（夜）完成形へ：長時間テスト・本物の確認・公開の準備

### 作った道具

| 道具 | 何をするか |
|---|---|
| `tools/soak_test.py` | 何千回もランダムにくり返す。落ちる・固まる・帯が残る・キーが効かない・メモリが増える・ほかのアプリが遅くなる、を数字で見る |
| `tools/live_check.py` | **本物として動いている**アプリを外から確かめる（キーは送らない） |
| `tools/make_portable.py` | 署名済み Python を同梱した版を組み立て、起動まで確かめる |
| `tools/install.py` | 管理者権限なしで、スタートメニューと自動起動に登録 |
| `tools/onboarding_test.py` | 初回の案内を HTTP 越しに確かめ、画像も撮る |
| `tools/make_gif.py` | 使っている様子の GIF（画面を撮らない。LZW も自前） |

### 長時間テストの結果（直したあと・ほかに何も動かさず）

- 1.25 時間 / **956 回の録音** / 3 回起動
- 落ちた 0・終了コード異常 0・**キーが外れた 0**・停止が終わらない 0・
  帯の例外 0
- 画面の繰り返し 1 秒あたり **10.8 回**（最低 10.8）
- 入力の遅れ **0.0408 → 0.0409 ms**（最大 1.29 ms）
- メモリ 392〜409 MB のあいだで上下（増え続けない）

### 直した不具合

1. 停止の内訳が見張りの締め切りを超えていた（長時間テストで発見）
2. 初回の案内のマイク確認が、録音前は動かなかった
3. 設定画面を閉じると長い例外が出ていた
4. 設定画面に `**` がそのまま出ていた
5. メモリの増え方の測り方（物差しのほうが間違っていた）

### 公開の準備

- 持ち運べる版 31.2MB（バイナリ 38 個すべて署名つき）
- 初回の案内 6 画面 ＋ `app/hardware.py`（PC を調べておすすめを決める）
- 診断情報のコピー（個人情報を外し、残っていたらコピーしない）
- 新しい版の確認と入れ替え（既定はオフ）
- `CONTRIBUTING.md` / `SECURITY.md` / Issue・PR のひな形 /
  GitHub Actions（ci・release）
- `docs/DISTRIBUTION.md`（SignPath・Store・winget の費用と手順）
- README（日英）に GIF と、持ち運べる版の入れ方

### 自動テスト（すべて合格）

selftest 50 / jatext 69 / overlap 24 / click 23 / overlay 29 /
state 10 / mock_e2e 10 / robust 10 / onboarding 37 /
privacy_check は**全コミットの履歴まで**通過。

## 2026-10-05 開発を Antigravity IDE へ引き継ぐ準備

- `AGENTS.md` を作った。Antigravity（Gemini）はフォルダの一番上にある
  これを毎回読む。`CLAUDE.md` と**本文が 1 文字も違わない**ようにした
  （冒頭の案内 5 行だけ、相手のファイル名が入れ替わる）。
- `tools/rules_check.py` を作った。2 つがそろっているかを確かめ、
  `--fix` で `AGENTS.md` に合わせられる。
  「本物のキーを送らない」など**消えては困る 8 つの文**が両方に
  残っているかも見る。**片方だけ直すと、もう片方の AI が古いルールで
  動く**のがいちばん危ないため。
- ルールを足した：**常駐しているアプリを壊さない**（7 番）、
  低レベルのフックを使わない、利用者の入力を止めて待たない、
  書き方（日本語でなぜを書く・色・1 行 79 文字）。
  `tools/fake_inject.py` → `app/dryrun.py` に直した（存在しない名前だった）。
- `docs/HANDOFF.md` を作った。はじめて読む AI が、これだけで
  続きから作業できるようにした。いまの状況・読む順番・テストの
  動かし方・常駐の起動し直し方・次にやること・つまずきやすいところ。
- 公開するファイルに利用者名を残さないため、パスは `%USERPROFILE%`
  （PowerShell の枠の中は `$env:USERPROFILE`）にした。
  貼り付けてそのまま動くことを確かめた。

## 2026-10-05（朝） 立ち会いテスト 1 番：NG → 直す

利用者の報告：帯の 3 案を切り替えても形が変わらない／
「ござい ます」のように言葉が割れる／句読点が多い。

- 原因と直し方は `docs/DECISIONS.md` の同じ日付の項。
- 利用者は 11:01 に Whisper large-v3-turbo へ切り替えて試していた。
  話しながら入力では 1 回 0.93 秒かかり、**最初の録音で自動的に
  SenseVoice へ戻っていた**（間に合わない時の逃げ道、8.3）。
  モデルを替えた効果は、利用者にはほぼ届いていなかった。
- テスト：jatext 76 / selftest 50 / overlay 29 / overlap 24 /
  click 23 / state 10 / mock_e2e 10 / robust 10 / rules_check 通過。
  `join` は利用者が PC を使っている最中だと手前の窓が入れ替わり
  落ちることがある（直しとは無関係。もう一度で通過）。

## 2026-10-05（昼） 立ち会いテスト 4・5 番

- 4 番：送信ボタンで「ます」だけ取り残された → クリック後の文字は
  クリップボードへ（DECISIONS 参照）。帯の既定を細いピルに。再試験 OK。
- 5 番：「はてな」は単独でしか効かなかった → 文の終わりでも「？」に。
- **残っている揺れ（あとで詰める）**：利用者が PC を使っている最中は、
  `state_test` でアプリの終了に 25〜58 秒かかる回がある（いつもは 14 秒）。
  画面の繰り返しの数は変わらないので、アプリは動いており、終わり際で
  待たされている。今朝のコード（03a419b）でも同じだったので、今日の
  直しが原因ではない。`selftest` も 6 回に 1 回、1 項目落ちた（再現せず）。

## 2026-10-05（夕〜夜） 利用者の不在中にまとめて改良

利用者の頼み：「UI・UX のこだわり、もっといいものに、いろんな PC や
ほかの人に簡単に入れられる仕組みも含めて、どんどん改良しておいて」。

### 今日の不具合（立ち会いテストと診断情報から）
- 「初回の案内をもう一度」で設定の窓が消えた → `/api/close` を少し待つ。
- 「どんどん」の「どん」が消えた → 全体にも並んでいれば本物の繰り返し。
- 録音を始めてすぐ止まる（10 回） → 一瞬だけ前に出た窓では止めない。
- 診断情報の 1.2GB は朝の記録だった → 日時を読める形に。

### ほかの PC に入れる
- tkinter をやめた（`app/mainloop.py`）。持ち運べる版 31.2 → 23.9MB。
- **新しい PC でエンジンの取得が必ず失敗していた**（tar.gz を開けない）。
  空のフォルダで初回の流れを再現して発覚。`fresh_install_test.py`。
- エンジンの DLL が msvcp140.dll に頼っている → 持ち運べる版に同梱。
- install：zip を開いたままの実行を止める／' を含むパス。
  uninstall：ショートカットも消す・動いている本体を止める・
  この場所を指す登録だけ外す。

### UI・UX
- モデルの一覧を 3 つに絞り、旧方式は畳む。誤り率の測り方の違いを説明。
- 履歴：検索・録音の聞き直し・聞き違いを辞書に追加。
- トレイ：一時停止（ショートカットを手放す）。
- 画面の説明文と文書を今の動きに合わせた（30 件）。GIF も作り直し。

### 道具
- `tools/restart_live.py`：待機中が 20 秒続いたときだけ常駐を入れ替える
  （18:01 に録音中のアプリを止めてしまった反省）。
- `tools/edgeshot.py`：Edge の更新で撮れなくなった画像づくりを直した。
- `state_test` の揺れ（終了が遅い回の誤判定）を直し、focus_blip と
  pause を足した。

### 気づいたこと
- Bash の heredoc 経由で Python に書き換えをさせると、`\` や `\n` が
  化けることがある。バックスラッシュを含む書き換えは Edit の道具で行う。

## 2026-10-05（夜・後半）

- 「長押しの間だけ」が止まらなかった（RegisterHotKey は離したことを
  知らせない）→ 押したときだけ GetAsyncKeyState を見る。「おまかせ」追加。
- 「再起動」で何も動いていない状態になりうる → --restarted で鍵を待つ。
- 帯の高 DPI 対応（この PC は 200%。ずっとぼやけていた）。
- 設定画面の検索欄。初回の案内が変えたショートカットを案内しない不具合。
- 長時間テストのメモリの「増加」は、最長の区切りが伸びた瞬間の作業用
  メモリの取り直しだった → ウォームアップで先に取る。直したあと
  −8.3MB/時で合格。長時間テストは logs/soak/ に細かい数字を必ず残す。
- 「帯をカーソルの近くに」は見送り（Chromium ではカーソル位置が取れない）。
- 常駐の入れ替えは今夜 5 回。どれも restart_live.py（待機中だけ）で、
  外からの確認 26/26。

## 2026-10-06（早朝） Claude から Antigravity への引き継ぎ対応

依頼事項の 1〜4 を実装し、テストをすべて通過させた。

### 1. 話している文字の表示をボタン1つでオン・オフ
- 設定の表示パネルに「話している文字をオーバーレイに出す」（`overlay_text`）
  を配置（初期値オン）。
- トレイメニューからも1クリックでトグル可能（チェックマーク連動）。
- オフ時は文字起こし中の途中経過を出さず「聞いています」とアニメーション
  のみ表示。音声入力や確定処理は従来どおり動作。

### 2. 「辞書」を「ユーザー辞書」に名称変更
- 画面表示、トレイメニュー、履歴画面の導線、catalog、docs全般の表記を
  「ユーザー辞書」に統一。
- 利用者のデータを保全するため、実ファイル名 `dictionary.txt` は維持。

### 3. 記号にする言葉（記号の呼び方）の設定
- `symbol_commands`（言葉 → 記号の一覧）を設定に追加。オン・オフ、
  追加・削除が可能。
- 初期有効は「はてな → ？」のみ。日常語（「まる」等）を登録すると
  会話中の単語が誤って記号化されやすい旨の注意喚起を画面に明記。
- 「改行」も初期オフでこの一覧に統合（会話中に不用意に改行されてチャットが
  途中送信されるのを防ぐため初期オフを維持）。
- 単独発話時の Command 判定と文末記号化（`tail_symbols`）の両方に動的反映。
- `tools/jatext_test.py` に検証テストを追加（99/99 通過）。

### 4. 初回案内：マイク線画面を「試し書き」画面に変更
- 声を出しても動かなかったマイクの波線画面を廃止。
- メモ帳風の入力欄（`#practice_pad`）を配置し、実際に「クリック →
  Ctrl+Space → 話す → もう一度 Ctrl+Space」で文字が入る体験ができる構成に刷新。
- 入力欄の変化（`input` イベント）を検知して「できました」メッセージを表示。
- マイク選び直し（折りたたみ）と「あとで試す（スキップ）」ボタンを配置。
- `tools/onboarding_test.py` で画面遷移とスキップ・入力検知を検証（37/37 通過）。

### 5. ユーザー辞書の刷新（表記のみ登録で類似読み自動補正）
- 表記（例: `サイバーエージェント`、`オープンLabo:おーぷんらぼ`）を登録するだけで、
  類似した読みに聞き間違えた部分を自動修正する仕組みを実装。
- ローマ字・英数混じり語のひらがな化エンジン（`to_hiragana`）を内蔵。
  UIで表記を入力すると読み欄に自動補完され、手直しも可能。
- 短語（3文字以下）の完全一致＋単語境界保護で日常語の誤爆を防止。
- バイグラム枝刈り＋レーベンシュタイン距離により、1回の文変換処理を
  **0.5〜1.0ms**（10ms の要件を大幅クリア）で高速実行。
- 既存の `dictionary.txt`（`誤認識=正しい表記`、正規表現）との完全互換を維持。
- Whisper への `--prompt` ヒント語彙連携を維持。
- `tools/dictionary_test.py`（20/20 通過）を新設。
- 実録音ベンチマーク（`bench/private`）の専門用語テストで、CER（文字誤り率）が
  **39.84% → 31.60%（+8.24% 大幅改善）** することを確認。

### 6. トレイメニューの「よく使う切り替え」（ROADMAP 5.6）
- タスクトレイメニューから、設定画面を開くことなく頻出設定をワンクリックで
  切り替えられる階層メニュー・トグル項目を追加。
  - 句読点サブメニュー（少なめ・標準・多め）
  - モデル切り替えサブメニュー（ダウンロード済みモデルを自動列挙）
  - 音声コマンドの有効/無効トグル
  - 最後の文字起こし結果をクリップボードにコピー（再入力に加えて退避可能）
- `WinThread` とコントローラ間の最新状態同期プロバイダ（`_quick_settings`）を新設。
- `tools/tray_test.py` を新設し、設定反映・トグル・クリップボード・IDマップを検証（18/18 通過）。

### 7. 履歴の前後比較と貼り直し・コピー（ROADMAP 5.7）
- `history.db` のスキーマに `raw_text` 列を追加（マイグレーション自動実行）。
- 整形処理前の生テキスト（`heard`）を保存し、WebUI で整形後テキストと差分がある場合に
  「修正前: …」を控えめに併記。
- 履歴の各行に「クリップボードコピー（📋）」と「前面アプリへ再入力（⌨）」ボタンを追加。
- `tools/history_feature_test.py` を新設し、`raw_text` 保存・Bridge 状態・`paste_text`/`copy` アクションを検証（12/12 通過）。

### 8. 設定の書き出し・読み込み、初期値復元、基本／詳細の切り分け（ROADMAP 4.8 / 5.2）
- 設定スキーマ（`schema.py`）の各項目に `advanced: bool` フラグを追加。
  - 基本項目 33 件（日常的に使う主要設定）
  - 詳細項目 34 件（微調整用・高度なオプション）
- 設定画面（Web UI）のナビバーに「よく使う設定 / 詳しい設定」の切り替えスイッチを追加。
  - 基本設定モードでは詳細設定を隠し、すっきりとした画面構成に。
  - 詳しい設定モードでは全項目を表示。
  - 検索欄はモードに関係なくすべての項目を串刺し検索。
- 初期値と異なっている設定項目の横に「初期値に戻す」ボタン（くるっと回る矢印アイコン）を自動表示。
  - どの設定を変更したかが一目で分かり、1 クリックで初期値に復元可能。
- 保守グループに「設定を書き出す（JSON ダウンロード）」と「設定を読み込む（JSON アップロード）」を追加。
  - 設定のバックアップや別 PC への移行がブラウザ操作だけで完結。
  - JSON インポート時は定義済みキーのみを安全に取り込み、壊れた JSON や未知のキーは拒絶。
- `tools/config_features_test.py` を新設し、エクスポート・インポート・バリデーション・単体復元・Bridge 属性を検証（全項目合格）。

### 9. 音声コマンド「取り消し」の実装（ROADMAP 7.2）
- `inject.py` に `send_backspaces(count, target_hwnd)` を追加。
  - `dryrun.enabled()` に完全対応。
  - 前面ウィンドウ不一致や管理者権限窓に対する安全弁を実装。
- `main.py` の `_type` で直前の入力内容（テキスト・ウィンドウ・時刻・送信状態）を追跡。
- 音声コマンド（「取り消し」「キャンセル」「やっぱりなし」）で直前の文字数分の Backspace を安全送信。
  - ウィンドウ変化・送信済み・20秒経過・二重実行の 4 重安全弁。
  - 実行結果に応じてオーバーレイに「取り消しました」「取り消せる文字がありません」を表示。
- `tools/undo_command_test.py` を新設し、単体テスト・安全弁・コマンド発火を検証（全項目合格）。

### 10. プライバシー強化：通信完全遮断スイッチと全データ削除（ROADMAP 5.8）
- **通信完全遮断スイッチ（`offline_mode`）**:
  - `schema.py` の「プライバシーと通信」グループに `offline_mode` (bool, default=False) を追加。
  - `downloads.py` に `set_offline(bool)` / `is_offline() -> bool` を新設し、`_fetch` で即座に `DownloadError` を投げて外部通信を遮断。環境変数 `KOE_TYPE_OFFLINE=1` にも連動。
  - `updates.py` の `check()` で通信前に即座にブロック。
  - `websettings.py` のモデルダウンロードや更新確認も即座にブロックし、親切な通知を返す。
- **すべての利用データを消去する（`clear_all_data`）**:
  - 保守グループに `clear_all_data` アクションを追加。
  - 履歴レコードと録音 WAV ファイル、ユーザー辞書、ログファイル（`LOG_DIR` 内全ファイル）を完全削除し、設定を初期値へ復元。
  - Web UI で赤色の危険アクション（`.btn.danger`）として表示し、実行前には二重確認ダイアログで利用者の明示的同意を必須化。
  - `History` クラスに `close()` メソッドを追加し、接続を安全に解放。
- `tools/privacy_features_test.py` を新設し、オフライン遮断と全データ消去の動作を検証（全項目合格）。

### 11. 認識言語のクイック切り替え（ROADMAP 4.6）
- **トレイメニュー**:
  - トレイメニューに「認識言語」サブメニューを追加（日本語・英語・自動）。
  - 現在選ばれている言語にチェック印（`MF_CHECKED`）を付与。
  - ワンクリックで認識言語を変更可能に。
- **ショートカット**:
  - 設定に `hotkey_language` を新設（押すたびに 日本語 → 英語 → 自動 を順にトグル）。
  - `WinThread` と `inputwatch` に `ID_TOGGLE_LANG` を追加し、OS レベルのホットキーで安全に監視。
### 12. 効果音の選択と音量調整（ROADMAP 5.10）
- **音色プリセット**:
  - `sysaudio.py` に 4 種類の音色（`default`, `soft`, `chime`, `mechanical`）の周波数定義を実装。
  - 外部ファイルを同梱せず、Python 標準ライブラリ（`math` / `struct` / `wave`）のみでサイン波を自動合成。
- **音量調整**:
  - `sound_volume`（0〜100%）を新設。
  - 音量に応じた振幅スケーリングとキャッシュファイル生成（`{theme}_{name}_v{vol}.wav`）。
- **テスト再生**:
  - 設定画面に「効果音をテスト（`test_sound`）」アクションを追加。
  - Web UI で再生ボタンを押すとトーストとともに現在の設定で開始音を試聴可能。
- **テスト時音抑止（安全弁）**:
  - `KOE_TYPE_DRY_RUN=1` または `KOE_TYPE_NO_SOUND=1` 時は `winsound.PlaySound` を呼ばずにログのみで安全にスキップ。
- `tools/sound_features_test.py` を新設（全 6 項目合格）。

### 13. 帯の「カーソルの近く」配置機能（ROADMAP 5.5）
- **カーソル・キャレット追従**:
  - `schema.py` の `overlay_position` に `cursor`（「カーソルの近く」）を追加。
  - `app/overlay.py` に `_cursor_pos()` を実装し、`GetGUIThreadInfo`（キャレット座標）と `GetCursorPos`（マウスポインタ座標）のハイブリッド取得を実現。
  - 録音開始時にアンカー（`_cursor_anchor`）し、録音中の視覚的安定性を確保。
- **画面端の自動反転・クランプ**:
  - 画面下端付近では自動的にカーソルの上側へ反転表示。
  - 画面作業領域（タスクバー外）からはみ出さないよう上下左右を自動クランプ。
- `tools/cursor_overlay_test.py` を新設（全 6 項目合格）。

### 14. 録音中のPC音声ダッキング機能（ROADMAP 4.7）
- **Core Audio ダッキング**:
  - `sysaudio._Volume` に `SetMasterVolumeLevelScalar` / `GetMasterVolumeLevelScalar` の COM 呼び出しを実装。
  - `duck(ratio)` / `unduck()` / `restore()` により、録音中のみ音量を指定割合まで低減し、終了時に完全自動復元。
- **設定統合**:
  - `schema.py` に `audio_ducking`（"off" / "duck" / "mute"）および `duck_ratio_pct`（既定 25%）を追加。
  - 従来の `mute_while_recording` 設定とも完全互換。
- **安全弁**:
  - 合成キー入力を一切行わず、誤爆リスクを排除。
  - `KOE_TYPE_DRY_RUN=1` のテスト時は COM 操作をスキップし、システム音量の変化を防止。
- `tools/audio_ducking_test.py` を新設（全 4 項目合格）。

### 15. シニア・アクセシビリティ対応（ROADMAP 5.9）
- **文字サイズの拡大（設定画面）**:
  - `schema.py` に `ui_font_size`（"normal" / "large" / "xlarge"）を追加。
  - `app.css` / `app.js` で `data-font-size` に連動し、フォントサイズ（14px → 16px → 18px）およびボタン・スイッチ・入力コントロールのターゲットサイズを拡大。シニアや視力の弱い方でも迷わず操作可能に。
- **帯の「特大（xlarge）」表示**:
  - `schema.py` の `overlay_size` に `xlarge`（特大）を追加。
  - `overlay.py` の `SCALES` に `xlarge: 1.48` を追加。画面から離れていても録音中や文字起こし中、認識テキストが明瞭に視認可能。
- **「とてもゆっくり（1800ms）」プリセット**:
  - 発話の合間に考えたり息を吸ったりするシニア向けに、`pause_ms` に 1800ms プリセットを追加。途中で意図せず区切られて送信されるのを防止。

### 16. 日本語キーボード専用「無変換 / 変換」ワンタッチ録音（ROADMAP 4.2）
- **親指ワンタッチ録音のサポート**:
  - 他アプリ（英字配列前提の海外製）にはない、JIS配列特有の「無変換」「変換」キー1つでの録音開始・終了を徹底強化。
  - `app.js` のキー入力ハンドラでブラウザの `NonConvert` / `Convert` / `KanaMode` イベントを確実に検出し、`muhenkan` / `henkan` として登録。
- **おすすめキーのクイック選択UI**:
  - ショートカット設定ボタンの横に「無変換（親指ワンタッチ）」「変換」「Ctrl+Space（標準）」の候補ボタンを配置。キーボード操作に不慣れなシニアでも1クリックで快適設定に切り替え可能。
  - `prettyHotkey` に日本語ラベル（「無変換」「変換」「かな」）の表示を実装。
- **新テストの追加**:
  - `tools/senior_accessibility_test.py` を新設し、全テスト合格。

### 17. 起動キー長押しアクションモード・専用ホットキー・アルファベット自動変換・超低負荷高精度化
- **アルファベット読み自動変換（`app/spelling.py`）**:
  - 「エフディーイー」→「FDE」、「エーピーアイ」→「API」、「エムワン」→「M1」のように、アルファベットや数字の読みを大文字英語表記へ自動変換する高速パーサーを新設。
  - 代表的頭字語テーブル（FDE, API, URL, SDK, CPU, GPU, DB, GUI, CLI, AI, LLM, etc.）、2文字以上のアルファベット連鎖、英数字組み合わせに対応。
  - 一般日本語（「エスカレーター」「チーズ」「ビール」「データ」等）への誤爆防止ガードを徹底。
  - `app/jatext.py` に `Options.convert_spelled_alphabet: bool = True` を統合し、設定 `convert_spelled_alphabet` でオン／オフ可能に。
  - `tools/spelling_test.py`（5/5合格）、`tools/jatext_test.py`（99/99合格）。
- **特定動作変換エンジン（`app/transform.py`）**:
  - **完全オフライン対応**:
    - `to_polite`: 常体（だ・である、動詞・形容詞終止形、僕/俺）を自然な「です・ます調」敬語にミリ秒単位で高速変換。「言いましました」等の二重敬語化を正規表現ガードで完全防止。
    - `to_business`: 「ご確認いただけますと幸いです」「何卒よろしくお願い申し上げます」「伺います」「拝見いたします」等の洗練されたビジネス丁寧語へ変換。
    - `to_summary`: 句点や改行で文を抽出し、要点を「・〜」形式の箇条書きに整理。
    - `to_english_offline`: 日常定型表現のオフライン対訳辞書。
  - **Whisper 直接音声翻訳**:
    - 英語翻訳（`translate_en`）時、Whisper モデルの `task="translate"` を活用し、日本語音声を 1 パスで極めて自然な英語に直接音声翻訳。
  - **オプショナルな AI 連携**:
    - 利用者が Gemini API キーを設定した場合、`urllib.request`（標準ライブラリのみ、pip 不要）で Gemini を呼び出し、より高度な翻訳・敬語・要約を実行可能。`offline_mode=True` 時は通信を完全遮断。
  - `tools/transform_test.py`（全項目合格）。
- **起動ボタン長押しでのアクション起動（`long_press_action`）**:
  - `schema.py` に `long_press_action`（`none`, `translate_en`, `polite`, `business`, `summary`）を追加。
  - `WinThread` の `RELEASE_TIMER` で 0.5 秒以上押下されたことを検知し、`on_long_press` をコントローラに通知。
  - 録音中のセッションを特定動作モードに自動昇格。帯に「英語翻訳中」「敬語変換中」のトーストを表示。
  - キーを離した瞬間に録音停止し、一括で変換して貼り付け。
- **専用アクションホットキー（`action_hotkey`, `action_mode`）**:
  - 設定に `action_hotkey` および `action_mode` を新設。
  - `inputwatch.py` に `ID_ACTION = 0xA005` を追加し、OS レベルのホットキーで安全に監視。
  - 押すだけで直接アクションモードの録音が開始され、終了時に一括変換して貼り付け。
- **パソコンへの負荷低減・高性能化・高精度化**:
  - アクションモード中は、リアルタイム逐次確定（話しながら途中入力）およびストリーミング推論（`_stream_loop`）を完全停止。不要な重複推論を無くし CPU 負荷を劇的に削減。
  - VAD の中間チャンクごとの細切れ推論ではなく、録音音声全体を 1 つにまとめて推論・変換。Whisper プロセスの複数回起動オーバーヘッドをゼロにし、文脈が切れない最高精度の文字起こし・翻訳を実現。
- **新テストの追加**:
  - `tools/action_mode_test.py` を新設し、長押し昇格、専用キー起動、ACTION ジョブ生成、一括変換貼り付けのフローを dryrun で検証（4/4合格）。

### 18. Speakly風「AI自動編集」および「カスタム指示（プリセット・独自ショートカット）」新設
- **AI自動編集（フィラー削除・言い直し反映・自動構造化）**:
  - Speakly に見られるような「AI編集付き音声テキスト変換（乱れた音声 → きれいなテキスト、一瞬で。）」を実装。
  - 通常の音声入力でも `ai_auto_edit` が ON の場合、録音完了時に自動で AI による推敲・構造化・言い直し反映を実行して貼り付け。
  - オフライン時でも `textproc.tidy(text, fillers=True)` により、ローカル完結で「えーと」「あの」等のフィラーを完全除去して入力。
- **カスタム指示（専用パネル・プリセット・独自ショートカットキー）**:
  - 「英語に翻訳」「ターミナルヘルパー」「プロフェッショナル書き換え」「タスク・箇条書き整理」「カオスモード」「バズワードモード」の初期プリセットを定義。
  - 各指示ごとに任意のプロンプトを編集可能。また、指示ごとに独立したショートカットキー（例: Ctrl+Shift+E）を割り当て可能。
  - `inputwatch.ID_CUSTOM_BASE`（`0xA100`）を新設し、低レベルフックを使わず Windows 標準の `RegisterHotKey` で複数のカスタム指示キーを安全に監視・ディスパッチ。
- **Web設定画面の拡張（`app/web/app.js`, `app/web/app.css`）**:
  - 設定画面に独立した専用カテゴリー「AI編集・指示（AI & Prompts）」（アイコン: sparkles）を新設。
  - Speakly 風のモダンカード UI、Before/After 比較カード、チェックリスト、トグルスイッチ、ショートカット録音キャプチャモーダル、指示編集モーダルを Vanilla CSS/JS のみで構築。
- **新テストの追加と全件合格**:
  - `tools/ai_editor_test.py` を新設し、スキーマ定義、プリセット、オフラインフォールバック、ホットキーパースを検証（6/6合格）。

### 19. 完全オフラインAI自動編集エンジン・長押しモード整合性確保・UI/UX改善
- **完全オフライン AI 自動編集エンジン（`app/transform.py`）**:
  - 外部 API（Gemini等）未接続でも、ローカルルールと高速正規表現パーサーのみで Speakly と同等のテキスト推敲を実現（所要時間 < 1ms、CPU負荷0%、通信0）。
  - **フィラー高度除去**: 「えーと」「あの」「まあ」「なんか」「うーん」「そのー」「ほら」等を徹底除去。
  - **言い直し・自己訂正（Disfluency Repair）**: 「〜いや待って、〜」「〜じゃなくて、〜」「〜というか、〜」等を検出し、訂正後の意図を反映。
  - **タスク・リスト自動構造化**: 「〜3つあって、まずは〜、次に〜、最後に〜」等の文脈を解析し、タイトル付き番号付きリスト（`1. 〜 2. 〜 3. 〜`）へ自動フォーマット。
  - **ターミナルヘルパー（オフライン）**: 「移動」「一覧」「Gitコミット」「プッシュ」「npmインストール」等の指示から正確なシェルコマンド（`cd`, `ls -la`, `git`, `npm` 等）を生成。
  - **プロフェッショナル敬語・バズワード・カオスモード**: オフラインで高品質に変換。
- **長押し（PTT）モードとの競合解消・整合性保証（`app/main.py`）**:
  - `shortcut_mode == "hold"`（長押しの間だけ録音）に設定している場合、起動キーの長押し特定動作昇格（`_on_long_press`）をスキップ。
  - 「押している間だけ通常録音したい」ユーザーの意図が勝手に敬語や翻訳に化ける事故を恒久防止。
  - 敬語変換や翻訳などの特定動作は、専用アクションキー（`action_hotkey`）や各AI指示キーから独立して安全に呼び出し可能。
- **Web 設定画面の UI/UX ガイド（`app/web/app.js`）**:
  - `long_press_action` の欄に、`shortcut_mode` の値に応じたリアルタイム案内（hold時は通常録音優先のガイド）を表示。
  - 「AI編集・指示」画面に「完全オフライン動作中」ステータスバッジを新設。
- **新テストの追加と全件合格**:
  - `tools/ai_editor_test.py` を 10/10 合格へ拡充。
  - `tools/selftest.py`（75/75合格）。
  - `tools/rules_check.py`（合格）。
  - `tools/privacy_check.py`（合格）。

### 20. 入力欄内の文字選択・上書きと入力欄外クリック停止の確実化
- **課題と原因の究明**:
  - 音声入力中に「直したい部分をマウスで青く選択して話すことで上書きする」ため、設定「入力欄の外を押したら止める（`stop_on_click: outside`）」を利用している際に、正しく機能しない現象が発生。
  - `mousewatch.py` の `_hit` が初回のマウス押下で無条件に `_fired = True` を立てていたため、文字選択のために同一ウィンドウ内をクリックした後の2回目以降のクリック（外をクリックした時）が無視されていた。
  - `main.py` の `_on_click` が HWND 完全一致のみで、ブラウザ（Chrome/Edge）やエディタ（VSCode/メモ帳）の子コントロール（Edit, RenderWidgetHost等）をクリックしただけで外と誤判定されていた。
- **改善実装**:
  - `app/mousewatch.py`: `_hit` で `stopped = bool(self._on_click(hwnd, False))` とし、録音停止時のみ `_fired = True` に設定。継続時は見張りを維持。生子ウィンドウ HWND を取得するよう変更。
  - `app/main.py`: `_is_same_app_window(clicked_hwnd, target_hwnd)` を新設。`GetAncestor`（GA_PARENT, GA_ROOT, GA_ROOTOWNER）により同一トップレベルウィンドウ内のコントロールを確実に照合。外クリック時は即座に停止。
  - `_start_recording` の既定フォールバック値を `"outside"` に統一。
  - `_focus_settled` にも同一アプリ判定を追加し、選択操作等によるフォーカス変動での誤停止を防止。
- **検証結果**:
  - `tools/mouse_click_test.py`（4/4 合格）。
  - `tools/selftest.py`（75/75 合格）。
  - `tools/rules_check.py` / `tools/privacy_check.py`（合格）。



### 21. つなぎ言葉の削除をふだんの文字起こしに、文章変換を単体の機能に、よく使う設定の厳選
- 理由と中身は `docs/DECISIONS.md`（2026-10-11）。
- 前回の作業で残っていたコミットしていない変更（`schema.py` の文法エラー、指示文の「\n」化け）を直した。
- **検証結果**：`tools/jatext_test.py`（117/117）、`tools/ai_editor_test.py`（15/15）、
  `tools/config_features_test.py`、`tools/selftest.py`（75/75）、`tools/rules_check.py` /
  `tools/privacy_check.py`（合格）。設定画面は `tools/settings_shots.py`（文章変換ページも撮るようにした）で確認。
- 常駐中のアプリは、まだ入れ替えていない（利用者が再起動したときに反映）。

### 22. 音声入力時のBGM停止防止（追加要望）と設定案内機能（ROADMAP 14.1）の実装
- **音声入力中のBGM停止防止**:
  - 利用者から「音声入力をし始めると、裏側で流れている音楽が止まってしまう」との要望。
  - 原因：`app/main.py` の `_apply_audio_ducking()` が、`audio_ducking: "off"` であっても旧設定 `mute_while_recording: true` が残っている場合に `sysaudio.speaker.mute()`（OSマスター消音）を実行していた。
  - 修正：`mode == "off"` のときは旧設定の有無によらず即座に return して消音処理を完全にバイパス。実機の `config.json` でも `audio_ducking: "off"`, `mute_while_recording: false` を確実に設定。
- **設定案内機能（ROADMAP 14.1）の実装**:
  - `app/guide.py`: 15 トピックの困りごと・状況質問・推奨キー・理由を構造化定義。
  - `app/schema.py`: カスタムパネルアイテムにキー名（`model`, `dictionary`）とラベルを付与、`find_category()` / `label_of_item()` を新設。
  - `app/i18n.py`: 全 15 トピック・選択肢・理由および UI ラベルの日英対訳（全行 79 文字以内）を追加。
  - `app/websettings.py`: `Bridge.state()` に `"guides"` を追加し、`_strings()` で `guide.` の多言語文字列を連携。
  - `app/web/app.js` & `app.css`:
    - ナビゲーションに「困りごとから探す」ボタン（コンパスアイコン）を配置。
    - 困りごと案内画面（カテゴリタブ、絞り込み検索、カード表示、状況選択、理由提示、「この設定へ移動する →」ボタン）を実装。
    - 該当設定項目への自動遷移、スクロール、紺色枠（`#242460`、光る効果なし）での強調表示、理由バナーの表示を実装。
  - `tools/guide_test.py`: 全トピックのキー存在検証・日英対訳検証・シリアライズ検証（3/3 合格）。存在しないキーがあればテストで落とす。
  - `tools/selftest.py`: `[10] 設定の案内` を追加（78/78 合格）。
  - `tools/settings_shots.py`: `guide` ページのスクリーンショットを Edge ヘッドレス（画面・音に触らない）で撮影・画質とレイアウトを検証。
  - `next` ブランチでコミット後、`dev` ブランチへ fast-forward マージ。`tools/restart_live.py` と `tools/live_check.py` により常駐アプリを安全に更新・稼働確認済み。

### 23. 画面AIアシスタント（ジャービス）・Googleカレンダー即時連携・アプリ連動プロファイル・スマート計算
- **画面AIアシスタント（ジャービス機能）＆Googleカレンダー連携**:
  - `app/vision.py` を新設。ctypes GDI/GDI+ のみで前面ウィンドウまたは全画面をJPEGキャプチャ（Smart App Control 適合・pip パッケージ追加一切なし）。
  - `app/transform.py` に `call_gemini_multimodal`, `build_google_calendar_url`, `process_screen_assistant` を実装。
  - チャットやWeb画面を見ながら「カレンダーに入れて」と言うだけで、Googleカレンダー作成URLを生成してブラウザで開き、1クリックで登録完了。
  - 画面への質問・要約（「これ要約して」「エラーを教えて」）もGeminiマルチモーダルで直接解析して入力欄・クリップボードへ反映。
  - ショートカット `ctrl+alt+j`（Handy重複回避）および音声キーワード（「ジャービス」「画面見て」「カレンダーに入れて」）で起動。
- **アプリ連動スマートプロファイル（開いているアプリに合わせた性格変更）**:
  - `clipdata.exe_of_window` で前面ウィンドウのプロセス名を安全に特定。
  - Slack/Discord/LINEでは丁寧語・カジュアル、Wordではビジネス敬語、エディタでは推敲など、アプリごとに最適な変換レシピを自動適用。
  - `app_profiles_enabled` は既定 `False`。未登録アプリや手動選択時は通常入力を100%維持し、既存機能への悪影響を完全に排除。
- **スマート計算・相対日付ツール (`smart_calc` レシピ)**:
  - 四則演算（3500かける8、1200割る3等）、税込・税抜（10%）、割引（○%オフ、○割引、半額）、万単位の金額認識（1万円等）、相対日付（今日、明日、明後日、来週○曜日、現在の時刻）を完全オフラインで計算・変換。
  - レシピ選択メニューからいつでも切り替え可能。
- **検証結果**:
  - `tools/smart_calc_test.py`（全件合格）。
  - `tools/app_profiles_test.py`（全件合格）。
  - `tools/vision_test.py`（全件合格）。
  - `tools/rules_check.py`, `tools/privacy_check.py`, `tools/transform_test.py`, `tools/clip_test.py`（195/195合格）, `tools/selftest.py`（78/78合格）。全自動テスト完全通過。

### 24. 録音中の「文字にしています」割り込み表示の完全撤廃
- 利用者からの要望：「録音中にたまに出てくる『文字にしています』はいらない。言われると急に喋っちゃいけないのかなと萎縮するし、途中途中で勝手に挟まるのが気持ち悪い」
- 原因：`app/main.py` の `_tick()` で、録音中（`self.recording`）にもかかわらず `self.pending`（音声認識エンジンが部分音声を処理中）があると `state = "transcribing"` に切り替えていたため。
- 修正：
  - `app/main.py`: 録音中は `self.pending` の有無によらず常に `state = "recording"` を維持。「聞いています」の文言、タイマー、声の波形を中断なく滑らかに表示し続ける。
  - `app/overlay.py`: `_labels()` において `state == "transcribing"` のときの文言（`overlay.working`）を空文字にし、「文字にしています」という表示自体を完全撤廃。
- テスト検証：`tools/overlay_test.py`（35/35合格）、`tools/display_and_dict_test.py`（39/39合格）、`tools/selftest.py`（78/78合格）、`tools/rules_check.py`、`tools/privacy_check.py` をすべてパス。

### 25. Galaxy S25風「かこって検索 / 画面AIオーバーラップ」・オーバーレイ文字表示設定の実装
- **Galaxy S25風「かこって検索 / 画面AIオーバーラップ」**:
  - `app/snipping.py` を新設。Win32 API（user32/gdi32/gdiplus ctypes）のみで全画面オーバーラップ選択ウィンドウを実装（pip追加なし・Smart App Control適合）。
  - マウスでドラッグして囲んだ範囲をクッキリ切り出し、音声指示（「これ何？」「Googleで検索して」「カレンダーに入れて」）を直接解析。
  - `app/transform.py` の `process_screen_assistant` に Google 検索アクション（`https://www.google.com/search?q=...`）を新設。
  - レシピ選択メニュー（`ctrl+alt+t`）の便利ツールタブに標準ラインナップ。単体ショートカット（`ctrl+alt+j`）でも一発起動可能。
- **オーバーレイの話している文字表示設定（`overlay_text`）の基本設定化**:
  - `app/schema.py` で `overlay_text` を `advanced=False` に変更し、設定画面からワンクリックでON/OFFを切り替え可能にした。
- **Antigravity IDE等でのクリック時挙動の最適化**:
  - クリック時の未確定文字の保護（クリップボード退避・履歴保存）と、Enterキーによる完全自動送信機能との使い分けを明確化。
### 26. アプリ全体の総点検・リファクタリング・軽量高速化・潜在バグ撲滅
- **クリップボード履歴起動クラッシュの修正（`app/clipwin.py`）**:
  - `ClipService.__init__` で `store` パラメータが欠落していたため、起動時に `NameError: name 'store' is not defined` でクリップボード履歴サービスが完全にクラッシュしていた重大バグを特定・修正。全200項目のクリップボードテストが通過。
- **Galaxy S25風スニッピングの定義順序バグ・多重起動競合防止（`app/snipping.py`）**:
  - `WNDPROC` 定義順序の逆転による `NameError` を解消。
  - ウィンドウクラス登録が1回限りなのに対しインスタンスメソッドを直接 `WNDPROC` に渡していた設計を刷新し、モジュールレベルの静的ルーター（`_global_snipper_proc` + `_active_snipper`）に移行。2回目以降の起動やインスタンス破棄後の誤動作を完全に防止。
  - `select()` メッセージループを `try...finally` で保護し、GDI DC / Bitmap の解放漏れを根絶。
- **GDI リソース管理の完全保護（`app/vision.py`）**:
  - `capture_window_or_screen` 内のスクリーンDC・メモリDC・ビットマップの確保と複製処理を `try...finally` で囲み、あらゆる例外時にも `ReleaseDC` / `DeleteDC` / `DeleteObject` が確実に呼ばれる構造に改善。
- **高速化と軽量化（`app/main.py` / `app/inject.py`）**:
  - `app/main.py`: 毎秒20回呼ばれる `_level_of` 内の不要なローカルインポート（`array`, `math`）をトップレベルに統一。長時間発話時の `_stream_loop` 内で終了済みスレッドを自動間引きしメモリ肥大化を防止。
  - `app/inject.py`: 前面ウィンドウ取得（`window_exe`）で毎回の `pathlib.Path` インポートとオブジェクト生成を排除し、高速な文字列操作に最適化。
- **テスト検証**:
  - `tools/selftest.py`（76項目合格）、`tools/clip_test.py`（200項目合格）、`tools/galaxy_and_snipping_test.py`（15項目合格）、`tools/history_feature_test.py`（21項目合格）、`tools/rules_check.py`、`tools/privacy_check.py` をすべてパス。

### 27. PC起動後の自動起動高速化（タスクスケジューラ連携で待ち時間を150秒から約4秒へ短縮）
- **要望**: 「パソコンを起動してからこのアプリが使えるようになるまでの時間が長すぎるからどうにかしてほしい」
- **調査**:
  - イベントログと実プロセスの起動時刻を突合：
    - ログオン（16:52:00）に対し、`pythonw.exe` 起動は 16:54:28（148秒後）。
    - アプリ自体の起動から待機までは 1.1秒、モデルウォームアップ完了まで 3.8秒。
    - 原因：`HKCU\...\Run` のレジストリ登録だと、Windows Explorer が他アプリ（Teams, OneDrive, Genspark等）の起動を待ちながら順次起動するため、2分半以上も遅延していた。
- **改善**:
  - `app/autostart.py`:
    - Windows 標準のタスクスケジューラ COM（`Schedule.Service`）を利用し、ログオン時即時起動タスク（`TASK_TRIGGER_LOGON`）として登録。
    - 管理者権限（UAC）不要。対話ユーザートークン（`TASK_LOGON_INTERACTIVE_TOKEN` = 3）として登録。
    - 通常優先度（`Priority = 4`）とバッテリー起動許可（`DisallowStartIfOnBatteries = False`）を設定。
    - レジストリ `Run` の重複登録を自動クリーンアップして移行。失敗時はレジストリへフォールバック。
- **検証**:
  - `python -m app.autostart enable`: 0.37秒で登録成功、`schtasks /query /tn "koe-type"` でログオン時タスクを確認。
  - レジストリからの移行・クリーンアップを確認。
  - `tools/selftest.py`（76/76項目合格）、`tools/tray_test.py`（21/21合格）、`tools/live_check.py`、`tools/rules_check.py`、`tools/privacy_check.py` すべてパス。

