<img src="assets/icon/png/idle-128.png" width="96" height="96" alt="koe-type">

# koe-type

**Offline Japanese voice typing for Windows 11. Free, and free forever.**

Press Ctrl+Space once and koe-type starts listening. Every time you pause for a
moment, the phrase you just said is transcribed and typed **straight into
whatever text field has focus** — a browser, a chat app, an editor, anything.

*[日本語の README](README.md)*

![What it looks like](docs/demo.gif)

<sub>The slim bar that appears while recording; the waveform moves with your
voice. Three shapes to choose from: pill (default), wave bar and card.</sub>

- **Your audio never leaves the PC.** The only network traffic is the one-time
  model download.
- **No paid API, no subscription, no "free tier".**
- **No third-party packages.** Python standard library and Windows system DLLs
  only — no pip, no virtualenv. It runs on PCs with Smart App Control enabled.
- About **1.2 s from starting to speak to the first character** (measured on
  the integrated GPU of an Intel Core Ultra 7 258V). The default model scores
  **12.3% character error rate** on FLEURS Japanese, and about 3–4% on real
  dictation ([full numbers](bench/RESULTS.md)).

Japanese is the primary target. Whisper (selectable) also handles English and
other languages, but the defaults are tuned for Japanese.

---

## Install

### Requirements

| | |
|---|---|
| OS | Windows 10 / 11 (64-bit) |
| Python | Not needed (the portable build ships its own signed Python). To use your own: 3.10 or newer; tkinter is not needed |
| Disk | from 700 MB (app 24 MB + default model 270 MB + headroom) |
| GPU | Optional. A Vulkan-capable GPU (recent Intel Arc / AMD / NVIDIA) makes it much faster |

### The easy way (about 10 minutes)

1. Download **`koe-type-…-portable.zip`** from [Releases](../../releases) and
   extract it anywhere.
2. **Double-click `install.cmd`.**
   - **No administrator rights needed**, and no Windows settings are changed.
   - It adds a Start-menu shortcut and starts koe-type when you sign in.
   - If you open it from inside the zip without extracting, it stops and
     asks you to extract first.
3. A **six-step setup guide** opens. Just go through it:
   1. Welcome (only three things to remember)
   2. **Check this PC** — looks at the CPU, memory and GPU, runs a short
      trial, and **picks a model for you, with the reason**
   3. Download the engine and model (about 270 MB, with progress; resumes if
      interrupted)
   4. Pick a microphone and check that it hears you
   5. Choose the shortcut (it checks for clashes with other apps)
   6. Try speaking

> The bundled Python is the **signed python.org build** (Python Software
> Foundation). The Visual C++ runtime the engine needs (`msvcp140.dll`) is
> bundled too. No new unsigned executables are created, so
> **Smart App Control does not block it.**

To uninstall, double-click **`uninstall.cmd`** in the same folder. It stops
koe-type, removes the Start-menu shortcut and autostart entry only if they
point to this folder, and asks whether to keep your settings, dictionary and
history.

### Light zip (if you already have Python)

1. Download `koe-type-….zip` (0.4 MB) from [Releases](../../releases) and
   extract it.
2. **Double-click `setup.cmd`.** If there is no usable Python, it installs the
   official python.org build via winget.
3. The setup guide opens.

### From source

```powershell
git clone https://github.com/<user>/koe-type.git
cd koe-type
start "" pythonw.exe koe-type.pyw
```

Models and engine binaries are downloaded on demand from the settings window,
or ahead of time:

```powershell
python -m app.fetch sensevoice-small
```

> **About SmartScreen and Smart App Control**
> koe-type itself is a Python script, so you will not see an "unknown
> publisher" prompt. The engine it downloads (the DLLs from the official
> transcribe.cpp release) is unsigned, and Smart App Control occasionally
> blocks individual files. (Legacy models under *Other models* use the
> official FunASR / whisper.cpp executables instead.) If that happens, pick a
> different model in the settings.

---

## Using it

| Key | What happens |
|---|---|
| **Ctrl+Space** (idle) | Start recording. A small capsule appears at the bottom |
| keep talking | Text is typed **while you are still speaking** |
| **Ctrl+Space** (recording) | Stop, transcribe the rest, type it. **Nothing is submitted** |
| **Enter** (recording) | Stop, type the rest, **then** press the send key |
| **Esc** (recording) | Cancel. Anything not yet typed is thrown away |

**When not recording, Enter and Esc are never intercepted.** Your normal typing
is untouched. Every shortcut can be changed in the settings.

### When text appears

The default is **while you speak**. koe-type re-transcribes the current
utterance from its start every 0.45 s and types only the part that three
consecutive passes agree on — the part that has stopped changing
(the LocalAgreement approach). The still-changing tail is shown faintly in the
indicator instead of being typed.

- **Text that has been typed is never deleted or rewritten**, because some
  applications corrupt text when you try.
- When you pause, the rest of that phrase is finalised and typed.
- *Transcription → When text is typed* offers three choices:
  - **While you speak (recommended)** — the default; text goes into the box
    as you talk.
  - **Preview in the bar** — in-progress text is shown only in the bar; the
    whole phrase is typed after a pause.
  - **Phrase by phrase (lightest)** — no preview; whole phrases are typed
    after a pause.

> **Why “while you speak” is the default**
> Phrase mode needs 0.7 s of silence to cut, and natural speech rarely has it.
> Measured on six real recordings here: the first text took 4.3 s on average,
> a 14.7 s recording contained exactly one qualifying pause, and one recording
> produced nothing at all until recording stopped.

### The indicator

A slim bar at the bottom centre (bottom-right or top, if you prefer). Pick
its shape under *Display → Shape*:

- **Pill** (default) — a short, slim capsule that rarely covers the box you
  are typing in
- **Wave bar** — a wide live waveform, so you can see the microphone hears you
- **Card** — shows what you are saying at the largest size

| Content | Meaning |
|---|---|
| red ● + moving bars + “Listening” + elapsed time | recording (the bars follow your voice) |
| navy ■ + “Writing it down” | finished speaking, the rest is being transcribed |
| green ✓ + a short notice | done, or stopped |
| faint text | not yet typed (while-you-speak mode) |

The wave bar and the card also show the key hint (“Ctrl+Space to stop · Esc
to cancel”); the pill does not.

It carries `WS_EX_NOACTIVATE` so it **never steals focus**, and
`WS_EX_TRANSPARENT` so **clicks pass straight through** to the app underneath.
It is drawn with GDI+ on a layered window, rounded and softly shadowed to match
Windows 11 notifications.

### Tray

Right-click the microphone icon: Settings / Dictionary / History / Open log /
Restart / Quit. Double-click opens the settings.

---

## Settings

Right-click the tray icon and choose **Settings** (double-clicking the icon
works too). Changes are **saved and applied immediately**; the few that need a
restart say so.

The settings window is HTML, shown through **Microsoft Edge in app mode**
(`msedge --app=...`) as a window of its own. Edge ships with Windows 11, so
nothing new has to be installed. It is served by a local server that

- listens on `127.0.0.1` only and rejects any request without the random token
  minted at startup,
- uses a throwaway Edge profile, so your normal browsing profile and history
  are untouched,
- shuts down as soon as the window closes.

On a PC without Edge it falls back to the default browser.

- **General** — recording shortcut, cancel shortcut, toggle vs push-to-talk,
  whether Enter submits, which key submits (Enter / Ctrl+Enter / Shift+Enter),
  delay before submitting, and a list of applications to leave alone
  (e.g. `Code.exe` keeps VS Code's Ctrl+Space working).
- **Audio** — microphone, stop after silence (default 10 s), stop when you
  click, stop when you move to another window, catch the start of your
  sentence (pre-roll), keep the end of your sentence (post-roll), silence that
  ends a phrase, microphone sensitivity, longest single chunk, maximum
  recording time, start/stop sounds, mute the PC while recording.
- **Transcription** — when text is typed (while you speak / preview in the
  bar / phrase by phrase), how often it re-listens (default 0.45 s), how sure
  it must be before typing, model list with download / delete / in-use /
  size / accuracy and speed ratings, language, punctuation, filler removal,
  half-width digits, voice commands.
- **Dictionary** — list, add, edit, delete, search, import, export.
- **Display** — indicator on/off, shape (pill / wave bar / card), key hints,
  position, size, distance from the edge, theme (follow Windows / light /
  dark), interface language (Japanese / English).
- **History** — list with copy and delete, how many entries to keep (0 = off),
  whether to keep the audio.
- **Application** — start with Windows, tray icon, open the log, open the data
  folder, reset all settings, version.

Settings live in `config.json` next to the app, as plain JSON. You can edit it
by hand — the running app notices and reloads within a second.

---

## Dictionary

A list of replacements applied right after transcription. Proper nouns are the
one thing no model gets right (30–45% error on every model tested), so the
dictionary is the main fix.

Edit it in the settings window, or open `dictionary.txt`:

```
misheard=correct spelling
```

one per line. **Saving applies it right away** — no restart.

- `#` starts a comment; blank lines are ignored
- the longest left-hand side wins, so overlapping entries are safe
- an empty right-hand side deletes the word (e.g. `um=`)
- prefix the left side with `re:` for a regular expression

The shipped file only contains examples. Add your own words as you hit them —
type the text exactly as it came out on the left.

---

## FAQ

**Is it really offline?** Yes. Audio is never sent anywhere. The only network
access is downloading models and engine binaries from Hugging Face and GitHub.
After that you can unplug the network entirely.

**Does it cost anything?** No. The default model, SenseVoice Small, is under
the FunASR Model License v1.1; the others are Apache-2.0 or MIT. All are free,
with no usage caps.

**Can I run it alongside another dictation tool?** Yes, as long as the
shortcuts differ. Modifiers are matched exactly, so holding `Ctrl+Space` does
not swallow `Ctrl+Shift+Space`.

**VS Code's Ctrl+Space stopped working.** Add `Code.exe` under
*General → Apps to leave alone* (it is there by default).

**Recording stopped when I clicked.** By default a click stops recording,
the same way Windows' own dictation does. Text produced after the click is not
pasted (it might land somewhere unexpected); it is put on the clipboard and
the bar says “The rest is on the clipboard — press Ctrl+V to paste it”.
Switching to another window also stops recording, but pop-ups that vanish in
under 0.3 s are ignored. Both can be changed under *Audio → Stopping by
itself*.

**Does it clobber my clipboard?** Normally no. The contents are saved just
before pasting and restored 0.25 s later. A few exotic formats (images in some
apps) cannot be restored; that is written to the log when it happens. When
koe-type copies instead of pasting (the window changed, an elevated app, or a
click stopped recording), the text stays on the clipboard so you can paste it,
and it can show up in the clipboard history (Win+V).

**Smart App Control blocked something.** Smart App Control blocks unsigned
executables based on reputation. koe-type itself is a script and is unaffected,
but an engine binary can be blocked. Pick a different model in the settings.
Do not turn Smart App Control off — it cannot be turned back on without
reinstalling Windows.

**Accuracy is not good enough.** 1) Add the mistakes to the dictionary.
2) Try **Whisper large-v3-turbo** under *Transcription* — slower but more
accurate. Set *When text is typed* to *Phrase by phrase*: in while-you-speak
mode Whisper usually cannot keep up and koe-type falls back to SenseVoice.
3) Move the microphone closer and lower the sensitivity under *Audio*.

**It cuts me off mid-sentence.** Raise *Audio → Silence that ends a phrase*
(say 1000 ms). Lower it (say 500 ms) if you want text to appear sooner.

**Where is my data?** Next to the app: `config.json`, `dictionary.txt`,
`data/history.db`, `logs/`. *Application → Open the data folder* takes you
there. To uninstall, double-click `uninstall.cmd` in the app folder.

---

## How it works

See the [Japanese README](README.md#中身の話) for the full layout. In short:

- Microphone capture talks to `winmm.dll` (`waveIn`) through ctypes.
- Silence detection is a small amplitude-based voice activity detector with an
  adaptive noise floor — no model, no extra dependency.
- Recognition runs inside the app: the transcribe.cpp DLL (`transcribe.dll`)
  is loaded through ctypes and keeps the model in memory, so there is no
  start-up wait per phrase. The official FunASR / whisper.cpp executables are
  only used, as a subprocess, for the legacy models.
- Text is inserted through the clipboard with Ctrl+V (so Japanese IME state
  cannot corrupt it), and the clipboard is restored afterwards. The temporary
  content is marked `CanIncludeInClipboardHistory = 0`, so nothing piles up in
  the Windows clipboard history (Win+V) or the cloud clipboard. (The exception
  is when it copies instead of pasting — see the FAQ above.)
- No tkinter. The settings window is a local HTML page shown in Edge's app
  mode, and the recording bar is drawn with GDI+ through ctypes. Both follow
  the Windows light/dark setting.

### Tests

```powershell
python tools\selftest.py        # no microphone, no speakers (49 checks)
python tools\pipeline_test.py   # WAV in, transcript out (14 checks)
python tools\tray_test.py       # tray and settings window (9 checks, no keys)
python tools\live_check.py      # checks the running app from the outside
python tools\privacy_check.py   # checks for personal data before committing
python tools\settings_shots.py  # 28 screenshots of the settings window
python tools\overlay_shots.py   # 10 pictures of the recording indicator
python tools\stream_bench.py    # latency and accuracy of both typing modes
python tools\make_icons.py      # rebuild the .ico and PNG files from the SVGs
python tools\make_social.py     # social preview and icon check sheet
```

Tests that synthesise key presses only do so when the test's **own** window is
confirmed to be in the foreground; otherwise they abort without sending
anything. Tests never use the speakers — the app reads a WAV through
`KOE_TYPE_FAKE_MIC` instead.

---

## Icon

The source artwork lives in `assets/icon/`: a voice waveform between Japanese
corner brackets, white on navy (`#242460`); the recording variant is red
(`#E0483A`).

- `icon.svg` — the base shape, used at 40px and above
- `icon-16/20/24/32.svg` — pixel-fitted variants. **Render each at its own size;
  never scale them.**
- `koe-type-idle.ico` / `koe-type-recording.ico` — Windows icons, 16–256px
- `png/` — PNGs at every size

Rebuild with `python tools\make_icons.py`. It reads the SVGs and rasterises
them in pure Python, with no extra dependencies.

---

## Licence

koe-type is [MIT](LICENSE).

Engine binaries and models are not part of this repository; they are fetched
from their official sources on first use.

| Component | Licence |
|---|---|
| Engine (transcribe.cpp) | MIT |
| Legacy engines (FunASR llama.cpp runtime, whisper.cpp) | MIT |
| SenseVoice Small (default model) | **FunASR Model Open Source License Agreement v1.1** — *not* Apache-2.0 |
| Whisper large-v3-turbo | Apache-2.0 |
| Moonshine Base Japanese | MIT |
| Fun-ASR-Nano (legacy) | Apache-2.0 |
| Whisper large-v3-turbo (ggml, legacy) | MIT |

SenseVoice Small requires that you keep the attribution and the model name.
See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the details.
