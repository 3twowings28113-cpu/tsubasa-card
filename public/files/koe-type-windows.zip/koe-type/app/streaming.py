"""話しながら入力するための、文字の「確定」の判定。

やり方は LocalAgreement-2。
いまの発話を 0.6 秒ほどごとに**先頭からやり直して**文字起こしし、
**連続する 2 回の結果で先頭から一致している部分**だけを「もう変わらない」
とみなして入力欄に送る。残り（まだ変わりうる部分）は入力せず、
画面の帯に薄く出すだけにする。

入力欄に入れた文字はあとから消したり書き換えたりしない。
アプリによっては文字が壊れるため。
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)

# 文の終わりで「？」に替わる言い方（jatext.TAIL_QUESTION_WORDS と同じ）。
# ここで jatext を読むと読み込みの順がややこしくなるので、写しを持つ。
TAIL_WORDS = ("はてなマーク", "ハテナマーク", "はてな", "ハテナ",
              "クエスチョンマーク", "クエスチョン", "疑問符",
              "びっくり", "感嘆符", "改行")

# 文の終わりらしい所まで下げて確定する。語の途中で切るより読みやすい。
BOUNDARY = "。、！？!?…」』）)"


def common_prefix(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


OVERLAP_WINDOW = 24          # 重なりを探す文字数
MIN_COMMIT = 2               # これ未満の文字数では確定しない（貼り付けが増えるだけ）

# 重なりを探すときに無視する記号と空白
_IGNORE = set("、。，．！？!?,.…・ "
              "　\t\n\r")

# 送り仮名の揺れ（「隣り」と「隣」）。漢字のうしろの送り仮名は
# 付いたり付かなかったりするので、骨組みを比べるときは落とす。
_HIRAGANA = (0x3041, 0x309F)


def _norm(text):  # noqa: ANN001, ANN201
    """記号と空白を落とし、カタカナをひらがなにそろえる。

    戻り値は (そろえた文字列, それぞれが元の何文字目か)。
    位置が分かるので、見つけた重なりを元の文字列の位置に戻せる。
    """
    out = []
    index = []
    for i, ch in enumerate(text):
        if ch in _IGNORE:
            continue
        code = ord(ch)
        # カタカナ → ひらがな（「キャク」と「きゃく」をそろえる）
        if 0x30A1 <= code <= 0x30F6:
            ch = chr(code - 0x60)
        out.append(ch)
        index.append(i)
    return "".join(out), index


def _skeleton(text: str) -> str:
    """ひらがなを落とした骨組み。送り仮名の揺れを吸収する。

    「隣りの客」も「隣の客」も「隣客」になる。
    **言い直しかどうかを疑うため**だけに使い、これで切る位置は決めない。
    """
    return "".join(ch for ch in text
                   if not (_HIRAGANA[0] <= ord(ch) <= _HIRAGANA[1]))


def resume_at(committed: str, text: str) -> int:
    """すでに入力した文字の「続き」が text のどこから始まるかを返す。

    文字起こしをやり直すと、同じ所が「10時」「十時」「隣り」「隣」の
    ように揺れる。前から順に比べるだけだと食い違った所から全部
    入れ直してしまい、**同じ言葉が二重に入る**（実際に起きた）。

    そこで

      1. 記号・空白を落とし、カタカナをひらがなにそろえて比べる
      2. 入力済みの末尾が text のどこに現れるかを、長いほうから探す
      3. 見つからなければ、**ひらがなを落とした骨組み**でもう一度探す
         （「隣りの」と「隣の」をここで拾う）
      4. それでも分からなければ、**入れないほうを選ぶ**

    4 が大事。迷ったときに入れると二重になり、入れた文字は直せない。
    """
    if not committed:
        return 0
    if text.startswith(committed):
        return len(committed)

    norm_c, _ = _norm(committed)
    norm_t, map_t = _norm(text)
    if not norm_c or not norm_t:
        return common_prefix(committed, text)

    # そろえた形で前方一致するなら、そこまで進める
    if norm_t.startswith(norm_c):
        return (map_t[len(norm_c)] if len(norm_c) < len(map_t)
                else len(text))

    tail = norm_c[-OVERLAP_WINDOW:]
    limit = min(len(norm_t), len(norm_c) + OVERLAP_WINDOW)
    # ★見つかった場所が、入力済みの長さよりずっと手前なら偶然の一致。
    # 「…止まっちゃってる、…聞いちゃってる、」まで入れたあと、最終が
    # 「…聞いゃったりす…」に変わると、末尾の「ちゃってる」が前の
    # 「止まっちゃってる」で見つかり、そこから後ろを**二重に入れた**
    # （2026-10-06。利用者のメッセージが途中から繰り返しになった）。
    slack = max(3, len(norm_c) // 4)
    for size in range(len(tail), 1, -1):
        piece = tail[-size:]
        found = norm_t.rfind(piece, 0, limit)
        if found >= 0:
            end = found + size
            if end < len(norm_c) - slack:
                continue           # 手前すぎる。もっと短い一致も同じ
            return map_t[end] if end < len(map_t) else len(text)

    # 先頭からほとんど同じで、終わりのほうだけ聞こえ方が変わったとき。
    # 入力済みと同じ文字数ぶん進めたところから続ける（直せない部分は
    # 残るが、二重にも欠けにもならず、文として読める）。
    same = common_prefix(norm_c, norm_t)
    if same >= len(norm_c) * 0.6 and len(norm_t) >= len(norm_c):
        at = len(norm_c)
        return map_t[at] if at < len(map_t) else len(text)

    # 骨組みで探す（送り仮名の揺れを越える）
    skip = _resume_by_skeleton(norm_c, norm_t, map_t, len(text))
    if skip is not None:
        return skip

    # ここまで来たら、重なりが分からない。
    # **入れないほうを選ぶ。** 二重に入れるより、少し足りないほうがよい。
    plain = common_prefix(committed, text)
    guess = _safe_skip(norm_c, norm_t, map_t, len(text))
    return max(plain, guess)


def _resume_by_skeleton(norm_c, norm_t, map_t, text_len):  # noqa: ANN001, ANN201
    """ひらがなを落とした骨組みで、言い直しの長さを探す。

    やり方は「**text の頭から何文字が、入力済みの言い直しか**」を
    いちばん長いところまで伸ばす。判定は骨組みで行うので、
    「隣り」と「隣」のような送り仮名の揺れを越えられる。

        入力済み  隣りの      → 骨組み 隣
        最終      隣の客は…
                  隣          骨組み 隣   → 隣 の後ろ。当たり
                  隣の        骨組み 隣   → 当たり（ここまで言い直し）
                  隣の客      骨組み 隣客 → 外れ。ここで止める

    結果、「客は…」から入れる。「隣りの」＋「客は…」で二重にならない。
    """
    skel_c = _skeleton(norm_c)
    if not skel_c:
        # 入力済みが全部ひらがな。骨組みでは何も言えないので触らない
        # （当てずっぽうで飛ばすと、文字が消える）。
        return None
    limit = min(len(norm_t), len(norm_c) + OVERLAP_WINDOW)
    best = None
    for j in range(1, limit + 1):
        skel_head = _skeleton(norm_t[:j])
        if not skel_head:
            continue
        if not skel_c.endswith(skel_head):
            if best is not None:
                break        # 伸ばせなくなったら、そこまで
            continue
        # ★切るのは「次の骨（漢字・カタカナ・数字）の手前」だけにする。
        # 送り仮名の途中で切ると「隣りの」＋「の客は」のように
        # 残ってしまう。文字列の終わりは、入力済みより長くない時だけ。
        if j < len(norm_t):
            nxt = norm_t[j]
            if _HIRAGANA[0] <= ord(nxt) <= _HIRAGANA[1]:
                continue
        elif len(norm_t) > len(norm_c):
            continue
        best = j
    if best is None:
        return None
    at = map_t[best] if best < len(map_t) else text_len
    log.info("送り仮名の揺れを越えて重なりを見つけました（%d 文字目から）", at)
    return at


def _safe_skip(norm_c, norm_t, map_t, text_len):  # noqa: ANN001, ANN201
    """重なりが分からないときの、控えめな逃げ道。

    入力済みの**最後の 2 文字**が text の前のほうに出てくるなら、
    そこまでは言い直しだと考えて飛ばす。何も見つからなければ 0。
    """
    if len(norm_c) < 2:
        return 0
    piece = norm_c[-2:]
    found = norm_t.find(piece, 0, min(len(norm_t), OVERLAP_WINDOW))
    if found < 0:
        return 0
    end = found + 2
    return map_t[end] if end < len(map_t) else text_len


def remainder(committed: str, final_text: str) -> str:
    """区間が終わったとき、すでに入力した分を除いた残りを返す。"""
    if not final_text:
        return ""
    start = resume_at(committed, final_text)
    if committed and start < len(committed):
        log.info("最終結果が入力済みと少し違います（%d/%d 文字目から続けます）",
                 start, len(committed))
    rest = final_text[start:]
    if not committed:
        return rest
    # 念のため、もう一度だけ重なりを落とす。
    # 位置の計算がどこかで外れても、**二重に入れない**ことを守る。
    rest = _drop_repeat(committed, rest, whole=final_text)
    # つなぎ目の記号は落とす（「あのね」＋「、そうなんです」を防ぐ）
    return rest.lstrip("\u3001\u3002\uff0c\uff0e\u2026 \u3000")


def _run_of(piece: str, text: str) -> int:
    """text の中で piece が**続けて**いちばん多く並ぶ回数。"""
    best = 0
    k = 1
    while piece * k in text:
        best = k
        k += 1
    return best


def _drop_repeat(committed: str, rest: str, *, whole: str = "") -> str:
    """残りの頭が、入力済みの終わりと重なっていたら削る。

    「取り消し」まで入れたあと、聞き直しが「取消しました」だと
    「取り消し」＋「消しました」になってしまう。ここで「消し」を落として
    「取り消しました」にする。

    1 文字の重なりは**落とさない**。たまたま同じ文字が続くことが
    あり、落とすと文字が消えてしまうので。

    ★whole（区間まるごとの結果）に、その並びが**本当に続けて**
    あるなら落とさない。「どんどん改良」の「どん」まで入れたあと、
    残りの「どん改良」の頭を重なりとみなして消し、「どん改良」に
    なっていた（2026-10-05）。「どんどん」「いろいろ」「まあまあ」は
    言葉そのものが繰り返しになっている。
    """
    norm_c, _ = _norm(committed)
    norm_r, map_r = _norm(rest)
    norm_w, _ = _norm(whole)
    if not norm_c or len(norm_r) < 2:
        return rest
    for size in range(min(8, len(norm_c), len(norm_r)), 1, -1):
        head = norm_r[:size]
        if norm_c.endswith(head):
            if norm_w:
                # つなぎ目で何回続くか（入力済みの終わり側＋残りの頭）
                joined = _run_of(head, norm_c[-size * 4:] + head)
                if _run_of(head, norm_w) >= joined:
                    return rest     # 全体にもその回数だけ並んでいる
            at = map_r[size] if size < len(map_r) else len(rest)
            log.info("残りの頭が重なっていたので %d 文字落とします", at)
            return rest[at:]
    return rest


class RoundGate:
    """話しながらの聞き直し（回）の「古さ」判定。区間ごとに数え直す。

    1 回の区間の中では、結果は頼んだ順に返ってこないので、
    「自分より長い音の結果がすでに反映されていたら、その回は捨てる」
    ことで巻き戻りを防ぐ。その基準（反映済みの最長バイト数）は
    **区間が変わるたびに 0 へ戻す**。

    ★以前はこの基準を録音全体で持ち続けていた。区間が確定すると
    カッターの蓄積は新しい区間の短い音から始まるのに、基準が前の
    区間の長さのまま残るため、新しい区間の回が（デコードまで済んだ
    あとで）全部「古い」と捨てられていた。とくに強制区切り
    （max_segment_ms）のあとは、次の区間が前の区間の長さを超える
    まで部分仮説が一切更新されず、

      ・話しながら入力が止まる
      ・保険の heard（最新／最良の仮説）が空・古いままになる
      ・最終デコードが空だった区間が、保険なしで丸ごと消える

    という壊れ方をした。長く話すほど後半で起きるのが特徴。
    世代（utterance）が変わったら数え直すことで防ぐ。
    """

    def __init__(self) -> None:
        self.generation = -1
        self.applied = 0       # その区間で反映済みの最長バイト数
        self.last_len = 0      # その区間で最後に頼んだ音のバイト数

    def sync_generation(self, generation: int) -> None:
        """区間が変わっていたら、基準を数え直す。"""
        if generation != self.generation:
            self.generation = generation
            self.applied = 0
            self.last_len = 0

    def should_spawn(self, nbytes: int, min_bytes: int) -> bool:
        """新しい回を頼んでよいか（前回と同じ長さなら結果は同じ）。"""
        return nbytes >= min_bytes and nbytes != self.last_len

    def note_spawn(self, nbytes: int) -> None:
        self.last_len = nbytes

    def accept(self, generation: int, nbytes: int) -> bool:
        """届いた結果を反映してよいか。

        ほかの区間の結果と、区間内で自分より長い音の結果が
        すでに反映されている場合は捨てる。
        """
        if generation != self.generation:
            return False
        if nbytes <= self.applied:
            return False
        self.applied = nbytes
        return True

class Agreement:
    """1 回の発話ぶんの状態。

    **何回連続で同じ先頭が出たら確定するか**を `rounds` で決める。
    2 回だと、モデルが迷っているうちに確定してしまう。実測では

        1回目: とも？
        2回目: とそれ。
        3回目: と総令母の。
        4回目: と総令母の新し。
        5回目: 智総 令母 の 新しい 記事 を。

    のように、ひらがな→カタカナ→漢字と揺れる。2 回一致だと 4〜5 回目で
    「と総令」を入れてしまい、**入れた文字は直せない**ので間違いが残る。
    3 回一致にすると、揺れが収まってから入る。
    常駐方式では 1 回が 0.1 秒なので、3 回でも 0.3 秒しか増えない。
    """

    def __init__(self, *, hold_chars: int = 2, rounds: int = 3,
                 min_span: float = 0.8) -> None:
        # (文字起こし, その時点で聞いた音の長さ秒)
        self.history: list[tuple[str, float]] = []
        self.committed = ""     # すでに入力欄へ送った文字
        self.latest = ""        # いちばん新しい文字起こし
        # この発話で**いちばんよく聞こえた**結果。
        # 確定の 1 回が空を返したときの保険に使う。
        self.best = ""
        self.hold_chars = hold_chars   # 末尾をこの文字数だけ確定させずに残す
        self.rounds = max(2, rounds)
        # 一致を認めるのに必要な「音の増え方」。
        # 回数だけで見ると、聞き直しが 180ms おきのときは
        # 3 回一致しても音は 0.36 秒しか増えておらず、
        # モデルが迷っている最中に確定してしまう（実際に起きた）。
        self.min_span = max(0.0, min_span)

    # ------------------------------------------------------------------

    @property
    def previous(self) -> str:
        """1 つ前の文字起こし（後方互換のため残してある）。"""
        return self.history[-1][0] if self.history else ""

    def _agreed_len(self) -> int:
        """確定してよい先頭の長さ。

        条件は 2 つ**とも**満たすこと。

          ・直近 `rounds` 回で先頭が一致している
          ・その一致が、**`min_span` 秒ぶん以上の音の増加**をまたいでいる

        2 つ目が大事。聞き直しの間隔が短いと、同じような音を
        何度も聞いているだけで「一致した」ことになってしまう。
        「もっと聞いても変わらなかった」ことを確かめたい。
        """
        if len(self.history) < self.rounds:
            return 0
        recent = self.history[-self.rounds:]
        agreed = len(recent[0][0])
        for text, _secs in recent[1:]:
            agreed = min(agreed, common_prefix(recent[0][0], text))
        if not agreed:
            return 0

        if self.min_span > 0:
            newest = self.history[-1][1]
            # その先頭が、いつから変わっていないかを探す
            oldest = newest
            for text, secs in reversed(self.history):
                if common_prefix(text, recent[-1][0]) < agreed:
                    break
                oldest = secs
            if newest - oldest < self.min_span:
                return 0
        return agreed

    def update(self, text: str, seconds: float = 0.0) -> str:
        """新しい文字起こしを入れ、今回あらたに確定した文字を返す。

        seconds は、その文字起こしが聞いた音の長さ。
        これがないと「もっと聞いても変わらなかった」が判定できない。
        """
        if text.strip() and len(text) > len(self.best):
            self.best = text
        self.latest = text
        self.history.append((text, seconds))
        # 音の増え方を見るので、少し長めに持っておく
        keep = max(self.rounds + 2, 16)
        if len(self.history) > keep:
            del self.history[0]
        agreed = self._agreed_len()

        if agreed <= len(self.committed):
            return ""

        # 末尾の数文字は、次の回で変わることが多いので残す
        cut = max(len(self.committed), agreed - self.hold_chars)
        cut = self._snap(text, cut, agreed)
        cut = self._hold_command_start(text, cut)
        if cut <= len(self.committed):
            return ""

        start = resume_at(self.committed, text)
        if cut - start < MIN_COMMIT and not (
                cut and text[cut - 1] in BOUNDARY):
            return ""          # 1 文字だけ送るのは割に合わない
        if start >= cut:
            return ""
        fresh = text[start:cut]
        self.committed = text[:cut]
        return fresh

    @staticmethod
    def _hold_command_start(text: str, cut: int) -> int:
        """確定の末尾が「は」「はて」なら、そこは入れずに待つ。

        文の終わりの「はてな」は「？」に替わる（jatext.tail_question）。
        先に「はて」まで入れてしまうと、入れた文字は直せないので
        「はて？」が残る。言葉が続けば次の回で入るので、遅れは小さい。
        """
        head = text[:cut]
        back = 0
        for word in TAIL_WORDS:
            for k in range(len(word), 0, -1):
                if k > back and head.endswith(word[:k]):
                    back = k
                    break
        return cut - back

    def _snap(self, text: str, cut: int, limit: int) -> int:
        """句読点の直後まで伸ばせるなら伸ばす（読みやすさのため）。"""
        for i in range(min(limit, len(text)), cut, -1):
            if text[i - 1] in BOUNDARY:
                return i
        return cut

    # ------------------------------------------------------------------

    def pending(self) -> str:
        """まだ入力していない部分（帯に薄く出す文字）。"""
        if self.latest.startswith(self.committed):
            return self.latest[len(self.committed):]
        return self.latest

    def take(self) -> str:
        """これまでに入力した分を返して、状態を空にする。

        区間が確定した時点で呼ぶ。以降の「残り」の計算は、
        返した文字列をもとに worker スレッドだけで行うので、
        2 つのスレッドが同じ状態を取り合うことがなくなる。
        """
        typed = self.committed
        self.reset()
        return typed

    def take_best(self) -> str:
        """この発話でいちばんよく聞こえた結果（確定が空だったときの保険）。"""
        return self.best

    def reset(self) -> None:
        self.history.clear()
        self.committed = ""
        self.latest = ""
        self.best = ""
