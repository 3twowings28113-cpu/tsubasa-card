"""最近この PC に入ってきたファイル（ダウンロード・デスクトップ・OneDrive）。

利用者の頼み（2026-10-11）：ダウンロードしたばかりのファイルを、
クリップボードの一覧からすぐ見て、そのままドラッグで渡したい。
OneDrive だけでなく、ローカルのダウンロードも。

  ・探すのは別のスレッド。一覧は前に調べた結果をすぐ出し、裏で新しくする
  ・os.scandir だけを使う（Windows では名前・大きさ・時刻・属性が
    1 回で取れ、ファイルを開かない）
  ・OneDrive の「クラウドだけ」にあるファイルは、中身を読まない。
    読むと、その場でダウンロードが始まってしまうため
    （縮小画像を作らない・印だけ付ける）
"""

from __future__ import annotations

import ctypes
import logging
import os
import threading
import time
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)

FILE_ATTRIBUTE_HIDDEN = 0x2
FILE_ATTRIBUTE_SYSTEM = 0x4
FILE_ATTRIBUTE_OFFLINE = 0x1000
FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x40000
FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x400000
CLOUD_ONLY = (FILE_ATTRIBUTE_OFFLINE | FILE_ATTRIBUTE_RECALL_ON_OPEN
              | FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS)

# 書きかけ・一時ファイル。ダウンロードの途中のものは渡せない
PARTIAL = (".crdownload", ".part", ".partial", ".tmp", ".download",
           ".opdownload", ".!ut", ".bc!", ".lnk", ".url", ".ini")
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff")
# 中を探さないフォルダ（大きい・関係ない）
SKIP_DIRS = {"node_modules", ".git", "__pycache__", "$recycle.bin",
             "appdata", ".venv", "venv"}


class GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


def _guid(text: str) -> GUID:
    parts = text.strip("{}").split("-")
    tail = bytes.fromhex(parts[3] + parts[4])
    return GUID(int(parts[0], 16), int(parts[1], 16), int(parts[2], 16),
                (ctypes.c_ubyte * 8)(*tail))


FOLDERID_DOWNLOADS = _guid("374DE290-123F-4565-9164-39C4925E467B")
FOLDERID_DESKTOP = _guid("B4BFCC3A-DB2C-424C-B029-7FE99A87C641")


def known_folder(folder_id: GUID) -> Path | None:
    """「ダウンロード」などの本当の場所（移してあっても正しく取れる）。"""
    try:
        shell32 = ctypes.WinDLL("shell32")
        ole32 = ctypes.WinDLL("ole32")
        fn = shell32.SHGetKnownFolderPath
        fn.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
                       ctypes.POINTER(ctypes.c_wchar_p)]
        fn.restype = ctypes.c_long
        out = ctypes.c_wchar_p()
        if fn(ctypes.byref(folder_id), 0, None, ctypes.byref(out)) != 0:
            return None
        try:
            return Path(out.value) if out.value else None
        finally:
            ole32.CoTaskMemFree.argtypes = [ctypes.c_void_p]
            ole32.CoTaskMemFree(ctypes.cast(out, ctypes.c_void_p))
    except Exception:
        log.debug("既知のフォルダを取れませんでした", exc_info=True)
        return None


@dataclass
class Root:
    path: Path
    label: str          # 一覧に出す場所の名前（「ダウンロード」など）
    depth: int          # 下の階層をいくつまで見るか


@dataclass
class Found:
    path: str
    name: str
    size: int
    stamp: float        # 作られた／変わった時刻の新しいほう
    where: str          # 「ダウンロード」「OneDrive - ○○\\画像」など
    cloud: bool         # クラウドだけにある（中身を読まない）

    @property
    def is_image(self) -> bool:
        return self.name.lower().endswith(IMAGE_EXT)


def roots(*, onedrive: bool = True, desktop: bool = True,
          labels: dict[str, str] | None = None) -> list[Root]:
    """探す場所。同じ場所は 1 回だけ（OneDrive に移したダウンロードなど）。"""
    labels = labels or {}
    out: list[Root] = []
    seen: set[str] = set()

    def add(path: Path | None, label: str, depth: int) -> None:
        if not path:
            return
        try:
            key = os.path.normcase(str(path.resolve()))
        except OSError:
            return
        if key in seen or not path.is_dir():
            return
        seen.add(key)
        out.append(Root(path, label, depth))

    home = Path(os.environ.get("USERPROFILE") or Path.home())
    add(known_folder(FOLDERID_DOWNLOADS) or home / "Downloads",
        labels.get("downloads", "Downloads"), 2)
    add(home / "Downloads", labels.get("downloads", "Downloads"), 2)
    if desktop:
        add(known_folder(FOLDERID_DESKTOP) or home / "Desktop",
            labels.get("desktop", "Desktop"), 1)
    if onedrive:
        for env in ("OneDriveConsumer", "OneDriveCommercial", "OneDrive"):
            value = os.environ.get(env)
            if value:
                add(Path(value), Path(value).name, 4)
    return out


def scan(where: list[Root], *, days: int, limit: int = 80,
         budget_s: float = 3.0) -> list[Found]:
    """最近のファイルを新しい順に。時間がかかりすぎたら、そこまでで返す。"""
    since = time.time() - max(1, days) * 86400
    deadline = time.monotonic() + budget_s
    found: list[Found] = []
    seen: set[str] = set()
    for root in where:
        stack: list[tuple[Path, int, str]] = [(root.path, 0, root.label)]
        while stack:
            if time.monotonic() > deadline:
                log.info("最近のファイル：時間切れのため途中まで（%d 件）",
                         len(found))
                break
            folder, depth, label = stack.pop()
            try:
                with os.scandir(folder) as it:
                    entries = list(it)
            except OSError:
                continue
            for entry in entries:
                name = entry.name
                if name.startswith((".", "~$", "~")):
                    continue
                try:
                    st = entry.stat(follow_symlinks=False)
                except OSError:
                    continue
                attrs = getattr(st, "st_file_attributes", 0)
                if attrs & (FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM):
                    continue
                if entry.is_dir(follow_symlinks=False):
                    if (depth + 1 < root.depth
                            and name.lower() not in SKIP_DIRS):
                        stack.append((Path(entry.path), depth + 1,
                                      f"{label}\\{name}"))
                    continue
                if name.lower().endswith(PARTIAL):
                    continue
                stamp = max(st.st_mtime, getattr(st, "st_birthtime",
                                                 st.st_ctime))
                if stamp < since:
                    continue
                key = os.path.normcase(entry.path)
                if key in seen:
                    continue
                seen.add(key)
                found.append(Found(entry.path, name, st.st_size, stamp,
                                   label, bool(attrs & CLOUD_ONLY)))
    found.sort(key=lambda f: f.stamp, reverse=True)
    return found[:limit]


class RecentFiles:
    """最近のファイルを覚えておき、頼まれたら裏で調べ直す。"""

    STALE_S = 20.0

    def __init__(self, settings, on_update=None) -> None:  # noqa: ANN001
        # settings() → {"days", "onedrive", "desktop", "labels"}
        self._settings = settings
        self._on_update = on_update
        self._lock = threading.Lock()
        self._items: list[Found] = []
        self._at = 0.0
        self._busy = False

    def items(self) -> list[Found]:
        """覚えている結果。古ければ、裏で調べ直しを頼む。"""
        with self._lock:
            items = list(self._items)
            stale = time.monotonic() - self._at > self.STALE_S
        if stale:
            self.refresh()
        return items

    @property
    def ready(self) -> bool:
        return self._at > 0

    def refresh(self) -> None:
        with self._lock:
            if self._busy:
                return
            self._busy = True
        threading.Thread(target=self._run, name="recent-files",
                         daemon=True).start()

    def scan_now(self) -> list[Found]:
        """その場で調べる（試験と、最初の 1 回用）。"""
        self._run(notify=False)
        return self.items()

    def _run(self, notify: bool = True) -> None:
        try:
            s = self._settings()
            where = roots(onedrive=bool(s.get("onedrive", True)),
                          desktop=bool(s.get("desktop", True)),
                          labels=s.get("labels"))
            # 試験では、渡された場所だけを見る（空なら何も見ない）
            if s.get("roots") is not None:
                where = list(s["roots"])
            found = scan(where, days=int(s.get("days", 7)))
            with self._lock:
                changed = [f.path for f in found] != [f.path for f in
                                                      self._items]
                self._items = found
                self._at = time.monotonic()
            if changed and notify and self._on_update is not None:
                self._on_update()
        except Exception:
            log.exception("最近のファイルを調べられませんでした")
        finally:
            with self._lock:
                self._busy = False
