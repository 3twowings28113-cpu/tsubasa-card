"""main スレッドの繰り返し。tkinter の代わり。

★tkinter をやめた理由（ROADMAP 6.14）
  tkinter で使っていたのは「80ms ごとの繰り返し」と「ほかのスレッドから
  頼まれた仕事を main スレッドで動かす」の 2 つだけだった（帯の描画は
  win スレッドのメッセージループで行っている）。それなのに tkinter が
  あるせいで、Microsoft／python.org が配る**埋め込み用 Python**
  （tkinter が入っていない）をそのまま使えず、配布物に tkinter を
  別の版から足す手間と危うさがあった。標準ライブラリだけで書ける。

守ること
  ・頼まれた仕事で例外が出ても、繰り返しそのものは止めない
    （止まると帯が消えず、Ctrl+Space も効かなくなる。実際に起きた）
  ・待つときは Event で待つ。busy wait で CPU を使わない
"""

from __future__ import annotations

import heapq
import itertools
import logging
import threading
import time
from typing import Callable

log = logging.getLogger(__name__)


class MainLoop:
    """after(ms, fn) と quit() と mainloop() だけを持つ、小さな繰り返し。

    after はどのスレッドから呼んでもよい。fn は mainloop() を
    呼んだスレッドで動く。
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._wake = threading.Event()
        self._quit = threading.Event()
        self._timers: list[tuple[float, int, Callable[[], object]]] = []
        self._seq = itertools.count()

    def after(self, ms: int, fn: Callable[[], object]) -> None:
        due = time.monotonic() + max(0, ms) / 1000.0
        with self._lock:
            heapq.heappush(self._timers, (due, next(self._seq), fn))
        self._wake.set()

    def quit(self) -> None:
        self._quit.set()
        self._wake.set()

    @property
    def running(self) -> bool:
        return not self._quit.is_set()

    def mainloop(self) -> None:
        while not self._quit.is_set():
            now = time.monotonic()
            due: list[Callable[[], object]] = []
            with self._lock:
                while self._timers and self._timers[0][0] <= now:
                    due.append(heapq.heappop(self._timers)[2])
                wait = (self._timers[0][0] - now) if self._timers else 0.5
            for fn in due:
                if self._quit.is_set():
                    return
                try:
                    fn()
                except Exception:
                    log.exception("main スレッドの仕事で例外")
            if due:
                continue
            self._wake.wait(min(0.5, max(0.0, wait)))
            self._wake.clear()
