"""録音中に出る小さな帯。

Windows 11 の小さな通知のような、角丸・やわらかい影のカプセル。
tkinter では角丸も影も半透明もきれいに出せないので、
**半透明ウィンドウ（UpdateLayeredWindow）に GDI+ で描く**。
どちらも OS 標準の DLL なので、新しい依存は増えない。

守ること
  ・入力先のフォーカスを絶対に奪わない（WS_EX_NOACTIVATE）
  ・クリックは下のアプリへ素通りさせる（WS_EX_TRANSPARENT）
  ・描画も窓の操作も、メッセージループを持つスレッド（WinThread）で行う
"""

from __future__ import annotations

import ctypes
import logging
import math
import threading
import time
from ctypes import wintypes

from . import theme
from .i18n import t

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
gdiplus = ctypes.WinDLL("gdiplus", use_last_error=True)

# ---------------------------------------------------------------- Win32 定義

WS_POPUP = 0x80000000
WS_EX_LAYERED = 0x00080000
WS_EX_TRANSPARENT = 0x00000020
WS_EX_NOACTIVATE = 0x08000000
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_TOPMOST = 0x00000008
SW_HIDE, SW_SHOWNOACTIVATE = 0, 4
HWND_TOPMOST = -1
SWP_NOACTIVATE, SWP_SHOWWINDOW = 0x0010, 0x0040
SWP_NOSIZE, SWP_NOMOVE = 0x0001, 0x0002
ULW_ALPHA = 0x00000002
AC_SRC_OVER, AC_SRC_ALPHA = 0x00, 0x01
SPI_GETWORKAREA = 0x0030


POINT = wintypes.POINT


class SIZE(ctypes.Structure):
    _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_byte), ("BlendFlags", ctypes.c_byte),
                ("SourceConstantAlpha", ctypes.c_byte),
                ("AlphaFormat", ctypes.c_byte)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long),
                ("biHeight", ctypes.c_long), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD), ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", ctypes.c_long),
                ("biYPelsPerMeter", ctypes.c_long),
                ("biClrUsed", wintypes.DWORD), ("biClrImportant", wintypes.DWORD)]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER),
                ("bmiColors", wintypes.DWORD * 3)]


class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [("GdiplusVersion", ctypes.c_uint32),
                ("DebugEventCallback", ctypes.c_void_p),
                ("SuppressBackgroundThread", wintypes.BOOL),
                ("SuppressExternalCodecs", wintypes.BOOL)]


class PointF(ctypes.Structure):
    _fields_ = [("X", ctypes.c_float), ("Y", ctypes.c_float)]


class RectF(ctypes.Structure):
    _fields_ = [("X", ctypes.c_float), ("Y", ctypes.c_float),
                ("Width", ctypes.c_float), ("Height", ctypes.c_float)]


user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, ctypes.c_void_p]
user32.CreateWindowExW.restype = wintypes.HWND
user32.DestroyWindow.argtypes = [wintypes.HWND]
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int,
                                ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                wintypes.UINT]
user32.UpdateLayeredWindow.argtypes = [
    wintypes.HWND, wintypes.HDC, ctypes.POINTER(POINT), ctypes.POINTER(SIZE),
    wintypes.HDC, ctypes.POINTER(POINT), wintypes.DWORD,
    ctypes.POINTER(BLENDFUNCTION), wintypes.DWORD]
user32.UpdateLayeredWindow.restype = wintypes.BOOL
user32.GetDC.argtypes = [wintypes.HWND]
user32.GetDC.restype = wintypes.HDC
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
user32.SystemParametersInfoW.argtypes = [wintypes.UINT, wintypes.UINT,
                                         ctypes.c_void_p, wintypes.UINT]
user32.GetSystemMetrics.argtypes = [ctypes.c_int]
gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
gdi32.CreateCompatibleDC.restype = wintypes.HDC
gdi32.CreateDIBSection.argtypes = [wintypes.HDC, ctypes.POINTER(BITMAPINFO),
                                   wintypes.UINT,
                                   ctypes.POINTER(ctypes.c_void_p),
                                   wintypes.HANDLE, wintypes.DWORD]
gdi32.CreateDIBSection.restype = wintypes.HBITMAP
gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
gdi32.SelectObject.restype = wintypes.HGDIOBJ
gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.DeleteDC.argtypes = [wintypes.HDC]


class GUITHREADINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
                ("hwndCapture", wintypes.HWND),
                ("hwndMenuOwner", wintypes.HWND),
                ("hwndMoveSize", wintypes.HWND),
                ("hwndCaret", wintypes.HWND), ("rcCaret", RECT)]


user32.GetGUIThreadInfo.argtypes = [wintypes.DWORD,
                                    ctypes.POINTER(GUITHREADINFO)]
user32.GetGUIThreadInfo.restype = wintypes.BOOL
user32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(POINT)]
user32.ClientToScreen.restype = wintypes.BOOL
user32.GetCursorPos.argtypes = [ctypes.POINTER(POINT)]
user32.GetCursorPos.restype = wintypes.BOOL

for name, args, ret in (
    ("GdiplusStartup", [ctypes.POINTER(ctypes.c_void_p),
                        ctypes.POINTER(GdiplusStartupInput), ctypes.c_void_p],
     ctypes.c_int),
    ("GdipCreateFromHDC", [wintypes.HDC, ctypes.POINTER(ctypes.c_void_p)],
     ctypes.c_int),
    ("GdipDeleteGraphics", [ctypes.c_void_p], ctypes.c_int),
    ("GdipSetSmoothingMode", [ctypes.c_void_p, ctypes.c_int], ctypes.c_int),
    ("GdipSetTextRenderingHint", [ctypes.c_void_p, ctypes.c_int], ctypes.c_int),
    ("GdipSetPixelOffsetMode", [ctypes.c_void_p, ctypes.c_int], ctypes.c_int),
    ("GdipGraphicsClear", [ctypes.c_void_p, ctypes.c_uint32], ctypes.c_int),
    ("GdipCreatePath", [ctypes.c_int, ctypes.POINTER(ctypes.c_void_p)],
     ctypes.c_int),
    ("GdipDeletePath", [ctypes.c_void_p], ctypes.c_int),
    ("GdipAddPathArc", [ctypes.c_void_p] + [ctypes.c_float] * 6, ctypes.c_int),
    ("GdipClosePathFigure", [ctypes.c_void_p], ctypes.c_int),
    ("GdipAddPathCurve2", [ctypes.c_void_p, ctypes.POINTER(PointF),
                           ctypes.c_int, ctypes.c_float], ctypes.c_int),
    ("GdipFillPath", [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p],
     ctypes.c_int),
    ("GdipCreateSolidFill", [ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p)],
     ctypes.c_int),
    ("GdipDeleteBrush", [ctypes.c_void_p], ctypes.c_int),
    ("GdipFillEllipse", [ctypes.c_void_p, ctypes.c_void_p] +
     [ctypes.c_float] * 4, ctypes.c_int),
    ("GdipFillRectangle", [ctypes.c_void_p, ctypes.c_void_p] +
     [ctypes.c_float] * 4, ctypes.c_int),
    ("GdipCreateFontFamilyFromName", [wintypes.LPCWSTR, ctypes.c_void_p,
                                      ctypes.POINTER(ctypes.c_void_p)],
     ctypes.c_int),
    ("GdipDeleteFontFamily", [ctypes.c_void_p], ctypes.c_int),
    ("GdipCreateFont", [ctypes.c_void_p, ctypes.c_float, ctypes.c_int,
                        ctypes.c_int, ctypes.POINTER(ctypes.c_void_p)],
     ctypes.c_int),
    ("GdipDeleteFont", [ctypes.c_void_p], ctypes.c_int),
    ("GdipCreateStringFormat", [ctypes.c_int, wintypes.WORD,
                                ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
    ("GdipDeleteStringFormat", [ctypes.c_void_p], ctypes.c_int),
    ("GdipSetStringFormatAlign", [ctypes.c_void_p, ctypes.c_int], ctypes.c_int),
    ("GdipSetStringFormatLineAlign", [ctypes.c_void_p, ctypes.c_int],
     ctypes.c_int),
    ("GdipSetStringFormatTrimming", [ctypes.c_void_p, ctypes.c_int],
     ctypes.c_int),
    ("GdipSetStringFormatFlags", [ctypes.c_void_p, ctypes.c_int], ctypes.c_int),
    ("GdipDrawString", [ctypes.c_void_p, wintypes.LPCWSTR, ctypes.c_int,
                        ctypes.c_void_p, ctypes.POINTER(RectF),
                        ctypes.c_void_p, ctypes.c_void_p], ctypes.c_int),
    ("GdipMeasureString", [ctypes.c_void_p, wintypes.LPCWSTR, ctypes.c_int,
                           ctypes.c_void_p, ctypes.POINTER(RectF),
                           ctypes.c_void_p, ctypes.POINTER(RectF),
                           ctypes.POINTER(ctypes.c_int),
                           ctypes.POINTER(ctypes.c_int)], ctypes.c_int),
    ("GdipCreatePen1", [ctypes.c_uint, ctypes.c_float, ctypes.c_int,
                        ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
    ("GdipDeletePen", [ctypes.c_void_p], ctypes.c_int),
    ("GdipDrawPath", [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p],
     ctypes.c_int),
):
    fn = getattr(gdiplus, name)
    fn.argtypes = args
    fn.restype = ret


_gdiplus_token = ctypes.c_void_p()
_gdiplus_ready = False


def _start_gdiplus() -> bool:
    global _gdiplus_ready
    if _gdiplus_ready:
        return True
    startup = GdiplusStartupInput(1, None, False, False)
    if gdiplus.GdiplusStartup(ctypes.byref(_gdiplus_token),
                              ctypes.byref(startup), None) == 0:
        _gdiplus_ready = True
    else:
        log.error("GDI+ を始められませんでした")
    return _gdiplus_ready


def argb(hex_colour: str, alpha: float = 1.0) -> int:
    h = hex_colour.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return (int(max(0.0, min(1.0, alpha)) * 255) << 24) | (r << 16) | (g << 8) | b


# ---------------------------------------------------------------- 見た目

# ## 色
#
# 設定画面とアイコンにそろえる。**紺 #242460** を土台に、
# 録音中だけ **赤 #E0483A**。紫〜青のグラデーション、光る効果、
# 絵文字は使わない（どのアプリにもある「AIっぽい」見た目になるので）。
PALETTE = {
    "dark": {
        "bg": "#1c1c33",        # 紺を暗く寝かせた地色
        "edge": "#343457",
        "fg": "#f3f3f8",
        "dim": "#b7b7cb",
        "faint": "#9191a9",
        "wave": "#4a4a6e",      # 声がないときの波
        "chip": "#2a2a48",      # 状態の札の地
        "brand": "#8c8cd8",     # 紺を明るくしたもの（暗い地で読める）
    },
    "light": {
        "bg": "#ffffff",
        "edge": "#dcdee8",
        "fg": "#1b1b2e",
        "dim": "#55556e",
        "faint": "#8585a0",
        "wave": "#c7cad8",
        "chip": "#eeeff6",
        "brand": "#242460",     # 設定画面と同じ紺
    },
}

# 状態の色。**色と形の両方**で分かるようにする（色だけだと見分けにくい）
STATE_COLOUR = {
    "recording": {"dark": "#e0483a", "light": "#cf3d2d"},
    "transcribing": {"dark": "#8c8cd8", "light": "#242460"},
    "done": {"dark": "#6ccb5f", "light": "#1a7f37"},
    "idle": {"dark": "#9191a9", "light": "#8585a0"},
}
# 録音中の色は選べる（2026-10-11 の頼み：赤だけでなく色を選びたい）。
# どれも単色。ライト／ダークそれぞれで、地の上で読める明るさにしてある。
# 形（丸・四角・チェック）でも状態が分かるので、色を変えても迷わない。
RECORD_COLOURS = {
    "red": {"dark": "#e0483a", "light": "#cf3d2d"},
    "orange": {"dark": "#f0883e", "light": "#c25e0a"},
    "green": {"dark": "#4cc38a", "light": "#1a7f4b"},
    "teal": {"dark": "#2fb6c1", "light": "#0b7c86"},
    "blue": {"dark": "#4c9aff", "light": "#1f63c6"},
    "navy": {"dark": "#8c8cd8", "light": "#242460"},
    "pink": {"dark": "#f06aa0", "light": "#c2306e"},
    "gray": {"dark": "#b4b4c4", "light": "#55556e"},
}


def record_colour(name: str, mode: str) -> str:
    """録音中の色。"accent" は Windows のアクセント色に合わせる。"""
    if name == "accent":
        colour = theme.accent_color()
        return colour if mode == "light" else _lighter(colour)
    return RECORD_COLOURS.get(name, RECORD_COLOURS["red"])[mode]


def _lighter(hex_colour: str, amount: float = 0.35) -> str:
    h = hex_colour.lstrip("#")
    rgb = [int(h[i:i + 2], 16) for i in (0, 2, 4)]
    return "#%02x%02x%02x" % tuple(round(c + (255 - c) * amount)
                                   for c in rgb)


# 状態の形。丸＝聞いている／四角＝文字にしている／チェック＝終わった
STATE_SHAPE = {
    "recording": "dot",
    "transcribing": "square",
    "done": "check",
    "idle": "dot",
}

FONTS = ("Segoe UI Variable Text", "Segoe UI", "Yu Gothic UI", "Meiryo UI")

# 5 つの案。設定の「表示」で選べる。
DESIGNS = ("pill", "wave", "card", "dot", "caption")
# 既定はピル。理由は _render_pill の説明を参照
DESIGN_DEFAULT = "pill"

# 大きさの倍率（シニア向け・遠距離視認性向上のため xlarge 1.48倍を追加）
SCALES = {"small": 0.86, "medium": 1.0, "large": 1.22, "xlarge": 1.48}

SHADOW = 14                 # 影のための余白（窓はこのぶん大きい）
SPI_GETCLIENTAREAANIMATION = 0x1042
MONITOR_DEFAULTTONEAREST = 2

user32.MonitorFromWindow.argtypes = [wintypes.HWND, wintypes.DWORD]
user32.MonitorFromWindow.restype = wintypes.HANDLE
# 拡大率を知る関数（Windows 10 1607 から）。無い Windows では使わない
for _name, _args in (("GetDpiForWindow", [wintypes.HWND]),
                     ("GetDpiForSystem", [])):
    if hasattr(user32, _name):
        getattr(user32, _name).argtypes = _args
        getattr(user32, _name).restype = wintypes.UINT
user32.MonitorFromPoint.argtypes = [POINT, wintypes.DWORD]
user32.MonitorFromPoint.restype = wintypes.HANDLE


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT),
                ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]


user32.GetMonitorInfoW.argtypes = [wintypes.HANDLE,
                                   ctypes.POINTER(MONITORINFO)]
user32.GetMonitorInfoW.restype = wintypes.BOOL


def animations_on() -> bool:
    """Windows の「アニメーションを表示する」が入っているか。

    切ってある人（「視覚効果を減らす」）の前では動かさない。
    """
    value = wintypes.BOOL(True)
    if not user32.SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0,
                                        ctypes.byref(value), 0):
        return True
    return bool(value.value)


class Overlay:
    """半透明ウィンドウに GDI+ で描く、録音中の帯。

    状態は別スレッドから `set_state` で入れ、描画は `tick()` を
    呼んだスレッドで行う。`tick()` は必ずメッセージループを持つ
    スレッドから呼ぶこと。

    守ること（ここを破ると利用者の作業を止めてしまう）
      ・入力先のフォーカスを奪わない（WS_EX_NOACTIVATE）
      ・クリックは下のアプリへ素通りさせる（WS_EX_TRANSPARENT）
      ・重い処理をしない（描くのは 50ms ごと、変化がなければ描かない）
    """

    def __init__(self) -> None:
        self.enabled = True
        self.position = "bottom"
        self.size_name = "medium"
        self.design = DESIGN_DEFAULT
        self.margin = 16
        self.dark = True
        self.hint_text = ""
        self.show_hint = True
        # 話している言葉（まだ入力していない分）を帯に出すか
        self.show_text = True

        self._hwnd = 0
        self._lock = threading.Lock()
        self._state = "idle"
        self._elapsed = 0.0
        self._level = 0.0
        self._pending = ""
        self._message = ""
        self._target = 0
        self._visible = False
        self._dirty = True
        self._wave: list[float] = []
        self._last_draw = 0.0
        self._font_family = None
        self._width = 0
        # 現れる・消えるときの短い動き
        self._fade = 0.0
        self._fade_at = 0.0
        self._animate = True
        self._cursor_anchor: tuple[int, int] | None = None

    # ------------------------------------------------------------ 設定

    def configure(self, *, theme_name: str, position: str, size: str,
                  margin_px: int, enabled: bool,
                  design: str = DESIGN_DEFAULT,
                  hint_text: str = "", show_hint: bool = True,
                  show_text: bool = True,
                  record_colour: str = "red") -> None:
        with self._lock:
            self.record_colour = record_colour
            self.dark = theme.resolve(theme_name) == "dark"
            self.position = position if position in (
                "bottom", "top", "bottom-right", "cursor") else "bottom"
            self.size_name = size if size in SCALES else "medium"
            self.design = design if design in DESIGNS else DESIGN_DEFAULT
            self.margin = max(0, margin_px)
            self.enabled = bool(enabled)
            self.hint_text = hint_text
            self.show_hint = bool(show_hint)
            self.show_text = bool(show_text)
            self._animate = animations_on()
            self._dirty = True

    # ------------------------------------------------------------ 状態

    def set_target(self, hwnd: int) -> None:
        """いま入力しているウィンドウ。そのモニターに帯を出す。"""
        with self._lock:
            if hwnd != self._target:
                self._target = int(hwnd or 0)
                self._dirty = True

    def set_state(self, state: str, *, elapsed: float = 0.0,
                  level: float = 0.0, pending: str = "",
                  message: str = "") -> None:
        """別スレッドから呼んでよい。実際の描画は tick() で行う。"""
        wake = False
        with self._lock:
            wake = self._state == "hidden" and state != "hidden"
            if (state, round(elapsed), pending, message) != (
                    self._state, round(self._elapsed), self._pending,
                    self._message):
                self._dirty = True
            if state != self._state:
                if state != "hidden":
                    self._fade_at = time.monotonic()
                if state in ("recording", "hidden"):
                    self._cursor_anchor = None
            self._state = state
            self._elapsed = elapsed
            self._level = level
            self._pending = pending
            self._message = message
        if wake and self.on_wake is not None:
            # 隠れていた帯を出す。ゆっくり回っていたタイマーを起こす
            try:
                self.on_wake()
            except Exception:
                log.debug("帯を起こせませんでした", exc_info=True)

    def idle(self) -> bool:
        """隠れていて、消えていく途中でもない（タイマーを遅くしてよい）。"""
        with self._lock:
            return self._state == "hidden" and not self._visible

    def hide(self) -> None:
        with self._lock:
            if self._state != "hidden":
                self._state = "hidden"
                self._fade_at = time.monotonic()
                self._dirty = True
            self._cursor_anchor = None

    # ------------------------------------------------------------ 窓

    # 隠れていた帯を出すときに呼ぶ（WinThread がタイマーを速くする）
    on_wake = None

    def create(self, hinstance: int) -> None:
        """メッセージループを持つスレッドから呼ぶ。"""
        if self._hwnd or not _start_gdiplus():
            return
        self._hwnd = user32.CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE
            | WS_EX_TOOLWINDOW | WS_EX_TOPMOST,
            "KoeTypeHiddenWindow", "koe-type overlay", WS_POPUP,
            0, 0, 10, 10, None, None, hinstance, None)
        if not self._hwnd:
            log.error("帯のウィンドウを作れませんでした err=%s",
                      ctypes.get_last_error())
            return
        for name in FONTS:
            family = ctypes.c_void_p()
            if gdiplus.GdipCreateFontFamilyFromName(
                    name, None, ctypes.byref(family)) == 0:
                self._font_family = family
                log.debug("帯のフォント: %s", name)
                break
        self._animate = animations_on()
        log.info("録音中の帯を用意しました（%s / 動き=%s）",
                 self.design, "あり" if self._animate else "なし")

    def destroy(self) -> None:
        if self._font_family:
            gdiplus.GdipDeleteFontFamily(self._font_family)
            self._font_family = None
        if self._hwnd:
            user32.DestroyWindow(self._hwnd)
            self._hwnd = 0

    # ------------------------------------------------------------ 描画

    FADE_IN = 0.14
    FADE_OUT = 0.11

    def _fade_now(self, state: str) -> float:
        """いまの濃さ（0.0〜1.0）。動きを切ってある人には 0 か 1 だけ。"""
        if not self._animate:
            return 0.0 if state == "hidden" else 1.0
        span = self.FADE_OUT if state == "hidden" else self.FADE_IN
        passed = time.monotonic() - self._fade_at
        ratio = 1.0 if span <= 0 else max(0.0, min(1.0, passed / span))
        # ゆるく止まる曲線（出入りを柔らかくする）
        eased = 1.0 - (1.0 - ratio) ** 2
        return (1.0 - eased) if state == "hidden" else eased

    def tick(self) -> None:
        """メッセージループを持つスレッドから 50ms ごとに呼ぶ。"""
        if not self._hwnd:
            return
        with self._lock:
            state = self._state
            enabled = self.enabled
        if not enabled:
            if self._visible:
                user32.ShowWindow(self._hwnd, SW_HIDE)
                self._visible = False
            return

        self._fade = self._fade_now(state)
        if state == "hidden" and self._fade <= 0.01:
            if self._visible:
                user32.ShowWindow(self._hwnd, SW_HIDE)
                self._visible = False
            return

        now = time.monotonic()
        animating = state == "recording" or 0.01 < self._fade < 0.99
        if not self._dirty and not animating and now - self._last_draw < 1.0:
            return
        self._last_draw = now
        try:
            self._draw()
        except Exception:
            log.exception("帯の描画で例外")

    def _draw(self) -> None:
        made = self._render()
        if made is None:
            return
        w, h, dc, graphics, bitmap, old, bits = made
        try:
            self._present(dc, w, h)
        finally:
            self._release(dc, graphics, bitmap, old)

    def snapshot(self) -> tuple[int, int, bytes] | None:
        """描いた中身をそのまま RGBA で返す（見た目の確認用）。"""
        made = self._render()
        if made is None:
            return None
        w, h, dc, graphics, bitmap, old, bits = made
        try:
            raw = ctypes.string_at(bits, w * h * 4)
            out = bytearray(w * h * 4)
            for i in range(w * h):
                b, g, r, a = raw[i * 4:i * 4 + 4]
                # GDI+ は乗算済みアルファで描くので、ふつうの形に戻す
                if a:
                    out[i * 4:i * 4 + 4] = bytes((
                        min(255, r * 255 // a), min(255, g * 255 // a),
                        min(255, b * 255 // a), a))
            return w, h, bytes(out)
        finally:
            self._release(dc, graphics, bitmap, old)

    # ------------------------------------------------------------ 波

    def _pump_wave(self, count: int, level: float, moving: bool) -> None:
        """声の大きさに合わせて、波をなめらかに動かす。

        値を直接入れずに、**少しずつ近づける**ことで角が立たないようにする。
        中央をいちばん高くし、外側へ低くしていく（声らしく見える）。
        """
        if len(self._wave) != count:
            self._wave = [0.18] * count
        now = time.monotonic()
        for i in range(count):
            if not moving:
                target = 0.14
            else:
                # 中央ほど大きく（端は落とす）
                centre = 1.0 - abs((i / max(1, count - 1)) - 0.5) * 1.3
                # ばらつき。2 つの波を重ねて、規則正しい櫛に見えないようにする
                phase = now * 5.0
                wobble = abs(math.sin(i * 1.73 + phase) * 0.6
                             + math.sin(i * 0.47 - phase * 0.8) * 0.4)
                target = 0.12 + (level * (0.30 + 0.90 * wobble)
                                  * max(0.20, centre) * 1.5)
            target = max(0.08, min(1.0, target))
            self._wave[i] += (target - self._wave[i]) * 0.4

    # ------------------------------------------------------------ 組み立て

    def _labels(self, state: str, elapsed: float, message: str) -> tuple:
        """(状態の名前, 時間, お知らせ) を返す。"""
        if message:
            return ("", "", message)
        if state == "recording":
            secs = int(elapsed)
            return (t("overlay.listening"), f"{secs // 60}:{secs % 60:02d}",
                    "")
        if state == "transcribing":
            # 利用者の要望：
            # 「文字にしています」と言われると「急に喋っちゃいけないのかな？」と
            # 不安になり、途中で勝手に挟まるのも不快なため、表示しない。
            return ("", "", "")
        if state == "done":
            return (t("overlay.stopped"), "", "")
        return ("", "", "")

    def _render(self):  # noqa: ANN202
        with self._lock:
            state, elapsed = self._state, self._elapsed
            level, pending, message = self._level, self._pending, self._message
            dark, size_name, design = self.dark, self.size_name, self.design
            hint = self.hint_text if self.show_hint else ""
            if not self.show_text:
                # 利用者の頼み：話している言葉を帯に出さない（状態だけ）
                pending = ""
            self._dirty = False
        if state == "hidden":
            # 消えていく途中。最後の見た目をそのまま薄くする
            state = "done"

        mode = "dark" if dark else "light"
        colours = PALETTE[mode]
        accent = STATE_COLOUR.get(state, STATE_COLOUR["idle"])[mode]
        if state == "recording":
            accent = record_colour(getattr(self, "record_colour", "red"),
                                   mode)
        # 大きさ × モニターの拡大率。拡大率を掛けないと、200% の画面では
        # Windows が 1 倍の絵を引き伸ばし、文字も波もぼやけていた
        # （この PC は 200%。2026-10-05 に気づいた）。
        scale = SCALES.get(size_name, 1.0) * self._dpi_factor()
        status, clock, note = self._labels(state, elapsed, message)
        if note:
            status, pending = note, ""
            hint = ""
        if state != "recording":
            # 「Ctrl+Space で止める」は、録音していない時には意味がない
            hint = ""

        if design == "wave":
            return self._render_wave(state, mode, colours, accent, scale,
                                     status, clock, pending, hint, level)
        if design == "card":
            return self._render_card(state, mode, colours, accent, scale,
                                     status, clock, pending, hint, level)
        if design == "dot":
            return self._render_dot(state, mode, colours, accent, scale,
                                    status, clock, pending, hint, level)
        if design == "caption":
            return self._render_caption(state, mode, colours, accent, scale,
                                        status, clock, pending, hint, level)
        return self._render_pill(state, mode, colours, accent, scale,
                                 status, clock, pending, hint, level)

    # ---------------------------------------------------- 案1 ピル

    def _render_pill(self, state, mode, colours, accent, scale,  # noqa: ANN001
                     status, clock, pending, hint, level):  # noqa: ANN201
        """案1「ピル」（既定）：縦に短く、横に伸びる細いカプセル 1 本。

        左に状態の印と波、中央に状態の名前と未確定の文字、右に時間。
        ★既定をカードからこれに替えた（2026-10-05）。カードは高さが
        170px ほどあり、チャットの入力欄の上に重なって、文字が入って
        いるのか見えなくなった。利用者からも「Handy のように縦に短く
        横に出る形がよい」と言われた。お知らせのときはさらに低くする。
        """
        quiet = state == "done"
        height = round((32 if quiet else 38) * scale)
        pad = round(14 * scale)
        gap = round(9 * scale)
        f_status = 12.5 * scale
        f_pending = 13.5 * scale
        f_clock = 12.0 * scale
        bars = 0 if quiet else 9
        bar_w = max(2.0, 2.6 * scale)
        bar_gap = max(1.5, 2.0 * scale)
        wave_w = max(0.0, bars * bar_w + (bars - 1) * bar_gap)
        mark = round(9 * scale)

        self._pump_wave(bars, level, state == "recording")

        probe = self._measure_setup()
        if probe is None:
            return None
        dc, graphics, bitmap, old, _bits = probe
        try:
            status_w = self._measure(graphics, status, self._font(f_status))
            clock_w = self._measure(graphics, clock, self._font(f_clock)) \
                if clock else 0.0
            f_hint = 11.0 * scale
            hint_w = self._measure(graphics, hint, self._font(f_hint)) \
                if (hint and state == "recording") else 0.0
            limit = round(420 * scale)
            pending, pending_w = self._fit_pending(graphics, pending,
                                                   f_pending, limit)
        finally:
            self._release(dc, graphics, bitmap, old)

        width = pad + mark + gap + round(status_w)
        if wave_w:
            width += wave_w + gap
        if pending:
            width += gap + round(pending_w)
        if hint_w:
            width += gap + round(hint_w)
        if clock:
            width += gap + round(clock_w)
        width += pad
        width = int(round(max(width, (120 if quiet else 200) * scale)))

        made = self._surface(width + SHADOW * 2, height + SHADOW * 2)
        if made is None:
            return None
        dc, graphics, bitmap, old, bits = made
        ok = False
        try:
            self._begin(graphics)
            radius = height / 2
            self._shell(graphics, width, height, radius, colours, accent,
                        state)
            x = SHADOW + pad
            mid = SHADOW + height / 2
            self._state_mark(graphics, state, x, mid, mark, accent)
            x += mark + gap
            if wave_w:
                self._wave_bars(graphics, x, mid, bar_w, bar_gap,
                                height * 0.5, state, accent, colours)
                x += wave_w + gap
            if status:
                self._text(graphics, status, self._font(f_status),
                           x, SHADOW, status_w + 2, height,
                           argb(colours["fg"], 1.0))
                x += status_w + gap
            if pending:
                self._text(graphics, pending, self._font(f_pending),
                           x, SHADOW, pending_w + 2, height,
                           argb(colours["dim"], 1.0))
                x += pending_w + gap
            if hint_w:
                self._text(graphics, hint, self._font(f_hint),
                           x, SHADOW, hint_w + 2, height,
                           argb(colours["faint"], 0.9))
                x += hint_w + gap
            if clock:
                self._text(graphics, clock, self._font(f_clock),
                           SHADOW + width - pad - clock_w, SHADOW,
                           clock_w + 2, height, argb(colours["faint"], 1.0))
            ok = True
        finally:
            if not ok:
                self._release(dc, graphics, bitmap, old)
        return (width + SHADOW * 2, height + SHADOW * 2, dc, graphics,
                bitmap, old, bits)

    # ---------------------------------------------------- 案2 波のバー

    def _render_wave(self, state, mode, colours, accent, scale,  # noqa: ANN001
                     status, clock, pending, hint, level):  # noqa: ANN201
        """案2「波のバー」：横いっぱいの、つながった声の波が主役。

        ★前の形はカードとほぼ同じ（同じ箱・同じ縦棒・同じヒントの行）で、
        利用者に「違いがよく分からない」と言われた（2026-10-05）。
        そこで、カードとは**見て分かるほど**変えた。

          ・縦棒ではなく、横いっぱいにつながった**なめらかな波の面**
          ・高さを抑えた横長の帯。角の丸みも小さめ
          ・録音中でも枠を赤くしない（赤いのは波そのもの）
          ・文字は波の下に 1 行だけ。状態・話している言葉・時間・ヒント
        """
        width = int(round(720 * scale))
        pad = round(14 * scale)
        f_status = 12.5 * scale
        f_pending = 14.0 * scale
        f_small = 11.0 * scale
        mark = round(9 * scale)
        # 声を拾っていないときは波を細い線にして、帯ごと低くする
        # （平らな線のために高さを取ると、間が抜けて見えた）。
        wave_h = round((46 if state == "recording" else 14) * scale)
        row_h = round(22 * scale)
        gap = round(10 * scale)
        if state == "done":
            hint = ""
        height = int(round(pad * 0.6 + wave_h + row_h + pad * 0.6))
        inner = width - pad * 2

        points = 56
        self._pump_wave(points, level, state == "recording")

        probe = self._measure_setup()
        if probe is None:
            return None
        dc, graphics, bitmap, old, _bits = probe
        try:
            status_w = self._measure(graphics, status, self._font(f_status))
            clock_w = (self._measure(graphics, clock, self._font(f_small))
                       if clock else 0.0)
            hint_w = (self._measure(graphics, hint, self._font(f_small))
                      if hint else 0.0)
            room = (inner - mark - gap - status_w - gap
                    - (clock_w + gap if clock else 0)
                    - (hint_w + gap * 2 if hint else 0))
            pending, pending_w = self._fit_pending(graphics, pending,
                                                   f_pending, max(60, room))
        finally:
            self._release(dc, graphics, bitmap, old)

        made = self._surface(width + SHADOW * 2, height + SHADOW * 2)
        if made is None:
            return None
        dc, graphics, bitmap, old, bits = made
        ok = False
        try:
            self._begin(graphics)
            self._flat_shell(graphics, width, height, round(10 * scale),
                             colours)
            top = SHADOW + pad * 0.6
            self._wave_area(graphics, SHADOW + pad, top + wave_h / 2,
                            inner, wave_h, state, accent, colours)

            y = top + wave_h
            x = SHADOW + pad
            self._state_mark(graphics, state, x, y + row_h / 2, mark, accent)
            x += mark + gap
            if status:
                self._text(graphics, status, self._font(f_status), x, y,
                           status_w + 2, row_h, argb(accent, 1.0))
                x += status_w + gap
            if clock:
                self._text(graphics, clock, self._font(f_small), x, y,
                           clock_w + 2, row_h, argb(colours["faint"], 1.0))
                x += clock_w + gap
            if pending:
                self._text(graphics, pending, self._font(f_pending), x, y,
                           pending_w + 2, row_h, argb(colours["fg"], 1.0))
            if hint:
                self._text(graphics, hint, self._font(f_small),
                           SHADOW + width - pad - hint_w, y, hint_w + 2,
                           row_h, argb(colours["faint"], 1.0))
            ok = True
        finally:
            if not ok:
                self._release(dc, graphics, bitmap, old)
        return (width + SHADOW * 2, height + SHADOW * 2, dc, graphics,
                bitmap, old, bits)

    def _flat_shell(self, graphics, width, height, radius,  # noqa: ANN001
                    colours) -> None:
        """波のバーの地。影・地色・細い枠だけ。状態の色の枠は付けない。

        カードと同じ赤い枠にすると、また見分けがつかなくなる。
        録音中であることは、赤い波がいちばん大きく知らせている。
        """
        for i in range(5, 0, -1):
            spread = i * 1.6
            self._rounded(graphics, SHADOW - spread, SHADOW - spread + 2.0,
                          width + spread * 2, height + spread * 2,
                          radius + spread, argb("#000000", 0.030))
        self._rounded(graphics, SHADOW, SHADOW, width, height, radius,
                      argb(colours["bg"], 0.985))
        self._rounded_outline(graphics, SHADOW, SHADOW, width, height,
                              radius, argb(colours["edge"], 0.95), 1.0)

    def _wave_area(self, graphics, x, mid, span, full,  # noqa: ANN001
                   state, accent, colours) -> None:
        """つながった波の面。上下に対称で、2 枚を重ねて奥行きを出す。

        外側は薄く、内側は濃く。光る効果やグラデーションは使わない
        （決まり：紫〜青のグラデーション・光る効果は使わない）。
        声がないときは細い線になる。線が動かないことで
        「マイクが拾えていない」が分かる。
        """
        recording = state == "recording"
        colour = (accent if state in ("recording", "transcribing")
                  else colours["wave"])
        values = self._wave or [0.1]
        count = len(values)
        step = span / max(1, count - 1)
        for scale, alpha in ((1.0, 0.30 if recording else 0.25),
                             (0.55, 1.0 if recording else 0.6)):
            halves = []
            for i, value in enumerate(values):
                amp = value if recording else 0.06
                # 両端に向かって細くする。端で太いまま切れると
                # 「波」ではなく「帯」に見える。
                taper = math.sin(math.pi * i / max(1, count - 1)) ** 0.5
                halves.append(max(0.8, full * amp * scale / 2 * taper))
            top = [PointF(x + i * step, mid - h)
                   for i, h in enumerate(halves)]
            bottom = [PointF(x + i * step, mid + h)
                      for i, h in reversed(list(enumerate(halves)))]
            self._fill_curve(graphics, top, bottom, argb(colour, alpha))

    def _fill_curve(self, graphics, top, bottom,  # noqa: ANN001
                    colour) -> None:
        """上の縁と下の縁をなめらかな曲線でつないで塗る。"""
        path = ctypes.c_void_p()
        if gdiplus.GdipCreatePath(0, ctypes.byref(path)) != 0:
            return
        brush = ctypes.c_void_p()
        try:
            for edge in (top, bottom):
                arr = (PointF * len(edge))(*edge)
                gdiplus.GdipAddPathCurve2(path, arr, len(edge),
                                          ctypes.c_float(0.5))
            gdiplus.GdipClosePathFigure(path)
            gdiplus.GdipCreateSolidFill(colour, ctypes.byref(brush))
            gdiplus.GdipFillPath(graphics, brush, path)
        finally:
            if brush:
                gdiplus.GdipDeleteBrush(brush)
            gdiplus.GdipDeletePath(path)

    # ---------------------------------------------------- 案3 カード

    def _render_card(self, state, mode, colours, accent, scale,  # noqa: ANN001
                     status, clock, pending, hint, level):  # noqa: ANN201
        """案3「カード」：話している言葉をいちばん大きく見せる。

        上に状態の札と時間、真ん中に未確定の文字（2 行まで・大きめ）、
        下に細い波と操作のヒント。読みやすさを最優先した案。
        """
        width = int(round(600 * scale))
        pad = round(20 * scale)
        f_status = 12.5 * scale
        f_pending = 17.0 * scale
        f_clock = 13.0 * scale
        f_hint = 11.5 * scale
        mark = round(10 * scale)
        chip_h = round(28 * scale)
        line_h = round(26 * scale)
        wave_h = round(22 * scale)
        hint_h = round(16 * scale) if hint else 0

        bars = 34
        inner = width - pad * 2
        bar_w = max(2.0, 3.0 * scale)
        bar_gap = max(1.0, (inner - bars * bar_w) / (bars - 1))

        self._pump_wave(bars, level, state == "recording")

        probe = self._measure_setup()
        if probe is None:
            return None
        dc, graphics, bitmap, old, _bits = probe
        try:
            status_w = self._measure(graphics, status, self._font(f_status))
            clock_w = self._measure(graphics, clock, self._font(f_clock)) \
                if clock else 0.0
            lines = self._wrap(graphics, pending, f_pending, inner, 2)
        finally:
            self._release(dc, graphics, bitmap, old)

        # 「止まりました」などのお知らせだけのときは、波もヒントも
        # 出さずに小さくする。短い時間しか出ないので、目障りにしない。
        quiet = state == "done"
        if quiet:
            hint, hint_h = "", 0
        chip_w = (round(12 * scale) + mark + round(8 * scale)
                  + round(status_w) + round(14 * scale))
        if quiet:
            width = int(round(min(width, chip_w + pad * 2
                                  + round(60 * scale) + clock_w)))
            inner = width - pad * 2
            bar_gap = max(1.0, (inner - bars * bar_w) / (bars - 1))
        height = pad + chip_h
        if lines:
            height += round(10 * scale) + line_h * len(lines)
        if not quiet:
            height += round(14 * scale) + wave_h
        if hint:
            height += round(8 * scale) + hint_h
        height = int(round(height + pad))

        made = self._surface(width + SHADOW * 2, height + SHADOW * 2)
        if made is None:
            return None
        dc, graphics, bitmap, old, bits = made
        ok = False
        try:
            self._begin(graphics)
            self._shell(graphics, width, height, round(18 * scale), colours,
                        accent, state)
            y = SHADOW + pad
            # 状態の札（色・形・言葉の 3 つで分かるようにする）
            self._rounded(graphics, SHADOW + pad, y, chip_w, chip_h,
                          chip_h / 2, argb(accent, 0.13))
            self._state_mark(graphics, state,
                             SHADOW + pad + round(12 * scale),
                             y + chip_h / 2, mark, accent)
            if status:
                self._text(graphics, status, self._font(f_status),
                           SHADOW + pad + round(12 * scale) + mark
                           + round(8 * scale), y, status_w + 4, chip_h,
                           argb(accent, 1.0))
            if clock:
                self._text(graphics, clock, self._font(f_clock),
                           SHADOW + width - pad - clock_w, y,
                           clock_w + 2, chip_h, argb(colours["faint"], 1.0))
            y += chip_h

            # 話している言葉（まだ確定していないので、2 行目は少し薄く）
            if lines:
                y += round(10 * scale)
                for i, line in enumerate(lines):
                    self._text(graphics, line, self._font(f_pending),
                               SHADOW + pad, y, inner, line_h,
                               argb(colours["fg"] if i == len(lines) - 1
                                    else colours["dim"], 1.0))
                    y += line_h

            # 細い波（マイクが拾えているかが分かる）
            if not quiet:
                y += round(14 * scale)
                self._wave_strip(graphics, SHADOW + pad, y + wave_h / 2,
                                 bar_w, bar_gap, wave_h, inner, state,
                                 accent, colours)
                y += wave_h
            if hint:
                y += round(8 * scale)
                self._text(graphics, hint, self._font(f_hint),
                           SHADOW + pad, y, inner, hint_h,
                           argb(colours["faint"], 1.0))
            ok = True
        finally:
            if not ok:
                self._release(dc, graphics, bitmap, old)
        return (width + SHADOW * 2, height + SHADOW * 2, dc, graphics,
                bitmap, old, bits)

    # ---------------------------------------------------- 案4 コンパクト

    def _render_dot(self, state, mode, colours, accent, scale,  # noqa: ANN001
                    status, clock, pending, hint, level):  # noqa: ANN201
        """案4「コンパクト」：画面の邪魔にならない極小インジケーター。

        丸いLEDと小さな5本の波、経過時間だけをミニマルに表示する。
        文字入力欄や視界を遮られたくない利用者向け。
        """
        quiet = state == "done"
        height = round((24 if quiet else 28) * scale)
        pad = round(10 * scale)
        gap = round(7 * scale)
        f_text = 11.0 * scale
        mark = round(8 * scale)
        bars = 0 if quiet else 5
        bar_w = max(1.8, 2.2 * scale)
        bar_gap = max(1.2, 1.6 * scale)
        wave_w = max(0.0, bars * bar_w + (bars - 1) * bar_gap)

        self._pump_wave(bars, level, state == "recording")

        disp = clock if clock else status
        probe = self._measure_setup()
        if probe is None:
            return None
        dc, graphics, bitmap, old, _bits = probe
        try:
            disp_w = self._measure(graphics, disp, self._font(f_text))
        finally:
            self._release(dc, graphics, bitmap, old)

        width = int(round(pad + mark + gap + disp_w + (gap + wave_w if wave_w else 0) + pad))
        height = int(round(height))

        made = self._surface(width + SHADOW * 2, height + SHADOW * 2)
        if made is None:
            return None
        dc, graphics, bitmap, old, bits = made
        ok = False
        try:
            self._begin(graphics)
            self._shell(graphics, width, height, height / 2, colours,
                        accent, state)
            x = SHADOW + pad
            mid_y = SHADOW + height / 2
            self._state_mark(graphics, state, x, mid_y, mark, accent)
            x += mark + gap
            if disp:
                col = accent if state == "recording" else colours["fg"]
                self._text(graphics, disp, self._font(f_text), x,
                           SHADOW + (height - f_text * 1.3) / 2,
                           disp_w + 2, f_text * 1.5, argb(col, 1.0))
                x += round(disp_w) + gap
            if wave_w:
                self._wave_strip(graphics, x, mid_y, bar_w, bar_gap,
                                 round(12 * scale), wave_w, state,
                                 accent, colours)
            ok = True
        finally:
            if not ok:
                self._release(dc, graphics, bitmap, old)
        return (width + SHADOW * 2, height + SHADOW * 2, dc, graphics,
                bitmap, old, bits)

    # ---------------------------------------------------- 案5 字幕テロップ

    def _render_caption(self, state, mode, colours, accent, scale,  # noqa: ANN001
                        status, clock, pending, hint, level):  # noqa: ANN201
        """案5「字幕テロップ」：動画の字幕のように横長で文字が見やすい形。

        画面下部にすっきり伸び、話した言葉が大きく横に並ぶ。
        動画配信やプレゼン、文章作成で文字の流れを確認したいときに最適。
        """
        quiet = state == "done"
        height = round((36 if quiet else 44) * scale)
        pad = round(16 * scale)
        gap = round(10 * scale)
        f_status = 12.0 * scale
        f_pending = 15.0 * scale
        mark = round(9 * scale)
        bars = 0 if quiet else 12
        bar_w = max(2.0, 2.5 * scale)
        bar_gap = max(1.5, 2.0 * scale)
        wave_w = max(0.0, bars * bar_w + (bars - 1) * bar_gap)

        self._pump_wave(bars, level, state == "recording")

        probe = self._measure_setup()
        if probe is None:
            return None
        dc, graphics, bitmap, old, _bits = probe
        try:
            status_w = self._measure(graphics, status, self._font(f_status))
            clock_w = self._measure(graphics, clock, self._font(f_status)) \
                if clock else 0.0
            limit = round(560 * scale)
            pending, pending_w = self._fit_pending(graphics, pending,
                                                   f_pending, limit)
        finally:
            self._release(dc, graphics, bitmap, old)

        width = pad + mark + gap + round(status_w)
        if wave_w:
            width += gap + wave_w
        if pending:
            width += gap * 2 + round(pending_w)
        if clock_w:
            width += gap + round(clock_w)
        width += pad
        # 最低幅を確保して安定した字幕感を出す
        width = int(round(max(round(340 * scale), width)))
        height = int(round(height))

        made = self._surface(width + SHADOW * 2, height + SHADOW * 2)
        if made is None:
            return None
        dc, graphics, bitmap, old, bits = made
        ok = False
        try:
            self._begin(graphics)
            self._shell(graphics, width, height, round(12 * scale), colours,
                        accent, state)
            x = SHADOW + pad
            mid_y = SHADOW + height / 2
            self._state_mark(graphics, state, x, mid_y, mark, accent)
            x += mark + gap
            if status:
                self._text(graphics, status, self._font(f_status), x,
                           SHADOW + (height - f_status * 1.3) / 2,
                           status_w + 2, f_status * 1.5, argb(accent, 1.0))
                x += round(status_w) + gap
            if wave_w:
                self._wave_strip(graphics, x, mid_y, bar_w, bar_gap,
                                 round(16 * scale), wave_w, state,
                                 accent, colours)
                x += wave_w + gap * 2
            if pending:
                self._text(graphics, pending, self._font(f_pending), x,
                           SHADOW + (height - f_pending * 1.3) / 2,
                           pending_w + 4, f_pending * 1.5,
                           argb(colours["fg"], 1.0))
            if clock_w:
                self._text(graphics, clock, self._font(f_status),
                           SHADOW + width - pad - clock_w,
                           SHADOW + (height - f_status * 1.3) / 2,
                           clock_w + 2, f_status * 1.5,
                           argb(colours["faint"], 1.0))
            ok = True
        finally:
            if not ok:
                self._release(dc, graphics, bitmap, old)
        return (width + SHADOW * 2, height + SHADOW * 2, dc, graphics,
                bitmap, old, bits)

    # ------------------------------------------------------------ 部品

    def _begin(self, graphics) -> None:  # noqa: ANN001
        gdiplus.GdipGraphicsClear(graphics, 0)
        gdiplus.GdipSetSmoothingMode(graphics, 4)        # AntiAlias
        gdiplus.GdipSetTextRenderingHint(graphics, 4)    # AntiAliasGridFit
        gdiplus.GdipSetPixelOffsetMode(graphics, 2)      # HighQuality

    def _shell(self, graphics, width, height, radius,  # noqa: ANN001
               colours, accent, state) -> None:
        """影・地色・枠。録音中だけ枠を状態の色で太くする。

        録音が止まっていることに気づかないと、話した内容が思わぬ場所に
        入ってしまうので、録音中は目立たせる。
        """
        for i in range(7, 0, -1):
            spread = i * 1.6
            self._rounded(graphics, SHADOW - spread, SHADOW - spread + 2.0,
                          width + spread * 2, height + spread * 2,
                          radius + spread, argb("#000000", 0.030))
        self._rounded(graphics, SHADOW, SHADOW, width, height, radius,
                      argb(colours["bg"], 0.985))
        if state == "recording":
            self._rounded_outline(graphics, SHADOW, SHADOW, width, height,
                                  radius, argb(accent, 0.95), 2.0)
        else:
            self._rounded_outline(graphics, SHADOW, SHADOW, width, height,
                                  radius, argb(colours["edge"], 0.95), 1.0)

    def _state_mark(self, graphics, state, x, mid, size,  # noqa: ANN001
                    accent) -> None:
        """状態の印。**形を変える**ので、色が見分けにくい人にも分かる。

          ・丸    ＝ 聞いている
          ・四角  ＝ 文字にしている
          ・チェック＝ 止まった
        """
        shape = STATE_SHAPE.get(state, "dot")
        colour = argb(accent, 1.0)
        if shape == "square":
            s = size * 0.78
            self._rounded(graphics, x, mid - s / 2, s, s, s * 0.28, colour)
            return
        if shape == "check":
            # 丸の中にチェック。線 2 本を角丸の細い棒で描く
            self._ellipse(graphics, x, mid - size / 2, size, size,
                          argb(accent, 0.2))
            self._tick_mark(graphics, x + size / 2, mid, size * 0.62, colour)
            return
        self._ellipse(graphics, x, mid - size / 2, size, size, colour)

    def _tick_mark(self, graphics, cx, cy, span, colour) -> None:  # noqa: ANN001
        """小さなチェック。斜めの棒 2 本を点で並べて描く（変換を使わない）。"""
        thick = max(1.6, span * 0.2)
        steps = max(4, int(span))
        for i in range(steps):
            r = i / (steps - 1)
            x = cx - span * 0.42 + span * 0.36 * r
            y = cy + span * 0.34 * r
            self._ellipse(graphics, x - thick / 2, y - thick / 2,
                          thick, thick, colour)
        for i in range(steps + 2):
            r = i / (steps + 1)
            x = cx - span * 0.06 + span * 0.48 * r
            y = cy + span * 0.34 - span * 0.62 * r
            self._ellipse(graphics, x - thick / 2, y - thick / 2,
                          thick, thick, colour)

    def _wave_strip(self, graphics, x, mid, bar_w, bar_gap,  # noqa: ANN001
                    full, span, state, accent, colours) -> None:
        """横に長い波。**上下に対称**に描くと「声の波」らしく見える。

        声がないときは細い線になる。線が動かないことで
        「マイクが拾えていない」が分かる。
        """
        colour = accent if state in ("recording", "transcribing") \
            else colours["wave"]
        alpha = 1.0 if state == "recording" else 0.65
        # 中心の線（波が小さいときの目印）
        self._rounded(graphics, x, mid - 0.5, span, 1.0, 0.5,
                      argb(colours["wave"], 0.5))
        for value in self._wave:
            amp = value if state == "recording" else 0.12
            h = max(2.0, full * amp)
            self._bar(graphics, x, mid - h / 2, bar_w, h, argb(colour, alpha))
            x += bar_w + bar_gap

    def _wave_bars(self, graphics, x, mid, bar_w, bar_gap,  # noqa: ANN001
                   full, state, accent, colours) -> None:
        for i, value in enumerate(self._wave):
            amp = value if state == "recording" else 0.16
            h = max(2.5, full * amp)
            colour = accent if state in ("recording", "transcribing") \
                else colours["wave"]
            alpha = 1.0 if state == "recording" else 0.75
            self._bar(graphics, x, mid - h / 2, bar_w, h, argb(colour, alpha))
            x += bar_w + bar_gap

    # ------------------------------------------------------------ 下回り

    def _font(self, size: float):  # noqa: ANN202
        if not self._font_family:
            return None
        font = ctypes.c_void_p()
        # 2 = ピクセル単位、0 = 標準の太さ
        if gdiplus.GdipCreateFont(self._font_family, ctypes.c_float(size), 0,
                                  2, ctypes.byref(font)) != 0:
            return None
        return font

    def _measure_setup(self):  # noqa: ANN202
        return self._surface(8, 8)

    def _surface(self, w: int, h: int):  # noqa: ANN202
        # 計算の途中で小数になりやすいので、ここで必ず整数にする
        w, h = max(1, int(round(w))), max(1, int(round(h)))
        screen = user32.GetDC(None)
        dc = gdi32.CreateCompatibleDC(screen)
        user32.ReleaseDC(None, screen)
        if not dc:
            return None
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = w
        info.bmiHeader.biHeight = -h              # 上から下へ
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        info.bmiHeader.biCompression = 0          # BI_RGB
        bits = ctypes.c_void_p()
        bitmap = gdi32.CreateDIBSection(dc, ctypes.byref(info), 0,
                                        ctypes.byref(bits), None, 0)
        if not bitmap:
            gdi32.DeleteDC(dc)
            return None
        old = gdi32.SelectObject(dc, bitmap)
        graphics = ctypes.c_void_p()
        if gdiplus.GdipCreateFromHDC(dc, ctypes.byref(graphics)) != 0:
            gdi32.SelectObject(dc, old)
            gdi32.DeleteObject(bitmap)
            gdi32.DeleteDC(dc)
            return None
        return dc, graphics, bitmap, old, bits

    def _release(self, dc, graphics, bitmap, old, bits=None) -> None:  # noqa: ANN001
        gdiplus.GdipDeleteGraphics(graphics)
        gdi32.SelectObject(dc, old)
        gdi32.DeleteObject(bitmap)
        gdi32.DeleteDC(dc)

    def _fit_pending(self, graphics, text: str,  # noqa: ANN001
                     size: float, limit: int) -> tuple[str, float]:
        """未確定の文字を、決めた幅に収める（後ろを残して前を省略）。"""
        if not text:
            return "", 0.0
        font = self._font(size)
        if font is None:
            return "", 0.0
        try:
            width = self._measure(graphics, text, font)
            if width <= limit:
                return text, width
            cut = text
            while cut and self._measure(graphics, "…" + cut, font) > limit:
                cut = cut[1:]
            cut = "…" + cut
            return cut, self._measure(graphics, cut, font)
        finally:
            gdiplus.GdipDeleteFont(font)

    def _wrap(self, graphics, text: str, size: float,  # noqa: ANN001
              limit: float, max_lines: int) -> list[str]:
        """未確定の文字を、幅で折り返して最大 max_lines 行にする。

        入りきらないときは**後ろを残す**（いま話している所が見たい）。
        """
        if not text:
            return []
        font = self._font(size)
        if font is None:
            return []
        try:
            lines: list[str] = []
            rest = text
            while rest:
                take = len(rest)
                while take > 1 and self._measure(
                        graphics, rest[:take], font) > limit:
                    take -= 1
                lines.append(rest[:take])
                rest = rest[take:]
            if len(lines) > max_lines:
                lines = lines[-max_lines:]
                lines[0] = "…" + lines[0][1:] if len(lines[0]) > 1 \
                    else lines[0]
            return lines
        finally:
            gdiplus.GdipDeleteFont(font)

    def _measure(self, graphics, text: str, font) -> float:  # noqa: ANN001
        if not text or font is None:
            return 0.0
        fmt = ctypes.c_void_p()
        gdiplus.GdipCreateStringFormat(0, 0, ctypes.byref(fmt))
        gdiplus.GdipSetStringFormatFlags(fmt, 0x00000800)   # NoWrap
        box = RectF(0, 0, 4000, 200)
        out = RectF()
        try:
            gdiplus.GdipMeasureString(graphics, text, -1, font,
                                      ctypes.byref(box), fmt,
                                      ctypes.byref(out), None, None)
            return float(out.Width)
        finally:
            gdiplus.GdipDeleteStringFormat(fmt)

    def _text(self, graphics, text: str, font, x: float, y: float,  # noqa: ANN001
              w: float, h: float, colour: int) -> None:
        if not text or font is None:
            return
        brush = ctypes.c_void_p()
        fmt = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(colour, ctypes.byref(brush))
        gdiplus.GdipCreateStringFormat(0, 0, ctypes.byref(fmt))
        gdiplus.GdipSetStringFormatLineAlign(fmt, 1)        # 縦は中央
        gdiplus.GdipSetStringFormatTrimming(fmt, 3)         # 末尾を…にする
        gdiplus.GdipSetStringFormatFlags(fmt, 0x00000800)   # NoWrap
        box = RectF(x, y, w, h)
        try:
            gdiplus.GdipDrawString(graphics, text, -1, font,
                                   ctypes.byref(box), fmt, brush)
        finally:
            gdiplus.GdipDeleteStringFormat(fmt)
            gdiplus.GdipDeleteBrush(brush)
            gdiplus.GdipDeleteFont(font)

    def _path(self, x: float, y: float, w: float, h: float, r: float):  # noqa: ANN202
        path = ctypes.c_void_p()
        if gdiplus.GdipCreatePath(0, ctypes.byref(path)) != 0:
            return None
        r = max(0.5, min(r, min(w, h) / 2))
        d = r * 2
        gdiplus.GdipAddPathArc(path, x, y, d, d, 180, 90)
        gdiplus.GdipAddPathArc(path, x + w - d, y, d, d, 270, 90)
        gdiplus.GdipAddPathArc(path, x + w - d, y + h - d, d, d, 0, 90)
        gdiplus.GdipAddPathArc(path, x, y + h - d, d, d, 90, 90)
        gdiplus.GdipClosePathFigure(path)
        return path

    def _rounded(self, graphics, x: float, y: float, w: float,  # noqa: ANN001
                 h: float, r: float, colour: int) -> None:
        if w <= 0 or h <= 0:
            return
        path = self._path(x, y, w, h, r)
        if path is None:
            return
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(colour, ctypes.byref(brush))
        try:
            gdiplus.GdipFillPath(graphics, brush, path)
        finally:
            gdiplus.GdipDeleteBrush(brush)
            gdiplus.GdipDeletePath(path)

    def _rounded_outline(self, graphics, x: float, y: float, w: float,  # noqa: ANN001
                         h: float, r: float, colour: int,
                         thickness: float = 1.0) -> None:
        path = self._path(x + thickness / 2, y + thickness / 2,
                          w - thickness, h - thickness, r)
        if path is None:
            return
        pen = ctypes.c_void_p()
        if gdiplus.GdipCreatePen1(colour, ctypes.c_float(thickness), 2,
                                  ctypes.byref(pen)) != 0:
            gdiplus.GdipDeletePath(path)
            return
        try:
            gdiplus.GdipDrawPath(graphics, pen, path)
        finally:
            gdiplus.GdipDeletePen(pen)
            gdiplus.GdipDeletePath(path)

    def _ellipse(self, graphics, x: float, y: float, w: float,  # noqa: ANN001
                 h: float, colour: int) -> None:
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(colour, ctypes.byref(brush))
        try:
            gdiplus.GdipFillEllipse(graphics, brush, x, y, w, h)
        finally:
            gdiplus.GdipDeleteBrush(brush)

    def _bar(self, graphics, x: float, y: float, w: float,  # noqa: ANN001
             h: float, colour: int) -> None:
        self._rounded(graphics, x, y, w, h, w / 2, colour)

    def _present(self, dc, w: int, h: int) -> None:  # noqa: ANN001
        x, y = self._place(w, h)
        src = POINT(0, 0)
        dst = POINT(x, y)
        size = SIZE(w, h)
        alpha = int(max(0.0, min(1.0, self._fade)) * 255)
        blend = BLENDFUNCTION(AC_SRC_OVER, 0, alpha, AC_SRC_ALPHA)
        screen = user32.GetDC(None)
        ok = user32.UpdateLayeredWindow(self._hwnd, screen, ctypes.byref(dst),
                                        ctypes.byref(size), dc,
                                        ctypes.byref(src), 0,
                                        ctypes.byref(blend), ULW_ALPHA)
        user32.ReleaseDC(None, screen)
        if not ok:
            log.debug("UpdateLayeredWindow に失敗 err=%s",
                      ctypes.get_last_error())
        if not self._visible:
            # 位置と大きさは UpdateLayeredWindow が決めるので動かさない
            user32.SetWindowPos(self._hwnd, HWND_TOPMOST, 0, 0, 0, 0,
                                SWP_NOACTIVATE | SWP_SHOWWINDOW
                                | SWP_NOSIZE | SWP_NOMOVE)
            self._visible = True
        self._width = w

    def _work_area(self) -> RECT:
        """帯を出すモニターの作業領域（タスクバーを除いた所）。

        **入力しているウィンドウと同じモニター**に出す。
        モニターが複数あるとき、別の画面に出ると気づけない。
        """
        with self._lock:
            target = self._target
        monitor = None
        if target:
            monitor = user32.MonitorFromWindow(target,
                                               MONITOR_DEFAULTTONEAREST)
        if not monitor:
            point = wintypes.POINT()
            if user32.GetCursorPos(ctypes.byref(point)):
                monitor = user32.MonitorFromPoint(
                    POINT(point.x, point.y), MONITOR_DEFAULTTONEAREST)
        if monitor:
            info = MONITORINFO()
            info.cbSize = ctypes.sizeof(MONITORINFO)
            if user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
                return info.rcWork
        work = RECT()
        if not user32.SystemParametersInfoW(SPI_GETWORKAREA, 0,
                                            ctypes.byref(work), 0):
            work.left, work.top = 0, 0
            work.right = user32.GetSystemMetrics(0)
            work.bottom = user32.GetSystemMetrics(1)
        return work

    def _dpi_factor(self) -> float:
        """帯を出すモニターの拡大率（1.0 = 100%）。

        アプリが DPI を自分で扱うと宣言していない（main._dpi_aware が
        できなかった）ときは、Windows が 96 を返すので 1.0 になり、
        今までと同じ大きさで描く。
        """
        with self._lock:
            target = self._target
        dpi = 0
        try:
            if target and hasattr(user32, "GetDpiForWindow"):
                dpi = int(user32.GetDpiForWindow(target))
            if not dpi and hasattr(user32, "GetDpiForSystem"):
                dpi = int(user32.GetDpiForSystem())
        except Exception:  # noqa: BLE001
            dpi = 0
        return max(1.0, min(4.0, dpi / 96.0)) if dpi else 1.0

    def _cursor_pos(self) -> tuple[int, int]:
        """テキスト入力のキャレット（またはマウスポインタ）の位置を返す。"""
        # 1. まずテキストキャレットの位置を試す
        try:
            gti = GUITHREADINFO()
            gti.cbSize = ctypes.sizeof(GUITHREADINFO)
            if user32.GetGUIThreadInfo(0, ctypes.byref(gti)) and gti.hwndCaret:
                pt = POINT(gti.rcCaret.left, gti.rcCaret.bottom)
                if user32.ClientToScreen(gti.hwndCaret, ctypes.byref(pt)):
                    if pt.x != 0 or pt.y != 0:
                        return (pt.x, pt.y)
        except Exception:
            pass
        # 2. キャレットが取れなければマウスポインタの位置を使う
        try:
            pt = POINT()
            if user32.GetCursorPos(ctypes.byref(pt)):
                return (pt.x, pt.y)
        except Exception:
            pass
        return (0, 0)

    def _place(self, w: int, h: int) -> tuple[int, int]:
        work = self._work_area()
        gap = round(self.margin * self._dpi_factor())
        if self.position == "top":
            return (work.left + (work.right - work.left - w) // 2,
                    work.top + gap - SHADOW)
        if self.position == "bottom-right":
            return (work.right - w - gap + SHADOW,
                    work.bottom - h - gap + SHADOW)
        if self.position == "cursor":
            if self._cursor_anchor is None:
                self._cursor_anchor = self._cursor_pos()
            cx, cy = self._cursor_anchor
            if cx != 0 or cy != 0:
                x = cx - w // 2
                y = cy + 18
                if y + h > work.bottom:
                    y = cy - h - 18
                x = max(work.left + gap, min(work.right - w - gap, x))
                y = max(work.top + gap, min(work.bottom - h - gap, y))
                return (x, y)
        return (work.left + (work.right - work.left - w) // 2,
                work.bottom - h - gap + SHADOW)
