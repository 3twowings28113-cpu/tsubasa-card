"""設定の案内（困りごと・やりたいことから探す）。

設定項目が増えて探しにくくなったため、利用者の「困りごと」や「やりたいこと」
から該当する設定項目へ直接案内するデータ構造を定義する。
案内先のキー（target_key）はすべて schema.py の定義と 1 対 1 で対応させる。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from . import i18n, schema


@dataclass(frozen=True)
class GuideChoice:
    """質問に対する選択肢。"""

    id: str
    label_key: str
    target_key: str  # schema.find(key) で取得できるキー
    reason_key: str  # 「なぜこれを変えるか」の説明文キー


@dataclass(frozen=True)
class GuideTopic:
    """困りごと・やりたいことの案内項目。

    選択肢が複数ある場合は question_key と choices で絞り込み、
    単一の項目で完結する場合は target_key と reason_key を直接持つ。
    """

    id: str
    category_tag: str  # speed / text / shortcut / window / audio / ui / app
    title_key: str
    summary_key: str
    target_key: str = ""  # 単一案内時のキー
    reason_key: str = ""  # 単一案内時の理由
    question_key: str = ""
    choices: tuple[GuideChoice, ...] = ()


GUIDE_TOPICS: tuple[GuideTopic, ...] = (
    # 1. 速度・入力タイミング
    GuideTopic(
        id="latency",
        category_tag="speed",
        title_key="guide.latency.title",
        summary_key="guide.latency.summary",
        question_key="guide.latency.question",
        choices=(
            GuideChoice(
                id="c_stream",
                label_key="guide.latency.c_stream.label",
                target_key="input_mode",
                reason_key="guide.latency.c_stream.reason",
            ),
            GuideChoice(
                id="c_model",
                label_key="guide.latency.c_model.label",
                target_key="model",
                reason_key="guide.latency.c_model.reason",
            ),
        ),
    ),
    # 2. 句読点
    GuideTopic(
        id="punctuation",
        category_tag="text",
        title_key="guide.punctuation.title",
        summary_key="guide.punctuation.summary",
        question_key="guide.punctuation.question",
        choices=(
            GuideChoice(
                id="c_commas",
                label_key="guide.punctuation.c_commas.label",
                target_key="punctuation_density",
                reason_key="guide.punctuation.c_commas.reason",
            ),
            GuideChoice(
                id="c_stops",
                label_key="guide.punctuation.c_stops.label",
                target_key="full_stops",
                reason_key="guide.punctuation.c_stops.reason",
            ),
        ),
    ),
    # 3. 録音キー
    GuideTopic(
        id="hotkey",
        category_tag="shortcut",
        title_key="guide.hotkey.title",
        summary_key="guide.hotkey.summary",
        question_key="guide.hotkey.question",
        choices=(
            GuideChoice(
                id="c_key",
                label_key="guide.hotkey.c_key.label",
                target_key="hotkey",
                reason_key="guide.hotkey.c_key.reason",
            ),
            GuideChoice(
                id="c_mode",
                label_key="guide.hotkey.c_mode.label",
                target_key="shortcut_mode",
                reason_key="guide.hotkey.c_mode.reason",
            ),
        ),
    ),
    # 4. チャット送信
    GuideTopic(
        id="chat_send",
        category_tag="shortcut",
        title_key="guide.chat_send.title",
        summary_key="guide.chat_send.summary",
        question_key="guide.chat_send.question",
        choices=(
            GuideChoice(
                id="c_enter",
                label_key="guide.chat_send.c_enter.label",
                target_key="enter_sends",
                reason_key="guide.chat_send.c_enter.reason",
            ),
            GuideChoice(
                id="c_click",
                label_key="guide.chat_send.c_click.label",
                target_key="stop_on_click",
                reason_key="guide.chat_send.c_click.reason",
            ),
            GuideChoice(
                id="c_sendkey",
                label_key="guide.chat_send.c_sendkey.label",
                target_key="send_key",
                reason_key="guide.chat_send.c_sendkey.reason",
            ),
        ),
    ),
    # 5. 英語・他言語
    GuideTopic(
        id="bilingual",
        category_tag="text",
        title_key="guide.bilingual.title",
        summary_key="guide.bilingual.summary",
        question_key="guide.bilingual.question",
        choices=(
            GuideChoice(
                id="c_lang",
                label_key="guide.bilingual.c_lang.label",
                target_key="language",
                reason_key="guide.bilingual.c_lang.reason",
            ),
            GuideChoice(
                id="c_translate",
                label_key="guide.bilingual.c_translate.label",
                target_key="long_press_action",
                reason_key="guide.bilingual.c_translate.reason",
            ),
        ),
    ),
    # 6. つなぎ言葉
    GuideTopic(
        id="fillers",
        category_tag="text",
        title_key="guide.fillers.title",
        summary_key="guide.fillers.summary",
        target_key="remove_fillers",
        reason_key="guide.fillers.reason",
    ),
    # 7. ウィンドウ切替・保留
    GuideTopic(
        id="away_text",
        category_tag="window",
        title_key="guide.away_text.title",
        summary_key="guide.away_text.summary",
        question_key="guide.away_text.question",
        choices=(
            GuideChoice(
                id="c_wait",
                label_key="guide.away_text.c_wait.label",
                target_key="away_text",
                reason_key="guide.away_text.c_wait.reason",
            ),
            GuideChoice(
                id="c_stop",
                label_key="guide.away_text.c_stop.label",
                target_key="stop_on_window_change",
                reason_key="guide.away_text.c_stop.reason",
            ),
        ),
    ),
    # 8. 録音停止忘れ
    GuideTopic(
        id="stop_forget",
        category_tag="shortcut",
        title_key="guide.stop_forget.title",
        summary_key="guide.stop_forget.summary",
        question_key="guide.stop_forget.question",
        choices=(
            GuideChoice(
                id="c_silence",
                label_key="guide.stop_forget.c_silence.label",
                target_key="stop_on_silence_ms",
                reason_key="guide.stop_forget.c_silence.reason",
            ),
            GuideChoice(
                id="c_hold",
                label_key="guide.stop_forget.c_hold.label",
                target_key="shortcut_mode",
                reason_key="guide.stop_forget.c_hold.reason",
            ),
        ),
    ),
    # 9. 話し始め・語尾切れ
    GuideTopic(
        id="speech_boundary",
        category_tag="audio",
        title_key="guide.speech_boundary.title",
        summary_key="guide.speech_boundary.summary",
        question_key="guide.speech_boundary.question",
        choices=(
            GuideChoice(
                id="c_preroll",
                label_key="guide.speech_boundary.c_preroll.label",
                target_key="mic_preroll_ms",
                reason_key="guide.speech_boundary.c_preroll.reason",
            ),
            GuideChoice(
                id="c_postroll",
                label_key="guide.speech_boundary.c_postroll.label",
                target_key="post_roll_ms",
                reason_key="guide.speech_boundary.c_postroll.reason",
            ),
        ),
    ),
    # 10. 録音中の帯（オーバーレイ）
    GuideTopic(
        id="overlay",
        category_tag="ui",
        title_key="guide.overlay.title",
        summary_key="guide.overlay.summary",
        question_key="guide.overlay.question",
        choices=(
            GuideChoice(
                id="c_design",
                label_key="guide.overlay.c_design.label",
                target_key="overlay_design",
                reason_key="guide.overlay.c_design.reason",
            ),
            GuideChoice(
                id="c_pos",
                label_key="guide.overlay.c_pos.label",
                target_key="overlay_position",
                reason_key="guide.overlay.c_pos.reason",
            ),
            GuideChoice(
                id="c_vis",
                label_key="guide.overlay.c_vis.label",
                target_key="overlay",
                reason_key="guide.overlay.c_vis.reason",
            ),
        ),
    ),
    # 11. BGM・PC音のダッキング
    GuideTopic(
        id="audio_ducking",
        category_tag="audio",
        title_key="guide.audio_ducking.title",
        summary_key="guide.audio_ducking.summary",
        target_key="audio_ducking",
        reason_key="guide.audio_ducking.reason",
    ),
    # 12. 半角英数字
    GuideTopic(
        id="halfwidth",
        category_tag="text",
        title_key="guide.halfwidth.title",
        summary_key="guide.halfwidth.summary",
        target_key="halfwidth_numbers",
        reason_key="guide.halfwidth.reason",
    ),
    # 13. 固有名詞・辞書
    GuideTopic(
        id="dictionary",
        category_tag="text",
        title_key="guide.dictionary.title",
        summary_key="guide.dictionary.summary",
        target_key="dictionary",
        reason_key="guide.dictionary.reason",
    ),
    # 14. 除外アプリ
    GuideTopic(
        id="excluded_apps",
        category_tag="app",
        title_key="guide.excluded_apps.title",
        summary_key="guide.excluded_apps.summary",
        target_key="excluded_apps",
        reason_key="guide.excluded_apps.reason",
    ),
    # 15. 効果音
    GuideTopic(
        id="sound",
        category_tag="audio",
        title_key="guide.sound.title",
        summary_key="guide.sound.summary",
        question_key="guide.sound.question",
        choices=(
            GuideChoice(
                id="c_theme",
                label_key="guide.sound.c_theme.label",
                target_key="sound_theme",
                reason_key="guide.sound.c_theme.reason",
            ),
            GuideChoice(
                id="c_volume",
                label_key="guide.sound.c_volume.label",
                target_key="sound_volume",
                reason_key="guide.sound.c_volume.reason",
            ),
        ),
    ),
)


def serialize_guides() -> list[dict[str, Any]]:
    """Web 設定画面向けに案内データを辞書リストへ変換する。"""
    out: list[dict[str, Any]] = []
    for topic in GUIDE_TOPICS:
        target_cat = (schema.find_category(topic.target_key)
                      if topic.target_key else "")
        target_item = (schema.find(topic.target_key)
                       if topic.target_key else None)
        target_label = (target_item.ja if i18n.language() == "ja"
                        else target_item.en) if target_item else ""

        choices_data = []
        for c in topic.choices:
            c_cat = schema.find_category(c.target_key) or ""
            c_item = schema.find(c.target_key)
            c_label = (c_item.ja if i18n.language() == "ja"
                       else c_item.en) if c_item else ""
            choices_data.append({
                "id": c.id,
                "label": i18n.t(c.label_key),
                "target_key": c.target_key,
                "target_category": c_cat,
                "target_label": c_label,
                "reason": i18n.t(c.reason_key),
            })

        out.append({
            "id": topic.id,
            "category_tag": topic.category_tag,
            "title": i18n.t(topic.title_key),
            "summary": i18n.t(topic.summary_key) if topic.summary_key else "",
            "target_key": topic.target_key,
            "target_category": target_cat,
            "target_label": target_label,
            "reason": i18n.t(topic.reason_key) if topic.reason_key else "",
            "question": (i18n.t(topic.question_key)
                         if topic.question_key else ""),
            "choices": choices_data,
        })
    return out
