"""録音中だけ、マウスのクリックを見る。**入力の流れには割り込まない。**

## なぜ作り直したか（2 回目）

最初は低レベルのフック（`WH_MOUSE_LL`）でクリックを**受け止めて**いた。
「送信ボタンを押されたら、残りの文字を入れ終わってからクリックを通す」
という作りで、言葉の最後が抜けないようにしたかった。

これが **PC 全体をほぼ固めた。** 低レベルのフックのコールバックは
Python では GIL（実行権）を取れるまで動けない。文字起こしが GIL を
持っているあいだ、Windows は **PC 全体のキー・マウス入力を止めて待つ**。
カーソルがカクつき、待ちすぎると Windows がフックを黙って外す。
利用者の PC が重くなり、再起動が必要になった。

**だから、クリックを止めて待つことは二度としない。**

## いまの作り

録音中だけ、短い間隔で `GetAsyncKeyState` を**読む**。

| | |
|---|---|
| 見る方法 | `GetAsyncKeyState`（ただ読むだけ。OS が持っている今の状態を返す） |
| 間隔 | 既定 15 ミリ秒（1 秒に約 66 回）。user32 の呼び出し 3 回ぶんなので、ほぼ負荷にならない |
| 動くとき | **録音中だけ**。待機中はスレッドも回らない |
| クリックへの影響 | **なし。** 受け止めない・遅らせない・書き換えない |

フックと違って、こちらが遅れても相手のアプリは待たされない。
最悪こちらが止まっても、クリックは普通に通る。

`SetWindowsHookEx` も `RegisterRawInputDevices` も使っていない。
Raw Input（`RIDEV_INPUTSINK`）でも入力は止まらないが、専用の窓と
メッセージの読み出しが必要で、得られるものが同じなので選ばなかった。

## 同じウィンドウの中のクリックも分かる

画面の見張り（`SetWinEventHook`）では、**同じウィンドウの中**を
押したことは分からない。チャットの送信ボタンがまさにそれで、
「送信を押しても録音が止まらない」になっていた。
ここで直接ボタンの状態を見ることで、それが分かるようになる。
"""

from __future__ import annotations

import ctypes
import logging
import threading
import time
from ctypes import wintypes

from . import dryrun

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)

VK_LBUTTON = 0x01
VK_RBUTTON = 0x02
VK_MBUTTON = 0x04

# 「左右を入れ替える」設定でも、どちらも見るので気にしなくてよい
BUTTONS = ((VK_LBUTTON, "左"), (VK_RBUTTON, "右"), (VK_MBUTTON, "中"))

GA_ROOT = 2

user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
user32.GetCursorPos.restype = wintypes.BOOL
user32.WindowFromPoint.argtypes = [wintypes.POINT]
user32.WindowFromPoint.restype = wintypes.HWND
user32.GetAncestor.argtypes = [wintypes.HWND, wintypes.UINT]
user32.GetAncestor.restype = wintypes.HWND


def _down(vk: int) -> bool:
    """いまボタンが押されているか。**上位ビットだけを見る。**

    下位ビット（前回の呼び出しからの押下）は呼んだ側で消えてしまい、
    ほかの場所で読まれると取りこぼす。使わない。
    """
    return bool(user32.GetAsyncKeyState(vk) & 0x8000)


def _window_under_cursor() -> int:
    """カーソルの下にある窓。

    `WindowFromPoint` は相手のアプリを待たせない（メッセージを送らない）。
    """
    point = wintypes.POINT()
    if not user32.GetCursorPos(ctypes.byref(point)):
        return 0
    hwnd = user32.WindowFromPoint(point)
    return int(hwnd or 0)



class MouseWatch:
    """録音中だけ、クリックを見るスレッド。

    `on_click(hwnd, held_click)` を呼ぶ。`held_click` は必ず False。
    受け止めないので、通す必要もない（`release()` は何もしない）。
    """

    def __init__(self, on_click, *, interval: float = 0.015) -> None:  # noqa: ANN001
        self._on_click = on_click
        self.interval = max(0.005, interval)
        self._thread: threading.Thread | None = None
        self._run = threading.Event()
        self._fired = False
        self._lock = threading.Lock()

    # ------------------------------------------------------------ 出入り

    def install(self) -> bool:
        """昔のフックの名残。いまは取り付けるものがない。"""
        return True

    def remove(self) -> None:
        self.disarm()

    def arm(self, *, interval: float | None = None) -> None:
        """録音を始めた。見張りを回す。"""
        if dryrun.enabled():
            return
        if interval:
            self.interval = max(0.005, interval)
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                self._fired = False
                return
            self._fired = False
            self._run.set()
            self._thread = threading.Thread(target=self._loop,
                                            name="clickwatch", daemon=True)
            self._thread.start()

    def disarm(self) -> None:
        """録音を止めた。見張りを下ろす（合流は待たない）。"""
        self._run.clear()
        with self._lock:
            self._thread = None

    def release(self) -> None:
        """受け止めたクリックを通す……という処理は、もう無い。

        以前の作りの名残。呼ばれても何もしない。
        """

    @property
    def armed(self) -> bool:
        return self._run.is_set()

    # ------------------------------------------------------------ 本体

    def _loop(self) -> None:
        # 始めた時点で押されているボタンは、押し下げとして数えない
        # （Ctrl+Space を押した直後にボタンを握っていた場合など）
        was = {vk: _down(vk) for vk, _ in BUTTONS}
        while self._run.is_set():
            try:
                for vk, name in BUTTONS:
                    now = _down(vk)
                    if now and not was[vk]:
                        was[vk] = True
                        self._hit(name)
                        if not self._run.is_set():
                            return
                    elif not now:
                        was[vk] = False
            except Exception:
                log.exception("マウスの見張りで例外（止めます）")
                return
            time.sleep(self.interval)

    def _hit(self, name: str) -> None:
        """押し下げを 1 回見つけた。停止したときだけ _fired を True にする。"""
        if self._fired:
            return
        hwnd = _window_under_cursor()
        log.info("録音中に%sボタンが押されました (hwnd=%s)", name, hwnd)
        try:
            stopped = bool(self._on_click(hwnd, False))
            if stopped:
                self._fired = True
        except Exception:
            log.exception("クリックの知らせで例外")

