"""PC 起動時の高速自動起動。

Windows のログオン直後（デスクトップ表示とほぼ同時）に即座に起動するため、
タスクスケジューラ（Schedule.Service COM）のログオントリガーを使う。

なぜレジストリ Run キーをやめたのか：
  従来の HKCU\\...\\Run レジストリでは、他アプリ（Teams, OneDrive,
  Genspark 等）の起動完了待ちや Windows Explorer の StartupDelay により、
  PC を起動（ログオン）してからこのアプリが起動するまでに 2 分半（150秒）
  以上も遅延していた。

タスクスケジューラは現在のユーザー権限（UAC 不要・非管理者）で登録する。
万が一タスクスケジューラが使えない環境では、レジストリ Run キーに
フォールバックする。
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
import winreg
from pathlib import Path

from .util import ROOT

log = logging.getLogger(__name__)

TASK_NAME = "koe-type"
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
REG_NAME = "koe-type"


def _pythonw() -> str:
    exe = Path(sys.executable)
    candidate = exe.with_name("pythonw.exe")
    return str(candidate if candidate.exists() else exe)


def command() -> str:
    return f'"{_pythonw()}" "{ROOT / "koe-type.pyw"}"'


def _run_ps(script: str) -> str:
    """PowerShell を安全に非表示・非対話で実行する。"""
    try:
        res = subprocess.run(
            [
                "powershell", "-NoProfile", "-NonInteractive",
                "-ExecutionPolicy", "Bypass", "-Command", script,
            ],
            capture_output=True,
            text=True,
            errors="ignore",
            creationflags=0x08000000,
            timeout=15,
        )
        return res.stdout.strip()
    except Exception:
        log.exception("PowerShell 実行で例外")
        return ""


def _register_task() -> bool:
    """タスクスケジューラにログオン時即時起動タスクを登録する。

    UAC 管理者権限は不要。ログオン中のユーザーのトークン
    （TASK_LOGON_INTERACTIVE_TOKEN = 3）として登録する。
    """
    pw = _pythonw().replace("'", "''")
    target = str(ROOT / "koe-type.pyw").replace("'", "''")
    cwd = str(ROOT).replace("'", "''")
    ps = f"""
$ErrorActionPreference = 'Stop'
$svc = New-Object -ComObject Schedule.Service
$svc.Connect()
$root = $svc.GetFolder('\\')

$def = $svc.NewTask(0)
$def.RegistrationInfo.Description = 'koe-type instant logon autostart'
$def.RegistrationInfo.Author = 'koe-type'

$def.Settings.Enabled = $true
$def.Settings.AllowDemandStart = $true
$def.Settings.DisallowStartIfOnBatteries = $false
$def.Settings.StopIfGoingOnBatteries = $false
$def.Settings.ExecutionTimeLimit = 'PT0S'
$def.Settings.Priority = 4
$def.Settings.StartWhenAvailable = $true
# すでに動いている間は新しい実体を起動しない（TASK_INSTANCES_IGNORE_NEW）
$def.Settings.MultipleInstances = 2

$trigger = $def.Triggers.Create(9)
$trigger.UserId = "$env:USERDOMAIN\\$env:USERNAME"
$trigger.Enabled = $true

$action = $def.Actions.Create(0)
$action.Path = '{pw}'
$action.Arguments = '"{target}"'
$action.WorkingDirectory = '{cwd}'

$root.RegisterTaskDefinition('{TASK_NAME}', $def, 6, $null, $null, 3) | Out-Null
Write-Host "OK"
"""
    out = _run_ps(ps)
    if "OK" in out:
        log.info("タスクスケジューラにログオン時即時起動を登録しました")
        return True
    log.warning("タスクスケジューラ登録に失敗: %s", out)
    return False


def _unregister_task() -> bool:
    """タスクスケジューラからタスクを削除する。"""
    ps = f"""
$ErrorActionPreference = 'SilentlyContinue'
$svc = New-Object -ComObject Schedule.Service
$svc.Connect()
$root = $svc.GetFolder('\\')
try {{ $root.DeleteTask('{TASK_NAME}', 0) }} catch {{}}
try {{ $root.DeleteTask('KoeTypeRun', 0) }} catch {{}}
Write-Host "OK"
"""
    out = _run_ps(ps)
    return "OK" in out


def _query_task() -> tuple[bool, str | None]:
    """タスクスケジューラに登録されているか調べる。"""
    ps = f"""
$ErrorActionPreference = 'SilentlyContinue'
$svc = New-Object -ComObject Schedule.Service
$svc.Connect()
$root = $svc.GetFolder('\\')
try {{
    $t = $root.GetTask('{TASK_NAME}')
    if ($t -and $t.Enabled) {{
        $a = $t.Definition.Actions.Item(1)
        Write-Host "FOUND|$($a.Path)|$($a.Arguments)"
    }}
}} catch {{}}
"""
    out = _run_ps(ps)
    if out.startswith("FOUND|"):
        parts = out.split("|", 2)
        cmd = f'"{parts[1]}" {parts[2]}' if len(parts) >= 3 else parts[1]
        return True, cmd
    return False, None


def _query_registry() -> str | None:
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            return winreg.QueryValueEx(key, REG_NAME)[0]
    except OSError:
        return None


def _enable_registry() -> bool:
    try:
        with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                                winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, REG_NAME, 0, winreg.REG_SZ, command())
        log.info("レジストリ Run キーに自動起動を登録しました: %s", command())
        return True
    except OSError:
        log.exception("レジストリ自動起動の登録に失敗")
        return False


def _disable_registry() -> bool:
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0,
                            winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, REG_NAME)
        log.info("レジストリ Run キーの自動起動を解除しました")
        return True
    except FileNotFoundError:
        return True
    except OSError:
        log.exception("レジストリ自動起動の解除に失敗")
        return False


def current() -> str | None:
    """現在の自動起動コマンド。タスク優先、無ければレジストリ。"""
    found, cmd = _query_task()
    if found and cmd:
        return cmd
    return _query_registry()


def enable() -> bool:
    """自動起動を登録する。

    最速起動のためにタスクスケジューラを優先する。
    成功したらレジストリ側の古い登録は解除して一本化する。
    タスクスケジューラが使えなければレジストリにフォールバックする。
    """
    if _register_task():
        _disable_registry()
        return True
    return _enable_registry()


def disable() -> bool:
    """自動起動を解除する。タスクとレジストリの両方を掃除する。"""
    ok1 = _unregister_task()
    ok2 = _disable_registry()
    log.info("自動起動を解除しました")
    return ok1 or ok2


def ensure() -> None:
    """登録されていない、または内容が古ければ登録し直す。

    検証用の安全弁つき。テストが本物のアプリを起動したときに、
    利用者の自動起動の登録を書き換えてしまう事故を起こしたため。
    """
    if os.environ.get("KOE_TYPE_NO_AUTOSTART"):
        log.info("検証用の設定なので、自動起動の登録は変えません")
        return
    want = command()
    curr = current()
    if curr != want:
        enable()
    else:
        # すでにタスクスケジューラにある場合、古い Run キーが残っていれば消す
        found, _ = _query_task()
        if found and _query_registry() is not None:
            _disable_registry()


def is_enabled() -> bool | None:
    """自動起動に登録されているか。調べられなければ None。"""
    try:
        found, _ = _query_task()
        if found:
            return True
        reg = _query_registry()
        return reg is not None
    except Exception:
        return None


def relaunch() -> None:
    """自分を起動し直す（トレイの「再起動」用）。

    ★`--restarted` を付ける。新しいほうを先に起動してから古いほうを
    終わらせるので、古いほうの終了が遅れると、新しいほうが「すでに
    起動している」と判断して自分から終わり、**再起動したのに何も
    動いていない**ことになりえた。付けたときは、古いほうが多重起動
    よけの鍵を手放すまで待つ（main.single_instance）。
    """
    try:
        subprocess.Popen([_pythonw(), str(ROOT / "koe-type.pyw"),
                          "--restarted"],
                         cwd=str(ROOT), close_fds=True,
                         creationflags=0x00000008 | 0x08000000)
    except Exception:
        log.exception("再起動に失敗")


if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "status"
    if action == "enable":
        enable()
        print("登録しました:", current())
    elif action == "disable":
        disable()
        print("解除しました")
    else:
        print("現在の登録:", current() or "（なし）")
