"""効果音と、録音中のスピーカーミュート。

効果音は wav を実行時に作って winsound で鳴らす（音源ファイルを同梱しないため）。
ミュートは Core Audio の IAudioEndpointVolume を ctypes の COM 呼び出しで操作する。
"""

from __future__ import annotations

import ctypes
import logging
import math
import struct
import threading
import wave
from ctypes import wintypes
from pathlib import Path

from .util import DATA_DIR

log = logging.getLogger(__name__)

SOUND_DIR = DATA_DIR / "sounds"


# ---------------------------------------------------------------- 効果音

THEMES: dict[str, dict[str, list[tuple[float, float]]]] = {
    "default": {
        "start": [(660.0, 0.055), (880.0, 0.075)],
        "stop": [(740.0, 0.055), (554.0, 0.085)],
        "cancel": [(440.0, 0.07)],
    },
    "soft": {
        "start": [(440.0, 0.06), (554.0, 0.08)],
        "stop": [(554.0, 0.06), (440.0, 0.08)],
        "cancel": [(330.0, 0.08)],
    },
    "chime": {
        "start": [(523.25, 0.045), (659.25, 0.045), (783.99, 0.065)],
        "stop": [(783.99, 0.045), (659.25, 0.045), (523.25, 0.065)],
        "cancel": [(493.88, 0.06), (466.16, 0.08)],
    },
    "mechanical": {
        "start": [(1200.0, 0.015), (1800.0, 0.02)],
        "stop": [(1800.0, 0.015), (1200.0, 0.02)],
        "cancel": [(800.0, 0.025)],
    },
}


def _tone(path: Path, freqs: list[tuple[float, float]], rate: int = 22050,
          volume: int = 80) -> None:
    """(周波数, 長さ秒) を並べた短い音を作る。角を丸めてプチッと鳴らない。"""
    vol = max(0, min(100, volume))
    amp = (vol / 100.0) * 0.16
    frames = bytearray()
    for freq, seconds in freqs:
        n = int(rate * seconds)
        for i in range(n):
            # 立ち上がり・立ち下がりをなめらかに
            env = min(1.0, i / (rate * 0.006), (n - i) / (rate * 0.03))
            value = math.sin(2 * math.pi * freq * i / rate) * env * amp
            frames += struct.pack("<h", int(value * 32767))
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(bytes(frames))


def ensure_sounds(theme: str = "default", volume: int = 80) -> dict[str, Path]:
    SOUND_DIR.mkdir(parents=True, exist_ok=True)
    out = {}
    specs = THEMES.get(theme) or THEMES["default"]
    vol = max(0, min(100, volume))
    for name, freqs in specs.items():
        path = SOUND_DIR / f"{theme}_{name}_v{vol}.wav"
        if not path.exists():
            try:
                _tone(path, freqs, volume=vol)
            except Exception:
                log.exception("効果音を作れませんでした: %s/%s", theme, name)
                continue
        out[name] = path
    return out


_sounds_cache: dict[tuple[str, int], dict[str, Path]] = {}


def play(name: str, theme: str = "default", volume: int = 80) -> None:
    """効果音を鳴らす（鳴らせなくても処理は止めない）。

    自動テスト（KOE_TYPE_DRY_RUN=1 または KOE_TYPE_NO_SOUND=1）時は
    スピーカー保護のため再生をスキップする。
    """
    import os
    if os.environ.get("KOE_TYPE_DRY_RUN") or os.environ.get("KOE_TYPE_NO_SOUND"):
        log.debug("効果音スキップ(テストモード): %s/%s v=%d", theme, name, volume)
        return
    if volume <= 0:
        return
    try:
        import winsound
        key = (theme, volume)
        if key not in _sounds_cache:
            _sounds_cache[key] = ensure_sounds(theme, volume)
        sounds = _sounds_cache[key]
        path = sounds.get(name)
        if path is None or not path.exists():
            return
        winsound.PlaySound(str(path),
                           winsound.SND_FILENAME | winsound.SND_ASYNC
                           | winsound.SND_NODEFAULT)
    except Exception:
        log.debug("効果音を鳴らせませんでした: %s/%s", theme, name, exc_info=True)


# ---------------------------------------------------------------- ミュート

ole32 = ctypes.WinDLL("ole32")
CLSCTX_ALL = 23
COINIT_APARTMENTTHREADED = 0x2


class GUID(ctypes.Structure):
    _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                ("Data3", wintypes.WORD), ("Data4", ctypes.c_byte * 8)]

    def __init__(self, text: str) -> None:
        super().__init__()
        ole32.CLSIDFromString(text, ctypes.byref(self))


CLSID_MMDeviceEnumerator = "{BCDE0395-E52F-467C-8E3D-C4579291692E}"
IID_IMMDeviceEnumerator = "{A95664D2-9614-4F35-A746-DE8DB63617E6}"
IID_IAudioEndpointVolume = "{5CDF2C82-841E-4546-9722-0CF74078229A}"

eRender, eConsole = 0, 1


def _vtable_call(ptr: ctypes.c_void_p, index: int, *args, restype=ctypes.c_long):
    vtable = ctypes.cast(ptr, ctypes.POINTER(ctypes.c_void_p))[0]
    fn_ptr = ctypes.cast(vtable, ctypes.POINTER(ctypes.c_void_p))[index]
    proto = ctypes.WINFUNCTYPE(restype, ctypes.c_void_p,
                               *[type(a) if not isinstance(a, int) else ctypes.c_int
                                 for a in args])
    return proto(fn_ptr)(ptr, *args)


class _Volume:
    """既定の再生デバイスのミュートや音量ダッキングを操作する。"""

    # IAudioEndpointVolume の vtable 位置
    SET_MASTER_VOLUME = 7
    GET_MASTER_VOLUME = 9
    SET_MUTE = 14
    GET_MUTE = 15

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._muted_by_us = False
        self._ducked_by_us = False
        self._prev_volume: float | None = None

    def _is_test(self) -> bool:
        import os
        return bool(os.environ.get("KOE_TYPE_DRY_RUN")
                    or os.environ.get("KOE_TYPE_NO_SOUND"))

    def _endpoint(self):
        ole32.CoInitializeEx(None, COINIT_APARTMENTTHREADED)
        enumerator = ctypes.c_void_p()
        hr = ole32.CoCreateInstance(
            ctypes.byref(GUID(CLSID_MMDeviceEnumerator)), None, CLSCTX_ALL,
            ctypes.byref(GUID(IID_IMMDeviceEnumerator)),
            ctypes.byref(enumerator))
        if hr != 0 or not enumerator:
            raise OSError(f"CoCreateInstance 失敗 hr={hr:#x}")
        try:
            device = ctypes.c_void_p()
            proto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p,
                                       ctypes.c_int, ctypes.c_int,
                                       ctypes.POINTER(ctypes.c_void_p))
            vt = ctypes.cast(enumerator,
                             ctypes.POINTER(ctypes.c_void_p))[0]
            fn = ctypes.cast(vt, ctypes.POINTER(ctypes.c_void_p))[4]
            hr = proto(fn)(enumerator, eRender, eConsole, ctypes.byref(device))
            if hr != 0 or not device:
                raise OSError(f"GetDefaultAudioEndpoint 失敗 hr={hr:#x}")
            try:
                volume = ctypes.c_void_p()
                proto2 = ctypes.WINFUNCTYPE(
                    ctypes.c_long, ctypes.c_void_p, ctypes.POINTER(GUID),
                    ctypes.c_int, ctypes.c_void_p,
                    ctypes.POINTER(ctypes.c_void_p))
                vt2 = ctypes.cast(device, ctypes.POINTER(ctypes.c_void_p))[0]
                fn2 = ctypes.cast(vt2, ctypes.POINTER(ctypes.c_void_p))[3]
                hr = proto2(fn2)(device, ctypes.byref(GUID(IID_IAudioEndpointVolume)),
                                 CLSCTX_ALL, None, ctypes.byref(volume))
                if hr != 0 or not volume:
                    raise OSError(f"Activate 失敗 hr={hr:#x}")
                return volume
            finally:
                _release(device)
        finally:
            _release(enumerator)

    def _set_mute(self, on: bool) -> bool:
        volume = self._endpoint()
        try:
            proto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p,
                                       ctypes.c_int, ctypes.POINTER(GUID))
            vt = ctypes.cast(volume, ctypes.POINTER(ctypes.c_void_p))[0]
            fn = ctypes.cast(vt, ctypes.POINTER(ctypes.c_void_p))[self.SET_MUTE]
            hr = proto(fn)(volume, 1 if on else 0, None)
            return hr == 0
        finally:
            _release(volume)

    def _get_mute(self) -> bool:
        volume = self._endpoint()
        try:
            state = ctypes.c_int(0)
            proto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p,
                                       ctypes.POINTER(ctypes.c_int))
            vt = ctypes.cast(volume, ctypes.POINTER(ctypes.c_void_p))[0]
            fn = ctypes.cast(vt, ctypes.POINTER(ctypes.c_void_p))[self.GET_MUTE]
            proto(fn)(volume, ctypes.byref(state))
            return bool(state.value)
        finally:
            _release(volume)

    def _set_volume(self, level: float) -> bool:
        volume = self._endpoint()
        try:
            proto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p,
                                       ctypes.c_float, ctypes.POINTER(GUID))
            vt = ctypes.cast(volume, ctypes.POINTER(ctypes.c_void_p))[0]
            fn = ctypes.cast(vt, ctypes.POINTER(ctypes.c_void_p))[
                self.SET_MASTER_VOLUME]
            hr = proto(fn)(volume, ctypes.c_float(max(0.0, min(1.0, level))),
                           None)
            return hr == 0
        finally:
            _release(volume)

    def _get_volume(self) -> float:
        volume = self._endpoint()
        try:
            level = ctypes.c_float(0.0)
            proto = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p,
                                       ctypes.POINTER(ctypes.c_float))
            vt = ctypes.cast(volume, ctypes.POINTER(ctypes.c_void_p))[0]
            fn = ctypes.cast(vt, ctypes.POINTER(ctypes.c_void_p))[
                self.GET_MASTER_VOLUME]
            hr = proto(fn)(volume, ctypes.byref(level))
            return float(level.value) if hr == 0 else 0.0
        finally:
            _release(volume)

    def mute(self) -> None:
        with self._lock:
            if self._muted_by_us:
                return
            if self._is_test():
                self._muted_by_us = True
                return
            try:
                if self._get_mute():
                    return            # もともと消えているので触らない
                if self._set_mute(True):
                    self._muted_by_us = True
            except Exception:
                log.debug("ミュートできませんでした", exc_info=True)

    def unmute(self) -> None:
        with self._lock:
            if not self._muted_by_us:
                return
            if self._is_test():
                self._muted_by_us = False
                return
            try:
                self._set_mute(False)
            except Exception:
                log.debug("ミュートを戻せませんでした", exc_info=True)
            finally:
                self._muted_by_us = False

    def duck(self, ratio: float = 0.25) -> None:
        """音量を指定した割合（0.0〜1.0）に下げる。"""
        with self._lock:
            if self._ducked_by_us or self._muted_by_us:
                return
            if self._is_test():
                self._prev_volume = 0.8
                self._ducked_by_us = True
                return
            try:
                curr = self._get_volume()
                if curr <= 0.01:
                    return
                target = max(0.0, min(1.0, curr * ratio))
                if self._set_volume(target):
                    self._prev_volume = curr
                    self._ducked_by_us = True
            except Exception:
                log.debug("ダッキングできませんでした", exc_info=True)

    def unduck(self) -> None:
        """ダッキングした音量を元に戻す。"""
        with self._lock:
            if not self._ducked_by_us:
                return
            if self._is_test():
                self._ducked_by_us = False
                self._prev_volume = None
                return
            try:
                if self._prev_volume is not None:
                    self._set_volume(self._prev_volume)
            except Exception:
                log.debug("音量を戻せませんでした", exc_info=True)
            finally:
                self._ducked_by_us = False
                self._prev_volume = None

    def restore(self) -> None:
        """ミュートとダッキングの両方を安全に戻す。"""
        self.unmute()
        self.unduck()


def _release(ptr: ctypes.c_void_p) -> None:
    try:
        vt = ctypes.cast(ptr, ctypes.POINTER(ctypes.c_void_p))[0]
        fn = ctypes.cast(vt, ctypes.POINTER(ctypes.c_void_p))[2]
        ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(fn)(ptr)
    except Exception:
        pass


speaker = _Volume()
