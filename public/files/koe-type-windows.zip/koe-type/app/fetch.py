r"""モデルと実行ファイルをコマンドから取得する。

  python -m app.fetch                     使えるモデルの一覧
  python -m app.fetch sensevoice-small    そのモデルに必要なものを全部取得
  python -m app.fetch --all               全部のモデルを取得
"""

from __future__ import annotations

import sys
import time

from . import catalog, downloads
from .util import ensure_dirs, setup_logging


def _list() -> None:
    print("使えるモデル:\n")
    for key, spec in catalog.MODELS.items():
        ready = catalog.model_ready(key) and catalog.runtime_ready(spec.runtime)
        mark = "済" if ready else "未"
        print(f"  [{mark}] {key:24} {spec.name}")
        print(f"       {spec.ja}")
        print(f"       サイズ {catalog.human_size(spec.size)} / "
              f"ライセンス {spec.license}")
        print(f"       {spec.source}\n")
    print("取得するには:  python -m app.fetch <モデル名>")


def _fetch(key: str) -> int:
    if key not in catalog.MODELS:
        print(f"'{key}' は一覧にありません。")
        return 1
    missing = catalog.missing_assets(key)
    if not missing:
        print(f"{key}: すでにそろっています。")
        return 0
    total = sum(a.size for a in missing)
    print(f"{key}: {len(missing)} ファイル / 約 {catalog.human_size(total)}")

    state = {"name": "", "shown": -1, "at": 0.0}

    def progress(name: str, frac: float) -> None:
        pct = int(frac * 100)
        now = time.monotonic()
        if name != state["name"] or pct != state["shown"] and now - state["at"] > 0.2:
            state.update(name=name, shown=pct, at=now)
            bar = "#" * (pct // 4) + "." * (25 - pct // 4)
            print(f"\r  {name[:40]:40} [{bar}] {pct:3d}%", end="", flush=True)

    try:
        downloads.fetch_all(missing, progress)
    except Exception as exc:  # noqa: BLE001
        print(f"\n失敗しました: {exc}")
        return 1
    print(f"\r  {'完了':40} {'':25}      ")
    print(f"{key}: 取得しました。")
    return 0


def main(argv: list[str]) -> int:
    ensure_dirs()
    setup_logging("INFO")
    args = [a for a in argv if not a.startswith("-")]
    if "--all" in argv:
        return max((_fetch(k) for k in catalog.MODELS), default=0)
    if not args:
        _list()
        return 0
    return max(_fetch(k) for k in args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
