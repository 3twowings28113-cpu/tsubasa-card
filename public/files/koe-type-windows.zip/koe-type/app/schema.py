"""設定項目の定義。

設定画面（HTML）もこの定義から組み立てる。項目を増やしたいときはここに足すだけ。
`default` はそのまま config.json の初期値になる。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class Option:
    value: Any
    ja: str
    en: str


@dataclass(frozen=True)
class Preset:
    value: Any
    ja: str
    en: str


@dataclass(frozen=True)
class Item:
    key: str
    kind: str          # bool / choice / segments / int / hotkey / applist /
                       # custom / action
    ja: str = ""
    en: str = ""
    help_ja: str = ""
    help_en: str = ""
    default: Any = None
    options: tuple[Option, ...] = ()
    presets: tuple[Preset, ...] = ()
    minimum: int = 0
    maximum: int = 100
    step: int = 1
    unit: str = ""     # "" / "ms_sec"（ミリ秒を秒で見せる）/ "ms_min"（分）/ "count"
    zero_ja: str = ""  # 0 のときの表示（例「無制限」）
    zero_en: str = ""
    restart: bool = False
    panel: str = ""        # kind == "custom" / "action" のときの識別子
    options_from: str = ""  # 実行時に選択肢を作る（microphones など）
    advanced: bool = False  # True なら「詳しい設定」を選んだときだけ見せる


@dataclass(frozen=True)
class Group:
    ja: str
    en: str
    items: tuple[Item, ...] = ()


@dataclass(frozen=True)
class Category:
    key: str
    icon: str          # app/web/app.js の ICONS にある名前
    ja: str
    en: str
    sub_ja: str = ""
    sub_en: str = ""
    groups: tuple[Group, ...] = field(default_factory=tuple)


def _opt(*rows: tuple[Any, str, str]) -> tuple[Option, ...]:
    return tuple(Option(v, ja, en) for v, ja, en in rows)


def _pre(*rows: tuple[Any, str, str]) -> tuple[Preset, ...]:
    return tuple(Preset(v, ja, en) for v, ja, en in rows)


_DEFAULT_CUSTOM_INSTRUCTIONS: tuple[dict[str, Any], ...] = (
    {
        "id": "instruct",
        "name": "自由指示で文章作成（その場で何でも作成）",
        "name_en": "Free Instruction (Create anything on the fly)",
        "desc": (
            "テンプレにない文章も、話した内容をそのまま指示として受け取り、"
            "完全に言った通りの文章を作って入力欄に入れます。"
        ),
        "desc_en": (
            "Transforms speech directly into the exact requested text, "
            "following any custom instruction on the fly."
        ),
        "prompt": (
            "あなたはユーザー専属の最高峰文章作成エキスパートです。\n"
            "ユーザーが話した以下の音声を【文章作成の要望・指示】として解釈し、"
            "ユーザーが求めている意図に100%合致した完成文章・テキストを作成してください。\n"
            "・「〜〜の文章を作って」「〜〜について書いて」「〜〜宛のメールにして」"
            "「〜〜風にして」「〜〜を要約して」など、ユーザーが発言した要望・条件・トーン・文体に"
            "完璧に従って文章を作成してください。\n"
            "・指示と対象のテキストが混ざっている場合（例：「これをもっと柔らかく断る文章にして、明日は都合が悪いです」）は、"
            "指示を反映した完成形のみを出力してください。\n"
            "・挨拶、前置き、「以下が作成した文章です」などの返答、解説、思考プロセスは絶対に含めず、"
            "入力欄に直接入れるべき完成した文章のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": True,
    },
    {
        "id": "translate_en",
        "name": "英語に翻訳",
        "name_en": "Translate to English",
        "desc": "あらゆる言語を自然で流暢な英語に翻訳します。",
        "desc_en": "Translates any speech into natural and fluent English.",
        "prompt": (
            "あなたはプロフェッショナルなバイリンガル翻訳エキスパートです。\n"
            "以下の音声を、文脈に最も適した極めて自然で流暢な英語に翻訳してください。\n"
            "・直訳を避け、ネイティブが実際に使う自然なイディオムや表現を用いてください。\n"
            "・ビジネス・日常会話の適切なニュアンスと敬意を維持してください。\n"
            "・前置き、挨拶、解説、引用符などは一切含めず、翻訳後の英文のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "prompt_creator",
        "name": "AIプロンプト作成（AIへの指示文）",
        "name_en": "AI Prompt Creator",
        "desc": "話した内容から、ChatGPTやClaude、AIエージェントにそのまま投げられる洗練された高品質プロンプトを作成します。",
        "desc_en": "Transforms speech into a well-crafted prompt ready for ChatGPT, Claude, or AI agents.",
        "prompt": (
            "あなたは世界最高峰のプロンプトエンジニアです。\n"
            "ユーザーが話した以下の要望・アイデア・指示内容をもとに、"
            "ChatGPTやClaudeなどの高性能AIが最高の回答を生成できるように設計された、"
            "洗練された高品質なプロンプトを作成してください。\n"
            "・目的・前提・具体的要件・制約条件・期待する出力フォーマットを論理的に構造化してください。\n"
            "・解説や前置き、「プロンプトを作成しました」等の発言は一切含めず、"
            "入力欄に貼り付けてそのままAIに送信できるプロンプト本文のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": True,
    },
    {
        "id": "polite",
        "name": "丁寧語・敬語に整える",
        "name_en": "Convert to Polite Japanese",
        "desc": "くだけた話し言葉を自然な「です・ます調」の敬語に整えます。",
        "desc_en": "Rewrites speech into polite Japanese with desu/masu endings.",
        "prompt": (
            "あなたは文章推敲のエキスパートです。\n"
            "以下の話し言葉・くだけた表現の日本語音声を、"
            "親しみやすく好印象な自然な「です・ます調（丁寧語）」に整えてください。\n"
            "・堅苦しすぎず、チャットや連絡で心地よい自然な表現にしてください。\n"
            "・解説や前置き、引用符は一切含めず、整えたテキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "professional",
        "name": "ビジネス敬語に変換",
        "name_en": "Business Polite Japanese",
        "desc": (
            "メッセージを社内外のビジネスチャットやメールに適した洗練された敬語に変換します。"
        ),
        "desc_en": (
            "Rewrites speech into polite, professional business Japanese."
        ),
        "prompt": (
            "あなたはエグゼクティブビジネスコミュニケーションの専門家です。\n"
            "以下の日本語音声を、社内外のビジネスチャットやメールでそのまま使える、"
            "洗練された信頼感のあるビジネス敬語の文章に書き直してください。\n"
            "・適切な敬語体系（尊敬語・謙譲語・丁寧語）を正しく使い分け、二重敬語を避けてください。\n"
            "・依頼には適切なクッション言葉を添え、角の立たない論理的な文章にしてください。\n"
            "・前置きや解説は含めず、結果のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "summary",
        "name": "要約（箇条書き）",
        "name_en": "Summarise as Bullet Points",
        "desc": "話した内容の要点を抽出し、簡潔な箇条書きでまとめます。",
        "desc_en": "Extracts key points and formats as clean bullet points.",
        "prompt": (
            "あなたは一流のビジネスアナリストです。\n"
            "以下の日本語音声の要点を抽出し、一目で理解できる簡潔で分かりやすい箇条書きでまとめてください。\n"
            "・不要な重複やつなぎ言葉は排除し、情報密度を高めてください。\n"
            "・解説や前置きは含めず、箇条書きのテキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "task_list",
        "name": "タスク・箇条書き整理",
        "name_en": "Task & Bullet List",
        "desc": (
            "話した内容からTODOやタスクを抽出し、見やすいリストに構造化します。"
        ),
        "desc_en": (
            "Extracts key points and action items into a clean bullet list."
        ),
        "prompt": (
            "以下の音声から重要ポイントややるべきタスク・TODOを整理し、"
            "実行順序がわかる見やすい番号付きリストまたは箇条書き形式に構造化してください。\n"
            "・主語とアクションを明確にしてください。\n"
            "・前置きや解説は含めず、結果のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "slack_report",
        "name": "Slack業務報告風に整理",
        "name_en": "Slack Work Report Format",
        "desc": "業務チャットですぐ送れる報告形式（見出し・詳細・ネクストアクション）に整えます。",
        "desc_en": "Formats speech as a concise Slack work report with headings.",
        "prompt": (
            "以下の音声を、SlackやTeams等の業務チャットでそのまま送れる"
            "簡潔で整理された報告文（【進捗・共有事項】【詳細】【ネクストアクション】の見出し・箇条書き）"
            "に整形してください。解説や前置きは含めず、本文のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "terminal_helper",
        "name": "ターミナルヘルパー",
        "name_en": "Terminal Helper",
        "desc": "話した指示を実行可能なシェル/ターミナルコマンドに変換します。",
        "desc_en": (
            "Converts spoken instructions into executable terminal commands."
        ),
        "prompt": (
            "以下の指示を実行可能な正確で安全なシェル/ターミナルコマンド"
            "（PowerShellまたはBash/Linux）に変換してください。\n"
            "・マークダウンのコードブロックや解説は含めず、コマンド文字列のみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "ai_auto_edit",
        "name": "AI自動編集（言い直し・構造化）",
        "name_en": "AI Auto-Edit",
        "desc": "言い直しを検出して意図を反映し、リスト化・構造化して読みやすく整えます。",
        "desc_en": "Automatically fixes restatements, repairs speech, and formats structure.",
        "prompt": (
            "以下の音声を自然で読みやすい文章に自動編集してください。\n"
            "・「えーと」「あの」「まあ」などのフィラーを削除する\n"
            "・言い直しや自己訂正を検出し、最終的な意図を反映する\n"
            "・タスク一覧や箇条書きの意図がある場合はリスト化・構造化して読みやすくフォーマットする\n"
            "・解説や前置き、引用符などは一切含めず、編集後のテキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": False,
        "api_required": False,
    },
    {
        "id": "chaos_mode",
        "name": "カオスモード",
        "name_en": "Chaos Mode",
        "desc": "ワイルドなトーン、絵文字、ミームエネルギーを注入します。",
        "desc_en": "Injects wild tone, emojis, and meme energy.",
        "prompt": (
            "以下の音声を、最高にテンションが高く、"
            "絵文字とネットミーム感あふれるワイルドでエネルギッシュな口調にアレンジしてください。"
            "前置きは不要で結果のみ出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": False,
        "api_required": False,
    },
    {
        "id": "buzzword_mode",
        "name": "バズワードモード",
        "name_en": "Buzzword Mode",
        "desc": (
            "シンプルなアイデアをバズワード満載のビジネス構想に膨らませます。"
        ),
        "desc_en": "Inflates simple ideas into buzzword-laden business concepts.",
        "prompt": (
            "以下のシンプルなアイデアを、カタカナ語・バズワード"
            "（アグリー、コミット、シナジー、解像度、レバレッジ等）を駆使した"
            "意識の高いビジネス構想風に膨らませて出力してください。"
            "前置きは不要です:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": False,
        "api_required": False,
    },
    {
        "id": "reply_generator",
        "name": "返信文ジェネレーター",
        "name_en": "Reply Generator",
        "desc": (
            "コピーした相手メッセージを参照し、失礼のない返信文を作成します。"
        ),
        "desc_en": (
            "Generates a polite reply referring to the copied message in "
            "the clipboard."
        ),
        "prompt": (
            "あなたはビジネスおよびチャットコミュニケーションの達人です。\n"
            "相手からのメッセージに対して、ユーザーの意図を汲み取った"
            "失礼のない完璧な返信文を作成してください。\n"
            "【相手からのメッセージ】\n{clipboard}\n\n"
            "【ユーザーからの返信要望・要件】\n{text}\n\n"
            "・相手への敬意と文脈に合わせた適切なトーンで作成してください。\n"
            "・解説や前置き、「以下が返信文です」等は絶対に含めず、"
            "返信本文のみを出力してください。"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "meeting_minutes",
        "name": "議事録・ミーティング要約",
        "name_en": "Meeting Minutes & Summary",
        "desc": "発言内容から決定事項・検討事項・ネクストアクションを整理します。",
        "desc_en": (
            "Organises spoken meeting notes into decisions, discussions, "
            "and next actions."
        ),
        "prompt": (
            "あなたは一流のプロジェクトマネージャーです。\n"
            "以下の音声（会議や打ち合わせの発言・要件）を、"
            "誰が見ても一目で状況が把握できる構造化された議事録にまとめてください。\n"
            "・【決定事項】\n"
            "・【検討事項・保留】\n"
            "・【ネクストアクション（タスク・担当・期限）】\n"
            "・解説や前置きは含めず、議事録テキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "proofread",
        "name": "文章推敲・校正",
        "name_en": "Proofread & Polish",
        "desc": "誤字脱字、助詞、主述のねじれを正し、美しい日本語に推敲します。",
        "desc_en": "Fixes typos, particles, and awkward phrasing naturally.",
        "prompt": (
            "あなたは最高峰の文章校正・エディターです。\n"
            "以下の音声書き起こしテキストを、意味や主張を変えずに、"
            "最も美しく自然で読みやすい日本語に推敲・校正してください。\n"
            "・誤字脱字、てにをは（助詞）の誤り、主語と述語のねじれを修正する。\n"
            "・同じ語尾の連続や冗長な重複表現を避けてスムーズにする。\n"
            "・解説や前置き、引用符は一切含めず、推敲後のテキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "standardize",
        "name": "標準語・公用文化",
        "name_en": "Standardise Speech",
        "desc": "くだけた口語・方言・スラングを公用文向けの端正な文体に整えます。",
        "desc_en": "Converts casual colloquialisms and slang into standard Japanese.",
        "prompt": (
            "あなたは公用文・ビジネス文書の校閲官です。\n"
            "以下の音声に含まれる方言、俗語、スラング、砕けた口語表現を、"
            "公的な文書や社内報告で通じる端正で格調高い標準語・共通語の文体に書き換えてください。\n"
            "・前置きや解説は含めず、整えたテキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "brainstorm",
        "name": "アイデア・企画骨子化",
        "name_en": "Brainstorm to Proposal",
        "desc": "思いつきのアイデアやメモをロジカルな企画案に展開・構造化します。",
        "desc_en": "Structures raw brainstorm ideas into a logical proposal outline.",
        "prompt": (
            "あなたは新規事業・企画立案のエキスパートです。\n"
            "ユーザーが話した以下のアイデアの断片やメモから、"
            "実現可能性の高いロジカルな企画骨子に構造化・展開してください。\n"
            "・【コアコンセプト】（一言で表す価値）\n"
            "・【背景とターゲット課題】\n"
            "・【具体的な施策・アイデアの骨子】\n"
            "・【期待される効果・ベネフィット】\n"
            "・前置きや解説は含めず、企画骨子のテキストのみを出力してください:\n\n{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
    {
        "id": "smart_calc",
        "name": "スマート計算・日付・便利ツール",
        "name_en": "Smart Calculator & Date Tool",
        "desc": (
            "話した四則演算、税込・税抜計算、割引、明日の日付や来週の曜日を"
            "自動計算して入力します。"
        ),
        "desc_en": (
            "Calculates math formulas, tax, discounts, and relative dates "
            "on the fly."
        ),
        "prompt": (
            "あなたは優秀な計算・日付変換アシスタントです。\n"
            "ユーザーが話した以下の内容から、四則演算、税込・税抜計算、"
            "割引計算、単位換算、または日付（今日、明日、来週の曜日など）を"
            "正確に計算・特定し、結果の数値・テキストのみを出力してください。\n"
            "・前置き、挨拶、解説は絶対に含めず、結果のみを出力してください:\n\n"
            "{text}"
        ),
        "hotkey": "",
        "enabled": True,
        "api_required": False,
    },
)

_DEFAULT_AI_AUTO_EDIT_PROMPT = (
    "以下の音声を自然で読みやすい文章に自動編集してください。\n"
    "・「えーと」「あの」「まあ」などのフィラーを削除する\n"
    "・言い直しや自己訂正を検出し、最終的な意図を反映する\n"
    "・タスク一覧や箇条書きの意図がある場合はリスト化・構造化して読みやすくフォーマットする\n"
    "・解説や前置き、引用符などは一切含めず、編集後のテキストのみを出力してください:\n\n{text}"
)


PRESETS: tuple[dict[str, Any], ...] = (
    {
        "id": "chat",
        "name": "チャット・SNS即時送信",
        "name_en": "Chat & Instant Send (Slack / LINE / Teams)",
        "desc": "話して Enter で即送信。送信キーの待ち時間を安全に確保し、文字が入ってから確実に送信します。",
        "desc_en": (
            "Enter sends immediately while recording. Safe delay ensures "
            "text lands before Enter."
        ),
        "icon": "chat",
        "badge": "人気",
        "badge_en": "Popular",
        "settings": {
            "enter_sends": True,
            "send_key": "enter",
            "enter_delay_ms": 220,
            "stop_on_click": "outside",
            "full_stops": "off",
            "punctuation_density": "few",
            "save_to_clipboard": "fallback",
        },
    },
    {
        "id": "writing",
        "name": "長文執筆・レポート作成",
        "name_en": "Document & Long Writing (Word / Notion)",
        "desc": "Enter を押しても誤送信せず、クリックしても止まりません。文字の選択や推敲をしながらじっくり書けます。",
        "desc_en": (
            "Enter does not send, clicks do not stop recording. Great for "
            "long writing & editing."
        ),
        "icon": "edit",
        "badge": "執筆",
        "badge_en": "Writing",
        "settings": {
            "enter_sends": False,
            "stop_on_click": "off",
            "full_stops": "all",
            "punctuation_density": "normal",
            "shortcut_mode": "toggle",
            "save_to_clipboard": "fallback",
        },
    },
    {
        "id": "coding",
        "name": "プログラミング・CLI",
        "name_en": "Coding & Terminal (VS Code / CLI)",
        "desc": "クリップボードを汚さず直接キー入力。句読点なし・半角英数重視でコードやコマンドを指示できます。",
        "desc_en": (
            "Direct typing without touching clipboard. No punctuation, "
            "half-width numbers."
        ),
        "icon": "terminal",
        "badge": "開発",
        "badge_en": "Dev",
        "settings": {
            "enter_sends": False,
            "stop_on_click": "off",
            "full_stops": "off",
            "punctuation_density": "none",
            "paste_method": "direct",
            "numbers_format": "half",
        },
    },
    {
        "id": "beginner",
        "name": "初心者・安心スタンダード",
        "name_en": "Standard & Safe (Recommended for beginners)",
        "desc": "迷ったらこれ。どこをクリックしても停止し、失敗時もクリップボードにバックアップされる安心設定です。",
        "desc_en": (
            "Balanced setup: clicks stop safely anywhere, backup on "
            "clipboard if typing fails."
        ),
        "icon": "shield",
        "badge": "標準",
        "badge_en": "Default",
        "settings": {
            "enter_sends": True,
            "send_key": "enter",
            "enter_delay_ms": 200,
            "stop_on_click": "any",
            "full_stops": "smart",
            "punctuation_density": "normal",
            "save_to_clipboard": "fallback",
        },
    },
)


CATEGORIES: tuple[Category, ...] = (
    # ============================================================= 一般
    Category(
        "general", "sliders", "一般", "General",
        "ショートカットと、文字の送り方", "Shortcuts and how text is sent",
        (
            Group("おすすめ使用感プリセット", "Usage Presets", (
                Item("preset_selector", "custom",
                     "使用感プリセット（ワンクリック適用）",
                     "Usage Presets (One-click apply)",
                     "用途や好みに合わせて、ショートカット・Enter送信・クリック停止・"
                     "句読点の設定をまとめて切り替えます。",
                     "Switch shortcuts, Enter-send, click-stop, and "
                     "punctuation settings all at once.",
                     panel="presets"),
            )),
            Group("ショートカット", "Shortcuts", (
                Item("hotkey", "hotkey",
                     "録音のショートカット", "Recording shortcut",
                     "このキーを押す → 録音が始まる。もう一度押す → "
                     "話した文字が入力欄に入る。\n"
                     "変えるときは、右のボタンを押してから使いたいキー"
                     "（例：無変換）を押します。",
                     "Press to start recording, press again to confirm and type. "
                     "To change it, press the button on the right, then the "
                     "key you want to use. Muhenkan is recommended on JIS.",
                     default="ctrl+space"),
                Item("cancel_hotkey", "hotkey",
                     "キャンセルのショートカット", "Cancel shortcut",
                     "録音中だけ効きます。押すと録音をやめ、"
                     "話した内容を入力せずに破棄します。",
                     "Only active while recording. Stops and discards anything "
                     "not yet typed.",
                     default="esc", advanced=True),
                Item("screen_assistant_hotkey", "hotkey",
                     "画面AIアシスタント（ジャービス）", "Screen AI Assistant",
                     "押す → 画面のスクリーンショットを撮り、音声指示"
                     "（「カレンダーに入れて」「これ要約して」など）を"
                     "聞いて Gemini AI が自動実行します。",
                     "Captures the screen and executes your spoken instructions "
                     "via Gemini (e.g. add to Google Calendar, summarize).",
                     default="ctrl+alt+j", advanced=True),
                # ★既定は Google レンズ（2026-10-25 に既定化）。
                # 画像検索の質は本家に任せ、内蔵版は Google アプリが
                # 無いときの受け皿として残す。既存の設定ファイルには
                # 旧既定（builtin）が書き込まれているので、そちらは
                # configstore._migrate が 1 回だけ寄せる。
                Item("snip_engine", "segments",
                     "かこって検索のエンジン", "Circle-to-search engine",
                     "画面アシスタント（かこって検索）で検索する先です。\n"
                     "・Google レンズ → Google アプリのレンズを呼びます"
                     "（おすすめ）。Google アプリが入っていないときは、"
                     "自動で内蔵版が開きます。\n"
                     "・内蔵 → koe-type の画面アシスタントを開きます。",
                     "Where circle-to-search searches. 'Google Lens' "
                     "calls the Google app's Lens (recommended); if "
                     "the Google app is not installed, the built-in "
                     "assistant opens instead. 'Built-in' always opens "
                     "koe-type's own screen assistant.",
                     default="google",
                     options=_opt(("builtin", "内蔵（今までどおり）",
                                   "Built-in (as before)"),
                                  ("google", "Google レンズ",
                                   "Google Lens")),
                     advanced=True),
                # ★このキーは koe-type が横取りするものではなく、
                # Google アプリへ「送る」組み合わせ。Google アプリ側の
                # レンズ用ショートカットと一致していないと届かない。
                # あらかじめ入っている組み合わせは、Google アプリ側で
                # 変えていなければそのまま使える（2026-10-25 実地で
                # 動作確認済み）。空にしたときは何も送らない
                # （app/googlelens.py の説明も参照）。
                Item("google_lens_hotkey", "hotkey",
                     "Google レンズのショートカット（送信用）",
                     "Google Lens shortcut (sent to the Google app)",
                     "Google アプリの「画面キャプチャ（レンズ）」の"
                     "ショートカットと同じ組み合わせを設定すると、"
                     "かこって検索のエンジンが Google レンズのときに"
                     "そのキーを送ってレンズを呼びます。\n"
                     "最初から入っている組み合わせは、Google アプリの"
                     "レンズ用ショートカットとして使われているものです。"
                     "Google アプリ側で変更した場合は、ここも同じ"
                     "組み合わせに合わせてください。空のままでは"
                     "何も送りません。",
                     "When the engine above is Google Lens, this key "
                     "combination is sent to the Google app to open Lens. "
                     "It must match the screenshot (Lens) shortcut in "
                     "the Google app's own settings. The prefilled "
                     "combination is the one the Google app uses unless "
                     "you changed it there. Left blank, nothing is sent.",
                     default="ctrl+alt+shift+l", advanced=True),
                Item("shortcut_mode", "segments",
                     "ショートカットの動作", "Shortcut behaviour",
                     "・押すたび切り替え → 1回押して話し、もう1回押すと入る"
                     "（ふつうはこれ）\n"
                     "・長押しの間だけ → 押しているあいだだけ録音。指を離すと入る"
                     "（うっかり録音しっぱなしを防げる）\n"
                     "・おまかせ → 短く押せば切り替え、長く押せば離したときに入る",
                     "Toggle starts on one press and stops on the next. "
                     "Push-to-talk records only while the key is held. "
                     "Auto uses toggle on short press and push-to-talk on hold.",
                     default="toggle",
                     options=_opt(("toggle", "押すたび切り替え", "Toggle"),
                                  ("hold", "長押しの間だけ", "Push to talk"),
                                  ("auto", "おまかせ", "Auto"))),
                Item("hotkey_double_tap_history", "bool",
                     "録音キーの二度押しで履歴を開く",
                     "Open history on double-press",
                     "オン → 録音キーを押してすぐ（0.4秒以内）に"
                     "もう一度押すと、その録音を捨てて、最近の"
                     "文字起こしの一覧を開きます。選ぶと、"
                     "クリップボードへコピーしてその場に貼り付けます。"
                     "文字が入力欄に入らなかったときの貼り直しに"
                     "使います。\n"
                     "オフ → 二度押しはふつうの停止として働きます。",
                     "On: pressing the recording key again within "
                     "0.4s discards that take and opens your recent "
                     "transcripts. Picking one copies it and pastes "
                     "it at the cursor. Off: the second press just "
                     "stops the recording.",
                     default=True),
                Item("fix_last_hotkey", "hotkey",
                     "直前の入力を直すショートカット",
                     "Fix the last input shortcut",
                     "押す → 直前に入れた文を、その場で直せる窓を"
                     "開きます。直した箇所は「学習候補」になり、"
                     "採用したものだけが次回から自動で直ります。"
                     "同音異義語（司会／視界など）は青く光り、"
                     "クリックで候補から差し替えられます。\n"
                     "空にしておくと無効になります。",
                     "Opens a small editor for the text you just "
                     "typed, so you can fix recognition mistakes. "
                     "Checked corrections are learned and applied "
                     "automatically next time. Homophones are "
                     "highlighted and can be swapped from a menu. "
                     "Leave blank to disable.",
                     default="ctrl+alt+z", advanced=True),
                Item("stop_on_click", "choice",
                     "クリックしたときの動作（文字選択と上書き）",
                     "When you click with mouse",
                     "録音中や文字起こし中にマウスをクリックしたときの動作です。"
                     "「止めない」にすると、直したい部分をカーソルで青く選択したまま"
                     "話して上書きできるようになります。"
                     "「入力欄の外を押したら」なら、送信ボタンなど別の場所をクリックしたときだけ止まります。",
                     "What happens when you click the mouse while recording. "
                     "Setting to 'Never' allows selecting text with your cursor "
                     "to overwrite it by speaking. 'Only outside' stops only when "
                     "clicking outside the current input window.",
                     default="outside",
                     options=_opt(("off", "止めない（文字を選択して上書きできる）",
                                    "Never (allow selection overwrite)"),
                                  ("outside", "入力欄の外を押したら止める",
                                    "Only outside the input box"),
                                  ("any", "どこを押しても止める（送信ボタン等）",
                                    "Anywhere")),
                     advanced=True),
                # ★よそをクリックしたり、ほかの窓を見たりしているあいだに
                # 出てきた文字の行き先。前はクリップボードへ逃がすだけで、
                # 利用者には「文字が入らない」ように見えていた（2026-10-11）。
                Item("away_text", "segments",
                     "よそを見ているあいだの文字", "Text while you are elsewhere",
                     "話している途中にほかの窓をクリックしたり、別のアプリに"
                     "切り替えたりしたときの、残りの文字の行き先です。\n"
                     "・元の欄に戻ったら入れる → 取っておき、元の窓に戻った"
                     "ところで入れる。3 分戻らなければクリップボードへ"
                     "（おすすめ）\n"
                     "・クリップボードへ → すぐクリップボードに入れる。"
                     "自分で Ctrl+V で貼る\n"
                     "録音を止めるかどうかは、上の「クリックしたときの動作」の"
                     "とおりです。",
                     "Where the rest of your words go when you click another "
                     "window or switch apps while speaking. 'When I come "
                     "back' keeps them and types them once you return to the "
                     "original window (falls back to the clipboard after 3 "
                     "minutes). 'Clipboard' copies them right away.",
                     default="wait",
                     options=_opt(("wait", "元の欄に戻ったら入れる",
                                   "When I come back"),
                                  ("clipboard", "クリップボードへ",
                                   "Clipboard"))),
                Item("restore_focus_on_finish", "bool",
                     "音声入力終了時に元の入力欄へ自動で戻す",
                     "Auto-restore focus to input field on finish",
                     "他のアプリを開いてスクロールしたり、チャットの履歴欄をクリックして"
                     "参照しながら話していても、音声入力が終わった瞬間に自動で元の入力欄へ"
                     "フォーカスを復帰させて文字を流し込みます。文字が入らない事故を完全に防ぎます。",
                     "Automatically restores keyboard focus to the original input "
                     "field when voice typing finishes, even if you clicked elsewhere "
                     "or scrolled other windows while speaking.",
                     default=True,
                     advanced=False),
            )),
            Group("文字の入力とクリップボード", "Typing and clipboard", (
                Item("paste_method", "choice",
                     "文字の入力方式", "Input method",
                     "入力欄へ文字を入れる方式です。"
                     "「クリップボード貼り付け」は Ctrl+V で瞬時に入力します（元のクリップボードは復元されます）。"
                     "「直接キー入力」はクリップボードを一切使わず、1文字ずつ直接キーとして送信します。"
                     "クリップボードの内容や履歴を絶対に汚したくない場合におすすめです。",
                     "How transcribed text is typed. 'Clipboard paste' uses "
                     "Ctrl+V quickly and restores your original clipboard. "
                     "'Direct typing' sends keystrokes directly without using "
                     "the clipboard at all.",
                     default="auto",
                     options=_opt(("auto", "クリップボード貼り付け（高速・既定）",
                                   "Clipboard paste (fast, default)"),
                                  ("direct", "直接キー入力（クリップボードを使わない）",
                                   "Direct typing (never uses clipboard)")),
                     advanced=True),
                Item("save_to_clipboard", "choice",
                     "クリップボードへの保存", "Save to clipboard",
                     "文字起こしした内容をクリップボードに保存するかを選びます。"
                     "「一切保存しない」にすると、途中で止めた時やウィンドウが変わった時でも"
                     "クリップボードを書き換えません（履歴には残ります）。",
                     "Whether to save transcribed text to the clipboard. "
                     "Choosing 'Never save' ensures your clipboard is never "
                     "modified even if recording stops or pasting fails.",
                     default="fallback",
                     options=_opt(("fallback", "入力できなかった時だけ保存（既定）",
                                   "Only when pasting fails (default)"),
                                  ("never", "一切保存しない（履歴のみに記録）",
                                   "Never save (history only)"),
                                  ("always", "常に保存する（通常入力時も残す）",
                                   "Always save to clipboard")),
                     advanced=True),
            )),
            Group("送信", "Sending", (
                Item("enter_sends", "bool",
                     "録音中に Enter で送信する", "Enter sends while recording",
                     "オンのとき、録音中の Enter は「停止 → 残りを入力 → 送信キー」"
                     "の順で動きます。オフにすると Enter を横取りしません。",
                     "When on, Enter while recording stops, types the rest, then "
                     "sends. When off, Enter is never intercepted.",
                     default=True, advanced=True),
                Item("send_key", "segments",
                     "送信に使うキー", "Key used to send",
                     "入力し終わってから送るキーです。"
                     "Slack など Ctrl+Enter で送るアプリ向け。",
                     "Sent after the text is typed. Use Ctrl+Enter for apps "
                     "like Slack.",
                     default="enter",
                     options=_opt(("enter", "Enter", "Enter"),
                                  ("ctrl+enter", "Ctrl+Enter", "Ctrl+Enter"),
                                  ("shift+enter", "Shift+Enter", "Shift+Enter")),
                     advanced=True),
                Item("enter_delay_ms", "int",
                     "送信までの待ち", "Delay before sending",
                     "文字が入り終わってから送信キーを送るまでの間。"
                     "送信が速すぎて取りこぼすアプリでは長くします。",
                     "Pause between typing the text and sending. Increase it "
                     "for apps that send before the text lands.",
                     default=200, minimum=0, maximum=1000, step=20,
                     unit="ms_sec", zero_ja="待たない", zero_en="No delay",
                     presets=_pre((100, "速い", "Fast"), (200, "標準", "Normal"),
                                  (400, "ゆっくり", "Slow")), advanced=True),
            )),
            Group("koe-type を使わないアプリ", "Apps that keep the shortcut", (
                Item("excluded_apps", "applist",
                     "koe-type を使わないアプリ", "Apps to leave alone",
                     "ここに入れた実行ファイルが前面にあるときは、ショートカットを"
                     "横取りしません（例：Code.exe なら VS Code の Ctrl+Space が"
                     "そのまま使えます）。",
                     "While one of these executables is in the foreground the "
                     "shortcut is passed through untouched — e.g. Code.exe keeps "
                     "VS Code's Ctrl+Space working.",
                     default=["Code.exe"], advanced=True),
            )),
        )),

    # ============================================================= 音声
    Category(
        "audio", "mic", "音声", "Audio",
        "マイクと、文の区切りかた", "Microphone and phrase detection",
        (
            Group("入力", "Input", (
                Item("microphone", "choice",
                     "マイク", "Microphone",
                     "声を拾うマイクを選びます。\n"
                     "ヘッドセットや外付けマイクにする → まわりの音やキーを打つ音を"
                     "拾いにくくなり、聞き間違いが減る。",
                     "Pick the input device. Reopen this window after plugging "
                     "in a new microphone.",
                     default="", options_from="microphones", restart=True),
                Item("speaker_focus", "segments",
                     "話者フォーカス（他人の声の遮断）",
                     "Speaker focus (isolate single speaker)",
                     "一人で話す時に、同室の他人の声や遠くの雑音を拾わないようにします。\n"
                     "・標準 → 遠くの声や背景の会話を自動で抑えます（おすすめ）\n"
                     "・強力 → 口元の主話者の声だけに集中し、周囲の声を厳格に遮断します\n"
                     "・オフ → 小さな声やまわりの音もそのまま拾います",
                     "Suppresses other people's voices in the room and background "
                     "chatter so only the main speaker is picked up.",
                     default="normal",
                     options=_opt(("off", "オフ", "Off"),
                                  ("normal", "標準", "Normal"),
                                  ("strong", "強力", "Strong"))),
            )),
            Group("自動で止める", "Stopping by itself", (
                Item("stop_on_silence_ms", "segments",
                     "静かになったら止める", "Stop after silence",
                     "この長さだけ何も聞こえなかったら、録音を自動で止めます。"
                     "切り忘れたまま、話した内容が別の場所に入るのを防ぎます。",
                     "If nothing is heard for this long, recording stops by "
                     "itself. This keeps a forgotten recording from typing "
                     "into somewhere unexpected.",
                     default=10000,
                     options=_opt((0, "止めない", "Never"),
                                  (5000, "5秒", "5 s"),
                                  (10000, "10秒", "10 s"),
                                  (20000, "20秒", "20 s")),
                     advanced=True),
                Item("stop_on_window_change", "choice",
                     "別のウィンドウに移ったら",
                     "When you move to another window",
                     "録音中にほかのアプリへ移ったときの動きです。"
                     "「止める」にすると、移った先には入力せず、クリップボード"
                     "と履歴に残します（話した内容が、思わぬ場所に入るのを"
                     "防げます）。通知やメニューのように一瞬だけ出る窓では"
                     "止めません。",
                     "What happens if you move to another app while "
                     "recording. “Stop” keeps what you said on the clipboard "
                     "and in the history instead of typing it into the new "
                     "window, so nothing lands anywhere unexpected. Brief "
                     "pop-ups such as notifications don't count.",
                     default="stop",
                     options=_opt(("stop", "録音を止める", "Stop recording"),
                                  ("keep", "そのまま続ける", "Keep recording")), advanced=True),
            )),
            Group("取りこぼし防止", "Don't miss a word", (
                Item("mic_preroll_ms", "segments",
                     "話し始めを逃さない", "Catch the start of your sentence",
                     "マイクを開いたままにして、ショートカットを押す前の音も"
                     "使います。押す前に話し始めても出だしが切れません。"
                     "ためておく音はメモリの上だけで、保存も文字起こしもしません"
                     "（Windows のマイク使用中の表示は出たままになります）。",
                     "Keeps the microphone open so the moment before you press "
                     "the shortcut is included — so the first word is never "
                     "clipped. The buffered audio stays in memory only and is "
                     "never saved or transcribed. Windows will show the "
                     "microphone as in use.",
                     default=1000,
                     options=_opt((0, "使わない", "Off"),
                                  (500, "0.5秒", "0.5 s"),
                                  (1000, "1秒", "1 s"),
                                  (1500, "1.5秒", "1.5 s")), advanced=True),
                Item("post_roll_ms", "segments",
                     "語尾を切り落とさない", "Keep the end of your sentence",
                     "止めたあとも少しだけ録り続けて、最後のひと言が"
                     "切れるのを防ぎます。",
                     "Keeps recording for a moment after you stop, so the last "
                     "word is not cut off.",
                     default=400,
                     options=_opt((0, "使わない", "Off"),
                                  (250, "0.25秒", "0.25 s"),
                                  (400, "0.4秒", "0.4 s"),
                                  (700, "0.7秒", "0.7 s")), advanced=True),
            )),
            Group("区切りの判定", "Phrase detection", (
                Item("pause_ms", "int",
                     "区切りとみなす無音の長さ", "Silence that ends a phrase",
                     "この長さだけ静かになったら、そこまでを文字にして入力します。"
                     "短くすると細かく入り、長くすると文がまとまります。"
                     "落ち着いてゆっくり話したいときは長めにします。",
                     "Once you stay quiet this long, the phrase so far is "
                     "transcribed and typed. Shorter means smaller, more "
                     "frequent insertions. Choose relaxed if you pause often.",
                     default=700, minimum=200, maximum=2000, step=50,
                     unit="ms_sec",
                     presets=_pre((400, "短め", "Short"), (700, "標準", "Normal"),
                                  (1200, "長め", "Long"),
                                  (1800, "とてもゆっくり", "Very relaxed")),
                     advanced=True),
                Item("vad_sensitivity", "segments",
                     "マイクの感度", "Microphone sensitivity",
                     "高いほど小さな声も拾います。まわりの音で勝手に区切られる"
                     "ときは下げてください。",
                     "Higher picks up quieter speech. Lower it if background "
                     "noise keeps triggering the recogniser.",
                     default=30,
                     options=_opt((60, "とても低い", "Lowest"),
                                  (45, "低い", "Low"),
                                  (30, "標準", "Normal"),
                                  (20, "高い", "High"),
                                  (14, "とても高い", "Highest")), advanced=True),
                Item("max_segment_ms", "int",
                     "ひと区切りの最長", "Longest single chunk",
                     "間を置かずに話し続けたときは、この長さでいったん区切ります。"
                     "長すぎると、モデルが聞き取れなくなることがあります。",
                     "If you never pause, the phrase is cut at this length "
                     "anyway. Too long and the model starts to struggle.",
                     default=10000, minimum=5000, maximum=60000, step=1000,
                     unit="ms_sec",
                     presets=_pre((8000, "短め", "Short"),
                                  (10000, "標準", "Normal"),
                                  (20000, "長め", "Long")), advanced=True),
                Item("max_record_ms", "int",
                     "最大録音時間", "Maximum recording time",
                     "録音開始からこの時間が経つと自動で止まります"
                     "（切り忘れ対策）。",
                     "Recording stops by itself after this long, in case you "
                     "forget to stop it.",
                     default=300000, minimum=0, maximum=1800000, step=30000,
                     unit="ms_min", zero_ja="無制限", zero_en="No limit", advanced=True),
            )),
            Group("ふるまい", "Behaviour", (
                Item("sound_feedback", "bool",
                     "録音の開始・停止で音を鳴らす",
                     "Play a sound when recording starts and stops",
                     "オン → 録音の始まりと終わりに小さく「ピッ」と鳴る。"
                     "画面を見なくても、録音しているか耳で分かる。\n"
                     "オフ → 音は鳴らない。",
                     "A very short, quiet blip.",
                     default=False),
                Item("sound_theme", "segments",
                     "効果音の音色", "Sound tone",
                     "録音開始・終了・中止の合図の音色を選べます。",
                     "Tone style for recording start, stop, and cancel.",
                     default="default",
                     options=_opt(("default", "標準", "Default"),
                                  ("soft", "ソフト", "Soft"),
                                  ("chime", "チャイム", "Chime"),
                                  ("mechanical", "メカニカル", "Mechanical")),
                     advanced=True),
                Item("sound_volume", "int",
                     "効果音の音量", "Sound volume",
                     "効果音の大きさを調整します（0〜100%）。",
                     "Volume level for feedback sounds (0-100%).",
                     default=80, minimum=0, maximum=100, step=5,
                     unit="%", advanced=True),
                Item("test_sound", "action",
                     "効果音をテスト", "Test sound",
                     "現在の音色と音量で開始音を再生して確認します。",
                     "Play the start sound with current tone and volume.",
                     panel="test_sound", advanced=True),
                Item("mute_while_recording", "bool",
                     "録音中はPCの音を消す", "Mute the PC while recording",
                     "録音している間だけスピーカーを消し、終わると元に戻します。"
                     "動画などの音をマイクが拾うのを防げます。",
                     "Mutes the speakers while recording and restores them "
                     "afterwards, so the microphone does not pick up what is "
                     "playing.",
                     default=False, advanced=True),
                Item("audio_ducking", "segments",
                     "録音中のPC音声（動画・音楽）の制御",
                     "PC audio during recording",
                     "NewsPicksやYouTubeなどの動画・音楽を再生中に話す際、"
                     "スピーカーの音をマイクが拾って誤入力するのを防止します。\n"
                     "・消音 → 録音中だけスピーカーを消音（動画の音の拾い込みを"
                     "完全に防止・おすすめ）\n"
                     "・音量を下げる → 録音中だけ動画の音量を小さくする\n"
                     "・そのまま → 音量を変えない\n"
                     "録音が終わると自動で元の音量に復帰します。",
                     "Control PC audio volume or mute while recording to prevent "
                     "videos (e.g. YouTube, NewsPicks) from being picked up.",
                     default="off",
                     options=_opt(("mute", "消音", "Mute"),
                                  ("duck", "音量を下げる", "Lower volume"),
                                  ("off", "そのまま", "Keep as is")),
                     advanced=False),
                Item("duck_ratio_pct", "int",
                     "音量を下げる割合", "Lowered volume level",
                     "録音中に音量を下げる場合、元の何％まで下げるかを指定します。",
                     "Target volume percentage while recording (5-50%).",
                     default=25, minimum=5, maximum=50, step=5,
                     unit="%", advanced=True),
            )),
        )),

    # ============================================================= 文字起こし
    Category(
        "transcription", "waveform", "文字起こし", "Transcription",
        "モデルの選択と、文字の整えかた", "Model choice and text clean-up",
        (
            Group("入力のタイミング", "When text appears", (
                Item("input_mode", "segments",
                     "文字が入るタイミング", "When text is typed",
                     "・話しながら → 話しているそばから、入力欄に文字が"
                     "どんどん入る（おすすめ）\n"
                     "・帯に先出し → 途中の文字は画面の帯にだけ出し、"
                     "ひと息ついたらまとめて入る\n"
                     "・ひと区切りごと → ひと息つくたびにまとめて入る。"
                     "PC がいちばん軽い",
                     "“While you speak” types into the box as you go "
                     "(default). It re-listens from the start of the phrase "
                     "every time, so by the time text is typed it already "
                     "has the surrounding words — measured on 125 s of real "
                     "speech, 3.6% vs 4.1% error. “Preview in the bar” "
                     "shows the in-progress text only in the bar and types "
                     "the whole phrase after a pause. “Phrase by phrase” "
                     "does not preview at all, and is the lightest.",
                     default="stream",
                     options=_opt(("stream", "話しながら（おすすめ）",
                                   "While you speak (recommended)"),
                                  ("preview", "帯に先出し",
                                   "Preview in the bar"),
                                  ("phrase", "ひと区切りごと（軽い）",
                                   "Phrase by phrase (lightest)"))),
                Item("stream_interval_ms", "int",
                     "聞き直す間隔", "How often it re-listens",
                     "「話しながら」のときだけ使います。"
                     "短いほど早く出ますが、PC が重くなります。"
                     "追いつかないときは自動で調整します。",
                     "Only used while you speak. Shorter means text appears "
                     "sooner but makes the PC work harder. koe-type adjusts "
                     "it automatically if it cannot keep up.",
                     default=450, minimum=200, maximum=2000, step=50,
                     unit="ms_sec",
                     presets=_pre((300, "速い", "Fast"),
                                  (450, "標準", "Normal"),
                                  (700, "ゆっくり", "Relaxed")), advanced=True),
                Item("stream_agree_rounds", "segments",
                     "文字を入れるまでの慎重さ",
                     "How sure it must be before typing",
                     "同じ聞こえ方が続いたら入力します。"
                     "少ないほど早く、多いほど確実です。"
                     "一度入れた文字は、あとから直せません。",
                     "It types once it has heard the same thing several "
                     "times in a row. Fewer is sooner, more is surer. "
                     "Text that has been typed is never rewritten.",
                     default=3,
                     options=_opt((2, "早め", "Sooner"),
                                  (3, "標準", "Normal"),
                                  (4, "慎重", "Surer")), advanced=True),
                Item("stream_workers", "segments",
                     "同時に処理する数", "How many at once",
                     "同時に処理すると、最初の文字が早く出ます。"
                     "増やすと PC の負担が増えます。",
                     "Processing more at once makes the first characters "
                     "appear sooner, at the cost of more load on the PC.",
                     default=2,
                     options=_opt((1, "1つ（控えめ）", "1 (light)"),
                                  (2, "2つ（標準）", "2 (normal)"),
                                  (3, "3つ（速い）", "3 (fast)")), advanced=True),
            )),
            Group("モデル", "Model", (
                Item("model", "custom", panel="models",
                     ja="文字起こしモデル", en="Speech-to-text model"),
            )),
            Group("言語と整形", "Language and clean-up", (
                Item("language", "segments",
                     "言語", "Language",
                     "話す言葉に合わせます。\n"
                     "・日本語 → 日本語として聞き取る（ふつうはこれ）\n"
                     "・英語 → 英語として聞き取る\n"
                     "・自動 → 声から言語を推測する（まれに取り違える）",
                     "The language you speak. Auto guesses from the audio.",
                     default="ja",
                     options=_opt(("ja", "日本語", "Japanese"),
                                  ("en", "英語", "English"),
                                  ("auto", "自動", "Auto"))),
                Item("hotkey_language", "hotkey",
                     "言語切り替えショートカット", "Language toggle shortcut",
                     "押すたびに認識言語（日本語 → 英語 → 自動）を順に"
                     "切り替えます。空にしておくと無効になります。",
                     "Pressing this toggles the recognition language "
                     "(Japanese → English → Auto). Leave blank to disable.",
                     default="", advanced=True),
                Item("punctuation_density", "segments",
                     "句読点の量", "How much punctuation",
                     "文の中の「、」の量です。話した言葉そのものは変えません。\n"
                     "・つけない → 「、」をまったく入れない\n"
                     "・少なめ → 文の切れ目（「〜けど、」「〜ので、」）だけ残す。"
                     "読みやすい（おすすめ）\n"
                     "・標準 → 聞き取ったまま\n"
                     "・多め → 「〜は、」「〜が、」のように細かく入れる",
                     "“Fewer” (default) keeps only the commas Japanese "
                     "writing needs: after conjunctions and between clauses, "
                     "and to break up long sentences. It drops commas after "
                     "spoken fillers and commas that split a word. "
                     "“Normal” keeps the model's commas; “More” adds commas "
                     "after particles. Your words are never changed.",
                     default="few",
                     options=_opt(("none", "つけない", "None"),
                                  ("few", "少なめ", "Fewer"),
                                  ("normal", "標準", "Normal"),
                                  ("many", "多め", "More"))),
                Item("join_separator", "segments",
                     "続けて録音したときのつなぎ目",
                     "Between one recording and the next",
                     "同じ入力欄に続けて入れるとき、前の文とのあいだに"
                     "置く文字です。「。」を付けない設定だと、"
                     "「ベストテスト今日の天気は」のようにつながって"
                     "しまうので、既定では空白を 1 つ入れます。"
                     "送信したあとや、別の入力欄に移ったあとは入れません。",
                     "What to put between the previous recording's text and "
                     "the next, in the same box. With full stops off the "
                     "sentences would otherwise run together, so a single "
                     "space is the default. Nothing is added after you send "
                     "or move to another box.",
                     default="space",
                     options=_opt(("space", "空白", "A space"),
                                  ("comma", "「、」", "A comma"),
                                  ("none", "なし", "Nothing")), advanced=True),
                Item("full_stops", "segments",
                     "「。」の付けかた", "Full stops",
                     "モデルは、言葉を切るたびに「。」を付けてきます。"
                     "そのため「導入した後に。うまいこといかなかった」の"
                     "ように、文の途中で切れてしまいます。"
                     "「付けない」にすると、モデルが付けた「。」を取ります"
                     "（「、」はそのまま残ります）。",
                     "The model adds a full stop every time you pause, so "
                     "sentences get cut in the middle. “Never” removes the "
                     "ones it added; commas are left alone.",
                     default="off",
                     options=_opt(("off", "付けない", "Never"),
                                  ("end", "録音の最後だけ", "Only at the end"),
                                  ("model", "モデルのまま", "Leave it to the model")), advanced=True),
                Item("question_marks", "segments",
                     "「？」の付けかた", "Question marks",
                     "【質問のときだけ】「〜ですか？」「なぜ？」など疑問の文脈で自動付与します。"
                     "【つけない】すべて「。」または記号なしにします（文末に「はてな」と言えば「？」にできます）。"
                     "【モデルにまかせる】AIモデルの判定通りに入れます。",
                     "How question marks are handled. 'Only for questions' "
                     "infers questions from speech context.",
                     default="never",
                     options=_opt(("never", "つけない", "Never"),
                                  ("smart", "質問のときだけ（推測）",
                                   "Only for questions (guessed)"),
                                  ("model", "モデルにまかせる",
                                   "Leave it to the model")), advanced=True),
                Item("fullwidth_punct", "bool",
                     "句読点を全角にそろえる",
                     "Use full-width Japanese punctuation",
                     "「,」「.」を「、」「。」にそろえます。"
                     "1,200 や 3.14 や example.com は壊しません。",
                     "Normalises ASCII commas and periods to Japanese ones, "
                     "while leaving 1,200, 3.14 and example.com alone.",
                     default=True, advanced=True),
                Item("remove_fillers", "bool",
                     "つなぎ言葉を消す", "Remove filler words",
                     "ふだんの文字起こしで、いつも効きます"
                     "（文章変換やAIは使いません）。\n"
                     "オン → 「えー」「あー」「あのー」「えっと」が入らない。"
                     "「えー今日は」→「今日は」（おすすめ）\n"
                     "オフ → 話したとおり、そのまま入る。\n"
                     "消す言葉は「詳しい設定」で足したり減らしたりできます。",
                     "Automatically removes hesitation sounds like um and er, "
                     "keeping only meaningful words.",
                     default=True),
                Item("filler_words", "custom",
                     "消すつなぎ言葉", "Filler words to remove",
                     "語の前後が句読点か文の端のときだけ消します。"
                     "「なんかしら」の「なんか」は消えません。",
                     "A word is removed only when it stands alone between "
                     "punctuation or sentence edges.",
                     panel="fillers", advanced=True),
                Item("halfwidth_numbers", "bool",
                     "数字と英字を半角にする", "Use half-width digits and letters",
                     "「１０時」を「10時」のように直します。",
                     "Converts full-width digits and Latin letters to ASCII.",
                     default=True, advanced=True),
                Item("arabic_numbers", "bool",
                     "漢数字を数字にする", "Write numbers as digits",
                     "「午前十時」を「午前10時」にします。"
                     "「一つ」「一番」「十分」のような言い回しは変えません。",
                     "Turns 十時 into 10時. Leaves set phrases such as 一つ, "
                     "一番 and 十分 as they are.",
                     default=False, advanced=True),
                Item("ja_en_spacing", "segments",
                     "日本語と英単語のあいだ",
                     "Between Japanese and Latin words",
                     "「ClaudeとChatGPT」と「Claude と ChatGPT」のどちらにするか。"
                     "数字の前後には空白を入れません。",
                     "Whether to put a space between Japanese and Latin "
                     "words. Numbers never get spaces.",
                     default="none",
                     options=_opt(("none", "空けない", "No space"),
                                  ("space", "空ける", "Add a space")), advanced=True),
                Item("fix_restatement", "bool",
                     "言い直しをまとめる", "Collapse corrections",
                     "「明日じゃなくて明後日です」を「明後日です」にします。"
                     "取り違えることがあるので、初期はオフです"
                     "（「冗談じゃなくて本当です」まで縮めてしまいます）。",
                     "Turns “not tomorrow but the day after” into “the day "
                     "after”. Off by default because it can misfire.",
                     default=False, advanced=True),
                Item("convert_spelled_alphabet", "bool",
                     "アルファベット読みを英語にする", "Convert spelled-out letters to English",
                     "「エフディーイー」を「FDE」、「エーピーアイ」を「API」、「エムワン」を「M1」のように、"
                     "アルファベットの読みを英語の大文字に直します。",
                     "Converts spoken letters (e.g. 'FDE', 'API', 'M1') into Latin capitals.",
                     default=True, advanced=True),
                Item("repair_mixed_loanwords", "bool",
                     "外来語の混在崩れを直す", "Repair mixed-script loanwords",
                     "音声認識が「アニメーション」を「アニnotion」のように、"
                     "カタカナと英単語を混ぜて出したときに元の外来語へ戻します。"
                     "混ざった形だけが対象で、英単語そのものは触りません。",
                     "Repairs recognition output that fuses katakana with "
                     "an English word (a mangled 'animation'). Standalone "
                     "English words are never touched.",
                     default=True, advanced=True),
                Item("fix_homophones", "bool",
                     "同音・同訓異義語を文脈で直す",
                     "Fix homophones from context",
                     "前後の文脈から、「機械／機会」「熱い／暑い」「収める／納める」"
                     "などの変換ミスを自動で補正します。",
                     "Automatically corrects homophones based on "
                     "surrounding context words.",
                     default=True, advanced=True),
            )),
            Group("記号の呼び方", "Spoken symbols", (
                Item("symbol_commands", "custom",
                     "記号にする言葉", "Words converted to symbols",
                     "言葉を記号（？や！など）に置き換えます。"
                     "追加・削除・オンオフができます。"
                     "ふだんの会話によく出る言葉（例：「まる」）を登録すると、"
                     "間違って記号になりやすいのでご注意ください。",
                     "Replaces words with punctuation marks (? or !). "
                     "Words that appear frequently in speech (e.g. 'maru') "
                     "may be converted to punctuation by mistake.",
                     panel="symbols",
                     default=[
                         {"word": "はてな", "symbol": "？", "enabled": True},
                         {"word": "クエスチョン", "symbol": "？", "enabled": True},
                         {"word": "はてなマーク", "symbol": "？", "enabled": True},
                         {"word": "びっくり", "symbol": "！", "enabled": False},
                         {"word": "感嘆符", "symbol": "！", "enabled": False},
                         {"word": "改行", "symbol": "\n", "enabled": False},
                         {"word": "まる", "symbol": "。", "enabled": False},
                         {"word": "てん", "symbol": "、", "enabled": False},
                     ], advanced=True),
            )),
            Group("音声コマンド", "Voice commands", (
                Item("voice_commands", "bool",
                     "音声コマンドを使う", "Enable voice commands",
                     "少し間を置いて「まる」「てん」「はてな」だけを言うと、"
                     "その記号が入ります（「改行」「段落」は初めは切って"
                     "あります。下の一覧で入れられます）。"
                     "ひと区切りがコマンドそのものだった時だけ反応するので、"
                     "「まるいテーブル」の「まる」には反応しません。",
                     "Pause, then say just “maru”, “ten” or “hatena” to "
                     "insert that mark (line-break commands start switched "
                     "off; turn them on below). A command only fires when "
                     "the whole phrase is the command, so ordinary speech "
                     "is never affected.",
                     default=True, advanced=True),
                Item("voice_command_list", "custom",
                     "使えるコマンド", "Available commands",
                     "言い方を足したり、個別に止めたりできます。",
                     "Add your own wordings, or switch individual commands "
                     "off.",
                     panel="commands", advanced=True),
            )),
        )),

    # ========================================================== AI・文章変換
    Category(
        # ふだんの文字起こし（つなぎ言葉の削除も含む）とは切り離した、
        # 独立した機能。以前は「AI自動編集」をオンにすると、ふだんの録音まで
        # 変換の流れに取られ、話しながら入力する動きが止まっていた。
        # 変換は、専用のショートカットを押したときだけ動く。
        "ai", "sparkles", "AI・文章変換", "AI & Actions",
        "話した内容を、AIやルールで翻訳・敬語・要約などに変えて入力する"
        "（ふだんの文字起こしとは別の機能）",
        "Transform speech with AI & smart rules: translate, summarize, "
        "polish… (separate from normal dictation)",
        (
            # ★キー 1 つで変換を選べるようにした（2026-10-11 の頼み：
            # 変換ごとにキーを決めるのは大変なので、一覧から選びたい）。
            Group("いちばん簡単な使い方", "The easy way", (
                Item("recipe_hotkey", "hotkey",
                     "変換を選んで録音するショートカット",
                     "Shortcut to pick an action",
                     "押す → 変換（レシピ）の一覧が出る。\n"
                     "↑↓ か 1〜9 で選ぶ → そのまま録音が始まる。\n"
                     "話し終えたら録音のキー（またはこのキー）をもう一度"
                     "押す → 選んだ変換をして、入力欄に入る。\n"
                     "変換ごとにキーを決めなくても、これ 1 つで全部使えます。",
                     "Press to list your actions, pick one with ↑↓ or 1–9 "
                     "and recording starts. Press the record key (or this "
                     "key) again to convert and type.",
                     default="alt+r"),
            )),
            Group("", "", (
                Item("ai_custom_instructions", "custom",
                     "変換の一覧", "Your text actions",
                     help_ja="変換ごとにショートカットを決めておき、"
                             "そのキーを押して話すと、変換した文章が入ります"
                             "（ふだんの録音キーはそのまま、変換なしで入ります）。"
                             "それぞれの指示文（プロンプト）は、最初から入っている"
                             "ものも自由に書きかえられます。「最初の文に戻す」で"
                             "いつでも元に戻せます。",
                     help_en="Give an action its own shortcut, press it and "
                             "speak, and the converted text is typed. Your "
                             "normal recording key is never converted. Every "
                             "prompt, including the built-in ones, can be "
                             "edited and restored.",
                     panel="ai_editor",
                     default=list(_DEFAULT_CUSTOM_INSTRUCTIONS)),
            )),
            Group("ほかの呼び出しかた", "Other ways to start an action", (
                Item("long_press_action", "choice",
                     "録音キーを長押ししたとき", "When you hold the record key",
                     "録音キーを長く押したまま話すと、離したときにここで"
                     "選んだ変換をして入力します。"
                     "「なし」なら、長押ししても普通の文字起こしです。"
                     "（「ショートカットの動作」が「長押しの間だけ」のときは"
                     "使えません）",
                     "Hold the record key while speaking and the chosen "
                     "action is applied on release. “None” keeps it as "
                     "normal dictation.",
                     default="none", options_from="instructions",
                     options=_opt(("none", "なし（ふつうの文字起こし）",
                                   "None (normal dictation)")),
                     advanced=True),
                Item("action_hotkey", "hotkey",
                     "AI変換用のショートカット", "AI Action shortcut",
                     "このキーで話すと、選んだAI変換（英語翻訳等）をして入力されます。"
                     "普段の録音キー（Ctrl+Space）とは被らないキーを設定できます。",
                     "Press this key and speak to apply AI actions like English translation.",
                     default="", advanced=True),
                Item("action_mode", "choice",
                     "そのキーでする変換", "Action for that shortcut",
                     "上のショートカットを押したときにする変換です。",
                     "What the shortcut above does.",
                     default="translate_en", options_from="instructions",
                     advanced=True),
            )),
            Group("アプリ連動（開いているアプリに合わせる）", "App Profiles", (
                Item("app_profiles_enabled", "bool",
                     "開いているアプリに合わせて自動切り替え",
                     "Adapt speech actions to active app",
                     "SlackやDiscordではチャット向け丁寧語、Wordではビジネス敬語、"
                     "エディタでは半角数字など、触っているアプリに合わせて"
                     "音声入力の動作を自動で切り替えます（完全オフライン対応）。",
                     "Automatically adapts dictation tone and settings (e.g. polite "
                     "for Slack, formal for Word) based on the active window.",
                     default=False, advanced=True),
                Item("app_profiles", "dict",
                     "アプリごとの設定ルール", "App profile rules",
                     "アプリ名（プロセス名）と、適用する変換アクションや"
                     "句読点の対応表です。",
                     "Mapping of process names to actions and punctuation settings.",
                     default={
                         "slack.exe": {"action": "polite", "punctuation": "few"},
                         "discord.exe": {"action": "polite", "punctuation": "few"},
                         "line.exe": {"action": "polite", "punctuation": "few"},
                         "teams.exe": {"action": "polite", "punctuation": "few"},
                         "winword.exe": {"action": "professional", "punctuation": "normal"},
                         "outlook.exe": {"action": "professional", "punctuation": "normal"},
                         "code.exe": {"action": "", "halfwidth_numbers": True},
                         "cursor.exe": {"action": "", "halfwidth_numbers": True},
                         "windowsterminal.exe": {"action": "", "halfwidth_numbers": True},
                     },
                     advanced=True),
            )),
        )),

    # ============================================================= 辞書
    Category(
        "dictionary", "book", "ユーザー辞書", "User dictionary",
        "誤認識を自分の言葉に直す", "Teach it your own words",
        (
            Group("", "", (
                Item("dictionary", "custom", panel="dictionary",
                     ja="ユーザー辞書", en="User dictionary"),
            )),
            Group("オプション", "Options", (
                Item("dictionary_as_hints", "bool",
                     "「正しい表記」を単語のヒントにも使う",
                     "Also pass the correct spellings to the model",
                     "単語のヒントに対応しているモデル（Whisper など）の"
                     "ときだけ効きます。",
                     "Only has an effect on models that accept word hints, "
                     "such as Whisper.",
                     default=True, advanced=True),
                Item("learn_fixes", "bool",
                     "直した内容を学習する",
                     "Learn from your corrections",
                     "オン → 「直前の入力を直す」窓で採用した置き換えを"
                     "覚えて、次回からの文字起こしに自動で当てます。"
                     "採用しなかった候補は残りません。\n"
                     "オフ → 学習候補は出ず、保存済みのペアも効きません"
                     "（同音異義語の差し替え自体は使えます）。",
                     "On: replacements you approve in the fix editor "
                     "are remembered and applied to future transcripts. "
                     "Unapproved candidates are discarded. Off: no "
                     "candidates are offered and learned pairs stop "
                     "applying (homophone swapping still works).",
                     default=True, advanced=True),
            )),
        )),

    # ============================================================= クリップ
    # 音声入力とは別の機能。コピーしたものをためておき、ショートカット
    # 1 つで貼り直せる。同じキーをもう一度押すと「よく使う」などの
    # グループに切り替わる（app/clipwin.py）。
    Category(
        "clipboard", "clipboard", "クリップボード", "Clipboard",
        "コピーしたものを、あとから選んで貼る",
        "Paste anything you copied earlier",
        (
            Group("基本・ショートカット", "Basics & Shortcut", (
                Item("clip_enabled", "bool",
                     "クリップボード履歴を使う", "Use clipboard history",
                     "オン → コピーした文字・画像・ファイルがたまり、"
                     "下のショートカットで一覧を出して貼れます。\n"
                     "オフ → 何も記録せず、ショートカットも手放します。",
                     "Keeps what you copy (text, images, files) so you can "
                     "paste it again from a list.",
                     default=True),
                Item("clip_hotkey", "hotkey",
                     "一覧を出すショートカット", "Shortcut to open the list",
                     "押す → 履歴の一覧が出ます。\n"
                     "もう一度押す → 「よく使う」や自作グループに切り替わり"
                     "ます（押すたびに次のタブへ）。\n"
                     "↑↓ で選んで Enter、またはクリックで貼り付けます。",
                     "Press to show the history. Press again to switch to "
                     "your own groups (one more group each press). Pick "
                     "with ↑↓ and Enter, or click.",
                     default="alt+v"),
                Item("clip_paste_mode", "segments",
                     "選んだとき", "When you pick an item",
                     "・貼り付ける → 入力中の欄に、そのまま入ります（標準）\n"
                     "・コピーだけ → クリップボードに入れるだけ。"
                     "自分で Ctrl+V で貼ります",
                     "Paste puts it straight into the box you were typing "
                     "in. Copy only puts it on the clipboard.",
                     default="paste",
                     options=_opt(("paste", "貼り付ける", "Paste"),
                                  ("copy", "コピーだけ", "Copy only"))),
                Item("clip_again", "segments",
                     "開いたまま、もう一度キーを押したとき",
                     "Pressing the shortcut again",
                     "・次のタブへ → 履歴 → よく使う → … と順に巡回（標準）\n"
                     "・閉じる → 一覧を閉じます\n"
                     "・貼る → いま選んでいるものをすぐ貼ります",
                     "Next tab cycles History → your tabs. Close hides "
                     "the list. Paste pastes the selected item.",
                     default="next",
                     options=_opt(("next", "次のタブへ", "Next tab"),
                                  ("close", "閉じる", "Close"),
                                  ("paste", "貼る", "Paste"))),
                Item("clip_click", "segments",
                     "マウスで貼るとき", "Pasting with the mouse",
                     "・1 回クリック → すぐ貼る（Windows の Win+V と同じ）\n"
                     "・ダブルクリック → 1 回目は選ぶだけ。"
                     "押し間違いを防ぎたい人向け",
                     "Single click pastes at once (like Win+V). Double "
                     "click needs two clicks, to avoid mistakes.",
                     default="single",
                     options=_opt(("single", "1 回クリック", "Single click"),
                                  ("double", "ダブルクリック",
                                   "Double click")),
                     advanced=True),
            )),
            Group("タブの種類と並び順", "Tabs & Order", (
                Item("clip_tab_order", "custom",
                     "タブの並び順と切り替え", "Tab order & visibility",
                     "ドラッグ＆ドロップ（長押しして上下）や ▲▼ ボタンで、"
                     "一覧のタブを自由に並び替えられます。",
                     "Drag & drop or use ▲▼ buttons to rearrange tabs.",
                     panel="clip_tab_order",
                     default=["history", "frequent", "groups", "downloads"]),
                Item("clip_sort", "segments",
                     "履歴の中の並び順", "History sort order",
                     "・使った順 → コピーまたは貼り付けした順に上に並びます"
                     "（標準）\n"
                     "・コピーした順 → 貼っても動かず、コピー順を維持します\n"
                     "・よく使う順 → 貼った回数が多い順に並びます",
                     "Recently used moves pasted items to top. Copy order "
                     "never moves items. Most used sorts by frequency.",
                     default="use",
                     options=_opt(("use", "使った順", "Recently used"),
                                  ("copy", "コピーした順", "Copy order"),
                                  ("count", "よく使う順", "Most used"))),
                Item("clip_pinned_first", "bool",
                     "固定したものを一番上に置く", "Keep pinned items on top",
                     "Ctrl+P で固定したものは消えず、常に一番上に並びます。",
                     "Pinned items (Ctrl+P) stay on top.",
                     default=True, advanced=True),
                Item("clip_show_frequent", "bool",
                     "「🤖よく使っている」タブを表示", "Show Frequent tab",
                     "直近で頻繁に使ったパスワードや定型文などの項目を"
                     "自動集計してタブに出します。",
                     "Collects items used frequently into a dedicated tab.",
                     default=True, advanced=True),
                Item("clip_frequent_days", "segments",
                     "「🤖よく使っている」の集計期間", "Frequent days window",
                     "", "", default=7,
                     options=_opt((3, "3日", "3 days"),
                                  (7, "1週間", "1 week"),
                                  (14, "2週間", "2 weeks"),
                                  (30, "1か月", "1 month")),
                     advanced=True),
                Item("clip_downloads", "segments",
                     "「ダウンロード」タブを表示", "Show Downloads tab",
                     "最近この PC に入ってきたファイル（ダウンロード・"
                     "デスクトップ・OneDrive）を一覧に出します。",
                     "Shows files that recently arrived in Downloads, etc.",
                     default="end",
                     options=_opt(("end", "表示する", "Show"),
                                  ("off", "出さない", "Off")),
                     advanced=True),
                Item("clip_download_days", "segments",
                     "何日前までのファイルを出すか", "Downloads time window",
                     "", "", default=7,
                     options=_opt((1, "1日", "1 day"),
                                  (3, "3日", "3 days"),
                                  (7, "1週間", "1 week"),
                                  (30, "1か月", "1 month")),
                     advanced=True),
                Item("clip_download_onedrive", "bool",
                     "OneDrive のファイルも探す", "Include OneDrive",
                     "OneDrive に保存・同期されたファイルも出します。"
                     "クラウドだけにあるものは名前だけ出します。",
                     "Also lists files saved or synced to OneDrive.",
                     default=True, advanced=True),
                Item("clip_download_desktop", "bool",
                     "デスクトップのファイルも探す", "Include desktop",
                     "", "", default=True, advanced=True),
                Item("clip_group_sort", "segments",
                     "自作グループの中の並び順", "Order inside groups",
                     "「自分で並べた順」は Ctrl+Shift+↑↓、またはグループ"
                     "設定の一覧で並べ替えられます。",
                     "Arrange your own order with Ctrl+Shift+↑↓.",
                     default="manual",
                     options=_opt(("manual", "自分で並べた順", "My order"),
                                  ("use", "使った順", "Recently used"),
                                  ("count", "よく使う順", "Most used"),
                                  ("name", "名前順", "By name")),
                     advanced=True),
            )),
            Group("一覧の見た目", "Appearance", (
                Item("clip_position", "segments",
                     "出す場所", "Where it opens",
                     "・文字カーソルの近く → 入力欄のすぐそば（おすすめ）\n"
                     "・マウスの近く → マウスポインタのそば\n"
                     "・画面の中央 → いつも画面の真ん中\n"
                     "・前回の場所 → 自分で動かした位置を覚えます",
                     "Near the text cursor, near mouse, centre of window, "
                     "or last moved location.",
                     default="caret",
                     options=_opt(("caret", "文字カーソルの近く",
                                   "Near text cursor"),
                                  ("mouse", "マウスの近く", "Near mouse"),
                                  ("center", "画面の中央", "Centre"),
                                  ("last", "前回の場所", "Last place"))),
                Item("clip_font_size", "segments",
                     "文字の大きさ", "Text size",
                     "一覧の文字の大きさです。窓の大きさは、ふちを"
                     "ドラッグして変えると覚えます。",
                     "Text size in the list. Drag edges to resize window.",
                     default="medium",
                     options=_opt(("small", "小", "Small"),
                                  ("medium", "中", "Medium"),
                                  ("large", "大", "Large"),
                                  ("xlarge", "特大", "Extra large"))),
                Item("clip_preview", "segments",
                     "中身のプレビュー", "Preview",
                     "選んでいるものの中身（全文や大きな画像）を出す場所です。",
                     "Where full text or larger image preview is shown.",
                     default="right",
                     options=_opt(("right", "右", "Right"),
                                  ("bottom", "下", "Bottom"),
                                  ("none", "出さない", "Off"))),
                Item("clip_rows", "segments",
                     "1 件の行数", "Lines per item",
                     "2 行 → 2行目の文字とコピー元アプリ・時刻も表示\n"
                     "1 行 → 多くの項目がすっきり並びます",
                     "Two lines show details; one line fits more items.",
                     default="two",
                     options=_opt(("two", "2 行", "Two"),
                                  ("one", "1 行", "One")), advanced=True),
                Item("clip_show_numbers", "bool",
                     "番号を出す（Ctrl+数字で貼れる）",
                     "Show numbers (Ctrl+number pastes)",
                     "上から 9 件に 1〜9 の番号を出し、Ctrl+3 で 3 番目を"
                     "すぐ貼れます。",
                     "Numbers top nine items; Ctrl+3 pastes the third.",
                     default=True, advanced=True),
                Item("clip_opacity", "segments",
                     "透けぐあい", "Opacity", "", "",
                     default=100,
                     options=_opt((100, "透けない", "Solid"),
                                  (95, "少し", "Slight"),
                                  (90, "やや", "Medium"),
                                  (80, "多め", "More")), advanced=True),
                Item("clip_open_tab", "segments",
                     "開いたときのタブ", "Tab shown first",
                     "", "", default="history",
                     options=_opt(("history", "いつも最初のタブ", "First tab"),
                                  ("last", "前回のタブ", "Last used tab")),
                     advanced=True),
                Item("clip_close_on_blur", "bool",
                     "ほかの所を押したら閉じる",
                     "Close when you click elsewhere",
                     "", "", default=True, advanced=True),
                Item("clip_close_after_drop", "bool",
                     "ドラッグして渡したら閉じる",
                     "Close after dragging an item out",
                     "画像やファイルを他アプリへドラッグで渡した後に閉じます。",
                     "List closes after dragging an item out.",
                     default=True, advanced=True),
                Item("clip_width", "int",
                     "窓の幅", "Width",
                     "ふちをドラッグして変えると、ここも変わります。",
                     "Changes when you drag edges of the list.",
                     default=640, minimum=380, maximum=1600, step=20,
                     unit="px", advanced=True),
                Item("clip_height", "int",
                     "窓の高さ", "Height", "", "",
                     default=440, minimum=300, maximum=1200, step=20,
                     unit="px", advanced=True),
            )),
            Group("定型文・パスワード（自作グループ）", "Saved Words & Groups", (
                Item("clip_groups", "custom",
                     "グループと中身", "Groups and their words",
                     "メールアドレス・住所・定型文・パスワードなどを"
                     "グループに分けて置いておけます。"
                     "「秘密」にした項目は暗号化して保存し、一覧では伏せ字に"
                     "なります。中身に {date}（今日の日付）・{time}"
                     "（いまの時刻）・{clipboard}（コピー中の文字）"
                     "を書くと、貼るときに自動で置き換わります。",
                     "Keep email addresses, templates or passwords in "
                     "groups. Secret items are encrypted. {date}, {time} and "
                     "{clipboard} are filled in when pasting.",
                     panel="clip_groups"),
            )),
            Group("保存期間・プライバシー", "History & Privacy", (
                Item("clip_capture_images", "bool",
                     "画像も残す", "Keep images",
                     "スクリーンショットやコピーした画像も残します。"
                     "一覧から他アプリへドラッグして渡せます。",
                     "Also keeps screenshots and copied images.",
                     default=True),
                Item("clip_max_items", "int",
                     "残す件数", "Items to keep",
                     "これを超えると古いものから自動で消えます"
                     "（固定したもの・グループのものは消えません）。",
                     "Older items are removed beyond this (pinned items and "
                     "groups are kept).",
                     default=500, minimum=50, maximum=5000, step=50,
                     unit="count", advanced=True),
                Item("clip_keep_days", "segments",
                     "残しておく期間", "How long to keep",
                     "この日数より前にコピーしたものは自動で消えます"
                     "（固定したもの・グループのものは消えません）。",
                     "Items copied before this are removed.",
                     default=30,
                     options=_opt((1, "1日", "1 day"),
                                  (7, "1週間", "1 week"),
                                  (30, "1か月", "1 month"),
                                  (90, "3か月", "3 months"),
                                  (0, "ずっと", "Forever")),
                     advanced=True),
                Item("clip_honor_private", "bool",
                     "パスワード管理アプリなどの「記録しないで」に従う",
                     "Respect private flags from password managers",
                     "1Password や Bitwarden などが付ける「記録しないで」の"
                     "印が付いたものは残しません（おすすめ）。",
                     "Password managers mark passwords as private; "
                     "with this on they are never stored.",
                     default=True, advanced=True),
                Item("clip_ignore_apps", "applist",
                     "記録しないアプリ", "Apps never to record",
                     "ここに入れたアプリでコピーしたものは残しません。",
                     "Nothing copied in these apps is kept.",
                     default=["1Password.exe", "KeePass.exe",
                              "KeePassXC.exe", "Bitwarden.exe"],
                     advanced=True),
                Item("clip_secret_clear_s", "segments",
                     "秘密項目を貼った後、クリップボードから消す時間",
                     "Clear secrets from clipboard after",
                     "パスワードなどがクリップボードに残り続けないよう自動消去します。",
                     "So passwords do not stay on clipboard.",
                     default=30,
                     options=_opt((15, "15秒", "15 s"),
                                  (30, "30秒", "30 s"),
                                  (60, "1分", "1 min"),
                                  (0, "消さない", "Never")), advanced=True),
                Item("clip_capture_files", "bool",
                     "エクスプローラーでコピーしたファイルも残す",
                     "Keep files copied in Explorer",
                     "ファイル実体ではなく、場所情報だけを残します。",
                     "Only locations are kept, not files.",
                     default=True, advanced=True),
                Item("clip_keep_formatting", "bool",
                     "書式（太字・表など）も残す",
                     "Keep formatting (bold, tables…)",
                     "貼るときに元の書式が戻ります。書式なしで貼る時は Shift+Enter。",
                     "Formatting comes back when pasting. Shift+Enter "
                     "pastes plain text.",
                     default=True, advanced=True),
                Item("clip_max_image_mb", "int",
                     "これより大きい画像は残さない",
                     "Skip images larger than",
                     "", "", default=30, minimum=1, maximum=200, step=1,
                     unit="mb", advanced=True),
            )),
            Group("貼り付け設定", "Pasting Options", (
                Item("clip_plain_default", "bool",
                     "いつも書式なしで貼る", "Always paste plain text",
                     "", "", default=False, advanced=True),
                Item("clip_expand_vars", "bool",
                     "{date} などを置き換える",
                     "Fill in {date} and friends",
                     "グループの言葉に書いた {date}・{time}・{clipboard} を"
                     "貼るときの値に自動展開します。",
                     "Replaces {date}, {time}, {clipboard} when pasting.",
                     default=True, advanced=True),
                Item("clip_join", "segments",
                     "まとめて貼るときの区切り", "Joining several items",
                     "複数選択した項目をつないで貼るときの区切り文字です。",
                     "Separator when pasting multiple items.",
                     default="newline",
                     options=_opt(("newline", "改行", "New line"),
                                  ("blank", "空行", "Blank line"),
                                  ("space", "空白", "Space"),
                                  ("none", "そのまま", "Nothing")),
                     advanced=True),
                Item("clip_restore_after", "bool",
                     "貼ったあと、元のクリップボードに戻す",
                     "Restore clipboard after pasting",
                     "一覧から貼っても、直前に Ctrl+C した内容を保ちます。",
                     "Restores clipboard to previous content after pasting.",
                     default=False, advanced=True),
            )),
            Group("データ管理・保守", "Data Management", (
                Item("", "custom", panel="clip_stats", advanced=True),
                Item("", "action", panel="clip_history_clear",
                     ja="履歴をすべて消す", en="Clear history",
                     help_ja="固定したものとグループの中身は残ります。",
                     help_en="Pinned items and groups are kept.",
                     advanced=True),
                Item("", "action", panel="clip_export",
                     ja="グループを書き出す", en="Export groups",
                     help_ja="グループと中身を JSON ファイルに保存します。",
                     help_en="Saves your groups to a JSON file.",
                     advanced=True),
                Item("", "action", panel="clip_import",
                     ja="グループを読み込む", en="Import groups",
                     help_ja="書き出したファイルから追加します（重複は統合）。",
                     help_en="Adds groups from an exported file.",
                     advanced=True),
            )),
        )),

    # ============================================================= 表示
    Category(
        "display", "monitor", "表示", "Display",
        "録音中の表示と、この画面の見た目",
        "The recording indicator and this window",
        (
            Group("録音中の表示", "Recording indicator", (
                Item("overlay", "bool",
                     "画面に状態を表示する", "Show the status indicator",
                     "オン → 録音中・文字にしている最中に、画面に小さな帯が出る。"
                     "いま聞いているかがひと目で分かる（おすすめ）\n"
                     "オフ → 画面には何も出さず、裏で静かに動く。",
                     "Shows a small indicator bar while recording or transcribing.",
                     default=True),
                Item("overlay_preview", "custom", panel="overlay_preview"),
                Item("overlay_design", "segments",
                     "表示のかたち", "Shape",
                     "録音中に出る帯のかたちです。\n"
                     "・ピル → 細くて小さい。入力欄に重なりにくい（標準）\n"
                     "・波のバー → 声の波が見える。マイクが声を拾えているか分かる\n"
                     "・カード → 話している言葉がいちばん大きく見える\n"
                     "・コンパクト → 極小の印と波だけ。邪魔にならない\n"
                     "・字幕テロップ → 映画の字幕のように横長で文字が見やすい",
                     "“Pill” is a slim strip that rarely covers the input box "
                     "(default). “Wave bar” fills the width with the live "
                     "waveform. “Card” shows what you say at the largest size. "
                     "“Compact” is a minimal badge. “Caption” displays wide "
                     "subtitles like a movie.",
                     default="pill",
                     options=_opt(("pill", "ピル", "Pill"),
                                  ("wave", "波のバー", "Wave bar"),
                                  ("card", "カード", "Card"),
                                  ("dot", "コンパクト", "Compact"),
                                  ("caption", "字幕テロップ", "Caption"))),
                Item("overlay_size", "segments",
                     "大きさ", "Size",
                     "帯の大きさです。「特大」はシニアの方や離れた大画面でも見やすいです。",
                     "Size of the bar. Extra large is easier to read.",
                     default="medium",
                     options=_opt(("small", "小", "Small"),
                                  ("medium", "中", "Medium"),
                                  ("large", "大", "Large"),
                                  ("xlarge", "特大", "Extra large"))),
                Item("overlay_position", "segments",
                     "表示の位置", "Position",
                     "画面上のどこに出すかを選べます。\n"
                     "・下の中央／右下／上の中央 → 画面の決まった位置に固定\n"
                     "・カーソルの近く → いま文字を打っている入力位置のそばに追従",
                     "Choose where to show the bar. Fixed at the bottom/top, "
                     "or follow near your text typing cursor.",
                     default="bottom",
                     options=_opt(("bottom", "下の中央", "Bottom centre"),
                                  ("bottom-right", "右下", "Bottom right"),
                                  ("top", "上の中央", "Top centre"),
                                  ("cursor", "カーソルの近く", "Near cursor"))),
                Item("overlay_color", "segments",
                     "録音中の色", "Recording colour",
                     "録音しているあいだの帯の色です。"
                     "「アクセント」は Windows の色に合わせます。"
                     "丸い印でも録音中だと分かるので、どの色でも迷いません。",
                     "Colour of the indicator while recording. “Accent” "
                     "follows your Windows accent colour.",
                     default="red",
                     options=_opt(("red", "赤", "Red"),
                                  ("orange", "オレンジ", "Orange"),
                                  ("green", "緑", "Green"),
                                  ("teal", "青緑", "Teal"),
                                  ("blue", "青", "Blue"),
                                  ("navy", "紺", "Navy"),
                                  ("pink", "ピンク", "Pink"),
                                  ("gray", "グレー", "Grey"),
                                  ("accent", "アクセント", "Accent"))),
                Item("overlay_text", "bool",
                     "話している文字をオーバーレイに出す",
                     "Show your words on the overlay",
                     "録音中、まだ入力していない文字をオーバーレイに薄く"
                     "出します。切ると、「聞いています」と録音中の動きだけが"
                     "出ます。タスクトレイの右クリックからも切り替えられます。",
                     "While recording, shows the words not yet typed on the "
                     "overlay. Turn it off to show only “Listening” and the "
                     "recording animation. You can also switch it from the "
                     "tray menu.",
                     default=True, advanced=False),
                Item("overlay_hint", "bool",
                     "操作のヒントを出す", "Show the key hints",
                     "「Ctrl+Space で止める ・ Esc で取り消し」を小さく"
                     "出します（「波のバー」「カード」のとき。細い"
                     "「ピル」には出ません）。慣れたら切ってください。",
                     "Shows “Ctrl+Space to stop · Esc to cancel” in small "
                     "text (Wave bar and Card only; the slim Pill has no "
                     "room). Turn it off once you know the keys.",
                     default=True, advanced=True),
                # 「中」でも、以前の帯よりはっきり大きくした。
                Item("overlay_margin_px", "int",
                     "画面の端からの距離", "Distance from the edge",
                     "0 にするとタスクバーのすぐ上（横）に貼り付きます。",
                     "At 0 it sits right against the taskbar.",
                     default=16, minimum=0, maximum=200, step=4,
                     unit="px", advanced=True),
            )),
            Group("見た目", "Appearance", (
                Item("theme", "segments",
                     "テーマ", "Theme",
                     "この設定画面の色です。「システム」なら Windows の"
                     "ライト・ダークに合わせます。",
                     "System follows the Windows light/dark setting.",
                     default="system",
                     options=_opt(("system", "システム", "System"),
                                  ("light", "ライト", "Light"),
                                  ("dark", "ダーク", "Dark")), advanced=True),
                Item("ui_font_size", "segments",
                     "文字の大きさ", "Text size",
                     "この設定画面の文字とボタンの大きさです。"
                     "「特大」にするとシニアの方でも読みやすくなります。",
                     "Size of text and buttons in this window.",
                     default="normal",
                     options=_opt(("normal", "標準", "Normal"),
                                  ("large", "大きめ", "Large"),
                                  ("xlarge", "特大", "Extra large")), advanced=True),
                Item("ui_language", "segments",
                     "表示言語", "Interface language",
                     "この画面と、タスクトレイのアイコンのメニューの言葉です。",
                     "Language of this window and the tray menu.",
                     default="ja",
                     options=_opt(("ja", "日本語", "日本語"),
                                  ("en", "English", "English")), advanced=True),
            )),
        )),

    # ============================================================= 履歴
    Category(
        "history", "history", "履歴", "History",
        "文字起こしの記録（このPCの中だけ）",
        "What you dictated, stored only on this PC",
        (
            Group("", "", (
                Item("", "custom", panel="history"),
            )),
            Group("保存", "Storage", (
                Item("history_limit", "int",
                     "保存件数", "Entries to keep",
                     "0 にすると履歴をいっさい保存しません。"
                     "履歴がこのPCの外に出ることはありません。",
                     "0 turns history off completely. History never leaves "
                     "this PC.",
                     default=200, minimum=0, maximum=2000, step=50,
                     unit="count", zero_ja="保存しない", zero_en="Off", advanced=True),
                Item("history_audio_days", "segments",
                     "録音を残しておく期間", "How long recordings are kept",
                     "この日数が過ぎた録音は自動で消します。"
                     "文字の記録は残ります。",
                     "Recordings older than this are deleted automatically. "
                     "The text stays.",
                     default=14,
                     options=_opt((7, "1週間", "1 week"),
                                  (14, "2週間", "2 weeks"),
                                  (30, "1か月", "1 month"),
                                  (0, "消さない", "Keep them")), advanced=True),
                Item("history_keep_audio", "bool",
                     "音声も残す", "Keep the audio too",
                     "文字起こしの元になった音声を残します。"
                     "聞き返せますが、ディスクの空きを使います。",
                     "Stores the source audio so you can listen back. "
                     "Uses disk space.",
                     default=True, advanced=True),
            )),
        )),

    # ============================================================= アプリ
    Category(
        "app", "window", "アプリ", "Application",
        "起動と保守", "Startup and maintenance",
        (
            Group("動作チェック", "Self-check", (
                Item("selfcheck", "custom",
                     "使える状態か調べる", "Check that everything is ready",
                     "うまく文字が入らないときに押す → マイク・モデル・"
                     "ショートカット・貼り付けをまとめて調べ、直し方を出す。",
                     "Checks the microphone, model, GPU, shortcut and paste "
                     "readiness, and tells you how to fix anything wrong.",
                     panel="selfcheck"),
            )),
            Group("起動", "Startup", (
                Item("autostart", "bool",
                     "PC起動時に自動で起動する", "Start automatically with Windows",
                     "オン → PC をつけると自動で立ち上がり、すぐ声で入力できる"
                     "（おすすめ）\n"
                     "オフ → 使うたびに自分で起動する。",
                     "Launches koe-type automatically when you sign in to Windows.",
                     default=True),
                Item("tray_icon", "bool",
                     "タスクトレイにアイコンを出す", "Show the tray icon",
                     "オフにすると、この画面を開く手段がなくなります。",
                     "With this off there is no way left to reach this window.",
                     default=True, restart=True, advanced=True),
            )),
            Group("プライバシーと通信", "Privacy & Network", (
                Item("offline_mode", "bool",
                     "通信を完全に遮断する（オフライン専用）",
                     "Block all network traffic (Offline mode)",
                     "更新確認やモデルのダウンロードなど、インターネットへの"
                     "一切の通信を遮断します。"
                     "モデルを先に入れておけば、完全にオフラインで動作します。",
                     "Blocks all internet communication including update "
                     "checks and model downloads. If models are already "
                     "downloaded, koe-type runs completely offline.",
                     default=False, advanced=True),
            )),
            Group("新しい版とモデル", "Updates and models", (
                Item("auto_update_mode", "choice",
                     "自動アップデート",
                     "Automatic updates",
                     "新しい版（機能改善や新モデル対応など）が出たときの動作です。"
                     "「自動で最新版にアップデート」を選ぶと、使っていない待機中に"
                     "最新版を安全にダウンロードして自動で再起動します。"
                     "設定・ユーザー辞書・履歴はそのまま引き継がれます。",
                     "How to handle new versions. 'Update automatically' "
                     "installs updates and restarts while idle.",
                     default="notify",
                     options=_opt(("notify", "新しい版が出たら知らせる（推奨）",
                                   "Notify when a new version is out"),
                                  ("auto", "自動で最新版にアップデートする",
                                   "Update to latest version automatically"),
                                  ("off", "確認しない（完全オフライン）",
                                   "Off (fully offline)")), advanced=True),
                Item("auto_update_catalog", "bool",
                     "新しいモデルを自動で一覧に追加する",
                     "Automatically fetch new models",
                     "新しい音声認識モデル（より高精度・軽量なモデル）が公開されたとき、"
                     "設定画面のモデル選択肢に自動で追加します。",
                     "Adds newly released models to the model choices automatically.",
                     default=True, advanced=True),
                Item("", "action", panel="check_update",
                     ja="いま更新を確かめる", en="Check for updates now",
                     help_ja="新しい版があれば、その場でワンクリックで入れ替えられます。"
                             "設定・ユーザー辞書・履歴はそのまま引き継ぎます。",
                     help_en="If there is a newer version you can install it "
                             "with one button. Settings, user dictionary and "
                             "history are kept.", advanced=True),
            )),
            Group("保守", "Maintenance", (
                Item("", "action", panel="diagnostics",
                     ja="診断情報をコピー", en="Copy diagnostics",
                     help_ja="不具合を知らせるための情報を、"
                             "そのまま貼れる形でコピーします。"
                             "話した内容・ユーザー名・パスは外します。",
                     help_en="Copies everything needed to report a problem, "
                             "ready to paste. What you said, your user name "
                             "and your paths are left out.", advanced=True),
                Item("", "action", panel="onboarding",
                     ja="初回の案内をもう一度", en="Run the setup guide again",
                     help_ja="この PC に合うモデルの選び方、マイク、"
                             "ショートカットを、6 画面で順に確かめられます。",
                     help_en="Walks through picking a model for this PC, "
                             "the microphone and the shortcut, in six "
                             "steps.", advanced=True),
                Item("", "action", panel="config_export",
                     ja="設定を書き出す", en="Export settings",
                     help_ja="現在の設定を JSON ファイルとして保存します。"
                             "バックアップや別の PC への移行に使えます。",
                     help_en="Saves your current settings as a JSON file. "
                             "Useful for backups or moving to another PC.", advanced=True),
                Item("", "action", panel="config_import",
                     ja="設定を読み込む", en="Import settings",
                     help_ja="JSON ファイルから設定を読み込んで反映します。",
                     help_en="Loads and applies settings from a JSON file.", advanced=True),
                Item("", "action", panel="open_log",
                     ja="ログを開く", en="Open the log",
                     help_ja="うまく動かないときの記録です。",
                     help_en="What happened, for when something goes wrong.", advanced=True),
                Item("", "action", panel="open_folder",
                     ja="保存フォルダを開く", en="Open the data folder",
                     help_ja="設定・ユーザー辞書・履歴が入っています。",
                     help_en="Settings, user dictionary and history live here.", advanced=True),
                Item("", "action", panel="reset",
                     ja="設定を初期化する", en="Reset all settings",
                     help_ja="すべての設定を初期値に戻します。"
                             "ユーザー辞書と履歴は消えません。",
                     help_en="Restores every setting to its default. "
                             "The user dictionary and history are kept.", advanced=True),
                Item("", "action", panel="clear_all_data",
                     ja="すべての利用データを消去する", en="Delete all user data",
                     help_ja="履歴・録音音声・ユーザー辞書・ログを完全に削除し、"
                             "設定も初期値に戻します。この操作は取り消せません。",
                     help_en="Permanently deletes history, audio recordings, "
                             "user dictionary, and logs, and resets all "
                             "settings. This cannot be undone.", advanced=True),
            )),
            Group("", "", (
                Item("", "custom", panel="about", advanced=True),
            )),
        )),
)


def defaults() -> dict[str, Any]:
    out: dict[str, Any] = {}
    for cat in CATEGORIES:
        for group in cat.groups:
            for item in group.items:
                if item.key and item.default is not None:
                    out[item.key] = (list(item.default)
                                     if isinstance(item.default, list)
                                     else item.default)
    # 画面に出さない細かい調整値
    # モデルの既定は catalog 側に 1 か所だけ置く。
    # ここに名前を直書きしていたせいで、catalog の既定を常駐版に変えても
    # 新しい利用者には古いほう（外部プロセス）が選ばれていた。
    from . import catalog  # noqa: PLC0415
    out.update({
        "model": catalog.DEFAULT_MODEL,
        "min_speech_ms": 300,
        # これより短い区切りは、その場で入れずに次の区切りにつなげる。
        # 言いよどんだときに「隣りの」だけが先に入るのを防ぐ。
        "input_mode": "stream",
        "overlay_design": "pill",
        # 初回の案内が終わったか。終わるまで、起動のたびに開く
        "onboarding_done": False,
        # 新しい版が出ていないか確かめる。**既定はオフ**。
        # これ以外の通信は一切しない。
        "check_updates": False,
        "update_repo": "koe-type/koe-type",
        "overlay_hint": True,
        "overlay_text": True,
        # つなぎ目を入れるのは、前に入れてからこの時間までのあいだ
        "join_window_ms": 120000,
        "merge_short_ms": 400,
        # つなげる相手が来ないまま、これだけ静かならひとりで出す。
        "hold_release_ms": 1500,
        "preroll_ms": 350,
        "tail_ms": 250,
        "vad_floor": 180,
        "clip_show_frequent": True,
        "clip_frequent_days": 7,
        "clip_tab_order_mode": "frequent_first",
        "guardian": True,            # 見張り役のプロセスを起こす
        # 一致を認めるのに必要な「音の増え方」。回数だけで見ると、
        # 同じような音を何度も聞いているだけで一致してしまう。
        "stream_agree_span_ms": 400,
        "shutdown_wait_ms": 6000,    # 終了前に残りを片づける最大の待ち
        # 停止がこの時間で終わらなかったら、待たずに待機へ戻す。
        # 以前、停止の途中で居残って帯が消えず、Ctrl+Space も
        # 効かなくなった。待ち続けないことがいちばん大事。
        "stop_timeout_ms": 3000,
        # 録音中だけマウスを見る間隔。入力の流れには割り込まない。
        "click_poll_ms": 15,
        # 使わなくなった（2026-10-05）。クリックで止めたあとの文字は
        # 待って貼るのをやめ、クリップボードへ入れる。古い設定ファイル
        # に残っていても困らないように、項目だけ残す。
        "click_finish_ms": 700,
        "polite_priority": True,     # 待機中は処理の優先度を下げる
        "auto_fast_model": True,     # 間に合わない時に軽いモデルへ逃げる
        "keep_model_loaded": True,   # 使っていない間もモデルを置いたままにする
        "paste_method": "auto",
        "save_to_clipboard": "fallback",
        "auto_update_mode": "notify",
        "auto_update_catalog": True,
        "filler_words": [],          # 空なら jatext.DEFAULT_FILLERS を使う
        # 「改行」「段落」は既定で止めてある。Enter キーは送らず
        # 改行の文字を貼り付ける作りなのでチャットでも送信されないが、
        # 話した「改行」という語を消してから入れる形になるため、
        # 使いたい人だけ設定で戻す。
        "voice_command_off": ["改行", "段落"],
        "voice_command_extra": {},   # 足した言い方 {コマンド名: [言い方...]}
        "paste_delay_ms": 70,
        "clipboard_restore_ms": 250,
        "wait_modifier_release_ms": 900,
        "warmup": True,
        "log_level": "INFO",
        "speaker_focus": "normal",
        "ai_provider": "auto",
        "ai_api_key": "",
        "ai_model": "gemini-3.8-flash",
        "custom_action_prompt": (
            "以下の音声を自然で読みやすい文章に整えてください。"
            "解説や前置きは含めず、結果のみを出力してください:\n\n{text}"
        ),
        # よそを見ているあいだの文字（away_text = "wait"）を、元の窓に
        # 戻るまで待つ秒数。過ぎたらクリップボードへ逃がす。
        "away_wait_s": 180,
        # クリップボード履歴の、画面に出さない値。
        # 窓の場所は「前回の場所」で使う（ドラッグして動かすと覚える）。
        "clip_pos_x": -99999,
        "clip_pos_y": -99999,
        "clip_last_tab": 0,
        "clip_tab_order": ["history", "frequent", "groups", "downloads"],
        "clip_tab_order_mode": "frequent_first",
        "clip_intro_done": False,    # 「使えます」のお知らせを出したか
        "clip_max_text_kb": 1024,    # これより長い文字は残さない
        "active_action": "",
        "ai_auto_edit": False,
        "ai_auto_edit_prompt": _DEFAULT_AI_AUTO_EDIT_PROMPT,
        "ai_custom_instructions": [dict(x) for x in _DEFAULT_CUSTOM_INSTRUCTIONS],
        # 文章変換の一覧に一度でも出した組み込みの ID（configstore を参照）
        "ai_instruction_ids_seen": sorted(
            x["id"] for x in _DEFAULT_CUSTOM_INSTRUCTIONS),
    })
    return out


def find(key: str) -> Item | None:
    for cat in CATEGORIES:
        for group in cat.groups:
            for item in group.items:
                if item.key == key:
                    return item
    return None


def find_category(key: str) -> str | None:
    """指定されたキーが属するカテゴリの key を返す。"""
    for cat in CATEGORIES:
        for group in cat.groups:
            for item in group.items:
                if item.key == key:
                    return cat.key
    return None


def label_of_item(key: str) -> str:
    """設定項目の表示ラベル（現在の言語）を返す。"""
    from . import i18n  # noqa: PLC0415
    item = find(key)
    if item is None:
        return key
    return item.ja if i18n.language() == "ja" else (item.en or item.ja)

