"""文字起こし結果の整形と、置き換え辞書。"""

from __future__ import annotations

import logging
import re
import unicodedata
from pathlib import Path
from typing import Any

from .engines import strip_tags
from .util import DICT_PATH

log = logging.getLogger(__name__)

# 日本語の文字どうしの間に入った空白は、エンジンの分かち書きの名残なので取り除く。
# 逆に英数字どうしの間（Claude Code など）は1個だけ残す。
_ASCII_WORD = re.compile(r"[0-9A-Za-z]")

# つなぎ言葉。前後が文字でも消えるよう、語そのものだけを見る。
FILLERS = (
    "えーと", "えーっと", "ええと", "えっと", "えーand",
    "あのー", "あのう", "あの、", "そのー", "そのう",
    "まあ、", "ま、", "なんか、", "えー、", "あー、", "うーん、", "んー、",
    "えー", "あー", "うーん", "んーと",
)
_FILLER_RE = re.compile("|".join(re.escape(f) for f in
                                 sorted(FILLERS, key=len, reverse=True)))

_PUNCT_RE = re.compile(r"[、。，．]")


def squeeze_spaces(text: str) -> str:
    out: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in " \t　":
            j = i
            while j < n and text[j] in " \t　":
                j += 1
            prev = out[-1] if out else ""
            nxt = text[j] if j < n else ""
            if prev and nxt and _ASCII_WORD.match(prev) and _ASCII_WORD.match(nxt):
                out.append(" ")
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def to_halfwidth(text: str) -> str:
    """全角の英数字と記号だけを半角にする（かな・漢字は触らない）。"""
    out = []
    for ch in text:
        code = ord(ch)
        if 0xFF10 <= code <= 0xFF19 or 0xFF21 <= code <= 0xFF3A \
                or 0xFF41 <= code <= 0xFF5A:
            out.append(chr(code - 0xFEE0))
        elif ch == "　":
            out.append(" ")
        else:
            out.append(ch)
    return "".join(out)


def tidy(text: str, *, punctuation: bool = True, fillers: bool = False,
         halfwidth: bool = False) -> str:
    """貼り付ける前の最終整形。"""
    text = strip_tags(text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # 改行は潰す（1区間は1まとまりとして入力する）
    text = re.sub(r"\n+", "", text)
    if fillers:
        text = _FILLER_RE.sub("", text)
    text = squeeze_spaces(text)
    if halfwidth:
        text = to_halfwidth(text)
    if not punctuation:
        text = _PUNCT_RE.sub("", text)
    text = text.strip(" \t　")
    # 先頭に句読点だけが来ることがあるので落とす
    text = re.sub(r"^[、。,.\s]+", "", text)
    return text


# 記号や句読点だけの結果は、物音を拾ったときの誤認識なので入力しない。
_SYMBOLS = re.compile(r"[\s、。，．,.…・ー~～\-〜？！?!「」『』（）()\[\]　]+")


def is_noise(text: str) -> bool:
    core = _SYMBOLS.sub("", text)
    if not core:
        return True
    # 半角記号 1 文字だけ、も捨てる（"." や "?" が単独で出ることがある）
    return len(core) == 1 and not core.isalnum() and ord(core) < 0x3000


# 末尾の断片として捨てる対象の仮名。相づち・感動詞の 1〜2 文字。
_TAIL_FRAGMENTS = frozenset("うんあえ")


def is_tail_fragment(text: str) -> bool:
    """テキストが「う」「うん」等の仮名 1〜2 文字だけかどうか。

    発話の末尾に紛れ込む断片の判定（使う条件は呼び出し側:
    本文が既に確定している・最終区間・短い音、の全部が揃った時
    だけ捨てる）。発話全体が「うん」のような短い応答だけの場合は
    本文扱いで、ここが True でも呼び出し側は捨てない。
    """
    core = _SYMBOLS.sub("", text)
    return 1 <= len(core) <= 2 and all(
        ch in _TAIL_FRAGMENTS for ch in core)


# ---------------------------------------------------------------- 幻覚の除外


# 学習データ（字幕や動画）に由来する、音と関係なく出てくる定型句。
# 無音や雑音を聞かせたときに、これらがそのまま出ることがある。
HALLUCINATIONS = (
    "ご視聴ありがとうございました",
    "ご覧いただきありがとうございました",
    "チャンネル登録",
    "最後までご覧いただき",
    "字幕提供",
    "字幕by",
    "本日はご覧いただき",
    "お疲れ様でした",
    "Thank you for watching",
    "Subtitles by",
    "Amara.org",
    "Thanks for watching",
    "Please subscribe",
    "www.",
    "http",
)

# 日本語として出てくるはずのない文字の並び（韓国語・キリル文字・タイ文字など）。
# 無音を聞かせたときに 1 文字だけ出ることがあるので、短い結果では弾く。
_FOREIGN = re.compile(
    r"[가-힯"          # ハングル
    r"Ѐ-ӿ"           # キリル文字
    r"฀-๿"           # タイ文字
    r"؀-ۿ"           # アラビア文字
    r"ऀ-ॿ]")         # デーバナーガリー
_JAPANESE = re.compile(r"[぀-ヿ一-鿿]")
_KANA = re.compile(r"[ぁ-ゖァ-ヺー]")
# 日本語の文章ではまず使わない字。簡体字や、中国語の感嘆詞など。
# 無音や物音に対してモデルが返してきたものを、実際のログから拾って並べた。
_CHINESE_ONLY = re.compile(
    r"[诶这哎嗯呃么个们来过还说没吗吧呀啊哦咦嘿嘛哈咳很"
    r"對时间后对纪经济资产业务员]")

# 日本語の話し言葉として自然に出てくる、ごく短い返事。
# 「短すぎるから雑音」と決めつけないよう、ここは通す。
SHORT_WORDS = frozenset((
    "はい", "いいえ", "うん", "ええ", "はいはい", "そう", "そうです",
    "ok", "OK", "了解", "承知", "わかりました", "ありがとう",
    "お願いします", "すみません", "はいどうぞ", "どうぞ", "いえ",
))

# 日本語なら、1 文字あたりこのくらいの秒数で話す。
# これより極端に少ない文字数しか出なければ、聞き取れていないとみなす。
SECONDS_PER_CHAR = 1.5


def is_hallucination(text: str, seconds: float = 0.0, *,
                     language: str = "ja") -> tuple[bool, str]:
    """音と関係のない文字が出ていないか。(捨てるか, 理由) を返す。

    無音や雑音を聞かせると、モデルは「何か」を返してしまう。
    実測では無音で 'I.'、ピンクノイズで '我.'、ざわめきで '그.' が出た。
    これらが入力欄に入るのは、使っていていちばん困る壊れ方なので、
    3 つの手で弾く。

    1. 学習データ由来の定型句（「ご視聴ありがとうございました」など）
    2. 日本語に出てこない文字（ハングル・キリル文字など）が短い結果に混ざる
    3. 話した長さに対して、文字数が極端に少ない
       （5 秒しゃべって 1 文字、ということは起こらない）
    """
    if not text:
        return True, "空"
    core = _SYMBOLS.sub("", text)
    if not core:
        return True, "記号だけ"

    # 定型句の照合は空白をそろえてから。記号を落とした core と比べると
    # 「Thank you for watching」が「Thankyouforwatching」になって当たらない。
    flat = re.sub(r"\s+", "", text).lower()
    for phrase in HALLUCINATIONS:
        if re.sub(r"\s+", "", phrase).lower() in flat:
            return True, f"定型の幻覚 '{phrase}'"

    if language == "ja" and len(core) <= 6 and _FOREIGN.search(core):
        return True, "日本語にない文字"

    if core.strip() in SHORT_WORDS or core.lower() in SHORT_WORDS:
        return False, ""

    if seconds > 0:
        least = max(1, int(seconds / SECONDS_PER_CHAR))
        if len(core) < least:
            return True, (f"{seconds:.1f}秒に対して {len(core)} 文字しかない"
                          f"（{least} 文字は欲しい）")

    if language == "ja" and len(core) <= 2 and not _JAPANESE.search(core):
        return True, "日本語が1文字も入っていない"

    # 日本語ではまず書かない字が混ざっている。
    # SenseVoice は多言語モデルなので、日本語を指定していても
    # 物音に対して中国語を返すことがある（実際の利用ログで確認）。
    if language == "ja" and len(core) <= 6 and _CHINESE_ONLY.search(core):
        return True, "日本語では使わない字が入っている"

    # とても短いのに、かなが 1 文字もない。
    # 実際の利用ログで、1.8 秒の物音に「哎，好。」と返していた。
    # 日本語の短い発話は、ほぼ必ずかなを含む
    # （「了解」「承知」などは上の一覧で通す）。
    # 2.5 秒より短いときは判定しない。「明日」「時間」のような
    # 漢字だけの短い言葉を、取りこぼしたくないため
    # （文字を失わないほうを優先する）。
    if (language == "ja" and seconds >= 2.5 and len(core) <= 2
            and not _KANA.search(core)):
        return True, f"かなが1文字もない短い結果（{seconds:.1f}秒）"

    return False, ""


_ROMAJI_MAP = {
    "a": "あ", "i": "い", "u": "う", "e": "え", "o": "お",
    "ka": "か", "ki": "き", "ku": "く", "ke": "け", "ko": "こ",
    "sa": "さ", "shi": "し", "si": "し", "su": "す", "se": "せ", "so": "そ",
    "ta": "た", "chi": "ち", "ti": "ち", "tsu": "つ", "tu": "つ", "te": "て", "to": "と",
    "na": "な", "ni": "に", "nu": "ぬ", "ne": "ね", "no": "の",
    "ha": "は", "hi": "ひ", "fu": "ふ", "hu": "ふ", "he": "へ", "ho": "ほ",
    "ma": "ま", "mi": "み", "mu": "む", "me": "め", "mo": "も",
    "ya": "や", "yu": "ゆ", "yo": "よ",
    "ra": "ら", "ri": "り", "ru": "る", "re": "れ", "ro": "ろ",
    "la": "ら", "li": "り", "lu": "る", "le": "れ", "lo": "ろ",
    "wa": "わ", "wo": "を", "nn": "ん", "n": "ん",
    "ga": "が", "gi": "ぎ", "gu": "ぐ", "ge": "げ", "go": "ご",
    "za": "ざ", "ji": "じ", "zi": "じ", "zu": "ず", "ze": "ぜ", "zo": "ぞ",
    "da": "だ", "di": "ぢ", "du": "づ", "de": "で", "do": "ど",
    "ba": "ば", "bi": "び", "bu": "ぶ", "be": "べ", "bo": "ぼ",
    "pa": "ぱ", "pi": "ぴ", "pu": "ぷ", "pe": "ぺ", "po": "ぽ",
    "ai": "えーあい",
}


def to_hiragana(text: str) -> str:
    """カタカナをひらがなに変換し、英数字を小文字化してローマ字も変換する。"""
    buf = []
    for ch in text:
        code = ord(ch)
        if 0x30A1 <= code <= 0x30F6:
            buf.append(chr(code - 0x60))
        elif ch == "ヴ":
            buf.append("ぶ")
        elif ch == "ヵ":
            buf.append("か")
        elif ch == "ヶ":
            buf.append("け")
        elif 0xFF21 <= code <= 0xFF3A:
            buf.append(chr(code - 0xFEE0).lower())
        elif 0xFF41 <= code <= 0xFF5A:
            buf.append(chr(code - 0xFEE0))
        elif 0xFF10 <= code <= 0xFF19:
            buf.append(chr(code - 0xFEE0))
        elif "A" <= ch <= "Z":
            buf.append(ch.lower())
        elif ch in "ー〜~-":
            buf.append("ー")
        else:
            buf.append(ch)
    joined = "".join(buf)

    # 連続するアルファベットをローマ字変換
    out = []
    i = 0
    n = len(joined)
    while i < n:
        if "a" <= joined[i] <= "z":
            # 3文字, 2文字, 1文字の順で照合
            matched = False
            for length in (3, 2, 1):
                if i + length <= n:
                    sub = joined[i:i + length]
                    if sub in _ROMAJI_MAP:
                        out.append(_ROMAJI_MAP[sub])
                        i += length
                        matched = True
                        break
            if not matched:
                out.append(joined[i])
                i += 1
        else:
            out.append(joined[i])
            i += 1
    return "".join(out)


def levenshtein_distance(s1: str, s2: str, max_dist: int = 2) -> int:
    """枝刈り付きレーベンシュタイン距離。max_dist を超えたら早期終了。"""
    if s1 == s2:
        return 0
    l1, l2 = len(s1), len(s2)
    if abs(l1 - l2) > max_dist:
        return max_dist + 1
    if l1 < l2:
        s1, s2, l1, l2 = s2, s1, l2, l1
    prev = list(range(l2 + 1))
    for i, c1 in enumerate(s1, 1):
        curr = [i] * (l2 + 1)
        min_val = i
        for j, c2 in enumerate(s2, 1):
            cost = 0 if c1 == c2 else 1
            curr[j] = min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost)
            if curr[j] < min_val:
                min_val = curr[j]
        if min_val > max_dist:
            return max_dist + 1
        prev = curr
    return prev[-1]


_SAFE_BOUNDS = set("はがをにへとでのからもねよかて、。 　!?！？「」『』（）()\n")


class AutoDictEntry:
    """表記と読みによる自動補正エントリ。"""

    def __init__(self, surface: str, reading: str = "") -> None:
        self.surface = surface
        # 主読み（ひらがな）
        r1 = to_hiragana(reading) if reading else to_hiragana(surface)
        # 表記自体のひらがな（漢字が混ざる場合など）
        r2 = to_hiragana(surface)
        readings = [r1]
        if r2 and r2 not in readings:
            readings.append(r2)
        self.readings = readings
        self.reading = r1
        self.r_len = len(r1)
        self.exact = (self.r_len <= 3)
        self.max_dist = 0 if self.exact else (1 if self.r_len <= 6 else 2)
        self.bigrams = {r1[i:i + 2] for i in range(len(r1) - 1)}
        if len(readings) > 1:
            for r in readings[1:]:
                self.bigrams.update({r[i:i + 2] for i in range(len(r) - 1)})


class DictRow:
    """辞書ファイル上の1行を表す構造。"""

    def __init__(self, surface: str, reading: str = "", mishearing: str = "",
                 is_regex: bool = False, raw: str = "") -> None:
        self.surface = surface
        self.reading = reading or to_hiragana(surface)
        self.mishearing = mishearing
        self.is_regex = is_regex
        self.raw = raw

    def to_tuple(self) -> tuple[str, str]:
        # 既存互換（左側＝元または読み、右側＝正しい表記）
        return (self.mishearing or self.reading, self.surface)

    def to_dict(self) -> dict[str, Any]:
        return {
            "surface": self.surface,
            "reading": self.reading,
            "mishearing": self.mishearing,
            "is_regex": self.is_regex,
        }


class Dictionary:
    """dictionary.txt を読み、保存されたら自動で読み直す。

    従来の「誤認識=正しい表記」に加えて、
    「正しい表記:読み」または「正しい表記」だけの登録で、
    似た読みに聞き間違えた語を自動修正する。
    """

    def __init__(self, path: Path = DICT_PATH) -> None:
        self.path = path
        self._mtime = -1.0
        self._pairs: list[tuple[str, str]] = []
        self._regex: list[tuple[re.Pattern[str], str]] = []
        self._auto_entries: list[AutoDictEntry] = []
        self._hints: list[str] = []
        self._rows: list[DictRow] = []
        self.reload(force=True)

    # ------------------------------------------------------------------ 読み

    def reload(self, *, force: bool = False) -> bool:
        try:
            mtime = self.path.stat().st_mtime
        except OSError:
            if force:
                log.warning("dictionary.txt が見つかりません: %s", self.path)
                self._pairs, self._regex, self._auto_entries = [], [], []
                self._hints, self._rows = [], []
            return False
        if not force and mtime == self._mtime:
            return False
        self._mtime = mtime

        pairs: list[tuple[str, str]] = []
        regex: list[tuple[re.Pattern[str], str]] = []
        auto_entries: list[AutoDictEntry] = []
        hints: list[str] = []
        rows: list[DictRow] = []

        try:
            lines = self.path.read_text("utf-8-sig").splitlines()
        except UnicodeDecodeError:
            from .configstore import quarantine  # noqa: PLC0415
            quarantine(self.path, "文字コードを読めません")
            self._pairs, self._regex, self._auto_entries = [], [], []
            self._hints, self._rows = [], []
            return False
        except Exception:
            log.exception("dictionary.txt を読めませんでした")
            return False

        for lineno, line in enumerate(lines, 1):
            raw_line = line
            line = line.strip()
            if not line or line.startswith("#"):
                continue

            if "=" in line:
                # 従来の置き換えルール（聞き間違い=正しい表記）
                left, right = line.split("=", 1)
                left, right = left.strip(), right.strip()
                if not left or not right:
                    continue
                if left.startswith("re:"):
                    try:
                        pat = re.compile(left[3:])
                        regex.append((pat, right))
                        rows.append(DictRow(surface=right, reading="",
                                            mishearing=left, is_regex=True,
                                            raw=raw_line))
                    except re.error as exc:
                        log.warning("dictionary.txt %d行目: 正規表現が不正(%s): %s",
                                    lineno, exc, line)
                    continue
                pairs.append((left, right))
                rows.append(DictRow(surface=right, reading=to_hiragana(right),
                                    mishearing=left, is_regex=False,
                                    raw=raw_line))
                if right and right not in hints:
                    hints.append(right)
            elif ":" in line:
                # 新形式（正しい表記:読み）
                surface, reading = line.split(":", 1)
                surface, reading = surface.strip(), reading.strip()
                if not surface:
                    continue
                auto_entries.append(AutoDictEntry(surface, reading))
                rows.append(DictRow(surface=surface, reading=reading,
                                    mishearing="", is_regex=False,
                                    raw=raw_line))
                if surface not in hints:
                    hints.append(surface)
            else:
                # 新形式（正しい表記単体、読みは自動解決）
                surface = line
                reading = to_hiragana(surface)
                auto_entries.append(AutoDictEntry(surface, reading))
                rows.append(DictRow(surface=surface, reading=reading,
                                    mishearing="", is_regex=False,
                                    raw=raw_line))
                if surface not in hints:
                    hints.append(surface)

        # 長い語から置き換える
        pairs.sort(key=lambda p: len(p[0]), reverse=True)
        # 自動修正も長い語から
        auto_entries.sort(key=lambda e: e.r_len, reverse=True)

        self._pairs, self._regex, self._auto_entries = pairs, regex, auto_entries
        self._hints, self._rows = hints, rows
        log.info("辞書を読み込みました: 置き換え %d 件 / 自動修正 %d 件 / 正規表現 %d 件",
                 len(pairs), len(auto_entries), len(regex))
        return True

    # ------------------------------------------------------------------ 書き

    def entries(self) -> list[tuple[str, str]]:
        """既存コード・テストとの互換用タプル一覧。"""
        self.reload()
        return [r.to_tuple() for r in self._rows]

    def detailed_entries(self) -> list[dict[str, Any]]:
        """設定画面用の詳細エントリ一覧。"""
        self.reload()
        return [r.to_dict() for r in self._rows]

    def save(self, rows: list[Any]) -> bool:
        """設定画面で編集した内容を書き戻す。"""
        header: list[str] = []
        try:
            for line in self.path.read_text("utf-8-sig").splitlines():
                if line.strip().startswith("#") or not line.strip():
                    header.append(line)
                else:
                    break
        except OSError:
            pass
        if not header:
            header = [
                "# ユーザー辞書  （保存するとすぐ反映されます）",
                "# ・正しい表記:読み （似た読みに聞き間違えたものを自動で直します）",
                "# ・誤認識=正しい表記 （特定の聞き間違いを直接置き換えます）",
            ]

        body: list[str] = []
        for r in rows:
            if isinstance(r, dict):
                surface = str(r.get("surface", "")).strip()
                reading = str(r.get("reading", "")).strip()
                mishearing = str(r.get("mishearing", "")).strip()
                if not surface:
                    continue
                if mishearing:
                    body.append(f"{mishearing}={surface}")
                elif reading and reading != to_hiragana(surface):
                    body.append(f"{surface}:{reading}")
                else:
                    body.append(surface)
            elif isinstance(r, (list, tuple)) and len(r) >= 2:
                left, right = str(r[0]).strip(), str(r[1]).strip()
                if not right and left:
                    right = left
                    left = ""
                if not right:
                    continue
                if left and left != to_hiragana(right):
                    body.append(f"{left}={right}")
                else:
                    if left and left != to_hiragana(right):
                        body.append(f"{right}:{left}")
                    else:
                        body.append(right)

        text = "\n".join(header + [""] + body) + "\n"
        tmp = self.path.with_suffix(".txt.tmp")
        try:
            tmp.write_text(text, "utf-8")
            tmp.replace(self.path)
        except OSError:
            log.exception("dictionary.txt を保存できませんでした")
            tmp.unlink(missing_ok=True)
            return False
        self.reload(force=True)
        return True

    def import_text(self, text: str, *, replace: bool = False) -> int:
        lines = text.lstrip("﻿").splitlines()
        incoming: list[dict[str, str]] = []
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                left, right = line.split("=", 1)
                if left.strip() and right.strip():
                    incoming.append({"surface": right.strip(),
                                     "reading": to_hiragana(right.strip()),
                                     "mishearing": left.strip()})
            elif ":" in line:
                surface, reading = line.split(":", 1)
                if surface.strip():
                    incoming.append({"surface": surface.strip(),
                                     "reading": reading.strip(),
                                     "mishearing": ""})
            else:
                incoming.append({"surface": line,
                                 "reading": to_hiragana(line),
                                 "mishearing": ""})
        current = [] if replace else self.detailed_entries()
        known = {r["surface"] + "||" + r.get("mishearing", "") for r in current}
        added = [r for r in incoming
                 if (r["surface"] + "||" + r.get("mishearing", "")) not in known]
        self.save(current + added)
        return len(added)

    def export_text(self) -> str:
        lines = []
        for r in self.detailed_entries():
            if r["mishearing"]:
                lines.append(f"{r['mishearing']}={r['surface']}")
            elif r["reading"] and r["reading"] != to_hiragana(r["surface"]):
                lines.append(f"{r['surface']}:{r['reading']}")
            else:
                lines.append(r["surface"])
        return "\n".join(lines) + "\n"

    def export_file(self, path: Path) -> bool:
        try:
            Path(path).write_text(self.export_text(), "utf-8")
            return True
        except Exception:
            log.exception("辞書を書き出せませんでした: %s", path)
            return False

    # ------------------------------------------------------------------ 利用

    def _apply_auto(self, text: str) -> str:
        """登録語の読みと似た箇所を自動置換する（10ms 以内で完了）。"""
        if not text or not self._auto_entries:
            return text

        h_chars = []
        char_map = []
        for i, ch in enumerate(text):
            h = to_hiragana(ch)
            for hc in h:
                h_chars.append(hc)
                char_map.append(i)
        char_map.append(len(text))
        h_text = "".join(h_chars)
        h_len = len(h_text)

        text_bigrams = {h_text[i:i + 2] for i in range(h_len - 1)}
        matches: list[tuple[int, int, AutoDictEntry, int, float]] = []

        for entry in self._auto_entries:
            for reading in entry.readings:
                r_len = len(reading)
                exact = (r_len <= 3)
                max_dist = 0 if exact else (1 if r_len <= 6 else 2)

                # 短語（3文字以下）は完全一致かつ単語境界判定
                if exact:
                    idx = 0
                    while True:
                        pos = h_text.find(reading, idx)
                        if pos == -1:
                            break
                        prev_ok = (pos == 0) or (h_text[pos - 1] in _SAFE_BOUNDS) or (ord(h_text[pos - 1]) >= 0x4E00)
                        next_ok = (pos + r_len == h_len) or (h_text[pos + r_len] in _SAFE_BOUNDS) or (ord(h_text[pos + r_len]) >= 0x4E00)
                        if prev_ok and next_ok:
                            matches.append((char_map[pos], char_map[pos + r_len], entry, 0, 1.0))
                        idx = pos + 1
                    continue

                # 長語（4文字以上）: バイグラムが1つも含まれなければ高速スキップ
                r_bigrams = {reading[k:k + 2] for k in range(r_len - 1)}
                if r_bigrams and not (r_bigrams & text_bigrams):
                    continue

                widths = (r_len, r_len - 1, r_len + 1) if r_len <= 6 else (
                    r_len, r_len - 1, r_len + 1, r_len - 2, r_len + 2
                )
                for w in widths:
                    if w <= 0 or w > h_len:
                        continue
                    for i in range(h_len - w + 1):
                        sub = h_text[i:i + w]
                        # 先頭文字または末尾文字がかすっていなければスキップ
                        if sub[0] != reading[0] and sub[-1] != reading[-1]:
                            continue
                        dist = levenshtein_distance(sub, reading, max_dist)
                        if dist <= max_dist:
                            sim = 1.0 - (dist / max(r_len, w))
                            if sim >= 0.80:
                                matches.append((char_map[i], char_map[i + w], entry, dist, sim))

        if not matches:
            return text

        # 重複解消: 類似度が高い順、長い順、誤り数が少ない順
        matches.sort(key=lambda m: (m[4], m[2].r_len, -m[3]), reverse=True)

        selected: list[tuple[int, int, str]] = []
        occupied = [False] * len(text)
        for s, e, entry, dist, sim in matches:
            if not any(occupied[s:e]):
                for k in range(s, e):
                    occupied[k] = True
                selected.append((s, e, entry.surface))

        selected.sort(key=lambda x: x[0], reverse=True)
        res = list(text)
        for s, e, surface in selected:
            res[s:e] = list(surface)
        return "".join(res)

    def apply(self, text: str) -> str:
        self.reload()
        if not text:
            return text
        # 1. 従来の置き換えルール（明示的な聞き間違い、正規表現）
        for src, dst in self._pairs:
            if src and src != dst and src in text:
                text = text.replace(src, dst)
        for pat, dst in self._regex:
            try:
                text = pat.sub(dst, text)
            except re.error:
                log.warning("正規表現の置き換えに失敗: %s", pat.pattern)
        # 2. 自動修正ルール（似た読みに聞き間違えた語を自動補正）
        text = self._apply_auto(text)
        return text

    @property
    def hints(self) -> list[str]:
        self.reload()
        return list(self._hints)

    def hint_string(self) -> str:
        return "、".join(self.hints)


def normalize_key(text: str) -> str:
    return unicodedata.normalize("NFKC", text).strip().lower()
