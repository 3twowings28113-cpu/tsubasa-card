"""表示言語（日本語 / English）。

外部ライブラリを使わないので、辞書を 1 つ持つだけの簡素なつくり。
`t("key")` で現在の言語の文字列を返す。見つからなければキーをそのまま返す。
"""

from __future__ import annotations

import logging

log = logging.getLogger(__name__)

_lang = "ja"

STRINGS: dict[str, dict[str, str]] = {
    # ---- 共通 ----
    "app.name": {"ja": "SpeakPulse", "en": "SpeakPulse"},
    "app.tagline": {"ja": "日本語音声入力 ＆ AI・多機能スイート",
                    "en": "Voice typing & smart AI suite"},
    "common.on": {"ja": "オン", "en": "On"},
    "common.off": {"ja": "オフ", "en": "Off"},
    "common.add": {"ja": "追加", "en": "Add"},
    "common.edit": {"ja": "編集", "en": "Edit"},
    "common.delete": {"ja": "削除", "en": "Delete"},
    "common.close": {"ja": "閉じる", "en": "Close"},
    "common.cancel": {"ja": "キャンセル", "en": "Cancel"},
    "common.save": {"ja": "保存", "en": "Save"},
    "common.search": {"ja": "検索", "en": "Search"},
    "common.import": {"ja": "読み込み", "en": "Import"},
    "common.export": {"ja": "書き出し", "en": "Export"},
    "common.copy": {"ja": "コピー", "en": "Copy"},
    "common.clear": {"ja": "すべて削除", "en": "Clear all"},
    "common.open": {"ja": "開く", "en": "Open"},
    "common.download": {"ja": "ダウンロード", "en": "Download"},
    "common.use": {"ja": "使う", "en": "Use"},
    "common.inuse": {"ja": "使用中", "en": "In use"},
    "common.installed": {"ja": "ダウンロード済み", "en": "Installed"},
    "common.notinstalled": {"ja": "未ダウンロード", "en": "Not downloaded"},
    "common.restart_needed": {"ja": "再起動後に反映されます",
                              "en": "Takes effect after restart"},
    "common.autosaved": {"ja": "変更は自動で保存され、すぐ反映されます",
                         "en": "Changes are saved and applied immediately"},
    "common.none": {"ja": "（なし）", "en": "(none)"},
    "common.default": {"ja": "Windows で選ばれているマイク", "en": "Default microphone"},
    "common.yes": {"ja": "はい", "en": "Yes"},
    "common.no": {"ja": "いいえ", "en": "No"},

    # ---- トレイ ----
    "tray.settings": {"ja": "設定", "en": "Settings"},
    "tray.dictionary": {"ja": "ユーザー辞書", "en": "User dictionary"},
    "tray.history": {"ja": "履歴", "en": "History"},
    "tray.log": {"ja": "ログを開く", "en": "Open log"},
    "tray.restart": {"ja": "再起動", "en": "Restart"},
    "tray.quit": {"ja": "終了", "en": "Quit"},
    "tray.idle": {"ja": "SpeakPulse（待機中）", "en": "SpeakPulse (idle)"},
    "tray.overlay_text": {"ja": "話している文字をオーバーレイに出す",
                          "en": "Show your words on the overlay"},
    "tray.pause": {"ja": "一時停止（ショートカットを手放す）",
                   "en": "Pause (release the shortcut)"},
    "tray.paused": {"ja": "SpeakPulse（一時停止中）",
                    "en": "SpeakPulse (paused)"},
    "tray.recording": {"ja": "SpeakPulse（録音中）", "en": "SpeakPulse (recording)"},
    "tray.transcribing": {"ja": "SpeakPulse（文字起こし中）",
                          "en": "SpeakPulse (transcribing)"},
    "tray.copy_last": {"ja": "最後の結果をクリップボードにコピー",
                       "en": "Copy last result to clipboard"},
    "tray.punctuation": {"ja": "句読点の量", "en": "Punctuation density"},
    "tray.punct_few": {"ja": "少なめ（推奨）", "en": "Few (recommended)"},
    "tray.punct_normal": {"ja": "標準", "en": "Standard"},
    "tray.punct_many": {"ja": "多め", "en": "Many"},
    "tray.language": {"ja": "認識言語", "en": "Recognition language"},
    "tray.lang_ja": {"ja": "日本語", "en": "Japanese"},
    "tray.lang_en": {"ja": "英語", "en": "English"},
    "tray.lang_auto": {"ja": "自動（音声から推測）", "en": "Auto (detect)"},
    "tray.voice_commands": {"ja": "音声コマンド（改行・まる・送って）",
                            "en": "Voice commands (enter, period, etc.)"},
    "tray.model": {"ja": "文字起こしモデル", "en": "Recognition model"},

    # ---- オーバーレイ通知 ----
    "overlay.lang_changed": {"ja": "認識言語: {val}",
                             "en": "Recognition language: {val}"},
    "overlay.punct_changed": {"ja": "句読点: {val}",
                              "en": "Punctuation: {val}"},
    "overlay.model_changed": {"ja": "モデル: {name}",
                              "en": "Model: {name}"},
    "overlay.commands_on": {"ja": "音声コマンド: オン",
                            "en": "Voice commands: On"},
    "overlay.commands_off": {"ja": "音声コマンド: オフ",
                             "en": "Voice commands: Off"},
    "overlay.slow_marked": {"ja": "「重かった」を記録しました",
                            "en": "Marked slow response in log"},
    "overlay.action_running_translate_en": {"ja": "英語に翻訳中…",
                                            "en": "Translating to English..."},
    "overlay.action_running_polite": {"ja": "敬語に変換中…",
                                      "en": "Converting to polite form..."},
    "overlay.action_running_business": {"ja": "ビジネス敬語に変換中…",
                                        "en": "Converting to business form..."},
    "overlay.action_running_summary": {"ja": "要約中…",
                                       "en": "Summarising..."},
    "overlay.action_running_slack_report": {"ja": "Slack報告文に整形中…",
                                            "en": "Formatting Slack report..."},
    "overlay.action_running_custom": {"ja": "カスタム指示で処理中…",
                                      "en": "Processing with custom prompt..."},
    "overlay.action_running_ai_auto_edit": {"ja": "AI自動編集中…",
                                            "en": "AI auto-editing..."},
    "overlay.action_running_reply_generator": {
        "ja": "返信文を作成中…", "en": "Generating reply..."},
    "overlay.action_running_meeting_minutes": {
        "ja": "議事録を作成中…", "en": "Creating meeting minutes..."},
    "overlay.action_running_proofread": {
        "ja": "文章を推敲中…", "en": "Proofreading..."},
    "overlay.action_running_standardize": {
        "ja": "標準語に整え中…", "en": "Standardising..."},
    "overlay.action_running_brainstorm": {
        "ja": "企画骨子を作成中…", "en": "Structuring proposal..."},
    "overlay.action_running_smart_calc": {
        "ja": "計算・日付処理中…", "en": "Calculating..."},
    "overlay.action_done_translate_en": {"ja": "英語に翻訳しました",
                                         "en": "Translated to English"},
    "overlay.action_done_polite": {"ja": "敬語に変換しました",
                                   "en": "Converted to polite form"},
    "overlay.action_done_business": {"ja": "ビジネス敬語に変換しました",
                                     "en": "Converted to business form"},
    "overlay.action_done_summary": {"ja": "要約しました",
                                    "en": "Summarised"},
    "overlay.action_done_slack_report": {"ja": "Slack報告文に整形しました",
                                         "en": "Formatted Slack report"},
    "overlay.action_done_custom": {"ja": "変換しました",
                                   "en": "Transformed"},
    "overlay.action_done_ai_auto_edit": {"ja": "AI自動編集が完了しました",
                                         "en": "AI auto-edit completed"},
    "overlay.action_done_reply_generator": {
        "ja": "返信文を作成しました", "en": "Reply generated"},
    "overlay.action_done_meeting_minutes": {
        "ja": "議事録を作成しました", "en": "Meeting minutes created"},
    "overlay.action_done_proofread": {
        "ja": "推敲が完了しました", "en": "Proofreading completed"},
    "overlay.action_done_standardize": {
        "ja": "標準語に整えました", "en": "Standardised"},
    "overlay.action_done_brainstorm": {
        "ja": "企画骨子を作成しました", "en": "Proposal structured"},
    "overlay.action_done_smart_calc": {
        "ja": "計算・日付を入力しました", "en": "Calculated and typed"},
    "overlay.screen_assistant_running": {
        "ja": "画面を解析中（ジャービス）…", "en": "Analyzing screen..."},
    "overlay.screen_assistant_done": {
        "ja": "画面AIの処理が完了しました", "en": "Screen assistant completed"},
    "overlay.calendar_opened": {
        "ja": "Googleカレンダーの予定作成を開きました",
        "en": "Opened Google Calendar event"},

    # ---- Google レンズ連携（かこって検索のエンジンが Google のとき） ----
    "googlelens.not_installed": {
        "ja": "Google アプリが入っていません。設定の「かこって検索の"
              "エンジン」を Google レンズにしている場合は、先に"
              "Google アプリを入れてください",
        "en": "The Google app is not installed. Install it first "
              "to use Google Lens as the circle-to-search engine"},
    "googlelens.launched": {
        "ja": "Google アプリの起動が間に合いませんでした。少し待って"
              "かこって検索を押してください",
        "en": "The Google app did not start in time. Wait a "
              "moment, then try circle-to-search again"},
    "googlelens.hotkey_not_configured": {
        "ja": "Google レンズのショートカットが未設定なので、"
              "まだ呼び出せません（既定の組み合わせは確認中です）",
        "en": "The Google Lens shortcut is not configured yet, "
              "so Lens cannot be opened"},
    "googlelens.ready": {
        "ja": "Google レンズを呼び出しました",
        "en": "Opened Google Lens"},
    "googlelens.launch_failed": {
        "ja": "Google アプリを起動できませんでした",
        "en": "Could not start the Google app"},
    "googlelens.installed": {
        "ja": "Google アプリを入れました",
        "en": "Installed the Google app"},
    "googlelens.install_failed": {
        "ja": "Google アプリを入れられませんでした",
        "en": "Could not install the Google app"},

    # ---- 画面下の表示 ----
    # --- つなぎ言葉の一覧
    "model.cer_label": {"ja": "文字誤り率", "en": "Character error rate"},
    "dict.hints_unsupported": {
        "ja": "いま使っているモデル（{model}）では使えません",
        "en": "The model you are using ({model}) does not support this"},
    "settings.stream_only": {
        "ja": "「話しながら」のときだけ使います",
        "en": "Only used in “While you speak” mode"},
    "fillers.hint": {
        "ja": "ここに書いた言葉を、文字起こしから取り除きます。"
              "語の前後が句読点か文の端のときだけ消すので、"
              "「なんかしら」の「なんか」は残ります。",
        "en": "Words listed here are removed from the transcript. A word is "
              "only removed when it stands alone, so ordinary words "
              "containing it are untouched."},
    "fillers.placeholder": {"ja": "消したい言葉を入れて Enter",
                            "en": "Type a word and press Enter"},
    "fillers.default": {
        "ja": "初期の一覧を使っています（えーと、あのー、なんか など）",
        "en": "Using the built-in list (um, er, like, and so on)"},
    "fillers.reset": {"ja": "初期の一覧に戻す", "en": "Back to the built-in list"},
    # --- 記号の呼び方
    "symbols.say": {"ja": "言葉", "en": "Word"},
    "symbols.symbol": {"ja": "記号", "en": "Symbol"},
    "symbols.on": {"ja": "使う", "en": "On"},
    "symbols.add": {"ja": "追加", "en": "Add"},
    "symbols.empty": {"ja": "登録されている言葉はありません",
                      "en": "No words registered"},
    "symbols.word_placeholder": {"ja": "言葉（例：びっくり）",
                                "en": "Word (e.g. bikkuri)"},
    "symbols.symbol_placeholder": {"ja": "記号（例：！）",
                                  "en": "Symbol (e.g. !)"},
    # --- 音声コマンド
    "commands.hint": {
        "ja": "言い方を足したり、個別に止めたりできます。",
        "en": "Add your own wordings, or switch one off."},
    "commands.say": {"ja": "言い方", "en": "Say"},
    "commands.does": {"ja": "すること", "en": "Does"},
    "commands.on": {"ja": "使う", "en": "On"},
    # --- 動作チェック
    "doctor.run": {"ja": "調べる", "en": "Check"},
    "doctor.again": {"ja": "もう一度調べる", "en": "Check again"},
    "doctor.idle": {"ja": "", "en": ""},
    "doctor.running": {"ja": "調べています…", "en": "Checking…"},
    "doctor.counts": {"ja": "問題なし {ok} / 注意 {warn} / エラー {bad}",
                      "en": "{ok} ok / {warn} warn / {bad} errors"},
    "doctor.all_ok": {"ja": "使える状態です（{n} 項目すべて問題なし）",
                      "en": "Everything is ready ({n} checks passed)"},
    "doctor.some_warn": {
        "ja": "使えますが、気になる点が {warn} 件あります",
        "en": "Usable, but {warn} thing(s) deserve a look"},
    "doctor.some_bad": {"ja": "このままでは使えません（{bad} 件）",
                        "en": "Not usable yet ({bad} problem(s))"},
    "doctor.details": {"ja": "くわしく見る", "en": "Show details"},
    "doctor.hide": {"ja": "たたむ", "en": "Hide"},
    "tray.slow": {"ja": "いま重かった（記録を残す）",
                  "en": "It just got slow (save a trace)"},
    "overlay.keys_lost": {
        "ja": "ショートカットが外れたので付け直しました",
        "en": "The shortcut was lost, so it was registered again"},
    "overlay.paused": {
        "ja": "一時停止しました（トレイからもう一度押すと戻ります）",
        "en": "Paused — choose it again in the tray to resume"},
    "overlay.resumed": {"ja": "再開しました", "en": "Resumed"},
    "overlay.text_on": {"ja": "話している文字をオーバーレイに出します",
                        "en": "Showing your words on the overlay"},
    "overlay.text_off": {"ja": "話している文字はオーバーレイに出しません",
                         "en": "Your words are hidden from the overlay"},
    "overlay.slow_marked": {
        "ja": "そのときの記録を残しました",
        "en": "Saved a trace of what just happened"},
    "overlay.punct_changed": {
        "ja": "句読点: {val} にしました",
        "en": "Punctuation set to {val}"},
    "overlay.commands_on": {
        "ja": "音声コマンドを有効にしました",
        "en": "Voice commands enabled"},
    "overlay.commands_off": {
        "ja": "音声コマンドを無効にしました",
        "en": "Voice commands disabled"},
    "overlay.model_changed": {
        "ja": "モデル: {name} に切り替えました",
        "en": "Switched model to {name}"},
    "overlay.copied": {
        "ja": "クリップボードにコピーしました",
        "en": "Copied to clipboard"},
    "tray.repaste": {"ja": "最後の結果をもう一度入れる",
                     "en": "Type the last result again"},
    "dict.add_starter": {"ja": "定番・AI単語パックを追加",
                         "en": "Add Starter & AI Pack"},
    "dict.add_starter_hint": {
        "ja": "Google各種、Slack、ChatGPT、主要アプリなど200語以上を一括追加",
        "en": "Adds 200+ essential words (Google, Slack, ChatGPT, apps)"},
    "overlay.preview_title": {"ja": "見た目のプレビュー", "en": "Live Preview"},
    "overlay.preview_hint": {
        "ja": "設定を変えるとリアルタイムに反映されます",
        "en": "Updates in real time as you change settings"},
    "overlay.test_btn": {"ja": "実際の画面でテスト表示（3秒）",
                         "en": "Test on desktop (3s)"},
    "overlay.recording": {"ja": "録音中", "en": "Recording"},
    "overlay.listening": {"ja": "聞いています", "en": "Listening"},
    "overlay.working": {"ja": "文字にしています", "en": "Writing it down"},
    "overlay.stopped": {"ja": "止まりました", "en": "Stopped"},
    # {stop} と {cancel} は、設定したキーの名前に置き換わる
    "overlay.hint": {"ja": "{stop} で止める　・　{cancel} で取り消し",
                     "en": "{stop} to stop  ·  {cancel} to cancel"},
    "overlay.transcribing": {"ja": "文字起こし中…", "en": "Transcribing…"},
    "overlay.cancelled": {"ja": "中止しました", "en": "Cancelled"},
    "overlay.cancelled_partial": {
        "ja": "中止しました（入力済みの分は残ります）",
        "en": "Cancelled — what was already typed stays"},
    "overlay.mic_error": {"ja": "マイクを開けません", "en": "Cannot open microphone"},
    "overlay.failed": {"ja": "文字起こしに失敗", "en": "Transcription failed"},
    "overlay.paste_failed": {"ja": "入力に失敗", "en": "Could not type text"},
    "overlay.no_model": {"ja": "モデル未設定", "en": "No model selected"},
    "overlay.copied": {"ja": "コピーしました（Ctrl+V で貼れます）",
                       "en": "Copied — press Ctrl+V to paste"},
    "historypick.title": {
        "ja": "最近の文字起こし（選ぶと貼り付け）",
        "en": "Recent transcripts (pick to paste)"},
    "historypick.edit_hint": {
        "ja": "（↑↓で選んで F2: 直す）",
        "en": " (↑↓ to select, F2: fix)"},

    # ---- 直す（編集ポップアップ） ----
    "fixwin.title": {"ja": "直前の入力を直す", "en": "Fix the last input"},
    "fixwin.hint": {
        "ja": "青い部分は同音異義語です。クリック（または Ctrl+↑↓ で"
              "移動して Alt+Enter）で候補から差し替えられます。",
        "en": "Highlighted words are homophones. Click one (or move "
              "with Ctrl+↑/↓ and press Alt+Enter) to swap it."},
    "fixwin.candidates": {
        "ja": "学習候補（チェックした置き換えだけを学習します）",
        "en": "Learning candidates (only checked pairs are learned)"},
    "fixwin.candidates_none": {
        "ja": "学習候補（直すと、ここに候補が出ます）",
        "en": "Learning candidates (fix something to see them here)"},
    "fixwin.candidates_more": {
        "ja": "ほか {n} 件は表示していません",
        "en": "{n} more not shown"},
    "fixwin.save": {"ja": "保存して戻す", "en": "Save and put back"},
    "fixwin.learned_view": {"ja": "学習済みを見る",
                            "en": "View learned"},
    "fixwin.back_to_edit": {"ja": "編集に戻る", "en": "Back to editing"},
    "fixwin.delete": {"ja": "選んだものを削除",
                      "en": "Delete selected"},
    "fixwin.prev": {"ja": "前の候補", "en": "Previous"},
    "fixwin.next": {"ja": "次の候補", "en": "Next"},
    "fixwin.empty_learned": {"ja": "（まだありません）",
                             "en": "(none yet)"},
    "fix.replaced": {"ja": "直しました（その場で書き換え）",
                     "en": "Fixed in place"},
    "fix.pasted": {
        "ja": "直した文を貼りました（元の文は残っています）",
        "en": "Pasted the corrected text (the original is still there)"},
    "fix.learned_suffix": {"ja": "／{n} 件を学習",
                           "en": " / learned {n}"},
    "fix.learned_only": {"ja": "{n} 件を学習しました",
                         "en": "Learned {n} pair(s)"},
    "fix.no_change": {"ja": "変更はありませんでした",
                      "en": "No changes"},
    "fix.nothing": {"ja": "直す対象がありません",
                    "en": "Nothing to fix"},
    "overlay.nothing_to_repaste": {"ja": "貼り直せる文字がありません",
                                   "en": "Nothing to paste again"},
    "overlay.mic_recovered": {"ja": "マイクを開き直しました",
                              "en": "Reopened the microphone"},
    "overlay.undo_unavailable": {"ja": "取り消しはまだ使えません",
                                 "en": "Undo is not available yet"},
    "overlay.undone": {"ja": "取り消しました", "en": "Undone"},
    "overlay.nothing_to_undo": {"ja": "取り消せる文字がありません",
                                "en": "Nothing to undo"},
    "overlay.switched_fast": {"ja": "混んでいるので軽いモデルに替えました",
    "overlay.switched_fallback": {
        "ja": "認識が不調なので予備のモデルに替えました",
        "en": "Recognition is failing, so I switched to the backup model"},
                              "en": "Switched to the light model to keep up"},
    "overlay.loading_model": {"ja": "モデルを読み込んでいます…",
                              "en": "Loading the model…"},
    "overlay.held": {
        "ja": "元の欄に戻ると入ります（{n} 文字）",
        "en": "Will be typed when you go back ({n} chars)"},
    "overlay.held_expired": {
        "ja": "戻ってこなかったので、クリップボードに入れました（Ctrl+V で貼れます）",
        "en": "You did not come back, so it is on the clipboard (Ctrl+V)"},
    "overlay.click_spill": {
        "ja": "残りはクリップボードに入れました（Ctrl+V で貼れます）",
        "en": "The rest is on the clipboard — press Ctrl+V to paste it"},
    "overlay.saved_to_history": {
        "ja": "残りは履歴に保存しました",
        "en": "The rest is saved to history"},
    "overlay.stopped_click": {
        "ja": "クリックされたので録音を止めました",
        "en": "Stopped recording — you clicked"},
    "overlay.stopped_window": {
        "ja": "別のウィンドウに移ったので録音を止めました",
        "en": "Stopped recording — you moved to another window"},
    "overlay.stopped_silence": {
        "ja": "静かなので録音を止めました",
        "en": "Stopped recording — it went quiet"},
    "overlay.config_reset": {
        "ja": "設定が壊れていたので初期値に戻しました",
        "en": "Settings were damaged, so the defaults were restored"},

    # ---- 設定画面：カテゴリ ----
    "cat.general": {"ja": "一般", "en": "General"},
    "cat.audio": {"ja": "音声", "en": "Audio"},
    "cat.transcription": {"ja": "文字起こし", "en": "Transcription"},
    "cat.dictionary": {"ja": "ユーザー辞書", "en": "User dictionary"},
    "cat.display": {"ja": "表示", "en": "Display"},
    "cat.history": {"ja": "履歴", "en": "History"},
    "cat.app": {"ja": "アプリ", "en": "Application"},

    # ---- 設定画面：その他 ----
    "settings.title": {"ja": "koe-type の設定", "en": "koe-type Settings"},
    "settings.press_keys": {"ja": "キーを押してください（Esc で取り消し）",
                            "en": "Press a key combination (Esc to cancel)"},
    "settings.change": {"ja": "変更", "en": "Change"},
    "settings.reset_confirm": {
        "ja": "すべての設定を初期値に戻します。ユーザー辞書と履歴は消えません。よろしいですか？",
        "en": "Reset every setting to its default. "
              "The user dictionary and history are kept. Continue?"},
    "settings.reset_done": {"ja": "初期値に戻しました。", "en": "Settings were reset."},
    "settings.clear_all_confirm": {
        "ja": "履歴・録音・ユーザー辞書・ログが完全に削除され、設定も初期値に戻ります。この操作は取り消せません。本当によろしいですか？",
        "en": "Your history, audio recordings, user dictionary, and logs will be permanently deleted, and settings reset. This cannot be undone. Continue?"},
    "settings.clear_all_done": {"ja": "すべての利用データを削除しました。",
                                "en": "All user data deleted."},
    "settings.reset_item": {"ja": "初期値（{default}）に戻す",
                            "en": "Reset to default ({default})"},
    "settings.item_reset_done": {"ja": "初期値に戻しました",
                                "en": "Reset to default"},
    "settings.export": {"ja": "設定を書き出す", "en": "Export settings"},
    "settings.export_done": {"ja": "設定ファイルを書き出しました。",
                             "en": "Settings exported."},
    "settings.import": {"ja": "設定を読み込む", "en": "Import settings"},
    "settings.import_confirm": {
        "ja": "現在の設定が上書きされます。よろしいですか？",
        "en": "Your current settings will be overwritten. Continue?"},
    "settings.import_done": {"ja": "{n} 項目の設定を読み込みました。",
                             "en": "Imported {n} settings."},
    "settings.import_failed": {
        "ja": "設定ファイルの読み込みに失敗しました: {err}",
        "en": "Failed to import settings: {err}"},
    "settings.restart_now": {"ja": "再起動する", "en": "Restart now"},
    "web.mode_basic": {"ja": "よく使う設定", "en": "Basic"},
    "web.mode_advanced": {"ja": "詳しい設定", "en": "Advanced"},
    "web.basic_hidden": {"ja": "よく使う設定だけを出しています。このページには、"
                               "ほかに {n} 項目の細かい設定があります（押すと全部出します）",
                         "en": "Showing the essentials only. {n} more detailed "
                               "settings on this page — click to show all."},

    # ---- ユーザー辞書 ----
    "dict.from": {"ja": "聞き間違い（任意）", "en": "Misheard as (optional)"},
    "dict.to": {"ja": "正しい表記", "en": "Correct spelling"},
    "dict.reading": {"ja": "読み（ふりがな）", "en": "Reading (hiragana)"},
    "dict.type": {"ja": "種類", "en": "Type"},
    "dict.type_auto": {"ja": "自動補正", "en": "Auto correct"},
    "dict.type_direct": {"ja": "直接置換", "en": "Direct replace"},
    "dict.empty": {"ja": "まだ何もありません。「追加」から登録してください。",
                   "en": "Nothing here yet. Press Add to register a word."},
    "dict.count": {"ja": "{n} 件", "en": "{n} entries"},
    "dict.dup": {"ja": "同じ表記がすでにあります。",
                 "en": "That entry already exists."},
    "dict.file": {"ja": "保存先: {path}", "en": "Stored in: {path}"},
    "dict.advanced": {"ja": "上級者向け：特定の誤認識だけを置き換える",
                      "en": "Advanced: replace specific mishearing only"},

    # ---- 履歴 ----
    "history.time": {"ja": "日時", "en": "Time"},
    "history.text": {"ja": "文字起こし", "en": "Transcript"},
    "history.empty": {"ja": "履歴はありません。", "en": "No history yet."},
    "history.search": {"ja": "履歴をさがす", "en": "Search history"},
    "history.no_match": {"ja": "見つかりませんでした。",
                         "en": "Nothing matches."},
    "history.play": {"ja": "録音を聞く", "en": "Play the recording"},
    "history.stop": {"ja": "止める", "en": "Stop"},
    "history.play_failed": {"ja": "録音を鳴らせませんでした",
                            "en": "Could not play the recording"},
    "history.to_dict": {"ja": "ユーザー辞書に追加", "en": "Add to user dictionary"},
    "history.to_dict_title": {"ja": "聞き違いをユーザー辞書に登録",
                              "en": "Teach it a correction"},
    "history.to_dict_hint": {
        "ja": "「元」に聞き違えた言葉、「先」に正しい言葉を入れます。"
              "次からは自動で置き換わります。文を選んでから押すと、"
              "選んだ部分が「元」に入ります。",
        "en": "Put the misheard words in “From” and the right words in "
              "“To”. It will be replaced automatically from now on. "
              "Select part of the text first to fill in “From”."},
    "history.to_dict_done": {"ja": "ユーザー辞書に足しました",
                             "en": "Added to user dictionary"},
    "history.off": {"ja": "保存件数が 0 なので履歴を残していません。",
                    "en": "History is off (limit is 0)."},
    "history.clear_confirm": {"ja": "履歴をすべて削除します。よろしいですか？",
                              "en": "Delete the entire history. Continue?"},
    "history.copy_item": {"ja": "クリップボードにコピー", "en": "Copy to clipboard"},
    "history.paste_item": {"ja": "もう一度入力する", "en": "Type again"},
    "history.raw_label": {"ja": "修正前", "en": "Before edit"},
    "history.copied": {"ja": "コピーしました", "en": "Copied to clipboard"},
    "history.pasted": {"ja": "入力しました", "en": "Typed"},
    "history.merge": {"ja": "1つに結合", "en": "Merge items"},
    "history.merged": {"ja": "選択した履歴を1つに結合しました", "en": "Merged selected history"},

    # ---- モデル ----
    "model.accuracy": {"ja": "精度", "en": "Accuracy"},
    "model.speed": {"ja": "速さ", "en": "Speed"},
    "model.size": {"ja": "サイズ", "en": "Size"},
    "model.downloading": {"ja": "ダウンロード中 {pct}%", "en": "Downloading {pct}%"},
    "model.download_failed": {"ja": "ダウンロードに失敗しました: {err}",
                              "en": "Download failed: {err}"},
    "model.delete_confirm": {"ja": "{name} のファイルを削除します。よろしいですか？",
                             "en": "Delete the files for {name}. Continue?"},
    "model.need_download": {"ja": "先にダウンロードしてください。",
                            "en": "Download it first."},
    "model.runtime": {"ja": "実行ファイル（共通）", "en": "Engine runtime (shared)"},
    # ---- 設定画面（HTML）----
    "web.pick_app": {"ja": "開いているアプリから選ぶ",
                     "en": "Pick a running app"},
    "web.pick_app_title": {"ja": "いま開いているアプリ", "en": "Running applications"},
    "web.no_apps": {"ja": "ありません。", "en": "Nothing here."},
    "web.add_app": {"ja": "追加", "en": "Add"},
    "web.app_placeholder": {"ja": "実行ファイル名（例 Code.exe）",
                            "en": "Executable name, e.g. Code.exe"},
    "web.selected": {"ja": "選択中", "en": "Selected"},
    "web.license": {"ja": "ライセンス", "en": "Licence"},
    "web.source": {"ja": "配布元", "en": "Source"},
    "web.cer": {"ja": "文字誤り率", "en": "Error rate"},
    "web.inuse_note": {"ja": "いま使っているモデル", "en": "The model in use"},
    "web.measured": {
        "ja": "文字誤り率と速さは koe-type が実測した値です。上の 3 つは"
              "公開の日本語音声 200 本（FLEURS）、「ほかのモデル」は"
              "合成音声 16 文で測っているので、数字を並べて比べることは"
              "できません（同じ SenseVoice Small でも値が違うのはこのため）。"
              "速さは PC と GPU によって大きく変わります。",
        "en": "Error rates and speeds are koe-type's own measurements. The "
              "three above use 200 public Japanese clips (FLEURS); the "
              "“other models” use 16 synthesised sentences, so the numbers "
              "are not comparable (which is why SenseVoice Small shows two "
              "different values). Speed depends heavily on the PC and GPU."},
    "web.search_settings": {"ja": "設定をさがす", "en": "Search settings"},
    "web.search_result": {"ja": "「{q}」の検索結果",
                          "en": "Results for “{q}”"},
    "web.search_none": {
        "ja": "見つかりませんでした。別の言葉でさがしてみてください。",
        "en": "Nothing found. Try another word."},
    "web.more_models": {
        "ja": "ほかのモデル（旧方式・CPU 向け）",
        "en": "Other models (legacy, CPU-only)"},
    "web.search_placeholder": {"ja": "語をさがす", "en": "Search words"},
    "web.dict_hint": {
        "ja": "正しい表記（と読み）を登録しておくと、似た読みに聞き間違えたときに"
              "自動で直します。特定の誤認識を直接置き換えることもできます。"
              "保存するとすぐ反映されます。行をダブルクリックすると編集できます。",
        "en": "Register correct spellings and readings, and words with similar "
              "sounds will be automatically corrected. You can also specify direct "
              "replacements. Changes apply immediately. Double-click a row to edit it."},
    "web.history_hint": {
        "ja": "行を押すと選べます。▶ で録音を聞き直せます。本の印で、"
              "聞き違えた言葉をユーザー辞書に登録できます（次から自動で直ります）。"
              "履歴はこの PC の中だけにあります。",
        "en": "Click rows to select them. ▶ plays the recording; the book "
              "icon adds a misheard word to the user dictionary so it is fixed "
              "from now on. History is stored only on this PC."},
    "web.about_line": {"ja": "完全オフライン・完全無料の日本語音声入力",
                       "en": "A fully offline, free Japanese voice typing tool"},
    "web.about_folder": {"ja": "保存フォルダ:", "en": "Data folder:"},
    "web.secs": {"ja": "秒", "en": "s"},
    "web.ms": {"ja": "ミリ秒", "en": "ms"},
    "web.mins": {"ja": "分", "en": "min"},
    "web.entries": {"ja": "件", "en": "entries"},
    "web.px": {"ja": "px", "en": "px"},
    "web.done": {"ja": "できました", "en": "Done"},
    "web.import_none": {"ja": "新しく足せる言葉はありませんでした",
                        "en": "Nothing new to add"},
    "web.confirm": {"ja": "はい", "en": "Yes"},
    "web.close": {"ja": "閉じる", "en": "Close"},
    "web.model_source": {
        "ja": "モデルは公式の配布元からダウンロードします。"
              "音声がこのPCの外に出ることはありません。",
        "en": "Models are fetched from their official sources. "
              "Your audio never leaves this PC."},

    # ---- クリップボード履歴（窓） ----
    "clip.tab_history": {"ja": "履歴", "en": "History"},
    "clip.default_group": {"ja": "よく使う", "en": "Favourites"},
    "clip.search_placeholder": {"ja": "探す（文字・アプリ名・グループ名）",
                                "en": "Search text, app or name"},
    "clip.just_now": {"ja": "たった今", "en": "just now"},
    "clip.minutes_ago": {"ja": "{n}分前", "en": "{n} min ago"},
    "clip.hours_ago": {"ja": "{n}時間前", "en": "{n} h ago"},
    "clip.yesterday": {"ja": "昨日 {hm}", "en": "yesterday {hm}"},
    "clip.kind_text": {"ja": "文字", "en": "Text"},
    "clip.kind_image": {"ja": "画像", "en": "Image"},
    "clip.kind_files": {"ja": "ファイル", "en": "Files"},
    "clip.kind_link": {"ja": "リンク", "en": "Link"},
    "clip.kind_colour": {"ja": "色", "en": "Colour"},
    "clip.kind_mail": {"ja": "メールアドレス", "en": "Email address"},
    "clip.kind_secret": {"ja": "秘密（伏せ字）", "en": "Secret (hidden)"},
    "clip.kind_all": {"ja": "すべて", "en": "All"},
    "clip.more_files": {"ja": "ほか {n} 個", "en": "+{n} more"},
    "clip.blank": {"ja": "（空白だけ）", "en": "(whitespace only)"},
    "clip.files_count": {"ja": "{n} 個のファイル", "en": "{n} files"},
    "clip.chars": {"ja": "{n} 文字", "en": "{n} chars"},
    "clip.used": {"ja": "{n} 回使用", "en": "used {n}×"},
    "clip.with_format": {"ja": "書式つき", "en": "formatted"},
    "clip.unknown_app": {"ja": "アプリ不明", "en": "Unknown app"},
    "clip.secret_hint": {
        "ja": "中身は暗号化して保存しています。貼り付けたあと、"
              "しばらくするとクリップボードから自動で消えます。"
              "中身を見たり直したりするのは設定の「クリップボード」からです。",
        "en": "Stored encrypted. After pasting it is cleared from the "
              "clipboard automatically. View or change it under "
              "Settings › Clipboard."},
    "clip.no_match": {"ja": "見つかりません", "en": "Nothing matches"},
    "clip.no_match_sub": {"ja": "別の言葉で探すか、Esc で検索を消してください。",
                          "en": "Try other words, or press Esc to clear."},
    "clip.empty_history": {"ja": "まだ何もコピーしていません",
                           "en": "Nothing copied yet"},
    "clip.empty_history_sub": {
        "ja": "文字や画像をコピーすると、ここにたまります。",
        "en": "Text and images you copy will collect here."},
    "clip.empty_group": {"ja": "このグループは空です",
                         "en": "This group is empty"},
    "clip.empty_group_sub": {
        "ja": "履歴の項目を右クリック →「グループへ移す」（Ctrl+G）か、"
              "設定の「クリップボード」で言葉を足せます。"
              "{hotkey} を押すたびにグループが替わります。",
        "en": "Right-click an item in History › Move to group (Ctrl+G), "
              "or add words under Settings › Clipboard. "
              "Press {hotkey} again to switch groups."},
    "clip.hint_paste": {"ja": "貼る", "en": "paste"},
    "clip.hint_paste_n": {"ja": "{n} 件をまとめて貼る",
                          "en": "paste {n} items"},
    "clip.hint_unselect": {"ja": "選ぶのをやめる", "en": "unselect"},
    "clip.hint_plain": {"ja": "書式なし", "en": "plain text"},
    "clip.hint_next_group": {"ja": "次のグループ", "en": "next group"},
    "clip.hint_to_group": {"ja": "グループへ", "en": "to group"},
    "clip.hint_pin": {"ja": "固定", "en": "pin"},
    "clip.hint_delete": {"ja": "削除", "en": "delete"},
    "clip.hint_edit": {"ja": "編集", "en": "edit"},
    "clip.hint_reorder": {"ja": "並べ替え", "en": "reorder"},
    "clip.menu_paste": {"ja": "貼り付ける\tEnter", "en": "Paste\tEnter"},
    "clip.menu_paste_n": {"ja": "{n} 件をまとめて貼り付ける\tEnter",
                          "en": "Paste {n} items\tEnter"},
    "clip.menu_plain": {"ja": "書式なしで貼り付ける\tShift+Enter",
                        "en": "Paste as plain text\tShift+Enter"},
    "clip.menu_transform": {"ja": "変えて貼り付ける", "en": "Paste as"},
    "clip.tf_trim": {"ja": "前後の空白を取る", "en": "Trimmed"},
    "clip.tf_oneline": {"ja": "改行をなくして 1 行に", "en": "One line"},
    "clip.tf_half": {"ja": "英数字を半角に", "en": "Half-width"},
    "clip.tf_full": {"ja": "英数字を全角に", "en": "Full-width"},
    "clip.tf_upper": {"ja": "大文字に", "en": "UPPER CASE"},
    "clip.tf_lower": {"ja": "小文字に", "en": "lower case"},
    "clip.tf_quote": {"ja": "引用にする（行頭に >）", "en": "Quoted (> )"},
    "clip.menu_copy": {"ja": "コピーだけする\tCtrl+Enter",
                       "en": "Copy only\tCtrl+Enter"},
    "clip.menu_pin": {"ja": "固定する（消えないようにする）\tCtrl+P",
                      "en": "Pin\tCtrl+P"},
    "clip.menu_unpin": {"ja": "固定をはずす\tCtrl+P", "en": "Unpin\tCtrl+P"},
    "clip.menu_move": {"ja": "グループへ移す\tCtrl+G",
                       "en": "Move to group\tCtrl+G"},
    "clip.menu_to_history": {"ja": "履歴に戻す", "en": "Back to History"},
    "clip.menu_new_group": {"ja": "新しいグループを作って移す…",
                            "en": "New group…"},
    "clip.menu_edit": {"ja": "名前・中身を編集…\tCtrl+E",
                       "en": "Edit name and text…\tCtrl+E"},
    "clip.menu_open": {"ja": "開く\tCtrl+O", "en": "Open\tCtrl+O"},
    "clip.menu_open_link": {"ja": "ブラウザで開く\tCtrl+O",
                            "en": "Open in browser\tCtrl+O"},
    "clip.menu_show_folder": {"ja": "保存場所を開く",
                              "en": "Show in folder"},
    "clip.menu_save_image": {"ja": "画像をファイルに保存…",
                             "en": "Save image as…"},
    "clip.menu_delete": {"ja": "削除\tDel", "en": "Delete\tDel"},
    "clip.menu_settings": {"ja": "クリップボードの設定…",
                           "en": "Clipboard settings…"},
    "clip.deleted": {"ja": "{n} 件削除しました（Ctrl+Z で元に戻す）",
                     "en": "Deleted {n} (Ctrl+Z to undo)"},
    "clip.restored": {"ja": "元に戻しました", "en": "Restored"},
    "clip.pinned": {"ja": "固定しました。整理しても消えません",
                    "en": "Pinned. It will not be cleaned up"},
    "clip.unpinned": {"ja": "固定をはずしました", "en": "Unpinned"},
    "clip.moved": {"ja": "「{name}」へ移しました", "en": "Moved to {name}"},
    "clip.copied": {"ja": "コピーしました", "en": "Copied"},
    "clip.copied_only": {
        "ja": "貼り付けられない窓なので、コピーだけしました。Ctrl+V で貼れます",
        "en": "Could not paste here, so it was copied. Press Ctrl+V"},
    "clip.paste_failed": {"ja": "取り出せませんでした",
                          "en": "Could not read that item"},
    "clip.mixed_skipped": {
        "ja": "まとめて貼れるのは文字だけです（画像・ファイルは外しました）",
        "en": "Only text can be pasted together (images and files skipped)"},
    "clip.filter": {"ja": "絞り込み: {name}", "en": "Filter: {name}"},
    "clip.reordered": {"ja": "並べ替えました", "en": "Reordered"},
    "clip.image_saved": {"ja": "保存しました", "en": "Saved"},
    "clip.intro": {"ja": "クリップボード履歴が使えます。{hotkey} で開きます",
                   "en": "Clipboard history is on. Press {hotkey} to open it"},
    "clip.hotkey_failed": {
        "ja": "{hotkey} はほかのアプリが使っているため、クリップボード履歴を"
              "開けません。設定の「クリップボード」で変えてください",
        "en": "{hotkey} is taken by another app. Change the clipboard "
              "shortcut under Settings › Clipboard"},
    "clip.paused": {"ja": "クリップボードの記録を一時停止しました",
                    "en": "Clipboard recording paused"},
    "clip.resumed": {"ja": "クリップボードの記録を再開しました",
                     "en": "Clipboard recording resumed"},
    "clip.secret_cleared": {"ja": "秘密の項目をクリップボードから消しました",
                            "en": "The secret was cleared from the clipboard"},
    # ---- クリップボード履歴（設定画面） ----
    "cweb.history": {"ja": "履歴", "en": "History"},
    "cweb.new_group": {"ja": "グループを作る", "en": "New group"},
    "cweb.new_group_title": {"ja": "新しいグループ", "en": "New group"},
    "cweb.group_name": {"ja": "グループの名前", "en": "Group name"},
    "cweb.group_name_ph": {"ja": "例：よく使う・メール・定型文・パスワード",
                           "en": "e.g. Favourites, Email, Templates"},
    "cweb.rename": {"ja": "名前を変える", "en": "Rename"},
    "cweb.delete_group": {"ja": "グループを削除", "en": "Delete group"},
    "cweb.delete_group_confirm": {
        "ja": "「{name}」と、その中の {n} 件を削除します。元に戻せません。",
        "en": "Delete “{name}” and its {n} items? This cannot be undone."},
    "cweb.move_left": {"ja": "前へ", "en": "Move left"},
    "cweb.move_right": {"ja": "後ろへ", "en": "Move right"},
    "cweb.group_hotkey": {"ja": "このグループを直接開くキー",
                          "en": "Shortcut for this group"},
    "cweb.group_hotkey_none": {"ja": "なし", "en": "None"},
    "cweb.group_hotkey_hint": {
        "ja": "押すと、履歴ではなくこのグループで一覧が開きます。",
        "en": "Opens the list straight on this group."},
    "cweb.add_item": {"ja": "言葉を足す", "en": "Add words"},
    "cweb.edit_item": {"ja": "編集", "en": "Edit"},
    "cweb.item_title": {"ja": "名前（なくてもよい）", "en": "Name (optional)"},
    "cweb.item_title_ph": {"ja": "例：会社のメール", "en": "e.g. Work email"},
    "cweb.item_text": {"ja": "中身", "en": "Text"},
    "cweb.item_secret": {
        "ja": "秘密にする（パスワードなど。暗号化して保存し、一覧では伏せ字）",
        "en": "Secret (passwords etc. — encrypted and masked)"},
    "cweb.vars_hint": {
        "ja": "{date} 今日の日付 ・ {time} いまの時刻 ・ {weekday} 曜日 ・ "
              "{clipboard} いまコピーしている文字 — 貼るときに置き換わります",
        "en": "{date}, {time}, {weekday} and {clipboard} are filled in "
              "when you paste"},
    "cweb.show": {"ja": "表示", "en": "Show"},
    "cweb.hide": {"ja": "隠す", "en": "Hide"},
    "cweb.secret_badge": {"ja": "秘密", "en": "Secret"},
    "cweb.pinned_badge": {"ja": "固定", "en": "Pinned"},
    "cweb.pin": {"ja": "固定する", "en": "Pin"},
    "cweb.unpin": {"ja": "固定をはずす", "en": "Unpin"},
    "cweb.move_to": {"ja": "グループへ移す…", "en": "Move to group…"},
    "cweb.move_up": {"ja": "上へ", "en": "Up"},
    "cweb.move_down": {"ja": "下へ", "en": "Down"},
    "cweb.empty_group": {
        "ja": "まだ何もありません。「言葉を足す」で入れるか、一覧（{hotkey}）で"
              "履歴の項目を右クリック →「グループへ移す」で入れられます。",
        "en": "Nothing here yet. Use Add words, or right-click an item in the "
              "list ({hotkey}) › Move to group."},
    "cweb.empty_history": {
        "ja": "まだ何もコピーしていません。コピーすると、ここと一覧（{hotkey}）"
              "にたまります。",
        "en": "Nothing copied yet. What you copy appears here and in the list "
              "({hotkey})."},
    "cweb.search": {"ja": "この中を探す", "en": "Search here"},
    "cweb.image": {"ja": "画像", "en": "Image"},
    "cweb.files": {"ja": "ファイル {n} 個", "en": "{n} files"},
    "cweb.saved": {"ja": "保存しました", "en": "Saved"},
    "cweb.deleted": {"ja": "削除しました", "en": "Deleted"},
    "cweb.moved": {"ja": "移しました", "en": "Moved"},
    "cweb.try_open": {"ja": "一覧を出してみる", "en": "Open the list now"},
    "cweb.stats": {
        "ja": "履歴 {history} 件（固定 {pinned}）・グループ {groups} 個・"
              "言葉 {items} 件・画像 {images} 枚・使用量 {size}",
        "en": "History {history} (pinned {pinned}) · {groups} groups · "
              "{items} saved words · {images} images · {size}"},
    "cweb.clear_confirm": {
        "ja": "履歴を消します。固定したものとグループの中身は残ります。",
        "en": "Clear the history? Pinned items and groups are kept."},
    "cweb.cleared": {"ja": "{n} 件消しました", "en": "Removed {n}"},
    "cweb.export_secrets": {
        "ja": "秘密の項目の中身も書き出しますか？ 書き出したファイルは"
              "暗号化されません。",
        "en": "Include the contents of secret items? The file is not "
              "encrypted."},
    "cweb.export_with": {"ja": "中身も含める", "en": "Include"},
    "cweb.export_without": {"ja": "名前だけ", "en": "Names only"},
    "cweb.imported": {"ja": "グループ {groups} 個・言葉 {items} 件を足しました",
                      "en": "Added {groups} groups and {items} items"},
    "cweb.import_failed": {"ja": "読み込めませんでした：{err}",
                           "en": "Could not import: {err}"},
    "cweb.hotkey_same": {
        "ja": "ほかのショートカット（録音・クリップボード・変換の一覧）と同じ"
              "キーは使えません（あとから登録したほうが効かなくなります）。"
              "別のキーを選んでください。",
        "en": "Another koe-type shortcut already uses this key; pick "
              "another one."},
    "cweb.hotkey_conflict": {
        "ja": "録音か一覧のショートカットと同じキーです。別のキーを選んでください。",
        "en": "Already used by another shortcut; pick another key."},
    "cweb.press_keys": {"ja": "キーを押してください…（Esc でやめる）",
                        "en": "Press keys… (Esc to cancel)"},
    "cweb.paused_note": {
        "ja": "いまは記録を一時停止しています（タスクトレイから再開できます）。",
        "en": "Recording is paused (resume from the tray menu)."},
    # ---- クリップボード：タブ並び替えと種類 ----
    "cweb.tab_order_title": {"ja": "タブの並び順と切り替え",
                             "en": "Tab order & visibility"},
    "cweb.tab_order_help": {
        "ja": "カードを上下にドラッグ（長押しして移動）、または ▲▼ ボタンで"
              "直感的に並び替えられます。",
        "en": "Drag & drop (hold and drag) or use ▲▼ buttons to reorder tabs."},
    "cweb.tab_history": {"ja": "履歴", "en": "History"},
    "cweb.tab_history_desc": {
        "ja": "直近にコピーした文字・画像・ファイルの一覧",
        "en": "Recently copied text, images, and files"},
    "cweb.tab_frequent": {"ja": "🤖よく使っている", "en": "Frequent"},
    "cweb.tab_frequent_desc": {
        "ja": "直近で頻繁に使った定型文やパスワードの自動集計",
        "en": "Frequently used templates and passwords"},
    "cweb.tab_groups": {"ja": "自作グループ", "en": "Saved Groups"},
    "cweb.tab_groups_desc": {
        "ja": "メール・住所・定型文・パスワードなどの保存グループ",
        "en": "Templates, addresses, and passwords in groups"},
    "cweb.tab_downloads": {"ja": "ダウンロード", "en": "Downloads"},
    "cweb.tab_downloads_desc": {
        "ja": "ダウンロード・デスクトップ・OneDriveの最近のファイル",
        "en": "Recent files from Downloads, Desktop, OneDrive"},
    "cweb.tab_cycle_flow": {"ja": "現在のタブ巡回順:",
                            "en": "Tab cycle flow:"},
    "cweb.tab_show": {"ja": "表示する", "en": "Show"},
    "cweb.tab_hide": {"ja": "非表示", "en": "Hide"},
    "cweb.tab_reordered": {"ja": "タブの並び順を更新しました",
                           "en": "Tab order updated"},
    # ---- クリップボード：よく使う & ダウンロード ----
    "clip.tab_frequent": {"ja": "🤖よく使っている", "en": "Frequent"},
    "clip.tab_downloads": {"ja": "ダウンロード", "en": "Downloads"},
    "clip.where_downloads": {"ja": "ダウンロード", "en": "Downloads"},
    "clip.where_desktop": {"ja": "デスクトップ", "en": "Desktop"},
    "clip.kind_file": {"ja": "ファイル", "en": "File"},
    "clip.cloud_only": {"ja": "クラウドのみ", "en": "online-only"},
    "clip.cloud_hint": {
        "ja": "OneDrive のクラウドだけにあります。開いたり渡したりすると、"
              "そのときにダウンロードされます。",
        "en": "Stored only in OneDrive. It downloads when you open or "
              "drag it."},
    "clip.download_keep": {
        "ja": "ファイルそのものは、ここからは消しません",
        "en": "Files are never deleted from here"},
    "clip.empty_downloads": {"ja": "最近のファイルはありません",
                             "en": "No recent files"},
    "clip.empty_downloads_sub": {
        "ja": "ダウンロード・デスクトップ・OneDrive に、この {days} 日で"
              "入ってきたファイルがここに出ます。",
        "en": "Files that arrived in Downloads, Desktop or OneDrive in "
              "the last {days} days appear here."},
    "clip.key_drag": {"ja": "ドラッグ", "en": "Drag"},
    "clip.hint_drag": {"ja": "ほかのアプリへ渡す", "en": "to another app"},
    "clip.hint_open": {"ja": "開く", "en": "open"},
    "clip.menu_paste_file": {"ja": "ファイルを貼り付ける\tEnter",
                             "en": "Paste the file\tEnter"},
    "clip.menu_file_to_group": {"ja": "グループに入れる（場所を覚える）",
                                "en": "Add to group (remember location)"},
    "cweb.save_failed": {"ja": "保存できませんでした", "en": "Could not save"},
    "cweb.key_unreadable": {"ja": "「{spec}」は読み取れないキーです",
                            "en": "Cannot read the key “{spec}”"},
    "cweb.key_paste": {
        "ja": "貼り付けのキーです。koe-type 自身も使うので選べません",
        "en": "That is a paste key, which koe-type itself uses"},
    "cweb.key_needs_modifier": {
        "ja": "Ctrl・Alt などと一緒に押すキーにしてください"
              "（1 キーだけだと、ふつうの入力ができなくなります）",
        "en": "Use Ctrl, Alt or similar with it (a single key would block "
              "normal typing)"},
    "cweb.key_taken": {"ja": "「{name}」と同じキーです。別のキーにしてください",
                       "en": "Already used by “{name}”; pick another key"},
    "cweb.use_record": {"ja": "録音", "en": "Recording"},
    "cweb.use_clip": {"ja": "クリップボードの一覧", "en": "Clipboard list"},
    "cweb.use_recipe": {"ja": "変換の一覧", "en": "Action list"},
    "cweb.use_language": {"ja": "言語の切り替え", "en": "Language switch"},
    "cweb.use_action": {"ja": "変換用のショートカット", "en": "Action shortcut"},
    "clip.reorder_manual_only": {
        "ja": "並べ替えは、グループの並び順が「自分で並べた順」のときだけです",
        "en": "Reordering works only when the group order is “My order”"},
    # ---- AI・文章変換のレシピ一覧 ----
    "recipe.title": {"ja": "AI・文章変換を選ぶ", "en": "Pick an AI / text action"},
    "recipe.search": {"ja": "変換を探す", "en": "Search actions"},
    "recipe.how": {
        "ja": "選ぶと録音が始まります。話し終えたら {hotkey} で、変換して入力します。",
        "en": "Recording starts when you pick. Press {hotkey} when done to "
              "convert and type."},
    "recipe.offline": {"ja": "（API キーなし：オフラインの簡易変換）",
                       "en": "(no API key: simple offline conversion)"},
    "recipe.empty": {
        "ja": "使える変換がありません。設定の「AI・文章変換」で足すか、"
              "止めているものをオンにしてください。",
        "en": "No actions available. Add or enable some under Settings › "
              "AI & Actions."},
    "recipe.hint_pick": {"ja": "選んで録音", "en": "pick and record"},
    "recipe.hint_number": {"ja": "すぐ選ぶ", "en": "pick by number"},
    "recipe.hint_category": {"ja": "カテゴリ切替", "en": "switch tab"},
    "recipe.hint_close": {"ja": "閉じる", "en": "close"},
    "recipe.cat_all": {"ja": "すべて", "en": "All"},
    "recipe.cat_text": {"ja": "文章作成・AI", "en": "AI Writing"},
    "recipe.cat_tools": {"ja": "ツール・計算", "en": "Tools & Calc"},
    "presets.current": {"ja": "現在適用中", "en": "Active"},
    "presets.is_active": {"ja": "✓ 適用中", "en": "✓ Active"},
    "presets.apply": {"ja": "このスタイルを適用", "en": "Apply Style"},
    "recipe.no_target": {
        "ja": "元の入力欄に戻れなかったので、録音を始めませんでした",
        "en": "Could not return to the text box, so recording did not start"},
    "recipe.hotkey_failed": {
        "ja": "{hotkey} はほかのアプリが使っているため、変換の一覧を開けません。"
              "設定の「AI・文章変換」で変えてください",
        "en": "{hotkey} is taken by another app. Change it under Settings › "
              "AI & Actions"},
    "tray.recipe_open": {"ja": "変換を選んで録音…", "en": "Pick an action and record…"},
    "tray.clip_open": {"ja": "クリップボード履歴を開く",
                       "en": "Open clipboard history"},
    "tray.clip_pause": {"ja": "クリップボードの記録を一時停止",
                        "en": "Pause clipboard recording"},

    # ---- 設定の案内（困りごと・やりたいことから探す） ----
    "guide.nav_label": {"ja": "困りごとから探す",
                        "en": "Troubleshoot & Guide"},
    "guide.nav_title": {"ja": "困りごとから探す",
                        "en": "Troubleshoot & Guide"},
    "guide.title": {"ja": "設定の案内", "en": "Settings Guide"},
    "guide.subtitle": {
        "ja": "困りごとや実現したいことから、変えるべき設定を見つけます。",
        "en": "Find settings based on your problems or what you want "
              "to achieve.",
    },
    "guide.search_placeholder": {
        "ja": "困りごとやキーワードで絞り込む…",
        "en": "Filter by issue or keyword…",
    },
    "guide.badge": {"ja": "案内", "en": "Guide"},
    "guide.jump_button": {"ja": "この設定へ移動する →",
                          "en": "Go to this setting →"},
    "guide.go_to_setting": {"ja": "この設定へ移動する →",
                            "en": "Go to this setting →"},
    "guide.filter_all": {"ja": "すべて", "en": "All"},
    "guide.tab_all": {"ja": "すべて", "en": "All"},
    "guide.filter_speed": {"ja": "速度・反応", "en": "Speed"},
    "guide.tab_speed": {"ja": "速度・動作", "en": "Speed"},
    "guide.filter_text": {"ja": "文字・認識", "en": "Text"},
    "guide.tab_text": {"ja": "文字・認識", "en": "Text"},
    "guide.filter_shortcut": {"ja": "キー・操作", "en": "Keys"},
    "guide.tab_key": {"ja": "キー・操作", "en": "Keys"},
    "guide.filter_audio": {"ja": "音・マイク", "en": "Audio"},
    "guide.tab_sound": {"ja": "音・背景", "en": "Audio"},
    "guide.filter_ui": {"ja": "画面・表示", "en": "Display"},
    "guide.tab_ui": {"ja": "画面・表示", "en": "Display"},
    "guide.filter_window": {"ja": "ウィンドウ", "en": "Window"},
    "guide.filter_app": {"ja": "アプリ連携", "en": "Apps"},
    "guide.empty": {"ja": "当てはまる案内が見つかりませんでした。",
                    "en": "No matching guides found."},
    "guide.no_match": {"ja": "当てはまる案内が見つかりませんでした。",
                       "en": "No matching guides found."},
    "guide.question_lead": {"ja": "状況を選んでください：",
                            "en": "Select your situation:"},
    "guide.select_situation": {"ja": "当てはまる状況を選んでください：",
                              "en": "Select your situation:"},
    "guide.target_lead": {"ja": "変更する設定：",
                          "en": "Setting to change:"},
    "guide.target_setting": {"ja": "変更する設定：",
                            "en": "Setting to change:"},
    "guide.reason_lead": {"ja": "なぜこれを変えるか：",
                          "en": "Why change this:"},
    "guide.why_change": {"ja": "なぜこれを変えるか：",
                         "en": "Why change this:"},
    "guide.guided_from": {"ja": "案内から移動しました",
                          "en": "Navigated from Guide"},
    "guide.recommend": {"ja": "推奨", "en": "Recommended"},

    # 1. 速度・入力タイミング
    "guide.latency.title": {"ja": "文字が出るのが遅い",
                            "en": "Text appears slowly"},
    "guide.latency.summary": {
        "ja": "話しながら入力やモデルの選択で、文字が出るまでの時間を短縮します。",
        "en": "Speed up typing by adjusting input timing or model.",
    },
    "guide.latency.question": {"ja": "どのような状況ですか？",
                               "en": "What is your main concern?"},
    "guide.latency.c_stream.label": {
        "ja": "話している途中ですぐ文字を出したい",
        "en": "I want text to appear while speaking",
    },
    "guide.latency.c_stream.reason": {
        "ja": "「文字が入るタイミング」を「話しながら」にすると、"
              "発話の終了を待たずにリアルタイムで文字が入力されます。",
        "en": "Setting 'When text is typed' to 'While you speak' inputs "
              "words in real-time without waiting.",
    },
    "guide.latency.c_model.label": {
        "ja": "パソコンが重い・文字起こし処理自体を速くしたい",
        "en": "PC feels heavy or recognition itself is slow",
    },
    "guide.latency.c_model.reason": {
        "ja": "より軽量なモデル（SenseVoice 等）を選ぶと、推論時間が短縮されて"
              "文字が出るまでの待ち時間が大幅に減ります。",
        "en": "Choosing a faster model (like SenseVoice) drastically cuts "
              "down transcription time.",
    },

    # 2. 句読点
    "guide.punctuation.title": {"ja": "句読点が多い・減らしたい",
                                "en": "Too many punctuation marks"},
    "guide.punctuation.summary": {
        "ja": "読点（、）や句点（。）の量を調整してすっきりした文章にします。",
        "en": "Adjust commas and periods for cleaner text.",
    },
    "guide.punctuation.question": {"ja": "どの句読点を調整したいですか？",
                                   "en": "Which punctuation marks do you want "
                                         "to adjust?"},
    "guide.punctuation.c_commas.label": {
        "ja": "読点『、』の数を減らしたい・なくしたい",
        "en": "Reduce or remove commas (,)",
    },
    "guide.punctuation.c_commas.reason": {
        "ja": "「句読点の量」を「少なめ」や「つけない」にすると、"
              "話した言葉の間に入る読点「、」を抑えられます。",
        "en": "Setting 'How much punctuation' to 'Fewer' or 'None' suppresses "
              "excessive commas.",
    },
    "guide.punctuation.c_stops.label": {
        "ja": "文末の句点『。』を付けたくない",
        "en": "Do not add periods at sentence ends",
    },
    "guide.punctuation.c_stops.reason": {
        "ja": "「『。』の付けかた」を「付けない」にすると、文末に句点を付けずに"
              "チャットなどで自然に話せます。",
        "en": "Setting 'Full stops' to 'Never' removes trailing periods, "
              "ideal for chat messages.",
    },

    # 3. 録音キー
    "guide.hotkey.title": {"ja": "録音キーを変えたい・押し方を変えたい",
                           "en": "Change recording key or behaviour"},
    "guide.hotkey.summary": {
        "ja": "親指で押せるキーへの変更や、押している間だけの長押し録音に設定します。",
        "en": "Change to an easy key like Muhenkan or push-to-talk hold mode.",
    },
    "guide.hotkey.question": {"ja": "どのように変更したいですか？",
                              "en": "How would you like to change it?"},
    "guide.hotkey.c_key.label": {"ja": "別のショートカットキーに変えたい",
                                 "en": "Change to a different shortcut key"},
    "guide.hotkey.c_key.reason": {
        "ja": "JISキーボードの「無変換」キーなど、親指で押しやすいキーに割り当てると"
              "素早く快適に録音できます。",
        "en": "Assigning to an accessible key like Muhenkan allows fast "
              "thumb-trigger voice typing.",
    },
    "guide.hotkey.c_mode.label": {
        "ja": "押している間だけ録音したい（長押し）",
        "en": "Record only while holding down the key",
    },
    "guide.hotkey.c_mode.reason": {
        "ja": "「ショートカットの動作」を「長押しの間だけ」にすると、"
              "キーを押している間だけ録音され、離すと入力されます。",
        "en": "Setting shortcut behaviour to 'Push to talk' records while "
              "held and stops on release.",
    },

    # 4. チャット送信
    "guide.chat_send.title": {"ja": "チャットで勝手に送信されてしまう",
                              "en": "Accidentally sends messages in chat"},
    "guide.chat_send.summary": {
        "ja": "録音中の Enter キーの動作や、送信キーの割り当てを見直します。",
        "en": "Adjust Enter key interception and send hotkey.",
    },
    "guide.chat_send.question": {"ja": "どのようなきっかけで送信されますか？",
                                 "en": "When does accidental sending occur?"},
    "guide.chat_send.c_enter.label": {
        "ja": "録音中に Enter キーを押したときに送信されるのを防ぎたい",
        "en": "Prevent Enter key from sending while recording",
    },
    "guide.chat_send.c_enter.reason": {
        "ja": "「録音中に Enter で送信する」をオフにすると、"
              "録音中の Enter キーの横取りをやめ、勝手な送信を防ぎます。",
        "en": "Turning off 'Enter sends while recording' prevents Enter "
              "from prematurely submitting chat.",
    },
    "guide.chat_send.c_click.label": {
        "ja": "マウスで送信ボタンなどを押したときに途中送信される",
        "en": "Accidentally sends when clicking with mouse",
    },
    "guide.chat_send.c_click.reason": {
        "ja": "「クリックしたときの動作」を「入力欄の外を押したら止める」にすると、"
              "送信ボタン押下時に残りの文字が安全に退避されます。",
        "en": "Setting 'When you click with mouse' to 'Only outside' safely "
              "diverts trailing text when sending.",
    },
    "guide.chat_send.c_sendkey.label": {
        "ja": "Slack などで Ctrl+Enter で送信するようにしたい",
        "en": "Send with Ctrl+Enter instead of Enter",
    },
    "guide.chat_send.c_sendkey.reason": {
        "ja": "「送信に使うキー」を「Ctrl+Enter」に変更すると、"
              "誤って通常の Enter で送信される事故を防げます。",
        "en": "Changing 'Key used to send' to 'Ctrl+Enter' avoids "
              "unintentional sends on Enter.",
    },

    # 5. 英語・他言語
    "guide.bilingual.title": {"ja": "英語も混ぜて話す・英語に翻訳したい",
                              "en": "Speak English or translate to English"},
    "guide.bilingual.summary": {
        "ja": "認識言語の切り替えや、話した内容の自動英語翻訳を設定します。",
        "en": "Configure recognition language or speech translation to "
              "English.",
    },
    "guide.bilingual.question": {"ja": "どちらの使い方をしたいですか？",
                                 "en": "Which one do you want to do?"},
    "guide.bilingual.c_lang.label": {
        "ja": "英語混じりの会話を正しく英語スペルで文字起こししたい",
        "en": "Transcribe English words with correct spelling",
    },
    "guide.bilingual.c_lang.reason": {
        "ja": "「言語」を「自動」または「英語」に切り替えると、"
              "英語の単語も正しい英字スペルで文字起こしされます。",
        "en": "Setting 'Language' to 'Auto' or 'English' recognizes spoken "
              "English words with proper letters.",
    },
    "guide.bilingual.c_translate.label": {
        "ja": "日本語で話して自動的に英語に翻訳して入力したい",
        "en": "Speak Japanese and translate to English",
    },
    "guide.bilingual.c_translate.reason": {
        "ja": "「録音キーを長押ししたとき」で「英語に翻訳」を選ぶと、"
              "話した日本語が自動で英文に翻訳されて貼り付けられます。",
        "en": "Setting 'When you hold record key' to 'Translate to English' "
              "automatically translates speech.",
    },

    # 6. つなぎ言葉
    "guide.fillers.title": {"ja": "つなぎ言葉（えー、あの）を消したい",
                            "en": "Remove filler words (um, uh)"},
    "guide.fillers.summary": {
        "ja": "「えーと」「あのー」などの口ぐせを文字起こしから自動で除外します。",
        "en": "Automatically remove speech fillers like 'um' and 'uh'.",
    },
    "guide.fillers.reason": {
        "ja": "「つなぎ言葉を消す」をオンにすると、発話の前後や文中の"
              "「えー」「あの」「まあ」などが自動で取り除かれます。",
        "en": "Enabling 'Remove filler words' automatically eliminates "
              "speech disfluencies and fillers.",
    },

    # 7. ウィンドウ切替・保留
    "guide.away_text.title": {"ja": "別の画面を見ている間の文字を失いたくない",
                              "en": "Don't lose words when switching windows"},
    "guide.away_text.summary": {
        "ja": "音声入力中に別のウィンドウへ移ったときの文字の行き先を設定します。",
        "en": "Control where text goes if you change windows while speaking.",
    },
    "guide.away_text.question": {
        "ja": "ウィンドウを離れたとき、どのように動かしたいですか？",
        "en": "How do you want it to behave when leaving?",
    },
    "guide.away_text.c_wait.label": {
        "ja": "元のウィンドウに戻った時に入力させたい（おすすめ）",
        "en": "Hold and type once I return to original window",
    },
    "guide.away_text.c_wait.reason": {
        "ja": "「よそを見ているあいだの文字」を「元の欄に戻ったら入れる」にすると、"
              "別の窓を見ていても文字が消えずに保留されます。",
        "en": "Setting to 'When I come back' holds transcribed text and "
              "safely inserts it when you return.",
    },
    "guide.away_text.c_stop.label": {
        "ja": "別のアプリに移ったら録音自体を安全に止めたい",
        "en": "Stop recording when moving to another app",
    },
    "guide.away_text.c_stop.reason": {
        "ja": "「別のウィンドウに移ったら」を「録音を止める」にすると、"
              "思わぬウィンドウに文字が入るのを未然に防ぎます。",
        "en": "Setting 'When you move to another window' to 'Stop' stops "
              "recording so nothing lands unexpectedly.",
    },

    # 8. 録音停止忘れ
    "guide.stop_forget.title": {
        "ja": "録音を止め忘れてしまう・自動で止めたい",
        "en": "Forget to stop recording / Auto-stop",
    },
    "guide.stop_forget.summary": {
        "ja": "話し終わって静かになったときに自動で終了させます。",
        "en": "Automatically stop after silence or using push-to-talk.",
    },
    "guide.stop_forget.question": {"ja": "どちらの方法で止めたいですか？",
                                   "en": "How would you prefer to stop "
                                         "recording?"},
    "guide.stop_forget.c_silence.label": {
        "ja": "無音が続いたら自動で録音を止めたい",
        "en": "Auto-stop when silence is detected",
    },
    "guide.stop_forget.c_silence.reason": {
        "ja": "「静かになったら止める」を 5秒 または 10秒 に設定すると、"
              "話し終えた後に自動で録音を終了します。",
        "en": "Setting 'Stop after silence' to 5s or 10s automatically ends "
              "recording once you stop talking.",
    },
    "guide.stop_forget.c_hold.label": {
        "ja": "キーを離した瞬間に確実に止めたい",
        "en": "Stop immediately when releasing the key",
    },
    "guide.stop_forget.c_hold.reason": {
        "ja": "「ショートカットの動作」を「長押しの間だけ」にすると、"
              "指を離すだけで確実に録音が止まります。",
        "en": "Using 'Push to talk' ensures recording stops immediately when "
              "you release the key.",
    },

    # 9. 話し始め・語尾切れ
    "guide.speech_boundary.title": {
        "ja": "話し始めや語尾が途切れてしまう",
        "en": "Start or end of speech gets cut off",
    },
    "guide.speech_boundary.summary": {
        "ja": "キーを押す前や離した後の余韻をマイク録音に含めます。",
        "en": "Include audio before keypress or after release.",
    },
    "guide.speech_boundary.question": {"ja": "どの部分が切れてしまいますか？",
                                       "en": "Which part gets cut off?"},
    "guide.speech_boundary.c_preroll.label": {
        "ja": "話し始めの最初の言葉が切れてしまう",
        "en": "The very first word gets cut off",
    },
    "guide.speech_boundary.c_preroll.reason": {
        "ja": "「話し始めを逃さない」を長くすると、キーを押す直前の音声も"
              "遡って文字起こしに含めます。",
        "en": "Increasing 'Catch the start of sentence' includes audio "
              "immediately before keypress.",
    },
    "guide.speech_boundary.c_postroll.label": {
        "ja": "話し終わりの語尾が切れてしまう",
        "en": "The ending tail gets cut off",
    },
    "guide.speech_boundary.c_postroll.reason": {
        "ja": "「話し終わりを逃さない」を長くすると、キーを離した後の余韻も"
              "しっかり拾って文字起こしします。",
        "en": "Increasing 'Catch the end of sentence' ensures words spoken on "
              "release are captured.",
    },

    # 10. 録音中の帯（オーバーレイ）
    "guide.overlay.title": {
        "ja": "録音中の帯（画面表示）が邪魔・形や位置を変えたい",
        "en": "Overlay banner is in the way / Customize",
    },
    "guide.overlay.summary": {
        "ja": "コンパクトなピル型への変更や、カーソル追従・非表示を設定します。",
        "en": "Switch to thin pill bar, follow text cursor, or hide.",
    },
    "guide.overlay.question": {"ja": "どのように調整したいですか？",
                               "en": "How would you like to adjust the "
                                     "overlay?"},
    "guide.overlay.c_design.label": {
        "ja": "帯の形をもっと小さく目立たない形にしたい",
        "en": "Make the overlay smaller and less distracting",
    },
    "guide.overlay.c_design.reason": {
        "ja": "「表示のかたち」を「ピル」にすると、高さ38pxの細いカプセル型になり"
              "画面を遮りません。",
        "en": "Setting 'Design' to 'Pill' renders a sleek 38px capsule that "
              "does not block your view.",
    },
    "guide.overlay.c_pos.label": {
        "ja": "帯の表示位置を変えたい（入力欄の邪魔にならない場所）",
        "en": "Change overlay position away from input areas",
    },
    "guide.overlay.c_pos.reason": {
        "ja": "「表示位置」を「上の中央」や「カーソルの近く」に変えると、"
              "入力欄や送信ボタンと重ならなくなります。",
        "en": "Changing 'Position' to 'Top center' or 'Near cursor' prevents "
              "overlapping with input boxes.",
    },
    "guide.overlay.c_vis.label": {
        "ja": "画面に帯を出さずに音声入力したい",
        "en": "Hide the overlay completely",
    },
    "guide.overlay.c_vis.reason": {
        "ja": "「録音中の帯を出す」をオフにすると、画面上に帯を出さず完全に"
              "バックグラウンドで動作します。",
        "en": "Turning off 'Show overlay while recording' lets you voice type "
              "without any screen popup.",
    },

    # 11. BGM・PC音のダッキング
    "guide.audio_ducking.title": {
        "ja": "PC の音（音楽・動画）を流したまま音声入力したい",
        "en": "Keep background music playing while voice typing",
    },
    "guide.audio_ducking.summary": {
        "ja": "録音中の自動消音やダッキングをオフにして、BGMを止めずに話せるようにします。",
        "en": "Disable automatic muting or volume ducking while recording.",
    },
    "guide.audio_ducking.reason": {
        "ja": "「録音中のPC音声の制御」を「そのまま」にすると、音声入力中も BGM や"
              "音楽が止まらず再生され続けます。",
        "en": "Setting 'PC audio during recording' to 'Keep as is' allows "
              "background music to keep playing untouched.",
    },

    # 12. 半角英数字
    "guide.halfwidth.title": {
        "ja": "数字を全角ではなく半角（123）にしたい",
        "en": "Format numbers as halfwidth digits (123)",
    },
    "guide.halfwidth.summary": {
        "ja": "「１２３」などの全角数字を半角数字「123」に自動統一します。",
        "en": "Automatically convert fullwidth numbers into standard "
              "halfwidth digits.",
    },
    "guide.halfwidth.reason": {
        "ja": "「英数字を半角にする」をオンにすると、認識された数字やアルファベットが"
              "半角に統一されます。",
        "en": "Enabling 'Halfwidth alphanumeric' automatically converts "
              "fullwidth digits and letters to halfwidth.",
    },

    # 13. 固有名詞・辞書
    "guide.dictionary.title": {
        "ja": "専門用語や名前が正しく漢字・英字にならない",
        "en": "Technical terms or names are misspelled",
    },
    "guide.dictionary.summary": {
        "ja": "ユーザー辞書に登録して、表記の揺れや聞き間違いを自動補正します。",
        "en": "Add custom terms to User Dictionary for automatic spelling "
              "correction.",
    },
    "guide.dictionary.reason": {
        "ja": "ユーザー辞書に登録すると、誤認識しやすい固有名詞や専門用語を"
              "正しい表記に自動置換・補正します。",
        "en": "Adding entries to the User Dictionary automatically corrects "
              "misheard words into exact desired terms.",
    },

    # 14. 除外アプリ
    "guide.excluded_apps.title": {
        "ja": "VS Code など特定のアプリで録音キーを使いたくない",
        "en": "Do not intercept shortcut in specific apps",
    },
    "guide.excluded_apps.summary": {
        "ja": "対象アプリが前面にある間だけ、koe-type のショートカットを素通しします。",
        "en": "Pass shortcuts through untouched when specific applications "
              "are in foreground.",
    },
    "guide.excluded_apps.reason": {
        "ja": "「koe-type を使わないアプリ」に exe 名（例: Code.exe）を追加すると、"
              "そのアプリ本来のショートカットが使えます。",
        "en": "Adding executables (like Code.exe) passes hotkeys through "
              "untouched to the active application.",
    },

    # 15. 効果音
    "guide.sound.title": {"ja": "合図の音（効果音）を変えたい・消したい",
                          "en": "Change or mute feedback sounds"},
    "guide.sound.summary": {
        "ja": "録音開始・終了時の音色を変更したり、音量を調整・無音にします。",
        "en": "Customize sound effect tone or lower/mute feedback volume.",
    },
    "guide.sound.question": {"ja": "どちらを変更したいですか？",
                             "en": "Which one do you want to change?"},
    "guide.sound.c_theme.label": {
        "ja": "効果音の音色を好みの音に変えたい",
        "en": "Change sound effect tone",
    },
    "guide.sound.c_theme.reason": {
        "ja": "「効果音の音色」を「控えめ」や「チャイム」等に変更すると、"
              "耳に優しい音に切り替えられます。",
        "en": "Setting 'Sound theme' to 'Soft' or 'Chime' gives a gentle, "
              "pleasant confirmation tone.",
    },
    "guide.sound.c_volume.label": {
        "ja": "効果音の音量を小さくしたい、または消したい",
        "en": "Lower volume or mute sound effects completely",
    },
    "guide.sound.c_volume.reason": {
        "ja": "「効果音の音量」を小さく調整したり、0%（または効果音オフ）にすることで"
              "無音にできます。",
        "en": "Lowering 'Sound volume' or setting it to 0% silences "
              "confirmation chimes.",
    },
}



def set_language(lang: str) -> None:
    global _lang
    _lang = "en" if str(lang).lower().startswith("en") else "ja"


def language() -> str:
    return _lang


def t(key: str, **fmt: object) -> str:
    entry = STRINGS.get(key)
    if entry is None:
        log.debug("未定義の表示文字列: %s", key)
        return key
    text = entry.get(_lang) or entry.get("ja") or key
    if fmt:
        try:
            return text.format(**fmt)
        except Exception:
            return text
    return text


def pick(ja: str, en: str) -> str:
    """スキーマのように ja/en を直接持っている場合に使う。"""
    return en if _lang == "en" else ja
