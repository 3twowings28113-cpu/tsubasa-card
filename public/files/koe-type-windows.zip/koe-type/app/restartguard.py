"""再起動の予算。再起動を繰り返して PC を操作不能にしないための門番。

## なぜ作ったか（2026-10-24 の障害）

再起動の経路が 3 つ（見張り役 guardian・ホットリロード reloader・
自動更新の入れ替え）あり、それぞれが「自分の担当ぶんだけ」数えていた。
しかも見張り役の数え方は**プロセス内のメモリ**だったので、
見張り役や本体が作り直されるたびに数が 0 に戻り、
「最大 5 回まで」という歯止めが実質的に効かなかった。
本体が起動直後に死ぬ／ファイル変更が続く等があると、
再起動 → 起動処理（モデルの読み込みとウォームアップで高負荷）→
また再起動…が無限に続いた。

## 作り

- 再起動した事実を**ファイルに残す**（`logs/restart-guard.json`）。
  プロセスが全部死んでも数え直しにならない。
- 窓（既定 10 分）の中の再起動は、経路を問わず合計で数える。
- 間隔は指数バックオフ：1 回目 60 秒 → 2 回目 120 秒 → 3 回目 240 秒。
- 窓の中の上限（既定 3 回）を超えたら、**その窓では二度と再起動しない**。
  呼び出し側は「知らせるだけ」に切り替えること。
- 壊れたファイル・読めないファイルは「記録なし」として扱い、
  この門番自身が原因でアプリが止まらないようにする。

Windows 専用の API は使わない（テストでそのまま動かせるように）。
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path

log = logging.getLogger(__name__)

WINDOW_SEC = 600.0          # この窓の中で数える
MAX_RESTARTS = 3            # 窓の中の上限（全経路の合計）
BASE_BACKOFF_SEC = 60.0     # 1 回目のあと空ける間隔
MAX_BACKOFF_SEC = 900.0     # バックオフの上限


def required_gap(done_in_window: int) -> float:
    """すでに done_in_window 回再起動したあと、次までに空ける秒数。"""
    if done_in_window <= 0:
        return 0.0
    return min(MAX_BACKOFF_SEC, BASE_BACKOFF_SEC * (2 ** (done_in_window - 1)))


class RestartGuard:
    """再起動してよいかを、ファイルに残した履歴から判断する。"""

    def __init__(self, path: Path, *, window_sec: float = WINDOW_SEC,
                 max_restarts: int = MAX_RESTARTS) -> None:
        self.path = Path(path)
        self.window_sec = float(window_sec)
        self.max_restarts = int(max_restarts)

    # ------------------------------------------------------------ 記録

    def _load(self, now: float) -> list[float]:
        """窓の中にある再起動時刻だけを返す。"""
        try:
            data = json.loads(self.path.read_text("utf-8"))
            events = [float(e["t"]) for e in data.get("events", [])
                      if isinstance(e, dict) and "t" in e]
        except Exception:
            return []
        return [t for t in events if now - t < self.window_sec]

    def _save(self, events: list[float], sources: list[str]) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(
                {"events": [{"t": t, "src": s}
                            for t, s in zip(events, sources)]}),
                "utf-8")
            os.replace(tmp, self.path)
        except OSError:
            log.debug("再起動の記録を書けませんでした", exc_info=True)

    # ------------------------------------------------------------ 判定

    def check(self, now: float | None = None) -> tuple[bool, str]:
        """いま再起動してよいか。(よいか, 理由) を返す。記録はしない。"""
        now = time.time() if now is None else now
        events = self._load(now)
        if len(events) >= self.max_restarts:
            return False, (f"{int(self.window_sec)} 秒のあいだに "
                           f"{len(events)} 回再起動したため、これ以上は"
                           "自動で起動し直しません")
        gap = required_gap(len(events))
        if events and now - events[-1] < gap:
            return False, (f"再起動の間隔が短すぎます"
                           f"（あと {gap - (now - events[-1]):.0f} 秒）")
        return True, ""

    def record(self, source: str, now: float | None = None) -> None:
        """再起動したことを残す。source は経路名（guardian 等）。"""
        now = time.time() if now is None else now
        events = self._load(now)
        # 時刻だけの旧形式にも耐えるよう、読み直して source をそろえる
        try:
            data = json.loads(self.path.read_text("utf-8"))
            kept = [(float(e["t"]), str(e.get("src", "?")))
                    for e in data.get("events", [])
                    if isinstance(e, dict) and "t" in e
                    and now - float(e["t"]) < self.window_sec]
        except Exception:
            kept = [(t, "?") for t in events]
        kept.append((now, source))
        self._save([t for t, _ in kept], [s for _, s in kept])

    def try_acquire(self, source: str,
                    now: float | None = None) -> tuple[bool, str]:
        """判定して、よければ記録まで済ませる（再起動の直前に呼ぶ）。"""
        now = time.time() if now is None else now
        ok, why = self.check(now)
        if ok:
            self.record(source, now)
        return ok, why

    def reset(self) -> None:
        """記録を消す（利用者が直して手で起動し直したとき等）。"""
        try:
            self.path.unlink(missing_ok=True)
        except OSError:
            pass
