"""テスト用の「から打ち」モード。

環境変数 `KOE_TYPE_DRY_RUN=1` を付けて動かすと、
**SendInput もクリップボードの書き換えも一切行わない**。
代わりに「何をするはずだったか」を `logs/dryrun.jsonl` に1行ずつ書き出す。

過去に、テスト中の合成キー入力が利用者の LINE や Vivaldi に入る事故が
3回あった。自動テストでは本物のキーを絶対に送らない、という決まりの土台。

書き出す内容の例

    {"t": 1.234, "kind": "paste", "text": "明日の打ち合わせは…"}
    {"t": 2.345, "kind": "submit", "key": "enter"}
    {"t": 3.456, "kind": "copy",  "text": "…", "reason": "window_changed"}
"""

from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

_ENV = "KOE_TYPE_DRY_RUN"
_lock = threading.Lock()
_started = time.monotonic()
_path: Path | None = None


def enabled() -> bool:
    return os.environ.get(_ENV, "") not in ("", "0", "false", "False")


def log_path() -> Path:
    global _path
    if _path is None:
        from .util import LOG_DIR
        override = os.environ.get("KOE_TYPE_DRY_RUN_LOG")
        _path = Path(override) if override else LOG_DIR / "dryrun.jsonl"
        _path.parent.mkdir(parents=True, exist_ok=True)
    return _path


def record(kind: str, **fields: object) -> None:
    """から打ちの記録を1行足す。失敗しても本体を止めない。"""
    if not enabled():
        return
    row = {"t": round(time.monotonic() - _started, 3), "kind": kind}
    row.update(fields)
    try:
        with _lock, log_path().open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
    except OSError:
        pass


def reset() -> None:
    """記録を空にする（テストの開始時に呼ぶ）。"""
    if not enabled():
        return
    try:
        log_path().write_text("", "utf-8")
    except OSError:
        pass


def entries() -> list[dict]:
    """記録を読み出す。"""
    try:
        lines = log_path().read_text("utf-8").splitlines()
    except OSError:
        return []
    out = []
    for line in lines:
        line = line.strip()
        if line:
            try:
                out.append(json.loads(line))
            except ValueError:
                pass
    return out


def typed_text() -> str:
    """入力されたはずの文字を、順につなげて返す。"""
    return "".join(e.get("text", "") for e in entries()
                   if e.get("kind") in ("paste", "copy"))
