"""speech.cpp の worker を常駐プロセスとして使う文字起こし。

Haas-ja-v1.0 のような FastConformer 系のモデルは、transcribe.cpp の
DLL（app/resident.py）では読めない。speech.cpp（MIT）には
`speech worker` という JSON Lines の常駐プロセスがあり、モデルを
読みっぱなしにして、依頼ごとに PCM を渡して文字にできる。
ここではそれを resident.Resident と同じ呼び味で包む。

決め事（resident.py と同じ理由）
  ・起動は単一飛行（試行を分かち合う）＋全インスタンスで直列。
    main 用と品質用が同時に speech.exe を起こすと、Vulkan の
    初期化とモデル読み込みが重なって互いを遅くし、片方が ready を
    返す前に死ぬ（2026-11-05 実機）。詳細は load() と _BOOT_LOCK。
  ・stdout はプロトコル専用。worker のログは stderr へ出るので、
    読み手のいないパイプで詰まらせないよう DEVNULL へ捨てる。
  ・実行がハングしたら、そのプロセスは捨てて世代を進める
    （2026-10-31 第三者監査 H2 の教訓: ハングした実行を握ったまま
    だと、認識がすべて止まり、unload すらできなくなる）。
  ・プロセスが死んでいたら、次の呼び出しで自動で起こし直す。
    依頼の途中で死んだ場合は、1 回だけ起こし直してやり直す。
  ・プロトコルは 4（speech.cpp 0.10.1）。違う版が来たら、
    黙って合わせず起動の時点で止める。
"""

from __future__ import annotations

import base64
import json
import logging
import os
import queue
import subprocess
import threading
import time
from pathlib import Path

from . import resident
from .resident import SAMPLE_RATE
from .util import BIN_DIR

log = logging.getLogger(__name__)

CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
PROTOCOL = 4
# 1 依頼の PCM をこの大きさで割って送る。base64 で約 1.33 倍に
# なるので、1 行が長すぎない単位にする（約 8 秒ぶん）。
CHUNK_BYTES = 1 << 18

_EOF = object()          # 読み取りスレッドの終了を伝える番兵

# 起動の直列化（全インスタンス共通）。main 用と品質用で別々の
# SpeechWorker が同時に speech.exe を起こすと、Vulkan 初期化と
# モデル読み込みが重なって互いを遅くする（2026-11-05 実機:
# 単独では読み込み 0.42 秒が、重なると 0.79/0.99 秒に悪化した）。
# プロセス生成〜ready の間だけをこれで囲み、1 つずつにする。
# 認識そのものは囲まない（走っている worker の依頼は並行して
# よく、囲むと入力が止まる作りになるため）。
_BOOT_LOCK = threading.Lock()


class SpeechWorkerError(resident.ResidentError):
    """worker とのやり取りの失敗。

    ResidentError の仲間にしてあるのは、engines.ResidentEngine が
    常駐コアの失敗を ResidentError で受ける作りだから。そのまま
    EngineError へ変換される。
    """


class _DiedError(SpeechWorkerError):
    """依頼の途中でプロセスが死んだ（起こし直して 1 回だけ再試行）。"""


class _Attempt:
    """起動の試行 1 回分。成否を、待っている呼び出しと分かち合う。"""

    __slots__ = ("done", "error")

    def __init__(self) -> None:
        self.done = threading.Event()
        self.error = ""


def worker_command(exe: Path, model_path: Path) -> list[str]:
    """worker の起動コマンド。追加フラグなし＝ウォームアップあり。"""
    return [str(exe), "worker", str(model_path)]


def default_command(model_path: Path) -> list[str]:
    """本番用の起動コマンド。speech.exe が無ければエラーにする。"""
    exe = BIN_DIR / "speech-cpp" / "speech.exe"
    if not exe.is_file():
        raise SpeechWorkerError(f"speech.exe が見つかりません: {exe}")
    return worker_command(exe, model_path)


def _error_text(msg: dict) -> str:
    """worker の error / fatal 行から、人が読む文を取り出す。"""
    err = msg.get("error")
    if isinstance(err, dict):
        return str(err.get("message") or err.get("code") or err)
    if err:
        return str(err)
    return str(msg.get("message") or msg.get("type") or "?")


class SpeechWorker:
    """speech worker プロセス 1 つを常駐させて、何度でも使う。

    command は差し替え可能（テストでは偽 worker を Python
    スクリプトとして起こす）。スレッドから同時に呼ばれても、
    依頼は 1 つずつ直列に流れる（worker 自身も直列に処理する）。
    """

    def __init__(self, command: list[str], *,
                 startup_timeout: float = 180.0) -> None:
        self.command = [str(c) for c in command]
        folder = Path(self.command[0]).parent
        self._cwd = str(folder) if folder.is_dir() else None
        self._startup_timeout = startup_timeout
        self._proc: subprocess.Popen | None = None
        self._is_ready = False
        self._lock = threading.RLock()
        self._run_lock = threading.Lock()
        self._loading = threading.Event()
        self._attempt: _Attempt | None = None
        self._warm_lock = threading.Lock()
        self._gen = 0
        self._seq = 0
        self._pending: dict[str, queue.Queue] = {}
        self._load_error = ""
        self.load_seconds = 0.0
        self.runs = 0
        self.total_seconds = 0.0
        self.last_seconds = 0.0

    # ---------------------------------------------------------- 読み込み

    @property
    def ready(self) -> bool:
        proc = self._proc
        return bool(self._is_ready and proc is not None
                    and proc.poll() is None)

    @property
    def error(self) -> str:
        return self._load_error

    def load(self) -> None:
        """worker を起こして ready を待つ。起きていれば何もしない。

        単一飛行: 同時に走る起動はインスタンスごとに 1 つだけ。
        起動中の呼び出しは試行（_Attempt）の成否を待って分かち
        合い、試行の合間に来た呼び出しは次の試行の主になる。
        以前は load のたびにプロセスを起こし、warmup・初回の
        認識・品質エンジンが起動を奪い合っていた（2026-11-05
        実機: 重なった片方が ready を返す前に死んだ）。
        試行そのものは _BOOT_LOCK で全インスタンス直列にする。
        """
        if self.ready:
            return
        with self._lock:
            if self.ready:
                return
            attempt = self._attempt
            if attempt is None:
                attempt = self._attempt = _Attempt()
                owner = True
            else:
                owner = False
        if not owner:
            attempt.done.wait()
            if attempt.error:
                raise SpeechWorkerError(attempt.error)
            return
        failure: BaseException | None = None
        try:
            with _BOOT_LOCK:
                with self._lock:
                    self._start_locked()
        except BaseException as exc:  # noqa: BLE001
            failure = exc
        with self._lock:
            if self._attempt is attempt:
                self._attempt = None
        if failure is not None:
            attempt.error = (str(failure)
                             or type(failure).__name__)
        attempt.done.set()
        if failure is not None:
            raise failure

    def _start_locked(self) -> None:
        old = self._proc
        self._proc = None
        self._is_ready = False
        if old is not None:
            _kill(old)
        startup: queue.Queue = queue.Queue()
        t0 = time.perf_counter()
        try:
            proc = subprocess.Popen(
                self.command, stdin=subprocess.PIPE,
                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                cwd=self._cwd, creationflags=CREATE_NO_WINDOW)
        except OSError as exc:
            self._load_error = f"speech worker を起動できません: {exc}"
            raise SpeechWorkerError(self._load_error) from exc
        self._proc = proc
        threading.Thread(target=self._read_loop, args=(proc, startup),
                         name="speech-worker-read", daemon=True).start()
        try:
            msg = startup.get(timeout=self._startup_timeout)
        except queue.Empty:
            _kill(proc)
            self._proc = None
            self._load_error = ("speech worker が時間内に ready を"
                                "返しませんでした")
            raise SpeechWorkerError(self._load_error) from None
        if msg is _EOF or not isinstance(msg, dict) \
                or msg.get("type") != "ready":
            detail = (_error_text(msg) if isinstance(msg, dict)
                      else "プロセスが終了しました")
            _kill(proc)
            self._proc = None
            self._load_error = f"speech worker が起動できません: {detail}"
            raise SpeechWorkerError(self._load_error)
        if msg.get("protocol") != PROTOCOL:
            _kill(proc)
            self._proc = None
            self._load_error = (f"speech worker のプロトコル "
                                f"{msg.get('protocol')} には対応して"
                                "いません")
            raise SpeechWorkerError(self._load_error)
        self._is_ready = True
        self.load_seconds = time.perf_counter() - t0
        self._load_error = ""
        log.info("speech worker を起動しました（%s / 読み込み %.2fs）",
                 msg.get("version", "?"), self.load_seconds)

    def load_async(self) -> None:
        """起動を別スレッドで始める（本体を止めない）。"""
        if self.ready or self._loading.is_set():
            return
        self._loading.set()

        def run() -> None:
            try:
                self.load()
            except Exception:
                log.debug("非同期の起動に失敗", exc_info=True)
            finally:
                self._loading.clear()

        threading.Thread(target=run, name="speech-worker-load",
                         daemon=True).start()

    def unload(self) -> None:
        """worker を終了する。実行がハングしていても待たされない。

        kill は投げるだけなので、詰まった実行の後始末は読み取り側の
        終了通知に任せ、ここは即座に戻る。
        """
        with self._lock:
            proc, self._proc = self._proc, None
            self._is_ready = False
            # 世代も進める。ハングした実行があとから目覚めても、
            # 古い世代の結果として扱われるようにするため。
            self._gen += 1
        if proc is not None:
            _kill(proc)
            log.info("speech worker を終了しました")

    # ---------------------------------------------------------- 読み取り

    def _read_loop(self, proc: subprocess.Popen,
                   startup: queue.Queue) -> None:
        """stdout を読み、ready と終端行を待ち手へ振り分ける。

        progress は捨てる。終端（end / error / cancelled）だけが
        依頼の結果で、id ごとに専用のキューへ渡す。
        """
        try:
            stream = proc.stdout
            if stream is None:
                return
            for raw in stream:
                line = raw.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except ValueError:
                    # プロトコル外の行はこちらでは落とさず読み飛ばす
                    log.warning("worker のプロトコル外の行: %r",
                                line[:120])
                    continue
                if not isinstance(msg, dict):
                    continue
                kind = msg.get("type")
                if kind in ("ready", "fatal"):
                    startup.put(msg)
                elif kind in ("end", "error", "cancelled"):
                    wait = self._pending.get(str(msg.get("id")))
                    if wait is not None:
                        wait.put(msg)
        except Exception:
            log.debug("worker の読み取りで例外", exc_info=True)
        finally:
            # プロセスが死んだら、待っている全員へ知らせる
            startup.put(_EOF)
            for wait in list(self._pending.values()):
                wait.put(_EOF)
            with self._lock:
                if self._proc is proc:
                    self._is_ready = False

    # -------------------------------------------------------- 文字起こし

    def transcribe_pcm(self, pcm: bytes, *, vocabulary=None,  # noqa: ANN001
                       timeout: float | None = None) -> str:
        """16bit PCM を文字にする。空の結果もあり得る。

        ★timeout の実効化は resident と同じ理由（監査 H2）。
        ハングした worker を握ったまま待つと全認識が止まるので、
        実行を別スレッドへ出し、過ぎたらプロセスごと捨てて世代を
        進め、呼び出し側へエラーを返す。再起動は次の呼び出しの
        load() が行う（タイムアウトした呼び出し自体は失敗で返す）。
        """
        if not pcm:
            return ""
        seconds = len(pcm) / (SAMPLE_RATE * 2)
        if timeout is None:
            timeout = max(30.0, seconds * 2 + 15.0)
        self.load()
        with self._lock:
            gen = self._gen
        t0 = time.perf_counter()
        outcome: dict = {}

        def work() -> None:
            if not self._run_lock.acquire(timeout=max(0.05, timeout)):
                outcome["error"] = SpeechWorkerError(
                    "前の認識が終わりません")
                return
            try:
                try:
                    outcome["text"] = self._request(pcm, vocabulary, gen)
                except _DiedError:
                    # 途中で死んだ。起こし直して 1 回だけやり直す。
                    self.load()
                    with self._lock:
                        again = self._gen
                    outcome["text"] = self._request(pcm, vocabulary,
                                                    again)
            except BaseException as exc:  # noqa: BLE001
                outcome["error"] = exc
            finally:
                self._run_lock.release()

        worker = threading.Thread(target=work, name="speech-worker-run",
                                  daemon=True)
        worker.start()
        worker.join(timeout)
        if worker.is_alive():
            self._abandon(gen)
            raise SpeechWorkerError(
                f"認識が {timeout:.1f} 秒を超えたので、"
                "ワーカーを作り直します")
        error = outcome.get("error")
        if error is not None:
            raise error
        self._note_run(t0)
        text = str(outcome.get("text") or "").strip()
        log.info("認識 %.3fs (speech worker): %s", self.last_seconds,
                 text.replace("\n", " ")[:160])
        return text

    def _request(self, pcm: bytes, vocabulary,  # noqa: ANN001
                 gen: int) -> str:
        """依頼 1 件を送り、自分の id の終端行まで待つ。"""
        with self._lock:
            self._seq += 1
            rid = f"g{gen}-{self._seq}"
        wait: queue.Queue = queue.Queue()
        self._pending[rid] = wait
        proc = self._proc
        try:
            seq = 0
            for off in range(0, len(pcm), CHUNK_BYTES):
                part = pcm[off:off + CHUNK_BYTES]
                self._send({"type": "chunk", "id": rid, "seq": seq,
                            "pcm": base64.b64encode(part)
                            .decode("ascii")})
                seq += 1
            req: dict = {"type": "transcribe", "id": rid,
                         "sample_rate": SAMPLE_RATE}
            if vocabulary:
                # 表示形だけを改行で並べる。読みは付けない
                # （Haas 側の推定と置き換えに任せる）。
                req["keywords"] = "\n".join(str(w) for w in vocabulary)
            self._send(req)
            while True:
                msg = wait.get()
                if msg is _EOF:
                    current = self._proc
                    if current is not None and current is not proc:
                        continue   # 前の世代の終了通知は読み飛ばす
                    raise _DiedError("worker が応答の途中で終了しました")
                kind = msg.get("type")
                if kind == "end":
                    return str(msg.get("text") or "")
                if kind == "error":
                    raise SpeechWorkerError(
                        "worker がエラーを返しました: "
                        f"{_error_text(msg)}")
                if kind == "cancelled":
                    raise SpeechWorkerError(
                        "worker が依頼を取り消しました")
                raise SpeechWorkerError(f"worker の想定外の応答: {kind}")
        finally:
            self._pending.pop(rid, None)

    def _send(self, msg: dict) -> None:
        proc = self._proc
        if proc is None or proc.stdin is None or proc.poll() is not None:
            raise _DiedError("worker が動いていません")
        line = (json.dumps(msg) + "\n").encode("utf-8")
        try:
            proc.stdin.write(line)
            proc.stdin.flush()
        except (OSError, ValueError) as exc:
            raise _DiedError(f"worker へ送れません: {exc}") from exc

    def _abandon(self, gen: int) -> None:
        """詰まった世代のプロセスを捨てる（再起動は次の load で）。

        プロセスを kill すれば読み取り側が終了を検知し、詰まった
        実行スレッドもほどける。世代が既に進んでいたら、ほかが
        先に片付けたので何もしない。
        """
        with self._lock:
            if gen != self._gen:
                return
            log.error("認識が時間を超えたので worker を捨てます"
                      "（世代 %d を破棄）", gen)
            self._gen += 1
            proc, self._proc = self._proc, None
            self._is_ready = False
        if proc is not None:
            _kill(proc)

    def _note_run(self, t0: float) -> None:
        """実行 1 回ぶんの計時を統計へ反映する（resident と同じ形）。"""
        self.last_seconds = time.perf_counter() - t0
        self.runs += 1
        self.total_seconds += self.last_seconds

    @property
    def average_seconds(self) -> float:
        return self.total_seconds / self.runs if self.runs else 0.0

    def warmup(self, long_seconds: float = 0.0) -> None:
        """起動と、最初の 1 回を済ませておく。

        worker 自身も起動時にウォームアップするが、こちらの統計
        （last_seconds）を用意する意味でも 1 回回す。

        同時に 1 つだけ: 起動時・切替時・品質エンジン用意時と
        複数の経路が温めに来ても、走っているものがあれば重ねずに
        戻る（起動は load() の単一飛行に相乗りするので、温め直し
        を重ねる意味が無い）。起動完了を待ってから、同じ
        プロセスで短い認識を 1 回だけ回す形は従来どおり。
        """
        if not self._warm_lock.acquire(blocking=False):
            return
        try:
            self.load()
            self.transcribe_pcm(bytes(SAMPLE_RATE))      # 0.5 秒の無音
            short = self.last_seconds
            if long_seconds > 0 and short < 0.25:
                self.transcribe_pcm(
                    bytes(int(SAMPLE_RATE * 2 * long_seconds)))
            log.info("ウォームアップ完了 speech worker"
                     "（読み込み %.2fs / 1回 %.3fs）",
                     self.load_seconds, short)
        except Exception as exc:
            log.warning("ウォームアップできませんでした: %s", exc)
        finally:
            self._warm_lock.release()


def _kill(proc: subprocess.Popen) -> None:
    """プロセスを止める。待ち合わせは別スレッド（呼ぶ側を止めない）。"""
    try:
        if proc.stdin is not None:
            proc.stdin.close()
    except Exception:
        pass
    try:
        if proc.poll() is None:
            proc.kill()
    except Exception:
        pass
    try:
        if proc.stdout is not None:
            proc.stdout.close()
    except Exception:
        pass

    def reap() -> None:
        try:
            proc.wait(timeout=10)
        except Exception:
            pass

    threading.Thread(target=reap, name="speech-worker-reap",
                     daemon=True).start()
