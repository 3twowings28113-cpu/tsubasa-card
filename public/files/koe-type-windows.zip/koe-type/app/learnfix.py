"""誤変換の自動学習: 「直した箇所」を、次の文字起こしへ効かせる。

利用者が音声入力の直後に手で直した内容は、いちばん確かな
「この聞き間違いはこう直す」という教材。ただし他アプリの
入力欄を覗いて差分を取るようなことはしない（相手のアプリの
状態は確実には分からず、誤学習のもとになる）。代わりに、

  ・専用の編集ポップアップ（app/fixwin.py）で直してもらい、
  ・元文との差分から「置き換えペア」の候補を機械的に出し、
  ・**本人がチェックして採用したペアだけ**を保存する

という経路に限定する。採用されなかった候補はどこにも残らない。

学習ペアの適用位置（整形パイプライン）:
  辞書（dictionary.txt）は整形の前段で掛かるが、学習ペアの
  「元の形」は利用者が**整形後の最終形**を見て直したもの。
  だから学習ペアは整形のいちばん最後（jatext.format_text の
  末尾）で当てる。辞書や同音異義語の文脈補正よりも後に効く
  ＝利用者の確定した直しが、推測のルールに勝つ、という順序。
"""

from __future__ import annotations

import difflib
import json
import logging
import re
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from .homophones import SURFACE_TO_READING
from .util import DATA_DIR

log = logging.getLogger(__name__)

STORE_PATH = DATA_DIR / "learned_fixes.json"

# 学習対象にする置き換えの長さ。文節まるごとの書き換えは
# 「聞き間違いの直し」ではなく文章の推敲なので、対象にしない。
_MAX_SRC = 12
_MAX_DST = 16

_KANJI = re.compile(r"[一-鿿]")
_PUNCT_ONLY = re.compile(r"[\s、。，．！？!?・「」『』（）()\[\]　]*$")
_HIRA_KATA = re.compile(r"[ぁ-ゖァ-ヺー]")


@dataclass(frozen=True)
class Pair:
    """置き換えペア（src を dst に直す）。kind は出どころの種類。"""
    src: str
    dst: str
    kind: str = "word"      # homophone / abbr / word


def _kanji_run(text: str) -> str:
    """漢字だけを抜き出した並び（送り仮名揺れの判定に使う）。"""
    return "".join(_KANJI.findall(text))


def _is_okurigana_wobble(src: str, dst: str) -> bool:
    """送り仮名程度の揺れかどうか（学習対象にしない）。

    「行なう→行う」のように、漢字の並びが同じで違う部分が
    仮名だけのものは、表記ゆれであって聞き間違いの直しでは
    ない。学習すると、利用者の書き方の癖を認識結果へ押しつ
    けることになるので候補から外す。漢字が 1 つも無いペア
    （ピーシー→PC 等）は、この判定の対象ではない。
    """
    run = _kanji_run(src)
    if not run or run != _kanji_run(dst):
        return False
    # 漢字の並びが同じで、全体が違えば、違いは仮名側にある
    return src != dst


def _classify(src: str, dst: str) -> str:
    """ペアの種類。同音異義語テーブル内なら homophone。"""
    reading = SURFACE_TO_READING.get(src)
    if reading and SURFACE_TO_READING.get(dst) == reading:
        return "homophone"
    if re.fullmatch(r"[A-Za-z0-9]+", dst) or \
            re.fullmatch(r"[ァ-ヺー]+", src):
        return "abbr"
    return "word"


def extract_pairs(original: str, corrected: str) -> list[Pair]:
    """元文と直した文から、学習候補の置き換えペアを出す。

    対象は「置き換え（replace）」だけ。文の追加・削除は
    内容の編集であって聞き間違いの直しではないので拾わない。
    句読点・空白だけの差も、整形の揺れとして拾わない。
    """
    if not original or not corrected or original == corrected:
        return []
    matcher = difflib.SequenceMatcher(None, original, corrected,
                                      autojunk=False)
    # 文全体が大きく書き換わっているものは「推敲」であって
    # 聞き間違いの直しではない。小さな置き換えに割れて
    # 漏れてくるので、全体の似かたが低いものは候補ゼロにする。
    if matcher.ratio() < 0.6:
        return []
    pairs: list[Pair] = []
    seen: set[tuple[str, str]] = set()
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag != "replace":
            continue
        src = original[i1:i2]
        dst = corrected[j1:j2]
        if src == dst:
            continue
        if len(src) > _MAX_SRC or len(dst) > _MAX_DST:
            continue            # 長い書き換えは推敲扱い
        if _PUNCT_ONLY.fullmatch(src) and _PUNCT_ONLY.fullmatch(dst):
            continue            # 句読点・空白だけの差
        if _is_okurigana_wobble(src, dst):
            continue            # 送り仮名程度の揺れ
        if (src, dst) in seen:
            continue
        seen.add((src, dst))
        pairs.append(Pair(src, dst, _classify(src, dst)))
    return pairs


def apply_pairs(text: str,
                pairs: tuple[tuple[str, str], ...]
                | list[tuple[str, str]]) -> str:
    """学習ペアを本文へ当てる（長い語から、辞書と同じ作法）。"""
    if not text or not pairs:
        return text
    for src, dst in sorted(pairs, key=lambda p: len(p[0]),
                           reverse=True):
        if src and src != dst and src in text:
            text = text.replace(src, dst)
    return text


# ---------------------------------------------------------------- 保存


class LearnStore:
    """採用された学習ペアの保存（data/learned_fixes.json）。

    辞書（Dictionary）と同じ流儀で、ファイルが変わっていたら
    読み直す。書き込みは一時ファイル経由で原子的に差し替える。
    """

    def __init__(self, path: Path = STORE_PATH) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._mtime = -1.0
        self._rows: list[dict[str, object]] = []
        self.reload(force=True)

    def reload(self, *, force: bool = False) -> bool:
        try:
            mtime = self.path.stat().st_mtime
        except OSError:
            if force:
                self._rows = []
            return False
        if not force and mtime == self._mtime:
            return False
        self._mtime = mtime
        try:
            data = json.loads(self.path.read_text("utf-8"))
            rows = data.get("pairs", []) if isinstance(data, dict) else []
            out: list[dict[str, object]] = []
            for row in rows:
                if isinstance(row, dict):
                    src, dst = str(row.get("src", "")), str(
                        row.get("dst", ""))
                    if src and dst and src != dst:
                        out.append({"src": src, "dst": dst,
                                    "at": row.get("at", 0)})
            self._rows = out
        except Exception:
            log.exception("学習ペアを読めませんでした")
            self._rows = []
            return False
        return True

    def pairs(self) -> tuple[tuple[str, str], ...]:
        """保存済みのペア（パイプラインへ渡す形）。"""
        self.reload()
        return tuple((str(r["src"]), str(r["dst"])) for r in self._rows)

    def add_pairs(self, pairs: list[tuple[str, str]]) -> int:
        """採用されたペアを保存する。追加・更新できた件数を返す。

        同じ src で逆向き・別向きのペアが既にあれば、新しい
        採用で差し替える（利用者の最新の直しが正）。
        """
        with self._lock:
            self.reload()
            current = {str(r["src"]): str(r["dst"]) for r in self._rows}
            added = 0
            for src, dst in pairs:
                if not src or not dst or src == dst:
                    continue
                if current.get(src) == dst:
                    continue
                # 逆向き（dst→src）があれば消す。行ったり来たりを防ぐ
                if current.get(dst) == src:
                    del current[dst]
                current[src] = dst
                added += 1
            if added:
                now = time.time()
                old_at = {(str(r["src"]), str(r["dst"])): r.get("at", now)
                          for r in self._rows}
                self._rows = [
                    {"src": s, "dst": d, "at": old_at.get((s, d), now)}
                    for s, d in current.items()]
                self._save()
            return added

    def remove(self, src: str, dst: str) -> bool:
        """学習済みペアを 1 件消す。"""
        with self._lock:
            self.reload()
            before = len(self._rows)
            self._rows = [r for r in self._rows
                          if not (r["src"] == src and r["dst"] == dst)]
            if len(self._rows) == before:
                return False
            self._save()
            return True

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(json.dumps({"pairs": self._rows},
                                      ensure_ascii=False, indent=1),
                           "utf-8")
            tmp.replace(self.path)
            self._mtime = self.path.stat().st_mtime
        except OSError:
            log.exception("学習ペアを保存できませんでした")
