"""設定の読み書き。

config.json は設定画面から書き換えるので、コメントは持たせない
（説明は設定画面と README にある）。古い形式も読めるようにしてある。
変更は即保存・即通知。保存は一時ファイル経由で入れ替えるので、
書き込み中に電源が落ちても設定が壊れない。
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path
from typing import Any, Callable

from . import schema
from .util import CONFIG_PATH, loads_tolerant

log = logging.getLogger(__name__)


def quarantine(path: Path, why: str) -> str:
    """壊れたファイルを退避する。戻り値は退避先の名前（失敗なら空）。

    消さずに残すのは、利用者が手で書いた内容を失わせないため。
    設定画面でも「壊れていたので初期値に戻しました」と知らせる。
    """
    stamp = time.strftime("%Y%m%d-%H%M%S")
    target = path.with_name(f"{path.stem}.broken-{stamp}{path.suffix}")
    try:
        os.replace(path, target)
    except OSError:
        log.exception("%s を退避できませんでした", path.name)
        return ""
    log.error("%s が壊れていたので %s へ退避し、初期値で起動します（%s）",
              path.name, target.name, why)
    return target.name


class Config:
    def __init__(self, path: Path = CONFIG_PATH) -> None:
        self.path = path
        self.recovered = ""        # 壊れていて退避したファイルの名前
        self._lock = threading.RLock()
        self._data: dict[str, Any] = schema.defaults()
        self._listeners: list[Callable[[set[str]], None]] = []
        self._own_mtime = 0.0
        self.load()

    # ------------------------------------------------------------------ 読み書き

    def load(self) -> None:
        """設定を読む。**壊れていても必ず起動する。**

        壊れたファイルは消さずに `config.broken-<日時>.json` へ退避する。
        上書きしてしまうと、利用者が手で直した内容が消えてしまうため。
        """
        raw: dict[str, Any] = {}
        self.recovered = ""
        try:
            raw = loads_tolerant(self.path.read_text("utf-8-sig"))
            if not isinstance(raw, dict):
                raise ValueError("JSON の一番外側が { } ではありません")
        except FileNotFoundError:
            log.info("config.json がないので初期値で作ります")
        except Exception as exc:
            self.recovered = quarantine(self.path, f"{exc}")
            raw = {}
        with self._lock:
            self._data = schema.defaults()
            self._data.update(_migrate(raw))
        # 読み込んだ内容を書き戻して、形を今の版にそろえる
        # （昔のコメント付き config.json もここで素の JSON になる）
        self.save()

    def save(self) -> None:
        with self._lock:
            data = dict(self._data)
        tmp = self.path.with_suffix(".json.tmp")
        try:
            tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n",
                           "utf-8")
            os.replace(tmp, self.path)
        except Exception:
            log.exception("config.json を保存できませんでした")
            tmp.unlink(missing_ok=True)
        else:
            # ★自分の保存を外部の変更と誤認しないよう、保存後の
            # mtime を覚えておく。これがないと poll_external が
            # 保存のたびに全読み＋移行を無駄に走らせる
            # （2026-10-31 第三者監査 L19）。
            try:
                with self._lock:
                    self._own_mtime = self.path.stat().st_mtime
            except OSError:
                pass

    # ------------------------------------------------------------------ 取得・変更

    def __getitem__(self, key: str) -> Any:
        with self._lock:
            return self._data[key]

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(key, default)

    def int_(self, key: str, default: int = 0) -> int:
        try:
            return int(self.get(key, default))
        except (TypeError, ValueError):
            return default

    def bool_(self, key: str, default: bool = False) -> bool:
        return bool(self.get(key, default))

    def str_(self, key: str, default: str = "") -> str:
        value = self.get(key, default)
        return default if value is None else str(value)

    def list_(self, key: str) -> list[str]:
        value = self.get(key, [])
        if isinstance(value, str):
            return [v.strip() for v in value.splitlines() if v.strip()]
        if isinstance(value, (list, tuple)):
            return [str(v) for v in value]
        # ★手編集で数値などのスカラーが入っていても例外にしない。
        # スカラーは 1 要素にし、形の合わないもの（dict 等）は空に
        # する（2026-10-31 第三者監査 L17。以前は数値を読むと
        # TypeError が呼び出し側へ伝播していた）。
        if value is None or isinstance(value, (dict, set, frozenset)):
            return []
        return [str(value)]

    def set(self, key: str, value: Any, *, save: bool = True) -> bool:
        """値を変える。変わったら True。"""
        with self._lock:
            if self._data.get(key) == value:
                return False
            self._data[key] = value
        log.info("設定を変更: %s = %r", key, value)
        if save:
            self.save()
        self._notify({key})
        return True

    def update(self, values: dict[str, Any]) -> None:
        changed: set[str] = set()
        with self._lock:
            for key, value in values.items():
                if self._data.get(key) != value:
                    self._data[key] = value
                    changed.add(key)
        if changed:
            self.save()
            self._notify(changed)

    def reset(self) -> None:
        with self._lock:
            before = set(self._data)
            self._data = schema.defaults()
            changed = before | set(self._data)
        log.warning("設定を初期値に戻しました")
        self.save()
        self._notify(changed)

    def as_dict(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._data)

    def poll_external(self) -> set[str]:
        """config.json が外（エディタなど）で書き換わっていたら読み直す。

        設定画面からの変更は自分で保存しているので、そのぶんは無視する。
        """
        try:
            mtime = self.path.stat().st_mtime
        except OSError:
            return set()
        if mtime == self._own_mtime:
            return set()
        try:
            raw = loads_tolerant(self.path.read_text("utf-8-sig"))
            if not isinstance(raw, dict):
                return set()
        except Exception:
            log.warning("外で書き換えられた config.json を読めませんでした")
            self._own_mtime = mtime
            return set()
        fresh = schema.defaults()
        fresh.update(_migrate(raw))
        with self._lock:
            changed = {k for k, v in fresh.items() if self._data.get(k) != v}
            self._data = fresh
            self._own_mtime = mtime
        if changed:
            log.info("config.json が外で変わったので読み直しました: %s",
                     sorted(changed))
            self._notify(changed)
        return changed

    # ------------------------------------------------------------------ 通知

    def subscribe(self, fn: Callable[[set[str]], None]) -> None:
        self._listeners.append(fn)

    def _notify(self, keys: set[str]) -> None:
        for fn in list(self._listeners):
            try:
                fn(keys)
            except Exception:
                log.exception("設定変更の通知で例外")


def _migrate(raw: dict[str, Any]) -> dict[str, Any]:
    """古い config.json を今の形に直す。"""
    out = dict(raw)

    # engines テーブルはコード側（catalog.py）へ移した
    out.pop("engines", None)

    # engine 名 -> model id
    engine = out.pop("engine", None)
    if engine and "model" not in out:
        out["model"] = {
            "sensevoice": "sensevoice-small",
            "sensevoice-cpu": "sensevoice-small",
            "funasr-nano": "funasr-nano",
            "funasr-nano-q5km": "funasr-nano",
            "whisper": "whisper-large-v3-turbo",
        }.get(str(engine), "sensevoice-small")

    # 感度を 3.0 のような実数から 30 のような整数へ。
    # ★実数のときだけ変換する。旧形式は実数で書かれていたので、
    # 変換後の整数とは区別できる。整数まで対象にすると、新形式で
    # 小さい値（例: 5）を選んだ利用者の設定を起動のたびに 10 倍に
    # してしまうし、0.5 → 5 → 50 のような二重変換も起こる。
    # 変換結果は整数になるので、これも自然に 1 回だけ効く。
    sens = out.get("vad_sensitivity")
    if isinstance(sens, float) and sens < 10:
        out["vad_sensitivity"] = int(round(sens * 10))

    # 表示位置まわりの名前替え
    if "overlay_bottom_px" in out and "overlay_margin_px" not in out:
        out["overlay_margin_px"] = out.pop("overlay_bottom_px")
    out.pop("overlay_theme", None)
    out.pop("overlay_bottom_px", None)
    out.pop("sound", None)
    out.pop("keep_last_wav", None)
    # 自己学習（2026-10-23 撤去）。話しながら入力の途中経過を「言い直し」と
    # 取り違え、でたらめな置き換えを覚えて入力を壊していた
    out.pop("adaptive_learning", None)

    # 帯は作業領域（タスクバーを除いた所）を基準に置くようになったので、
    # 昔の大きな余白はそのままだと浮きすぎる。
    # ★マーカー (overlay_margin_migrated) で 1 回だけ。正規の範囲
    # （0〜200）と重なるため、マーカーなしだと 48 以上を愛用して
    # いる人の設定を起動のたびに 16 へ消してしまう（2026-10-31
    # 第三者監査）。あとから利用者が大きな値へ戻しても触らない。
    if not out.get("overlay_margin_migrated"):
        margin = out.get("overlay_margin_px")
        if isinstance(margin, (int, float)) and margin >= 48:
            out["overlay_margin_px"] = 16
        out["overlay_margin_migrated"] = True

    # 常駐方式ができたので、同じ中身の常駐版へ移す。
    # 外部プロセス版は 1 回につき 0.6 秒の固定費があり、常駐版なら 0.12 秒。
    # 利用者が自分で選び直さなくても速くなるようにする。
    # ★マーカー (resident_model_migrated) で 1 回だけ。以前は
    # 無条件・毎回適用だったため、外部プロセス版を選び直しても
    # 次の起動で黙って常駐版へ戻されていた（2026-10-31 第三者
    # 監査: 設定層に残った一方通行変更）。レンズ既定化
    # (lens_defaults_applied) と同じ流儀にそろえる。
    if not out.get("resident_model_migrated"):
        model = out.get("model")
        if model in ("sensevoice-small", "sensevoice", "sensevoice-cpu"):
            out["model"] = "sensevoice-resident"
        elif model == "whisper-large-v3-turbo":
            out["model"] = "whisper-turbo-resident"
        out["resident_model_migrated"] = True

    # 句読点は「つける／つけない」から「量」へ変わった
    if "punctuation" in out:
        on = bool(out.pop("punctuation"))
        out.setdefault("punctuation_density", "normal" if on else "none")

    # かこって検索の既定を Google レンズにする（2026-10-25 既定化）。
    # schema の初期値を変えただけでは届かない: 既存の config.json には
    # 旧既定（snip_engine="builtin" / google_lens_hotkey=""）が値として
    # 書き込まれているため。そこで 1 回だけ寄せる。
    # ★マーカー (lens_defaults_applied) で二度と触らない。あとから
    # 利用者が内蔵へ戻しても、次の起動で勝手に Google へ戻さない。
    # 利用者が自分で入れた組み合わせ（空でない値）も上書きしない。
    if not out.get("lens_defaults_applied"):
        if out.get("snip_engine") in (None, "builtin"):
            out["snip_engine"] = "google"
        if not out.get("google_lens_hotkey"):
            out["google_lens_hotkey"] = "ctrl+alt+shift+l"
        out["lens_defaults_applied"] = True

    _merge_new_instructions(out)
    return out


# 文章変換の一覧に、最初から入っていた変換。これより後に足した変換は、
# すでに一覧を持っている人にも 1 回だけ追加する。
_FIRST_INSTRUCTION_IDS = ("translate_en", "terminal_helper", "professional",
                          "task_list", "chaos_mode", "buzzword_mode")


def _merge_new_instructions(out: dict[str, Any]) -> None:
    """新しく増えた組み込みの変換を、利用者の一覧に足す。

    一覧は丸ごと config.json に保存されるので、そのままだと新しい変換が
    いつまでも出てこない。一方で、利用者が消した変換を勝手に戻すのも困る。
    そこで「一度見せた ID」を覚えておき、まだ見せていないものだけを足す。
    """
    current = out.get("ai_custom_instructions")
    if not isinstance(current, list):
        return
    defaults = [dict(x) for x in schema._DEFAULT_CUSTOM_INSTRUCTIONS]
    seen = out.get("ai_instruction_ids_seen")
    if not isinstance(seen, list):
        seen = list(_FIRST_INSTRUCTION_IDS)
    have = {str(x.get("id")) for x in current if isinstance(x, dict)}
    merged = list(current)
    for inst in defaults:
        if inst["id"] not in seen and inst["id"] not in have:
            merged.append(inst)
    out["ai_custom_instructions"] = merged
    out["ai_instruction_ids_seen"] = sorted(
        set(seen) | {x["id"] for x in defaults})
