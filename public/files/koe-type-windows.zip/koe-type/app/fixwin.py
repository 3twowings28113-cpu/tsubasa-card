"""「直す」ための編集ポップアップ（誤変換の学習＋同音異義語）。

入口は 2 つ（どちらも app/main.py から）:
  ・「直前の挿入を直す」専用ホットキー
  ・履歴ピッカーの項目で F2

窓の中でできること:
  ・本文を直接編集する
  ・同音異義語（app/homophones.py のテーブルにある表記）が
    青く光る。クリック（または Ctrl+↑↓ で巡回して Alt+Enter）
    で候補メニューを出し、選ぶとその出現だけ差し替わる。
    選んだ表記は「好み」として記録され、次回の候補で先頭に出る
  ・元文との差分から学習候補（app/learnfix.py）が出る。
    チェックしたペアだけが、閉じるときに呼び出し側へ渡る
    （＝保存される）。チェックしなかった候補は残らない
  ・学習済みペアの一覧と削除

窓の基盤は clipwin / histpick と同じ作法（ctypes の自前窓・
専用スレッドで開く・クラス名は実体ごとに変える）。編集欄は
RichEdit（MsftEdit.dll、OS 標準）。キーは**自分の窓の中だけ**
で見る。低レベルフックは使わない（AGENTS.md の決まり）。
"""

from __future__ import annotations

import ctypes
import logging
import os
import threading
from ctypes import wintypes
from dataclasses import dataclass, field

from . import dryrun, homophones, learnfix
from .i18n import t

# snipping.py / histpick.py と同じ互換シム
if not hasattr(wintypes, "HCURSOR"):
    wintypes.HCURSOR = wintypes.HANDLE  # type: ignore[attr-defined]

log = logging.getLogger(__name__)


@dataclass
class FixResult:
    """編集ポップアップの成果（保存して閉じたとき）。"""
    text: str
    pairs: list[tuple[str, str]] = field(default_factory=list)


# ---------------------------------------------------------------- 定数

WS_POPUP = 0x80000000
WS_VISIBLE = 0x10000000
WS_CHILD = 0x40000000
WS_BORDER = 0x00800000
WS_TABSTOP = 0x00010000
WS_VSCROLL = 0x00200000
BS_LEFT = 0x00000100
BS_AUTOCHECKBOX = 0x0003
LBS_NOTIFY = 0x0001
ES_MULTILINE = 0x0004
ES_AUTOVSCROLL = 0x0040
ES_WANTRETURN = 0x1000
WS_EX_TOPMOST = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080
SW_HIDE = 0
SW_SHOW = 5

WM_DESTROY = 0x0002
WM_ACTIVATE = 0x0006
WM_SETFONT = 0x0030
WM_CLOSE = 0x0010
WM_COMMAND = 0x0111
WM_TIMER = 0x0113
WM_KEYDOWN = 0x0100
WM_SETTEXT = 0x000C
WM_GETTEXT = 0x000D
WM_GETTEXTLENGTH = 0x000E
WM_LBUTTONUP = 0x0202

EM_GETSEL = 0x00B0
EM_SETSEL = 0x00B1
EM_SCROLLCARET = 0x00B7
EM_REPLACESEL = 0x00C2
EM_CHARFROMPOS = 0x00D7
EM_EXSETSEL = 0x0400 + 55
EM_GETTEXTEX = 0x0400 + 94
EM_SETCHARFORMAT = 0x0400 + 68

EN_CHANGE = 0x0300
BN_CLICKED = 0
BM_GETCHECK = 0x00F0
BST_CHECKED = 1

LB_ADDSTRING = 0x0180
LB_GETCURSEL = 0x0188
LB_DELETESTRING = 0x0182
LB_RESETCONTENT = 0x0184
LB_ERR = -1
BM_SETCHECK = 0x00F1

MF_STRING = 0x0000
MF_SEPARATOR = 0x0800
MF_CHECKED = 0x0008
TPM_RETURNCMD = 0x0100
TPM_RIGHTBUTTON = 0x0002
TPM_NONOTIFY = 0x0040

CFM_COLOR = 0x40000000
CFM_BACKCOLOR = 0x04000000
CFM_FACE = 0x20000000
CFM_SIZE = 0x80000000
SCF_SELECTION = 0x0001
SCF_ALL = 0x0004

GWLP_WNDPROC = -4
VK_ESCAPE = 0x1B
VK_RETURN = 0x0D
VK_UP = 0x26
VK_DOWN = 0x28
VK_CONTROL = 0x11
VK_MENU = 0x12

COLOR_WINDOW = 5
COLOR_WINDOWTEXT = 8
COLOR_HIGHLIGHT = 13
COLOR_HIGHLIGHTTEXT = 14

_TIMER_REFRESH = 1
_MAX_CANDIDATES = 10

_ID_EDIT = 3000
_ID_SAVE = 3001
_ID_LEARNED = 3002
_ID_CANCEL = 3003
_ID_DELETE = 3004
_ID_BACK = 3005
_ID_PREV = 3006
_ID_NEXT = 3007
_ID_LIST = 3008
_ID_CAND_BASE = 3100

WNDPROC = ctypes.WINFUNCTYPE(
    ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
    wintypes.WPARAM, wintypes.LPARAM)


class _WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT), ("style", wintypes.UINT),
        ("lpfnWndProc", ctypes.c_void_p), ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int), ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON), ("hCursor", wintypes.HCURSOR),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HICON),
    ]


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _POINTS(ctypes.Structure):
    _fields_ = [("x", ctypes.c_short), ("y", ctypes.c_short)]


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class _MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", _RECT),
                ("rcWork", _RECT), ("dwFlags", wintypes.DWORD)]


class _MSG(ctypes.Structure):
    _fields_ = [("hwnd", wintypes.HWND), ("message", wintypes.UINT),
                ("wParam", wintypes.WPARAM), ("lParam", wintypes.LPARAM),
                ("time", wintypes.DWORD), ("pt", _POINT)]


class _CHARRANGE(ctypes.Structure):
    _fields_ = [("cpMin", ctypes.c_long), ("cpMax", ctypes.c_long)]


class _GETTEXTEX(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("codePage", wintypes.UINT),
                ("lpDefaultChar", ctypes.c_void_p),
                ("lpUsedDefChar", ctypes.c_void_p)]


class _CHARFORMAT2(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT), ("dwMask", wintypes.DWORD),
        ("dwEffects", wintypes.DWORD), ("yHeight", ctypes.c_long),
        ("yOffset", ctypes.c_long), ("crTextColor", wintypes.DWORD),
        ("bCharSet", wintypes.BYTE), ("bPitchAndFamily", wintypes.BYTE),
        ("szFaceName", ctypes.c_wchar * 32), ("wWeight", wintypes.WORD),
        ("sSpacing", ctypes.c_short), ("crBackColor", wintypes.DWORD),
        ("lcid", wintypes.DWORD), ("dwReserved", wintypes.DWORD),
        ("sStyle", ctypes.c_short), ("wKerning", wintypes.WORD),
        ("bUnderlineType", wintypes.BYTE), ("bAnimation", wintypes.BYTE),
        ("bReserved", wintypes.BYTE), ("bRevAuthor", wintypes.BYTE),
        ("bUnderlineColor", wintypes.BYTE),
    ]


user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

# 64bit でハンドルが切り捨てられないよう宣言を付ける（既存モジュールの教訓）
user32.DefWindowProcW.restype = ctypes.c_ssize_t
user32.DefWindowProcW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.CreateWindowExW.restype = wintypes.HWND
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HANDLE, wintypes.HINSTANCE, ctypes.c_void_p]
user32.RegisterClassExW.restype = wintypes.ATOM
user32.RegisterClassExW.argtypes = [ctypes.POINTER(_WNDCLASSEXW)]
user32.UnregisterClassW.restype = wintypes.BOOL
user32.UnregisterClassW.argtypes = [wintypes.LPCWSTR, wintypes.HINSTANCE]
user32.GetMessageW.restype = wintypes.BOOL
user32.GetMessageW.argtypes = [
    ctypes.c_void_p, wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.TranslateMessage.restype = wintypes.BOOL
user32.TranslateMessage.argtypes = [ctypes.c_void_p]
user32.DispatchMessageW.restype = ctypes.c_ssize_t
user32.DispatchMessageW.argtypes = [ctypes.c_void_p]
user32.DestroyWindow.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [wintypes.HWND]
user32.PostQuitMessage.restype = None
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.PostMessageW.restype = wintypes.BOOL
user32.PostMessageW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.SendMessageW.restype = ctypes.c_ssize_t
user32.SendMessageW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.ShowWindow.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetForegroundWindow.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.SetFocus.restype = wintypes.HWND
user32.SetFocus.argtypes = [wintypes.HWND]
user32.GetCursorPos.restype = wintypes.BOOL
user32.GetCursorPos.argtypes = [ctypes.POINTER(_POINT)]
user32.MonitorFromPoint.restype = wintypes.HANDLE
user32.MonitorFromPoint.argtypes = [_POINT, wintypes.DWORD]
user32.GetMonitorInfoW.restype = wintypes.BOOL
user32.GetMonitorInfoW.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(_MONITORINFO)]
user32.LoadCursorW.restype = wintypes.HCURSOR
user32.LoadCursorW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR]
user32.GetSysColor.restype = wintypes.DWORD
user32.GetSysColor.argtypes = [ctypes.c_int]
user32.CreatePopupMenu.restype = wintypes.HMENU
user32.CreatePopupMenu.argtypes = []
user32.AppendMenuW.restype = wintypes.BOOL
user32.AppendMenuW.argtypes = [
    wintypes.HMENU, wintypes.UINT, ctypes.c_void_p, wintypes.LPCWSTR]
user32.TrackPopupMenu.restype = wintypes.UINT
user32.TrackPopupMenu.argtypes = [
    wintypes.HMENU, wintypes.UINT, ctypes.c_int, ctypes.c_int,
    ctypes.c_int, wintypes.HWND, ctypes.c_void_p]
user32.DestroyMenu.restype = wintypes.BOOL
user32.DestroyMenu.argtypes = [wintypes.HMENU]
user32.SetTimer.restype = ctypes.c_void_p
user32.SetTimer.argtypes = [
    wintypes.HWND, ctypes.c_void_p, wintypes.UINT, ctypes.c_void_p]
user32.KillTimer.restype = wintypes.BOOL
user32.KillTimer.argtypes = [wintypes.HWND, ctypes.c_void_p]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.SetWindowLongPtrW.restype = ctypes.c_void_p
user32.SetWindowLongPtrW.argtypes = [
    wintypes.HWND, ctypes.c_int, ctypes.c_void_p]
user32.CallWindowProcW.restype = ctypes.c_ssize_t
user32.CallWindowProcW.argtypes = [
    ctypes.c_void_p, wintypes.HWND, wintypes.UINT,
    wintypes.WPARAM, wintypes.LPARAM]
kernel32.GetModuleHandleW.restype = wintypes.HINSTANCE
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
gdi32.CreateFontW.restype = wintypes.HFONT
gdi32.CreateFontW.argtypes = [
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.LPCWSTR]
gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.DeleteObject.argtypes = [ctypes.c_void_p]

_active: "_Editor | None" = None
_open_lock = threading.Lock()
_class_counter = 0


def _global_proc(hwnd: int, msg: int, wparam: int, lparam: int) -> int:
    if _active is not None:
        return _active._proc(hwnd, msg, wparam, lparam)
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


_static_proc = WNDPROC(_global_proc)


def _edit_class() -> tuple[str, bool]:
    """編集欄の窓クラス。(クラス名, 色付けできるか) を返す。

    RichEdit（MsftEdit.dll）は OS 標準の DLL。読み込めなければ
    通常の EDIT に落とす（色付けはできないが編集と学習候補は
    そのまま使える）。
    """
    try:
        ctypes.WinDLL("msftedit.dll")
        return "RICHEDIT50W", True
    except OSError:
        pass
    try:
        ctypes.WinDLL("riched20.dll")
        return "RichEdit20W", True
    except OSError:
        return "EDIT", False


def _ui_scale() -> float:
    """画面の拡大率（histpick.py と同じ考え方）。"""
    try:
        get_dpi = getattr(user32, "GetDpiForSystem", None)
        if get_dpi is not None:
            dpi = int(get_dpi())
            if dpi > 0:
                return max(1.0, min(2.5, dpi / 96.0))
    except Exception:
        pass
    return 1.0


def _escape(text: str) -> str:
    """ボタンの文字では & がニーモニック扱いになるので二重にする。"""
    return text.replace("&", "&&")


class _Editor:
    def __init__(self, original: str, title: str,
                 store: learnfix.LearnStore,
                 prefs: homophones.Prefs, *,
                 learn_enabled: bool = True) -> None:
        self.original = original
        self.title = title
        self.store = store
        self.prefs = prefs
        self.learn_enabled = learn_enabled
        self.result: FixResult | None = None
        self._hwnd = 0
        self._edit = 0
        self._rich = False
        self._font = 0
        self._done = False
        self._learned_view = False
        self._controls: dict[str, int] = {}
        self._cand_boxes: list[int] = []
        self._cand_pairs: list[learnfix.Pair] = []
        self._cand_sig: tuple = ()
        self._occ_sig: tuple = ()
        self._occ_index = -1          # 巡回中の出現の通し番号
        self._edit_proc_ref = None    # サブクラス化のコールバック保持
        self._edit_orig_proc = 0
        global _class_counter
        _class_counter += 1
        self._class_name = (f"KoeTypeFixEditor{os.getpid():x}"
                            f"{_class_counter:x}")

    # ------------------------------------------------------------ 開く

    def run(self) -> FixResult | None:
        scale = _ui_scale()
        width = int(680 * scale)
        height = int(500 * scale)

        wc = _WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(_WNDCLASSEXW)
        wc.style = 0x0002 | 0x0001
        wc.lpfnWndProc = ctypes.cast(_static_proc, ctypes.c_void_p)
        wc.hInstance = kernel32.GetModuleHandleW(None)
        wc.hCursor = user32.LoadCursorW(
            None, ctypes.cast(32512, wintypes.LPCWSTR))
        wc.hbrBackground = ctypes.c_void_p(5 + 1)   # COLOR_WINDOW
        wc.lpszClassName = self._class_name
        if not user32.RegisterClassExW(ctypes.byref(wc)):
            log.warning("直し窓のクラスを登録できませんでした")
            return None
        try:
            x, y = self._place(width, height)
            hwnd = user32.CreateWindowExW(
                WS_EX_TOPMOST | WS_EX_TOOLWINDOW, self._class_name,
                self.title, WS_POPUP | WS_BORDER | WS_VISIBLE,
                x, y, width, height, 0, 0,
                kernel32.GetModuleHandleW(None), None)
            if not hwnd:
                log.warning("直し窓を作れませんでした")
                return None
            self._hwnd = hwnd
            self._build(scale, width, height)
            user32.ShowWindow(hwnd, SW_SHOW)
            user32.SetForegroundWindow(hwnd)
            if self._edit:
                user32.SetFocus(self._edit)
            self._refresh_highlights(force=True)
            self._refresh_candidates(force=True)

            msg = _MSG()
            while user32.GetMessageW(ctypes.byref(msg), 0, 0, 0) > 0:
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            return self.result
        finally:
            if self._edit and self._edit_orig_proc:
                user32.SetWindowLongPtrW(self._edit, GWLP_WNDPROC,
                                         self._edit_orig_proc)
                self._edit_orig_proc = 0
            if self._font:
                gdi32.DeleteObject(self._font)
                self._font = 0
            user32.UnregisterClassW(self._class_name,
                                    kernel32.GetModuleHandleW(None))

    def _place(self, width: int, height: int) -> tuple[int, int]:
        pt = _POINT()
        x, y = 40, 40
        try:
            if user32.GetCursorPos(ctypes.byref(pt)):
                x, y = pt.x + 12, pt.y + 12
                mon = user32.MonitorFromPoint(pt, 2)
                info = _MONITORINFO()
                info.cbSize = ctypes.sizeof(_MONITORINFO)
                if mon and user32.GetMonitorInfoW(
                        mon, ctypes.byref(info)):
                    work = info.rcWork
                    x = max(work.left, min(x, work.right - width))
                    y = max(work.top, min(y, work.bottom - height))
        except Exception:
            log.debug("直し窓の表示位置を決められませんでした",
                      exc_info=True)
        return x, y

    # ------------------------------------------------------------ 部品

    def _child(self, cls: str, text: str, style: int, x: int, y: int,
               w: int, h: int, ident: int) -> int:
        hwnd = user32.CreateWindowExW(
            0, cls, text, WS_CHILD | WS_VISIBLE | style,
            x, y, w, h, self._hwnd, ident,
            kernel32.GetModuleHandleW(None), None)
        if hwnd and self._font:
            user32.SendMessageW(hwnd, WM_SETFONT, self._font, 1)
        return int(hwnd or 0)

    def _build(self, scale: float, width: int, height: int) -> None:
        s = scale
        self._font = gdi32.CreateFontW(
            -int(14 * s), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 0, 0,
            "Yu Gothic UI")
        pad = int(10 * s)
        title_h = int(24 * s)
        edit_h = int(150 * s)
        hint_h = int(36 * s)
        cand_label_h = int(20 * s)
        cand_h = int(118 * s)
        btn_h = int(34 * s)
        inner_w = width - pad * 2

        self._controls["title"] = self._child(
            "STATIC", self.title, 0, pad, int(6 * s), inner_w,
            title_h, 0)
        edit_class, self._rich = _edit_class()
        self._edit = self._child(
            edit_class, "", WS_TABSTOP | WS_BORDER | WS_VSCROLL
            | ES_MULTILINE | ES_AUTOVSCROLL | ES_WANTRETURN,
            pad, title_h + int(8 * s), inner_w, edit_h, _ID_EDIT)
        self._set_text(self.original)
        if self._rich:
            self._set_default_format(s)
        self._subclass_edit()
        y = title_h + int(8 * s) + edit_h + int(4 * s)
        self._controls["hint"] = self._child(
            "STATIC", t("fixwin.hint"), 0, pad, y, inner_w, hint_h, 0)
        y += hint_h
        # 学習済みの一覧（編集ビューと切り替えて使う）
        self._controls["list"] = self._child(
            "LISTBOX", "", WS_BORDER | WS_VSCROLL | LBS_NOTIFY,
            pad, title_h + int(8 * s), inner_w,
            edit_h + hint_h + cand_label_h + cand_h, _ID_LIST)
        user32.ShowWindow(self._controls["list"], SW_HIDE)
        cand_y = y
        if self.learn_enabled:
            self._controls["cand_label"] = self._child(
                "STATIC", t("fixwin.candidates"), 0, pad, cand_y,
                inner_w, cand_label_h, 0)
        self._cand_area = (pad, cand_y + cand_label_h, inner_w, cand_h)
        btn_y = height - btn_h - pad
        bw = int(132 * s)
        self._controls["save"] = self._child(
            "BUTTON", t("fixwin.save"), WS_TABSTOP, pad, btn_y,
            int(150 * s), btn_h, _ID_SAVE)
        self._controls["prev"] = self._child(
            "BUTTON", t("fixwin.prev"), WS_TABSTOP,
            pad + int(158 * s), btn_y, int(92 * s), btn_h, _ID_PREV)
        self._controls["next"] = self._child(
            "BUTTON", t("fixwin.next"), WS_TABSTOP,
            pad + int(254 * s), btn_y, int(92 * s), btn_h, _ID_NEXT)
        if self.learn_enabled:
            self._controls["learned"] = self._child(
                "BUTTON", t("fixwin.learned_view"), WS_TABSTOP,
                pad + int(350 * s), btn_y, bw, btn_h, _ID_LEARNED)
            self._controls["delete"] = self._child(
                "BUTTON", t("fixwin.delete"), WS_TABSTOP,
                pad + int(350 * s), btn_y, bw, btn_h, _ID_DELETE)
            user32.ShowWindow(self._controls["delete"], SW_HIDE)
            self._controls["back"] = self._child(
                "BUTTON", t("fixwin.back_to_edit"), WS_TABSTOP,
                pad + int(350 * s), btn_y, bw, btn_h,
                _ID_BACK)
            user32.ShowWindow(self._controls["back"], SW_HIDE)
        self._controls["cancel"] = self._child(
            "BUTTON", t("common.cancel"), WS_TABSTOP,
            width - pad - int(96 * s), btn_y, int(96 * s), btn_h,
            _ID_CANCEL)

    # ------------------------------------------------------------ 編集欄

    def _set_default_format(self, scale: float) -> None:
        fmt = _CHARFORMAT2()
        fmt.cbSize = ctypes.sizeof(_CHARFORMAT2)
        fmt.dwMask = CFM_FACE | CFM_SIZE
        fmt.szFaceName = "Yu Gothic UI"
        fmt.yHeight = int(225 * scale)          # 1/20 ポイント単位
        user32.SendMessageW(self._edit, EM_SETCHARFORMAT, SCF_ALL,
                            ctypes.byref(fmt))

    def _subclass_edit(self) -> None:
        """編集欄のキーとクリックを、候補のために横取りする。

        使うのは自分の窓のサブクラス化だけ（フックではない）。
        """
        if not self._edit:
            return

        editor = self

        def proc(hwnd: int, msg: int, wparam: int, lparam: int) -> int:
            try:
                if msg == WM_LBUTTONUP:
                    res = user32.CallWindowProcW(
                        editor._edit_orig_proc, hwnd, msg, wparam,
                        lparam)
                    editor._on_edit_click(lparam)
                    return res
                if msg == WM_KEYDOWN:
                    if editor._on_edit_key(int(wparam)):
                        return 0
                if msg == WM_DESTROY:
                    res = user32.CallWindowProcW(
                        editor._edit_orig_proc, hwnd, msg, wparam,
                        lparam)
                    editor._edit_orig_proc = 0
                    return res
            except Exception:
                log.exception("直し窓の編集欄で例外")
            return user32.CallWindowProcW(
                editor._edit_orig_proc, hwnd, msg, wparam, lparam)

        self._edit_proc_ref = WNDPROC(proc)
        self._edit_orig_proc = user32.SetWindowLongPtrW(
            self._edit, GWLP_WNDPROC,
            ctypes.cast(self._edit_proc_ref, ctypes.c_void_p))

    def _set_text(self, text: str) -> None:
        if self._edit:
            user32.SendMessageW(self._edit, WM_SETTEXT, 0,
                                text.replace("\n", "\r\n"))

    def _get_text(self) -> str:
        if not self._edit:
            return ""
        if self._rich:
            length = int(user32.SendMessageW(
                self._edit, WM_GETTEXTLENGTH, 0, 0))
            buf = ctypes.create_unicode_buffer(max(2, length + 1024))
            gte = _GETTEXTEX()
            gte.cb = ctypes.sizeof(buf)
            gte.flags = 0               # 段落は \r 1 文字で返る
            gte.codePage = 1200         # Unicode
            user32.SendMessageW(self._edit, EM_GETTEXTEX,
                                ctypes.byref(gte), buf)
            return buf.value.replace("\r\n", "\n").replace("\r", "\n")
        length = int(user32.SendMessageW(
            self._edit, WM_GETTEXTLENGTH, 0, 0))
        buf = ctypes.create_unicode_buffer(max(2, length + 2))
        user32.SendMessageW(self._edit, WM_GETTEXT, len(buf), buf)
        return buf.value.replace("\r\n", "\n")

    def _selection(self) -> tuple[int, int]:
        packed = int(user32.SendMessageW(self._edit, EM_GETSEL, 0, 0))
        return packed & 0xFFFF, (packed >> 16) & 0xFFFF

    def _select(self, start: int, end: int) -> None:
        if self._rich:
            cr = _CHARRANGE(start, end)
            user32.SendMessageW(self._edit, EM_EXSETSEL, 0,
                                ctypes.byref(cr))
        else:
            user32.SendMessageW(self._edit, EM_SETSEL, start, end)
        user32.SendMessageW(self._edit, EM_SCROLLCARET, 0, 0)

    # ------------------------------------------------------------ 色付け

    def _format_range(self, start: int, end: int, *, back: int,
                      fore: int) -> None:
        self._select(start, end)
        fmt = _CHARFORMAT2()
        fmt.cbSize = ctypes.sizeof(_CHARFORMAT2)
        fmt.dwMask = CFM_BACKCOLOR | CFM_COLOR
        fmt.crBackColor = back
        fmt.crTextColor = fore
        user32.SendMessageW(self._edit, EM_SETCHARFORMAT,
                            SCF_SELECTION, ctypes.byref(fmt))

    def _refresh_highlights(self, *, force: bool = False) -> None:
        if not self._rich or not self._edit or self._learned_view:
            return
        text = self._get_text()
        occs = homophones.find_occurrences(text, self.prefs)
        sig = tuple((o.start, o.end, o.surface) for o in occs)
        if not force and sig == self._occ_sig:
            return
        self._occ_sig = sig
        caret = self._selection()
        back_clear = int(user32.GetSysColor(COLOR_WINDOW))
        fore_clear = int(user32.GetSysColor(COLOR_WINDOWTEXT))
        self._format_range(0, len(text) + 1, back=back_clear,
                           fore=fore_clear)
        back = int(user32.GetSysColor(COLOR_HIGHLIGHT))
        fore = int(user32.GetSysColor(COLOR_HIGHLIGHTTEXT))
        for occ in occs:
            self._format_range(occ.start, occ.end, back=back, fore=fore)
        self._select(*caret)

    # ------------------------------------------------------------ 候補

    def _refresh_candidates(self, *, force: bool = False) -> None:
        if not self.learn_enabled or self._learned_view:
            return
        text = self._get_text()
        pairs = learnfix.extract_pairs(self.original, text)
        sig = tuple((p.src, p.dst) for p in pairs)
        if not force and sig == self._cand_sig:
            return
        self._cand_sig = sig
        checked = {(p.src, p.dst) for p, hwnd in
                   zip(self._cand_pairs, self._cand_boxes)
                   if int(user32.SendMessageW(hwnd, BM_GETCHECK, 0, 0))
                   == BST_CHECKED}
        for hwnd in self._cand_boxes:
            user32.DestroyWindow(hwnd)
        self._cand_boxes = []
        self._cand_pairs = pairs[:_MAX_CANDIDATES]
        x0, y0, w0, _h0 = self._cand_area
        scale = _ui_scale()
        row_h = int(22 * scale)
        col_w = w0 // 2
        for i, pair in enumerate(self._cand_pairs):
            col, row = divmod(i, 5)
            hwnd = self._child(
                "BUTTON", _escape(f"{pair.src} → {pair.dst}"),
                WS_TABSTOP | BS_AUTOCHECKBOX | BS_LEFT,
                x0 + col * col_w, y0 + row * row_h,
                col_w - int(6 * scale), row_h, _ID_CAND_BASE + i)
            if (pair.src, pair.dst) in checked:
                user32.SendMessageW(hwnd, BM_SETCHECK, BST_CHECKED, 0)
            self._cand_boxes.append(hwnd)
        label = self._controls.get("cand_label")
        if label:
            if not pairs:
                text_label = t("fixwin.candidates_none")
            elif len(pairs) > _MAX_CANDIDATES:
                text_label = (t("fixwin.candidates") + "　"
                              + t("fixwin.candidates_more",
                                  n=len(pairs) - _MAX_CANDIDATES))
            else:
                text_label = t("fixwin.candidates")
            user32.SendMessageW(label, WM_SETTEXT, 0, text_label)

    def _approved_pairs(self) -> list[tuple[str, str]]:
        out: list[tuple[str, str]] = []
        for pair, hwnd in zip(self._cand_pairs, self._cand_boxes):
            if int(user32.SendMessageW(hwnd, BM_GETCHECK, 0, 0)) \
                    == BST_CHECKED:
                out.append((pair.src, pair.dst))
        return out

    # ------------------------------------------------------- 同音異義語

    def _occurrences(self) -> list[homophones.Occurrence]:
        return homophones.find_occurrences(self._get_text(), self.prefs)

    def _on_edit_click(self, lparam: int) -> None:
        if not self._rich:
            return
        pts = _POINTS()
        pts.x = ctypes.c_short(lparam & 0xFFFF)
        pts.y = ctypes.c_short((int(lparam) >> 16) & 0xFFFF)
        index = int(user32.SendMessageW(
            self._edit, EM_CHARFROMPOS, 0, ctypes.byref(pts)))
        if index < 0:
            return
        for occ in self._occurrences():
            if occ.start <= index < occ.end:
                self._select(occ.start, occ.end)
                self._show_menu(occ)
                return

    def _on_edit_key(self, vk: int) -> bool:
        if vk == VK_ESCAPE:
            user32.PostMessageW(self._hwnd, WM_CLOSE, 0, 0)
            return True
        ctrl = bool(user32.GetAsyncKeyState(VK_CONTROL) & 0x8000)
        alt = bool(user32.GetAsyncKeyState(VK_MENU) & 0x8000)
        if ctrl and vk in (VK_DOWN, VK_UP):
            self._cycle(1 if vk == VK_DOWN else -1)
            return True
        if alt and vk == VK_RETURN:
            caret = self._selection()[0]
            for occ in self._occurrences():
                if occ.start <= caret <= occ.end:
                    self._select(occ.start, occ.end)
                    self._show_menu(occ)
                    return True
            return False
        return False

    def _cycle(self, step: int) -> None:
        occs = self._occurrences()
        if not occs:
            return
        caret = self._selection()[0]
        if step > 0:
            target = next((o for o in occs if o.start > caret), occs[0])
        else:
            target = next((o for o in reversed(occs)
                           if o.start < caret), occs[-1])
        self._select(target.start, target.end)
        user32.SetFocus(self._edit)

    def _show_menu(self, occ: homophones.Occurrence) -> None:
        """候補メニューを出し、選ばれたらその出現だけ差し替える。"""
        menu = user32.CreatePopupMenu()
        try:
            for i, cand in enumerate(occ.candidates):
                flags = MF_STRING | (MF_CHECKED if cand == occ.surface
                                     else 0)
                user32.AppendMenuW(menu, flags, 4000 + i, cand)
            pt = _POINT()
            user32.GetCursorPos(ctypes.byref(pt))
            choice = int(user32.TrackPopupMenu(
                menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY,
                pt.x, pt.y, 0, self._hwnd, None))
        finally:
            user32.DestroyMenu(menu)
        if not choice:
            return
        picked = occ.candidates[choice - 4000]
        if picked == occ.surface:
            return
        self._select(occ.start, occ.end)
        user32.SendMessageW(self._edit, EM_REPLACESEL, 1, picked)
        self.prefs.choose(occ.reading, picked)
        self._occ_sig = ()
        self._refresh_highlights(force=True)
        user32.SetTimer(self._hwnd, _TIMER_REFRESH, 50, None)

    # ------------------------------------------------------------ 画面切替

    def _show_learned(self, show: bool) -> None:
        self._learned_view = show
        edit_side = [self._edit, self._controls.get("hint", 0),
                     self._controls.get("cand_label", 0),
                     self._controls.get("prev", 0),
                     self._controls.get("next", 0),
                     self._controls.get("learned", 0)]
        for hwnd in edit_side:
            if hwnd:
                user32.ShowWindow(hwnd, SW_HIDE if show else SW_SHOW)
        for hwnd in self._cand_boxes:
            user32.ShowWindow(hwnd, SW_HIDE if show else SW_SHOW)
        for key in ("list", "delete", "back"):
            hwnd = self._controls.get(key, 0)
            if hwnd:
                user32.ShowWindow(hwnd, SW_SHOW if show else SW_HIDE)
        if show:
            self._reload_learned_list()
        else:
            self._occ_sig = ()
            self._refresh_highlights(force=True)
            self._cand_sig = ()
            self._refresh_candidates(force=True)

    def _reload_learned_list(self) -> None:
        lst = self._controls.get("list", 0)
        if not lst:
            return
        user32.SendMessageW(lst, LB_RESETCONTENT, 0, 0)
        self._learned_rows = list(self.store.pairs())
        for src, dst in self._learned_rows:
            user32.SendMessageW(lst, LB_ADDSTRING, 0, f"{src} → {dst}")
        if not self._learned_rows:
            user32.SendMessageW(lst, LB_ADDSTRING, 0,
                                t("fixwin.empty_learned"))

    # ------------------------------------------------------------ 終わり

    def _finish(self, result: FixResult | None) -> None:
        if self._done:
            return
        self._done = True
        self.result = result
        if self._hwnd:
            user32.DestroyWindow(self._hwnd)

    def _save(self) -> None:
        self._finish(FixResult(text=self._get_text(),
                               pairs=self._approved_pairs()))

    # ------------------------------------------------------------ 本体

    def _proc(self, hwnd: int, msg: int, wparam: int,
              lparam: int) -> int:
        try:
            if msg == WM_COMMAND:
                code = (int(wparam) >> 16) & 0xFFFF
                ident = int(wparam) & 0xFFFF
                if code == EN_CHANGE and int(lparam) == self._edit:
                    user32.SetTimer(self._hwnd, _TIMER_REFRESH, 600,
                                    None)
                    return 0
                if code == BN_CLICKED:
                    if ident == _ID_SAVE:
                        self._save()
                    elif ident == _ID_CANCEL:
                        self._finish(None)
                    elif ident == _ID_LEARNED:
                        self._show_learned(True)
                    elif ident == _ID_BACK:
                        self._show_learned(False)
                    elif ident == _ID_DELETE:
                        self._delete_selected()
                    elif ident == _ID_PREV:
                        self._cycle(-1)
                    elif ident == _ID_NEXT:
                        self._cycle(1)
                    return 0
                return 0
            if msg == WM_TIMER and int(wparam) == _TIMER_REFRESH:
                user32.KillTimer(self._hwnd, _TIMER_REFRESH)
                self._refresh_highlights()
                self._refresh_candidates()
                return 0
            if msg == WM_CLOSE:
                self._finish(None)
                return 0
            if msg == WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0
        except Exception:
            log.exception("直し窓の処理で例外")
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _delete_selected(self) -> None:
        lst = self._controls.get("list", 0)
        if not lst:
            return
        sel = int(user32.SendMessageW(lst, LB_GETCURSEL, 0, 0))
        rows = getattr(self, "_learned_rows", [])
        if sel == LB_ERR or sel >= len(rows):
            return
        src, dst = rows[sel]
        if self.store.remove(src, dst):
            log.info("学習ペアを削除しました: %s -> %s", src, dst)
        self._cand_sig = ()
        self._reload_learned_list()


def open_editor(original: str, title: str, *,
                store: learnfix.LearnStore,
                prefs: homophones.Prefs,
                learn_enabled: bool = True) -> FixResult | None:
    """編集ポップアップを開き、保存結果を返す（やめたら None）。

    呼んだスレッドでメッセージループを回すので、専用スレッド
    から呼ぶこと。同時に 2 つは開かない。から打ち（テスト）
    では窓を一切開かず None を返す。
    """
    global _active
    if dryrun.enabled():
        log.info("から打ちのため直し窓は開きません")
        return None
    if not _open_lock.acquire(blocking=False):
        log.info("直し窓はすでに開いています")
        return None
    try:
        editor = _Editor(original, title, store, prefs,
                         learn_enabled=learn_enabled)
        _active = editor
        try:
            return editor.run()
        finally:
            _active = None
    finally:
        _open_lock.release()
