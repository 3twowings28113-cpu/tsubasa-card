"""カーソルのある入力欄へ文字を入れる。

日本語IMEがオンでも崩れないよう、クリップボード経由で貼り付ける。
貼ったあとは元のクリップボードの中身を戻す。

確実に入れるための決まり
  ・押されている修飾キーが離れるのを待ってから貼る
  ・クリップボードが**本当に変わったこと**を確かめてからキーを送る
  ・相手が読み終わるのを待ってから元に戻す
  ・入れる先の窓が変わっていたら**貼らずにコピーだけ**して知らせる
  ・ターミナルでは Ctrl+Shift+V に切り替える
  ・Win+V の履歴に断片を残さない

`KOE_TYPE_DRY_RUN=1` のときは、SendInput もクリップボードの書き換えも
**1回も行わず**、何をするはずだったかを記録するだけにする。
"""

from __future__ import annotations

import collections
import ctypes
import logging
import time
from ctypes import wintypes

from . import dryrun

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)

CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
GMEM_INVALID_HANDLE = 0x8000

# GDI のハンドルで持つ形式。メモリブロックではないので、
# GlobalSize / GlobalLock を使ってはいけない（ヒープが壊れて即死する）。
GDI_FORMATS = {
    2,      # CF_BITMAP
    3,      # CF_METAFILEPICT
    9,      # CF_PALETTE
    14,     # CF_ENHMETAFILE
    0x80,   # CF_OWNERDISPLAY
    0x82,   # CF_DSPBITMAP
    0x83,   # CF_DSPMETAFILEPICT
    0x8E,   # CF_DSPENHMETAFILE
}

# クリップボード履歴（Win+V）とクラウド同期に、貼り付け用の断片を残さないための印。
HISTORY_FORMATS = (
    "CanIncludeInClipboardHistory",          # DWORD 0 で履歴に入れない
    "CanUploadToCloudClipboard",             # DWORD 0 でクラウドへ送らない
)
MONITOR_FORMAT = "ExcludeClipboardContentFromMonitorProcessing"

VK_CONTROL = 0x11
VK_SHIFT = 0x10
VK_MENU = 0x12
VK_LWIN = 0x5B
VK_RWIN = 0x5C
VK_RETURN = 0x0D
VK_V = 0x56

INPUT_KEYBOARD = 1
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002
KEYEVENTF_UNICODE = 0x0004

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
TOKEN_QUERY = 0x0008

# ターミナルの窓。ここでは Ctrl+V が「貼り付け」ではないことがある。
TERMINAL_CLASSES = {
    "CASCADIA_HOSTING_WINDOW_CLASS",   # Windows Terminal
    "ConsoleWindowClass",              # conhost（cmd / PowerShell）
    "PuTTY", "mintty", "VirtualConsoleClass",
}
TERMINAL_EXES = {
    "windowsterminal.exe", "wt.exe", "conhost.exe", "cmd.exe",
    "powershell.exe", "pwsh.exe", "mintty.exe", "putty.exe", "alacritty.exe",
}


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [
        ("wVk", wintypes.WORD),
        ("wScan", wintypes.WORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("ki", KEYBDINPUT), ("pad", ctypes.c_byte * 32)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wintypes.DWORD), ("u", _INPUTUNION)]


user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
user32.SendInput.restype = wintypes.UINT

# 64bit ではハンドルが 32bit に収まらないので、必ず argtypes を指定する
kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
kernel32.GlobalAlloc.restype = ctypes.c_void_p
kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
kernel32.GlobalLock.restype = ctypes.c_void_p
kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
kernel32.GlobalUnlock.restype = wintypes.BOOL
kernel32.GlobalFree.argtypes = [ctypes.c_void_p]
kernel32.GlobalFree.restype = ctypes.c_void_p
kernel32.GlobalSize.argtypes = [ctypes.c_void_p]
kernel32.GlobalSize.restype = ctypes.c_size_t
kernel32.GlobalFlags.argtypes = [ctypes.c_void_p]
kernel32.GlobalFlags.restype = wintypes.UINT
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.GetCurrentProcess.restype = wintypes.HANDLE
kernel32.QueryFullProcessImageNameW.argtypes = [
    wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
    ctypes.POINTER(wintypes.DWORD)]
user32.GetClipboardData.argtypes = [wintypes.UINT]
user32.GetClipboardData.restype = ctypes.c_void_p
user32.SetClipboardData.argtypes = [wintypes.UINT, ctypes.c_void_p]
user32.SetClipboardData.restype = ctypes.c_void_p
user32.OpenClipboard.argtypes = [wintypes.HWND]
user32.OpenClipboard.restype = wintypes.BOOL
user32.EnumClipboardFormats.argtypes = [wintypes.UINT]
user32.EnumClipboardFormats.restype = wintypes.UINT
user32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
user32.RegisterClipboardFormatW.restype = wintypes.UINT
user32.GetClipboardSequenceNumber.restype = wintypes.DWORD
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                            ctypes.POINTER(wintypes.DWORD)]
advapi32.OpenProcessToken.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                      ctypes.POINTER(wintypes.HANDLE)]
advapi32.GetTokenInformation.argtypes = [wintypes.HANDLE, ctypes.c_int,
                                         ctypes.c_void_p, wintypes.DWORD,
                                         ctypes.POINTER(wintypes.DWORD)]


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class GUITHREADINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("hwndActive", wintypes.HWND),
        ("hwndFocus", wintypes.HWND),
        ("hwndCapture", wintypes.HWND),
        ("hwndMenuOwner", wintypes.HWND),
        ("hwndMoveSize", wintypes.HWND),
        ("hwndCaret", wintypes.HWND),
        ("rcCaret", RECT),
    ]


user32.GetGUIThreadInfo.argtypes = [wintypes.DWORD, ctypes.POINTER(GUITHREADINFO)]
user32.GetGUIThreadInfo.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.SetForegroundWindow.restype = wintypes.BOOL
user32.BringWindowToTop.argtypes = [wintypes.HWND]
user32.BringWindowToTop.restype = wintypes.BOOL
user32.SetFocus.argtypes = [wintypes.HWND]
user32.SetFocus.restype = wintypes.HWND
user32.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
user32.AttachThreadInput.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.ShowWindow.restype = wintypes.BOOL
user32.IsIconic.argtypes = [wintypes.HWND]
user32.IsIconic.restype = wintypes.BOOL
user32.IsWindow.argtypes = [wintypes.HWND]
user32.IsWindow.restype = wintypes.BOOL
kernel32.GetCurrentThreadId.restype = wintypes.DWORD


def get_focus_control(target_window: int = 0) -> int:
    """target_window のスレッドでフォーカスを持っているコントロールを返す。"""
    if not target_window or dryrun.enabled():
        return 0
    tid = user32.GetWindowThreadProcessId(target_window, None)
    if not tid:
        return 0
    info = GUITHREADINFO()
    info.cbSize = ctypes.sizeof(GUITHREADINFO)
    if user32.GetGUIThreadInfo(tid, ctypes.byref(info)):
        return int(info.hwndFocus or info.hwndCaret or 0)
    return 0


def activate_window(hwnd: int, focus_ctrl: int = 0) -> bool:
    """指定したウィンドウを安全にフォアグラウンドへ復帰させ、フォーカスを戻す。"""
    if not hwnd:
        return False
    if dryrun.enabled():
        dryrun.record("activate", target_hwnd=hwnd, focus_ctrl=focus_ctrl)
        return True
    if not user32.IsWindow(hwnd):
        return False

    # 最小化されていたら元の大きさに戻す
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE

    cur_fg = user32.GetForegroundWindow()
    if cur_fg == hwnd:
        if focus_ctrl and user32.IsWindow(focus_ctrl):
            user32.SetFocus(focus_ctrl)
        return True

    cur_tid = user32.GetWindowThreadProcessId(cur_fg, None) if cur_fg else 0
    my_tid = kernel32.GetCurrentThreadId()

    attached = False
    if cur_tid and cur_tid != my_tid:
        attached = bool(user32.AttachThreadInput(my_tid, cur_tid, True))

    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
        if focus_ctrl and user32.IsWindow(focus_ctrl):
            user32.SetFocus(focus_ctrl)
    finally:
        if attached:
            user32.AttachThreadInput(my_tid, cur_tid, False)

    time.sleep(0.03)
    now_fg = user32.GetForegroundWindow()
    return now_fg == hwnd


# このアプリが起こしたキー入力を自前のフックで無視するための目印
MARKER = 0x4B4F4554  # "KOET"

# 貼り付けの結果
PASTED = "pasted"
COPIED = "copied"
FAILED = "failed"



# ---------------------------------------------------------------- キー送信


def _send(*keys: tuple[int, bool]) -> None:
    """(仮想キーコード, 離すかどうか) を並べて一度に送る。"""
    if dryrun.enabled():
        dryrun.record("keys", keys=[[vk, up] for vk, up in keys])
        return
    arr = (INPUT * len(keys))()
    extra = ctypes.pointer(wintypes.ULONG(MARKER))
    for i, (vk, up) in enumerate(keys):
        flags = KEYEVENTF_KEYUP if up else 0
        if vk in (VK_RWIN, 0x2D, 0x2E, 0x24, 0x23, 0x21, 0x22,
                  0x25, 0x26, 0x27, 0x28):
            flags |= KEYEVENTF_EXTENDEDKEY
        arr[i].type = INPUT_KEYBOARD
        arr[i].ki = KEYBDINPUT(wVk=vk, wScan=0, dwFlags=flags, time=0,
                               dwExtraInfo=extra)
    sent = user32.SendInput(len(keys), arr, ctypes.sizeof(INPUT))
    if sent != len(keys):
        log.warning("SendInput が %d/%d しか送れませんでした (err=%s)",
                    sent, len(keys), ctypes.get_last_error())


def wait_modifiers_released(timeout_ms: int) -> bool:
    """Ctrl 等が押されたままだと貼り付けが壊れるので、離すまで待つ。"""
    if dryrun.enabled():
        return True
    deadline = time.monotonic() + timeout_ms / 1000.0
    watched = (VK_CONTROL, VK_SHIFT, VK_MENU, VK_LWIN, VK_RWIN)
    while time.monotonic() < deadline:
        if not any(user32.GetAsyncKeyState(vk) & 0x8000 for vk in watched):
            return True
        time.sleep(0.02)
    log.debug("修飾キーが押されたままですが待機を打ち切ります")
    return False


# ---------------------------------------------------------------- 相手の窓


def foreground() -> int:
    return int(user32.GetForegroundWindow() or 0)


def window_class(hwnd: int) -> str:
    buf = ctypes.create_unicode_buffer(128)
    user32.GetClassNameW(hwnd, buf, 128)
    return buf.value


def window_exe(hwnd: int) -> str:
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value:
        return ""
    handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False,
                                  pid.value)
    if not handle:
        return ""
    try:
        size = wintypes.DWORD(260)
        buf = ctypes.create_unicode_buffer(size.value)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf,
                                               ctypes.byref(size)):
            val = buf.value
            return val.replace("/", "\\").rsplit("\\", 1)[-1] if val else ""
    finally:
        kernel32.CloseHandle(handle)
    return ""


def is_terminal(hwnd: int) -> bool:
    """ターミナルの窓か。Ctrl+V が効かないことがあるので見分ける。"""
    if not hwnd:
        return False
    if window_class(hwnd) in TERMINAL_CLASSES:
        return True
    return window_exe(hwnd).lower() in TERMINAL_EXES


def is_elevated_window(hwnd: int) -> bool:
    """相手が自分より強い権限で動いていないか。

    管理者として動いているアプリには、ふつうのアプリからキーを送れない
    （Windows が黙って捨てるので、文字が入らず消える）。
    その時は貼らずにコピーへ切り替える。

    見分け方：相手のトークンを TOKEN_QUERY で開けるかどうかを見る。
    同じか下の権限なら開ける。上の権限だと「アクセスが拒否されました」
    になる。SID の中身を自分で読み解くより、こちらのほうが安全。
    """
    if not hwnd:
        return False
    try:
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return False
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False,
                                      pid.value)
        if not handle:
            # そもそも開けない＝たいてい権限が上。安全側に倒す。
            log.debug("相手のプロセスを開けません pid=%d", pid.value)
            return True
        token = wintypes.HANDLE()
        try:
            if advapi32.OpenProcessToken(handle, TOKEN_QUERY,
                                         ctypes.byref(token)):
                kernel32.CloseHandle(token)
                return False
            err = ctypes.get_last_error()
            if err == 5:        # ERROR_ACCESS_DENIED
                log.debug("相手のほうが権限が上です pid=%d", pid.value)
                return True
            return False
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        log.debug("権限を調べられませんでした", exc_info=True)
        return False


# ---------------------------------------------------------------- クリップボード


def _open_clipboard(retries: int = 25) -> bool:
    for _ in range(retries):
        if user32.OpenClipboard(None):
            return True
        time.sleep(0.02)
    log.warning("クリップボードを開けませんでした")
    return False


def snapshot_clipboard() -> list[tuple[int, bytes]] | None:
    """メモリ形式のクリップボード内容を控える。失敗したら None。

    **メモリブロック（HGLOBAL）で持っている形式だけを控える。**
    画像（CF_BITMAP）やメタファイルは GDI のハンドルであって
    メモリブロックではない。これに GlobalSize / GlobalLock を使うと
    でたらめな大きさが返り、ヒープを壊してプロセスが即死する
    （STATUS_HEAP_CORRUPTION）。利用者が画像をコピーしているだけで
    音声入力のたびにアプリが落ちていたので、ここで必ず見分ける。
    """
    if not _open_clipboard():
        return None
    saved: list[tuple[int, bytes]] = []
    skipped: list[int] = []
    try:
        fmt = 0
        while True:
            fmt = user32.EnumClipboardFormats(fmt)
            if not fmt:
                break
            if fmt in GDI_FORMATS:
                skipped.append(fmt)
                continue
            handle = user32.GetClipboardData(fmt)
            if not handle:
                continue
            # GlobalFlags は、メモリブロックでないハンドルには
            # GMEM_INVALID_HANDLE を返す。触る前にこれで確かめる。
            flags = kernel32.GlobalFlags(handle)
            if flags == GMEM_INVALID_HANDLE:
                skipped.append(fmt)
                continue
            try:
                size = kernel32.GlobalSize(handle)
                if not size or size > 32 * 1024 * 1024:
                    skipped.append(fmt)
                    continue
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    continue
                try:
                    saved.append((fmt, ctypes.string_at(ptr, size)))
                finally:
                    kernel32.GlobalUnlock(handle)
            except Exception:
                log.debug("形式 %d は控えられませんでした", fmt)
                continue
    finally:
        user32.CloseClipboard()
    if skipped:
        log.info("クリップボードの %d 個の形式（画像など）は戻せません: %s",
                 len(skipped), skipped)
    return saved


_dryrun_clipboard: str = ""


def clipboard_text() -> str:
    """いまクリップボードにある文字。なければ空。"""
    if dryrun.enabled():
        return _dryrun_clipboard
    if not _open_clipboard(5):
        return ""
    try:
        handle = user32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return ""
        ptr = kernel32.GlobalLock(handle)
        if not ptr:
            return ""
        try:
            size = kernel32.GlobalSize(handle)
            raw = ctypes.string_at(ptr, size)
            return raw.decode("utf-16-le", "replace").rstrip("\x00")
        finally:
            kernel32.GlobalUnlock(handle)
    finally:
        user32.CloseClipboard()


def _put(items: list[tuple[int, bytes]]) -> bool:
    if not _open_clipboard():
        return False
    try:
        user32.EmptyClipboard()
        for fmt, data in items:
            handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data) or 1)
            if not handle:
                continue
            ptr = kernel32.GlobalLock(handle)
            if not ptr:
                kernel32.GlobalFree(handle)
                continue
            ctypes.memmove(ptr, data, len(data))
            kernel32.GlobalUnlock(handle)
            if not user32.SetClipboardData(fmt, handle):
                kernel32.GlobalFree(handle)
        return True
    finally:
        user32.CloseClipboard()


# koe-type 自身が「一時的に」書いたクリップボードの番号。
# 音声入力は、貼るために文字を置き、貼ったあと元の中身へ戻す。
# クリップボード履歴（app/clipwin.py）がこれを「新しいコピー」と
# 取り違えないように、戻したときの番号を覚えておく。
_own_seqs: collections.deque[int] = collections.deque(maxlen=32)


def note_own_write() -> None:
    try:
        _own_seqs.append(int(user32.GetClipboardSequenceNumber()))
    except Exception:
        pass


def is_own_sequence(seq: int) -> bool:
    return bool(seq) and seq in _own_seqs


_history_marks: list[tuple[int, bytes]] | None = None


def _no_history_marks() -> list[tuple[int, bytes]]:
    """クリップボード履歴に残さないための、おまけの形式一式。"""
    global _history_marks
    if _history_marks is None:
        marks: list[tuple[int, bytes]] = []
        for name in HISTORY_FORMATS:
            fmt = user32.RegisterClipboardFormatW(name)
            if fmt:
                marks.append((fmt, (0).to_bytes(4, "little")))
        fmt = user32.RegisterClipboardFormatW(MONITOR_FORMAT)
        if fmt:
            marks.append((fmt, b"\x00"))
        _history_marks = marks
    return _history_marks


def set_clipboard_text(text: str, *, keep_out_of_history: bool = True) -> bool:
    """クリップボードに文字を置き、**本当に入ったか確かめる**。"""
    global _dryrun_clipboard
    if dryrun.enabled():
        _dryrun_clipboard = text
        dryrun.record("clipboard", text=text, history=not keep_out_of_history)
        return True
    data = text.encode("utf-16-le") + b"\x00\x00"
    items = [(CF_UNICODETEXT, data)]
    if keep_out_of_history:
        items += _no_history_marks()
    for attempt in range(3):
        if _put(items) and clipboard_text() == text:
            if keep_out_of_history:
                note_own_write()
            return True
        time.sleep(0.03 * (attempt + 1))
    log.warning("クリップボードに文字を置けませんでした")
    return False


def restore_clipboard(saved: list[tuple[int, bytes]] | None) -> None:
    """控えておいた中身に戻す。元の中身なので履歴よけは付けない。"""
    if saved is None or dryrun.enabled():
        return
    if not saved:
        if _open_clipboard():
            try:
                user32.EmptyClipboard()
            finally:
                user32.CloseClipboard()
            note_own_write()
        return
    _put(saved)
    note_own_write()


# ---------------------------------------------------------------- 入力


def type_text(text: str, *, target_hwnd: int = 0,
              target_focus: int = 0, restore_target: bool = True,
              char_delay_ms: int = 0,
              abort=None) -> str:  # noqa: ANN001
    """クリップボードを一切使わず、SendInput の UNICODE で直接入力する。

    戻り値は PASTED / FAILED。
    """
    if not text:
        return PASTED
    if dryrun.enabled():
        dryrun.record("type", text=text, target_hwnd=target_hwnd)
        return PASTED

    if target_hwnd and foreground() not in (0, target_hwnd):
        if restore_target and activate_window(target_hwnd, target_focus):
            log.info("直接入力の前に元のウィンドウへフォーカスを復帰しました")
        else:
            log.warning("直接入力の前に前面ウィンドウが変わっていたため中断します")
            return FAILED

    utf16_bytes = text.encode("utf-16-le")
    units = [int.from_bytes(utf16_bytes[i:i + 2], "little")
             for i in range(0, len(utf16_bytes), 2)]

    extra = ctypes.pointer(wintypes.ULONG(MARKER))
    delay = max(0, char_delay_ms) / 1000.0

    for code in units:
        if abort is not None and abort():
            log.info("直接入力の途中で中止されたので中断します")
            return PASTED
        if target_hwnd and foreground() not in (0, target_hwnd):
            log.warning("直接入力中に前面ウィンドウが変わったため中断します")
            return FAILED
        arr = (INPUT * 2)()
        arr[0].type = INPUT_KEYBOARD
        arr[0].ki = KEYBDINPUT(wVk=0, wScan=code,
                               dwFlags=KEYEVENTF_UNICODE,
                               time=0, dwExtraInfo=extra)
        arr[1].type = INPUT_KEYBOARD
        arr[1].ki = KEYBDINPUT(wVk=0, wScan=code,
                               dwFlags=KEYEVENTF_UNICODE | KEYEVENTF_KEYUP,
                               time=0, dwExtraInfo=extra)
        sent = user32.SendInput(2, arr, ctypes.sizeof(INPUT))
        if sent != 2:
            log.warning("SendInput(UNICODE) 送信失敗: sent=%d err=%s",
                        sent, ctypes.get_last_error())
        if delay > 0:
            time.sleep(delay)
    return PASTED


def paste_text(text: str, *, paste_delay_ms: int = 70,
               restore_delay_ms: int = 250, modifier_timeout_ms: int = 900,
               target_hwnd: int = 0, target_focus: int = 0,
               restore_target: bool = True, method: str = "auto",
               copy_on_fallback: bool = True,
               abort=None) -> str:  # noqa: ANN001
    """text を入力欄へ入れる。戻り値は PASTED / COPIED / FAILED。

    target_hwnd を渡すと、その窓が前面にある時だけ貼る。
    restore_target が True のとき、別の窓に移っていても元の窓を
    前面へ復帰させてから貼り付ける（スクロールやよそ見の誤爆防止）。
    copy_on_fallback が False のときはクリップボードに置かず失敗とする。
    method が "direct" のときはクリップボードを使わず直接キー入力する。
    """
    if not text:
        return PASTED

    wait_modifiers_released(modifier_timeout_ms)
    if abort is not None and abort():
        log.info("貼り付け直前に中止されたので入力しません")
        return PASTED

    now = foreground()
    reason = ""
    if target_hwnd and now and now != target_hwnd:
        if restore_target and activate_window(target_hwnd, target_focus):
            now = foreground()
            log.info("元の入力先ウィンドウへフォーカスを復帰しました (hwnd=%s)",
                     target_hwnd)
        else:
            reason = "window_changed"
    elif is_elevated_window(now):
        reason = "elevated"

    if reason:
        if copy_on_fallback:
            ok = set_clipboard_text(text, keep_out_of_history=False)
            dryrun.record("copy", text=text, reason=reason)
            log.info("入れる先が変わった（%s）ので、貼らずにコピーしました",
                     reason)
            return COPIED if ok else FAILED
        dryrun.record("copy", text=text, reason=reason, skipped=True)
        log.info("入れる先が変わった（%s）がクリップボード保存無効のためコピーしません",
                 reason)
        return FAILED

    # 同じウィンドウ内等で入力欄からフォーカスが外れていた場合、フォーカスを復帰
    if target_focus and not dryrun.enabled():
        try:
            if user32.IsWindow(target_focus):
                user32.SetFocus(target_focus)
        except Exception:
            pass

    if method == "direct":
        return type_text(text, target_hwnd=target_hwnd,
                         target_focus=target_focus,
                         restore_target=restore_target, abort=abort)

    saved = snapshot_clipboard()
    if not set_clipboard_text(text):
        return FAILED
    try:
        if abort is not None and abort():
            log.info("貼り付け直前に中止されたので入力しません")
            return PASTED
        if target_hwnd and foreground() not in (0, target_hwnd):
            if copy_on_fallback:
                dryrun.record("copy", text=text, reason="window_changed_late")
                log.info("直前に窓が変わったので貼りません（コピー済み）")
                return COPIED
            dryrun.record("copy", text=text, reason="window_changed_late",
                          skipped=True)
            log.info("直前に窓が変わったので貼りません（クリップボード保存無効）")
            return FAILED
        keys = _paste_keys(method, now)
        dryrun.record("paste", text=text, method=keys[0])
        _send(*keys[1])

        time.sleep(max(0, paste_delay_ms) / 1000.0)
        return PASTED
    finally:
        time.sleep(max(0, restore_delay_ms) / 1000.0)
        try:
            restore_clipboard(saved)
        except Exception:
            log.exception("クリップボードを戻せませんでした")


def send_paste(hwnd: int, method: str = "auto") -> str:
    """いまのクリップボードを貼るキーだけを送る（クリップボード履歴用）。

    ターミナルでは Ctrl+Shift+V にする。戻り値は使ったキーの名前。
    から打ちモードでは送らずに記録だけする（_send の中で）。
    """
    keys = _paste_keys(method, hwnd)
    dryrun.record("paste_keys", method=keys[0], source="clip")
    _send(*keys[1])
    return keys[0]


def _paste_keys(method: str, hwnd: int):  # noqa: ANN202
    """貼り付けに使うキーを選ぶ。"""
    method = (method or "auto").lower()
    if method == "auto":
        method = "ctrl_shift_v" if is_terminal(hwnd) else "ctrl_v"
    if method == "ctrl_shift_v":
        return ("ctrl_shift_v", ((VK_CONTROL, False), (VK_SHIFT, False),
                                 (VK_V, False), (VK_V, True),
                                 (VK_SHIFT, True), (VK_CONTROL, True)))
    if method == "shift_insert":
        return ("shift_insert", ((VK_SHIFT, False), (0x2D, False),
                                 (0x2D, True), (VK_SHIFT, True)))
    return ("ctrl_v", ((VK_CONTROL, False), (VK_V, False),
                       (VK_V, True), (VK_CONTROL, True)))


SEND_KEYS = {
    "enter": ((VK_RETURN, False), (VK_RETURN, True)),
    "ctrl+enter": ((VK_CONTROL, False), (VK_RETURN, False),
                   (VK_RETURN, True), (VK_CONTROL, True)),
    "shift+enter": ((VK_SHIFT, False), (VK_RETURN, False),
                    (VK_RETURN, True), (VK_SHIFT, True)),
}


def send_submit(spec: str = "enter") -> None:
    """入力し終わってから「送信」のキーを送る。"""
    keys = SEND_KEYS.get(str(spec).lower().replace(" ", ""))
    if keys is None:
        log.warning("送信キー '%s' が分からないので Enter を送ります", spec)
        keys = SEND_KEYS["enter"]
    wait_modifiers_released(400)
    dryrun.record("submit", key=spec)
    _send(*keys)


VK_BACK = 0x08


def send_backspaces(count: int, *, target_hwnd: int = 0,
                    modifier_timeout_ms: int = 900) -> bool:
    """直前の文字を取り消すため Backspace を count 回送る。

    target_hwnd が指定されている場合、その窓が前面にあるときだけ送る。
    別の窓に移っていたら絶対にキーを送らない（安全弁）。
    """
    if count <= 0:
        return False
    wait_modifiers_released(modifier_timeout_ms)
    now = foreground()
    if target_hwnd and now and now != target_hwnd:
        log.warning("取り消し先の窓が変わった（%s != %s）ので中止します",
                    now, target_hwnd)
        return False
    if is_elevated_window(now):
        log.warning("管理者権限の窓なので取り消しキーを送れません")
        return False

    if dryrun.enabled():
        dryrun.record("backspace", count=count, target_hwnd=target_hwnd)
        return True

    keys: list[tuple[int, bool]] = []
    for _ in range(count):
        keys.append((VK_BACK, False))
        keys.append((VK_BACK, True))
    _send(*keys)
    return True
