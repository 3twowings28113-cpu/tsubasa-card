"""Win32 のメッセージループを持つスレッド。

ここで
  ・低レベルキーボードフック（ホットキー / 録音中の Enter・キャンセルキーの横取り）
  ・タスクトレイのアイコンとメニュー
の両方を扱う。どちらもメッセージを回しているスレッドで動かす必要があるため。

フックの処理関数は素早く返さないと OS に外されるので、
判定だけしてコントローラにはコールバックで通知するだけにする。
"""

from __future__ import annotations

import ctypes
import logging
import os
import threading
import time
from ctypes import wintypes
from pathlib import Path
from typing import Callable

from . import dryrun, inputwatch
from . import hotkeys as _hotkeys
from .i18n import t
from .icons import ensure_icons
from .inject import MARKER
from .overlay import Overlay

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)

WH_KEYBOARD_LL = 13
HC_ACTION = 0
WM_KEYDOWN, WM_KEYUP = 0x0100, 0x0101
WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0104, 0x0105

WM_DESTROY = 0x0002
WM_CLOSE = 0x0010
WM_COMMAND = 0x0111
WM_RBUTTONUP = 0x0205
WM_LBUTTONDBLCLK = 0x0203
WM_USER = 0x0400
WM_TRAY = WM_USER + 20
WM_QUIT_APP = WM_USER + 21
WM_SET_ICON = WM_USER + 22
WM_SHOW_TRAY = WM_USER + 23
WM_INSTALL_MOUSE = WM_USER + 24
WM_SYNC_KEYS = WM_USER + 25
WM_VERIFY_KEYS = WM_USER + 26
WM_TIMER = 0x0113
OVERLAY_TIMER = 1
# 長押しのあいだ、キーを離したかを見るタイマー（押されたときだけ動く）
RELEASE_TIMER = 2
RELEASE_POLL_MS = 30
RELEASE_GIVE_UP_S = 600.0   # 10 分押しっぱなしは、離したとみなす
OVERLAY_INTERVAL_MS = 50
# 帯が隠れているあいだの間隔。前は帯を出していなくても 1 秒に 20 回
# 動いていた（待機中の CPU の大半。2026-10-11 に計測）。出すときは
# overlay.on_wake で、すぐ速いほうへ戻す。
OVERLAY_IDLE_MS = 500
WM_OVERLAY_WAKE = 0x0400 + 27

NIM_ADD, NIM_MODIFY, NIM_DELETE = 0x0, 0x1, 0x2
NIF_MESSAGE, NIF_ICON, NIF_TIP = 0x1, 0x2, 0x4
IMAGE_ICON = 1
LR_LOADFROMFILE = 0x0010
MF_STRING, MF_SEPARATOR, MF_CHECKED, MF_POPUP = 0x0000, 0x0800, 0x0008, 0x0010
TPM_RIGHTBUTTON, TPM_RETURNCMD = 0x0002, 0x0100

ID_SETTINGS, ID_DICT, ID_HISTORY = 1001, 1002, 1003
ID_LOG, ID_RESTART, ID_QUIT = 1004, 1005, 1006
ID_REPASTE = 1007
ID_SLOW = 1008
ID_PAUSE = 1009
ID_OVERLAY_TEXT = 1010
ID_COPY_LAST = 1011
ID_PUNCT_FEW = 1012
ID_PUNCT_NORMAL = 1013
ID_PUNCT_MANY = 1014
ID_VOICE_COMMANDS = 1015
ID_LANG_JA = 1016
ID_LANG_EN = 1017
ID_LANG_AUTO = 1018
ID_CLIP_OPEN = 1019
ID_CLIP_PAUSE = 1020
ID_RECIPE_OPEN = 1021
ID_MODEL_BASE = 1050

VK_SHIFT, VK_CONTROL, VK_MENU = 0x10, 0x11, 0x12
VK_LWIN, VK_RWIN = 0x5B, 0x5C
VK_RETURN, VK_ESCAPE = 0x0D, 0x1B

PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
SM_CXSMICON = 49
ICON_SMALL, ICON_BIG = 0, 1
WM_SETICON = 0x0080

VK_NAMES: dict[str, int] = {
    "space": 0x20, "enter": 0x0D, "return": 0x0D, "tab": 0x09, "esc": 0x1B,
    "escape": 0x1B, "backspace": 0x08, "capslock": 0x14, "insert": 0x2D,
    "delete": 0x2E, "home": 0x24, "end": 0x23, "pageup": 0x21,
    "pagedown": 0x22, "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28,
    "`": 0xC0, "-": 0xBD, "=": 0xBB, "[": 0xDB, "]": 0xDD, "\\": 0xDC,
    ";": 0xBA, "'": 0xDE, ",": 0xBC, ".": 0xBE, "/": 0xBF,
}
for _i in range(1, 25):
    VK_NAMES[f"f{_i}"] = 0x6F + _i
for _c in "0123456789":
    VK_NAMES[_c] = ord(_c)
for _c in "abcdefghijklmnopqrstuvwxyz":
    VK_NAMES[_c] = ord(_c.upper())
# ★無変換・変換などの日本語キーボードのキー。設定画面のおすすめボタン
# （「無変換（親指ワンタッチ）」）で選べるのに、ここが知らなかったため、
# 選んでも黙って Ctrl+Space に戻っていた（2026-10-11 発覚）。
for _name, (_vk, _ja, _en) in _hotkeys.SPECIAL_KEYS.items():
    VK_NAMES.setdefault(_name, _vk)

MOD_NAMES = {"ctrl": "ctrl", "control": "ctrl", "shift": "shift",
             "alt": "alt", "win": "win", "meta": "win", "super": "win"}


def parse_hotkey(spec: str, fallback: str = "ctrl+space"
                 ) -> tuple[int, frozenset[str]]:
    mods: set[str] = set()
    key: int | None = None
    for part in str(spec).lower().replace(" ", "").split("+"):
        if not part:
            continue
        if part in MOD_NAMES:
            mods.add(MOD_NAMES[part])
        elif part in VK_NAMES:
            key = VK_NAMES[part]
        else:
            log.warning("ホットキーの '%s' が分かりません", part)
    if key is None:
        log.warning("ホットキー '%s' を解釈できないので %s にします", spec, fallback)
        if spec != fallback:
            return parse_hotkey(fallback, fallback)
        return 0x20, frozenset({"ctrl"})
    return key, frozenset(mods)


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.c_void_p),
    ]


class NOTIFYICONDATA(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("hWnd", wintypes.HWND),
        ("uID", wintypes.UINT),
        ("uFlags", wintypes.UINT),
        ("uCallbackMessage", wintypes.UINT),
        ("hIcon", wintypes.HICON),
        ("szTip", wintypes.WCHAR * 128),
        ("dwState", wintypes.DWORD),
        ("dwStateMask", wintypes.DWORD),
        ("szInfo", wintypes.WCHAR * 256),
        ("uVersion", wintypes.UINT),
        ("szInfoTitle", wintypes.WCHAR * 64),
        ("dwInfoFlags", wintypes.DWORD),
        ("guidItem", ctypes.c_byte * 16),
        ("hBalloonIcon", wintypes.HICON),
    ]


class WNDCLASS(ctypes.Structure):
    _fields_ = [
        ("style", wintypes.UINT),
        ("lpfnWndProc", ctypes.c_void_p),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HANDLE),
        ("hbrBackground", wintypes.HANDLE),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
    ]


HOOKPROC = ctypes.CFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int, wintypes.WPARAM,
                            wintypes.LPARAM)
WNDPROC = ctypes.CFUNCTYPE(ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
                           wintypes.WPARAM, wintypes.LPARAM)

# 64bit ではハンドルが 32bit に収まらないので、使う関数すべてに argtypes を付ける。
# 付け忘れると ctypes が c_int に落として OverflowError になる。
user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE,
                                     wintypes.DWORD]
user32.SetWindowsHookExW.restype = wintypes.HHOOK
user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM,
                                  wintypes.LPARAM]
user32.CallNextHookEx.restype = ctypes.c_ssize_t
user32.DefWindowProcW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                  wintypes.LPARAM]
user32.DefWindowProcW.restype = ctypes.c_ssize_t
user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                wintypes.LPARAM]
user32.PostMessageW.restype = wintypes.BOOL
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HMENU, wintypes.HINSTANCE, ctypes.c_void_p]
user32.CreateWindowExW.restype = wintypes.HWND
user32.DestroyWindow.argtypes = [wintypes.HWND]
user32.LoadImageW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR, wintypes.UINT,
                              ctypes.c_int, ctypes.c_int, wintypes.UINT]
user32.LoadImageW.restype = wintypes.HANDLE
user32.CreatePopupMenu.restype = wintypes.HMENU
user32.AppendMenuW.argtypes = [wintypes.HMENU, wintypes.UINT, ctypes.c_size_t,
                               wintypes.LPCWSTR]
user32.DestroyMenu.argtypes = [wintypes.HMENU]
user32.TrackPopupMenu.argtypes = [wintypes.HMENU, wintypes.UINT, ctypes.c_int,
                                  ctypes.c_int, ctypes.c_int, wintypes.HWND,
                                  ctypes.c_void_p]
user32.TrackPopupMenu.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
user32.GetAsyncKeyState.restype = ctypes.c_short
user32.GetMessageW.argtypes = [ctypes.c_void_p, wintypes.HWND, wintypes.UINT,
                               wintypes.UINT]
user32.RegisterClassW.argtypes = [ctypes.c_void_p]
user32.RegisterClassW.restype = wintypes.WORD
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                            ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowThreadProcessId.restype = wintypes.DWORD
user32.GetSystemMetrics.argtypes = [ctypes.c_int]
user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
user32.IsWindowVisible.argtypes = [wintypes.HWND]
shell32.Shell_NotifyIconW.argtypes = [wintypes.DWORD, ctypes.c_void_p]
shell32.Shell_NotifyIconW.restype = wintypes.BOOL
user32.SetTimer.argtypes = [wintypes.HWND, ctypes.c_size_t, wintypes.UINT,
                            ctypes.c_void_p]
user32.SetTimer.restype = ctypes.c_size_t
user32.KillTimer.argtypes = [wintypes.HWND, ctypes.c_size_t]
user32.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                                wintypes.LPARAM]
user32.SendMessageW.restype = ctypes.c_ssize_t
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.QueryFullProcessImageNameW.argtypes = [
    wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
    ctypes.POINTER(wintypes.DWORD)]


def foreground_exe() -> str:
    """前面にあるウィンドウの実行ファイル名（例 "Code.exe"）。"""
    try:
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return ""
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return ""
        handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False,
                                      pid.value)
        if not handle:
            return ""
        try:
            size = wintypes.DWORD(260)
            buf = ctypes.create_unicode_buffer(size.value)
            if kernel32.QueryFullProcessImageNameW(handle, 0, buf,
                                                   ctypes.byref(size)):
                return Path(buf.value).name
        finally:
            kernel32.CloseHandle(handle)
    except Exception:
        log.debug("前面のアプリ名を取れませんでした", exc_info=True)
    return ""


def list_windows() -> list[dict[str, str]]:
    """いま開いている窓の [{exe, title}]。設定画面の「アプリから選ぶ」用。"""
    out: list[dict[str, str]] = []
    seen: set[str] = set()
    enum = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(hwnd, _):  # noqa: ANN001
        try:
            if not user32.IsWindowVisible(hwnd):
                return True
            length = user32.GetWindowTextLengthW(hwnd)
            if not length:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,
                                          False, pid.value)
            if not handle:
                return True
            try:
                size = wintypes.DWORD(260)
                name = ctypes.create_unicode_buffer(size.value)
                if not kernel32.QueryFullProcessImageNameW(
                        handle, 0, name, ctypes.byref(size)):
                    return True
                exe = Path(name.value).name
            finally:
                kernel32.CloseHandle(handle)
            if exe.lower() in seen or exe.lower() in (
                    "explorer.exe", "applicationframehost.exe", "msedge.exe",
                    "textinputhost.exe", "searchhost.exe", "shellexperiencehost.exe"):
                return True
            seen.add(exe.lower())
            out.append({"exe": exe, "title": buf.value[:60]})
        except Exception:
            pass
        return True

    try:
        user32.EnumWindows(enum(cb), 0)
    except Exception:
        log.debug("窓の一覧を取れませんでした", exc_info=True)
    return sorted(out, key=lambda r: r["exe"].lower())


class WinThread(threading.Thread):
    """フックとトレイを持つメッセージループ。"""

    def install_mouse(self, watch) -> None:  # noqa: ANN001
        """マウスの見張りを、このスレッドで取り付ける。

        低レベルのフックは、メッセージループを持つスレッドから
        取り付けないと呼ばれない。
        """
        self._mouse = watch
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_INSTALL_MOUSE, 0, 0)

    def is_own_window(self, hwnd: int) -> bool:
        """その窓が koe-type 自身のものか。

        録音中の表示や設定画面が前面に来たときに、
        「入力先が変わった」と誤って判定しないために使う。
        """
        if not hwnd:
            return False
        try:
            pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            return pid.value == os.getpid()
        except Exception:
            return False

    def __init__(self, *,
                 on_hotkey_down: Callable[[], None],
                 on_hotkey_up: Callable[[], None],
                 on_send: Callable[[], None],
                 on_cancel: Callable[[], None],
                 on_menu: Callable[[str], None],
                 is_recording: Callable[[], bool],
                 on_toggle_lang: Callable[[], None] | None = None,
                 on_action_down: Callable[[], None] | None = None,
                 on_assistant_down: Callable[[], None] | None = None,
                 on_fix_down: Callable[[], None] | None = None,
                 on_custom_action_down: Callable[[str], None] | None = None,
                 on_long_press: Callable[[float], None] | None = None,
                 quick_settings_fn: Callable[[], dict[str, object]] | None = None) -> None:
        super().__init__(name="win", daemon=True)
        self.icons = ensure_icons()
        self._on_hotkey_down = on_hotkey_down
        self._on_hotkey_up = on_hotkey_up
        self._on_send = on_send
        self._on_cancel = on_cancel
        self._on_menu = on_menu
        self._is_recording = is_recording
        self._on_toggle_lang = on_toggle_lang
        self._on_action_down = on_action_down
        self._on_assistant_down = on_assistant_down
        self._on_fix_down = on_fix_down
        self._on_custom_action_down = on_custom_action_down
        self._on_long_press = on_long_press
        self._long_press_notified = False
        self._quick_settings_fn = quick_settings_fn

        # 設定で変わるもの（configure() で差し替える）
        self.hotkey_vk, self.hotkey_mods = parse_hotkey("ctrl+space")
        self.cancel_vk, self.cancel_mods = parse_hotkey("esc", "esc")
        self.action_vk: int = 0
        self.action_mods: frozenset[str] = frozenset()
        self.assistant_vk: int = 0
        self.assistant_mods: frozenset[str] = frozenset()
        self.fix_vk: int = 0
        self.fix_mods: frozenset[str] = frozenset()
        self.custom_hotkeys: list[tuple[str, int, frozenset[str], int]] = []
        self.lang_vk: int = 0
        self.lang_mods: frozenset[str] = frozenset()
        self.hold_mode = False
        self.enter_sends = True
        self.excluded: set[str] = set()
        self.show_tray = True
        # 一時停止中（トレイから）。録音のショートカットを手放す。
        # 覚えておかない：起動し直したら必ずふだんに戻る。
        self.paused = False
        # 帯に話している言葉を出しているか（メニューのチェック用）
        self.overlay_text_on = True

        self._hwnd: int = 0
        self._hook: int = 0
        self._hicons: dict[str, int] = {}
        self._hotkey_held = False
        self._down_at = 0.0
        self._tray_added = False
        # ★ログオン直後の自動起動では、エクスプローラーのタスクバーが
        # まだ無く、トレイへの追加が失敗してアイコンが出ないままになった。
        # TaskbarCreated を受けたとき・追加できていないときは付け直す。
        self._taskbar_msg = 0
        self._tray_retry_at = 0.0
        self._exe_cache: tuple[int, str] = (0, "")
        self._mouse = None
        # ショートカットは RegisterHotKey で取る（低レベルのフックをやめた）
        self.keys: inputwatch.Hotkeys | None = None
        self.focus: inputwatch.FocusWatch | None = None
        self._on_focus_change = None
        self._hotkeys_dirty = True
        self._excluded_now_flag = False
        self._keys_ok = True
        self._on_keys_lost = None
        self.overlay = Overlay()
        self._ready = threading.Event()
        # ctypes のコールバックは参照を保持しないと回収されてしまう
        self._wnd_proc = WNDPROC(self._wnd_cb)

    # ------------------------------------------------------------ 設定反映

    def configure(self, *, hotkey: str, cancel_hotkey: str, hold_mode: bool,
                  enter_sends: bool, excluded: list[str], show_tray: bool,
                  lang_hotkey: str = "", action_hotkey: str = "",
                  assistant_hotkey: str = "", fix_hotkey: str = "",
                  custom_hotkeys: list[tuple[str, str]] = ()) -> None:
        self.hotkey_vk, self.hotkey_mods = parse_hotkey(hotkey)
        self.cancel_vk, self.cancel_mods = parse_hotkey(cancel_hotkey, "esc")
        if action_hotkey.strip():
            self.action_vk, self.action_mods = parse_hotkey(action_hotkey, "")
        else:
            self.action_vk, self.action_mods = 0, frozenset()
        if assistant_hotkey.strip():
            self.assistant_vk, self.assistant_mods = parse_hotkey(
                assistant_hotkey, ""
            )
        else:
            self.assistant_vk, self.assistant_mods = 0, frozenset()
        if fix_hotkey.strip():
            self.fix_vk, self.fix_mods = parse_hotkey(fix_hotkey, "")
        else:
            self.fix_vk, self.fix_mods = 0, frozenset()
        if lang_hotkey.strip():
            self.lang_vk, self.lang_mods = parse_hotkey(lang_hotkey, "")
        else:
            self.lang_vk, self.lang_mods = 0, frozenset()

        # カスタム指示ごとの個別ショートカット
        self.custom_hotkeys = []
        for idx, (inst_id, hk_str) in enumerate(custom_hotkeys):
            if hk_str and hk_str.strip():
                vk, mods = parse_hotkey(hk_str.strip(), "")
                if vk:
                    key_id = inputwatch.ID_CUSTOM_BASE + idx
                    self.custom_hotkeys.append((inst_id, vk, mods, key_id))

        self.hold_mode = bool(hold_mode)
        self.enter_sends = bool(enter_sends)
        self.excluded = {e.strip().lower() for e in excluded if e.strip()}
        if show_tray != self.show_tray:
            self.show_tray = bool(show_tray)
            if self._hwnd:
                user32.PostMessageW(self._hwnd, WM_SHOW_TRAY,
                                    1 if show_tray else 0, 0)
        log.info("ショートカット: 録音 vk=%#x mods=%s / 中止 vk=%#x / "
                 "特定動作 vk=%#x / 言語 vk=%#x / カスタム指示=%d件 / 長押し=%s / Enter送信=%s",
                 self.hotkey_vk, sorted(self.hotkey_mods), self.cancel_vk,
                 self.action_vk, self.lang_vk, len(self.custom_hotkeys),
                 self.hold_mode, self.enter_sends)
        # 除外アプリも残す（「効かない」と言われたときに、まず見る所）。
        # 書いていなかったため mock_e2e の excluded が通らなかった。
        log.info("使わないアプリ（除外）: %s",
                 ", ".join(sorted(excluded)) or "なし")
        self.sync_hotkeys()

    # ------------------------------------------------------ ショートカット

    def sync_hotkeys(self) -> None:
        """登録を今の状態に合わせる（別スレッドから呼んでよい）。"""
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_SYNC_KEYS, 0, 0)

    def _apply_hotkeys_now(self) -> None:
        """登録の付け外し。**必ず win スレッドで呼ぶこと。**

        録音していない間は、録音の開始キーだけを登録する。
        Enter と Esc は**録音中だけ**登録するので、ふだんの操作には
        いっさい触れない。
        """
        if self.keys is None:
            return
        recording = self._is_recording()

        # 録音の開始／停止。除外アプリが前面のときは登録を外して譲る。
        # 一時停止中も、除外アプリのときと同じく手放す
        if (self._excluded_now_flag or self.paused) and not recording:
            self.keys.unregister(inputwatch.ID_RECORD)
        else:
            self.keys.register(inputwatch.ID_RECORD, self.hotkey_mods,
                               self.hotkey_vk)

        # 中止（Esc）と送信（Enter）は録音中だけ
        if recording:
            self.keys.register(inputwatch.ID_CANCEL, self.cancel_mods,
                               self.cancel_vk)
            if self.enter_sends:
                self.keys.register(inputwatch.ID_SEND, set(), VK_RETURN)
            else:
                self.keys.unregister(inputwatch.ID_SEND)
        else:
            self.keys.unregister(inputwatch.ID_CANCEL)
            self.keys.unregister(inputwatch.ID_SEND)

        # 言語切り替えショートカット（設定されている場合）
        lang_vk = getattr(self, "lang_vk", 0)
        if lang_vk:
            self.keys.register(inputwatch.ID_TOGGLE_LANG,
                               getattr(self, "lang_mods", frozenset()),
                               lang_vk)
        else:
            self.keys.unregister(inputwatch.ID_TOGGLE_LANG)

        # 特定動作用ショートカット（設定されている場合）
        action_vk = getattr(self, "action_vk", 0)
        if (self._excluded_now_flag or self.paused) or recording:
            self.keys.unregister(inputwatch.ID_ACTION)
        elif action_vk:
            self.keys.register(inputwatch.ID_ACTION,
                               getattr(self, "action_mods", frozenset()),
                               action_vk)
        else:
            self.keys.unregister(inputwatch.ID_ACTION)

        # 画面AIアシスタント（ジャービス）用ショートカット
        asst_vk = getattr(self, "assistant_vk", 0)
        if (self._excluded_now_flag or self.paused) or recording:
            self.keys.unregister(inputwatch.ID_ASSISTANT)
        elif asst_vk:
            self.keys.register(inputwatch.ID_ASSISTANT,
                               getattr(self, "assistant_mods", frozenset()),
                               asst_vk)
        else:
            self.keys.unregister(inputwatch.ID_ASSISTANT)

        # 直前の挿入を直すショートカット（アシスタントと同じ扱い）
        fix_vk = getattr(self, "fix_vk", 0)
        if (self._excluded_now_flag or self.paused) or recording:
            self.keys.unregister(inputwatch.ID_FIX)
        elif fix_vk:
            self.keys.register(inputwatch.ID_FIX,
                               getattr(self, "fix_mods", frozenset()),
                               fix_vk)
        else:
            self.keys.unregister(inputwatch.ID_FIX)

        # カスタム指示用ショートカット
        for inst_id, vk, mods, key_id in getattr(self, "custom_hotkeys", []):
            if (self._excluded_now_flag or self.paused) or recording:
                self.keys.unregister(key_id)
            elif vk:
                self.keys.register(key_id, mods, vk)
            else:
                self.keys.unregister(key_id)

    def refresh_hotkeys(self) -> None:
        """いまあるべき姿に組み立て直してほしい、と win スレッドへ頼む。"""
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_VERIFY_KEYS, 0, 0)

    def verify_hotkeys(self) -> None:
        """登録が生きているか確かめてほしい、と win スレッドへ頼む。"""
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_VERIFY_KEYS, 0, 0)

    def _verify_hotkeys_now(self) -> None:
        """登録を確かめ、外れていたら付け直す。**win スレッドで動く。**

        ★まず `_apply_hotkeys_now()` で「いまあるべき姿」を作り直す。
        以前はいま持っている分を付け直すだけだった。そのため、
        除外アプリが前面だった拍子に録音キーの登録が外れると、
        **次に画面が切り替わるまで二度と戻らなかった**
        （何も持っていない時は、そのまま何もせずに帰っていた）。
        """
        if self.keys is None:
            return
        self._apply_hotkeys_now()
        want = self.keys.held_ids()
        if not want:
            return
        # ★付け直し（全キーを解除→再登録）は、登録の失敗が実際に
        # 記録されているときだけにする（2026-10-24 改修）。
        # 以前は確認のたび（2 秒ごと）に全キーを付け直していて、
        # 解除されている一瞬に押されたキーが消えたり、二重登録の
        # 失敗ログが出たりする無駄があった。_apply_hotkeys_now が
        # 「いまあるべき姿」への付け外しは担うので、通常確認は
        # それだけで足りる。
        if self.keys.failures:
            self.keys.reassert()
        ok = self.keys.held_ids() == want
        if self._keys_ok and not ok:
            log.error("ショートカットの登録が外れました")
        self._keys_ok = ok
        if self._on_keys_lost is not None and not ok:
            try:
                self._on_keys_lost()
            except Exception:
                log.exception("ショートカットの通知で例外")

    def set_keys_listener(self, fn) -> None:  # noqa: ANN001
        self._on_keys_lost = fn

    @property
    def keys_ok(self) -> bool:
        return self._keys_ok

    def _hotkey_fired(self, key_id: int) -> None:
        """WM_HOTKEY が来た。ここは軽く済ませる。"""
        if key_id == inputwatch.ID_RECORD:
            self._long_press_notified = False
            if self.hold_mode:
                # ★離したことを知るため、押されたときだけ 30ms ごとに
                # キーの状態を見る。RegisterHotKey は離したことを
                # 知らせてくれない。前はここで何もしておらず、
                # 「長押しの間だけ」を選ぶとショートカットで録音を
                # 止められなかった（2026-10-05 発覚）。
                # GetAsyncKeyState は読むだけで、相手のアプリも
                # 利用者の入力も待たせない（フックではない）。
                self._hotkey_held = True
                self._down_at = time.monotonic()
                user32.SetTimer(self._hwnd, RELEASE_TIMER, RELEASE_POLL_MS,
                                None)
            self._on_hotkey_down()
        elif key_id == inputwatch.ID_CANCEL:
            self._on_cancel()
        elif key_id == inputwatch.ID_SEND:
            self._on_send()
        elif key_id == inputwatch.ID_TOGGLE_LANG:
            if self._on_toggle_lang is not None:
                self._on_toggle_lang()
        elif key_id == inputwatch.ID_ACTION:
            if getattr(self, "_on_action_down", None) is not None:
                self._on_action_down()
        elif key_id == inputwatch.ID_ASSISTANT:
            if getattr(self, "_on_assistant_down", None) is not None:
                self._on_assistant_down()
        elif key_id == inputwatch.ID_FIX:
            if getattr(self, "_on_fix_down", None) is not None:
                self._on_fix_down()
        elif inputwatch.ID_CUSTOM_BASE <= key_id < inputwatch.ID_CUSTOM_BASE + 64:
            for inst_id, _vk, _mods, kid in getattr(self, "custom_hotkeys", []):
                if kid == key_id:
                    if getattr(self, "_on_custom_action_down", None) is not None:
                        self._on_custom_action_down(inst_id)
                    break

    def _focus_changed(self, hwnd: int, event: int) -> None:
        """前面のウィンドウや入力先が変わった。

        ここは**数えて知らせるだけ**。重い判定はしない
        （相手のアプリを待たせないため、`WINEVENT_OUTOFCONTEXT` で
        受けているが、それでも軽くしておく）。
        """
        if self._on_focus_change is not None:
            try:
                self._on_focus_change(hwnd, event)
            except Exception:
                log.exception("画面の切り替わりの通知で例外")
        # 除外アプリかどうかを、ここで更新しておく（軽い処理）
        try:
            self._excluded_now_flag = self._excluded_now()
        except Exception:
            self._excluded_now_flag = False
        self.sync_hotkeys()

    def _poll_release(self) -> None:
        """長押しのあいだ、録音キーを離したかを見る。win スレッドで動く。"""
        if not self._hotkey_held:
            user32.KillTimer(self._hwnd, RELEASE_TIMER)
            return
        held = time.monotonic() - self._down_at
        # 長押し閾値（0.5秒）に達したら1回だけ知らせる
        if (held >= 0.5 and not self._long_press_notified
                and getattr(self, "_on_long_press", None) is not None):
            self._long_press_notified = True
            try:
                self._on_long_press(held)
            except Exception:
                log.exception("長押し通知で例外")

        down = bool(user32.GetAsyncKeyState(self.hotkey_vk) & 0x8000)
        if down and held < RELEASE_GIVE_UP_S:
            return
        user32.KillTimer(self._hwnd, RELEASE_TIMER)
        self._hotkey_held = False
        self._long_press_notified = False
        try:
            self._on_hotkey_up(held)
        except Exception:
            log.exception("キーを離したときの処理で例外")

    def set_focus_listener(self, fn) -> None:  # noqa: ANN001
        self._on_focus_change = fn

    # ------------------------------------------------------------ フック

    def _mods_down(self) -> set[str]:
        down: set[str] = set()
        if user32.GetAsyncKeyState(VK_CONTROL) & 0x8000:
            down.add("ctrl")
        if user32.GetAsyncKeyState(VK_SHIFT) & 0x8000:
            down.add("shift")
        if user32.GetAsyncKeyState(VK_MENU) & 0x8000:
            down.add("alt")
        if (user32.GetAsyncKeyState(VK_LWIN) & 0x8000
                or user32.GetAsyncKeyState(VK_RWIN) & 0x8000):
            down.add("win")
        return down

    def _excluded_now(self) -> bool:
        """前面が「使わないアプリ」なら True。フックの中なので結果を短く覚える。"""
        if not self.excluded:
            return False
        hwnd = int(user32.GetForegroundWindow() or 0)
        cached_hwnd, cached_exe = self._exe_cache
        if hwnd != cached_hwnd:
            cached_exe = foreground_exe().lower()
            self._exe_cache = (hwnd, cached_exe)
        return cached_exe in self.excluded

    # ★キーフックは撤去した。
    #
    # 低レベルのフック（WH_KEYBOARD_LL）のコールバックは、Python では
    # GIL を取れるまで動けない。文字起こしで GIL がふさがっていると、
    # そのあいだ **PC 全体のキー入力が待たされる**。
    # マウス側で実際に PC がほぼ固まったため、キー側も同じ危険があると
    # 判断して RegisterHotKey に置き換えた（app/inputwatch.py）。
    #
    # 長押しモード（押しているあいだだけ録音）は、キーを離したことを
    # 知る必要がある。フックは使わず、押されたときだけタイマーで
    # GetAsyncKeyState を見る（_poll_release）。

    # ------------------------------------------------------------ トレイ

    def _wnd_cb(self, hwnd: int, msg: int, wparam: int, lparam: int) -> int:
        try:
            if self._taskbar_msg and msg == self._taskbar_msg:
                # タスクバーが作り直された（起動直後・explorer 再起動）
                self._tray_added = False
                if self.show_tray:
                    self._set_tray_visible(True)
                return 0
            if msg == WM_OVERLAY_WAKE:
                self._overlay_speed(True)
                self.overlay.tick()
                return 0
            if msg == WM_TIMER and wparam == OVERLAY_TIMER:
                self.overlay.tick()
                self._overlay_speed(not self.overlay.idle())
                if (self.show_tray and not self._tray_added
                        and time.monotonic() >= self._tray_retry_at):
                    self._tray_retry_at = time.monotonic() + 3.0
                    self._set_tray_visible(True)
                return 0
            if msg == WM_TIMER and wparam == RELEASE_TIMER:
                self._poll_release()
                return 0
            if msg == WM_TRAY:
                low = lparam & 0xFFFF
                if low == WM_RBUTTONUP:
                    self._show_menu()
                elif low == WM_LBUTTONDBLCLK:
                    self._on_menu("settings")
                return 0
            if msg == WM_COMMAND:
                self._menu_command(wparam & 0xFFFF)
                return 0
            if msg == WM_SET_ICON:
                self._apply_icon(wparam)
                return 0
            if msg == WM_SHOW_TRAY:
                self._set_tray_visible(bool(wparam))
                return 0
            if msg == inputwatch.WM_HOTKEY:
                self._hotkey_fired(int(wparam))
                return 0
            if msg == WM_SYNC_KEYS:
                self._apply_hotkeys_now()
                return 0
            if msg == WM_VERIFY_KEYS:
                self._verify_hotkeys_now()
                return 0
            if msg == WM_INSTALL_MOUSE:
                if self._mouse is not None:
                    self._mouse.install()
                return 0
            if msg == WM_QUIT_APP:
                user32.PostQuitMessage(0)
                return 0
            if msg in (WM_CLOSE, WM_DESTROY) and hwnd == self._hwnd:
                user32.PostQuitMessage(0)
                return 0
        except Exception:
            log.exception("ウィンドウ処理で例外")
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _overlay_speed(self, fast: bool) -> None:
        """帯のタイマーの速さを切り替える（win スレッドで動く）。"""
        if fast == getattr(self, "_overlay_fast", True):
            return
        self._overlay_fast = fast
        user32.SetTimer(self._hwnd, OVERLAY_TIMER,
                        OVERLAY_INTERVAL_MS if fast else OVERLAY_IDLE_MS,
                        None)

    def _menu_command(self, cid: int) -> None:
        name = {ID_SETTINGS: "settings", ID_DICT: "dictionary",
                ID_HISTORY: "history", ID_LOG: "log", ID_RESTART: "restart",
                ID_QUIT: "quit", ID_REPASTE: "repaste",
                ID_COPY_LAST: "copy_last",
                ID_SLOW: "slow", ID_PAUSE: "pause",
                ID_OVERLAY_TEXT: "overlay_text",
                ID_PUNCT_FEW: "punct:few",
                ID_PUNCT_NORMAL: "punct:normal",
                ID_PUNCT_MANY: "punct:many",
                ID_LANG_JA: "lang:ja",
                ID_LANG_EN: "lang:en",
                ID_LANG_AUTO: "lang:auto",
                ID_CLIP_OPEN: "clip_open",
                ID_CLIP_PAUSE: "clip_pause",
                ID_RECIPE_OPEN: "recipe_open",
                ID_VOICE_COMMANDS: "voice_commands"}.get(cid)
        if name:
            self._on_menu(name)
        elif cid >= ID_MODEL_BASE and hasattr(self, "_menu_model_keys"):
            idx = cid - ID_MODEL_BASE
            if 0 <= idx < len(self._menu_model_keys):
                self._on_menu(f"model:{self._menu_model_keys[idx]}")

    def _show_menu(self) -> None:
        menu = user32.CreatePopupMenu()
        if not menu:
            return
        submenus: list[int] = []
        try:
            user32.AppendMenuW(menu, MF_STRING, ID_SETTINGS, t("tray.settings"))
            user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
            user32.AppendMenuW(menu, MF_STRING, ID_REPASTE, t("tray.repaste"))
            user32.AppendMenuW(menu, MF_STRING, ID_COPY_LAST,
                               t("tray.copy_last"))
            user32.AppendMenuW(menu, MF_STRING, ID_DICT, t("tray.dictionary"))
            user32.AppendMenuW(menu, MF_STRING, ID_HISTORY, t("tray.history"))
            user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)

            # クイック切り替えの状態を取得
            qs: dict[str, object] = (self._quick_settings_fn()
                                     if self._quick_settings_fn else {})

            # 文章変換を一覧から選んで録音する（キーを忘れたときにも使える）
            if qs.get("recipe_ready"):
                user32.AppendMenuW(menu, MF_STRING, ID_RECIPE_OPEN,
                                   t("tray.recipe_open"))
            # クリップボード履歴（使っているときだけ出す）
            if qs.get("clip_enabled"):
                user32.AppendMenuW(menu, MF_STRING, ID_CLIP_OPEN,
                                   t("tray.clip_open"))
                user32.AppendMenuW(
                    menu, MF_STRING | (MF_CHECKED if qs.get("clip_paused")
                                       else 0),
                    ID_CLIP_PAUSE, t("tray.clip_pause"))
                user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
            punct = str(qs.get("punct_density", "few"))
            commands_on = bool(qs.get("voice_commands", True))
            cur_model = str(qs.get("current_model", ""))
            ready_models = qs.get("ready_models", [])

            # 句読点の量（少なめ・標準・多め）
            punct_menu = user32.CreatePopupMenu()
            if punct_menu:
                submenus.append(punct_menu)
                user32.AppendMenuW(
                    punct_menu,
                    MF_STRING | (MF_CHECKED if punct == "few" else 0),
                    ID_PUNCT_FEW, t("tray.punct_few"))
                user32.AppendMenuW(
                    punct_menu,
                    MF_STRING | (MF_CHECKED if punct == "normal" else 0),
                    ID_PUNCT_NORMAL, t("tray.punct_normal"))
                user32.AppendMenuW(
                    punct_menu,
                    MF_STRING | (MF_CHECKED if punct == "many" else 0),
                    ID_PUNCT_MANY, t("tray.punct_many"))
                user32.AppendMenuW(menu, MF_POPUP, punct_menu,
                                   t("tray.punctuation"))

            # 認識言語（日本語・英語・自動）
            lang_menu = user32.CreatePopupMenu()
            if lang_menu:
                submenus.append(lang_menu)
                cur_lang = str(qs.get("language", "ja"))
                user32.AppendMenuW(
                    lang_menu,
                    MF_STRING | (MF_CHECKED if cur_lang == "ja" else 0),
                    ID_LANG_JA, t("tray.lang_ja"))
                user32.AppendMenuW(
                    lang_menu,
                    MF_STRING | (MF_CHECKED if cur_lang == "en" else 0),
                    ID_LANG_EN, t("tray.lang_en"))
                user32.AppendMenuW(
                    lang_menu,
                    MF_STRING | (MF_CHECKED if cur_lang == "auto" else 0),
                    ID_LANG_AUTO, t("tray.lang_auto"))
                user32.AppendMenuW(menu, MF_POPUP, lang_menu,
                                   t("tray.language"))

            # モデルの切り替え（用意できているモデルが 2 つ以上ある場合）
            self._menu_model_keys = []
            if isinstance(ready_models, list) and len(ready_models) >= 1:
                model_menu = user32.CreatePopupMenu()
                if model_menu:
                    submenus.append(model_menu)
                    for i, item in enumerate(ready_models):
                        if isinstance(item, (tuple, list)) and len(item) >= 2:
                            m_key, m_name = str(item[0]), str(item[1])
                            self._menu_model_keys.append(m_key)
                            cid = ID_MODEL_BASE + i
                            checked = MF_CHECKED if m_key == cur_model else 0
                            user32.AppendMenuW(model_menu, MF_STRING | checked,
                                               cid, m_name)
                    user32.AppendMenuW(menu, MF_POPUP, model_menu,
                                       t("tray.model"))

            # 音声コマンドの有効・無効
            user32.AppendMenuW(
                menu, MF_STRING | (MF_CHECKED if commands_on else 0),
                ID_VOICE_COMMANDS, t("tray.voice_commands"))

            user32.AppendMenuW(
                menu, MF_STRING | (MF_CHECKED if self.overlay_text_on else 0),
                ID_OVERLAY_TEXT, t("tray.overlay_text"))
            user32.AppendMenuW(
                menu, MF_STRING | (MF_CHECKED if self.paused else 0),
                ID_PAUSE, t("tray.pause"))
            user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
            user32.AppendMenuW(menu, MF_STRING, ID_SLOW, t("tray.slow"))
            user32.AppendMenuW(menu, MF_STRING, ID_LOG, t("tray.log"))
            user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
            user32.AppendMenuW(menu, MF_STRING, ID_RESTART, t("tray.restart"))
            user32.AppendMenuW(menu, MF_STRING, ID_QUIT, t("tray.quit"))
            pt = wintypes.POINT()
            user32.GetCursorPos(ctypes.byref(pt))
            user32.SetForegroundWindow(self._hwnd)
            cid = user32.TrackPopupMenu(
                menu, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0,
                self._hwnd, None)
            user32.PostMessageW(self._hwnd, 0, 0, 0)
            if cid:
                self._menu_command(int(cid))
        finally:
            user32.DestroyMenu(menu)

    def _load_icon(self, state: str) -> int:
        """その状態の .ico を、トレイに合う大きさで読み込む。

        LoadImage に大きさを渡すと、.ico の中からいちばん近いものが選ばれる。
        高 DPI でもぼやけないよう、システムの小アイコンの大きさを使う。
        """
        if state not in self._hicons:
            path = self.icons.get(state) or self.icons.get("idle")
            if path is None:
                self._hicons[state] = 0
                return 0
            size = user32.GetSystemMetrics(SM_CXSMICON) or 16
            handle = user32.LoadImageW(None, str(path), IMAGE_ICON,
                                       size, size, LR_LOADFROMFILE)
            if not handle:
                log.warning("アイコンを読み込めませんでした: %s", path)
            self._hicons[state] = handle or 0
        return self._hicons[state]

    def _nid(self, flags: int) -> NOTIFYICONDATA:
        nid = NOTIFYICONDATA()
        nid.cbSize = ctypes.sizeof(NOTIFYICONDATA)
        nid.hWnd = self._hwnd
        nid.uID = 1
        nid.uFlags = flags
        return nid

    def _set_tray_visible(self, visible: bool) -> None:
        if visible and not self._tray_added:
            nid = self._nid(NIF_MESSAGE | NIF_ICON | NIF_TIP)
            nid.uCallbackMessage = WM_TRAY
            nid.hIcon = self._load_icon("idle")
            nid.szTip = t("tray.idle")
            ok = bool(shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(nid)))
            if not ok:
                # 前のプロセスの残骸などですでに登録されている場合は更新を試す
                ok = bool(shell32.Shell_NotifyIconW(NIM_MODIFY,
                                                    ctypes.byref(nid)))
                if not ok:
                    # 一度削除してから再追加を試みる（Explorer の同期ずれ復旧）
                    shell32.Shell_NotifyIconW(NIM_DELETE,
                                              ctypes.byref(self._nid(0)))
                    ok = bool(shell32.Shell_NotifyIconW(NIM_ADD,
                                                        ctypes.byref(nid)))
            self._tray_added = ok
        elif not visible and self._tray_added:
            shell32.Shell_NotifyIconW(NIM_DELETE,
                                      ctypes.byref(self._nid(0)))
            self._tray_added = False

    def _apply_icon(self, index: int) -> None:
        if not self._tray_added:
            if self.show_tray:
                self._set_tray_visible(True)
            return
        states = ["idle", "recording", "transcribing"]
        state = states[index] if 0 <= index < len(states) else "idle"
        nid = self._nid(NIF_ICON | NIF_TIP)
        nid.hIcon = self._load_icon(state)
        tip = "paused" if self.paused and state == "idle" else state
        nid.szTip = t(f"tray.{tip}")
        if not shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(nid)):
            # 更新失敗＝Explorer 再起動等でアイコンが消失した恐れがあるので復旧
            self._tray_added = False
            if self.show_tray:
                self._set_tray_visible(True)

    def set_state(self, state: str) -> None:
        """他スレッドから呼ぶ。メッセージを投げるだけ。"""
        states = {"idle": 0, "recording": 1, "transcribing": 2}
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_SET_ICON, states.get(state, 0), 0)

    def set_paused(self, paused: bool) -> None:
        """一時停止の切り替え（別スレッドから呼んでよい）。

        付け外しは win スレッドに頼む（RegisterHotKey は登録した
        スレッドのもの。よそのスレッドで外すと外れない）。
        """
        self.paused = bool(paused)
        self.sync_hotkeys()
        self.set_state("idle")

    def refresh_tray(self) -> None:
        """表示言語が変わったときにツールチップを付け直す。"""
        self.set_state("idle")

    def quit(self) -> None:
        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_QUIT_APP, 0, 0)

    # ------------------------------------------------------------ ループ

    def wait_ready(self, timeout: float = 5.0) -> bool:
        return self._ready.wait(timeout)

    def run(self) -> None:
        try:
            self._setup()
        except Exception:
            log.exception("Win32 の初期化に失敗")
            self._ready.set()
            return
        self._ready.set()
        msg = ctypes.create_string_buffer(64)
        while True:
            ret = user32.GetMessageW(msg, None, 0, 0)
            if ret in (0, -1):
                break
            user32.TranslateMessage(msg)
            user32.DispatchMessageW(msg)
        self._teardown()

    def _setup(self) -> None:
        hinst = kernel32.GetModuleHandleW(None)
        cls = WNDCLASS()
        cls.lpfnWndProc = ctypes.cast(self._wnd_proc, ctypes.c_void_p)
        cls.hInstance = hinst
        cls.lpszClassName = "KoeTypeHiddenWindow"
        if not user32.RegisterClassW(ctypes.byref(cls)):
            err = ctypes.get_last_error()
            if err != 1410:            # ERROR_CLASS_ALREADY_EXISTS
                raise OSError(f"RegisterClassW 失敗 err={err}")
        self._hwnd = user32.CreateWindowExW(
            0, "KoeTypeHiddenWindow", "koe-type", 0, 0, 0, 0, 0,
            None, None, hinst, None)
        if not self._hwnd:
            raise OSError(f"CreateWindowExW 失敗 err={ctypes.get_last_error()}")
        self._taskbar_msg = int(
            user32.RegisterWindowMessageW("TaskbarCreated") or 0)

        icon = self._load_icon("idle")
        if icon:
            user32.SendMessageW(self._hwnd, WM_SETICON, ICON_SMALL, icon)
            user32.SendMessageW(self._hwnd, WM_SETICON, ICON_BIG, icon)

        if self.show_tray:
            self._set_tray_visible(True)
            if not self._tray_added:
                log.warning("トレイアイコンを追加できませんでした")

        self.overlay.create(hinst)
        user32.SetTimer(self._hwnd, OVERLAY_TIMER, OVERLAY_INTERVAL_MS, None)
        self._overlay_fast = True
        self.overlay.on_wake = lambda: user32.PostMessageW(
            self._hwnd, WM_OVERLAY_WAKE, 0, 0)

        self._hook = None
        if dryrun.enabled():
            # から打ちモードでは何も取り付けない。
            # 常駐中の本物のアプリとショートカットを取り合わないため。
            log.warning("から打ちモードなのでショートカットは登録しません")
        else:
            # ★低レベルのフックはやめた。
            # OS が押された時だけ WM_HOTKEY を投げてくれるので、
            # こちらが遅くても他のアプリの入力は止まらない。
            self.keys = inputwatch.Hotkeys(self._hwnd)
            self.focus = inputwatch.FocusWatch(self._focus_changed)
            self.focus.install()
            self._apply_hotkeys_now()
            log.info("ショートカットとトレイを用意しました"
                     "（入力を止めない方式）")

    def _teardown(self) -> None:
        if self.keys is not None:
            self.keys.clear()
        if self.focus is not None:
            self.focus.remove()
        try:
            user32.KillTimer(self._hwnd, OVERLAY_TIMER)
            self.overlay.destroy()
        except Exception:
            log.exception("帯の後片付けで例外")
        try:
            if self._hook:
                user32.UnhookWindowsHookEx(self._hook)
                self._hook = 0
            self._set_tray_visible(False)
            if self._hwnd:
                user32.DestroyWindow(self._hwnd)
                self._hwnd = 0
        except Exception:
            log.exception("後片付けで例外")

# ---------------------------------------------------------------- 動作チェック用


class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", ctypes.c_char * 260),
    ]


def _own_pid() -> int:
    import os  # noqa: PLC0415
    return os.getpid()


def running_exes() -> set[str]:
    """いま動いているプロセスの実行ファイル名（小文字）。

    ほかの音声入力が同時に動いていないかを調べるために使う。
    kernel32 の標準の口だけを使う（新しい依存は増やさない）。
    """
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD,
                                                  wintypes.DWORD]
    kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    kernel32.Process32First.argtypes = [wintypes.HANDLE,
                                        ctypes.POINTER(PROCESSENTRY32)]
    kernel32.Process32Next.argtypes = [wintypes.HANDLE,
                                       ctypes.POINTER(PROCESSENTRY32)]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    TH32CS_SNAPPROCESS = 0x00000002
    INVALID = wintypes.HANDLE(-1).value
    out: set[str] = set()
    snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if not snapshot or snapshot == INVALID:
        return out
    try:
        entry = PROCESSENTRY32()
        entry.dwSize = ctypes.sizeof(PROCESSENTRY32)
        if not kernel32.Process32First(snapshot, ctypes.byref(entry)):
            return out
        while True:
            name = entry.szExeFile.decode("mbcs", "replace").lower()
            if name:
                out.add(name)
            if not kernel32.Process32Next(snapshot, ctypes.byref(entry)):
                break
    finally:
        kernel32.CloseHandle(snapshot)
    return out
