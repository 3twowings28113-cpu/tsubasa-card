"""エンジン切替の状態（格下げ・障害フォールバック・復帰）の置き場。

2026-10-31 の第三者監査の構造判断: 全面の作り直しは不要だが、
「エンジン切替の状態管理」だけは集約に値する。高・中 severity の
大半がここに集中していた。以前は理由・失敗数・遅さの数え方が
Controller の各所に散らばり、

  ・障害フォールバックの失敗カウンタが成功で戻らず「累積」で発動
    （docstring の「続けて失敗」と実装が食い違う）
  ・格下げ（"slow"）には復帰があるのに障害（"trouble"）には無い
  ・切替の通知が "slow" の時だけ

という「一方通行＋無通知」の同型の穴が、直した箇所の死角に残った。

そこで、数え方と印の持ち方をこの小さなクラスに寄せる。Controller は
「いつ切り替えるか」の判断と実行だけを持ち、状態遷移の規則はここで
固定する（状態遷移テストは tests/test_engine_state.py）。
"""

from __future__ import annotations

# 発動までの回数。どちらも「連続」したものだけを数える。
FAIL_LIMIT = 3        # 認識の失敗が続いたら受け皿へ逃げる
SLOW_LIMIT = 3        # 処理の遅れが続いたら速いモデルへ逃げる
# ストライクの連続とみなす間隔。これより空いたら数え直す
# （数分〜数日にわたる累積で発動させないため）。
SLOW_WINDOW = 15.0
# 組み立て・切替の直後は初期化の遅れを含みうるので数えない時間。
COLD_GRACE = 2.0
# エンジンが ready になってから数えない時間。組み立てと ready は
# 別物で、常駐エンジンは初回読み込みが終わるまで ready にならない。
# 組み立て基準の COLD_GRACE だけでは、読み込みに時間が空いた時の
# 起動ジッタを取りこぼす（2026-11-05 実機: 組み立てから 11 秒後に
# ready、その直後の超過で格下げが発動した）。
READY_GRACE = 5.0


class EngineSwitchState:
    """自動でエンジンを切り替えた理由と、その判断に使う数え方。

    手動のモデル選択はここには現れない。設定からの組み立て
    （_build_engine）が reset_for_build で印を消すので、「印がある」
    こと自体が「自動で逃げている最中」を意味する。
    """

    def __init__(self) -> None:
        self.reason = ""           # 逃げている理由: "" / "slow" / "trouble"
        self.fails = 0             # 連続した認識の失敗
        self.slow_runs = 0         # 連続した「遅い」ストライク
        self.slow_last_at = 0.0    # 最後に遅いと数えた時刻
        self.since = 0.0           # エンジンを組み立て・切り替えた時刻
        self.ready_at = 0.0        # ready を観測した時刻（未観測は 0）
        # この逃避エピソードで通知済みの理由。同じ切替を何度も
        # 知らせないため。理由が消えたら（復帰・再構築）一緒に消す。
        self.notified: set[str] = set()

    # ------------------------------------------------------------ 遷移

    def reset_for_build(self, now: float) -> None:
        """設定からの組み立て直し。自動切替の印と数え方を全部戻す。

        利用者が自分でモデルを選び直した時もここを通るので、
        「手動の選択には干渉しない」はこのリセットで担保する。
        失敗数も戻す: 別のエンジンの失敗まで「続けて」と数えると、
        選び直した直後の 1 回で受け皿へ逃げてしまう。
        """
        self.reason = ""
        self.fails = 0
        self.slow_runs = 0
        self.slow_last_at = 0.0
        self.since = now
        self.ready_at = 0.0
        self.notified.clear()

    def note_switch(self, reason: str, now: float) -> None:
        """エンジンを切り替えた。切替直後の遅れは数えないよう戻す。"""
        self.reason = reason
        self.since = now
        self.slow_runs = 0
        self.slow_last_at = 0.0
        # 切り替えた先は別のエンジン。ready の観測もやり直す
        # （前のエンジンの ready 時刻で猶予を判定しないため）。
        self.ready_at = 0.0

    def note_ready(self, now: float) -> None:
        """エンジンが ready になった（Controller が観測した）。

        番人の猶予は、組み立て時刻（since）だけでなく ready の
        時刻からも測る。note_round 側の判定を参照。
        """
        self.ready_at = now

    def clear_reason(self) -> None:
        """設定のモデルへ戻れた。逃避エピソードを終える。"""
        self.reason = ""
        self.notified.clear()

    def mark_notified(self, reason: str) -> bool:
        """この理由の通知が初めてなら True（通知してよい）。"""
        if reason in self.notified:
            return False
        self.notified.add(reason)
        return True

    # ------------------------------------------------------------ 数え方

    def note_success(self) -> None:
        """認識が 1 回成功した。失敗の数え直し（「連続」の担保）。"""
        self.fails = 0

    def note_failure(self) -> bool:
        """認識が 1 回失敗した。受け皿へ逃げるべき回数に達したら True。

        達した時点で数え直す。逃げ先でも失敗が続けば、また届いて
        呼び出し側が判断できる（ただし逃げ先にいる間の扱いは
        呼び出し側の _switch_engine の同一モデル判定が受ける）。
        """
        self.fails += 1
        if self.fails >= FAIL_LIMIT:
            self.fails = 0
            return True
        return False

    def note_round(self, took: float, budget: float, now: float) -> bool:
        """1 回の認識の速さを記録する。格下げすべきなら True。

        - 組み立て・切替から COLD_GRACE 以内に始まった認識は数えない
          （初期化の遅れは「間に合っていない」証拠ではない）。
        - ready から READY_GRACE 以内に始まった認識も数えない。
          組み立て〜ready の間に読み込みで時間が空くと、COLD_GRACE
          （組み立て基準）では起動直後のジッタを取りこぼす
          （2026-11-05 実機: ready の 1〜2 秒後の超過 3 回で発動）。
        - ストライクは連続したものだけ。前のストライクから
          SLOW_WINDOW より空いたら数え直す。
        - 速かった回はストライクを 1 つ減らす（境界での揺れで
          発動させない）。
        発動に達したらストライクは数え直す（設定で禁じられていて
        逃げなかった場合も、次の判断は新しく始める）。
        """
        if now - took - self.since < COLD_GRACE:
            return False
        if self.ready_at and now - took < self.ready_at + READY_GRACE:
            return False
        if took > budget:
            if now - self.slow_last_at > SLOW_WINDOW:
                self.slow_runs = 0
            self.slow_runs += 1
            self.slow_last_at = now
        else:
            self.slow_runs = max(0, self.slow_runs - 1)
        if self.slow_runs >= SLOW_LIMIT:
            self.slow_runs = 0
            return True
        return False
