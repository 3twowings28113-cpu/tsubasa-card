"""この PC の力を調べて、合うモデルをすすめる。

初回の案内で使う。**調べるだけで、何も書き換えない。**
外へ通信もしない（モデルのダウンロードは別）。

調べること

| 何を | どうやって |
|---|---|
| CPU の名前と数 | レジストリ（`HKLM\\...\\CentralProcessor\\0`）と `GetSystemInfo` |
| AVX2 が使えるか | `IsProcessorFeaturePresent(40)` |
| メモリ | `GlobalMemoryStatusEx` |
| 空き容量 | `GetDiskFreeSpaceExW` |
| GPU と Vulkan | transcribe.cpp の `backends()` |
| 実際の速さ | 2 秒ぶんの音を 1 回聞かせて測る（モデルがあるときだけ） |

どれも OS 標準の DLL か、もう入っているものだけを使う。
"""

from __future__ import annotations

import ctypes
import logging
import os
import platform
import sys
import time
import winreg
from ctypes import wintypes
from dataclasses import asdict, dataclass, field

from . import catalog

log = logging.getLogger(__name__)

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

PF_AVX2_INSTRUCTIONS_AVAILABLE = 40
PF_AVX_INSTRUCTIONS_AVAILABLE = 39


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", wintypes.DWORD),
                ("dwMemoryLoad", wintypes.DWORD),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]


kernel32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MEMORYSTATUSEX)]
kernel32.GlobalMemoryStatusEx.restype = wintypes.BOOL
kernel32.IsProcessorFeaturePresent.argtypes = [wintypes.DWORD]
kernel32.IsProcessorFeaturePresent.restype = wintypes.BOOL
kernel32.GetDiskFreeSpaceExW.argtypes = [
    wintypes.LPCWSTR, ctypes.POINTER(ctypes.c_ulonglong),
    ctypes.POINTER(ctypes.c_ulonglong), ctypes.POINTER(ctypes.c_ulonglong)]
kernel32.GetDiskFreeSpaceExW.restype = wintypes.BOOL


@dataclass
class Profile:
    """この PC の力。数字はすべて「調べて分かった範囲」。"""

    cpu_name: str = ""
    cpu_cores: int = 0
    avx2: bool = False
    avx: bool = False
    memory_gb: float = 0.0
    free_gb: float = 0.0
    gpu_name: str = ""
    vulkan: bool = False
    backends: list = field(default_factory=list)
    windows: str = ""
    python: str = ""
    bench_seconds: float = 0.0        # 2 秒の音を 1 回聞くのにかかった秒
    bench_model: str = ""
    notes: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------- 調べる


def cpu_name() -> str:
    try:
        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
            return str(winreg.QueryValueEx(key, "ProcessorNameString")[0]
                       ).strip()
    except OSError:
        return platform.processor() or "不明"


def memory_gb() -> tuple[float, float]:
    status = MEMORYSTATUSEX()
    status.dwLength = ctypes.sizeof(status)
    if not kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):
        return 0.0, 0.0
    return (status.ullTotalPhys / (1024 ** 3),
            status.ullAvailPhys / (1024 ** 3))


def free_gb(path: str) -> float:
    free = ctypes.c_ulonglong()
    if kernel32.GetDiskFreeSpaceExW(str(path), ctypes.byref(free),
                                    None, None):
        return free.value / (1024 ** 3)
    return 0.0


def gpu_info() -> tuple[str, bool, list]:
    """Vulkan が使える装置を調べる。見つからなければ CPU のみ。"""
    try:
        from . import resident  # noqa: PLC0415
        tcpp = resident.load_binding()
    except Exception as exc:  # noqa: BLE001
        log.debug("GPU を調べられません: %s", exc)
        return "", False, []
    try:
        raw = tcpp.backends()
    except Exception as exc:  # noqa: BLE001
        log.debug("backends() で例外: %s", exc)
        return "", False, []
    names = []
    for item in raw:
        # transcribe.cpp は BackendDevice という形で返す。
        # そのまま文字にすると長い中身が全部出てしまうので、
        # **人が読む名前（description）だけ**を取る。
        label = (getattr(item, "description", "")
                 or getattr(item, "name", "")
                 or (item.get("description") if isinstance(item, dict) else "")
                 or str(item))
        kind = (getattr(item, "kind", "")
                or (item.get("kind") if isinstance(item, dict) else ""))
        names.append({"name": str(label), "kind": str(kind or "")})
    gpus = [d for d in names
            if d["kind"].lower() not in ("cpu", "")
            or "cpu" not in d["name"].lower()]
    gpus = [d for d in names if d["kind"].lower() == "vulkan"] or [
        d for d in names if "cpu" not in d["name"].lower()
        and d["kind"].lower() != "cpu"]
    return (gpus[0]["name"] if gpus else "", bool(gpus),
            [d["name"] for d in names])


def profile(*, bench: bool = True) -> Profile:
    """この PC の力をひと通り調べる。**何も書き換えない。**"""
    total, _avail = memory_gb()
    gpu, vulkan, backends = gpu_info()
    p = Profile(
        cpu_name=cpu_name(),
        cpu_cores=os.cpu_count() or 0,
        avx2=bool(kernel32.IsProcessorFeaturePresent(
            PF_AVX2_INSTRUCTIONS_AVAILABLE)),
        avx=bool(kernel32.IsProcessorFeaturePresent(
            PF_AVX_INSTRUCTIONS_AVAILABLE)),
        memory_gb=round(total, 1),
        free_gb=round(free_gb(str(catalog.MODEL_DIR)), 1),
        gpu_name=gpu, vulkan=vulkan, backends=backends,
        windows=f"{platform.system()} {platform.release()} "
                f"({platform.version()})",
        python=platform.python_version(),
    )
    if not p.avx2:
        p.notes.append("AVX2 が使えないので、文字起こしは遅めになります")
    if p.memory_gb and p.memory_gb < 6:
        p.notes.append("メモリが少なめです。軽いモデルをおすすめします")
    if p.free_gb and p.free_gb < 2:
        p.notes.append("空き容量が少なめです。小さいモデルを選んでください")
    if bench:
        measure(p)
    return p


def measure(p: Profile) -> None:
    """もう入っているモデルで、2 秒の音を 1 回聞いて速さを測る。

    まだ何も入っていなければ、何もしない（ダウンロード前なので）。
    """
    try:
        from . import resident  # noqa: PLC0415
    except Exception:  # noqa: BLE001
        return
    for key in (catalog.DEFAULT_MODEL, *catalog.MODELS):
        spec = catalog.MODELS.get(key)
        if spec is None or not catalog.model_ready(key):
            continue
        if spec.extra.get("worker"):
            # worker 方式のモデルは transcribe.dll では読めない。
            # 測ろうとしても読み込みに失敗してログが汚れるだけ
            # なので、明示的に飛ばす。
            continue
        path = catalog.resident_file(key)
        if path is None or not path.is_file():
            continue
        core = None
        try:
            core = resident.Resident(path)
            core.load()
            pcm = bytes(16000 * 2 * 2)      # 2 秒ぶんの無音
            began = time.perf_counter()
            core.transcribe_pcm(pcm)
            p.bench_seconds = round(time.perf_counter() - began, 3)
            p.bench_model = spec.name
        except Exception as exc:  # noqa: BLE001
            log.debug("速さを測れません: %s", exc)
        finally:
            if core is not None:
                try:
                    core.unload()
                except Exception:  # noqa: BLE001
                    pass
        return


# ---------------------------------------------------------------- すすめる


@dataclass
class Advice:
    model: str
    name: str
    reason_ja: str
    reason_en: str
    alternatives: list = field(default_factory=list)

    def as_dict(self) -> dict:
        return asdict(self)


def recommend(p: Profile) -> Advice:
    """この PC に合うモデルを 1 つ選ぶ。**理由も返す。**

    考え方は PRODUCT_SPEC の「完成の基準」どおり、
    **速さ（最初の文字まで 1.5 秒）を最優先**にする。
    速さが足りないと、音声入力そのものが使われなくなるため。

      ・Vulkan が使えてメモリ 8GB 以上 → Haas-ja-v1.0（worker 常駐）
      ・Vulkan はあるがメモリが少ない／GPU なしで AVX2 あり
        → SenseVoice Small（常駐）
      ・AVX2 もない／メモリが少ない → Moonshine Base 日本語（小さい）

    精度のいちばん高い Whisper large-v3-turbo は、速さが 1/12 なので
    初期値にはしない。「精度を上げたい人」が選べるように並べておく。
    """
    small = "moonshine-base-ja"
    fast = "sensevoice-resident"
    accurate = "whisper-turbo-resident"
    new = "haas-ja"

    def spec_name(key: str) -> str:
        spec = catalog.MODELS.get(key)
        return spec.name if spec else key

    weak = (not p.avx2) or (p.memory_gb and p.memory_gb < 6)
    tiny_disk = bool(p.free_gb) and p.free_gb < 2.0

    if tiny_disk or (weak and not p.vulkan):
        pick = small
        ja = ("この PC は{why}ので、いちばん軽いモデルを選びました。"
              "小さいぶん速く、メモリも食いません。")
        why = ("空き容量が少ない" if tiny_disk
               else ("AVX2 が使えない" if not p.avx2 else "メモリが少なめな"))
        reason_ja = ja.format(why=why)
        reason_en = ("This PC has limited resources, so koe-type picked the "
                     "lightest model. It is fast and uses little memory.")
    elif p.vulkan and p.memory_gb >= 8:
        pick = new
        reason_ja = ("日本語専用の新しいモデル Haas を選びました。"
                     f"{p.gpu_name} で速く動き、精度も高いモデルです。")
        reason_en = ("koe-type picked Haas, the newer Japanese-only "
                     f"model: fast on {p.gpu_name} and accurate.")
    elif p.vulkan:
        pick = fast
        reason_ja = (f"{p.gpu_name} が使えるので、速くて日本語に強いモデルを"
                     "選びました。話しながら文字が出ます。")
        reason_en = (f"{p.gpu_name} is available, so koe-type picked the fast "
                     "Japanese model. Text appears while you speak.")
    else:
        pick = fast
        reason_ja = ("GPU は見つかりませんでしたが、AVX2 が使えるので"
                     "このモデルで十分に速く動きます。")
        reason_en = ("No GPU was found, but this CPU supports AVX2, so this "
                     "model is still fast enough.")

    if p.bench_seconds:
        reason_ja += (f"（この PC での実測：2 秒の音を "
                      f"{p.bench_seconds:.2f} 秒で文字にしました）")
        reason_en += (f" Measured here: {p.bench_seconds:.2f}s to transcribe "
                      f"2s of audio.")

    others = []
    for key, label_ja, label_en in (
            (new, "日本語専用の新しいモデル。速くて精度も高い",
             "Newer Japanese-only model, fast and accurate"),
            (fast, "速さと精度のつりあいがよい（おすすめ）",
             "Balanced speed and accuracy (recommended)"),
            (accurate, "精度はいちばん高いが、12 倍ほど時間がかかる",
             "Most accurate, but about 12x slower"),
            (small, "いちばん軽い。非力な PC 向け",
             "Lightest. For slower PCs")):
        if key == pick or key not in catalog.MODELS:
            continue
        others.append({"model": key, "name": spec_name(key),
                       "ja": label_ja, "en": label_en})

    return Advice(model=pick, name=spec_name(pick),
                  reason_ja=reason_ja, reason_en=reason_en,
                  alternatives=others)


def summary_lines(p: Profile) -> list:
    """画面に並べる「この PC」の行。"""
    def mark(good: bool) -> str:
        return "ok" if good else "warn"

    rows = [
        {"label_ja": "CPU", "label_en": "CPU",
         "value": f"{p.cpu_name}（{p.cpu_cores} 個）", "state": "ok"},
        {"label_ja": "AVX2", "label_en": "AVX2",
         "value": "使えます" if p.avx2 else "使えません",
         "state": mark(p.avx2)},
        {"label_ja": "メモリ", "label_en": "Memory",
         "value": f"{p.memory_gb:.1f} GB",
         "state": mark(p.memory_gb >= 6)},
        {"label_ja": "空き容量", "label_en": "Free space",
         "value": f"{p.free_gb:.1f} GB",
         "state": mark(p.free_gb >= 2)},
        {"label_ja": "GPU", "label_en": "GPU",
         "value": (f"{p.gpu_name}（Vulkan）" if p.vulkan
                   else "見つかりません（CPU で動きます）"),
         "state": mark(p.vulkan)},
    ]
    if p.bench_seconds:
        rows.append({"label_ja": "試し計測", "label_en": "Quick test",
                     "value": f"2 秒の音を {p.bench_seconds:.2f} 秒で",
                     "state": mark(p.bench_seconds < 0.6)})
    return rows


if __name__ == "__main__":        # python -m app.hardware
    import json
    prof = profile()
    print(json.dumps(prof.as_dict(), ensure_ascii=False, indent=2))
    tip = recommend(prof)
    print("\nおすすめ:", tip.name)
    print(tip.reason_ja)
    for row in summary_lines(prof):
        print(f"  {row['label_ja']:10} {row['value']}  [{row['state']}]")
