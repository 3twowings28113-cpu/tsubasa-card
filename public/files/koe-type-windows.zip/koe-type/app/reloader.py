"""コード変更を検知して自動で再起動（ホットリロード）する監視役。

開発・設定変更時に、アプリを起動したまま自動で最新のコードを反映する。
録音中・文字起こし中には再起動せず、待機中（idle）になるのを待ってから安全に行う。
構文エラー（保存途中）がある場合は再起動を保留し、直るのを待つ。

★2026-10-24 改修：これは**開発用**の仕組みなので、既定では動かさない。
  有効にするのは環境変数 `KOE_TYPE_HOT_RELOAD=1` のときだけ。
  以前は常駐アプリの通常起動でも無条件に動いていて、
    ・起動後に app/ へ**新しく現れたファイル**を「変更」と誤判定する
      （`_check_changes` が未記録ファイルを即・変更扱いしていた）
    ・再起動の回数制限が無く、ファイルが変わり続ける限り
      起動し直し続ける
  という 2 点が、再起動ループの経路になっていた。
  あわせて、再起動の前に restartguard（全経路共通の予算）へ必ず聞く。
"""

from __future__ import annotations

import ast
import ctypes
import logging
import os
import threading
import time
from pathlib import Path
from typing import Callable

from . import autostart, dryrun
from .restartguard import RestartGuard
from .util import LOG_DIR, ROOT

log = logging.getLogger(__name__)


def enabled() -> bool:
    """ホットリロードが有効か。開発時の明示指定（環境変数）でのみ有効。"""
    return os.environ.get("KOE_TYPE_HOT_RELOAD") == "1"

_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.FindFirstChangeNotificationW.argtypes = [ctypes.c_wchar_p,
                                                   ctypes.c_int,
                                                   ctypes.c_uint32]
_kernel32.FindFirstChangeNotificationW.restype = ctypes.c_void_p
_kernel32.FindNextChangeNotification.argtypes = [ctypes.c_void_p]
_kernel32.FindCloseChangeNotification.argtypes = [ctypes.c_void_p]
_kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
_kernel32.WaitForSingleObject.restype = ctypes.c_uint32
_INVALID = ctypes.c_void_p(-1).value

# 監視対象の拡張子
_WATCH_EXTS = {".py", ".js", ".css", ".html"}
# 除外するフォルダ・ファイル
_IGNORE_PARTS = {"__pycache__", ".git", "logs", "data", "models", "engines"}


def _get_app_files() -> list[Path]:
    """監視対象のファイルを収集する。"""
    app_dir = ROOT / "app"
    files: list[Path] = []
    if not app_dir.is_dir():
        return files
    for p in app_dir.rglob("*"):
        if p.is_file() and p.suffix in _WATCH_EXTS:
            if any(part in p.parts for part in _IGNORE_PARTS):
                continue
            files.append(p)
    return files


def _is_valid_python(path: Path) -> bool:
    """Python ファイルが構文エラーなくパースできるか確認する。"""
    if path.suffix != ".py":
        return True
    try:
        source = path.read_text("utf-8")
        ast.parse(source, filename=str(path))
        return True
    except (SyntaxError, UnicodeDecodeError) as exc:
        log.warning("構文エラーまたは読み込み失敗のため再起動を保留します (%s): %s",
                    path.name, exc)
        return False


class HotReloader:
    """バックグラウンドでファイル更新を監視し、待機中に自動再起動する。"""

    def __init__(self, is_idle_fn: Callable[[], bool],
                 on_restart_fn: Callable[[], None],
                 interval_s: float = 1.5) -> None:
        self.is_idle = is_idle_fn
        self.on_restart = on_restart_fn
        self.interval = interval_s
        self._mtimes: dict[Path, float] = {}
        self._pending: dict[Path, float] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._revision = int(time.time())

    @property
    def revision(self) -> int:
        return self._revision

    def start(self) -> None:
        if dryrun.enabled():
            return
        if not enabled():
            log.info("ホットリロードは無効です"
                     "（開発時のみ KOE_TYPE_HOT_RELOAD=1 で有効）")
            return
        # 初回のタイムスタンプ記録
        for f in _get_app_files():
            try:
                self._mtimes[f] = f.stat().st_mtime
            except OSError:
                pass

        self._thread = threading.Thread(
            target=self._loop, name="hot-reloader", daemon=True)
        self._thread.start()
        log.info("ホットリロード監視を開始しました（ファイル変更で自動反映）")

    def stop(self) -> None:
        self._stop.set()

    def _wait_for_change(self, handle: int | None) -> None:
        """ファイルが変わるまで待つ。

        ★前は 1.5 秒ごとに app の中の全ファイルを調べていた（待機中の
        CPU の一部。2026-10-11 に計測）。Windows の変更通知
        （FindFirstChangeNotification）で、変わったときだけ起きる。
        使えないときは、いままでどおり一定間隔で調べる。
        """
        if not handle:
            time.sleep(self.interval)
            return
        # 止めるときに抜けられるよう、5 秒ごとに一度は起きる
        if _kernel32.WaitForSingleObject(handle, 5000) == 0:
            _kernel32.FindNextChangeNotification(handle)
            time.sleep(0.3)             # 続けて保存されるのを少し待つ

    def _loop(self) -> None:
        handle = None
        try:
            handle = _kernel32.FindFirstChangeNotificationW(
                str(ROOT / "app"), True, 0x1 | 0x10)  # 名前・書き込み
            if handle in (None, 0, -1, _INVALID):
                handle = None
        except Exception:
            handle = None
        try:
            self._watch(handle)
        finally:
            if handle:
                _kernel32.FindCloseChangeNotification(handle)

    def _watch(self, handle: int | None) -> None:
        while not self._stop.is_set():
            self._wait_for_change(handle)
            changed_file = self._check_changes()
            if changed_file is not None:
                # 構文チェック
                if not _is_valid_python(changed_file):
                    time.sleep(1.0)
                    continue

                log.info("ファイル変更を検知しました: %s → 自動反映を準備中",
                         changed_file.name)
                # 編集の連続保存を考慮して少し待つ
                time.sleep(1.0)

                # 待機中になるまで待つ（録音・入力中は邪魔しない）
                for _ in range(60):
                    if self._stop.is_set():
                        return
                    if self.is_idle():
                        break
                    time.sleep(0.5)

                # ★全経路共通の再起動予算を必ず確認する。ファイル変更が
                # 続いても、予算を超えたらこのプロセスでは二度と
                # 起動し直さない（2026-10-24 のループ対策）。
                guard = RestartGuard(LOG_DIR / "restart-guard.json")
                ok, why = guard.try_acquire("reloader")
                if not ok:
                    log.error("ホットリロードによる再起動を止めます: %s", why)
                    return

                log.info("待機中を確認。最新コードを反映して再起動します…")
                self._revision = int(time.time())
                try:
                    autostart.relaunch()
                    self.on_restart()
                except Exception:
                    log.exception("ホットリロード再起動で例外")
                return

    def _check_changes(self) -> Path | None:
        """変わったファイルを 1 つ返す。

        ★新しく現れたファイルは「変更」ではない（2026-10-24 改修）。
        以前は未記録のファイルを即・変更として返していたため、起動後に
        app/ へファイルが 1 つ増えるだけで再起動が走った。いまは黙って
        記録するだけにする。
        ★変更は「2 回続けて同じ mtime で見えた」ときに確定する。
        保存の途中（書き込みの最中）の mtime で再起動しないため。
        """
        current_files = _get_app_files()
        for f in current_files:
            try:
                mtime = f.stat().st_mtime
            except OSError:
                continue
            last = self._mtimes.get(f)
            if last is None:
                self._mtimes[f] = mtime
                continue
            if mtime > last:
                seen = self._pending.get(f)
                if seen is not None and seen == mtime:
                    self._mtimes[f] = mtime
                    self._pending.pop(f, None)
                    return f
                self._pending[f] = mtime
        return None
