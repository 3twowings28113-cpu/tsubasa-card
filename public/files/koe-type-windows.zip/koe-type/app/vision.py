"""画面キャプチャと画像処理（Smart App Control 適合・ctypes のみ）。

指定されたウィンドウまたは全画面を GDI / GDI+ でキャプチャし、
JPEG バイト列として出力する。pip パッケージ（PIL など）は一切使わない。
`KOE_TYPE_DRY_RUN=1` のときは画面に触らず、最小限のダミー画像を返す。
"""

from __future__ import annotations

import ctypes
import logging
from ctypes import wintypes
from pathlib import Path
import tempfile

from . import clipgfx
from . import dryrun

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
gdiplus = ctypes.WinDLL("gdiplus", use_last_error=True)

# GDI+ 画像エンコーダーの CLSID
JPEG_ENCODER = clipgfx.guid("557CF401-1A04-11D3-9A73-0000F81EF32E")
PNG_ENCODER = clipgfx.guid("557CF406-1A04-11D3-9A73-0000F81EF32E")

# GdipCreateBitmapFromHBITMAP の引数定義
_vp = ctypes.c_void_p
_pvp = ctypes.POINTER(ctypes.c_void_p)
_i = ctypes.c_int

try:
    gdiplus.GdipCreateBitmapFromHBITMAP.argtypes = [
        wintypes.HBITMAP, wintypes.HPALETTE, _pvp
    ]
    gdiplus.GdipCreateBitmapFromHBITMAP.restype = _i
except AttributeError:
    pass

# gdi32 / user32 のプロトタイプ宣言。宣言なしだと戻り値・引数が
# 32bit 扱いになり、2^31 を超える HDC を渡すと OverflowError になる
# （snipping 側が宣言付きでフル幅の HDC を渡すようになり顕在化した。
# 2026-10-25 AI PC 実機: capture_dc_rect のサムネイル生成が HDC の
# 値しだいで時々失敗した）。snipping.py と宣言をそろえる。
gdi32.CreateCompatibleDC.restype = _vp
gdi32.CreateCompatibleDC.argtypes = [_vp]
gdi32.CreateCompatibleBitmap.restype = _vp
gdi32.CreateCompatibleBitmap.argtypes = [_vp, _i, _i]
gdi32.SelectObject.restype = _vp
gdi32.SelectObject.argtypes = [_vp, _vp]
gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.DeleteObject.argtypes = [_vp]
gdi32.DeleteDC.restype = wintypes.BOOL
gdi32.DeleteDC.argtypes = [_vp]
gdi32.BitBlt.restype = wintypes.BOOL
gdi32.BitBlt.argtypes = [_vp, _i, _i, _i, _i, _vp, _i, _i, wintypes.DWORD]
user32.GetDC.restype = _vp
user32.GetDC.argtypes = [_vp]
user32.ReleaseDC.restype = _i
user32.ReleaseDC.argtypes = [_vp, _vp]

# 1x1 ピクセルの最小限の有効な JPEG バイト列（テスト用）
DUMMY_JPEG = bytes.fromhex(
    "ffd8ffe000104a46494600010101004800480000ffdb00430008060607060508070707"
    "0909080a0c140d0c0b0b0c1912130f141d1a1f1e1d1a1c1c20242e2720222c231c1c28"
    "37292c30313434341f27393d38323c2e333432ffc0000b080001000101011100ffc400"
    "1f0000010501010101010100000000000000000102030405060708090a0bffda000801"
    "0100003f007f00ffd9"
)


def capture_window_or_screen(hwnd: int = 0, *,
                             rect: tuple[int, int, int, int] | None = None,
                             max_dimension: int = 1600) -> bytes:
    """指定ウィンドウまたは矩形（指定なしなら全画面）をキャプチャして JPEG を返す。"""
    if dryrun.enabled():
        return DUMMY_JPEG

    if not clipgfx.start():
        log.warning("GDI+ の起動に失敗したためキャプチャできません")
        return b""

    # キャプチャ領域の取得
    if rect is not None:
        rx, ry, rw, rh = rect
        x, y = rx, ry
        w = max(1, rw)
        h = max(1, rh)
    elif hwnd and user32.IsWindow(hwnd):
        w_rect = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(w_rect))
        x = w_rect.left
        y = w_rect.top
        w = max(1, w_rect.right - w_rect.left)
        h = max(1, w_rect.bottom - w_rect.top)
    else:
        # 全画面（仮想スクリーン全体）
        SM_XVIRTUALSCREEN = 76
        SM_YVIRTUALSCREEN = 77
        SM_CXVIRTUALSCREEN = 78
        SM_CYVIRTUALSCREEN = 79
        x = user32.GetSystemMetrics(SM_XVIRTUALSCREEN)
        y = user32.GetSystemMetrics(SM_YVIRTUALSCREEN)
        w = max(1, user32.GetSystemMetrics(SM_CXVIRTUALSCREEN))
        h = max(1, user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))

    hdc_screen = user32.GetDC(0)
    if not hdc_screen:
        return b""

    hdc_mem = 0
    hbm = 0
    old_bmp = 0
    gp_bmp = ctypes.c_void_p()
    try:
        hdc_mem = gdi32.CreateCompatibleDC(hdc_screen)
        hbm = gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
        old_bmp = gdi32.SelectObject(hdc_mem, hbm)

        # 画面からコピー（SRCCOPY = 0x00CC0020 | CAPTUREBLT = 0x40000000）
        SRCCOPY_CAPTUREBLT = 0x00CC0020 | 0x40000000
        gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_screen, x, y, SRCCOPY_CAPTUREBLT)

        gdi32.SelectObject(hdc_mem, old_bmp)
        old_bmp = 0

        res = gdiplus.GdipCreateBitmapFromHBITMAP(hbm, 0, ctypes.byref(gp_bmp))
        if res != 0 or not gp_bmp:
            log.warning("GdipCreateBitmapFromHBITMAP に失敗しました: %d", res)
            return b""
    finally:
        if old_bmp and hdc_mem:
            gdi32.SelectObject(hdc_mem, old_bmp)
        if hdc_mem:
            gdi32.DeleteDC(hdc_mem)
        if hbm:
            gdi32.DeleteObject(hbm)
        user32.ReleaseDC(0, hdc_screen)

    return _bitmap_to_jpeg(gp_bmp, max_dimension=max_dimension)


def _bitmap_to_jpeg(gp_bmp: ctypes.c_void_p, max_dimension: int = 1600) -> bytes:
    """GDI+ ビットマップを指定サイズ以下に縮小し JPEG バイト列を生成する。"""
    try:
        orig_w, orig_h = clipgfx.image_size(gp_bmp)
        target_bmp = gp_bmp
        need_dispose_scaled = False

        if orig_w > max_dimension or orig_h > max_dimension:
            scale = min(max_dimension / orig_w, max_dimension / orig_h)
            nw = max(1, int(orig_w * scale))
            nh = max(1, int(orig_h * scale))
            scaled = clipgfx._scaled_copy(gp_bmp, nw, nh)
            if scaled:
                target_bmp = scaled
                need_dispose_scaled = True

        tmp = Path(tempfile.gettempdir()) / f"koe_cap_{id(gp_bmp)}.jpg"
        try:
            save_res = gdiplus.GdipSaveImageToFile(
                target_bmp, str(tmp), ctypes.byref(JPEG_ENCODER), None
            )
            if save_res == 0 and tmp.exists():
                return tmp.read_bytes()
            log.warning("JPEG 保存に失敗しました: %d", save_res)
            return b""
        finally:
            tmp.unlink(missing_ok=True)
            if need_dispose_scaled:
                gdiplus.GdipDisposeImage(target_bmp)
    finally:
        gdiplus.GdipDisposeImage(gp_bmp)


def capture_dc_rect(hdc_src: int, x: int, y: int, w: int, h: int,
                    max_dimension: int = 1600) -> bytes:
    """指定された DC の矩形領域から直接 JPEG バイト列を生成する。"""
    if dryrun.enabled():
        return DUMMY_JPEG
    if not hdc_src or w <= 0 or h <= 0 or not clipgfx.start():
        return b""

    hdc_mem = gdi32.CreateCompatibleDC(hdc_src)
    hbm = gdi32.CreateCompatibleBitmap(hdc_src, w, h)
    old_bmp = gdi32.SelectObject(hdc_mem, hbm)

    gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_src, x, y, 0x00CC0020)
    gdi32.SelectObject(hdc_mem, old_bmp)
    gdi32.DeleteDC(hdc_mem)

    gp_bmp = ctypes.c_void_p()
    res = gdiplus.GdipCreateBitmapFromHBITMAP(hbm, 0, ctypes.byref(gp_bmp))
    gdi32.DeleteObject(hbm)

    if res != 0 or not gp_bmp:
        log.warning("capture_dc_rect で GdipCreateBitmapFromHBITMAP 失敗: %d", res)
        return b""

    return _bitmap_to_jpeg(gp_bmp, max_dimension=max_dimension)


def capture_dc_png(hdc_src: int, x: int, y: int, w: int, h: int) -> bytes:
    """指定された DC の矩形領域から直接 PNG バイト列を生成する。"""
    if dryrun.enabled():
        return b"\x89PNG\r\n\x1a\n"
    if not hdc_src or w <= 0 or h <= 0 or not clipgfx.start():
        return b""

    hdc_mem = gdi32.CreateCompatibleDC(hdc_src)
    hbm = gdi32.CreateCompatibleBitmap(hdc_src, w, h)
    old_bmp = gdi32.SelectObject(hdc_mem, hbm)

    gdi32.BitBlt(hdc_mem, 0, 0, w, h, hdc_src, x, y, 0x00CC0020)
    gdi32.SelectObject(hdc_mem, old_bmp)
    gdi32.DeleteDC(hdc_mem)

    gp_bmp = ctypes.c_void_p()
    res = gdiplus.GdipCreateBitmapFromHBITMAP(hbm, 0, ctypes.byref(gp_bmp))
    gdi32.DeleteObject(hbm)

    if res != 0 or not gp_bmp:
        log.warning("capture_dc_png で GdipCreateBitmapFromHBITMAP 失敗: %d", res)
        return b""

    tmp = Path(tempfile.gettempdir()) / f"koe_cap_{id(gp_bmp)}.png"
    try:
        save_res = gdiplus.GdipSaveImageToFile(
            gp_bmp, str(tmp), ctypes.byref(PNG_ENCODER), None
        )
        if save_res == 0 and tmp.exists():
            return tmp.read_bytes()
        return b""
    finally:
        tmp.unlink(missing_ok=True)
        gdiplus.GdipDisposeImage(gp_bmp)

