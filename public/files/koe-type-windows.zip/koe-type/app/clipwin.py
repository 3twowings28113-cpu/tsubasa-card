"""クリップボード履歴の本体。専用のスレッドで、見張り・ショートカット・窓を持つ。

なぜ専用のスレッドか
  ・音声入力（win スレッド）と分けておけば、クリップボードの側で何かが
    詰まっても、録音のショートカットや帯は止まらない
  ・画像を PNG にするような重い仕事は、さらに別の「clip-store」
    スレッドで行う。窓の動きを待たせないため

入力を止めない作り（AGENTS.md の決まり）
  ・ショートカットは RegisterHotKey（低レベルのフックは使わない）
  ・クリップボードの変化は AddClipboardFormatListener で**知らせてもらう**
    （ほかのアプリを待たせない。見張りの窓はメッセージ専用の窓）
  ・窓の中のキーは、窓が前に出ているときにふつうに受け取るだけ

から打ちモード（KOE_TYPE_DRY_RUN=1）では
  ・見張りもショートカットも付けない
  ・窓は作るが画面には出さない（描いた絵は snapshot() で取り出せる）
  ・クリップボードへは書かず、貼り付けのキーも送らない（記録だけ）
"""

from __future__ import annotations

import ctypes
import logging
import os
import queue
import subprocess
import threading
import time
from ctypes import wintypes
from pathlib import Path
from typing import Any, Callable

from . import clipdata, clipdrag, clipgfx, clipstore, dryrun, hotkeys
from . import inject, theme
from .clipmodel import Command, PopupModel, Tab, expand, look, transform
from .clipstore import DOWNLOADS, FREQUENT, HISTORY, ClipStore, Payload
from .clipview import ClipView, app_label
from .i18n import language, t
from .recentfiles import IMAGE_EXT, RecentFiles
from .recipes import RecipeModel, RecipeView, from_config
from .inputwatch import WM_HOTKEY, Hotkeys

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
dwmapi = ctypes.WinDLL("dwmapi")
comdlg32 = ctypes.WinDLL("comdlg32", use_last_error=True)

_vp = ctypes.c_void_p
LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wintypes.HWND, wintypes.UINT,
                             wintypes.WPARAM, wintypes.LPARAM)

# ---------------------------------------------------------------- Win32

WM_DESTROY, WM_SIZE, WM_ACTIVATE = 0x0002, 0x0005, 0x0006
WM_PAINT, WM_CLOSE, WM_ERASEBKGND = 0x000F, 0x0010, 0x0014
WM_SETTINGCHANGE, WM_SETCURSOR, WM_GETMINMAXINFO = 0x001A, 0x0020, 0x0024
WM_NCCALCSIZE, WM_NCHITTEST, WM_NCACTIVATE = 0x0083, 0x0084, 0x0086
WM_KEYDOWN, WM_CHAR, WM_SYSKEYDOWN, WM_SYSCHAR = 0x100, 0x102, 0x104, 0x106
WM_IME_STARTCOMPOSITION, WM_IME_COMPOSITION = 0x010D, 0x010F
WM_SYSCOMMAND, WM_TIMER = 0x0112, 0x0113
WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP = 0x0200, 0x0201, 0x0202
WM_LBUTTONDBLCLK, WM_RBUTTONUP, WM_MOUSEWHEEL = 0x0203, 0x0205, 0x020A
WM_EXITSIZEMOVE, WM_MOUSELEAVE = 0x0232, 0x02A3
WM_DPICHANGED, WM_CLIPBOARDUPDATE = 0x02E0, 0x031D
WM_APP = 0x8000
WM_APP_RUN = WM_APP + 1          # 頼まれた仕事（queue）を、このスレッドで行う
WM_APP_REFRESH = WM_APP + 2      # 中身が変わった（窓が出ていれば描き直す）

HTCLIENT, HTCAPTION = 1, 2
HT_EDGES = {(-1, 0): 10, (1, 0): 11, (0, -1): 12, (-1, -1): 13,
            (1, -1): 14, (0, 1): 15, (-1, 1): 16, (1, 1): 17}
SC_KEYMENU = 0xF100
WA_INACTIVE = 0

WS_POPUP, WS_THICKFRAME = 0x80000000, 0x00040000
WS_CLIPCHILDREN = 0x02000000
WS_EX_TOOLWINDOW, WS_EX_TOPMOST, WS_EX_LAYERED = 0x80, 0x8, 0x80000
WS_EX_TRANSPARENT = 0x20
GWL_EXSTYLE = -20
CS_DBLCLKS = 0x0008
SWP_NOSIZE, SWP_NOMOVE, SWP_NOZORDER = 0x1, 0x2, 0x4
SWP_NOACTIVATE, SWP_FRAMECHANGED, SWP_SHOWWINDOW = 0x10, 0x20, 0x40
SW_HIDE, SW_SHOW = 0, 5
HWND_TOPMOST = -1
HWND_MESSAGE = -3
LWA_ALPHA = 0x2
IDC_ARROW, IDC_IBEAM, IDC_HAND = 32512, 32513, 32649
SM_CXDRAG, SM_CYDRAG = 68, 69
VK_SHIFT, VK_CONTROL, VK_MENU, VK_F4 = 0x10, 0x11, 0x12, 0x73
MK_LBUTTON = 0x0001
TPM_RETURNCMD, TPM_RIGHTBUTTON, TPM_NONOTIFY = 0x100, 0x2, 0x80
MF_STRING, MF_GRAYED, MF_POPUP, MF_SEPARATOR = 0x0, 0x1, 0x10, 0x800
MONITOR_DEFAULTTONEAREST, MONITOR_DEFAULTTONULL = 2, 0
TME_LEAVE = 0x2

CAPTURE_TIMER = 1
RESTORE_TIMER = 2
SECRET_TIMER = 3
NOTE_TIMER = 4
RECIPE_HOLD_TIMER = 5
KEYS_CHECK_TIMER = 6

ID_CLIP = 0xB001
ID_RECIPE = 0xB002
ID_GROUP_BASE = 0xB100

# メニューの番号
M_PASTE, M_PLAIN, M_COPY, M_PIN, M_EDIT = 1, 2, 3, 4, 5
M_OPEN, M_FOLDER, M_SAVE, M_DELETE, M_SETTINGS = 6, 7, 8, 9, 10
M_TO_HISTORY, M_NEW_GROUP = 11, 12
M_TRANSFORM = 100       # 100 + 加工の番号
M_GROUP = 1000          # 1000 + グループの id


class POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [("style", wintypes.UINT), ("lpfnWndProc", _vp),
                ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                ("hInstance", wintypes.HINSTANCE), ("hIcon", wintypes.HICON),
                ("hCursor", wintypes.HANDLE),
                ("hbrBackground", wintypes.HANDLE),
                ("lpszMenuName", wintypes.LPCWSTR),
                ("lpszClassName", wintypes.LPCWSTR)]


class PAINTSTRUCT(ctypes.Structure):
    _fields_ = [("hdc", wintypes.HDC), ("fErase", wintypes.BOOL),
                ("rcPaint", RECT), ("fRestore", wintypes.BOOL),
                ("fIncUpdate", wintypes.BOOL),
                ("rgbReserved", ctypes.c_byte * 32)]


class MSG(ctypes.Structure):
    _fields_ = [("hwnd", wintypes.HWND), ("message", wintypes.UINT),
                ("wParam", wintypes.WPARAM), ("lParam", wintypes.LPARAM),
                ("time", wintypes.DWORD), ("pt", POINT),
                ("lPrivate", wintypes.DWORD)]


class MINMAXINFO(ctypes.Structure):
    _fields_ = [("ptReserved", POINT), ("ptMaxSize", POINT),
                ("ptMaxPosition", POINT), ("ptMinTrackSize", POINT),
                ("ptMaxTrackSize", POINT)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", RECT),
                ("rcWork", RECT), ("dwFlags", wintypes.DWORD)]


class MARGINS(ctypes.Structure):
    _fields_ = [("l", ctypes.c_int), ("r", ctypes.c_int),
                ("t", ctypes.c_int), ("b", ctypes.c_int)]


class TRACKMOUSEEVENT(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("hwndTrack", wintypes.HWND), ("dwHoverTime", wintypes.DWORD)]


class GUITHREADINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("flags", wintypes.DWORD),
                ("hwndActive", wintypes.HWND), ("hwndFocus", wintypes.HWND),
                ("hwndCapture", wintypes.HWND),
                ("hwndMenuOwner", wintypes.HWND),
                ("hwndMoveSize", wintypes.HWND),
                ("hwndCaret", wintypes.HWND), ("rcCaret", RECT)]


class COMPOSITIONFORM(ctypes.Structure):
    _fields_ = [("dwStyle", wintypes.DWORD), ("ptCurrentPos", POINT),
                ("rcArea", RECT)]


class CANDIDATEFORM(ctypes.Structure):
    _fields_ = [("dwIndex", wintypes.DWORD), ("dwStyle", wintypes.DWORD),
                ("ptCurrentPos", POINT), ("rcArea", RECT)]


class OPENFILENAMEW(ctypes.Structure):
    _fields_ = [("lStructSize", wintypes.DWORD), ("hwndOwner", wintypes.HWND),
                ("hInstance", wintypes.HINSTANCE),
                ("lpstrFilter", wintypes.LPCWSTR),
                ("lpstrCustomFilter", wintypes.LPWSTR),
                ("nMaxCustFilter", wintypes.DWORD),
                ("nFilterIndex", wintypes.DWORD),
                ("lpstrFile", wintypes.LPWSTR), ("nMaxFile", wintypes.DWORD),
                ("lpstrFileTitle", wintypes.LPWSTR),
                ("nMaxFileTitle", wintypes.DWORD),
                ("lpstrInitialDir", wintypes.LPCWSTR),
                ("lpstrTitle", wintypes.LPCWSTR), ("Flags", wintypes.DWORD),
                ("nFileOffset", wintypes.WORD),
                ("nFileExtension", wintypes.WORD),
                ("lpstrDefExt", wintypes.LPCWSTR),
                ("lCustData", wintypes.LPARAM), ("lpfnHook", _vp),
                ("lpTemplateName", wintypes.LPCWSTR), ("pvReserved", _vp),
                ("dwReserved", wintypes.DWORD), ("FlagsEx", wintypes.DWORD)]


def _sig(dll: Any, name: str, args: list, ret: Any) -> None:
    fn = getattr(dll, name)
    fn.argtypes = args
    fn.restype = ret


for _n, _a, _r in (
    ("RegisterClassW", [ctypes.POINTER(WNDCLASSW)], wintypes.ATOM),
    ("CreateWindowExW", [wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR,
                         wintypes.DWORD, ctypes.c_int, ctypes.c_int,
                         ctypes.c_int, ctypes.c_int, wintypes.HWND,
                         wintypes.HMENU, wintypes.HINSTANCE, _vp],
     wintypes.HWND),
    ("DestroyWindow", [wintypes.HWND], wintypes.BOOL),
    ("DefWindowProcW", [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                        wintypes.LPARAM], LRESULT),
    ("PostMessageW", [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                      wintypes.LPARAM], wintypes.BOOL),
    ("GetMessageW", [ctypes.POINTER(MSG), wintypes.HWND, wintypes.UINT,
                     wintypes.UINT], ctypes.c_int),
    ("TranslateMessage", [ctypes.POINTER(MSG)], wintypes.BOOL),
    ("DispatchMessageW", [ctypes.POINTER(MSG)], LRESULT),
    ("PostQuitMessage", [ctypes.c_int], None),
    ("ShowWindow", [wintypes.HWND, ctypes.c_int], wintypes.BOOL),
    ("IsWindowVisible", [wintypes.HWND], wintypes.BOOL),
    ("IsWindow", [wintypes.HWND], wintypes.BOOL),
    ("SetWindowPos", [wintypes.HWND, wintypes.HWND, ctypes.c_int,
                      ctypes.c_int, ctypes.c_int, ctypes.c_int,
                      wintypes.UINT], wintypes.BOOL),
    ("GetWindowRect", [wintypes.HWND, ctypes.POINTER(RECT)], wintypes.BOOL),
    ("GetClientRect", [wintypes.HWND, ctypes.POINTER(RECT)], wintypes.BOOL),
    ("ScreenToClient", [wintypes.HWND, ctypes.POINTER(POINT)],
     wintypes.BOOL),
    ("ClientToScreen", [wintypes.HWND, ctypes.POINTER(POINT)],
     wintypes.BOOL),
    ("SetForegroundWindow", [wintypes.HWND], wintypes.BOOL),
    ("GetForegroundWindow", [], wintypes.HWND),
    ("SetFocus", [wintypes.HWND], wintypes.HWND),
    ("InvalidateRect", [wintypes.HWND, _vp, wintypes.BOOL], wintypes.BOOL),
    ("UpdateWindow", [wintypes.HWND], wintypes.BOOL),
    ("BeginPaint", [wintypes.HWND, ctypes.POINTER(PAINTSTRUCT)],
     wintypes.HDC),
    ("EndPaint", [wintypes.HWND, ctypes.POINTER(PAINTSTRUCT)],
     wintypes.BOOL),
    ("SetTimer", [wintypes.HWND, ctypes.c_size_t, wintypes.UINT, _vp],
     ctypes.c_size_t),
    ("KillTimer", [wintypes.HWND, ctypes.c_size_t], wintypes.BOOL),
    ("GetKeyState", [ctypes.c_int], ctypes.c_short),
    # ★GetAsyncKeyState は長らく型宣言なしで呼ばれていた（戻り値は
    # SHORT なのに int として読む）。たまたま動いていたが、宣言を入れる。
    ("GetAsyncKeyState", [ctypes.c_int], ctypes.c_short),
    ("GetCursorPos", [ctypes.POINTER(POINT)], wintypes.BOOL),
    ("SetCursor", [wintypes.HANDLE], wintypes.HANDLE),
    ("LoadCursorW", [wintypes.HINSTANCE, _vp], wintypes.HANDLE),
    ("SetCapture", [wintypes.HWND], wintypes.HWND),
    ("ReleaseCapture", [], wintypes.BOOL),
    ("TrackMouseEvent", [ctypes.POINTER(TRACKMOUSEEVENT)], wintypes.BOOL),
    ("GetSystemMetrics", [ctypes.c_int], ctypes.c_int),
    ("MonitorFromPoint", [POINT, wintypes.DWORD], wintypes.HANDLE),
    ("MonitorFromWindow", [wintypes.HWND, wintypes.DWORD], wintypes.HANDLE),
    ("GetMonitorInfoW", [wintypes.HANDLE, ctypes.POINTER(MONITORINFO)],
     wintypes.BOOL),
    ("GetWindowThreadProcessId", [wintypes.HWND,
                                  ctypes.POINTER(wintypes.DWORD)],
     wintypes.DWORD),
    ("GetGUIThreadInfo", [wintypes.DWORD, ctypes.POINTER(GUITHREADINFO)],
     wintypes.BOOL),
    ("CreatePopupMenu", [], wintypes.HMENU),
    ("AppendMenuW", [wintypes.HMENU, wintypes.UINT, ctypes.c_size_t,
                     wintypes.LPCWSTR], wintypes.BOOL),
    ("TrackPopupMenu", [wintypes.HMENU, wintypes.UINT, ctypes.c_int,
                        ctypes.c_int, ctypes.c_int, wintypes.HWND, _vp],
     wintypes.BOOL),
    ("DestroyMenu", [wintypes.HMENU], wintypes.BOOL),
    ("GetWindowLongPtrW", [wintypes.HWND, ctypes.c_int], ctypes.c_ssize_t),
    ("SetWindowLongPtrW", [wintypes.HWND, ctypes.c_int, ctypes.c_ssize_t],
     ctypes.c_ssize_t),
    ("SetLayeredWindowAttributes", [wintypes.HWND, wintypes.COLORREF,
                                    wintypes.BYTE, wintypes.DWORD],
     wintypes.BOOL),
    ("CreateCaret", [wintypes.HWND, wintypes.HBITMAP, ctypes.c_int,
                     ctypes.c_int], wintypes.BOOL),
    ("SetCaretPos", [ctypes.c_int, ctypes.c_int], wintypes.BOOL),
    ("DestroyCaret", [], wintypes.BOOL),
    ("GetDC", [wintypes.HWND], wintypes.HDC),
    ("ReleaseDC", [wintypes.HWND, wintypes.HDC], ctypes.c_int),
    ("AttachThreadInput", [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL],
     wintypes.BOOL),
    ("BringWindowToTop", [wintypes.HWND], wintypes.BOOL),
    ("UnregisterClassW", [wintypes.LPCWSTR, wintypes.HINSTANCE],
     wintypes.BOOL),
):
    _sig(user32, _n, _a, _r)
kernel32.GetCurrentThreadId.restype = wintypes.DWORD
if hasattr(user32, "GetDpiForWindow"):
    _sig(user32, "GetDpiForWindow", [wintypes.HWND], wintypes.UINT)
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = wintypes.HMODULE
dwmapi.DwmExtendFrameIntoClientArea.argtypes = [wintypes.HWND,
                                                ctypes.POINTER(MARGINS)]
dwmapi.DwmSetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD,
                                         _vp, wintypes.DWORD]
comdlg32.GetSaveFileNameW.argtypes = [ctypes.POINTER(OPENFILENAMEW)]
comdlg32.GetSaveFileNameW.restype = wintypes.BOOL

try:
    imm32 = ctypes.WinDLL("imm32", use_last_error=True)
    _sig(imm32, "ImmGetContext", [wintypes.HWND], _vp)
    _sig(imm32, "ImmReleaseContext", [wintypes.HWND, _vp], wintypes.BOOL)
    _sig(imm32, "ImmSetCompositionWindow",
         [_vp, ctypes.POINTER(COMPOSITIONFORM)], wintypes.BOOL)
    _sig(imm32, "ImmSetCandidateWindow",
         [_vp, ctypes.POINTER(CANDIDATEFORM)], wintypes.BOOL)
except (OSError, AttributeError):
    imm32 = None

# 変わったら、見張りやショートカットを付け直す設定。
# 窓の位置・大きさ（clip_pos_x など）は、次に開くときに読むだけでよい。
# ここに入れてしまうと、窓を動かすたびにショートカットを付け直していた。
RECONFIGURE_KEYS = frozenset({
    "clip_enabled", "clip_hotkey", "clip_font_size", "clip_preview",
    "clip_rows", "clip_show_numbers", "clip_click", "theme", "hotkey",
    "recipe_hotkey", "clip_downloads"})


def parse_key(spec: str) -> tuple[int, frozenset[str]]:
    """"alt+v" を (仮想キー, 修飾キー) にする。読めなければ (0, ∅)。

    ★winthread.parse_hotkey は、読めないキー名を黙って Ctrl+Space に
    置き換える（録音キー向けの作り）。ここで使うと、グループ専用のキー
    などに変な値が入ったときに Ctrl+Space を横取りしてしまうので、
    読めなければ何も登録しない。
    """
    from .winthread import MOD_NAMES, VK_NAMES  # noqa: PLC0415
    mods: set[str] = set()
    key = 0
    for part in str(spec).lower().replace(" ", "").split("+"):
        if not part:
            continue
        if part in MOD_NAMES:
            mods.add(MOD_NAMES[part])
        elif part in VK_NAMES and not key:
            key = VK_NAMES[part]
        else:
            return (0, frozenset())
    return (key, frozenset(mods))


def _lo(value: int) -> int:
    return ctypes.c_short(value & 0xFFFF).value


def _hi(value: int) -> int:
    return ctypes.c_short((value >> 16) & 0xFFFF).value


def _down(vk: int) -> bool:
    return bool(user32.GetKeyState(vk) & 0x8000)


# ---------------------------------------------------------------- 本体


class ClipService(threading.Thread):
    """クリップボード履歴。main.Controller から start() / stop() する。

    外から呼んでよいのは、start / stop / configure / open / api /
    image_bytes / toggle_pause / snapshot / simulate_* だけ。
    どれも、窓や一覧に触る仕事は call() でこのスレッドへ渡す。
    """

    def __init__(self, cfg, *,  # noqa: ANN001
                 store: ClipStore | None = None,
                 notify: Callable[[str], None] = lambda _m: None,
                 open_settings: Callable[[int], None] = lambda _i: None,
                 last_target: Callable[[], int] = lambda: 0,
                 start_recipe: Callable[[str], None] = lambda _i: None,
                 is_recording: Callable[[], bool] = lambda: False,
                 stop_recording: Callable[[], None] = lambda: None,
                 is_busy: Callable[[], bool] = lambda: False,
                 on_screen_assistant: Callable[[], None] | None = None) -> None:
        super().__init__(name="clip", daemon=True)
        self.cfg = cfg
        self._notify = notify
        self._open_settings = open_settings
        self._last_target = last_target
        # 文章変換のレシピ一覧（同じ窓の仕組みを使う。app/recipes.py）
        self._start_recipe = start_recipe
        self._is_recording = is_recording
        self._stop_recording = stop_recording
        self._is_busy = is_busy
        self._on_screen_assistant = on_screen_assistant
        self._recipe_vk = 0
        self._recipe_press_start = 0.0
        self._recipe_held = False
        self.store = store or ClipStore()
        self.headless = dryrun.enabled()
        self.paused = False            # トレイの「一時停止」（覚えない）
        self.view = ClipView()
        self.model = PopupModel(self._tabs, self._items)
        self.mode = "clip"             # 窓に出しているもの（clip / recipe）
        # 「ダウンロード」タブ：最近 PC に入ってきたファイル（保存しない）
        self.recent = RecentFiles(self._recent_settings,
                                  on_update=self.refresh)
        self._virtual: dict[int, clipstore.Clip] = {}
        # 探す場所を差し替える（試験用）。から打ちでは、差し替えが
        # なければ何も探さない＝利用者のフォルダを試験が読まない
        self.recent_roots: list | None = [] if self.headless else None
        self.rmodel = RecipeModel(self._recipe_items)
        self.rview = RecipeView(self.view)
        self._jobs: queue.Queue[Callable[[], None]] = queue.Queue()
        self._work: queue.Queue[clipdata.Captured | None] = queue.Queue()
        self._ready = threading.Event()
        self._host = 0                 # 見張り用（メッセージ専用の窓）
        self._hwnd = 0                 # ポップアップ
        self._hinst = 0
        self.visible = False
        self._target = 0               # 貼る先の窓
        self._scale = 1.0
        self._canvas: clipgfx.Canvas | None = None
        self._dirty = True
        self._thumbs: dict[tuple[int, int, int], tuple[int, int, int]] = {}
        self._keys: Hotkeys | None = None
        self._group_keys: dict[int, int] = {}     # hotkey id -> group id
        # 登録したいキーの控え（id -> (修飾キー, vk) / グループ id）。
        # 登録に失敗したキーを後から付け直すときに使う。
        self._want_keys: dict[int, tuple[frozenset, int]] = {}
        self._want_groups: dict[int, int] = {}
        self._key_sign: tuple = ()
        self._own_seqs: list[int] = []
        self._capture_tries = 0
        self._captures = 0
        self._purge_rows: list[dict] = []
        self._restore: list | None = None
        self._secret_seq = 0
        self._press: tuple[int, int, int] | None = None
        self._last_move = (-1, -1)
        self._tracking = False
        self._modal = 0
        self._high_surrogate = ""
        self._caret_h = -1
        self._full_cache: tuple[int, str] = (0, "")
        self._listening = False
        self._last_seq = 0
        self._last_hash = ""
        self._proc_host = WNDPROC(self._host_proc)
        self._proc_popup = WNDPROC(self._popup_proc)
        # ★窓の種類の名前は、この本体ごとに変える。同じ名前で 2 つ目を
        # 作ると、Windows は 1 つ目の登録（1 つ目の本体の関数）を使い続け、
        # 2 つ目への知らせが 1 つ目に届いた（試験で発覚。片付けた関数を
        # 呼べば落ちる）。終わるときに登録も外す。
        tag = f"{os.getpid():x}{id(self):x}"
        self._host_class = f"KoeTypeClipHost{tag}"
        self._popup_class = f"KoeTypeClipPopup{tag}"
        self.last_error = ""

    # ============================================================ 外から

    def start(self) -> None:  # noqa: D102
        super().start()
        self._ready.wait(5.0)
        threading.Thread(target=self._store_loop, name="clip-store",
                         daemon=True).start()

    def stop(self) -> None:
        self._work.put(None)
        if self._host:
            user32.PostMessageW(self._host, WM_CLOSE, 0, 0)

    def call(self, fn: Callable[[], None]) -> None:
        """fn をこのスレッドで行う（窓と一覧はこのスレッドのもの）。"""
        self._jobs.put(fn)
        if self._host:
            user32.PostMessageW(self._host, WM_APP_RUN, 0, 0)

    def configure(self) -> None:
        self.call(self._configure)

    def open(self, gid: int | None = None, *, target: int = 0) -> None:
        self.call(lambda: self._show(gid, target=target))

    def refresh(self) -> None:
        if self._host:
            user32.PostMessageW(self._host, WM_APP_REFRESH, 0, 0)

    def toggle_pause(self) -> bool:
        self.paused = not self.paused
        log.info("クリップボードの記録: %s",
                 "一時停止" if self.paused else "再開")
        return self.paused

    @property
    def enabled(self) -> bool:
        return self.cfg.bool_("clip_enabled", True)

    # ============================================================ スレッド

    def run(self) -> None:
        try:
            self._setup()
        except Exception as exc:  # noqa: BLE001
            log.exception("クリップボード履歴を始められませんでした")
            self.last_error = str(exc)
            self._ready.set()
            return
        self._ready.set()
        msg = MSG()
        result = 1
        try:
            while result > 0:
                result = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if result > 0:
                    user32.TranslateMessage(ctypes.byref(msg))
                    user32.DispatchMessageW(ctypes.byref(msg))
        except Exception:
            # 黙って抜けると「一覧がいつの間にか死んでいる」になる
            # （2026-10-31 監査: 静かに死ぬ系）。必ず記録を残す。
            log.exception("クリップボード履歴のメッセージループで例外")
        if result < 0:
            # GetMessageW のエラー戻り。これも異常終了として残す。
            log.error("クリップボード履歴のメッセージループが異常"
                      "終了しました (err=%d)", ctypes.get_last_error())
            self.last_error = "メッセージループが異常終了しました"
        log.info("クリップボード履歴の見張りを終えます")
        self._teardown()

    def _setup(self) -> None:
        clipdrag.init_thread()
        clipgfx.start()
        self._hinst = kernel32.GetModuleHandleW(None)
        for name, proc, style in ((self._host_class, self._proc_host, 0),
                                  (self._popup_class, self._proc_popup,
                                   CS_DBLCLKS)):
            cls = WNDCLASSW()
            cls.style = style
            cls.lpfnWndProc = ctypes.cast(proc, _vp)
            cls.hInstance = self._hinst
            cls.hCursor = user32.LoadCursorW(None, _vp(IDC_ARROW))
            cls.lpszClassName = name
            if not user32.RegisterClassW(ctypes.byref(cls)):
                err = ctypes.get_last_error()
                if err != 1410:        # ERROR_CLASS_ALREADY_EXISTS
                    raise OSError(f"RegisterClassW {name} err={err}")
        # メッセージ専用の窓：画面に出ず、ほかのアプリからの一斉送信も
        # 受けない（受けると、こちらが忙しいときに相手を待たせる）
        self._host = user32.CreateWindowExW(
            0, self._host_class, "koe-type clip", 0, 0, 0, 0, 0,
            wintypes.HWND(HWND_MESSAGE), None, self._hinst, None)
        if not self._host:
            raise OSError(f"見張りの窓を作れません err="
                          f"{ctypes.get_last_error()}")
        self.store.ensure_default_groups([t("clip.default_group")])
        self._configure()
        # 登録に失敗したキーの見張り（付け直しは失敗があるときだけ）
        user32.SetTimer(self._host, KEYS_CHECK_TIMER, 2000, None)
        threading.Thread(target=self._housekeeping, name="clip-clean",
                         daemon=True).start()
        log.info("クリップボード履歴を用意しました（%s）",
                 "から打ち" if self.headless else "見張り中")

    def _teardown(self) -> None:
        # ★段ごとに分けて守る。1 つの try にまとめると、途中で
        # 失敗した段より後ろが全部飛ばされ、静かに残る
        # （2026-10-31 監査: 静かに死ぬ系）。失敗は段ごとに記録し、
        # 残りの片付けは必ず最後まで行う。
        def step(fn) -> None:  # noqa: ANN001
            try:
                fn()
            except Exception:
                log.exception("クリップボード履歴の後片付けで例外")

        if self._listening:
            step(lambda: clipdata.unlisten(self._host))
        if self._keys is not None:
            step(self._keys.clear)

        def dispose_thumbs() -> None:
            for bmp, _w, _h in self._thumbs.values():
                clipgfx.dispose(bmp)
            self._thumbs.clear()

        step(dispose_thumbs)
        if self._canvas is not None:
            step(self._canvas.close)
        step(self.view.fonts.clear)

        def destroy_windows() -> None:
            for hwnd in (self._hwnd, self._host):
                if hwnd:
                    user32.DestroyWindow(hwnd)
            self._hwnd = self._host = 0

        step(destroy_windows)

        def unregister() -> None:
            for name in (self._popup_class, self._host_class):
                user32.UnregisterClassW(name, self._hinst)

        step(unregister)
        step(lambda: self.store.purge_files(self._purge_rows))
        clipdrag.done_thread()

    def _housekeeping(self) -> None:
        """起動のときに 1 回だけ：古い履歴と、残った画像を片付ける。"""
        try:
            time.sleep(3.0)
            self._trim()
            self.store.orphan_images()
            clipdrag.clean_drag_dir()
            if self.cfg.str_("clip_downloads", "end") != "off":
                self.recent.refresh()
        except Exception:
            log.exception("クリップボード履歴の片付けで例外")

    def _trim(self) -> None:
        self.store.trim(max_items=self.cfg.int_("clip_max_items", 500),
                        keep_days=self.cfg.int_("clip_keep_days", 30))

    # ------------------------------------------------------------ 設定

    def _configure(self) -> None:
        """設定を読み直し、見張りとショートカットを付け外しする。"""
        cfg = self.cfg
        on = self.enabled
        label = hotkeys.label(cfg.str_("clip_hotkey", "alt+v"))
        self.view.configure(
            theme=theme.resolve(cfg.str_("theme", "system")),
            accent=theme.accent_color(),
            font_size=cfg.str_("clip_font_size", "medium"),
            preview=cfg.str_("clip_preview", "right"),
            two_lines=cfg.str_("clip_rows", "two") == "two",
            show_meta=True,
            show_numbers=cfg.bool_("clip_show_numbers", True),
            hotkey_label=label.replace(" ", ""))
        self.model.click_to_paste = cfg.str_("clip_click",
                                             "single") == "single"
        self.view.download_days = cfg.int_("clip_download_days", 7)
        self._dirty = True
        self._border_colour()
        if self.headless:
            return
        if on and not self._listening:
            self._listening = clipdata.listen(self._host)
            if not self._listening:
                log.warning("クリップボードを見張れません err=%s",
                            ctypes.get_last_error())
        elif not on and self._listening:
            clipdata.unlisten(self._host)
            self._listening = False
        self._register_keys(on)
        self._retry_failed_keys()
        if not on and self.visible:
            self._hide()

    def _register_keys(self, on: bool) -> None:
        # ★キーが変わったときだけ付け直す。前は Windows の設定が変わる
        # たび（テーマの切り替えなど）に全部を外して付け直していた。
        # そのすきに、ほかのアプリや音声入力側にキーを取られることがあり、
        # 失敗の知らせも毎回出ていた（レビューで発覚）。
        sign = (on, self.cfg.str_("clip_hotkey", ""),
                self.cfg.str_("recipe_hotkey", ""),
                tuple((g.id, g.hotkey) for g in self.store.groups()))
        if self._keys is not None and sign == self._key_sign:
            return
        self._key_sign = sign
        if self._keys is None:
            self._keys = Hotkeys(self._host)
        self._keys.clear()
        self._group_keys.clear()
        self._want_keys.clear()
        self._want_groups.clear()
        # 文章変換のレシピ一覧のキーは、クリップボード履歴を切っていても効く
        spec = self.cfg.str_("recipe_hotkey", "").strip()
        self._recipe_vk = 0
        if spec:
            vk, mods = parse_key(spec)
            self._recipe_vk = vk
            if vk:
                self._want_keys[ID_RECIPE] = (mods, vk)
                if not self._keys.register(ID_RECIPE, set(mods), vk):
                    self._notify(t("recipe.hotkey_failed",
                                   hotkey=hotkeys.label(spec)))
        if not on:
            return
        spec = self.cfg.str_("clip_hotkey", "alt+v").strip()
        if spec:
            vk, mods = parse_key(spec)
            if vk:
                self._want_keys[ID_CLIP] = (mods, vk)
                if not self._keys.register(ID_CLIP, set(mods), vk):
                    self._notify(t("clip.hotkey_failed",
                                   hotkey=hotkeys.label(spec)))
        for i, group in enumerate(self.store.groups()[:64]):
            if not group.hotkey:
                continue
            vk, mods = parse_key(group.hotkey)
            if vk:
                key_id = ID_GROUP_BASE + i
                self._want_keys[key_id] = (mods, vk)
                self._want_groups[key_id] = group.id
                if self._keys.register(key_id, set(mods), vk):
                    self._group_keys[key_id] = group.id

    def _retry_failed_keys(self) -> None:
        """登録に失敗したキーを付け直す。

        ★付け直す仕組みが長らく無く、起動時にほかのアプリ（や、終了
        しきっていない自分自身の前のプロセス）がキーを持っていると、
        相手が離した後もキーが二度と戻らなかった（2026-10-26、
        Ctrl+Shift+W のレシピキーが効かない件で実測・発覚）。
        録音キー側（winthread）には見張り＋付け直しがあるので、同じ
        考え方をこちらにも入れる。失敗が残っている間だけ静かに試す。
        """
        keys = self._keys
        if keys is None or not keys.failures:
            return
        for key_id in list(keys.failures):
            want = self._want_keys.get(key_id)
            if want is None:
                # ★もう対象でないキーの失敗は捨てる。残し続けると
                # この走査が 2 秒ごとに空回りし続け、失敗の有無の
                # 判定も濁る（2026-10-31 第三者監査 L22）。
                keys.failures.pop(key_id, None)
                continue
            mods, vk = want
            if keys.register(key_id, set(mods), vk, quiet=True):
                log.info("ショートカットを付け直しました (id=%#x)", key_id)
                gid = self._want_groups.get(key_id)
                if gid is not None:
                    self._group_keys[key_id] = gid

    # ------------------------------------------------------------ 見張り窓

    def _host_proc(self, hwnd: int, msg: int, wparam: int,
                   lparam: int) -> int:
        try:
            if msg == WM_APP_RUN:
                while True:
                    try:
                        job = self._jobs.get_nowait()
                    except queue.Empty:
                        break
                    try:
                        job()
                    except Exception:
                        log.exception("クリップボード履歴の仕事で例外")
                return 0
            if msg == WM_CLIPBOARDUPDATE:
                # すぐには読まない。コピーしたアプリが、いくつもの形式を
                # 置き終わるまで少し待つ（続けて来たら 1 回にまとめる）
                self._capture_tries = 0
                user32.SetTimer(hwnd, CAPTURE_TIMER, 80, None)
                return 0
            if msg == WM_TIMER:
                if wparam == CAPTURE_TIMER:
                    user32.KillTimer(hwnd, CAPTURE_TIMER)
                    self._capture()
                elif wparam == RESTORE_TIMER:
                    user32.KillTimer(hwnd, RESTORE_TIMER)
                    self._restore_now()
                elif wparam == SECRET_TIMER:
                    user32.KillTimer(hwnd, SECRET_TIMER)
                    if clipdata.clear_if(self._secret_seq, self._host):
                        log.info("秘密の項目をクリップボードから消しました")
                elif wparam == KEYS_CHECK_TIMER:
                    self._retry_failed_keys()
                elif wparam == RECIPE_HOLD_TIMER:
                    held = time.monotonic() - getattr(self, "_recipe_press_start", 0.0)
                    vk = getattr(self, "_recipe_vk", 0)
                    down = bool(user32.GetAsyncKeyState(vk) & 0x8000) if vk else False
                    if not down:
                        user32.KillTimer(hwnd, RECIPE_HOLD_TIMER)
                        self._recipe_held = False
                        self._recipe_hotkey()
                    elif held >= 0.45:
                        user32.KillTimer(hwnd, RECIPE_HOLD_TIMER)
                        self._recipe_held = False
                        if getattr(self, "_on_screen_assistant", None) is not None:
                            try:
                                self._on_screen_assistant()
                            except Exception:
                                log.exception("画面AIアシスタントの起動で例外")
                return 0
            if msg == WM_HOTKEY:
                self._hotkey(int(wparam))
                return 0
            if msg == WM_APP_REFRESH:
                self._refresh_now()
                return 0
            if msg == WM_CLOSE:
                user32.PostQuitMessage(0)
                return 0
        except Exception:
            log.exception("クリップボードの見張りで例外")
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    # ------------------------------------------------------------ 記録

    def _capture(self) -> None:
        if not self.enabled or self.paused:
            return
        seq = clipdata.sequence()
        if seq in self._own_seqs or inject.is_own_sequence(seq):
            # 自分が置いたもの（貼るため・元に戻すため）は記録しない
            return
        cap = clipdata.read(
            self._host,
            images=self.cfg.bool_("clip_capture_images", True),
            files=self.cfg.bool_("clip_capture_files", True),
            formatting=self.cfg.bool_("clip_keep_formatting", True),
            honor_private=self.cfg.bool_("clip_honor_private", True),
            max_text_bytes=self.cfg.int_("clip_max_text_kb", 1024) * 1024,
            max_image_bytes=self.cfg.int_("clip_max_image_mb", 30)
            * 1024 * 1024)
        if cap is None:
            # ほかのアプリがまだ開いている。少し待ってもう一度
            self._capture_tries += 1
            if self._capture_tries < 8:
                user32.SetTimer(self._host, CAPTURE_TIMER, 60, None)
            else:
                # 打ち切るなら記録に残す。黙って捨てると「コピー
                # したのに履歴に無い」が追えなくなる
                # （2026-10-31 監査: 静かに死ぬ系）。
                log.warning("クリップボードを取り込みきれませんでした"
                            "（ほかのアプリが開いたままです）")
            return
        if cap.skipped:
            log.info("クリップボードを記録しませんでした（%s）", cap.skipped)
            return
        if not cap.kind:
            return
        cap.app = clipdata.source_app()
        ignore = {a.strip().lower() for a in self.cfg.list_(
            "clip_ignore_apps")}
        if cap.app.lower() in ignore:
            log.info("記録しないアプリからのコピーです（%s）", cap.app)
            return
        self._work.put(cap)

    def simulate_capture(self, *, text: str = "", png: bytes = b"",
                         dib: bytes = b"", files: list[str] | None = None,
                         app: str = "test.exe") -> None:
        """試験用：クリップボードを読まずに、コピーされたことにする。"""
        cap = clipdata.Captured(app=app)
        if files:
            cap.kind, cap.files = "files", list(files)
        elif text:
            cap.kind, cap.text = "text", text
        elif png or dib:
            cap.kind, cap.png, cap.dib = "image", png, dib
        self._work.put(cap)

    def _store_loop(self) -> None:
        """コピーされたものを保存する（重い仕事はここで）。"""
        while True:
            cap = self._work.get()
            if cap is None:
                return
            try:
                self._save(cap)
            except Exception:
                log.exception("クリップボードの保存で例外")

    def _save(self, cap: clipdata.Captured) -> None:
        hash_ = cap.hash()
        # 「いまクリップボードにある最新のもの」の印は、番号と指紋を
        # 同じ時に書く。別々のスレッドで書いていたので、大きな画像を
        # 保存しているすきに前の項目を選ぶと、画像が貼られた（レビュー）
        self._last_seq, self._last_hash = cap.seq, hash_
        if cap.kind == "text":
            self.store.add(kind="text", hash_=hash_, text=cap.text,
                           html=cap.html, rtf=cap.rtf, app=cap.app)
        elif cap.kind == "files":
            self.store.add(kind="files", hash_=hash_, files=cap.files,
                           app=cap.app)
        elif cap.kind == "image":
            same = self.store.find_hash(hash_)
            if same is not None:
                self.store.bump(same.id, app=cap.app)
            else:
                self._save_image(cap, hash_)
        self._captures += 1
        if self._captures % 25 == 0:
            self._trim()
        self.refresh()

    def _save_image(self, cap: clipdata.Captured, hash_: str) -> None:
        name = f"{int(time.time() * 1000)}-{hash_[:10]}.png"
        path = self.store.image_dir / name
        self.store.image_dir.mkdir(parents=True, exist_ok=True)
        if cap.png:
            path.write_bytes(cap.png)
            w, h = clipgfx.png_size(cap.png)
        else:
            w, h = clipgfx.dib_to_png(cap.dib, path)
        if not w or not h or not path.exists():
            log.warning("画像を保存できませんでした")
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass
            return
        clipgfx.save_preview(path, self.store.image_dir
                             / clipstore.preview_name(name), 720, 540)
        self.store.add(kind="image", hash_=hash_, image=name, width=w,
                       height=h, app=cap.app, size=path.stat().st_size)

    def _refresh_now(self) -> None:
        if self.visible:
            self.model.reload()
            self._repaint()

    # ------------------------------------------------------------ 一覧

    def _tabs(self) -> list[Tab]:
        head = [Tab(HISTORY, "", self.store.history_count())]
        show_freq = self.cfg.bool_("clip_show_frequent", True)
        freq_tab: list[Tab] = []
        if show_freq:
            days = self.cfg.int_("clip_frequent_days", 7)
            f_count = len(self.store.frequent_items(days=days))
            freq_tab = [Tab(FREQUENT, t("clip.tab_frequent"), f_count)]

        groups = [Tab(g.id, g.name, g.count, g.hotkey)
                  for g in self.store.groups()]

        files: list[Tab] = []
        where = self.cfg.str_("clip_downloads", "end")
        if where != "off":
            files = [Tab(DOWNLOADS, t("clip.tab_downloads"),
                         len(self.recent.items()))]

        # ユーザーがドラッグ＆ドロップで決めたタブの並び順を取得
        if where == "second":
            order = ["history", "downloads", "frequent", "groups"]
        else:
            order = self.cfg.get("clip_tab_order")
            if not isinstance(order, (list, tuple)) or not order:
                order_mode = self.cfg.str_("clip_tab_order_mode",
                                           "frequent_first")
                if order_mode == "downloads_first":
                    order = ["history", "downloads", "frequent", "groups"]
                elif order_mode == "groups_first":
                    order = ["history", "groups", "frequent", "downloads"]
                elif order_mode == "frequent_downloads":
                    order = ["history", "frequent", "downloads", "groups"]
                else:
                    order = ["history", "frequent", "groups", "downloads"]

        tab_map = {
            "history": head,
            "frequent": freq_tab,
            "groups": groups,
            "downloads": files,
        }
        res: list[Tab] = []
        seen = set()
        for key in order:
            if key in tab_map and key not in seen:
                res.extend(tab_map[key])
                seen.add(key)
        for key in ("history", "frequent", "groups", "downloads"):
            if key not in seen and key in tab_map:
                res.extend(tab_map[key])
        return res

    def _recent_settings(self) -> dict:
        return {"roots": self.recent_roots,
                "days": self.cfg.int_("clip_download_days", 7),
                "onedrive": self.cfg.bool_("clip_download_onedrive", True),
                "desktop": self.cfg.bool_("clip_download_desktop", True),
                "labels": {"downloads": t("clip.where_downloads"),
                           "desktop": t("clip.where_desktop")}}

    def _download_clips(self) -> list[clipstore.Clip]:
        """「ダウンロード」タブの項目。番号は場所と時刻から作る（負の数）。"""
        import zlib  # noqa: PLC0415
        out = []
        for f in self.recent.items():
            key = f"{f.path}|{f.stamp}".encode("utf-8", "replace")
            cid = -(zlib.crc32(key) & 0x7FFFFFFF) - 1
            out.append(clipstore.Clip(
                id=cid, group_id=DOWNLOADS, kind="files", title=f.name,
                snippet=f.name, files=[f.path], app=f.where,
                created=f.stamp, size=f.size, path=f.path, cloud=f.cloud))
        self._virtual = {c.id: c for c in out}
        return out

    def _clip(self, clip_id: int) -> clipstore.Clip | None:
        if clip_id < 0:
            return self._virtual.get(clip_id)
        return self.store.get(clip_id)

    def _payload(self, clip_id: int) -> Payload | None:
        """貼る中身。ダウンロードの項目は、その実ファイルを渡す。"""
        if clip_id >= 0:
            return self.store.payload(clip_id)
        clip = self._virtual.get(clip_id)
        if clip is None:
            return None
        image = None
        if (clip.path.lower().endswith(IMAGE_EXT) and not clip.cloud
                and clip.size <= 30 * 1024 * 1024):
            image = Path(clip.path)
        return Payload(kind="files", files=[clip.path], image_path=image)

    def _items(self, gid: int) -> list[clipstore.Clip]:
        if gid == DOWNLOADS:
            return self._download_clips()
        if gid == FREQUENT:
            return self.store.frequent_items(
                days=self.cfg.int_("clip_frequent_days", 7))
        if gid == HISTORY:
            return self.store.items(
                HISTORY, sort=self.cfg.str_("clip_sort", "use"),
                pinned_first=self.cfg.bool_("clip_pinned_first", True))
        return self.store.items(
            gid, sort=self.cfg.str_("clip_group_sort", "manual"),
            pinned_first=self.cfg.bool_("clip_pinned_first", True))

    # ------------------------------------------------------------ 出す

    def _hotkey(self, key_id: int) -> None:
        if key_id == ID_RECIPE:
            if getattr(self, "_on_screen_assistant", None) is not None and getattr(self, "_recipe_vk", 0):
                self._recipe_press_start = time.monotonic()
                self._recipe_held = True
                user32.SetTimer(self._host, RECIPE_HOLD_TIMER, 25, None)
                return
            self._recipe_hotkey()
            return
        gid = self._group_keys.get(key_id)
        if key_id != ID_CLIP and gid is None:
            return
        if self.visible and self.mode != "clip":
            # レシピ一覧を出していた。同じ貼り先のまま、クリップボードの
            # 一覧に切り替える
            prev = self._target
            self._hide()
            self._show(gid, target=prev)
            return
        if self.visible and self._is_front():
            again = self.cfg.str_("clip_again", "next")
            if gid is not None and self.model.gid != gid:
                self.model.set_tab(self._tab_index(gid))
                self._repaint()
            elif again == "close":
                self._hide()
            elif again == "paste":
                self._run(self.model.key(0x0D) or Command("close"))
            else:
                self.model.next_tab()
                self._repaint()
            return
        self._show(gid)

    def _tab_index(self, gid: int) -> int:
        for i, tab in enumerate(self.model.tabs):
            if tab.gid == gid:
                return i
        return 0

    def _is_front(self) -> bool:
        if self.headless:
            return self.visible
        return int(user32.GetForegroundWindow() or 0) == self._hwnd

    def _pick_target(self, target: int) -> int:
        """一覧を閉じたあとに戻る窓（貼り先）を決める。"""
        if target or self.headless:
            # から打ちでは、本物の前面の窓を貼り先にしない（試験が
            # 利用者の窓の名前を読むことさえないように）
            return target
        front = int(user32.GetForegroundWindow() or 0)
        if front and front != self._hwnd and not self._own(front):
            return front
        return self._last_target() or self._target

    def _finish_voice(self) -> None:
        """音声入力を、入れ終わるまで済ませてから一覧を出す。

        ★録音中、音声入力は Enter（送信）と Esc（中止）を PC 全体で
        預かっている。そのまま一覧を出すと、一覧で Enter を押したのに
        チャットが送られ、Esc で閉じようとすると話した分が消えた
        （レビューで発覚）。話した文が貼り先に入ったあとで一覧を出す。
        """
        if self._is_recording():
            self._stop_recording()
        deadline = time.monotonic() + 3.0
        time.sleep(0.05)
        while time.monotonic() < deadline and (
                self._is_recording() or self._is_busy()):
            time.sleep(0.03)

    def _show(self, gid: int | None = None, *, target: int = 0) -> None:
        if not self.enabled:
            return
        self._finish_voice()
        self._target = self._pick_target(target)
        self.mode = "clip"
        if gid is None and self.cfg.str_("clip_open_tab",
                                         "history") == "last":
            gid = self.cfg.int_("clip_last_tab", HISTORY)
        self.model.open(gid)
        self._present()
        if self.headless:
            dryrun.record("clip_show", tab=self.model.gid,
                          items=len(self.model.view))

    # ------------------------------------------------------------ レシピ

    def _recipe_items(self) -> list:
        return from_config(self.cfg.get("ai_custom_instructions") or [],
                           language())

    def _recipe_hotkey(self) -> None:
        """レシピ一覧のキー。録音中なら止める（＝変換して入力）。"""
        if self._is_recording():
            self._stop_recording()
            return
        if self.visible and self.mode == "recipe" and self._is_front():
            self._hide()                       # もう一度押したら閉じる
            return
        prev = self._target if self.visible else 0
        if self.visible:
            self._hide()
        self._finish_voice()
        self.open_recipes(target=prev)

    def open_recipes(self, *, target: int = 0) -> None:
        """レシピ一覧を出す。このスレッドで呼ぶこと（外からは call() で）。"""
        self._target = self._pick_target(target)
        self.mode = "recipe"
        self.rmodel.open()
        self.rview.record_key = hotkeys.label(
            self.cfg.str_("hotkey", "ctrl+space")).replace(" ", "")
        self.rview.api_ready = bool(
            self.cfg.str_("ai_api_key", "").strip()
            and not self.cfg.bool_("offline_mode", False))
        self._present()
        if self.headless:
            dryrun.record("recipe_show", items=len(self.rmodel.view))

    def _pick_recipe(self, inst_id: str) -> None:
        """レシピを選んだ。元の窓へ戻してから、その変換で録音を始める。

        ★録音は「始めた時の前面の窓」を入力先にする。一覧が前に出た
        ままで始めると、入力先が一覧（自分の窓）になってしまうので、
        先に元の窓を前へ戻し、戻ったのを確かめてから始める。
        """
        target = self._target
        dryrun.record("recipe_pick", id=inst_id, target=target)
        if not self.headless and target:
            user32.SetForegroundWindow(target)
        self._hide()
        if not self.headless and target and not self._wait_front(target):
            log.warning("元の窓に戻れなかったので、変換の録音を始めません")
            self._notify(t("recipe.no_target"))
            return
        self._start_recipe(inst_id)

    def _run_recipe(self, cmd: tuple[str, str] | None) -> None:
        if cmd is None:
            return
        kind, value = cmd
        if kind == "pick":
            self._pick_recipe(value)
        elif kind == "close":
            self._hide()
        else:
            self._repaint()

    def _present(self) -> None:
        """いまの中身で窓を出し、前に出す。"""
        self._ensure_window()
        self._place()
        self._apply_opacity()
        self._dirty = True
        self.visible = True
        if self.headless:
            return
        self._render()
        user32.ShowWindow(self._hwnd, SW_SHOW)
        self._bring_front()
        user32.SetFocus(self._hwnd)
        self._place_caret()

    def _bring_front(self) -> None:
        """一覧を前に出して、キーを受け取れるようにする。

        ショートカット（WM_HOTKEY）を受け取った直後なら、ふつうは
        SetForegroundWindow だけで前に出られる。Windows が断ったとき
        だけ、前面のアプリと入力の列を**一瞬だけ**つないで出す
        （つないだままにすると、相手が固まったときに巻き込まれる）。
        """
        user32.SetForegroundWindow(self._hwnd)
        if int(user32.GetForegroundWindow() or 0) == self._hwnd:
            return
        front = int(user32.GetForegroundWindow() or 0)
        if not front:
            return
        mine = kernel32.GetCurrentThreadId()
        theirs = user32.GetWindowThreadProcessId(front, None)
        if not theirs or theirs == mine:
            return
        if user32.AttachThreadInput(mine, theirs, True):
            try:
                user32.BringWindowToTop(self._hwnd)
                user32.SetForegroundWindow(self._hwnd)
            finally:
                user32.AttachThreadInput(mine, theirs, False)
        if int(user32.GetForegroundWindow() or 0) != self._hwnd:
            log.warning("一覧を前に出せませんでした（キーは届きません）")

    def _own(self, hwnd: int) -> bool:
        pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return pid.value == os.getpid()

    def _hide(self) -> None:
        if not self.visible:
            return
        self.visible = False
        # 「前回のグループで開く」ときだけ覚える（閉じるたびに設定の
        # ファイルを書かないように）
        if (self.mode == "clip"
                and self.cfg.str_("clip_open_tab", "history") == "last"
                and self.cfg.int_("clip_last_tab", 0) != self.model.gid):
            self.cfg.set("clip_last_tab", self.model.gid)
        if self._hwnd and not self.headless:
            user32.ShowWindow(self._hwnd, SW_HIDE)
            user32.DestroyCaret()
            self._caret_h = -1
        # 「元に戻す」ができなくなったので、消した画像を本当に消す
        if self._purge_rows:
            rows, self._purge_rows = self._purge_rows, []
            self.store.purge_files(rows)
        self.model.undo.clear()
        # 窓を閉じているあいだは、大きな絵を持ち続けない
        if len(self._thumbs) > 80:
            self._drop_thumbs()

    def _drop_thumbs(self) -> None:
        for bmp, _w, _h in self._thumbs.values():
            clipgfx.dispose(bmp)
        self._thumbs.clear()

    def _ensure_window(self) -> None:
        if self._hwnd:
            return
        self._hwnd = user32.CreateWindowExW(
            WS_EX_TOOLWINDOW | WS_EX_TOPMOST, self._popup_class,
            "koe-type クリップボード", WS_POPUP | WS_THICKFRAME
            | WS_CLIPCHILDREN, 0, 0, 640, 440, None, None, self._hinst,
            None)
        if not self._hwnd:
            raise OSError(f"窓を作れません err={ctypes.get_last_error()}")
        try:
            # 影を付ける・角を丸める・枠の色をそろえる・出すときの動きを省く
            margins = MARGINS(1, 1, 1, 1)
            dwmapi.DwmExtendFrameIntoClientArea(self._hwnd,
                                                ctypes.byref(margins))
            on = ctypes.c_int(1)
            dwmapi.DwmSetWindowAttribute(self._hwnd, 3, ctypes.byref(on), 4)
            corner = ctypes.c_int(2)
            dwmapi.DwmSetWindowAttribute(self._hwnd, 33,
                                         ctypes.byref(corner), 4)
        except Exception:
            log.debug("窓の飾りを付けられませんでした", exc_info=True)
        user32.SetWindowPos(self._hwnd, None, 0, 0, 0, 0,
                            SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER
                            | SWP_NOACTIVATE | SWP_FRAMECHANGED)
        self._border_colour()

    def _apply_opacity(self) -> None:
        if self.headless or not self._hwnd:
            return
        percent = max(50, min(100, self.cfg.int_("clip_opacity", 100)))
        self._set_alpha(percent)

    def _set_alpha(self, percent: int) -> None:
        style = user32.GetWindowLongPtrW(self._hwnd, GWL_EXSTYLE)
        if percent >= 100:
            if style & WS_EX_LAYERED:
                user32.SetWindowLongPtrW(self._hwnd, GWL_EXSTYLE,
                                         style & ~WS_EX_LAYERED)
            return
        if not style & WS_EX_LAYERED:
            user32.SetWindowLongPtrW(self._hwnd, GWL_EXSTYLE,
                                     style | WS_EX_LAYERED)
        user32.SetLayeredWindowAttributes(self._hwnd, 0,
                                          round(255 * percent / 100),
                                          LWA_ALPHA)

    def _border_colour(self) -> None:
        """Windows 11 の窓のふちの色を、窓の線の色にそろえる。

        そろえないと、「タイトルバーとふちにアクセントカラーを使う」に
        している人の環境で、ふちだけ色がついて浮いて見える。
        """
        if self.headless or not self._hwnd:
            return
        try:
            colour = ctypes.c_uint(clipgfx.colorref(self.view.c["line"]))
            dwmapi.DwmSetWindowAttribute(self._hwnd, 34,
                                         ctypes.byref(colour), 4)
        except Exception:
            pass

    # ------------------------------------------------------------ 位置

    def _work_area(self, x: int, y: int) -> RECT:
        monitor = user32.MonitorFromPoint(POINT(x, y),
                                          MONITOR_DEFAULTTONEAREST)
        info = MONITORINFO()
        info.cbSize = ctypes.sizeof(MONITORINFO)
        if monitor and user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            return info.rcWork
        return RECT(0, 0, user32.GetSystemMetrics(0),
                    user32.GetSystemMetrics(1))

    def _caret_point(self) -> tuple[int, int] | None:
        """貼る先の窓の文字カーソル（キャレット）の位置。取れなければ None。

        ブラウザなど、キャレットを Windows に教えないアプリでは取れない。
        """
        if not self._target:
            return None
        tid = user32.GetWindowThreadProcessId(self._target, None)
        info = GUITHREADINFO()
        info.cbSize = ctypes.sizeof(GUITHREADINFO)
        if not tid or not user32.GetGUIThreadInfo(tid, ctypes.byref(info)):
            return None
        if not info.hwndCaret:
            return None
        pt = POINT(info.rcCaret.left, info.rcCaret.bottom)
        if not user32.ClientToScreen(info.hwndCaret, ctypes.byref(pt)):
            return None
        if pt.x == 0 and pt.y == 0:
            return None
        return (pt.x, pt.y)

    def _anchor(self) -> tuple[str, int, int]:
        mode = self.cfg.str_("clip_position", "caret")
        cursor = POINT()
        user32.GetCursorPos(ctypes.byref(cursor))
        if mode == "caret":
            point = self._caret_point()
            if point:
                return ("caret", point[0], point[1])
            return ("mouse", cursor.x, cursor.y)
        if mode == "last":
            x, y = (self.cfg.int_("clip_pos_x", -99999),
                    self.cfg.int_("clip_pos_y", -99999))
            if user32.MonitorFromPoint(POINT(x + 40, y + 20),
                                       MONITOR_DEFAULTTONULL):
                return ("last", x, y)
            mode = "center"
        if mode == "center":
            if self._target:
                rect = RECT()
                if user32.GetWindowRect(self._target, ctypes.byref(rect)):
                    return ("center", (rect.left + rect.right) // 2,
                            (rect.top + rect.bottom) // 2)
            return ("center", cursor.x, cursor.y)
        return ("mouse", cursor.x, cursor.y)

    def _place(self) -> None:
        mode, ax, ay = self._anchor()
        if not self.headless:
            # まず小さくその場所へ動かして、そのモニターの拡大率を知る
            user32.SetWindowPos(self._hwnd, None, ax, ay, 0, 0,
                                SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE)
        self._scale = self._dpi() / 96.0
        s = self._scale
        work = self._work_area(ax, ay)
        ww, wh = work.right - work.left, work.bottom - work.top
        w = min(round(self.cfg.int_("clip_width", 640) * s), int(ww * 0.96))
        h = min(round(self.cfg.int_("clip_height", 440) * s), int(wh * 0.96))
        gap = round(14 * s)
        if mode == "center":
            x, y = ax - w // 2, ay - h // 2
        elif mode == "last":
            x, y = ax, ay
        else:
            x = ax - round(28 * s)
            y = ay + gap if mode == "mouse" else ay + round(6 * s)
            if y + h > work.bottom:
                # 下に入らなければ、上に出す（カーソルを隠さないように）
                y = ay - h - gap
        x = max(work.left + 4, min(x, work.right - w - 4))
        y = max(work.top + 4, min(y, work.bottom - h - 4))
        if self.headless:
            self._size = (w, h)
            return
        user32.SetWindowPos(self._hwnd, wintypes.HWND(HWND_TOPMOST), x, y,
                            w, h, SWP_NOACTIVATE)

    def _dpi(self) -> int:
        if self._hwnd and hasattr(user32, "GetDpiForWindow"):
            try:
                return int(user32.GetDpiForWindow(self._hwnd)) or 96
            except Exception:
                pass
        return 96

    def _client_size(self) -> tuple[int, int]:
        if self.headless:
            return getattr(self, "_size", (640, 440))
        rect = RECT()
        user32.GetClientRect(self._hwnd, ctypes.byref(rect))
        return (max(1, rect.right - rect.left), max(1, rect.bottom - rect.top))

    # ------------------------------------------------------------ 描く

    def _thumb(self, clip: clipstore.Clip, w: int,
               h: int) -> tuple[int, int, int]:
        key = (clip.id, w, h)
        hit = self._thumbs.get(key)
        if hit is not None:
            return hit
        if len(self._thumbs) > 160:
            self._drop_thumbs()
        if clip.path:
            # ダウンロードの画像は、その実ファイルから縮める。クラウドだけに
            # あるものは読まない（読むとダウンロードが始まる）
            if clip.cloud or not clip.path.lower().endswith(IMAGE_EXT):
                return (0, 0, 0)
            loaded = clipgfx.load_scaled(Path(clip.path), w, h)
            self._thumbs[key] = loaded
            return loaded
        prev = self.store.image_dir / clipstore.preview_name(clip.image)
        src = prev if prev.exists() else self.store.image_dir / clip.image
        loaded = clipgfx.load_scaled(src, w, h)
        self._thumbs[key] = loaded
        return loaded

    def _full_text(self, clip: clipstore.Clip) -> str:
        if self._full_cache[0] != clip.id:
            text = clip.snippet if clip.chars <= len(clip.snippet) else \
                self.store.full_text(clip.id)
            self._full_cache = (clip.id, text)
        return self._full_cache[1]

    def _render(self) -> clipgfx.Canvas | None:
        w, h = self._client_size()
        if self._canvas is None or (self._canvas.width,
                                    self._canvas.height) != (w, h):
            if self._canvas is not None:
                self._canvas.close()
            self._canvas = clipgfx.Canvas(w, h)
        if self.mode == "recipe":
            self.rview.paint(self._canvas, self.rmodel, self._scale,
                             focused=self.visible,
                             note=self.model.note_now())
        else:
            self.view.paint(self._canvas, self.model, self._scale,
                            thumb=self._thumb, full_text=self._full_text,
                            focused=self.visible)
        self._dirty = False
        return self._canvas

    def _repaint(self) -> None:
        self._dirty = True
        if self.headless or not self._hwnd:
            return
        user32.InvalidateRect(self._hwnd, None, False)

    def snapshot(self, path: Path) -> bool:
        """いまの窓の絵を PNG にする（試験用。画面は使わない）。"""
        done = threading.Event()
        result = [False]

        def job() -> None:
            try:
                self._ensure_window()
                if self.headless and not hasattr(self, "_size"):
                    self._scale = 1.5
                    self._size = (960, 660)
                canvas = self._render()
                result[0] = bool(canvas and canvas.save_png(path))
            finally:
                done.set()
        self.call(job)
        done.wait(10.0)
        return result[0]

    def _place_caret(self) -> None:
        """IME の変換窓を、検索欄の文字カーソルの所に出す。"""
        if self.headless or not self._hwnd or not self.visible:
            return
        x, y, h = self._active_view().layout.caret
        # Windows のキャレットは見せない（自分で描いている）。作るのは
        # 高さが変わったときだけ。IME や拡大鏡がこの位置を見る。
        if self._caret_h != h:
            user32.DestroyCaret()
            user32.CreateCaret(self._hwnd, None, 1, max(1, h))
            self._caret_h = h
        user32.SetCaretPos(x, y)
        if imm32 is None:
            return
        himc = imm32.ImmGetContext(self._hwnd)
        if not himc:
            return
        try:
            comp = COMPOSITIONFORM(2, POINT(x, y), RECT())     # CFS_POINT
            imm32.ImmSetCompositionWindow(himc, ctypes.byref(comp))
            cand = CANDIDATEFORM(0, 0x40, POINT(x, y + h + 2), RECT())
            imm32.ImmSetCandidateWindow(himc, ctypes.byref(cand))
        finally:
            imm32.ImmReleaseContext(self._hwnd, himc)

    # ------------------------------------------------------------ 窓の処理

    def _popup_proc(self, hwnd: int, msg: int, wparam: int,
                    lparam: int) -> int:
        try:
            out = self._popup_msg(hwnd, msg, wparam, lparam)
            if out is not None:
                return out
        except Exception:
            log.exception("クリップボードの窓で例外 (msg=%#x)", msg)
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _popup_msg(self, hwnd: int, msg: int, wparam: int,  # noqa: C901
                   lparam: int) -> int | None:
        if msg == WM_NCCALCSIZE and wparam:
            return 0                    # 枠をなくし、全部を中身にする
        if msg == WM_NCACTIVATE:
            return user32.DefWindowProcW(hwnd, msg, wparam, -1)
        if msg == WM_NCHITTEST:
            return self._hit_test(lparam)
        if msg == WM_ERASEBKGND:
            return 1
        if msg == WM_PAINT:
            ps = PAINTSTRUCT()
            hdc = user32.BeginPaint(hwnd, ctypes.byref(ps))
            try:
                canvas = self._render() if (self._dirty or self._canvas
                                            is None) else self._canvas
                if canvas is not None:
                    canvas.blit(hdc)
            finally:
                user32.EndPaint(hwnd, ctypes.byref(ps))
            # 描いたあとの文字カーソルの位置に、IME の変換窓を合わせる
            self._place_caret()
            return 0
        if msg == WM_SIZE:
            self._dirty = True
            user32.InvalidateRect(hwnd, None, False)
            return 0
        if msg == WM_ACTIVATE:
            if (wparam & 0xFFFF) == WA_INACTIVE and self.visible \
                    and not self._modal \
                    and self.cfg.bool_("clip_close_on_blur", True):
                self._hide()
            return 0
        if msg == WM_CLOSE:
            self._hide()
            return 0
        if msg == WM_SYSCOMMAND and (wparam & 0xFFF0) == SC_KEYMENU:
            return 0                    # Alt で窓のメニューに入らない
        if msg in (WM_KEYDOWN, WM_SYSKEYDOWN):
            return self._on_key(int(wparam), msg == WM_SYSKEYDOWN, lparam)
        if msg == WM_SYSCHAR:
            return 0                    # Alt+文字の「ポン」という音を出さない
        if msg == WM_CHAR:
            self._on_char(int(wparam))
            return 0
        if msg in (WM_IME_STARTCOMPOSITION, WM_IME_COMPOSITION):
            self._place_caret()
            return None
        if msg == WM_MOUSEMOVE:
            self._on_move(_lo(lparam), _hi(lparam), int(wparam))
            return 0
        if msg == WM_MOUSELEAVE:
            self._tracking = False
            if self.view.hover_kind:
                self.view.hover_kind = ""
                self._repaint()
            return 0
        if msg == WM_LBUTTONDOWN:
            self._on_down(_lo(lparam), _hi(lparam))
            return 0
        if msg == WM_LBUTTONUP:
            self._on_up(_lo(lparam), _hi(lparam))
            return 0
        if msg == WM_LBUTTONDBLCLK:
            if self.mode == "recipe":
                return 0
            what, index = self.view.hit(_lo(lparam), _hi(lparam), self.model)
            if what == "row":
                self._run(self.model.double_click(index))
            elif what == "search":
                self.model.search.select_all()
                self._repaint()
            return 0
        if msg == WM_RBUTTONUP:
            if self.mode == "recipe":
                return 0
            what, index = self.view.hit(_lo(lparam), _hi(lparam), self.model)
            if what == "row":
                if self.model.view[index].id not in self.model.multi:
                    self.model.multi = []
                self.model.select(index)
                self._repaint()
                pt = POINT(_lo(lparam), _hi(lparam))
                user32.ClientToScreen(hwnd, ctypes.byref(pt))
                self._menu(pt.x, pt.y)
            return 0
        if msg == WM_MOUSEWHEEL:
            delta = _hi(int(wparam))
            model = self.rmodel if self.mode == "recipe" else self.model
            model.scroll(-round(delta / 120 * 3))
            self._repaint()
            return 0
        if msg == WM_SETCURSOR:
            if (lparam & 0xFFFF) == HTCLIENT:
                pt = POINT()
                user32.GetCursorPos(ctypes.byref(pt))
                user32.ScreenToClient(hwnd, ctypes.byref(pt))
                what, _i = self._hit(pt.x, pt.y)
                cursor = IDC_IBEAM if what == "search" else IDC_ARROW
                user32.SetCursor(user32.LoadCursorW(None, _vp(cursor)))
                return 1
            return None
        if msg == WM_GETMINMAXINFO:
            info = ctypes.cast(lparam, ctypes.POINTER(MINMAXINFO)).contents
            s = self._scale
            info.ptMinTrackSize.x = round(380 * s)
            info.ptMinTrackSize.y = round(300 * s)
            return 0
        if msg == WM_EXITSIZEMOVE:
            self._remember_rect()
            return 0
        if msg == WM_DPICHANGED:
            self._scale = (wparam & 0xFFFF) / 96.0
            rect = ctypes.cast(lparam, ctypes.POINTER(RECT)).contents
            user32.SetWindowPos(hwnd, None, rect.left, rect.top,
                                rect.right - rect.left,
                                rect.bottom - rect.top,
                                SWP_NOZORDER | SWP_NOACTIVATE)
            self.view.fonts.clear()
            self._repaint()
            return 0
        if msg == WM_SETTINGCHANGE:
            # Windows のライト／ダークを切り替えた
            self.call(self._configure)
            return None
        if msg == WM_TIMER and wparam == NOTE_TIMER:
            user32.KillTimer(hwnd, NOTE_TIMER)
            self._repaint()
            return 0
        return None

    def _hit_test(self, lparam: int) -> int:
        pt = POINT(_lo(lparam), _hi(lparam))
        user32.ScreenToClient(self._hwnd, ctypes.byref(pt))
        w, h = self._client_size()
        edge = max(4, round(6 * self._scale))
        dx = -1 if pt.x < edge else (1 if pt.x >= w - edge else 0)
        dy = -1 if pt.y < edge else (1 if pt.y >= h - edge else 0)
        if dx or dy:
            return HT_EDGES[(dx, dy)]
        what, _i = self._hit(pt.x, pt.y)
        return HTCAPTION if what == "caption" else HTCLIENT

    def _active_view(self):  # noqa: ANN202
        return self.rview if self.mode == "recipe" else self.view

    def _hit(self, x: int, y: int) -> tuple[str, int]:
        if self.mode == "recipe":
            return self.rview.hit(x, y, self.rmodel)
        return self.view.hit(x, y, self.model)

    def _remember_rect(self) -> None:
        rect = RECT()
        if not user32.GetWindowRect(self._hwnd, ctypes.byref(rect)):
            return
        s = self._scale or 1.0
        w = round((rect.right - rect.left) / s)
        h = round((rect.bottom - rect.top) / s)
        changes = {"clip_pos_x": rect.left, "clip_pos_y": rect.top}
        if abs(w - self.cfg.int_("clip_width", 640)) > 2:
            changes["clip_width"] = max(380, min(1600, w))
        if abs(h - self.cfg.int_("clip_height", 440)) > 2:
            changes["clip_height"] = max(300, min(1200, h))
        self.cfg.update(changes)

    # ------------------------------------------------------------ キー

    def _on_key(self, vk: int, sys_key: bool, lparam: int) -> int:
        alt = bool(lparam & (1 << 29)) if sys_key else _down(VK_MENU)
        if alt and vk == VK_F4:
            self._hide()
            return 0
        if self.mode == "recipe":
            picked = self.rmodel.key(vk, ctrl=_down(VK_CONTROL),
                                     shift=_down(VK_SHIFT), alt=alt)
            if picked is None:
                return 0 if sys_key else user32.DefWindowProcW(
                    self._hwnd, WM_KEYDOWN, vk, lparam)
            self._run_recipe(picked)
            return 0
        cmd = self.model.key(vk, ctrl=_down(VK_CONTROL),
                             shift=_down(VK_SHIFT), alt=alt)
        if cmd is None:
            return 0 if sys_key else user32.DefWindowProcW(
                self._hwnd, WM_SYSKEYDOWN if sys_key else WM_KEYDOWN, vk,
                lparam)
        self._run(cmd)
        return 0

    def _on_char(self, code: int) -> None:
        if 0xD800 <= code <= 0xDBFF:
            self._high_surrogate = chr(code)
            return
        ch = chr(code)
        if 0xDC00 <= code <= 0xDFFF and self._high_surrogate:
            ch = (self._high_surrogate + ch).encode(
                "utf-16-le", "surrogatepass").decode("utf-16-le")
        self._high_surrogate = ""
        if _down(VK_CONTROL) and not _down(VK_MENU):
            return                      # Ctrl+文字は key() で扱った
        model = self.rmodel if self.mode == "recipe" else self.model
        if model.char(ch):
            self._repaint()

    # ------------------------------------------------------------ マウス

    def _track_leave(self) -> None:
        if self._tracking or self.headless:
            return
        tme = TRACKMOUSEEVENT(ctypes.sizeof(TRACKMOUSEEVENT), TME_LEAVE,
                              self._hwnd, 0)
        self._tracking = bool(user32.TrackMouseEvent(ctypes.byref(tme)))

    def _on_move(self, x: int, y: int, keys: int) -> None:
        self._track_leave()
        if (self._press is not None and keys & MK_LBUTTON
                and self.mode == "clip"):
            px, py, index = self._press
            if (abs(x - px) > user32.GetSystemMetrics(SM_CXDRAG) * 2
                    or abs(y - py) > user32.GetSystemMetrics(SM_CYDRAG) * 2):
                self._press = None
                user32.ReleaseCapture()
                self._drag(index)
            return
        if (x, y) == self._last_move:
            return
        self._last_move = (x, y)
        if self.mode == "recipe":
            what, index = self.rview.hit(x, y, self.rmodel)
            if what == "row" and index != self.rmodel.sel:
                self.rmodel.select(index)
                self._repaint()
            return
        what, index = self.view.hit(x, y, self.model)
        hover = what if what in ("settings", "tab_add", "kind") else ""
        changed = hover != self.view.hover_kind
        self.view.hover_kind = hover
        if what == "row" and index != self.model.sel:
            self.model.select(index)
            changed = True
        if changed:
            self._repaint()

    def _on_down(self, x: int, y: int) -> None:
        if self.mode == "recipe":
            what, index = self.rview.hit(x, y, self.rmodel)
            # レシピは引きずって渡すものではないので、押した印だけ残す
            self._press = (x, y, index) if what == "row" else None
            return
        what, index = self.view.hit(x, y, self.model)
        if what == "row":
            self._press = (x, y, index)
            user32.SetCapture(self._hwnd)
        elif what == "search":
            self._caret_from_x(x)
            self._repaint()

    def _caret_from_x(self, x: int) -> None:
        canvas = self._canvas
        if canvas is None:
            return
        box = self.view.layout.search
        start = box.x + round(36 * self._scale)
        text = self.model.search.text
        px = self.view.px(13.5, self._scale)
        best, best_d = 0, abs(x - start)
        for i in range(1, len(text) + 1):
            w = clipgfx.measure(canvas.dc, self.view.fonts, text[:i],
                                px=px)[0]
            d = abs(x - (start + w))
            if d < best_d:
                best, best_d = i, d
        self.model.search.move(best, False)

    def _on_up(self, x: int, y: int) -> None:
        press, self._press = self._press, None
        user32.ReleaseCapture()
        if self.mode == "recipe":
            what, index = self.rview.hit(x, y, self.rmodel)
            if what == "row" and press is not None and press[2] == index:
                self._run_recipe(self.rmodel.click(index))
            elif what == "tab":
                self.rmodel.set_category_index(index)
                self._repaint()
            return
        what, index = self.view.hit(x, y, self.model)
        ctrl, shift = _down(VK_CONTROL), _down(VK_SHIFT)
        if what == "row" and press is not None and press[2] == index:
            self._run(self.model.click(index, ctrl=ctrl, shift=shift))
        elif what == "tab":
            self.model.set_tab(index)
            self._repaint()
        elif what == "kind":
            from .clipview import KIND_ORDER  # noqa: PLC0415
            kind = KIND_ORDER[index][0]
            self.model.set_kind("all" if self.model.kind == kind else kind)
            self.model.say(t("clip.filter", name=t(f"clip.kind_{kind}")),
                           1.5)
            self._note_timer(1.6)
            self._repaint()
        elif what == "settings":
            self._run(Command("settings"))
        elif what == "tab_add":
            self._run(Command("new_group"))

    def _note_timer(self, seconds: float) -> None:
        if self._hwnd and not self.headless:
            user32.SetTimer(self._hwnd, NOTE_TIMER, int(seconds * 1000),
                            None)

    # ------------------------------------------------------------ 操作

    def key(self, vk: int, *, ctrl: bool = False, shift: bool = False,
            alt: bool = False) -> None:
        """試験用：窓にキーが押されたことにする（本物のキーは使わない）。"""
        def job() -> None:
            if self.mode == "recipe":
                self._run_recipe(self.rmodel.key(vk, ctrl=ctrl, shift=shift,
                                                 alt=alt))
            else:
                self._run(self.model.key(vk, ctrl=ctrl, shift=shift,
                                         alt=alt))
        self.call(job)

    def type_text(self, text: str) -> None:
        """試験用：検索欄に文字を打ったことにする。"""
        def job() -> None:
            model = self.rmodel if self.mode == "recipe" else self.model
            for ch in text:
                model.char(ch)
            self._repaint()
        self.call(job)

    def press_hotkey(self) -> None:
        """試験用：ショートカットが押されたことにする。"""
        self.call(lambda: self._hotkey(ID_CLIP))

    def press_recipe_hotkey(self) -> None:
        """試験用：レシピ一覧のショートカットが押されたことにする。"""
        self.call(lambda: self._hotkey(ID_RECIPE))

    def show_recipes(self, *, target: int = 0) -> None:
        """レシピ一覧を出す（どのスレッドから呼んでもよい）。"""
        self.call(lambda: self.open_recipes(target=target))

    def _run(self, cmd: Command | None) -> None:  # noqa: C901
        if cmd is None:
            return
        kind = cmd.kind
        if kind == "repaint":
            self._repaint()
        elif kind == "close":
            self._hide()
        elif kind in ("paste", "copy"):
            self._paste(cmd.ids, plain=cmd.plain, how=cmd.transform,
                        copy_only=kind == "copy")
        elif kind == "delete":
            if any(i < 0 for i in cmd.ids):
                # ダウンロードしたファイルそのものは、ここからは消さない
                self.model.say(t("clip.download_keep"))
                self._note_timer(2.6)
                self._repaint()
                return
            rows = self.store.delete(cmd.ids, keep_files=True)
            self._purge_rows += rows
            self.model.remember_deleted(rows)
            self.model.multi = []
            self.model.reload()
            self.model.say(t("clip.deleted", n=len(rows)), 4.0)
            self._note_timer(4.1)
            self._repaint()
        elif kind == "undo":
            rows = self.model.pop_undo()
            if rows:
                self.store.restore(rows)
                ids = {r.get("id") for r in rows}
                self._purge_rows = [r for r in self._purge_rows
                                    if r.get("id") not in ids]
                self.model.reload()
                self.model.say(t("clip.restored"))
                self._note_timer(2.6)
                self._repaint()
        elif kind == "pin":
            clips = [self.store.get(i) for i in cmd.ids if i >= 0]
            clips = [c for c in clips if c]
            if clips:
                pin = not clips[0].pinned
                self.store.set_pinned([c.id for c in clips], pin)
                self.model.reload()
                self.model.say(t("clip.pinned" if pin else "clip.unpinned"))
                self._note_timer(2.6)
                self._repaint()
        elif kind == "group_menu":
            self._group_menu(cmd.ids)
        elif kind == "move":
            self._move(cmd.ids, cmd.group_id)
        elif kind == "reorder":
            if self.cfg.str_("clip_group_sort", "manual") != "manual":
                self.model.say(t("clip.reorder_manual_only"))
                self._note_timer(2.6)
                self._repaint()
                return
            if cmd.ids and self.store.reorder(
                    cmd.ids[0], cmd.delta,
                    pinned_first=self.cfg.bool_("clip_pinned_first", True)):
                self.model.reload()
                self.model.select(self.model.sel)
                self._repaint()
        elif kind == "edit":
            if cmd.ids and cmd.ids[0] >= 0:
                self._hide()
                self._open_settings(cmd.ids[0])
        elif kind in ("settings", "new_group"):
            self._hide()
            self._open_settings(-1 if kind == "new_group" else 0)
        elif kind == "open":
            self._open_item(cmd.ids[:1])
        elif kind == "menu":
            pt = self._row_screen_point(cmd.index)
            self._menu(pt[0], pt[1])
        elif kind == "search_paste":
            text = "" if self.headless else inject.clipboard_text()
            self.model.paste_into_search(text)
            self._repaint()

    def _row_screen_point(self, index: int) -> tuple[int, int]:
        lay = self.view.layout
        row = max(0, index - self.model.top)
        pt = POINT(lay.listing.x + round(60 * self._scale),
                   lay.listing.y + (row + 1) * lay.row_h)
        if self._hwnd and not self.headless:
            user32.ClientToScreen(self._hwnd, ctypes.byref(pt))
        return (pt.x, pt.y)

    # ------------------------------------------------------------ 貼る

    def _compose(self, ids: list[int], *, plain: bool,
                 how: str) -> tuple[Payload | None, list[int]]:
        """貼る中身を組み立てる。まとめて貼るときは文字だけをつなぐ。"""
        if len(ids) == 1:
            payload = self._payload(ids[0])
            if payload is None:
                return (None, [])
            clip = self._clip(ids[0])
            if payload.kind == "text":
                if clip and clip.group_id != HISTORY and self.cfg.bool_(
                        "clip_expand_vars", True):
                    current = self._current_clip_text()
                    expanded = expand(payload.text, clipboard=current)
                    if expanded != payload.text:
                        payload.text = expanded
                        payload.html = payload.rtf = b""
                if how:
                    payload.text = transform(payload.text, how)
                    payload.html = payload.rtf = b""
                if plain or self.cfg.bool_("clip_plain_default", False):
                    payload.html = payload.rtf = b""
            return (payload, ids)
        texts, used, skipped = [], [], False
        for clip_id in ids:
            payload = self._payload(clip_id)
            if payload is None or payload.kind != "text":
                skipped = True
                continue
            text = payload.text
            if how:
                text = transform(text, how)
            texts.append(text)
            used.append(clip_id)
        if skipped:
            self._notify(t("clip.mixed_skipped"))
        if not texts:
            return (None, [])
        join = {"newline": "\n", "blank": "\n\n", "space": " ",
                "none": ""}.get(self.cfg.str_("clip_join", "newline"), "\n")
        return (Payload(kind="text", text=join.join(texts)), used)

    def _current_clip_text(self) -> str:
        """{clipboard} に入れる文字。いまの履歴の一番新しい文字。"""
        rows = self.store.items(HISTORY, sort="copy", pinned_first=False,
                                limit=1)
        if rows and rows[0].kind == "text":
            return self.store.full_text(rows[0].id)
        return ""

    def _write(self, payload: Payload, *, plain: bool) -> int:
        dib = png = b""
        files = None
        text: str | None = payload.text if payload.kind == "text" else None
        html = b"" if plain else payload.html
        rtf = b"" if plain else payload.rtf
        if payload.kind == "image" and payload.image_path is not None:
            try:
                png = payload.image_path.read_bytes()
            except OSError:
                png = b""
            dib = clipgfx.png_to_dib(payload.image_path)
            if not dib and not png:
                return -1
        elif payload.kind == "files":
            files = [f for f in payload.files if os.path.exists(f)] or \
                payload.files
            text = "\r\n".join(payload.files)
            if payload.image_path is not None:
                # 画像のファイルは、絵としても貼れるようにする（ペイント・
                # Word などはファイルより絵を受け取る）
                dib = clipgfx.png_to_dib(payload.image_path)
                if payload.image_path.suffix.lower() == ".png":
                    try:
                        png = payload.image_path.read_bytes()
                    except OSError:
                        png = b""
        seq = clipdata.write(self._host, text=text, html=html, rtf=rtf,
                             dib=dib, png=png, files=files,
                             private=payload.secret)
        if seq:
            self._own_seqs.append(seq)
            del self._own_seqs[:-16]
        return seq

    def _paste(self, ids: list[int], *, plain: bool = False,
               how: str = "", copy_only: bool = False) -> None:
        # 前の貼り付けの「元に戻す」が残っていても使わない（途中で
        # 失敗した回の控えで、古い中身へ戻されることがあった）
        self._restore = None
        user32.KillTimer(self._host, RESTORE_TIMER)
        payload, used = self._compose(ids, plain=plain, how=how)
        if payload is None:
            self.model.say(t("clip.paste_failed"))
            self._repaint()
            return
        target = self._target
        if self.cfg.str_("clip_paste_mode", "paste") == "copy":
            copy_only = True
        if not copy_only and not self._can_paste(target):
            copy_only = True
            fallback = True
        else:
            fallback = False
        if (not copy_only and not self.headless
                and self.cfg.bool_("clip_restore_after", False)):
            self._restore = inject.snapshot_clipboard()
        plain_now = plain or self.cfg.bool_("clip_plain_default", False)
        if self._still_on_clipboard(used, plain=plain_now, how=how):
            # いまクリップボードにある、いちばん新しいコピーそのもの。
            # 書き直さずに貼る。書き直すと、Excel のセルのような
            # 元のアプリ独自の形式（数式など）が落ちてしまう。
            seq = clipdata.sequence()
        else:
            seq = self._write(payload, plain=plain)
        dryrun.record("clip_paste" if not copy_only else "clip_copy",
                      text=payload.text, what=payload.kind,
                      secret=payload.secret, target=target,
                      plain=plain, how=how)
        if seq <= 0:
            # ★置けなかった（ほかのアプリがクリップボードを使用中など）。
            # ここで Ctrl+V を送ると、前の中身を貼ってしまう。
            self.model.say(t("clip.paste_failed"))
            self._repaint()
            return
        self.store.mark_used([i for i in used if i >= 0])
        if copy_only:
            self._hide()
            self._notify(t("clip.copied_only") if fallback
                         else t("clip.copied"))
            self._after_secret(payload, seq)
            return
        if not self.headless:
            # 先に相手を前へ出してから、自分の窓を隠す（逆にすると、
            # 前へ出す権利を失って貼り先へ戻れないことがある）
            user32.SetForegroundWindow(target)
        self._hide()
        if not self.headless and not self._wait_front(target):
            self._notify(t("clip.copied_only"))
            self._after_secret(payload, seq)
            return
        inject.wait_modifiers_released(600)
        inject.send_paste(target)
        if self._restore is not None:
            user32.SetTimer(self._host, RESTORE_TIMER, 450, None)
        self._after_secret(payload, seq)

    def _still_on_clipboard(self, ids: list[int], *, plain: bool,
                            how: str) -> bool:
        """選んだものが、いまクリップボードにある最新のコピーそのものか。"""
        if self.headless or plain or how or len(ids) != 1:
            return False
        if not self._last_seq or clipdata.sequence() != self._last_seq:
            return False
        clip = self.store.get(ids[0])
        return bool(clip and clip.group_id == HISTORY
                    and clip.hash and clip.hash == self._last_hash)

    def _after_secret(self, payload: Payload, seq: int) -> None:
        seconds = self.cfg.int_("clip_secret_clear_s", 30)
        if payload.secret and seconds > 0 and seq:
            self._secret_seq = seq
            user32.SetTimer(self._host, SECRET_TIMER, seconds * 1000, None)

    def _restore_now(self) -> None:
        saved, self._restore = self._restore, None
        if saved is None:
            return
        try:
            inject.restore_clipboard(saved)
        except Exception:
            log.exception("クリップボードを元に戻せませんでした")

    def _can_paste(self, target: int) -> bool:
        """その窓へ貼れるか。だめなら、コピーだけにして知らせる。"""
        if self.headless:
            return bool(target)
        if not target or not user32.IsWindow(target):
            return False
        if self._own(target):
            return False
        if inject.window_class(target) in ("Shell_TrayWnd",
                                           "Shell_SecondaryTrayWnd",
                                           "Progman", "WorkerW"):
            return False
        return not inject.is_elevated_window(target)

    def _wait_front(self, target: int, timeout: float = 0.5) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if int(user32.GetForegroundWindow() or 0) == target:
                # 前に出た直後は、入力欄へキーが届く準備ができていない
                # アプリがある（ブラウザなど）。ほんの少し待つ。
                time.sleep(0.03)
                return True
            time.sleep(0.01)
        return False

    # ------------------------------------------------------------ メニュー

    def _menu(self, x: int, y: int) -> None:
        clip = self.model.current()
        if clip is None or self.headless:
            return
        ids = self.model.chosen()
        kind = look(clip)
        if kind == "download":
            self._file_menu(x, y, ids, clip)
            return
        menu = user32.CreatePopupMenu()
        subs: list[int] = []
        try:
            add = user32.AppendMenuW
            if len(ids) > 1:
                add(menu, MF_STRING, M_PASTE, t("clip.menu_paste_n",
                                                n=len(ids)))
            else:
                add(menu, MF_STRING, M_PASTE, t("clip.menu_paste"))
            if clip.kind == "text":
                add(menu, MF_STRING, M_PLAIN, t("clip.menu_plain"))
                tf = user32.CreatePopupMenu()
                subs.append(tf)
                from .clipmodel import TRANSFORMS  # noqa: PLC0415
                for i, name in enumerate(TRANSFORMS):
                    add(tf, MF_STRING, M_TRANSFORM + i, t(f"clip.tf_{name}"))
                add(menu, MF_POPUP, tf, t("clip.menu_transform"))
            add(menu, MF_STRING, M_COPY, t("clip.menu_copy"))
            add(menu, MF_SEPARATOR, 0, None)
            add(menu, MF_STRING, M_PIN,
                t("clip.menu_unpin" if clip.pinned else "clip.menu_pin"))
            groups = user32.CreatePopupMenu()
            subs.append(groups)
            for g in self.store.groups():
                flags = MF_GRAYED if g.id == clip.group_id else MF_STRING
                add(groups, flags, M_GROUP + g.id, g.name)
            add(groups, MF_SEPARATOR, 0, None)
            add(groups, MF_STRING, M_NEW_GROUP, t("clip.menu_new_group"))
            add(menu, MF_POPUP, groups, t("clip.menu_move"))
            if clip.group_id != HISTORY:
                add(menu, MF_STRING, M_TO_HISTORY, t("clip.menu_to_history"))
            if clip.kind == "text" or clip.title or clip.group_id:
                add(menu, MF_STRING, M_EDIT, t("clip.menu_edit"))
            if kind == "link":
                add(menu, MF_STRING, M_OPEN, t("clip.menu_open_link"))
            elif kind == "image":
                add(menu, MF_STRING, M_OPEN, t("clip.menu_open"))
                add(menu, MF_STRING, M_SAVE, t("clip.menu_save_image"))
                add(menu, MF_STRING, M_FOLDER, t("clip.menu_show_folder"))
            elif kind == "files":
                add(menu, MF_STRING, M_FOLDER, t("clip.menu_show_folder"))
            add(menu, MF_SEPARATOR, 0, None)
            add(menu, MF_STRING, M_DELETE, t("clip.menu_delete"))
            add(menu, MF_SEPARATOR, 0, None)
            add(menu, MF_STRING, M_SETTINGS, t("clip.menu_settings"))
            self._modal += 1
            try:
                choice = user32.TrackPopupMenu(
                    menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY,
                    x, y, 0, self._hwnd, None)
            finally:
                self._modal -= 1
        finally:
            user32.DestroyMenu(menu)      # 中のサブメニューも一緒に消える
        if choice:
            self._menu_choice(int(choice), ids, clip)

    def _file_menu(self, x: int, y: int, ids: list[int],
                   clip: clipstore.Clip) -> None:
        """「ダウンロード」の項目の右クリック。ファイルは消さない。"""
        menu = user32.CreatePopupMenu()
        try:
            add = user32.AppendMenuW
            add(menu, MF_STRING, M_PASTE, t("clip.menu_paste_file"))
            add(menu, MF_STRING, M_COPY, t("clip.menu_copy"))
            add(menu, MF_SEPARATOR, 0, None)
            add(menu, MF_STRING, M_OPEN, t("clip.menu_open"))
            add(menu, MF_STRING, M_FOLDER, t("clip.menu_show_folder"))
            groups = user32.CreatePopupMenu()
            for g in self.store.groups():
                add(groups, MF_STRING, M_GROUP + g.id, g.name)
            add(groups, MF_SEPARATOR, 0, None)
            add(groups, MF_STRING, M_NEW_GROUP, t("clip.menu_new_group"))
            add(menu, MF_POPUP, groups, t("clip.menu_file_to_group"))
            add(menu, MF_SEPARATOR, 0, None)
            add(menu, MF_STRING, M_SETTINGS, t("clip.menu_settings"))
            self._modal += 1
            try:
                choice = user32.TrackPopupMenu(
                    menu, TPM_RETURNCMD | TPM_RIGHTBUTTON | TPM_NONOTIFY,
                    x, y, 0, self._hwnd, None)
            finally:
                self._modal -= 1
        finally:
            user32.DestroyMenu(menu)
        if choice:
            self._menu_choice(int(choice), ids, clip)

    def _menu_choice(self, choice: int, ids: list[int],
                     clip: clipstore.Clip) -> None:
        from .clipmodel import TRANSFORMS  # noqa: PLC0415
        if choice == M_PASTE:
            self._run(Command("paste", ids))
        elif choice == M_PLAIN:
            self._run(Command("paste", ids, plain=True))
        elif M_TRANSFORM <= choice < M_TRANSFORM + len(TRANSFORMS):
            self._run(Command("paste", ids,
                              transform=TRANSFORMS[choice - M_TRANSFORM]))
        elif choice == M_COPY:
            self._run(Command("copy", ids))
        elif choice == M_PIN:
            self._run(Command("pin", ids))
        elif choice == M_EDIT:
            self._run(Command("edit", [clip.id]))
        elif choice == M_OPEN:
            self._open_item([clip.id])
        elif choice == M_FOLDER:
            self._show_folder(clip)
        elif choice == M_SAVE:
            self._save_image_as(clip)
        elif choice == M_DELETE:
            self._run(Command("delete", ids))
        elif choice == M_SETTINGS:
            self._run(Command("settings"))
        elif choice == M_TO_HISTORY:
            self._move(ids, HISTORY)
        elif choice == M_NEW_GROUP:
            gid = self.store.add_group(t("clip.default_group") + " "
                                       + str(len(self.store.groups()) + 1))
            self._move(ids, gid)
        elif choice >= M_GROUP:
            self._move(ids, choice - M_GROUP)

    def _group_menu(self, ids: list[int]) -> None:
        """Ctrl+G：グループを選ぶメニューを、選んでいる行の所に出す。"""
        if not ids or self.headless:
            return
        clip = self._clip(ids[0])
        menu = user32.CreatePopupMenu()
        try:
            for i, g in enumerate(self.store.groups()):
                label = (f"&{i + 1}  " if i < 9 else "    ") + g.name
                flags = MF_GRAYED if clip and g.id == clip.group_id else 0
                user32.AppendMenuW(menu, flags, M_GROUP + g.id, label)
            user32.AppendMenuW(menu, MF_SEPARATOR, 0, None)
            if clip and clip.group_id != HISTORY:
                user32.AppendMenuW(menu, MF_STRING, M_TO_HISTORY,
                                   t("clip.menu_to_history"))
            user32.AppendMenuW(menu, MF_STRING, M_NEW_GROUP,
                               t("clip.menu_new_group"))
            x, y = self._row_screen_point(self.model.sel)
            self._modal += 1
            try:
                choice = user32.TrackPopupMenu(
                    menu, TPM_RETURNCMD | TPM_NONOTIFY, x, y, 0,
                    self._hwnd, None)
            finally:
                self._modal -= 1
        finally:
            user32.DestroyMenu(menu)
        if choice == M_TO_HISTORY:
            self._move(ids, HISTORY)
        elif choice == M_NEW_GROUP and clip:
            self._menu_choice(M_NEW_GROUP, ids, clip)
        elif choice >= M_GROUP:
            self._move(ids, int(choice) - M_GROUP)

    def _move(self, ids: list[int], gid: int) -> None:
        moved = self.store.move([i for i in ids if i >= 0], gid)
        for clip_id in (i for i in ids if i < 0):
            # ダウンロードのファイルは動かさない。場所だけをグループに写す
            clip = self._virtual.get(clip_id)
            if clip is None:
                continue
            import hashlib  # noqa: PLC0415
            hash_ = hashlib.sha1(("f:" + clip.path).encode("utf-8")
                                 ).hexdigest()
            if self.store.add(kind="files", hash_=hash_, files=[clip.path],
                              group_id=gid, title=clip.title,
                              app="explorer.exe"):
                moved += 1
        if not moved:
            return
        name = t("clip.tab_history") if gid == HISTORY else (
            self.store.group(gid).name if self.store.group(gid) else "")
        self.model.multi = []
        self.model.reload()
        self.model.say(t("clip.moved", name=name))
        self._note_timer(2.6)
        self._repaint()

    def _open_item(self, ids: list[int]) -> None:
        if not ids or self.headless:
            return
        clip = self._clip(ids[0])
        if clip is None:
            return
        kind = look(clip)
        try:
            if kind == "download":
                self._hide()
                os.startfile(clip.path)  # noqa: S606
            elif kind == "link":
                url = clip.snippet.strip()
                if url.lower().startswith("www."):
                    url = "https://" + url
                if url.lower().startswith(("http://", "https://")):
                    self._hide()
                    os.startfile(url)  # noqa: S606
            elif kind == "image":
                self._hide()
                os.startfile(str(self.store.image_dir / clip.image))  # noqa
            elif kind == "files" and clip.files:
                self._show_folder(clip)
        except OSError:
            log.exception("開けませんでした")

    def _show_folder(self, clip: clipstore.Clip) -> None:
        path = str(self.store.image_dir / clip.image) if clip.image else (
            clip.files[0] if clip.files else "")
        if not path:
            return
        self._hide()
        try:
            subprocess.Popen(["explorer.exe", "/select,", path])  # noqa: S603
        except OSError:
            log.exception("フォルダを開けませんでした")

    def _save_image_as(self, clip: clipstore.Clip) -> None:
        src = self.store.image_dir / clip.image
        name = time.strftime(f"{t('clip.kind_image')} %Y-%m-%d %H.%M.%S.png",
                             time.localtime(clip.created or time.time()))
        buf = ctypes.create_unicode_buffer(name, 1024)
        ofn = OPENFILENAMEW()
        ofn.lStructSize = ctypes.sizeof(OPENFILENAMEW)
        ofn.hwndOwner = self._hwnd
        ofn.lpstrFilter = "PNG\0*.png\0\0"
        ofn.lpstrFile = ctypes.cast(buf, wintypes.LPWSTR)
        ofn.nMaxFile = 1024
        ofn.lpstrDefExt = "png"
        ofn.Flags = 0x2 | 0x800 | 0x8 | 0x80000
        self._modal += 1
        try:
            ok = comdlg32.GetSaveFileNameW(ctypes.byref(ofn))
        finally:
            self._modal -= 1
        if ok and buf.value:
            try:
                Path(buf.value).write_bytes(src.read_bytes())
                self.model.say(t("clip.image_saved"))
                self._note_timer(2.6)
                self._repaint()
            except OSError:
                log.exception("画像を保存できませんでした")

    # ------------------------------------------------------------ ドラッグ

    def _drag(self, index: int) -> None:
        if not 0 <= index < len(self.model.view):
            return
        clip = self.model.view[index]
        # ダウンロード項目（負のID）も正しく取得できるよう _payload を使う
        payload = self._payload(clip.id)
        if payload is None:
            return
        text: str | None = None
        files: list[str] | None = None
        if payload.kind == "image" and payload.image_path is not None:
            name = time.strftime(
                f"{t('clip.kind_image')} %Y-%m-%d %H.%M.%S.png",
                time.localtime(clip.created or time.time()))
            copy = clipdrag.friendly_copy(payload.image_path, name)
            if copy is None:
                return
            files = [str(copy)]
        elif payload.kind == "files":
            files = [f for f in payload.files if os.path.exists(f)]
            if not files:
                return
        else:
            text = payload.text
            if clip.group_id != HISTORY and self.cfg.bool_(
                    "clip_expand_vars", True):
                text = expand(text, clipboard=self._current_clip_text())
        if self.headless:
            dryrun.record("clip_drag", text=text, files=files,
                          what=payload.kind)
            return
        # 落とす先が窓の後ろにあっても見えるよう薄くし、
        # マウスが窓の上にあっても後ろの窓へ落とせるよう透過属性を付与
        self._set_alpha(45)
        old_exstyle = user32.GetWindowLongW(self._hwnd, GWL_EXSTYLE)
        user32.SetWindowLongW(self._hwnd, GWL_EXSTYLE,
                              old_exstyle | WS_EX_TRANSPARENT)
        self._modal += 1
        try:
            result = clipdrag.drag(self._hwnd, text=text, files=files)
        finally:
            self._modal -= 1
            user32.SetWindowLongW(self._hwnd, GWL_EXSTYLE, old_exstyle)
            self._apply_opacity()
        log.info("ドラッグ: %s（%s）", result, payload.kind)
        if result == "dropped":
            if clip.id >= 0:
                self.store.mark_used([clip.id])
            if self.cfg.bool_("clip_close_after_drop", True):
                self._hide()
                return
            self.model.reload()
        self._repaint()

    # ============================================================ 設定画面

    def api(self, name: str, payload: dict) -> dict:  # noqa: C901
        """設定画面からの頼み。HTTP のスレッドで動く（store は共有できる）。"""
        store = self.store
        p = payload or {}

        def changed(keys: bool = False) -> dict:
            self.refresh()
            if keys:
                self.configure()
            return {"ok": True}

        if name == "clip_overview":
            groups = [{"id": g.id, "name": g.name, "hotkey": g.hotkey,
                       "count": g.count} for g in store.groups()]
            return {"ok": True, "groups": groups,
                    "history": store.history_count(),
                    "stats": store.stats(), "paused": self.paused,
                    "error": self.last_error}
        if name == "clip_items":
            gid = int(p.get("group_id", 0))
            rows = []
            for clip in self._items(gid)[:2000]:
                rows.append(self._row_json(clip))
            manual = self.cfg.str_("clip_group_sort", "manual") == "manual"
            return {"ok": True, "items": rows, "manual": manual}
        if name == "clip_item_get":
            clip = store.get(int(p.get("id", 0)))
            if clip is None:
                return {"ok": False}
            data = self._row_json(clip)
            data["text"] = store.full_text(clip.id) if clip.kind == "text" \
                else ""
            return {"ok": True, "item": data}
        if name == "clip_item_save":
            title = str(p.get("title", ""))[:200]
            text = str(p.get("text", ""))
            secret = bool(p.get("secret"))
            clip_id = int(p.get("id", 0) or 0)
            if clip_id:
                ok = store.update_item(clip_id, title=title,
                                       text=text if "text" in p else None,
                                       secret=secret if "secret" in p
                                       else None)
                return changed() if ok else {"ok": False}
            gid = int(p.get("group_id", 0))
            if not text.strip() and not title.strip():
                return {"ok": False, "error": "empty"}
            new_id = store.add(kind="text", hash_=clipstore.text_hash(text),
                               text=text, group_id=gid, title=title,
                               secret=secret and bool(text))
            if not new_id:
                return {"ok": False}
            changed()
            return {"ok": True, "id": new_id}
        if name == "clip_item_delete":
            store.delete([int(i) for i in p.get("ids", [])])
            return changed()
        if name == "clip_item_move":
            store.move([int(i) for i in p.get("ids", [])],
                       int(p.get("group_id", 0)))
            return changed()
        if name == "clip_item_reorder":
            if self.cfg.str_("clip_group_sort", "manual") != "manual":
                return {"ok": False, "error": t("clip.reorder_manual_only")}
            store.reorder(int(p.get("id", 0)), int(p.get("delta", 0)),
                          pinned_first=self.cfg.bool_("clip_pinned_first",
                                                      True))
            return changed()
        if name == "clip_item_pin":
            store.set_pinned([int(i) for i in p.get("ids", [])],
                             bool(p.get("pinned", True)))
            return changed()
        if name == "clip_group_add":
            gid = store.add_group(str(p.get("group_name", "")).strip() or
                                  t("clip.default_group"))
            changed(keys=True)
            return {"ok": True, "id": gid}
        if name == "clip_group_rename":
            ok = store.rename_group(int(p.get("id", 0)),
                                    str(p.get("group_name", "")))
            return changed() if ok else {"ok": False}
        if name == "clip_group_delete":
            store.delete_group(int(p.get("id", 0)))
            return changed(keys=True)
        if name == "clip_group_reorder":
            store.reorder_group(int(p.get("id", 0)), int(p.get("delta", 0)))
            return changed(keys=True)
        if name == "clip_group_hotkey":
            spec = str(p.get("hotkey", "")).strip().lower()
            gid = int(p.get("id", 0))
            problem = self.key_problem(spec, group_id=gid) if spec else ""
            if problem:
                return {"ok": False, "error": problem}
            store.set_group_hotkey(gid, spec)
            return changed(keys=True)
        if name == "clip_key_check":
            # 設定画面でほかのショートカットを変えるときにも、グループの
            # キーとぶつからないかを確かめる（websettings.set_value から）
            problem = self.key_problem(str(p.get("spec", "")),
                                       setting=str(p.get("setting", "")))
            return {"ok": not problem, "error": problem}
        if name == "clip_history_clear":
            removed = store.clear_history(
                keep_pinned=bool(p.get("keep_pinned", True)))
            changed()
            return {"ok": True, "removed": removed}
        if name == "clip_export":
            return {"ok": True, "name": "koe-type-clipboard-groups.json",
                    "text": store.export_json(
                        include_secrets=bool(p.get("include_secrets")))}
        if name == "clip_import":
            try:
                counts = store.import_json(str(p.get("text", "")))
            except (ValueError, TypeError) as exc:
                return {"ok": False, "error": str(exc)}
            changed(keys=True)
            return {"ok": True, **counts}
        if name == "clip_open":
            self.open(target=self._last_target())
            return {"ok": True}
        if name == "clip_pause":
            return {"ok": True, "paused": self.toggle_pause()}
        return {"ok": False, "error": f"unknown: {name}"}

    def key_problem(self, spec: str, *, group_id: int = 0,
                    setting: str = "") -> str:
        """そのキーを使えない理由（使えるなら ""）。

        ★前は録音キーと一覧のキーと文字で比べるだけだった。変換の一覧・
        言語の切り替え・特定動作・ほかのグループのキーとぶつかると、
        あとから登録したほうが黙って効かなくなり、Ctrl+V のような
        貼り付けのキーまで取れてしまった（レビューで発覚）。
        """
        vk, mods = parse_key(spec)
        if not vk:
            return t("cweb.key_unreadable", spec=spec)
        normal = hotkeys.normalise(spec)
        if normal in ("ctrl+v", "ctrl+shift+v", "shift+insert"):
            return t("cweb.key_paste")
        for level, ja, en, _fj, _fe in hotkeys.conflicts(spec):
            if level == "bad":
                return ja if language() == "ja" else en
        special = {v[0] for v in hotkeys.SPECIAL_KEYS.values()}
        if not mods and vk not in special:
            return t("cweb.key_needs_modifier")
        mine = (vk, mods)
        for label, other in self._keys_in_use(group_id=group_id,
                                              setting=setting):
            if parse_key(other) == mine:
                return t("cweb.key_taken", name=label)
        return ""

    def _keys_in_use(self, *, group_id: int = 0,
                     setting: str = "") -> list[tuple[str, str]]:
        """koe-type が使っているショートカット（自分のぶんは除く）。"""
        cfg = self.cfg
        out = []
        for key, label in (("hotkey", t("cweb.use_record")),
                           ("clip_hotkey", t("cweb.use_clip")),
                           ("recipe_hotkey", t("cweb.use_recipe")),
                           ("hotkey_language", t("cweb.use_language")),
                           ("action_hotkey", t("cweb.use_action"))):
            if key != setting and cfg.str_(key, "").strip():
                out.append((label, cfg.str_(key, "")))
        for inst in cfg.get("ai_custom_instructions") or []:
            if isinstance(inst, dict) and str(inst.get("hotkey") or ""):
                out.append((str(inst.get("name") or inst.get("id")),
                            str(inst["hotkey"])))
        for g in self.store.groups():
            if g.hotkey and g.id != group_id:
                out.append((g.name, g.hotkey))
        return out

    def _row_json(self, clip: clipstore.Clip) -> dict:
        return {
            "id": clip.id, "group_id": clip.group_id, "kind": clip.kind,
            "look": look(clip), "title": clip.title,
            "text": "" if clip.secret else clip.snippet[:600],
            "secret": clip.secret, "pinned": clip.pinned,
            "width": clip.width, "height": clip.height,
            "files": clip.files[:20], "app": app_label(clip.app),
            "time": time.strftime("%Y/%m/%d %H:%M",
                                  time.localtime(clip.touched or 0)),
            "used": clip.use_count, "chars": clip.chars,
        }

    def image_bytes(self, clip_id: int) -> bytes:
        """設定画面に出す画像（小さめの版があればそれ）。"""
        clip = self.store.get(clip_id)
        if clip is None or not clip.image:
            return b""
        prev = self.store.image_dir / clipstore.preview_name(clip.image)
        path = prev if prev.exists() else self.store.image_dir / clip.image
        try:
            return path.read_bytes()
        except OSError:
            return b""
