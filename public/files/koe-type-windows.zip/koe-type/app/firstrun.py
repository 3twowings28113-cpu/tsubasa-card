"""初回の案内（6 画面）の中身。

画面そのものは `app/web/onboarding.*`。ここはその裏側で、

  1. ようこそ
  2. この PC を調べる（→ `app.hardware`）
  3. モデルを用意する（ダウンロード：進み具合・再開・確認）
  4. マイクを選んで、声が届いているか見る
  5. ショートカットと、ぶつかりの確認
  6. 話してみる／使い方のまとめ

を受け持つ。**調べるだけのものは何も書き換えない。**
設定を変えるのは、利用者がその画面で選んだときだけ。

どこまで進んだかは設定の `onboarding_done` に残る。
終わっていなければ、起動のたびに開く。
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any

from . import catalog, hardware, hotkeys, i18n

log = logging.getLogger(__name__)

# おすすめのモデルに付ける、ひとこと説明
MODEL_NOTES = {
    "sensevoice-resident": ("速くて日本語に強い。ふだん使いにいちばん向く",
                            "Fast and good at Japanese. Best for daily use"),
    "whisper-turbo-resident": ("いちばん正確。ただし 12 倍ほど時間がかかる",
                               "Most accurate, but about 12x slower"),
    "moonshine-base-ja": ("いちばん軽い。非力な PC 向け",
                          "Lightest. For slower PCs"),
}

# ショートカットの選べる候補（Handy などとぶつかりにくいもの）
HOTKEY_CHOICES = (
    ("ctrl+space", "いちばんふつう。日本語入力の切り替えと重ならない"),
    ("muhenkan", "親指で押せる。ほかのアプリとまず重ならない"),
    ("ctrl+alt+space", "ぶつかりにくい。3 つ同時に押す"),
    ("win+alt+h", "Windows 標準の音声入力に近い押し心地"),
)


class Onboarding:
    """初回の案内の状態。設定画面のサーバーから呼ばれる。"""

    def __init__(self, bridge) -> None:  # noqa: ANN001
        self.bridge = bridge
        self.cfg = bridge.cfg
        self.step = 0
        self.profile: hardware.Profile | None = None
        self.advice: hardware.Advice | None = None
        self.practice = ""
        self.download = {"state": "idle", "fraction": 0.0, "detail": ""}
        self._lock = threading.Lock()
        self._probing = False
        self._downloading_now = False

    # -------------------------------------------------------- 調べる

    def probe(self) -> None:
        """この PC を調べる。**時間がかかるので別のスレッドで。**"""
        with self._lock:
            if self._probing:
                return
            self._probing = True

        def run() -> None:
            try:
                prof = hardware.profile(bench=True)
                advice = hardware.recommend(prof)
                self.profile = prof
                self.advice = advice
                log.info("この PC を調べました: %s / おすすめ %s",
                         prof.cpu_name, advice.name)
                # まだ選んでいなければ、おすすめを入れておく。
                # 既定のままのときだけ差し替える。利用者が自分で
                # 別のモデルを選んでいたら、その選択を尊重する
                # （調べ直すたびに選び直しになる事故を防ぐ）。
                current = self.cfg.str_("model", "")
                if current in ("", catalog.DEFAULT_MODEL) and not (
                        catalog.model_ready(current)):
                    self.cfg.set("model", advice.model)
            except Exception:
                log.exception("この PC を調べられませんでした")
            finally:
                self._probing = False

        threading.Thread(target=run, name="probe", daemon=True).start()

    # -------------------------------------------------------- モデル

    def _progress_for(self, missing: list, total: int):
        """ファイルごとの進み具合を、全体の割合に直す関数を作る。

        昔はファイルごとの割合をそのまま出していたので、エンジン
        （17MB）が終わった直後にモデル（250MB）へ移ると表示が
        100% から 0% へ戻り、「失敗した」と誤解されていた。
        名前から、そのファイルより前に終わった分のバイト数を引く。
        """
        offsets: dict[str, int] = {}
        done_bytes = 0
        for asset in missing:
            offsets.setdefault(asset.name, done_bytes)
            done_bytes += asset.size

        def progress(name: str, frac: float) -> None:
            base = offsets.get(name, 0)
            size = next((a.size for a in missing if a.name == name), 0)
            whole = (base + size * max(0.0, min(1.0, frac))) / total
            # 巻き戻って見えないよう、いまの表示より小さくしない
            shown = max(whole, float(self.download.get("fraction", 0.0)))
            self.download = {"state": "running",
                             "fraction": max(0.0, min(1.0, shown)),
                             "detail": name}

        return progress

    def start_download(self) -> None:
        with self._lock:
            if self._downloading_now:
                # 二度押しで同じファイルへ同時に書くと壊れる。
                # 進んでいるものがあるなら、それを見守るだけにする。
                return
            self._downloading_now = True
        key = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        self.download = {"state": "running", "fraction": 0.0,
                         "detail": "準備しています…"}

        def run() -> None:
            from . import downloads  # noqa: PLC0415
            try:
                if key not in catalog.MODELS:
                    self.download = {
                        "state": "error", "fraction": 0.0,
                        "detail": "選ばれているモデルが見つかりません。"
                                  "「おすすめ」のモデルを選んでから、"
                                  "もう一度ためしてください。"}
                    return
                missing = catalog.missing_assets(key)
                if not missing:
                    self.download = {"state": "done", "fraction": 1.0,
                                     "detail": ""}
                    return
                # 始める前に空き容量を確かめる。途中でいっぱいに
                # なると、受け取り済みの分まで壊れるため。
                total = sum(a.size for a in missing) or 1
                downloads.check_space(catalog.MODEL_DIR / "_",
                                      total)
                downloads.fetch_all(list(missing),
                                    self._progress_for(missing, total))
                if catalog.usable(key):
                    self.download = {"state": "done", "fraction": 1.0,
                                     "detail": ""}
                    self.bridge.action("model_changed")
                    log.info("モデルを用意しました: %s", key)
                else:
                    self.download = {
                        "state": "error", "fraction": 0.0,
                        "detail": "ファイルがそろいませんでした。"
                                  "もう一度ためすと、足りない分だけを"
                                  "取りに行きます。"}
            except downloads.DownloadError as exc:
                # downloads 側の言葉は、次に何をすればよいかまで
                # 書いてある。そのまま見せる。
                log.warning("モデルを取れませんでした: %s", exc)
                self.download = {"state": "error", "fraction": 0.0,
                                 "detail": str(exc)[:300]}
            except Exception as exc:  # noqa: BLE001
                log.exception("モデルを取れませんでした")
                self.download = {
                    "state": "error", "fraction": 0.0,
                    "detail": "うまくいきませんでした。通信を確認して、"
                              "もう一度ためしてください。途中まで"
                              "受け取った分は再開に使います。"
                              f"（{type(exc).__name__}）"}
            finally:
                with self._lock:
                    self._downloading_now = False

        threading.Thread(target=run, name="first-download",
                         daemon=True).start()

    def model_rows(self) -> list:
        picked = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        best = self.advice.model if self.advice else catalog.DEFAULT_MODEL
        rows = []
        for key in ("sensevoice-resident", "whisper-turbo-resident",
                    "moonshine-base-ja"):
            spec = catalog.MODELS.get(key)
            if spec is None:
                continue
            ja, en = MODEL_NOTES.get(key, ("", ""))
            rows.append({
                "key": key, "name": spec.name,
                "note": ja if i18n.language() == "ja" else en,
                "recommended": key == best,
                "ready": catalog.model_ready(key),
                "selected": key == picked,
            })
        return rows

    def size_note(self) -> str:
        key = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        total = sum(a.size for a in catalog.missing_assets(key))
        if total <= 0:
            return "すべて用意できています"
        return f"およそ {total / 1e6:.0f} MB"

    # -------------------------------------------------------- キー

    def hotkey_rows(self) -> list:
        out = []
        for spec, note in HOTKEY_CHOICES:
            out.append({"spec": spec, "label": hotkeys.label(spec),
                        "note": note})
        return out

    def hotkey_check(self) -> dict:
        from . import selfcheck  # noqa: PLC0415
        spec = self.cfg.str_("hotkey", "ctrl+space")
        try:
            result = selfcheck.check_hotkey(
                spec, tuple(self.cfg.list_("excluded_apps")))
        except Exception as exc:  # noqa: BLE001
            return {"state": "warn", "detail": f"調べられません: {exc}"}
        status = str(getattr(result, "status", "ok")).lower()
        state = {"ok": "ok", "info": "ok", "warn": "warn",
                 "bad": "bad"}.get(status, "warn")
        detail = getattr(result, "detail_ja", "") or ""
        if not detail:
            detail = ("ぶつかっているアプリは見つかりませんでした。"
                      if state == "ok" else "")
        return {"state": state, "detail": detail,
                "hint": getattr(result, "fix_ja", "") or ""}

    def other_voice_apps(self) -> list:
        from . import selfcheck  # noqa: PLC0415
        try:
            result = selfcheck.check_other_voice_input()
        except Exception:  # noqa: BLE001
            return []
        extra = getattr(result, "extra", None) or {}
        return [str(x) for x in (extra.get("apps") or [])]

    # -------------------------------------------------------- まとめ

    def state(self) -> dict[str, Any]:
        key = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        ready = catalog.model_ready(key)
        spec = catalog.MODELS.get(key)
        from . import theme as theme_mod  # noqa: PLC0415
        out: dict[str, Any] = {
            "step": self.step,
            "theme": theme_mod.resolve(self.cfg.str_("theme", "system")),
            "profile": self.profile.as_dict() if self.profile else None,
            "rows": (hardware.summary_lines(self.profile)
                     if self.profile else []),
            "advice": self.advice.as_dict() if self.advice else None,
            "probing": self._probing,
            "model": key,
            "models": self.model_rows(),
            "ready": ready,
            "ready_note": (f"{spec.name} が使えます" if ready and spec else ""),
            "size_note": self.size_note(),
            "download": self.download,
            "microphones": self.bridge.microphones(),
            "microphone": self.cfg.str_("microphone", ""),
            "mic_error": self.bridge.mic_error(),
            "level": self.bridge.mic_level(),
            "hotkey": self.cfg.str_("hotkey", "ctrl+space"),
            "hotkey_label": hotkeys.label(self.cfg.str_("hotkey",
                                                        "ctrl+space")),
            "hotkey_options": self.hotkey_rows(),
            "hotkey_check": self.hotkey_check(),
            "other_apps": self.other_voice_apps(),
            "practice": self.practice,
            "recording": self.bridge.is_recording(),
        }
        return out

    def run(self, name: str, payload: dict) -> dict:
        if name == "probe":
            self.probe()
        elif name == "download":
            self.start_download()
        elif name == "choose":
            key = str(payload.get("model", ""))
            if key in catalog.MODELS:
                self.cfg.set("model", key)
                self.bridge.action("model_changed")
        elif name == "microphone":
            self.cfg.set("microphone", str(payload.get("value", "")))
        elif name == "hotkey":
            spec = str(payload.get("spec", ""))
            if spec:
                self.cfg.set("hotkey", hotkeys.normalise(spec))
        elif name == "step":
            self.step = max(0, min(5, int(payload.get("step", 0))))
        elif name == "finish":
            self.cfg.set("onboarding_done", True)
            log.info("初回の案内が終わりました（%s）",
                     "あとで" if payload.get("skipped") else "最後まで")
        else:
            return {"ok": False, "error": f"unknown: {name}"}
        return {"ok": True}

    # -------------------------------------------------------- 練習

    def heard(self, text: str) -> None:
        """練習の画面に出す文字。本体から呼ばれる。"""
        if not text:
            return
        joined = (self.practice + text)[-400:]
        self.practice = joined
        self.bridge.push({"type": "practice", "text": joined})


def should_open(cfg) -> bool:  # noqa: ANN001
    """初回の案内を開くべきか。

    まだ終わっていない、かモデルが 1 つもないときだけ。
    一度終われば二度と勝手には開かない（設定から開き直せる）。
    """
    if cfg.bool_("onboarding_done", False):
        return False
    if any(catalog.usable(k) for k in catalog.MODELS):
        # モデルと実行ファイルがそろっている＝すでに使えている人。
        # 新しい版に上げたとたんに案内が出ると、驚かせるだけ。
        # ★モデルだけあって実行ファイルが無い人は「使えている」
        # ことにならない。昔はモデルだけで判定していたので、
        # エンジンが無いまま案内も出ず、詰まっていた。
        cfg.set("onboarding_done", True)
        return False
    return True


def wait_a_moment() -> None:
    """起動直後は窓が落ち着くまで少し待つ（見た目のため）。"""
    time.sleep(1.2)
