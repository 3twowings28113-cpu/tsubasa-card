"""使えるモデルと実行ファイルの一覧。

リポジトリにはモデルもバイナリも入れない。ここに書いた**公式の配布元**から
初回起動時か設定画面でダウンロードする。
ライセンスは README / THIRD_PARTY_NOTICES.md にも載せている。
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field

from .util import BIN_DIR, MODEL_DIR

log = logging.getLogger(__name__)

HF = "https://huggingface.co"
GH = "https://github.com"


@dataclass(frozen=True)
class Asset:
    name: str
    url: str
    size: int                      # バイト（おおよそ。進捗表示用）
    into: str = "models"           # "models" or "engines"
    unzip_from: str = ""           # zip の中のこのファイルを取り出す
    rename_to: str = ""


@dataclass(frozen=True)
class Runtime:
    key: str
    ja: str
    en: str
    assets: tuple[Asset, ...]
    license: str
    license_url: str
    source: str


@dataclass(frozen=True)
class Model:
    key: str
    name: str
    ja: str
    en: str
    runtime: str
    argv: tuple[str, ...]
    assets: tuple[Asset, ...]
    # accuracy / speed は bench/RESULTS.md の実測から決めている。
    #   accuracy: 合成音声16文の文字誤り率 cer から
    #             <=2.1% -> 5 / <=3% -> 4 / <=5% -> 3 / <=10% -> 2 / それ以上 -> 1
    #   speed:    5秒の発話に換算した所要時間から
    #             <=0.8s -> 5 / <=1.5s -> 4 / <=3s -> 3 / <=8s -> 2 / それ以上 -> 1
    accuracy: int                  # 1〜5
    speed: int                     # 1〜5
    cer: float                     # 合成音声16文の文字誤り率（％）
    note_ja: str
    note_en: str
    license: str
    license_url: str
    source: str
    join_spaces: bool = True
    supports_hints: bool = False
    languages: tuple[str, ...] = ("ja", "en", "auto")
    extra: dict = field(default_factory=dict)

    @property
    def size(self) -> int:
        return sum(a.size for a in self.assets)


# ---------------------------------------------------------------- 実行ファイル

FUNASR_REL = f"{GH}/modelscope/FunASR/releases/download/v1.4.16"
WHISPER_REL = f"{GH}/ggml-org/whisper.cpp/releases/download/v1.9.2"
TCPP_REL = f"{GH}/handy-computer/transcribe.cpp/releases/download/v0.3.0"
TCPP_DIR = "transcribe-cpp"
SPEECH_REL = f"{GH}/nyosegawa/speech.cpp/releases/download/v0.10.1"
SPEECH_DIR = "speech-cpp"

RUNTIMES: dict[str, Runtime] = {
    "funasr": Runtime(
        "funasr",
        "FunASR llama.cpp ランタイム", "FunASR llama.cpp runtime",
        (
            Asset("llama-funasr-cli.exe",
                  f"{FUNASR_REL}/funasr-llamacpp-windows-x64-avx2.zip",
                  5_200_000, into="engines",
                  unzip_from="llama-funasr-cli.exe"),
            Asset("llama-funasr-sensevoice-vulkan.exe",
                  f"{FUNASR_REL}/funasr-llamacpp-windows-x64-vulkan.zip",
                  15_500_000, into="engines",
                  unzip_from="llama-funasr-sensevoice.exe",
                  rename_to="llama-funasr-sensevoice-vulkan.exe"),
        ),
        "MIT", f"{GH}/modelscope/FunASR/blob/main/LICENSE",
        f"{GH}/modelscope/FunASR/tree/main/runtime/llama.cpp",
    ),
    # ★既定のランタイム。モデルをメモリに置いたまま使えるので、
    # 1 回あたり 0.6 秒かかっていた起動の固定費がなくなる
    # （この PC での実測: SenseVoice Small が 0.62 秒 → 0.12 秒）。
    "tcpp": Runtime(
        "tcpp",
        "transcribe.cpp ランタイム（常駐）",
        "transcribe.cpp runtime (keeps the model loaded)",
        (
            Asset(f"{TCPP_DIR}/transcribe-native-windows-x86_64-cpu-vulkan/"
                  "transcribe.dll",
                  f"{TCPP_REL}/transcribe-native-0.3.0-"
                  "windows-x86_64-cpu-vulkan.tar.gz",
                  17_400_000, into="engines",
                  unzip_from="*"),
        ),
        "MIT", f"{GH}/handy-computer/transcribe.cpp/blob/main/LICENSE",
        f"{GH}/handy-computer/transcribe.cpp",
    ),
    # speech.cpp（Haas など FastConformer 系を worker 常駐で使う）。
    # zip の中はフラットな並びなので、目印の speech.exe から丸ごと
    # 取り出すと、相棒の speech.dll も隣に並ぶ（downloads の "*" 仕様）。
    "speechcpp": Runtime(
        "speechcpp",
        "speech.cpp ランタイム（worker 常駐）",
        "speech.cpp runtime (worker, keeps the model loaded)",
        (
            Asset(f"{SPEECH_DIR}/speech.exe",
                  f"{SPEECH_REL}/speech-0.10.1-windows-x64-vulkan.zip",
                  29_548_632, into="engines", unzip_from="*"),
        ),
        "MIT", f"{GH}/nyosegawa/speech.cpp/blob/main/LICENSE",
        f"{GH}/nyosegawa/speech.cpp",
    ),
    "whispercpp": Runtime(
        "whispercpp",
        "whisper.cpp ランタイム", "whisper.cpp runtime",
        (
            Asset("whisper/whisper-cli.exe",
                  f"{WHISPER_REL}/whisper-blas-bin-x64.zip",
                  60_000_000, into="engines",
                  unzip_from="Release/*"),
        ),
        "MIT", f"{GH}/ggml-org/whisper.cpp/blob/master/LICENSE",
        f"{GH}/ggml-org/whisper.cpp",
    ),
}


# ---------------------------------------------------------------- モデル

MODELS: dict[str, Model] = {
    # ============================================================
    # 常駐（transcribe.cpp）。この PC での実測値を note に書いている。
    # ============================================================
    "sensevoice-resident": Model(
        "sensevoice-resident", "SenseVoice Small",
        "いちばん速く、話しながらの入力に向きます（はじめはこれ）。",
        "The fastest, and the best fit for typing as you speak. Start here.",
        runtime="tcpp",
        argv=(),                      # 常駐方式は外部プロセスを使わない
        assets=(Asset("SenseVoiceSmall-Q8_0.gguf",
                      f"{HF}/handy-computer/SenseVoiceSmall-gguf/resolve/main/"
                      "SenseVoiceSmall-Q8_0.gguf", 252_684_608),),
        accuracy=3, speed=5, cer=12.3,
        note_ja="4.5 秒の話し声を 0.12 秒で文字にします（内蔵GPUでの実測）。"
                "長く話し続けると苦手になるので、10 秒くらいで"
                "いったん区切って聞き取ります。",
        note_en="Turns 4.5 seconds of speech into text in 0.12 s (measured "
                "on this PC's integrated GPU). It struggles with long "
                "stretches, so speech is cut into chunks of about ten "
                "seconds.",
        license="FunASR Model License v1.1",
        license_url=f"{GH}/modelscope/FunASR/blob/main/MODEL_LICENSE",
        source=f"{HF}/handy-computer/SenseVoiceSmall-gguf",
        # SenseVoice は語彙ヒントを受け付けない（エンジンが無視する）。
        # 固有名詞は辞書の置き換えで直す。
        supports_hints=False,
        # 長い音が苦手。FLEURS 日本語 200 本のうち 22 本（11%）で、
        # 11 秒を超えるあたりから記号しか返さなくなった。
        # 区間をこの長さで切り、それでも空なら半分に割って聞き直す。
        extra={"backend": "vulkan", "resident": True,
               "file": "SenseVoiceSmall-Q8_0.gguf", "best_seconds": 10},
    ),
    "whisper-turbo-resident": Model(
        "whisper-turbo-resident", "Whisper large-v3-turbo",
        "いちばん正確ですが、ひと区切りに 1.3 秒ほどかかります。",
        "The most accurate, but about 1.3 s per phrase.",
        runtime="tcpp",
        assets=(Asset("whisper-large-v3-turbo-Q8_0.gguf",
                      f"{HF}/handy-computer/whisper-large-v3-turbo-gguf/"
                      "resolve/main/whisper-large-v3-turbo-Q8_0.gguf",
                      886_400_000),),
        argv=(),
        accuracy=5, speed=2, cer=4.82,
        note_ja="長い話にも強く、誤りがいちばん少ないモデルです。"
                "ただしひと区切りに 1.3 秒ほどかかるので、"
                "「話しながら」よりも「ひと区切りごと」に向きます。",
        note_en="The most accurate, and strong on long passages, but about "
                "1.3 s per phrase — better suited to phrase-by-phrase than "
                "to typing as you speak.",
        license="Apache-2.0",
        license_url=f"{HF}/openai/whisper-large-v3-turbo",
        source=f"{HF}/handy-computer/whisper-large-v3-turbo-gguf",
        # 語彙ヒント（vocabulary）は受け付ける。2026-10-26 に AI PC の
        # 本番経路で実証: session.run に vocabulary を渡しても例外に
        # ならず、出力に反映された。SenseVoice はネイティブ層が
        # 「非対応・無視」と返すので、あちらは False のまま。
        supports_hints=True,
        extra={"backend": "vulkan", "resident": True,
               "file": "whisper-large-v3-turbo-Q8_0.gguf",
               "best_seconds": 30},
    ),
    "moonshine-base-ja": Model(
        "moonshine-base-ja", "Moonshine Base 日本語",
        "とても小さく（77MB）、古い PC や GPU なしでも動きます。",
        "Very small (77 MB). Works on older PCs and without a GPU.",
        runtime="tcpp",
        argv=(),
        assets=(Asset("moonshine-base-ja-Q8_0.gguf",
                      f"{HF}/handy-computer/moonshine-base-ja-gguf/resolve/"
                      "main/moonshine-base-ja-Q8_0.gguf", 77_476_480),),
        accuracy=3, speed=5, cer=10.4,
        note_ja="日本語だけを学んだ小さなモデル。77MB しかないので"
                "読み込みが 0.14 秒で済みます。"
                "長く話し続けても取りこぼしません。",
        note_en="A small Japanese-only model. At 77 MB it loads in 0.14 s, "
                "and it keeps up with long stretches of speech.",
        license="MIT",
        license_url=f"{HF}/handy-computer/moonshine-base-ja-gguf",
        source=f"{HF}/handy-computer/moonshine-base-ja-gguf",
        # 長い音にも強い。FLEURS 200 本で空になったものが 1 本もなかった。
        extra={"backend": "vulkan", "resident": True,
               "file": "moonshine-base-ja-Q8_0.gguf", "best_seconds": 30},
    ),
    "haas-ja": Model(
        "haas-ja", "Haas-ja-v1.0",
        "日本語専用の新しいモデル。速さと精度を両立します。",
        "A newer Japanese-only model, both fast and accurate.",
        runtime="speechcpp",
        argv=(),                      # worker 常駐方式（speech.cpp）
        assets=(Asset("Haas-616M-ja-v1.0-Q8_0.gguf",
                      f"{HF}/sakasegawa/Haas-ja-v1.0-GGUF/resolve/main/"
                      "Haas-616M-ja-v1.0-Q8_0.gguf", 656_381_472),),
        accuracy=5, speed=5, cer=4.39,
        note_ja="10 秒の話し声を約 0.5 秒で文字にします（内蔵GPU・"
                "常駐時の実測）。日本語専用に作られたモデルで、"
                "句読点も付きます。長い話は区切りごとに聞き取ります。",
        note_en="Turns 10 seconds of speech into text in about 0.5 s "
                "(measured resident on an integrated GPU). A "
                "Japanese-only model that also writes punctuation; "
                "long speech is handled phrase by phrase.",
        license="Apache-2.0",
        license_url=f"{HF}/third-intelligence/Haas-ja-v1.0",
        source=f"{HF}/sakasegawa/Haas-ja-v1.0-GGUF",
        # 語彙ヒントは worker の keywords で渡せる。ここでは表示形
        # だけを渡し、読みは付けない（Haas 側の推定に任せる）。
        supports_hints=True,
        languages=("ja",),
        # transcribe.dll では読めないので、常駐の担い手は speech.cpp
        # の worker プロセス（app/speechworker.py）。best_seconds は
        # 学習上限（30 秒）に合わせ、区切りは分割救済に任せる。
        extra={"worker": "speech", "resident": True,
               "backend": "vulkan",
               "file": "Haas-616M-ja-v1.0-Q8_0.gguf", "best_seconds": 30},
    ),
    # ============================================================
    # 外部プロセスを起こす方式（常駐が使えない時の受け皿）
    # ============================================================
    "sensevoice-small": Model(
        "sensevoice-small", "SenseVoice Small（旧方式）",
        "上と同じモデルですが、使うたびに読み込むので 5 倍遅くなります。",
        "The same model, but reloaded each time, so five times slower.",
        runtime="funasr",
        argv=("{bin}/llama-funasr-sensevoice-vulkan.exe",
              "-m", "{models}/sensevoice-small-q8.gguf",
              "--backend", "{backend}",
              "-a", "{wav}"),
        assets=(Asset("sensevoice-small-q8.gguf",
                      f"{HF}/FunAudioLLM/SenseVoiceSmall-GGUF/resolve/main/"
                      "sensevoice-small-q8.gguf", 254_208_320),),
        accuracy=5, speed=5, cer=2.04,
        note_ja="Vulkan が使える GPU があれば、5秒の発話を 1 秒ほどで返します"
                "（内蔵GPUでの実測 0.6 秒）。GPU がないと十数秒かかります。",
        note_en="With a Vulkan-capable GPU it returns five seconds of speech in "
                "about a second (0.6 s measured on an integrated GPU). Without "
                "a GPU it takes well over ten seconds.",
        # 元モデル SenseVoiceSmall のライセンスは Apache-2.0 ではなく
        # 「FunASR Model Open Source License Agreement v1.1」。
        # GGUF 配布リポジトリのタグは apache-2.0 になっているが、
        # 上流より緩くはならないので、厳しいほうに従って表示する。
        license="FunASR Model License v1.1",
        license_url=f"{GH}/modelscope/FunASR/blob/main/MODEL_LICENSE",
        source=f"{HF}/FunAudioLLM/SenseVoiceSmall-GGUF",
        extra={"backend": "vulkan", "cpu_backend": "cpu"},
    ),
    "funasr-nano": Model(
        "funasr-nano", "Fun-ASR-Nano",
        "句読点や言い直しの処理が自然。CPUで動くぶん遅い。",
        "Nicer punctuation and disfluency handling. CPU only, so slower.",
        runtime="funasr",
        argv=("{bin}/llama-funasr-cli.exe",
              "--enc", "{models}/funasr-encoder-f16.gguf",
              "-m", "{models}/qwen3-0.6b-q4km.gguf",
              "-a", "{wav}"),
        assets=(
            Asset("funasr-encoder-f16.gguf",
                  f"{HF}/FunAudioLLM/Fun-ASR-Nano-GGUF/resolve/main/"
                  "funasr-encoder-f16.gguf", 469_331_008),
            Asset("qwen3-0.6b-q4km.gguf",
                  f"{HF}/FunAudioLLM/Fun-ASR-Nano-GGUF/resolve/main/"
                  "qwen3-0.6b-q4km.gguf", 484_219_776),
        ),
        accuracy=5, speed=3, cer=1.91,
        note_ja="LLM デコーダ付きで、CPU だけで動きます。"
                "5秒の発話におよそ 1.5〜2 秒（8コアの CPU での実測 1.7 秒）。",
        note_en="Has an LLM decoder and runs on the CPU alone. Roughly 1.5–2 s "
                "for five seconds of speech (1.7 s measured on an 8-core CPU).",
        # Fun-ASR-Nano-2512 はモデルカード・リポジトリとも Apache-2.0（確認済み）
        license="Apache-2.0",
        license_url=f"{HF}/FunAudioLLM/Fun-ASR-Nano-2512",
        source=f"{HF}/FunAudioLLM/Fun-ASR-Nano-GGUF",
    ),
    "whisper-large-v3-turbo": Model(
        "whisper-large-v3-turbo", "Whisper large-v3-turbo（旧方式）",
        "単語ヒントが効く。GPUなしのCPUだとかなり遅い。",
        "Accepts word hints. Quite slow without a supported GPU.",
        runtime="whispercpp",
        argv=("{bin}/whisper/whisper-cli.exe",
              "-m", "{models}/ggml-large-v3-turbo-q8_0.bin",
              "-l", "{language}", "-nt", "-np", "-t", "8",
              "--prompt", "{hints}",
              "-f", "{wav}"),
        assets=(Asset("ggml-large-v3-turbo-q8_0.bin",
                      f"{HF}/ggerganov/whisper.cpp/resolve/main/"
                      "ggml-large-v3-turbo-q8_0.bin", 874_188_075),),
        accuracy=4, speed=1, cer=2.56,
        note_ja="ユーザー辞書の語をヒントとして渡せます。"
                "ただし CPU では 5秒の発話に十数秒かかり、話しながら使うには"
                "向きません（8コアの CPU での実測 14 秒）。",
        note_en="Can take your user dictionary words as hints, but on a CPU five "
                "seconds of speech takes well over ten seconds, which is too "
                "slow to dictate with (14 s measured on an 8-core CPU).",
        # ggml 版の配布元は MIT、元の Whisper も MIT（確認済み）
        license="MIT",
        license_url=f"{GH}/openai/whisper/blob/main/LICENSE",
        source=f"{HF}/ggerganov/whisper.cpp",
        join_spaces=False, supports_hints=True,
    ),
}

DEFAULT_MODEL = "sensevoice-resident"
# 常駐方式が使えない PC での受け皿（exe を毎回起こす昔の方式）
FALLBACK_MODEL = "sensevoice-small"
# 間に合わない時に逃げこむ、いちばん軽いモデル
FAST_MODEL = "sensevoice-resident"


def is_resident(key: str) -> bool:
    spec = MODELS.get(key)
    return bool(spec and spec.extra.get("resident"))


def resident_file(key: str):  # noqa: ANN201
    """常駐モデルの gguf の場所。"""
    spec = MODELS.get(key)
    if spec is None:
        return None
    name = spec.extra.get("file") or ""
    return MODEL_DIR / name if name else None


def model(key: str) -> Model:
    return MODELS.get(key) or MODELS[DEFAULT_MODEL]


def asset_path(asset: Asset):
    base = BIN_DIR if asset.into == "engines" else MODEL_DIR
    return base / asset.name


def asset_ok(asset: Asset) -> bool:
    """そのファイルが「使える形で」あるか。

    昔は exists() だけで見ていたので、0 バイトの残骸や、取り出しが
    途中で止まったファイルでも「用意できた」ことになり、エンジンが
    読めずに初めて詰まっていた（初回導線の監査 2026-10-28）。
    大きさの完全な照合はしない。カタログの size は「おおよそ」で、
    厳密に比べると本物を壊れていると間違えるため。
    """
    path = asset_path(asset)
    try:
        return path.is_file() and path.stat().st_size > 0
    except OSError:
        return False


def model_ready(key: str) -> bool:
    spec = MODELS.get(key)
    if spec is None:
        return False
    return all(asset_ok(a) for a in spec.assets)


def runtime_ready(key: str) -> bool:
    rt = RUNTIMES.get(key)
    if rt is None:
        return False
    return all(asset_ok(a) for a in rt.assets)


def usable(key: str) -> bool:
    """モデルと、その実行ファイルの両方がそろっているか。

    モデルだけあってもエンジンが無ければ文字起こしはできない。
    初回の案内を「もう終わった」とするかは、こちらで見る。
    """
    spec = MODELS.get(key)
    return bool(spec and model_ready(key)
                and runtime_ready(spec.runtime))


def missing_assets(model_key: str) -> list[Asset]:
    """そのモデルを使うのに足りないファイル（実行ファイルも含む）。"""
    spec = MODELS.get(model_key)
    if spec is None:
        return []
    out: list[Asset] = []
    rt = RUNTIMES.get(spec.runtime)
    if rt is not None:
        out += [a for a in rt.assets if not asset_ok(a)]
    out += [a for a in spec.assets if not asset_ok(a)]
    return out


def human_size(num: int) -> str:
    if num >= 1_000_000_000:
        return f"{num / 1_000_000_000:.1f} GB"
    if num >= 1_000_000:
        return f"{num / 1_000_000:.0f} MB"
    return f"{num / 1000:.0f} KB"


def scan_local_models() -> int:
    """models/ フォルダにある未登録の .gguf ファイルを自動登録する。"""
    if not MODEL_DIR.is_dir():
        return 0
    known_files: set[str] = set()
    for m in MODELS.values():
        f = m.extra.get("file")
        if f:
            known_files.add(str(f))
        for a in m.assets:
            known_files.add(a.name)

    added = 0
    for p in MODEL_DIR.glob("*.gguf"):
        if p.name in known_files:
            continue
        key = f"local-{p.stem.lower()}"
        if key in MODELS:
            continue
        size = p.stat().st_size
        MODELS[key] = Model(
            key=key,
            name=f"ローカル: {p.stem}",
            ja=f"追加されたモデル ({p.name})",
            en=f"Local model ({p.name})",
            runtime="tcpp",
            argv=(),
            assets=(Asset(p.name, "", size),),
            accuracy=4,
            speed=4,
            cer=5.0,
            note_ja=f"models に追加された GGUF モデル ({human_size(size)})",
            note_en=f"GGUF model in models folder ({human_size(size)})",
            license="Custom / Local",
            license_url="",
            source=str(p),
            extra={"backend": "vulkan", "resident": True,
                   "file": p.name, "best_seconds": 30},
        )
        added += 1
    if added:
        log.info("ローカルの GGUF モデルを %d 件自動登録しました", added)
    return added


REMOTE_CATALOG_URL = (
    "https://raw.githubusercontent.com/{repo}/main/assets/models.json"
)


def load_catalog_json(data: dict) -> int:
    """外部の JSON カタログから新しいモデル定義を読み込む。"""
    added = 0
    models_data = data.get("models") or []
    for item in models_data:
        key = item.get("key")
        if not key or key in MODELS:
            continue
        try:
            assets = tuple(
                Asset(
                    name=a.get("name", ""),
                    url=a.get("url", ""),
                    size=int(a.get("size", 0)),
                    into=a.get("into", "models"),
                    unzip_from=a.get("unzip_from", ""),
                    rename_to=a.get("rename_to", ""),
                )
                for a in item.get("assets", [])
            )
            extra = item.get(
                "extra", {"resident": True, "backend": "vulkan"}
            )
            MODELS[key] = Model(
                key=key,
                name=item.get("name", key),
                ja=item.get("ja", ""),
                en=item.get("en", ""),
                runtime=item.get("runtime", "tcpp"),
                argv=tuple(item.get("argv", ())),
                assets=assets,
                accuracy=int(item.get("accuracy", 3)),
                speed=int(item.get("speed", 3)),
                cer=float(item.get("cer", 5.0)),
                note_ja=item.get("note_ja", ""),
                note_en=item.get("note_en", ""),
                license=item.get("license", ""),
                license_url=item.get("license_url", ""),
                source=item.get("source", ""),
                supports_hints=bool(item.get("supports_hints", False)),
                extra=extra,
            )
            added += 1
        except Exception:
            log.warning("モデル定義読み込み失敗: %s", key, exc_info=True)
    if added:
        log.info("リモートから新しいモデルを %d 件追加しました", added)
    return added


def update_remote_catalog(repo: str = "koe-type/koe-type") -> int:
    """GitHub から最新のモデル定義カタログを取得してマージする。"""
    from . import downloads  # noqa: PLC0415
    if downloads.is_offline():
        return 0
    import urllib.request  # noqa: PLC0415
    url = REMOTE_CATALOG_URL.format(repo=repo)
    req = urllib.request.Request(url, headers={"User-Agent": "koe-type"})
    try:
        with urllib.request.urlopen(  # noqa: S310
                req, timeout=15,
                context=downloads.tls_context()) as res:
            if res.status == 200:
                data = json.loads(res.read().decode("utf-8", "replace"))
                return load_catalog_json(data)
    except Exception as exc:  # noqa: BLE001
        log.debug("リモートモデルカタログ取得をスキップ: %s", exc)
    return 0


# 初期化時にローカルモデルを自動スキャン
try:
    scan_local_models()
except Exception:  # noqa: BLE001
    pass
