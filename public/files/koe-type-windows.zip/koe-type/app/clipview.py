"""クリップボードの窓の見た目。配置を決め、描き、どこを押したかを答える。

方針（設定画面とそろえる）
  ・Windows 11 になじむ、静かで精密な道具。色は地・面・線・文字と
    アクセント 1 色だけ。グラデーション・発光・絵文字は使わない
  ・選んでいる行は、アクセントを薄く混ぜた地＋左の細い縦棒。
    色だけに頼らず形でも分かるようにする
  ・アイコンは Windows 標準の「Segoe Fluent Icons」の記号を使う
    （Windows 10 では Segoe MDL2 Assets）。新しい絵のファイルは要らない

描く処理は Win32 の窓を知らない。Canvas（メモリ上の絵）に描くだけなので、
画面に何も出さずに見た目の画像を作れる（tools/clip_test.py --shots）。
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable

from . import clipgfx
from .clipgfx import FW_SEMIBOLD, Canvas, Painter, mix
from .clipmodel import PopupModel, look
from .clipstore import Clip
from .i18n import language, t

# Segoe Fluent Icons の記号
GLYPH = {
    "search": "", "settings": "", "pin": "",
    "picture": "", "link": "", "folder": "",
    "lock": "", "add": "", "text": "",
    "all": "", "paste": "", "mail": "",
    "colour": "", "close": "", "doc": "",
    "filter": "", "video": "", "audio": "",
    "cloud": "", "zip": "",
}

VIDEO_EXT = (".mp4", ".mov", ".avi", ".mkv", ".wmv", ".webm", ".m4v")
AUDIO_EXT = (".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".wma")
ZIP_EXT = (".zip", ".7z", ".rar", ".lzh", ".tar", ".gz")
PIC_EXT = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff",
           ".webp", ".heic", ".svg")


def file_glyph(name: str) -> str:
    """ファイルの種類に合う記号の名前。"""
    low = name.lower()
    if low.endswith(PIC_EXT):
        return "picture"
    if low.endswith(VIDEO_EXT):
        return "video"
    if low.endswith(AUDIO_EXT):
        return "audio"
    if low.endswith(ZIP_EXT):
        return "zip"
    return "doc"

PALETTES = {
    "dark": {
        "bg": "#272727", "panel": "#2b2b2b", "field": "#1f1f1f",
        "field_line": "#3d3d3d", "line": "#363636", "fg": "#ffffff",
        "fg2": "#d0d0d0", "fg3": "#9d9d9d", "faint": "#6e6e6e",
        "chip": "#353535", "chip_fg": "#d6d6d6", "toast": "#f2f2f2",
        "toast_fg": "#1a1a1a", "check": "#3a3a3a",
    },
    "light": {
        "bg": "#f9f9f9", "panel": "#f3f3f3", "field": "#ffffff",
        "field_line": "#d9d9d9", "line": "#e5e5e5", "fg": "#1a1a1a",
        "fg2": "#4d4d4d", "fg3": "#7a7a7a", "faint": "#ababab",
        "chip": "#ebebeb", "chip_fg": "#3d3d3d", "toast": "#2b2b2b",
        "toast_fg": "#ffffff", "check": "#e6e6e6",
    },
}

FONT_SCALES = {"small": 0.9, "medium": 1.0, "large": 1.15, "xlarge": 1.32}
KIND_ORDER = (("all", "all"), ("text", "text"), ("image", "picture"),
              ("link", "link"), ("files", "folder"))


@dataclass
class Box:
    x: int = 0
    y: int = 0
    w: int = 0
    h: int = 0

    def has(self, px: int, py: int) -> bool:
        return (self.x <= px < self.x + self.w
                and self.y <= py < self.y + self.h)

    @property
    def right(self) -> int:
        return self.x + self.w

    @property
    def bottom(self) -> int:
        return self.y + self.h


@dataclass
class Layout:
    width: int = 0
    height: int = 0
    s: float = 1.0
    search: Box = field(default_factory=Box)
    settings: Box = field(default_factory=Box)
    tabs: list[Box] = field(default_factory=list)
    tab_add: Box = field(default_factory=Box)
    kinds: list[Box] = field(default_factory=list)
    tab_bar: Box = field(default_factory=Box)
    listing: Box = field(default_factory=Box)
    preview: Box = field(default_factory=Box)
    footer: Box = field(default_factory=Box)
    row_h: int = 0
    caret: tuple[int, int, int] = (0, 0, 0)        # x, y, 高さ


def relative_time(stamp: float, now: float | None = None) -> str:
    """「2分前」「昨日 14:05」のような短い時刻。"""
    if not stamp:
        return ""
    now = now if now is not None else time.time()
    diff = max(0.0, now - stamp)
    if diff < 60:
        return t("clip.just_now")
    if diff < 3600:
        return t("clip.minutes_ago", n=int(diff // 60))
    lt, ln = time.localtime(stamp), time.localtime(now)
    if diff < 86400 and lt.tm_mday == ln.tm_mday:
        return t("clip.hours_ago", n=int(diff // 3600))
    yesterday = time.localtime(now - 86400)
    if (lt.tm_year, lt.tm_yday) == (yesterday.tm_year, yesterday.tm_yday):
        return t("clip.yesterday", hm=time.strftime("%H:%M", lt))
    if lt.tm_year == ln.tm_year:
        return time.strftime("%m/%d %H:%M", lt).lstrip("0")
    return time.strftime("%Y/%m/%d", lt)


def human_bytes(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f} KB"
    return f"{n / 1024 / 1024:.1f} MB"


def app_label(exe: str) -> str:
    """"chrome.exe" → "Chrome"。"""
    if not exe:
        return ""
    name = exe[:-4] if exe.lower().endswith(".exe") else exe
    known = {"chrome": "Chrome", "msedge": "Edge", "firefox": "Firefox",
             "code": "VS Code", "explorer": "エクスプローラー"
             if language() == "ja" else "Explorer",
             "winword": "Word", "excel": "Excel", "powerpnt": "PowerPoint",
             "outlook": "Outlook", "notepad": "メモ帳"
             if language() == "ja" else "Notepad",
             "line": "LINE", "slack": "Slack", "teams": "Teams",
             "ms-teams": "Teams", "discord": "Discord",
             "snippingtool": "Snipping Tool", "vivaldi": "Vivaldi",
             "windowsterminal": "Terminal", "obsidian": "Obsidian",
             "notion": "Notion"}
    return known.get(name.lower(), name)


def first_lines(text: str, lines: int) -> str:
    """一覧に出す最初の数行。空の行と行頭の空白は詰める。"""
    out = []
    for line in text.replace("\r", "").split("\n"):
        line = " ".join(line.split())
        if line:
            out.append(line)
        if len(out) >= lines:
            break
    return "\n".join(out)


class ClipView:
    """窓の中を描く。"""

    def __init__(self) -> None:
        self.fonts = clipgfx.Fonts()
        self.theme = "dark"
        self.accent = "#0f6cbd"
        self.font_scale = 1.0
        self.preview_pos = "right"
        self.two_lines = True
        self.show_meta = True
        self.show_numbers = True
        self.hotkey_label = "Alt+V"
        self.layout = Layout()
        self.hover_kind = ""
        self.caret_on = True
        self.download_days = 7

    # ------------------------------------------------------------ 設定

    def configure(self, *, theme: str, accent: str, font_size: str,
                  preview: str, two_lines: bool, show_meta: bool,
                  show_numbers: bool, hotkey_label: str) -> None:
        self.theme = "light" if theme == "light" else "dark"
        self.accent = accent or "#0f6cbd"
        self.font_scale = FONT_SCALES.get(font_size, 1.0)
        self.preview_pos = preview if preview in ("right", "bottom",
                                                  "none") else "right"
        self.two_lines = bool(two_lines)
        self.show_meta = bool(show_meta)
        self.show_numbers = bool(show_numbers)
        self.hotkey_label = hotkey_label

    @property
    def c(self) -> dict[str, str]:
        return PALETTES[self.theme]

    @property
    def accent_fg(self) -> str:
        """文字や細い線に使うアクセント。暗い地では明るくして読めるように。"""
        if self.theme == "dark":
            return mix(self.accent, "#ffffff", 0.38)
        return self.accent

    def px(self, size: float, s: float) -> int:
        return max(8, round(size * s * self.font_scale))

    # ------------------------------------------------------------ 配置

    def arrange(self, width: int, height: int, s: float,
                model: PopupModel) -> Layout:
        """窓の大きさから、各部の位置を決める。"""
        lay = Layout(width=width, height=height, s=s)
        pad = round(12 * s)
        top_h = round(56 * s * max(1.0, self.font_scale * 0.95))
        field_h = round(36 * s * max(1.0, self.font_scale * 0.92))
        btn = round(34 * s)
        lay.settings = Box(width - pad - btn, (top_h - btn) // 2, btn, btn)
        lay.search = Box(pad, (top_h - field_h) // 2,
                         lay.settings.x - pad - round(6 * s), field_h)
        tab_h = round(38 * s * max(1.0, self.font_scale * 0.95))
        lay.tab_bar = Box(0, top_h, width, tab_h)
        # 種類の絞り込み（右端の小さな記号）
        kind_w = round(30 * s)
        kinds_x = width - pad - kind_w * len(KIND_ORDER)
        lay.kinds = [Box(kinds_x + i * kind_w, top_h + round(4 * s), kind_w,
                         tab_h - round(8 * s))
                     for i in range(len(KIND_ORDER))]
        # タブ（グループ）
        x = pad - round(4 * s)
        tab_px = self.px(12.5, s)
        lay.tabs = []
        limit = kinds_x - round(8 * s)
        dc_measure = getattr(self, "_measure_dc", None)
        for tab in model.tabs:
            label = self.tab_label(tab)
            text_w = self._text_w(label, tab_px, dc_measure)
            count_w = self._text_w(str(tab.count), self.px(11, s),
                                   dc_measure) if tab.count else 0
            w = text_w + (count_w + round(6 * s) if count_w else 0) \
                + round(20 * s)
            lay.tabs.append(Box(x, top_h, w, tab_h))
            x += w
        # はみ出すときは、選んでいるタブが見えるように左へずらす
        add_w = round(32 * s)
        if lay.tabs and lay.tabs[-1].right + add_w > limit:
            active = lay.tabs[min(model.tab, len(lay.tabs) - 1)]
            shift = max(0, active.right + add_w - limit)
            for box in lay.tabs:
                box.x -= shift
        end = lay.tabs[-1].right if lay.tabs else x
        lay.tab_add = Box(end, top_h + round(4 * s), add_w,
                          tab_h - round(8 * s))
        foot_h = round(30 * s * max(1.0, self.font_scale * 0.95))
        lay.footer = Box(0, height - foot_h, width, foot_h)
        body_y = top_h + tab_h + 1
        body_h = lay.footer.y - body_y
        if self.preview_pos == "right" and width >= 520 * s:
            pw = max(round(200 * s), round(width * 0.38))
            lay.listing = Box(0, body_y, width - pw, body_h)
            lay.preview = Box(width - pw, body_y, pw, body_h)
        elif self.preview_pos == "bottom" and body_h >= 300 * s:
            ph = round(body_h * 0.36)
            lay.listing = Box(0, body_y, width, body_h - ph)
            lay.preview = Box(0, body_y + body_h - ph, width, ph)
        else:
            lay.listing = Box(0, body_y, width, body_h)
            lay.preview = Box()
        main = self.px(13, s)
        meta = self.px(11.5, s)
        if self.two_lines and self.show_meta:
            lay.row_h = round(main * 1.45 + meta * 1.45 + 16 * s)
        else:
            lay.row_h = round(max(main * 1.5 + 14 * s, 36 * s))
        model.page = max(1, (lay.listing.h - round(6 * s)) // lay.row_h)
        self.layout = lay
        return lay

    def _text_w(self, text: str, px: int, dc: int | None) -> int:
        if dc:
            return clipgfx.measure(dc, self.fonts, text, px=px)[0]
        return int(len(text) * px * 0.9)

    @staticmethod
    def tab_label(tab) -> str:  # noqa: ANN001
        return tab.name or t("clip.tab_history")

    # ------------------------------------------------------------ 当たり

    def hit(self, x: int, y: int, model: PopupModel) -> tuple[str, int]:
        lay = self.layout
        if lay.search.has(x, y):
            return ("search", 0)
        if lay.settings.has(x, y):
            return ("settings", 0)
        for i, box in enumerate(lay.kinds):
            if box.has(x, y):
                return ("kind", i)
        if lay.tab_add.has(x, y):
            return ("tab_add", 0)
        for i, box in enumerate(lay.tabs):
            if box.has(x, y) and box.x >= 0:
                return ("tab", i)
        if lay.listing.has(x, y):
            row = (y - lay.listing.y - round(3 * lay.s)) // max(1, lay.row_h)
            index = model.top + row
            # ★描いているのは model.page 行まで。その下の余りを押すと、
            # 光っていない項目が貼られていた（レビューで発覚）
            if 0 <= row < model.page and index < len(model.view):
                return ("row", index)
            return ("list", -1)
        if lay.preview.has(x, y):
            return ("preview", 0)
        if y < lay.tab_bar.bottom:
            return ("caption", 0)
        return ("", -1)

    # ------------------------------------------------------------ 描く

    def paint(self, canvas: Canvas, model: PopupModel, s: float, *,
              thumb: Callable[[Clip, int, int], tuple[int, int, int]],
              full_text: Callable[[Clip], str],
              focused: bool = True, now: float | None = None) -> None:
        self._measure_dc = canvas.dc
        lay = self.arrange(canvas.width, canvas.height, s, model)
        p = Painter(canvas, self.fonts)
        try:
            c = self.c
            p.clear(c["bg"])
            self._paint_search(p, model, lay, focused)
            self._paint_tabs(p, model, lay)
            p.line(0, lay.tab_bar.bottom, lay.width, lay.tab_bar.bottom,
                   c["line"])
            self._paint_list(p, model, lay, thumb, now)
            if lay.preview.w and lay.preview.h:
                self._paint_preview(p, model, lay, thumb, full_text, now)
            self._paint_footer(p, model, lay)
            note = model.note_now()
            if note:
                self._paint_toast(p, lay, note)
        finally:
            p.close()

    def _paint_search(self, p: Painter, model: PopupModel, lay: Layout,
                      focused: bool) -> None:
        c, s = self.c, lay.s
        box = lay.search
        r = round(5 * s)
        p.round_rect(box.x, box.y, box.w, box.h, r, fill=c["field"],
                     stroke=c["field_line"], width=max(1.0, s * 0.8))
        if focused:
            # Windows 11 の入力欄と同じ、下の細いアクセント線
            p.rect(box.x + r * 0.6, box.bottom - round(2 * s),
                   box.w - r * 1.2, round(2 * s), self.accent_fg)
        icon_px = self.px(14, s)
        icon_w = round(34 * s)
        p.text(GLYPH["search"], box.x + round(4 * s), box.y, icon_w, box.h,
               colour=c["fg3"], px=icon_px, icon=True, align="center")
        tx = box.x + icon_w + round(2 * s)
        tw = box.w - icon_w - round(12 * s)
        text_px = self.px(13.5, s)
        sb = model.search
        if not sb.text:
            p.text(t("clip.search_placeholder"), tx, box.y, tw, box.h,
                   colour=c["faint"], px=text_px)
            caret_x = tx
        else:
            # 選んでいる範囲の地
            sel = sb.selection()
            if sel:
                a = p.measure(sb.text[:sel[0]], px=text_px)[0]
                b = p.measure(sb.text[:sel[1]], px=text_px)[0]
                p.rect(tx + a, box.y + round(8 * s), max(1, b - a),
                       box.h - round(16 * s),
                       mix(c["field"], self.accent, 0.45))
            p.text(sb.text, tx, box.y, tw, box.h, colour=c["fg"],
                   px=text_px, ellipsis=False)
            caret_x = tx + p.measure(sb.text[:sb.caret], px=text_px)[0]
        caret_h = round(text_px * 1.25)
        caret_y = box.y + (box.h - caret_h) // 2
        lay.caret = (int(caret_x), int(caret_y), int(caret_h))
        if focused and self.caret_on:
            p.rect(caret_x, caret_y, max(1, round(1.2 * s)), caret_h,
                   c["fg"])
        # 設定
        btn = lay.settings
        if self.hover_kind == "settings":
            p.round_rect(btn.x, btn.y, btn.w, btn.h, round(5 * s),
                         fill=c["chip"])
        p.text(GLYPH["settings"], btn.x, btn.y, btn.w, btn.h,
               colour=c["fg2"], px=self.px(14, s), icon=True,
               align="center")

    def _paint_tabs(self, p: Painter, model: PopupModel,
                    lay: Layout) -> None:
        c, s = self.c, lay.s
        tab_px = self.px(12.5, s)
        count_px = self.px(11, s)
        limit = lay.kinds[0].x - round(8 * s) if lay.kinds else lay.width
        p.clip(0, lay.tab_bar.y, limit, lay.tab_bar.h)
        for i, (tab, box) in enumerate(zip(model.tabs, lay.tabs)):
            active = i == model.tab
            label = self.tab_label(tab)
            text_w = p.measure(label, px=tab_px,
                               weight=FW_SEMIBOLD if active else 400)[0]
            x = box.x + round(10 * s)
            p.text(label, x, box.y, text_w + round(4 * s), box.h,
                   colour=c["fg"] if active else c["fg3"], px=tab_px,
                   weight=FW_SEMIBOLD if active else 400, ellipsis=False)
            if tab.count:
                p.text(str(tab.count), x + text_w + round(5 * s), box.y,
                       round(40 * s), box.h, colour=c["faint"],
                       px=count_px, ellipsis=False)
            if active:
                bar_w = max(round(16 * s), box.w - round(24 * s))
                p.round_rect(box.x + (box.w - bar_w) / 2,
                             box.bottom - round(3 * s), bar_w,
                             round(3 * s), round(1.5 * s),
                             fill=self.accent_fg)
        p.unclip()
        add = lay.tab_add
        if add.x < limit:
            if self.hover_kind == "tab_add":
                p.round_rect(add.x, add.y, add.w, add.h, round(5 * s),
                             fill=c["chip"])
            p.text(GLYPH["add"], add.x, add.y, add.w, add.h,
                   colour=c["fg3"], px=self.px(11, s), icon=True,
                   align="center")
        for (kind, glyph), box in zip(KIND_ORDER, lay.kinds):
            on = model.kind == kind
            if on:
                p.round_rect(box.x + round(2 * s), box.y, box.w - round(4 * s),
                             box.h, round(5 * s),
                             fill=mix(c["bg"], self.accent, 0.28))
            p.text(GLYPH[glyph], box.x, box.y, box.w, box.h,
                   colour=self.accent_fg if on else c["fg3"],
                   px=self.px(12.5, s), icon=True, align="center")

    def _paint_list(self, p: Painter, model: PopupModel, lay: Layout,
                    thumb: Callable[[Clip, int, int], tuple[int, int, int]],
                    now: float | None) -> None:
        c, s = self.c, lay.s
        area = lay.listing
        if not model.view:
            self._paint_empty(p, model, area, s)
            return
        p.clip(area.x, area.y, area.w, area.h)
        y = area.y + round(3 * s)
        # 収まりきる行だけ描く。途中で切れた行は、下のプレビューに
        # 文字の上半分だけがはみ出して見え、汚かった。
        last = min(len(model.view), model.top + model.page)
        for index in range(model.top, last):
            clip = model.view[index]
            self._paint_row(p, model, clip, index, Box(area.x, y, area.w,
                                                       lay.row_h),
                            s, thumb, now)
            y += lay.row_h
        p.unclip()
        # スクロールの位置（細い棒）
        if len(model.view) > model.page:
            track_h = area.h - round(8 * s)
            bar_h = max(round(24 * s),
                        track_h * model.page // len(model.view))
            span = max(1, len(model.view) - model.page)
            bar_y = area.y + round(4 * s) + (track_h - bar_h) \
                * model.top // span
            p.round_rect(area.right - round(6 * s), bar_y, round(3 * s),
                         bar_h, round(1.5 * s), fill=c["faint"], alpha=0.8)

    def _paint_row(self, p: Painter, model: PopupModel, clip: Clip,
                   index: int, box: Box, s: float,
                   thumb: Callable[[Clip, int, int], tuple[int, int, int]],
                   now: float | None) -> None:
        c = self.c
        selected = index == model.sel
        in_multi = clip.id in model.multi
        inset = round(6 * s)
        if selected or in_multi:
            # 明るい地では薄く混ぜる（濃いと、文字より地が目立った）
            strength = (0.24, 0.14) if self.theme == "dark" else (0.13, 0.07)
            fill = mix(c["bg"], self.accent,
                       strength[0] if selected else strength[1])
            p.round_rect(box.x + inset, box.y + round(1 * s),
                         box.w - inset * 2 - round(4 * s),
                         box.h - round(2 * s), round(5 * s), fill=fill)
            if selected:
                p.round_rect(box.x + inset, box.y + box.h * 0.28,
                             round(3 * s), box.h * 0.44, round(1.5 * s),
                             fill=self.accent_fg)
        main_px = self.px(13, s)
        meta_px = self.px(11.5, s)
        x = box.x + inset + round(8 * s)
        right = box.right - inset - round(12 * s)
        # 1〜9 の番号（Ctrl+数字で貼れる）
        num_w = round(18 * s) if self.show_numbers else 0
        if self.show_numbers and index < 9:
            p.text(str(index + 1), x, box.y, num_w, box.h,
                   colour=c["faint"], px=self.px(11, s), align="left")
        x += num_w
        kind = look(clip)
        title, sub, meta = self.row_lines(clip, now)
        # 2 行目に出すものが何もない行は、1 行として縦の中央にそろえる
        # （上に寄って、下が空いて見えた）
        two = self.two_lines and self.show_meta and bool(sub or meta)
        line1_y = box.y + round(7 * s)
        line_h = round(main_px * 1.45)
        # 先頭の印（画像の小さな絵・色見本・記号）。どの行にも置いて、
        # 文字の始まりをそろえる（記号のない行だけ左にずれて見えた）。
        lead = 0
        if kind == "download":
            # 画像なら縮めた絵、そうでなければ種類の記号
            tw_max, th_max = round(54 * s), box.h - round(12 * s)
            bmp, tw, th = thumb(clip, tw_max, th_max)
            if bmp:
                ty = box.y + (box.h - th) // 2
                tx = x + (tw_max - tw) // 2
                p.round_rect(tx - 1, ty - 1, tw + 2, th + 2, round(3 * s),
                             fill=c["line"])
                p.image(bmp, tx, ty, tw, th)
            else:
                p.round_rect(x + round(8 * s), box.y + round(8 * s),
                             tw_max - round(16 * s), box.h - round(16 * s),
                             round(5 * s), fill=c["chip"])
                p.text(GLYPH[file_glyph(clip.title)], x, box.y, tw_max,
                       box.h, colour=c["fg2"], px=self.px(15, s),
                       icon=True, align="center")
            lead = tw_max + round(10 * s)
        elif kind == "image":
            tw_max, th_max = round(54 * s), box.h - round(12 * s)
            bmp, tw, th = thumb(clip, tw_max, th_max)
            if bmp:
                ty = box.y + (box.h - th) // 2
                tx = x + (tw_max - tw) // 2
                p.round_rect(tx - 1, ty - 1, tw + 2, th + 2, round(3 * s),
                             fill=c["line"])
                p.image(bmp, tx, ty, tw, th)
            lead = tw_max + round(10 * s)
        elif kind == "colour":
            sw = round(17 * s)
            colour = clip.snippet.strip()
            if len(colour) == 4:
                colour = "#" + "".join(ch * 2 for ch in colour[1:])
            sy = (line1_y + (line_h - sw) / 2) if two else \
                box.y + (box.h - sw) / 2
            p.round_rect(x + round(1 * s), sy, sw, sw, round(4 * s),
                         fill=colour[:7], stroke=c["field_line"])
            lead = round(26 * s)
        else:
            glyph = {"link": "link", "files": "folder", "secret": "lock",
                     "mail": "mail"}.get(kind, "doc")
            gy = line1_y if two else box.y
            gh = line_h if two else box.h
            p.text(GLYPH[glyph], x, gy, round(20 * s), gh, colour=c["fg3"],
                   px=self.px(12.5, s), icon=True)
            lead = round(26 * s)
        x += lead
        # 右側の印（固定・まとめて選んだ順）
        marks_w = 0
        if clip.id in model.multi:
            order = model.multi.index(clip.id) + 1
            d = round(18 * s)
            cy = (line1_y + line_h / 2) if two else box.y + box.h / 2
            p.circle(right - d / 2, cy, d / 2, self.accent_fg)
            p.text(str(order), right - d, cy - d / 2, d, d,
                   colour="#ffffff" if self.theme == "light" else "#1a1a1a",
                   px=self.px(10.5, s), weight=FW_SEMIBOLD, align="center")
            marks_w += d + round(6 * s)
        if clip.pinned:
            gw = round(16 * s)
            cy = line1_y if two else box.y
            p.text(GLYPH["pin"], right - marks_w - gw, cy, gw,
                   line_h if two else box.h, colour=self.accent_fg,
                   px=self.px(11, s), icon=True, align="center")
            marks_w += gw + round(4 * s)
        text_w = right - x - marks_w
        fg = c["fg"]
        if two:
            p.text(title, x, line1_y, text_w, line_h, colour=fg,
                   px=main_px)
            meta_y = line1_y + line_h
            meta_h = round(meta_px * 1.5)
            meta_w = p.measure(meta, px=meta_px)[0] if meta else 0
            if meta_w:
                meta_w = min(meta_w, (right - x) // 2 if sub
                             else right - x)
                p.text(meta, right - meta_w, meta_y, meta_w, meta_h,
                       colour=c["fg3"], px=meta_px)
            if sub:
                p.text(sub, x, meta_y, right - x - meta_w - round(12 * s),
                       meta_h, colour=c["fg3"], px=meta_px)
        else:
            if self.show_meta and meta:
                mw = min(p.measure(meta, px=meta_px)[0], text_w // 2)
                p.text(meta, right - marks_w - mw, box.y, mw, box.h,
                       colour=c["fg3"], px=meta_px)
                text_w -= mw + round(10 * s)
            p.text(title, x, box.y, text_w, box.h, colour=fg, px=main_px)

    def row_lines(self, clip: Clip,
                  now: float | None) -> tuple[str, str, str]:
        """行の (1 行目, 2 行目の左, 2 行目の右) 。

        履歴は「何を・どこから・いつ」が大事なので、右にアプリと時刻。
        グループは自分で付けた名前が大事なので、名前を 1 行目にし、
        中身を 2 行目に出す（時刻は要らない）。
        """
        kind = look(clip)
        if kind == "download":
            info = [relative_time(clip.created, now), human_bytes(clip.size)]
            if clip.cloud:
                info.append(t("clip.cloud_only"))
            return (clip.title, clip.app, " · ".join(info))
        in_group = clip.group_id != 0
        info = []
        if not in_group:
            app = app_label(clip.app)
            if app:
                info.append(app)
            info.append(relative_time(clip.touched, now))
        if kind == "files":
            info.append(t("clip.files_count", n=len(clip.files)))
        elif kind == "image":
            info.append(human_bytes(clip.size))
        elif kind == "text" and clip.chars > 200 and not in_group:
            info.append(t("clip.chars", n=clip.chars))
        if clip.use_count > 1:
            info.append(t("clip.used", n=clip.use_count))
        meta = " · ".join(i for i in info if i)
        if kind == "secret":
            return (clip.title or t("clip.kind_secret"), "•" * 10,
                    meta)
        if kind == "image":
            label = clip.title or t("clip.kind_image")
            return (f"{label}  {clip.width} × {clip.height}", "", meta)
        if kind == "files":
            names = [f.replace("/", "\\").split("\\")[-1]
                     for f in clip.files]
            head = clip.title or ", ".join(names[:3])
            if len(names) > 3:
                head += " " + t("clip.more_files", n=len(names) - 3)
            folder = clip.files[0].rsplit("\\", 1)[0] if clip.files else ""
            return (head, folder, meta)
        lines = first_lines(clip.snippet, 2).split("\n")
        if clip.title:
            return (clip.title, lines[0], meta)
        second = lines[1] if len(lines) > 1 else ""
        return (lines[0] or t("clip.blank"), second, meta)

    def _paint_empty(self, p: Painter, model: PopupModel, area: Box,
                     s: float) -> None:
        c = self.c
        if model.search.text or model.kind != "all":
            head = t("clip.no_match")
            sub = t("clip.no_match_sub")
        elif model.gid == 0:
            head = t("clip.empty_history")
            sub = t("clip.empty_history_sub")
        elif model.gid < 0:
            head = t("clip.empty_downloads")
            sub = t("clip.empty_downloads_sub", days=self.download_days)
        else:
            head = t("clip.empty_group")
            sub = t("clip.empty_group_sub", hotkey=self.hotkey_label)
        cy = area.y + area.h * 0.36
        p.text(GLYPH["paste"], area.x, cy - round(40 * s), area.w,
               round(36 * s), colour=c["faint"], px=self.px(26, s),
               icon=True, align="center")
        p.text(head, area.x + round(24 * s), cy + round(4 * s),
               area.w - round(48 * s), round(24 * s), colour=c["fg2"],
               px=self.px(13.5, s), weight=FW_SEMIBOLD, align="center")
        p.text(sub, area.x + round(32 * s), cy + round(32 * s),
               area.w - round(64 * s), round(80 * s), colour=c["fg3"],
               px=self.px(12, s), align="center", wrap=True)

    def _paint_preview(self, p: Painter, model: PopupModel, lay: Layout,
                       thumb: Callable[[Clip, int, int],
                                       tuple[int, int, int]],
                       full_text: Callable[[Clip], str],
                       now: float | None) -> None:
        c, s = self.c, lay.s
        box = lay.preview
        p.rect(box.x, box.y, box.w, box.h, c["panel"])
        if box.y > lay.listing.y:
            p.line(box.x, box.y, box.right, box.y, c["line"])
        else:
            p.line(box.x, box.y, box.x, box.bottom, c["line"])
        clip = model.current()
        if clip is None:
            return
        pad = round(14 * s)
        x, y = box.x + pad, box.y + pad
        w = box.w - pad * 2
        meta_px = self.px(11.5, s)
        kind = look(clip)
        if kind == "download":
            self._paint_file_preview(p, clip, x, y, w, box, pad, thumb, now)
            return
        # 上：種類と大きさ
        label = {"image": t("clip.kind_image"),
                 "files": t("clip.kind_files"),
                 "link": t("clip.kind_link"),
                 "colour": t("clip.kind_colour"),
                 "mail": t("clip.kind_mail"),
                 "secret": t("clip.kind_secret")}.get(kind,
                                                       t("clip.kind_text"))
        facts = [label]
        if kind == "image":
            facts.append(f"{clip.width} × {clip.height}")
            facts.append(human_bytes(clip.size))
        elif kind in ("text", "link", "mail"):
            facts.append(t("clip.chars", n=clip.chars))
            if clip.has_format:
                facts.append(t("clip.with_format"))
        p.text("  ·  ".join(facts), x, y, w, round(meta_px * 1.6),
               colour=c["fg3"], px=meta_px)
        y += round(meta_px * 1.6 + 8 * s)
        bottom = box.bottom - pad - round(meta_px * 3.4)
        if clip.title and kind != "image":
            title_px = self.px(13, s)
            p.text(clip.title, x, y, w, round(title_px * 1.6), colour=c["fg"],
                   px=title_px, weight=FW_SEMIBOLD)
            y += round(title_px * 1.6 + 4 * s)
        if kind == "image":
            bmp, tw, th = thumb(clip, w, max(1, bottom - y))
            if bmp:
                ix = x + (w - tw) // 2
                p.round_rect(ix - 1, y - 1, tw + 2, th + 2, round(4 * s),
                             fill=c["line"])
                p.image(bmp, ix, y, tw, th)
        elif kind == "secret":
            p.text("●" * 12, x, y, w, round(24 * s), colour=c["fg2"],
                   px=self.px(13, s))
            p.text(t("clip.secret_hint"), x, y + round(30 * s), w,
                   bottom - y - round(30 * s), colour=c["fg3"],
                   px=self.px(11.5, s), wrap=True)
        elif kind == "files":
            line_h = round(self.px(12, s) * 1.6)
            for name in clip.files:
                if y + line_h > bottom:
                    break
                p.text(name, x, y, w, line_h, colour=c["fg2"],
                       px=self.px(12, s))
                y += line_h
        elif kind == "colour":
            colour = clip.snippet.strip()
            if len(colour) == 4:
                colour = "#" + "".join(ch * 2 for ch in colour[1:])
            p.round_rect(x, y, w, min(round(90 * s), bottom - y),
                         round(6 * s), fill=colour[:7],
                         stroke=c["field_line"])
        else:
            body = full_text(clip)[:4000]
            p.text(body, x, y, w, max(0, bottom - y), colour=c["fg"],
                   px=self.px(12.5, s), wrap=True)
        # 下：どこから・いつ・何回
        # 自分で足した言葉には「どのアプリから」は無いので出さない
        source = app_label(clip.app) or (
            "" if clip.group_id else t("clip.unknown_app"))
        info = [source, time.strftime(
            "%Y/%m/%d %H:%M", time.localtime(clip.created or time.time()))]
        info = [i for i in info if i]
        if clip.use_count:
            info.append(t("clip.used", n=clip.use_count))
        p.line(x, bottom + round(8 * s), x + w, bottom + round(8 * s),
               c["line"])
        p.text("  ·  ".join(info), x, bottom + round(14 * s), w,
               round(meta_px * 1.6), colour=c["fg3"], px=meta_px)

    def _paint_file_preview(self, p: Painter, clip: Clip, x: int, y: int,
                            w: int, box: Box, pad: int,
                            thumb: Callable[[Clip, int, int],
                                            tuple[int, int, int]],
                            now: float | None) -> None:
        """「ダウンロード」の項目の中身：画像なら大きく、ほかは名前と場所。"""
        c, s = self.c, self.layout.s
        meta_px = self.px(11.5, s)
        facts = [t("clip.kind_file"), human_bytes(clip.size)]
        if clip.cloud:
            facts.append(t("clip.cloud_only"))
        p.text("  ·  ".join(facts), x, y, w, round(meta_px * 1.6),
               colour=c["fg3"], px=meta_px)
        y += round(meta_px * 1.6 + 8 * s)
        bottom = box.bottom - pad - round(meta_px * 4.6)
        bmp, tw, th = thumb(clip, w, max(1, bottom - y - round(30 * s)))
        if bmp:
            ix = x + (w - tw) // 2
            p.round_rect(ix - 1, y - 1, tw + 2, th + 2, round(4 * s),
                         fill=c["line"])
            p.image(bmp, ix, y, tw, th)
            y += th + round(10 * s)
        else:
            p.text(GLYPH[file_glyph(clip.title)], x, y, w, round(56 * s),
                   colour=c["fg3"], px=self.px(30, s), icon=True,
                   align="center")
            y += round(64 * s)
        title_px = self.px(12.5, s)
        p.text(clip.title, x, y, w, round(title_px * 3.2), colour=c["fg"],
               px=title_px, wrap=True)
        if clip.cloud:
            p.text(t("clip.cloud_hint"), x, y + round(title_px * 3.4), w,
                   round(meta_px * 3.2), colour=c["fg3"], px=meta_px,
                   wrap=True)
        p.line(x, bottom + round(8 * s), x + w, bottom + round(8 * s),
               c["line"])
        folder = clip.path.rsplit("\\", 1)[0] if clip.path else clip.app
        p.text(folder, x, bottom + round(14 * s), w, round(meta_px * 1.6),
               colour=c["fg3"], px=meta_px)
        p.text(time.strftime("%Y/%m/%d %H:%M",
                             time.localtime(clip.created or time.time())),
               x, bottom + round(14 * s + meta_px * 1.6), w,
               round(meta_px * 1.6), colour=c["fg3"], px=meta_px)

    def _paint_footer(self, p: Painter, model: PopupModel,
                      lay: Layout) -> None:
        c, s = self.c, lay.s
        box = lay.footer
        p.rect(box.x, box.y, box.w, box.h, c["panel"])
        p.line(0, box.y, box.w, box.y, c["line"])
        key_px = self.px(10.5, s)
        label_px = self.px(11, s)
        if model.multi:
            hints = [("Enter", t("clip.hint_paste_n", n=len(model.multi))),
                     ("Esc", t("clip.hint_unselect"))]
        elif model.gid < 0:
            hints = [("Enter", t("clip.hint_paste")),
                     (t("clip.key_drag"), t("clip.hint_drag")),
                     ("Ctrl+O", t("clip.hint_open")),
                     ("Ctrl+G", t("clip.hint_to_group"))]
        elif model.gid == 0:
            hints = [("Enter", t("clip.hint_paste")),
                     ("Shift+Enter", t("clip.hint_plain")),
                     (self.hotkey_label, t("clip.hint_next_group")),
                     ("Ctrl+G", t("clip.hint_to_group")),
                     ("Ctrl+P", t("clip.hint_pin")),
                     ("Del", t("clip.hint_delete"))]
        else:
            hints = [("Enter", t("clip.hint_paste")),
                     (self.hotkey_label, t("clip.hint_next_group")),
                     ("Ctrl+E", t("clip.hint_edit")),
                     ("Ctrl+Shift+↑↓", t("clip.hint_reorder")),
                     ("Del", t("clip.hint_delete"))]
        x = round(12 * s)
        limit = box.w - round(12 * s)
        chip_h = round(key_px * 1.75)
        cy = box.y + (box.h - chip_h) // 2
        for key, label in hints:
            kw = p.measure(key, px=key_px)[0] + round(10 * s)
            lw = p.measure(label, px=label_px)[0]
            if x + kw + lw + round(6 * s) > limit:
                break
            p.round_rect(x, cy, kw, chip_h, round(4 * s), fill=c["chip"])
            p.text(key, x, cy, kw, chip_h, colour=c["chip_fg"], px=key_px,
                   align="center", ellipsis=False)
            x += kw + round(5 * s)
            p.text(label, x, box.y, lw + round(2 * s), box.h,
                   colour=c["fg3"], px=label_px, ellipsis=False)
            x += lw + round(14 * s)

    def _paint_toast(self, p: Painter, lay: Layout, note: str) -> None:
        c, s = self.c, lay.s
        px = self.px(12, s)
        w = min(lay.width - round(40 * s),
                p.measure(note, px=px)[0] + round(32 * s))
        h = round(px * 2.4)
        x = (lay.width - w) // 2
        y = lay.footer.y - h - round(12 * s)
        p.round_rect(x, y, w, h, round(6 * s), fill=c["toast"])
        p.text(note, x + round(16 * s), y, w - round(32 * s), h,
               colour=c["toast_fg"], px=px, align="center")
