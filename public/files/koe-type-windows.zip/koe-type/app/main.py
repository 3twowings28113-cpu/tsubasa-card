"""koe-type 本体。

   録音のショートカット（既定 Ctrl+Space）… 録音の開始 / 停止
   録音中の Enter … 停止 → 残りを入力 → 送信キーを送る
   録音中のキャンセルキー（既定 Esc）… 中止（未入力の分は捨てる）

スレッド構成
   main   : 小さな繰り返し（app/mainloop.py）。80ms ごとに状態を見る。
            tkinter はやめた（埋め込み用 Python で動かすため。6.14）。
   win    : Win32 メッセージループ。キーフックとトレイ。
   audio  : マイクからの取り込み。区間が切れたら work キューに積む。
   control: フックから届いた操作（開始/停止/送信/中止）を実行する。
   worker : 文字起こしと貼り付け。1 本だけなので順番が入れ替わらない。
"""

from __future__ import annotations

import array
import ctypes
import logging
import math
import os
import queue
import sys
from pathlib import Path
import threading
import time

from . import (autostart, catalog, engines, hotkeys, i18n, inject, sysaudio,
                    transform)
from .audio import SAMPLE_RATE, Recorder, device_count
from .configstore import Config
from .mainloop import MainLoop
from .engines import EngineError
from .history import History
from .i18n import t
from .streaming import Agreement, RoundGate, remainder
from . import jatext
from .textproc import (Dictionary, is_hallucination, is_noise,
                       is_tail_fragment, tidy)
from .util import (CONFIG_PATH, DATA_DIR, DICT_PATH, HOME, LOG_DIR, ROOT, VERSION,
                   ensure_dictionary, ensure_dirs, guard, set_log_level,
                   setup_logging)
from .vad import SegmentCutter, is_silence
from .websettings import Bridge, SettingsServer
from .winthread import WinThread, list_windows
from . import dryrun, enginestate, health, histpick, mousewatch, priority, testdrive
from . import fixwin, homophones, learnfix

log = logging.getLogger(__name__)

AUDIO = object()   # work キューの種類を表す目印
SUBMIT = object()
TEXT = object()    # 話しながらモードが確定させた文字
KEEP = object()    # 中止した録音。入力はせず履歴にだけ残す
ACTION = object()  # 特定動作（翻訳・敬語・ビジネス・要約）の一括処理
HELD = object()    # よそを見ていたあいだに取っておいた文字（入れる／逃がす）


class Controller:
    def __init__(self) -> None:
        ensure_dirs()
        ensure_dictionary()
        # ログを先に用意する。設定を読む前に起きたこと（設定ファイルが
        # 壊れていて退避した、など）も記録に残すため。
        setup_logging("INFO")
        self.cfg = Config()
        set_log_level(self.cfg.str_("log_level", "INFO"))
        i18n.set_language(self.cfg.str_("ui_language", "ja"))
        log.info("=" * 60)
        log.info("koe-type %s を起動します (python %s)", VERSION,
                 sys.version.split()[0])

        self.dictionary = Dictionary(DICT_PATH)
        self.history = History()
        # 誤変換の学習（採用したペア）と同音異義語の好み。
        # 用意できなくても音声入力そのものは止めない（None で守る）。
        self.learn_store: learnfix.LearnStore | None = None
        self.homo_prefs: homophones.Prefs | None = None
        try:
            self.learn_store = learnfix.LearnStore()
            self.homo_prefs = homophones.Prefs()
        except Exception:
            log.exception("学習ストアを用意できませんでした")
        self.engine = None
        self.engine_error = ""
        # エンジン切替の状態（逃げている理由・失敗と遅さの数え方・
        # 通知済みの印）は enginestate に集約した（2026-10-31 第三者
        # 監査の構造判断: 高・中の大半がこの状態の分散に集中していた）。
        # engine_fallback / _engine_fails / _slow_runs / _slow_last_at /
        # _engine_since は、その状態への互換プロパティ（__init__ の後）。
        self._switch_state = enginestate.EngineSwitchState()
        # ready を観測済みのエンジン（_note_engine_ready が使う）。
        # エンジンの実物で比べるので、組み立て・切替のたびに
        # 新しいエンジンで観測し直す形になる。
        self._ready_engine = None
        self._fast_runs = 0
        # 自動格下げ（"slow"）の最中だけ、区間の最終デコード用に
        # 抱える設定モデルのエンジン（_quality_engine が管理）。
        self._final_engine = None
        self._final_engine_key = ""
        self._quality_failed_at = 0.0   # 品質エンジン生成に失敗した時刻
        self._quality_lock = threading.Lock()
        # 発話（セッション）ごとに、確定した本文の文字数を数える。
        # 末尾の断片ガード（_handle_audio）が「実質的な本文が既に
        # 確定しているか」の判定に使う。
        self._session_body: dict[int, int] = {}
        self._build_engine()

        self.cutter = self._build_cutter()
        self.recorder = Recorder(self._on_audio)
        self.recorder.on_idle = self._on_idle_audio
        self.recorder.device_name = self.cfg.str_("microphone", "")

        self.recording = False
        # 話しながらモードの状態。区間が変わるたびに utterance を進め、
        # 古い回の結果が後から割り込まないようにする。
        self.agreement = Agreement(
            rounds=self.cfg.int_("stream_agree_rounds", 3),
            min_span=self.cfg.int_("stream_agree_span_ms", 800) / 1000.0)
        self.utterance = 0
        self._agree_lock = threading.Lock()
        # 停止の「録り残し（post_roll）」のあいだも音を受けるための旗。
        # _stop_recording が recording=False にしたあと post_roll ぶん
        # 待つが、その間も _on_audio が音をカッターへ渡さないと、
        # 最後の 0.4 秒がまるごと消える（実際に消えていた）。
        self._tail_capture = False
        # 録音キーの二度押し（履歴ピッカー）の判定と、開始経路の印。
        self._dtap = histpick.DoubleTapGate()
        self._start_via_main_key = False
        self._picker_target = 0
        self.stream_thread: threading.Thread | None = None
        self.session = 0
        self.cancelled: set[int] = set()
        # クリックで止めた録音。これより後に出てきた文字は貼らずに
        # クリップボードへためる（_stop_for_click を参照）。
        self._spill_session = 0
        self._spill_buf = ""
        # よその窓を見ているあいだに出てきた文字。元の入力欄の分として
        # 取っておき、その窓に戻ったところで入れる（_hold / _flush_held）。
        # ★前はクリップボードへ逃がすだけで、利用者には「話したのに
        # 文字が入らない」ように見えていた（2026-10-11 の頼み）。
        self._held: list[tuple[str, int, int, bool]] = []
        self._held_target = 0
        self._held_since = 0.0
        self._held_left = False      # いちど元の窓から離れたか
        self._held_queued = False    # 入れる仕事を worker へ頼み済みか
        self._spill_hold = False     # クリックで止めた分を取っておくか
        self._spill_target = 0
        # 台本（テスト）で模擬した前面の窓。本物の前面は変えないため
        self._sim_foreground = 0
        self.started_at = 0.0
        self.pending = 0
        self.last_message = ""
        self.last_message_at = 0.0
        # 入力先の窓。録音を始めた時のものを覚えておき、処理中に別の窓へ
        # 移っていたら貼らずにコピーへ切り替える（誤爆を防ぐ）。
        self.target_hwnd = 0
        self.target_focus_hwnd = 0  # 録音開始時のフォーカス対象コントロール
        self.last_text = ""        # 貼り直し用に、最後に入力した文字
        self._mic_checked = 0.0
        self._last_sound = 0.0     # 最後に声が聞こえた時刻
        self._window_warned = 0.0
        # ★クリックを受け止めて待つ仕組みはやめた（PC 全体が重くなるため）。
        # 入力先が変わったことは、画面の見張り（SetWinEventHook）で知る。
        self.mouse = mousewatch.MouseWatch(self._on_click)
        self.settings = None
        self._next_config_poll = 0.0
        self._next_purge = 0.0
        self._next_keycheck = 0.0
        # 軽さの見張り。測ること自体が重くならないよう、1 秒に 1 回だけ。
        self.health = health.Health(LOG_DIR / "metrics.jsonl",
                                    heartbeat=LOG_DIR / "heartbeat")

        self._events: queue.Queue[tuple[str, dict]] = queue.Queue()
        self._ui_jobs: queue.Queue = queue.Queue()
        # 「止める途中」の状態。ここで固まると、帯が消えず
        # Ctrl+Space も効かなくなる（実際に起きた）。必ず時間で見張る。
        self.stopping = False
        self._stop_began = 0.0
        self._stop_asked = False     # 停止を control へ頼んだ（二重防止）
        self._next_stuck_log = 0.0
        self._note_hold = 1.0        # いまのお知らせを出しておく長さ
        self._idle_level = 0.0       # 録音していない間の声の大きさ（表示用）
        # 続けて録音したときの、前の文とのつなぎ目。
        # どの窓へ・いつ入れたかを覚えておく。
        self._last_insert_hwnd = 0
        self._last_insert_at = 0.0
        self._last_insert_tail = ""
        self._last_insert_group = -1
        # 直前の入力の取り消し（undo）用
        self._last_typed_text = ""
        self._last_typed_hwnd = 0
        self._last_typed_at = 0.0
        self._last_typed_submitted = False
        # 検証用。「音が聞こえない」状況を作るための印。
        # から打ちモードの台本からしか立たない。
        self._quiet_test = False
        # 特定動作（アクションモード：長押し／専用キー）の状態
        self._current_action: str = ""
        self._action_pcm: bytearray = bytearray()
        self._action_sessions: set[int] = set()
        self._long_press_promoted: bool = False
        self._work: queue.Queue[tuple[object, object, int]] = queue.Queue()
        self._session_entry_ids: dict[int, int] = {}
        self._stop = threading.Event()
        self._lock = threading.Lock()

        # 名前は昔の tkinter のなごり（after / quit / mainloop だけ使う）
        self.root = MainLoop()

        self.win = WinThread(
            on_hotkey_down=lambda: self._post("hotkey_down"),
            on_hotkey_up=lambda held=0.0: self._post("hotkey_up",
                                                      held=held),
            on_action_down=lambda: self._post("action_down"),
            on_custom_action_down=lambda inst_id: self._post("custom_action_down",
                                                             inst_id=inst_id),
            on_long_press=lambda held=0.0: self._post("long_press",
                                                       held=held),
            on_send=lambda: self._post("send"),
            on_cancel=lambda: self._post("cancel"),
            on_menu=lambda name: self._post("menu", name=name),
            is_recording=lambda: self.recording,
            on_toggle_lang=lambda: self._post("toggle_language"),
            on_assistant_down=lambda: self._post("assistant_down"),
            on_fix_down=lambda: self._post("fix_down"),
            quick_settings_fn=self._quick_settings,
        )
        self.overlay = self.win.overlay
        self.win.set_focus_listener(self._focus_changed)
        self.win.set_keys_listener(self._keys_lost)
        self._refresh_overlay()
        self._apply_hotkeys()
        self.cfg.subscribe(self._config_changed)

        # クリップボード履歴。音声入力とは別のスレッドで動く。
        # ここで失敗しても音声入力は止めない（記録だけ残して先へ進む）。
        # 最後に前に出ていた「ほかのアプリ」の窓を覚えておき、トレイから
        # 一覧を開いたときの貼り先にする（トレイを押すと前面がタスク
        # バーに替わってしまうため）。
        self._last_foreground = 0
        self.clip = None
        try:
            from .clipwin import ClipService  # noqa: PLC0415
            self.clip = ClipService(
                self.cfg,
                notify=lambda m: self._notify(m, hold=self.NOTE_INFO),
                open_settings=self._open_clip_settings,
                last_target=lambda: self._last_foreground,
                # 文章変換のレシピ一覧から選んだら、その変換で録音する
                start_recipe=lambda iid: self._post("custom_action_down",
                                                    inst_id=iid),
                is_recording=lambda: self.recording,
                stop_recording=lambda: self._post("stop"),
                is_busy=lambda: bool(self.recording or self.pending
                                     or self.stopping),
                on_screen_assistant=lambda: self._post("assistant_down"))
        except Exception:
            log.exception("クリップボード履歴を用意できませんでした")

    # ------------------------------------------------ 切替状態への互換

    def _state(self) -> enginestate.EngineSwitchState:
        """エンジン切替の状態。__init__ を通らない生成（テストの
        スタブ組み立て）でも、初回アクセスで遅延して用意する。"""
        state = self.__dict__.get("_switch_state")
        if state is None:
            state = enginestate.EngineSwitchState()
            self.__dict__["_switch_state"] = state
        return state

    @property
    def engine_fallback(self) -> str:
        """自動で逃げている理由（"" / "slow" / "trouble"）。"""
        return self._state().reason

    @engine_fallback.setter
    def engine_fallback(self, value: str) -> None:
        self._state().reason = value

    @property
    def _engine_fails(self) -> int:
        return self._state().fails

    @_engine_fails.setter
    def _engine_fails(self, value: int) -> None:
        self._state().fails = value

    @property
    def _slow_runs(self) -> int:
        return self._state().slow_runs

    @_slow_runs.setter
    def _slow_runs(self, value: int) -> None:
        self._state().slow_runs = value

    @property
    def _slow_last_at(self) -> float:
        return self._state().slow_last_at

    @_slow_last_at.setter
    def _slow_last_at(self, value: float) -> None:
        self._state().slow_last_at = value

    @property
    def _engine_since(self) -> float:
        return self._state().since

    @_engine_since.setter
    def _engine_since(self, value: float) -> None:
        self._state().since = value

    def _quick_settings(self) -> dict[str, object]:
        """トレイメニューのクイック切り替え項目に渡す現在の状態。"""
        ready_models: list[tuple[str, str]] = []
        for k, m in catalog.MODELS.items():
            if not catalog.missing_assets(k):
                ready_models.append((k, m.name))
        return {
            "punct_density": self.cfg.str_("punctuation_density", "few"),
            "language": self.cfg.str_("language", "ja"),
            "voice_commands": self.cfg.bool_("voice_commands", True),
            "current_model": self.cfg.str_("model", catalog.DEFAULT_MODEL),
            "ready_models": ready_models,
            "clip_enabled": (self.clip is not None
                             and self.cfg.bool_("clip_enabled", True)),
            "clip_paused": bool(self.clip is not None and self.clip.paused),
            "recipe_ready": self.clip is not None,
        }

    # ------------------------------------------------------------ 組み立て

    def _build_engine(self) -> None:
        key = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        old = self.engine
        try:
            self.engine = engines.build(key, self.cfg.str_("language", "ja"))
            self.engine_error = ""
            log.info("モデル: %s（%s）", self.engine.name,
                     "常駐" if getattr(self.engine, "resident", False)
                     else "外部プロセス")
        except EngineError as exc:
            self.engine = None
            self.engine_error = str(exc)
            log.error("モデルを使えません: %s", exc)
        if old is not None and old is not self.engine:
            try:
                old.close()
            except Exception:
                log.debug("前のモデルの後片付けで例外", exc_info=True)
        # 設定からの組み立て＝権威あるエンジン。自動切替の印と
        # 数え直しをリセットし、品質エンジンも手放す。
        # 利用者が自分でモデルを選び直した時もここを通るので、
        # 「手動の選択には干渉しない」のはこのリセットで担保する。
        self._state().reset_for_build(time.monotonic())
        self._drop_quality_engine()

    def _switch_engine(self, key: str, *, reason: str = "") -> None:
        """使うモデルを切り替える（設定は書き換えない）。

        混んでいて間に合わない時に、速いモデルへ逃げるために使う。
        設定を書き換えないのは、落ち着いたら元に戻すため。
        """
        if key == getattr(self.engine, "name", ""):
            return
        try:
            fresh = engines.build(key, self.cfg.str_("language", "ja"))
        except EngineError as exc:
            log.error("%s に切り替えられません: %s", key, exc)
            return
        old, self.engine = self.engine, fresh
        # 切り替えた直後は初期化の遅れを含みうるのと、遅さの実績は
        # 前のエンジンに対してのものなので、番人は数え直す。
        self._state().note_switch(reason, time.monotonic())
        log.warning("モデルを %s に切り替えました（理由: %s）", key, reason)
        # 切替は必ず知らせる。以前は "slow" の時だけで、障害での
        # 切替（"trouble"）は無通知のまま精度が落ちていた
        # （2026-10-31 監査 H1）。同じ逃避中の重ね通知は状態側で止める。
        if reason == "slow":
            self._notify_switch(reason, t("overlay.switched_fast"))
        elif reason == "trouble":
            self._notify_switch(reason, t("overlay.switched_fallback"))
        if old is not None:
            try:
                old.close()
            except Exception:
                log.debug("前のモデルの後片付けで例外", exc_info=True)
        threading.Thread(target=fresh.warmup, name="warmup",
                         daemon=True).start()

    def _notify_switch(self, reason: str, message: str) -> None:
        """切替の通知。同じ逃避エピソードでは理由ごとに 1 回だけ。"""
        if self._state().mark_notified(reason):
            self._notify(message, hold=self.NOTE_INFO)

    def _note_engine_ready(self) -> None:
        """今のエンジンが ready になった時刻を番人へ伝える。

        組み立て（_build_engine）と ready は別物: 常駐エンジンは
        初回の読み込みが終わるまで ready にならず、Haas では
        組み立てから 11 秒後に ready になった（2026-11-05 実機）。
        番人の猶予を組み立て時刻だけで見ると、読み込み明けの
        起動ジッタを「遅い」と数えて格下げが誤発する。観測は
        _tick（定期的）と _watch_speed の両方から行い、enginestate
        側で ready から 5 秒の猶予（READY_GRACE）に使う。
        ready を持たないエンジン（テストのスタブ等）では何もしない。
        """
        eng = self.engine
        if eng is None or getattr(self, "_ready_engine", None) is eng:
            return
        if getattr(eng, "ready", None) is True:
            self._ready_engine = eng
            self._state().note_ready(time.monotonic())

    def _watch_speed(self, took: float, audio_seconds: float) -> None:
        """間に合っているかを見張り、遅れ続けたら速いモデルへ逃げる。

        基準は「音の長さに対して処理が長い」こと。音より処理が長いと、
        話し続けるほど遅れが積み上がる（雪だるま式）。

        番人の衛生（2026-10-26）:
        - エンジンの組み立て・切替から 2 秒以内に始まった認識は
          数えない。初回の遅れはモデル読み込み等の初期化であって
          「間に合っていない」証拠ではない。実際に、発話冒頭の
          3.11 秒（予算 0.50 秒）が引き金の一部になって格下げが
          発動し、戻す処理が無かったために以後の全発話が軽い
          モデルのままになる事故があった。
        - エンジンが ready になってから 5 秒以内に始まった認識も
          数えない（_note_engine_ready）。組み立て〜ready の間に
          読み込みで時間が空くと、組み立て基準の 2 秒では起動
          ジッタを取りこぼす（2026-11-05 実機: ready の直後の
          超過だけで発動した）。
        - ストライクは連続したものだけ数える。前のストライクから
          15 秒以上空いたら数え直し（数分にわたる累積で発動しない）。
        - 既に速いモデルにいる時は、逃げ先が無いので何もしない
          （以前は「逃げます」の警告だけが繰り返し出ていた）。

        数え方の実体は enginestate 側（note_round）に寄せた。
        ここは「逃げ先があるか・設定で許されているか」の判断だけ。
        """
        if self.engine is None:
            return
        self._note_engine_ready()
        if getattr(self.engine, "name", "") == catalog.FAST_MODEL:
            return
        budget = max(0.5, audio_seconds * 0.6)
        if not self._state().note_round(took, budget, time.monotonic()):
            return
        wanted = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        if wanted == catalog.FAST_MODEL or not self.cfg.bool_(
                "auto_fast_model", True):
            return
        log.warning("処理が間に合っていないので速いモデルへ逃げます "
                    "(%.2fs > %.2fs)", took, budget)
        self._switch_engine(catalog.FAST_MODEL, reason="slow")
        if self.engine_fallback == "slow":
            # 格下げ中の最終デコード用に、設定モデルのエンジンを
            # 先に用意して温めておく（_quality_engine 参照）。
            threading.Thread(target=self._quality_engine,
                             name="quality-warmup", daemon=True).start()

    def _restore_auto_downgrade(self) -> None:
        """自動切替から設定のモデルへ戻す（録音開始時に呼ぶ）。

        ★格下げは「その発話限り」。以前は戻す処理が無く、アプリを
        起動し直すまで軽いモデルで認識され続け、長文の後半が
        崩壊した（2026-10-26、利用者の実例で確定）。
        利用者が自分で選んだモデルには干渉しない: 戻すのは
        engine_fallback に印（"slow" / "trouble"）がある時だけ。
        手動の変更は _build_engine 経由でこの印を消すので、
        ここには来ない。

        障害での切替（"trouble"）も対象（2026-10-31 監査 H1 で追加）。
        以前は「勝手に戻すと壊れたモデルへ逆戻りしかねない」として
        対象外だったが、その結果、再起動か設定変更まで弱いモデルに
        固定され、利用者は精度低下に気づけなかった。戻すのは
        「次回録音開始時に 1 回だけ再試行」であり、設定モデルが
        本当に壊れていれば、また連続失敗で受け皿へ逃げ直す
        （_engine_trouble）。一方通行にせず、行き来できる形にする。
        """
        state = self._state()
        reason = state.reason
        if reason not in ("slow", "trouble") or self.engine is None:
            return
        escape = (catalog.FAST_MODEL if reason == "slow"
                  else catalog.FALLBACK_MODEL)
        wanted = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        if (getattr(self.engine, "name", "") != escape
                or wanted == escape):
            # 逃げ先にいない、または設定自体が逃げ先。その場合は
            # 印だけ消す（戻す先が存在しない）。
            state.clear_reason()
            return
        log.info("前回の発話で %s へ逃げていたので、"
                 "設定のモデル %s へ戻します", escape, wanted)
        self._switch_engine(wanted, reason="restore")
        if (self.engine is not None
                and getattr(self.engine, "name", "") != escape):
            # 戻れた（常駐が使えず受け皿エンジンに落ちた場合を含む）。
            state.clear_reason()
            self._drop_quality_engine()
        # 戻れなかったら印を残し、次の録音開始でもう一度試す。

    def _drop_quality_engine(self) -> None:
        """最終デコード用に抱えた設定モデルのエンジンを手放す。"""
        with self._quality_lock:
            engine = self._final_engine
            self._final_engine = None
            self._final_engine_key = ""
        if engine is not None:
            try:
                engine.close()
            except Exception:
                log.debug("品質エンジンの後片付けで例外", exc_info=True)

    def _quality_engine(self):  # noqa: ANN202 - Engine | ResidentEngine
        """自動格下げ中だけ使う、設定モデルのエンジン（最終用）。

        話しながらの部分仮説は速いモデルで出し続ける（遅れると
        入力が雪だるま式に遅れる）。一方、**区間の最終デコードは
        設定モデルでやる**。2026-10-26 の再デコード実験（AI PC・
        本番経路）で、同じ 59.6 秒の音声を SenseVoice が中盤から
        崩壊させ末尾を落としたのに対し、Whisper large-v3-turbo は
        末尾までほぼ正確に復元した。精度を決めるのは最終デコード
        なので、ここだけは妥協しない。

        格下げしていない時、設定モデルが今のエンジンと同じ時は
        None を返す（今のエンジンが最終デコードも担う）。
        生成に失敗したら 60 秒は再試行しない（毎区間エラーで
        遅くならないため）。読み込み自体は常駐モデルの遅延
        ロード任せで、この呼び出しは軽い。
        """
        if self.engine is None or self.engine_fallback != "slow":
            return None
        wanted = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        if wanted == getattr(self.engine, "name", ""):
            return None
        fresh = None
        with self._quality_lock:
            if (self._final_engine is not None
                    and self._final_engine_key == wanted):
                return self._final_engine
            if time.monotonic() - self._quality_failed_at < 60.0:
                return None
            try:
                fresh = engines.build(
                    wanted, self.cfg.str_("language", "ja"))
            except EngineError as exc:
                self._quality_failed_at = time.monotonic()
                log.error("最終デコード用の %s を用意できません: %s",
                          wanted, exc)
                return None
            if fresh.name == getattr(self.engine, "name", ""):
                # 常駐が使えず受け皿に落ちる等で、今のエンジンと
                # 実質同じものができた。二重に抱えない。
                self._quality_failed_at = time.monotonic()
                spare = fresh
                fresh = None
            else:
                spare = self._final_engine
                self._final_engine = fresh
                self._final_engine_key = wanted
        if spare is not None:
            try:
                spare.close()
            except Exception:
                log.debug("品質エンジンの後片付けで例外", exc_info=True)
        if fresh is None:
            return None
        threading.Thread(target=fresh.warmup, name="quality-warmup",
                         daemon=True).start()
        log.info("最終デコード用に %s を用意しました", wanted)
        return fresh

    def _decode_final(self, pcm: bytes, *, final: bool = False
                      ) -> tuple[str, float, bool]:
        """区間の確定デコード。(整形済みテキスト, 秒, 品質経路か)。

        自動格下げ中は設定モデルのエンジンで聞く（_quality_engine）。
        品質エンジン側で失敗したら今のエンジンで聞き直し、文字を
        失わない。品質経路の所要時間は _watch_speed へ渡さない:
        番人が見るのは「話ながらの経路が間に合うか」であって、
        品質デコードの遅さは格下げの判断材料ではない。
        """
        quality = self._quality_engine()
        if quality is None:
            started = time.perf_counter()
            text = self._transcribe(pcm, final=final)
            return text, time.perf_counter() - started, False
        started = time.perf_counter()
        try:
            raw = quality.transcribe_pcm(pcm, self._hints(quality))
        except Exception:  # noqa: BLE001 - 失敗しても文字は失わない
            log.warning("最終デコード（設定モデル）に失敗したので、"
                        "今のエンジンで聞き直します", exc_info=True)
            self._drop_quality_engine()
            self._quality_failed_at = time.monotonic()
            started = time.perf_counter()
            text = self._transcribe(pcm, final=final)
            return text, time.perf_counter() - started, False
        took = time.perf_counter() - started
        self.health.last_transcribe = took
        return self._clean(raw, final=final), took, True

    def _build_cutter(self) -> SegmentCutter:
        return SegmentCutter(
            SAMPLE_RATE,
            pause_ms=self.cfg.int_("pause_ms", 700),
            min_speech_ms=self.cfg.int_("min_speech_ms", 300),
            max_segment_ms=self.cfg.int_("max_segment_ms", 15000),
            preroll_ms=self.cfg.int_("preroll_ms", 350),
            tail_ms=self.cfg.int_("tail_ms", 250),
            sensitivity=self.cfg.int_("vad_sensitivity", 30) / 10.0,
            floor=float(self.cfg.int_("vad_floor", 180)),
            merge_short_ms=self.cfg.int_("merge_short_ms", 400),
            hold_release_ms=self.cfg.int_("hold_release_ms", 1500),
            speaker_focus=self.cfg.str_("speaker_focus", "normal"),
        )

    def _apply_hotkeys(self) -> None:
        custom_instructions = self.cfg.get("ai_custom_instructions") or []
        custom_hotkeys: list[tuple[str, str]] = []
        for inst in custom_instructions:
            inst_id = str(inst.get("id", "")).strip()
            hk = str(inst.get("hotkey", "")).strip()
            enabled = bool(inst.get("enabled", True))
            if inst_id and hk and enabled:
                custom_hotkeys.append((inst_id, hk))

        self.win.configure(
            hotkey=self.cfg.str_("hotkey", "ctrl+space"),
            cancel_hotkey=self.cfg.str_("cancel_hotkey", "esc"),
            lang_hotkey=self.cfg.str_("hotkey_language", ""),
            action_hotkey=self.cfg.str_("action_hotkey", ""),
            assistant_hotkey=self.cfg.str_("screen_assistant_hotkey",
                                           "ctrl+alt+j"),
            fix_hotkey=self.cfg.str_("fix_last_hotkey", "ctrl+alt+z"),
            custom_hotkeys=custom_hotkeys,
            # 離したことを見るのは「長押し」「おまかせ」または「長押し特定動作が有効」のとき
            hold_mode=(
                self.cfg.str_("shortcut_mode", "toggle") in ("hold", "auto")
                or self.cfg.str_("long_press_action", "none") != "none"
            ),
            enter_sends=self.cfg.bool_("enter_sends", True),
            excluded=self.cfg.list_("excluded_apps"),
            show_tray=self.cfg.bool_("tray_icon", True),
        )

    # ------------------------------------------------------------ 設定の反映

    @guard
    def _config_changed(self, keys: set[str]) -> None:
        if keys & {"hotkey", "cancel_hotkey", "hotkey_language",
                   "action_hotkey", "screen_assistant_hotkey",
                   "fix_last_hotkey",
                   "long_press_action", "ai_custom_instructions",
                   "shortcut_mode", "enter_sends", "excluded_apps",
                   "tray_icon"}:
            self._apply_hotkeys()
        if self.clip is not None:
            from .clipwin import RECONFIGURE_KEYS  # noqa: PLC0415
            if keys & RECONFIGURE_KEYS:
                self.clip.configure()
        if keys & {"pause_ms", "min_speech_ms", "max_segment_ms", "preroll_ms",
                   "tail_ms", "vad_sensitivity", "vad_floor"}:
            if not self.recording:
                self.cutter = self._build_cutter()
        if keys & {"model", "language"}:
            self._build_engine()
        if "microphone" in keys:
            self.recorder.device_name = self.cfg.str_("microphone", "")
            if not self.recording:
                self.recorder.unlisten()
                self.recorder.listen()
        if "mic_preroll_ms" in keys:
            self.recorder.preroll_ms = self.cfg.int_("mic_preroll_ms", 1000)
            if not self.recording:
                if self.recorder.preroll_ms <= 0:
                    self.recorder.unlisten()
                else:
                    self.recorder.listen()
        if "ui_language" in keys:
            i18n.set_language(self.cfg.str_("ui_language", "ja"))
            self.win.refresh_tray()
        # ★ここに無い項目は、設定画面で変えても帯に伝わらない。
        # 「表示のかたち」が抜けていて、選び直しても起動し直すまで
        # カードのままだった（2026-10-05 立ち会いテストで発覚）。
        if keys & {"overlay", "overlay_position", "overlay_size",
                   "overlay_margin_px", "theme", "overlay_design",
                   "overlay_hint", "overlay_text", "hotkey", "overlay_color",
                   "cancel_hotkey"}:
            self._ui_jobs.put(self._refresh_overlay)
        if "log_level" in keys:
            set_log_level(self.cfg.str_("log_level", "INFO"))
        if "autostart" in keys:
            if self.cfg.bool_("autostart", True):
                autostart.enable()
            else:
                autostart.disable()
        if "history_limit" in keys and self.cfg.int_("history_limit") <= 0:
            self.history.clear()

    def _hint_text(self) -> str:
        """帯に小さく出す操作のヒント。設定したキーの名前を入れる。"""
        return t("overlay.hint").format(
            stop=hotkeys.label(self.cfg.str_("hotkey", "ctrl+space")),
            cancel=hotkeys.label(self.cfg.str_("cancel_hotkey", "esc")))

    @guard
    def _refresh_overlay(self) -> None:
        self.overlay.configure(
            theme_name=self.cfg.str_("theme", "system"),
            position=self.cfg.str_("overlay_position", "bottom"),
            size=self.cfg.str_("overlay_size", "medium"),
            margin_px=self.cfg.int_("overlay_margin_px", 16),
            enabled=self.cfg.bool_("overlay", True),
            design=self.cfg.str_("overlay_design", "pill"),
            hint_text=self._hint_text(),
            show_hint=self.cfg.bool_("overlay_hint", True),
            show_text=self.cfg.bool_("overlay_text", True),
            record_colour=self.cfg.str_("overlay_color", "red"),
        )
        # トレイのメニューのチェックも合わせる
        self.win.overlay_text_on = self.cfg.bool_("overlay_text", True)

    # ------------------------------------------------------------ 起動/終了

    def run(self) -> None:
        if device_count() == 0:
            log.warning("マイクが見つかりません（あとから挿しても構いません）")

        self.win.start()
        self.win.wait_ready()
        self._apply_hotkeys()
        self._start_clip()

        threading.Thread(target=self._control_loop, name="control",
                         daemon=True).start()
        threading.Thread(target=self._worker_loop, name="worker",
                         daemon=True).start()

        if getattr(self.cfg, "recovered", ""):
            # 設定が壊れていた。黙って初期値に戻すと気づけないので知らせる。
            log.warning("設定を初期値に戻しました（%s に退避）",
                        self.cfg.recovered)
            self._notify(t("overlay.config_reset"), hold=8.0)

        from . import firstrun  # noqa: PLC0415
        if firstrun.should_open(self.cfg):
            # 初めて使う人。6 画面の案内を開く。
            # 設定画面にいきなり放り込むより、順に進めるほうが迷わない。
            log.info("初回の案内を開きます")
            self._ui_jobs.put(lambda: self.open_settings("onboarding"))
        elif self.engine_error:
            self._notify(t("overlay.no_model"), hold=6.0)
            if not any(catalog.model_ready(k) for k in catalog.MODELS):
                log.info("モデルが未取得なので設定画面を開きます")
                self._ui_jobs.put(lambda: self.open_settings("transcription"))
        elif self.cfg.bool_("warmup", True):
            threading.Thread(target=self._warmup, name="warmup",
                             daemon=True).start()

        try:
            if self.cfg.bool_("autostart", True):
                autostart.ensure()
        except Exception:
            log.exception("自動起動の確認で例外")

        self.recorder.preroll_ms = self.cfg.int_("mic_preroll_ms", 1000)
        self.recorder.listen()
        if self.cfg.bool_("polite_priority", True):
            priority.idle()
        self.win.install_mouse(self.mouse)
        self._purge_audio()
        self.health.start()
        self._start_guardian()

        # ファイル変更監視（ホットリロード）：待機中に自動で再起動して
        # 最新コードを反映する。★開発専用（2026-10-24 改修）：通常起動では
        # 監視自体を始めない。有効化は環境変数 KOE_TYPE_HOT_RELOAD=1 の
        # ときだけ（reloader.enabled()）。利用者の PC で、常駐中に勝手に
        # 起動し直す経路を残さないため。
        from . import reloader as _reloader_mod  # noqa: PLC0415
        from .reloader import HotReloader  # noqa: PLC0415
        self.reloader = None
        if _reloader_mod.enabled():
            self.reloader = HotReloader(
                is_idle_fn=lambda: (
                    not self.recording
                    and self.health.stopping_since == 0.0
                    and self.pending == 0
                ),
                on_restart_fn=lambda: self.root.after(0, self.root.quit),
            )
            self.reloader.start()
        else:
            log.info("ホットリロード監視は無効です（開発専用）")

        # 自動更新・モデルカタログ確認の見張り役
        from .autoupdate import AutoUpdater  # noqa: PLC0415
        self.updater = AutoUpdater(
            self.cfg,
            notify_fn=lambda msg: self._notify(msg, hold=self.NOTE_INFO),
            is_idle_fn=lambda: (
                not self.recording
                and self.health.stopping_since == 0.0
                and self.pending == 0
            ),
        )
        self.updater.start()

        # テストの台本があれば流す（から打ちモードのときだけ動く）
        testdrive.start(self._post, lambda: self.root.after(0, self.root.quit))

        self.root.after(80, self._tick)
        log.info("待機中です。%s で録音を開始します。", self.cfg.str_("hotkey"))
        try:
            self.root.mainloop()
        finally:
            self.shutdown()

    def shutdown(self) -> None:
        if self._stop.is_set():
            return
        if hasattr(self, "reloader") and self.reloader is not None:
            self.reloader.stop()
        log.info("終了します")
        try:
            # 終わるときに、直近の様子を残しておく（あとで調べられるように）
            self.health.mark("終了")
            log.info("最後の様子: %s", self.health.summary())
            # 画面の繰り返しが生きていた証拠。止まると帯が消えず、
            # Ctrl+Space も効かなくなる（実際に起きた）。
            log.info("画面の繰り返し %d 回", self.health.ticks)
        except Exception:
            log.debug("終了時の記録で例外", exc_info=True)
        self._drain(self.cfg.int_("shutdown_wait_ms", 6000) / 1000.0)
        self._stop.set()
        if self.settings is not None:
            try:
                self.settings.stop()
            except Exception:
                log.exception("設定画面のサーバーを止められませんでした")
        if self.clip is not None:
            try:
                self.clip.stop()
            except Exception:
                log.exception("クリップボード履歴を止められませんでした")
        for fn in (self.health.stop, self.mouse.disarm, self.mouse.remove,
                   self.recorder.shutdown, sysaudio.speaker.restore,
                   self.win.quit):
            try:
                fn()
            except Exception:
                log.exception("終了処理で例外")

    def _drain(self, timeout: float) -> None:
        """終わる前に、残っている文字起こしを片づける。

        ここで待たないと、**話した内容がまるごと消える**。
        履歴への保存は文字起こしのあとなので、処理前に終わると
        音も文字も残らない。PC が混んでいると実際に起きた。
        """
        if timeout <= 0 or not self.pending:
            return
        log.info("残り %d 件を片づけます（最大 %.1f 秒待ちます）",
                 self.pending, timeout)
        deadline = time.monotonic() + timeout
        while self.pending and time.monotonic() < deadline:
            time.sleep(0.05)
        if self.pending:
            log.warning("%d 件を片づけきれませんでした", self.pending)
        else:
            log.info("残りをすべて片づけました")

    @guard
    def _warmup(self) -> None:
        """起動直後にモデルを読み、1 回空回しして待ちをなくす。

        **既定ではモデルを外さない。** ここで読んだものを、そのまま
        置いたままにする。利用者が初めて Ctrl+Space を押した時に
        「読み込み中です」と待たせないため。
        """
        if self.engine is None:
            return
        self.engine.warmup()

    # ------------------------------------------------------------ 画面更新

    def _tick(self) -> None:
        try:
            # config.json を手で書き換えた場合も拾う（1 秒に 1 回だけ見る）
            now = time.monotonic()
            if now >= self._next_config_poll:
                self._next_config_poll = now + 1.0
                self.cfg.poll_external()

            while True:
                try:
                    self._ui_jobs.get_nowait()()
                except queue.Empty:
                    break
                except Exception:
                    log.exception("画面側の処理で例外")

            self.health.ticks += 1
            # ready の観測は録音の有無によらずこちらでも行う
            # （待機中に読み込みが終わった時刻を番人へ渡すため）。
            self._note_engine_ready()
            self.health.recording = self.recording
            self.health.pending = self.pending
            self.health.stopping_since = (self._stop_began
                                          if self.stopping else 0.0)
            self._watch_keys()
            self._watch_mic()
            if time.monotonic() >= getattr(self, "_next_purge", 0):
                self._purge_audio()

            # 待機中は控えめに。録音・文字起こし中だけ通常へ戻す。
            if self.cfg.bool_("polite_priority", True):
                if self.recording or self.pending:
                    priority.busy()
                else:
                    priority.idle()

            if self.recording:
                self._watch_recording()
            # 「止める途中」のまま居残っていないか、毎回見る
            self._watch_stopping()
            # よそを見ていたあいだの文字を、元の欄へ入れるか逃がすか
            self._watch_held()

            if self.recording:
                elapsed = time.monotonic() - self.started_at
                # ★録音中は文字起こし処理中（self.pending）でも
                # 常に "recording"（聞いています＋波形＋タイマー）を維持する。
                # 以前は `state = "transcribing" if self.pending else "recording"`
                # としていたため、話している途中で「文字にしています」がパカパカ
                # 挟まり、「喋っちゃいけないのか」と利用者を不安にさせていた。
                self.overlay.set_state("recording", elapsed=elapsed,
                                       level=self.cutter.level,
                                       pending=self._pending_text())
                limit = self.cfg.int_("max_record_ms", 0)
                if limit and elapsed * 1000 >= limit:
                    log.info("最大録音時間に達したので停止します")
                    self._post("stop")
            elif self.pending:
                # 録音終了後、残りの文字を注入中の待機。
                # 「文字にしています」文言は出さず、未確定文字だけ維持する。
                self.overlay.set_state("transcribing",
                                       pending=self._pending_text())
            elif (self.last_message
                  and time.monotonic() - self.last_message_at
                  < self._note_hold):
                self.overlay.set_state("done", message=self.last_message)
            else:
                self.overlay.hide()
        except Exception:
            log.exception("画面更新で例外")
        finally:
            # ★ここは必ず finally で呼ぶ。
            # 以前は try の中で `return` していて、静かで自動停止した
            # とたんに**この繰り返しそのものが終わっていた**。
            # 帯が消えず、設定画面も開かず、待機に戻れなくなった。
            if not self._stop.is_set():
                self.root.after(80, self._tick)

    def _focus_changed(self, hwnd: int, event: int) -> None:
        """入力先が変わった。**ここは軽く済ませる。**

        クリックそのものは見ない（入力を止めない方針）。
        クリックで入力先が変われば、ここに届く。
        重い判定はせず、control スレッドへ渡すだけにする。
        """
        if hwnd and event == 0x0003:        # EVENT_SYSTEM_FOREGROUND
            # クリップボード履歴の貼り先の候補。タスクバー（トレイを
            # 押したとき）やデスクトップは除く。自分の窓はそもそも届かない
            # （WINEVENT_SKIPOWNPROCESS）。
            try:
                if inject.window_class(hwnd) not in (
                        "Shell_TrayWnd", "Shell_SecondaryTrayWnd",
                        "NotifyIconOverflowWindow", "Progman", "WorkerW",
                        "TopLevelWindowForOverflowXamlIsland"):
                    self._last_foreground = hwnd
            except Exception:
                pass
        if not self.recording or not hwnd:
            return
        if hwnd == self.target_hwnd:
            return
        self._post("focus_changed", hwnd=hwnd)

    # 入力先が変わってから、本当に変わったと決めるまで待つ秒数
    FOCUS_SETTLE = 0.3

    @guard
    def _handle_focus_change(self, hwnd: int,
                             simulated: bool = False) -> None:
        """入力先が変わったときの始末。control スレッドで動く。

        ★すぐには止めない。FOCUS_SETTLE 秒待って、まだ元の窓に
        戻っていなければ止める。メニューや通知のように**一瞬だけ前に
        出て消える窓**で止めてしまい、録音を始めて 0.1〜1.9 秒で
        止まることが 10 回続いた（2026-10-05 の診断情報）。
        待つのは control スレッドの Timer で、利用者の入力は待たせない。
        """
        if not self.recording:
            return
        if self.win.is_own_window(hwnd):
            return
        mode = self.cfg.str_("stop_on_window_change", "stop")
        if mode != "stop":
            return
        session = self.session
        if simulated:
            self._sim_foreground = hwnd
        threading.Timer(
            self.FOCUS_SETTLE,
            lambda: self._post("focus_settled", hwnd=hwnd, session=session,
                               simulated=simulated)).start()

    @staticmethod
    def _where(hwnd: int) -> str:
        """窓のアプリ名と種類（ログ用）。アプリ名は個人の情報ではない。"""
        try:
            return f"{inject.window_exe(hwnd)} / {inject.window_class(hwnd)}"
        except Exception:  # noqa: BLE001
            return "?"

    @guard
    def _focus_settled(self, hwnd: int, session: int,
                       simulated: bool = False) -> None:
        """少し待ったあと、本当に入力先が変わったままかを見て決める。

        simulated は台本（テスト）から来た模擬の切り替え。その場合は
        本物の前面の窓を見ずに、台本の窓が前にあるものとして扱う。
        """
        if not self.recording or session != self.session:
            return
        now = self._sim_foreground if simulated else inject.foreground()
        if (now == self.target_hwnd
                or (now and self.win.is_own_window(now))
                or (now and self._is_same_app_window(now, self.target_hwnd))):
            log.info("一瞬だけ前に出た窓または同一アプリ内のため、録音を続けます (%s: %s)",
                     hwnd, self._where(hwnd))
            return
        # ★移った先のアプリ名と窓の種類も残す。番号だけだと、
        # あとから原因を追えなかった。
        log.info("入力先が変わったので録音を止めます (%s -> %s: %s)",
                 self.target_hwnd, now, self._where(now))
        self._notify(t("overlay.stopped_window"), hold=self.NOTE_SHORT)
        self._stop_recording(submit=False)

    def _is_same_app_window(self, clicked_hwnd: int,
                            target_hwnd: int) -> bool:
        """クリックされた窓が、入力先と同じウィンドウ・同一入力領域かを判定。"""
        if not clicked_hwnd or not target_hwnd:
            return False
        if clicked_hwnd == target_hwnd:
            return True
        try:
            user32 = ctypes.windll.user32
            # 1. 親子・直接の祖先関係チェック
            # GA_PARENT = 1, GA_ROOT = 2, GA_ROOTOWNER = 3
            for ga_type in (1, 2, 3):
                anc = int(user32.GetAncestor(clicked_hwnd, ga_type) or 0)
                if anc == target_hwnd:
                    return True
                anc_t = int(user32.GetAncestor(target_hwnd, ga_type) or 0)
                if anc_t == clicked_hwnd:
                    return True

            # 2. ルートウィンドウおよびオーナーウィンドウ同士の比較
            r1_root = int(user32.GetAncestor(clicked_hwnd, 2) or clicked_hwnd)
            r2_root = int(user32.GetAncestor(target_hwnd, 2) or target_hwnd)
            if r1_root and r2_root and r1_root == r2_root:
                return True

            r1_owner = int(user32.GetAncestor(clicked_hwnd, 3) or clicked_hwnd)
            r2_owner = int(user32.GetAncestor(target_hwnd, 3) or target_hwnd)
            if r1_owner and r2_owner and r1_owner == r2_owner:
                return True
        except Exception:
            log.debug("同一ウィンドウ判定で例外", exc_info=True)
        return False

    def _on_click(self, hwnd: int, held_click: bool) -> bool:
        """録音中にマウスが押された。見張りのスレッドから呼ばれる。

        戻り値: 録音を停止した場合は True、継続した場合は False。
        """
        if not self.recording:
            return False
        mode = self.cfg.str_("stop_on_click", "outside")
        if mode == "off":
            # マウス操作で選択・移動した可能性があるので直前の文との結合空白はリセット
            self._last_insert_hwnd = 0
            self._last_insert_tail = ""
            return False
        if mode == "outside" and self._is_same_app_window(hwnd,
                                                          self.target_hwnd):
            # 入力欄の中（＝同じ窓・同じアプリ）を押しただけ。
            # 直したい部分をマウスで青く選択して上書きしたり、
            # カーソル移動するため録音を続ける。
            self._last_insert_hwnd = 0
            self._last_insert_tail = ""
            log.debug("同一ウィンドウ内のクリックのため録音を継続します "
                      "(hwnd=%s, target=%s)", hwnd, self.target_hwnd)
            return False
        if self.win.is_own_window(hwnd):
            return False
        inside = self._is_same_app_window(hwnd, self.target_hwnd)
        log.info("録音中にクリックされたので止めます (hwnd=%s, target=%s, mode=%s, "
                 "%s)", hwnd, self.target_hwnd, mode,
                 "同じ窓の中" if inside else "よその窓")
        self._post("click_stop", outside=not inside)
        return True

    @guard
    def _stop_for_click(self, outside: bool = False) -> None:
        """クリックで録音を止める。クリックそのものは止めていない。

        ★止めたあとに出てきた文字は、**入力欄へ貼らずにクリップボードへ**
        入れる。前は 0.7 秒だけ貼り続けていたが、送信ボタンだと
        押したあとの空の入力欄に「ます」だけが入り、本文は
        「宜しくお願いし」で送られてしまった（2026-10-05 立ち会いテスト）。
        送信ボタン以外を押した場合も、入れたい場所が変わっている
        かもしれないので、貼らないほうが安全。

        outside は「よその窓を押した」。そのときの残りは、設定
        （away_text）が「元の欄に戻ったら入れる」なら取っておき、
        元の窓に戻ったところで入れる。同じ窓の中（送信ボタンなど）を
        押したときは、空になった欄に残りが入る事故を防ぐため、
        いままでどおりクリップボードへ。
        """
        with self._lock:
            self._spill_session = self.session
            self._spill_buf = ""
            self._spill_target = self.target_hwnd
            self._spill_hold = bool(
                outside and self.target_hwnd
                and self.cfg.str_("away_text", "wait") == "wait")
        self._notify(t("overlay.stopped_click"), hold=self.NOTE_SHORT)
        self._stop_recording(submit=False)

    def _spill(self, text: str, session: int, *, group: int = 0,
               join: bool = False) -> bool:
        """クリックで止めた録音の文字なら、クリップボードへためて True。

        いくつかに分かれて届いても、まとめて 1 回で貼れるようにつなぐ。
        黙って捨てずに、履歴（入力の前に保存済み）と帯でも知らせる。
        よその窓を押して止めたときは、取っておいて元の窓で入れる。
        """
        if session != self._spill_session or not text:
            return False
        if self._spill_hold:
            self._hold(text, session, group=group, join=join,
                       target=self._spill_target)
            return True
        self._spill_buf += text
        self.last_text = self._spill_buf
        save_cb = self.cfg.str_("save_to_clipboard", "fallback")
        if save_cb != "never":
            try:
                inject.set_clipboard_text(self._spill_buf,
                                          keep_out_of_history=False)
                log.info("クリックのあとの文字はクリップボードへ: %s",
                         self._spill_buf[:60])
            except Exception:
                log.exception("クリップボードに逃がせませんでした")
            self._notify(t("overlay.click_spill"), hold=self.NOTE_WARN)
        else:
            log.info("クリック後の文字（クリップボード保存無効・履歴のみ）: %s",
                     self._spill_buf[:60])
            self._notify(t("overlay.saved_to_history"), hold=self.NOTE_INFO)
        return True

    # ------------------------------------------------------ よそを見ているあいだ

    # 元の窓に戻ってから、文字を入れるまで待つ秒数。クリックで戻った
    # 直後は、文字カーソルがまだ置かれていないアプリがある。
    HELD_SETTLE = 0.25
    # 離れたことが分からないまま（よそを押しても前面が替わらなかった
    # など）、元の窓にいるとみなして入れるまでの秒数
    HELD_STAY = 1.5

    def _away_from(self, target: int) -> bool:
        """いま、入力先の窓から「よそ」へ移っているか。

        同じアプリの別の窓（ダイアログ・ポップアップ）と、koe-type 自身の
        窓（帯・クリップボードの一覧）は、よそに数えない。
        """
        if not target:
            return False
        if dryrun.enabled():
            # 試験では本物の前面の窓を見ない（台本が作った窓だけを見る）
            now = self._sim_foreground or target
        else:
            now = inject.foreground()
        if not now or now == target:
            return False
        if self.win.is_own_window(now):
            # 自分の窓のうち、前に出るのはクリップボード（変換）の一覧
            # だけ。一覧を出しているあいだの文字は、閉じて元の欄に
            # 戻ってから入れる（一覧に貼ろうとしてコピーに逃げていた）
            popup = getattr(self.clip, "_hwnd", 0) if self.clip else 0
            return bool(popup) and now == popup
        return not self._is_same_app_window(now, target)

    def _hold(self, text: str, session: int, *, group: int, join: bool,
              target: int) -> None:
        """元の入力欄に入れる文字を、戻ってくるまで取っておく。worker で動く。"""
        if not text or not target:
            return
        stale: list[tuple[str, int, int, bool]] = []
        with self._lock:
            if self._held and self._held_target != target:
                # 別の窓の分が残っていた。混ぜずに、古いほうは逃がす
                stale, self._held = self._held, []
            if not self._held:
                self._held_since = time.monotonic()
                self._held_left = False
            self._held_target = target
            self._held.append((text, session, group, join))
            total = sum(len(item[0]) for item in self._held)
        if stale:
            self._expire_held(stale, why="別の窓の分")
        log.info("よそを見ているので、元の欄の分として取っておきます"
                 "（%d 文字）: %s", total, text[:40])
        self._notify(t("overlay.held", n=total), hold=self.NOTE_WARN)

    def _watch_held(self) -> None:
        """取っておいた文字を、入れるか逃がすか決める（_tick から呼ぶ）。

        ここでは決めるだけ。貼るのは worker スレッドだけが行う。
        """
        if not self._held or self._held_queued:
            return
        now = time.monotonic()
        limit = self.cfg.int_("away_wait_s", 180)
        if limit > 0 and now - self._held_since > limit:
            self._held_queued = True
            self._work.put((HELD, "expire", -1))
            return
        if self._away_from(self._held_target):
            self._held_left = True
            # 録音終了後で自動復帰がオンなら、手動で戻るのを待たずにフラッシュを促す
            if not self.recording and self.cfg.bool_("restore_focus_on_finish", True):
                self._held_queued = True
                self._work.put((HELD, "flush", -1))
            return
        if self._held_left or now - self._held_since > self.HELD_STAY:
            self._held_queued = True
            self._work.put((HELD, "flush", -1))

    def _flush_held(self, how: str) -> None:
        """取っておいた文字を、元の欄に入れる（how="flush"）か、
        クリップボードへ逃がす（how="expire"）。worker で動く。"""
        with self._lock:
            items, self._held = self._held, []
            target = self._held_target
            self._held_queued = False
        items = [item for item in items if item[1] not in self.cancelled]
        if not items:
            return
        if how != "flush" or not target:
            self._expire_held(items, why="戻ってこなかった")
            return
        if not dryrun.enabled():
            # ボタンを離して、文字カーソルが落ち着くまで少し待つ
            deadline = time.monotonic() + 1.5
            while time.monotonic() < deadline and any(
                    mousewatch._down(vk) for vk, _n in mousewatch.BUTTONS):
                time.sleep(0.03)
            time.sleep(self.HELD_SETTLE)
        if self._away_from(target):
            # 自動で元の入力先へ戻して入力する
            if self.cfg.bool_("restore_focus_on_finish", True):
                focus = getattr(self, "target_focus_hwnd", 0)
                inject.activate_window(target, focus)
            if self._away_from(target):
                # 入れる直前に、また離れた。取っておき直す
                with self._lock:
                    self._held = items + self._held
                    self._held_target = target
                    self._held_left = True
                return
        log.info("元の窓に戻ったので、取っておいた %d 件を入れます",
                 len(items))
        for text, session, group, join in items:
            self._type(text, session, join=join, group=group, target=target)

    def _expire_held(self, items: list[tuple[str, int, int, bool]], *,
                     why: str) -> None:
        """取っておいた文字を、クリップボードへ逃がして知らせる。"""
        text = "".join(item[0] for item in items)
        if not text:
            return
        self.last_text = text
        log.info("取っておいた文字をクリップボードへ（%s）: %s", why,
                 text[:60])
        if self.cfg.str_("save_to_clipboard", "fallback") == "never":
            self._notify(t("overlay.saved_to_history"), hold=self.NOTE_INFO)
            return
        try:
            inject.set_clipboard_text(text, keep_out_of_history=False)
        except Exception:
            log.exception("クリップボードに逃がせませんでした")
        self._notify(t("overlay.held_expired"), hold=self.NOTE_WARN)

    def _watch_recording(self) -> bool:
        """録音中の見張り。止めたら True を返す。

        切り忘れたまま回り続けると、**話した内容が思わぬ場所に入る**。
        送信ボタンをマウスで押したときなど、こちらからは分からない形で
        入力先が変わることがあるので、こまめに見る。
        """
        now = time.monotonic()

        # 入力先のウィンドウの見張りは、画面の見張り（SetWinEventHook）が
        # 受け持つ。ここで毎回 GetForegroundWindow を呼ぶ必要はない。

        # --- 長く静かだった
        limit = self.cfg.int_("stop_on_silence_ms", 10000) / 1000.0
        if limit > 0:
            if not self._quiet_test and (
                    self.cutter.in_speech or self.cutter.level > 0.02):
                self._last_sound = now
            elif now - self._last_sound >= limit and not self._stop_asked:
                log.info("%.0f 秒静かだったので録音を止めます", limit)
                self._notify(t("overlay.stopped_silence"),
                             hold=self.NOTE_SHORT)
                # ★ここで直接止めてはいけない。停止には録り残しの待ちや
                # スレッドの合流が入るので、画面の繰り返しを秒単位で
                # 止めてしまう。control スレッドへ渡す。
                self._stop_asked = True
                self._post("stop")
                return True
        return False

    def _watch_stopping(self) -> bool:
        """「止める途中」で居残っていたら、強引に待機へ戻す。

        止める途中には、録り残しの待ち・スレッドの合流・マイクの停止が
        ある。どれかが遅れても、**待ち続けずに待機へ戻す**。
        そうしないと帯が消えず、Ctrl+Space も効かなくなる。
        """
        if not self.stopping:
            return False
        waited = time.monotonic() - self._stop_began
        limit = max(1.0, self.cfg.int_("stop_timeout_ms", 3000) / 1000.0)
        if waited < limit:
            return False
        if time.monotonic() >= self._next_stuck_log:
            self._next_stuck_log = time.monotonic() + 10.0
            log.error("停止が %.1f 秒終わらないので、待機へ戻します", waited)
            self.health.mark("停止が終わらない")
        self._force_idle("停止が終わらなかった")
        return True

    def _force_idle(self, why: str) -> None:
        """どんな状態からでも待機へ戻す。**失敗しても最後まで進む。**

        Ctrl+Space と Esc がいつでも効くための受け皿。
        片づけはひとつずつ try で囲む。途中で例外が出ても、
        残りを飛ばさないため。
        """
        log.warning("待機の状態へ戻します（%s）", why)
        with self._lock:
            self.recording = False
            self.stopping = False
            self._stop_asked = False
            self._quiet_test = False
        for step, fn in (("マウスの見張りを下ろす", self.mouse.disarm),
                         ("録音の停止", self.recorder.stop),
                         ("消音と音量の解除", sysaudio.speaker.restore)):
            try:
                fn()
            except Exception:
                log.exception("%s で例外（続けます）", step)
        self.stream_thread = None      # 合流は待たない（daemon なので残らない）
        try:
            self.win.refresh_hotkeys()
        except Exception:
            log.exception("ショートカットの付け直しで例外")
        try:
            self._tray_state()
            self.overlay.hide()
        except Exception:
            log.exception("画面の片づけで例外")
        self.last_message = ""      # 帯を残さない

    @guard
    def _purge_audio(self) -> None:
        """期限を過ぎた録音を消す。起動時と、1 時間ごとに。"""
        days = self.cfg.int_("history_audio_days", 14)
        self.history.purge_audio(days)
        self._next_purge = time.monotonic() + 3600

    def _watch_keys(self) -> None:
        """ショートカットの登録が外れていないか、2 秒ごとに見る。

        外れていても気づけないと「押しても何も起きない」になる。
        外れていたら付け直し、トレイの絵で知らせる。
        """
        now = time.monotonic()
        if now < self._next_keycheck:
            return
        # 30 秒ごと（2026-10-24 改修：以前は 2 秒ごとで、そのたびに
        # 全ショートカットを解除→再登録していた。登録の付け直しは
        # 「失敗が記録されているときだけ」にし、間隔も広げた。
        # winthread._verify_hotkeys_now を参照）
        self._next_keycheck = now + 30.0
        # ★確認そのものを win スレッドへ頼む。
        # RegisterHotKey は登録したスレッドのものなので、
        # 別のスレッドから付け外しすると失敗する（実際に外れた）。
        try:
            self.win.verify_hotkeys()
            self.health.hotkeys_ok = self.win.keys_ok
        except Exception:
            log.exception("ショートカットの見張りで例外")

    @guard
    def _keys_lost(self) -> None:
        """ショートカットの登録が外れた（win スレッドから呼ばれる）。"""
        self.health.hotkeys_ok = False
        self._notify(t("overlay.keys_lost"), hold=self.NOTE_WARN)
        self.health.mark("ショートカットの登録が外れた")

    @guard
    def _start_clip(self) -> None:
        """クリップボード履歴を始める。初めてのときだけ、使い方を知らせる。"""
        if self.clip is None:
            return
        self.clip.start()
        if (self.cfg.bool_("clip_enabled", True)
                and not self.cfg.bool_("clip_intro_done", False)
                and not dryrun.enabled()):
            self.cfg.set("clip_intro_done", True)
            self._notify(t("clip.intro", hotkey=hotkeys.label(
                self.cfg.str_("clip_hotkey", "alt+v"))), hold=6.0)

    def _open_clip_settings(self, item_id: int = 0) -> None:
        """設定の「クリップボード」を開く。item_id があれば、その編集から。

        -1 は「新しいグループを作る」。開くのは画面のスレッドで行う。
        """
        def go() -> None:
            self.open_settings("clipboard")
            if self.settings is not None and item_id:
                event = ({"type": "clip_new_group"} if item_id < 0
                         else {"type": "clip_edit", "id": item_id})
                self.settings.bridge.push(event)
        self._ui_jobs.put(go)

    @guard
    def _start_guardian(self) -> None:
        """見張り役のプロセスを起こす（落ちたら起動し直してくれる）。"""
        if dryrun.enabled() or not self.cfg.bool_("guardian", True):
            return
        if os.environ.get("KOE_TYPE_NO_GUARDIAN"):
            log.info("KOE_TYPE_NO_GUARDIAN が指定されているため、"
                     "見張り役は起こしません")
            return
        import subprocess  # noqa: PLC0415
        exe = Path(sys.executable)
        if exe.name.lower() == "python.exe":
            alt = exe.with_name("pythonw.exe")
            if alt.is_file():
                exe = alt
        try:
            subprocess.Popen(  # noqa: S603
                [str(exe), "-m", "app.guardian", "--quiet"],
                cwd=str(ROOT), creationflags=0x08000000)
            log.info("見張り役を起こしました")
        except Exception:
            log.exception("見張り役を起こせませんでした")

    def _watch_mic(self) -> None:
        """マイクが黙ったままになっていたら開き直す。

        スリープ復帰やマイクの抜き差しのあと、waveIn がそのままでは
        二度と音を返さないことがある。2 秒ごとに様子を見る。
        """
        now = time.monotonic()
        if now < self._mic_checked:
            return
        self._mic_checked = now + 2.0
        if not self.recorder.listening:
            return
        try:
            if self.recorder.recover() and self.recording:
                self._notify(t("overlay.mic_recovered"),
                             hold=self.NOTE_INFO)
        except Exception:
            log.exception("マイクの様子見で例外")

    def _pending_text(self) -> str:
        """帯に薄く出す「まだ入力していない文字」。"""
        if not self._previews():
            return ""
        with self._agree_lock:
            if self._types_while_speaking():
                return self.agreement.pending()[-60:]
            # 先出しだけのモードは、聞こえている全部を薄く出す
            return self.agreement.latest[-60:]

    # お知らせを出す長さ。**短く、終わったら帯ごと消す。**
    # 出しっぱなしは目障りで、録音中かどうかも分かりにくくなる。
    NOTE_SHORT = 1.0      # 予想どおりのこと（静かなので止めた、など）
    NOTE_INFO = 2.2       # 知っておくとよいこと（コピーした、など）
    NOTE_WARN = 3.5       # 困りごと（入力できない、マイクが開けない）

    def _notify(self, message: str, hold: float = 1.0) -> None:
        self.last_message = message
        self.last_message_at = time.monotonic()
        self._note_hold = max(0.3, hold)

    # 「おまかせ」で、これより長く押したら「押している間だけ」とみなす
    HOLD_THRESHOLD = 0.5

    def _hotkey_down(self) -> None:
        """録音キーが押された。設定の「ショートカットの動作」で分ける。

          toggle  押すたびに 開始／停止
          hold    押したら開始、離したら停止（長押しの間だけ）
          auto    おまかせ。短く押せば toggle、長く押せば hold
        """
        # ★二度押しは、通常の開始／停止より先に判定する。
        # 録音開始から 400ms 以内の 2 回目は「止める」ではなく、
        # テイクを捨てて履歴ピッカーを開く合図（histpick 参照）。
        # 1 回目の押下では従来どおり即・録音開始する（遅らせない）。
        if self.recording and self._dtap.classify(
                time.monotonic(),
                recording=True,
                enabled=self.cfg.bool_("hotkey_double_tap_history", True)):
            self._discard_take_and_pick_history()
            return
        if not self.recording:
            # この押下で始まる録音は「メインキー経由」と印を付ける。
            # 二度押し判定の開始時刻は、この経路の録音だけに付ける。
            self._start_via_main_key = True
        mode = self.cfg.str_("shortcut_mode", "toggle")
        if mode == "hold":
            self._started_by_press = True
            self._start_recording()
        elif mode == "auto":
            if self.recording:
                self._started_by_press = False
                self._stop_recording(submit=False)
            else:
                self._started_by_press = True
                self._start_recording()
        else:
            self._toggle()

    def _hotkey_up(self, held: float) -> None:
        """録音キーを離した。"""
        mode = self.cfg.str_("shortcut_mode", "toggle")
        started = getattr(self, "_started_by_press", False)
        self._started_by_press = False
        if not self.recording:
            return
        # 長押しアクションに昇格していた場合は、離したら停止して変換実行
        if self._long_press_promoted:
            log.info("長押しアクション終了（%.1f 秒押していた）", held)
            self._stop_recording(submit=False)
            return
        if not started:
            return
        if mode == "hold" or (mode == "auto"
                              and held >= self.HOLD_THRESHOLD):
            log.info("キーを離したので止めます（%.1f 秒押していた）", held)
            self._stop_recording(submit=False)

    def _action_name(self, action: str) -> str:
        """アクション識別子から画面・通知用の表示名称を返す。"""
        if not action:
            return ""
        fixed_names = {
            "polite": "敬語",
            "summary": "要約",
            "translate_en": "英語翻訳",
            "reply_generator": "返信文作成",
            "meeting_minutes": "議事録要約",
            "proofread": "文章推敲",
            "standardize": "標準語化",
            "brainstorm": "企画骨子化",
            "smart_calc": "スマート計算",
            "screen_assistant": "画面AIアシスタント",
        }
        if action in fixed_names:
            return fixed_names[action]
        if action.startswith("custom_instruction_"):
            inst_id = action[len("custom_instruction_"):]
            if inst_id in fixed_names:
                return fixed_names[inst_id]
            # 設定されたカスタム指示リストから名前を検索
            raw_list = self.cfg.get("custom_instructions", [])
            if isinstance(raw_list, list):
                for item in raw_list:
                    if isinstance(item, dict) and item.get("id") == inst_id:
                        name = item.get("name")
                        if name:
                            return str(name)
            return inst_id
        return action

    def _action_down(self) -> None:
        """専用アクションキーが押された。"""
        if self.recording:
            self._stop_recording(submit=False)
        else:
            action = self.cfg.str_("action_mode", "translate_en")
            self._start_recording(action=action)

    def _screen_assistant_down(self) -> None:
        """画面AIアシスタント（かこって検索・Galaxy風）を起動する。"""
        if self.recording:
            self._stop_recording(submit=False)
            return

        # 既定は Google レンズ。内蔵版は、エンジン設定が内蔵のときと、
        # Google アプリが入っていないときの受け皿として開く。
        if self.cfg.str_("snip_engine", "google") == "google":
            self._google_lens_down()
            return
        self._open_builtin_assistant()

    def _open_builtin_assistant(self) -> None:
        """内蔵版のかこって検索を開く（Google 未導入時の受け皿も兼ねる）。"""
        if getattr(self, "_assistant_running", False):
            return
        self._assistant_running = True

        def _worker() -> None:
            try:
                from . import snipping  # noqa: PLC0415
                snipping.open_screen_assistant(
                    cfg=self.cfg,
                    engine=self.engine,
                    on_notify=lambda m: self._ui_jobs.put(
                        lambda: self._notify(m, hold=self.NOTE_INFO)
                    )
                )
            except Exception:
                log.exception("画面AIアシスタントの実行で例外")
            finally:
                self._assistant_running = False

        threading.Thread(target=_worker, name="screen-assistant",
                         daemon=True).start()

    # Google レンズの状態 → 知らせる言葉（i18n のキー）
    _LENS_STATUS_KEYS = {
        "NOT_INSTALLED": "googlelens.not_installed",
        "NOT_RUNNING_THEN_LAUNCHED": "googlelens.launched",
        "HOTKEY_NOT_CONFIGURED": "googlelens.hotkey_not_configured",
        "READY": "googlelens.ready",
        "LAUNCH_FAILED": "googlelens.launch_failed",
    }

    def _notify_lens_status(self, status: object) -> None:
        """googlelens.open_lens() の状態を言葉にして知らせる。"""
        key = self._LENS_STATUS_KEYS.get(getattr(status, "name", ""),
                                         "googlelens.ready")
        msg = t(key)
        self._ui_jobs.put(
            lambda msg=msg: self._notify(msg, hold=self.NOTE_INFO))

    def _google_lens_down(self) -> None:
        """Google レンズ連携。状態に応じて呼び、無理なら内蔵版を開く。

        Google アプリ側の体験にそろえるのが原則： 起動中なら
        アプリ自身の画面検索を呼ぶキーを 1 回送るだけで、成功
        しても koe-type からは何も知らせない。止まっていたら
        起動して常駐の立ち上がりを裏で待ち、送れるところまで
        1 回のキー操作で届ける。
        以前は「起動しました。もう一度押してください」と知らせ、
        1.5 秒後に 1 回だけ送り直していたが、表示を見て押し直す
        と裏の再送と重なってキーが二重に飛び（画面検索が開いて
        すぐ閉じる）、再送が立ち上がりに間に合わないと通知だけ
        で何も起きなかった。待つのはこちら側が引き受ける。
        未導入のときに勝手にダウンロードはしない。その代わり、
        知らせたうえで内蔵版のかこって検索を開く（受け皿）。
        導入は利用者が設定や案内から自分で始めるものとする。
        """
        if getattr(self, "_assistant_running", False):
            return
        self._assistant_running = True

        def _worker() -> None:
            handed_off = False
            try:
                from . import googlelens  # noqa: PLC0415
                # 旗はこのワーカーが終わるまで持ち続ける。起動待ち
                # のあいだに押し直されても、二重に送らないため。
                status = googlelens.open_lens_when_ready(self.cfg)
                if status is googlelens.LensStatus.NOT_INSTALLED:
                    self._notify_lens_status(status)
                    # 旗は内蔵側へ渡す（内蔵側が立て直して管理する）
                    self._assistant_running = False
                    handed_off = True
                    self._open_builtin_assistant()
                    return
                if status is not googlelens.LensStatus.READY:
                    # READY（キーを送れた）なら何も知らせない。
                    # 知らせるのは、利用者の手が要るときだけ。
                    self._notify_lens_status(status)
            except Exception:
                log.exception("Google レンズ連携の実行で例外")
                # 黙って失敗しない。例外でも「呼び出せなかった」ことを
                # 利用者へ知らせる。以前はログだけで、キーを押しても
                # 何も起きないように見えた（2026-10-27 の実例: 呼び出し先
                # 関数の版ズレで 3 回とも無言で失敗）。ここでは
                # googlelens の名前に頼らず、文言キーから直接組み立てる
                # （例外が import 直後でも通知が届くように）。
                msg = t("googlelens.launch_failed")
                self._ui_jobs.put(
                    lambda msg=msg: self._notify(msg, hold=self.NOTE_INFO))
            finally:
                if not handed_off:
                    self._assistant_running = False

        threading.Thread(target=_worker, name="google-lens",
                         daemon=True).start()

    def _custom_action_down(self, inst_id: str) -> None:
        """変換レシピ・カスタム指示が選ばれた。"""
        if inst_id == "screen_assistant":
            self._screen_assistant_down()
            return

        rec_key = hotkeys.label(self.cfg.str_("hotkey", "ctrl+space"))
        if inst_id == "normal":
            self.cfg.set("active_action", "")
            self._notify(f"通常の文字入力（変換なし）に設定しました",
                         hold=self.NOTE_SHORT)
            if self.recording:
                self._stop_recording(submit=False)
            return

        action = f"custom_instruction_{inst_id}"
        # 選択した変換モードを保持（ふだんの録音キーでもこの変換で動くようにする）
        self.cfg.set("active_action", action)
        name = self._action_name(action)

        if self.recording:
            # 録音中に押された場合は停止して確定入力
            self._stop_recording(submit=False)
        else:
            self._notify(f"【{name}】モード開始（[{rec_key}] で停止・確定）",
                         hold=self.NOTE_SHORT)
            self._start_recording(action=action)

    def _on_long_press(self, held: float) -> None:
        """起動キーが長押しされた。アクションモードへ昇格する。"""
        # ショートカットの動作が「長押しの間だけ（hold）」の場合は、
        # 起動キーの長押しは通常録音（PTT）専用なので特定動作へ昇格させない。
        # 特定動作は専用アクションキーやカスタム指示キーから行う。
        if self.cfg.str_("shortcut_mode", "toggle") == "hold":
            log.debug("shortcut_mode が hold のため長押し特定動作への昇格はスキップします")
            return

        long_action = self.cfg.str_("long_press_action", "none")
        if not self.recording or long_action == "none" or self._long_press_promoted:
            return
        with self._lock:
            self._current_action = long_action
            self._long_press_promoted = True
            self._action_sessions.add(self.session)
        log.info("長押しを検知しました (%.2fs): アクション '%s' を有効化",
                 held, long_action)
        msg_key = f"overlay.action_running_{long_action}"
        label = t(msg_key)
        if label != msg_key:
            self._notify(label, hold=3.0)

    def _tray_state(self) -> None:
        if self.recording:
            self.win.set_state("recording")
        elif self.pending:
            self.win.set_state("transcribing")
        else:
            self.win.set_state("idle")

    # ------------------------------------------------------------ 操作

    def _post(self, event: str, **kw: object) -> None:
        """フックやトレイからの操作を control スレッドへ渡す。

        第 1 引数の名前は `event`。`name` にすると
        `_post("menu", name=...)` と衝突する。
        """
        self._events.put((event, kw))

    def _control_loop(self) -> None:
        while not self._stop.is_set():
            try:
                event, kw = self._events.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                if event == "hotkey_down":
                    self._long_press_promoted = False
                    self._hotkey_down()
                elif event == "hotkey_up":
                    self._hotkey_up(float(kw.get("held", 0.0) or 0.0))
                elif event == "action_down":
                    self._action_down()
                elif event == "assistant_down":
                    self._screen_assistant_down()
                elif event == "custom_action_down":
                    self._custom_action_down(str(kw.get("inst_id", "")))
                elif event == "long_press":
                    self._on_long_press(float(kw.get("held", 0.0) or 0.0))
                elif event == "stop":
                    self._stop_recording(submit=False)
                elif event == "send":
                    self._stop_recording(submit=True)
                elif event == "cancel":
                    self._cancel()
                elif event == "repaste":
                    self._repaste()
                elif event == "history_pick":
                    self._history_pick(str(kw.get("text", "")))
                elif event == "fix_down":
                    self._fix_last()
                elif event == "fix_edit":
                    self._open_fix_editor(str(kw.get("text", "")),
                                          int(kw.get("target", 0)))
                elif event == "fix_done":
                    self._apply_fix_result(
                        str(kw.get("original", "")),
                        str(kw.get("edited", "")),
                        list(kw.get("pairs", [])),
                        int(kw.get("target", 0)))
                elif event == "click_stop":
                    self._stop_for_click(outside=bool(kw.get("outside")))
                elif event == "silence":
                    # 検証用。「もう音が聞こえない」状況を作る。
                    # から打ちモードのときだけ効かせる。
                    if dryrun.enabled():
                        self._quiet_test = True
                        self._last_sound = 0.0
                        log.info("台本: 静かになったことにします")
                elif event == "focus_changed":
                    sim = bool(kw.get("simulated", dryrun.enabled()))
                    self._handle_focus_change(
                        int(kw.get("hwnd", 0)),
                        simulated=sim)
                elif event == "focus_back":
                    # 台本：一瞬だけ別の窓が出て、元の窓に戻った
                    self._sim_foreground = self.target_hwnd or 0x1001
                elif event == "focus_settled":
                    self._focus_settled(
                        int(kw.get("hwnd", 0)), int(kw.get("session", 0)),
                        simulated=bool(kw.get("simulated", False)))
                elif event == "toggle_language":
                    self._toggle_language()
                elif event == "menu":
                    self._menu(str(kw.get("name", "")))
                elif event.startswith("clip_") and self.clip is not None:
                    self._clip_event(event, kw)
            except Exception:
                log.exception("操作 '%s' の処理で例外", event)

    def _clip_event(self, event: str, kw: dict) -> None:
        """台本（試験）から、クリップボード履歴を操作する。

        から打ちモードでしか台本は動かないので、ここでも本物のキーや
        クリップボードには触れない（clipwin の側でも記録だけになる）。
        """
        clip = self.clip
        if event == "clip_capture":
            clip.simulate_capture(text=str(kw.get("text", "")),
                                  app=str(kw.get("app", "test.exe")))
        elif event == "clip_open":
            gid = kw.get("group")
            clip.open(None if gid is None else int(gid),
                      target=int(kw.get("target", 0)))
        elif event == "clip_hotkey":
            clip.press_hotkey()
        elif event == "clip_recipe_hotkey":
            clip.press_recipe_hotkey()
        elif event == "clip_key":
            clip.key(int(kw.get("vk", 0)), ctrl=bool(kw.get("ctrl")),
                     shift=bool(kw.get("shift")))
        elif event == "clip_type":
            clip.type_text(str(kw.get("text", "")))
        elif event == "clip_snapshot":
            clip.snapshot(Path(str(kw.get("path", LOG_DIR / "clip.png"))))

    def _toggle_language(self) -> None:
        """認識言語を 日本語 → 英語 → 自動 で順に切り替える。"""
        cur = self.cfg.str_("language", "ja")
        cycle = {"ja": "en", "en": "auto", "auto": "ja"}
        nxt = cycle.get(cur, "ja")
        self.cfg.set("language", nxt)
        label = {"ja": "日本語", "en": "英語", "auto": "自動"}.get(nxt, nxt)
        self._notify(t("overlay.lang_changed", val=label),
                     hold=self.NOTE_INFO)

    def _toggle(self) -> None:
        if self.recording:
            self._stop_recording(submit=False)
        else:
            self._start_recording()

    def _play_sound(self, name: str) -> None:
        """効果音を鳴らす（設定でオフなら何もしない）。"""
        if not self.cfg.bool_("sound_feedback"):
            return
        theme = self.cfg.str_("sound_theme", "default")
        volume = self.cfg.int_("sound_volume", 80)
        sysaudio.play(name, theme=theme, volume=volume)

    def _apply_audio_ducking(self) -> None:
        """録音中のPC音声（消音または音量低下）を適用する。"""
        mode = self.cfg.str_("audio_ducking", "off")
        # ★ mode が "off"（そのまま）なら、消音も音量低下も一切しない。
        # 以前は古い設定 mute_while_recording が残っていると mode が off でも
        # 強制的に mute になり、音楽が止まってしまっていた（2026-10-11 改修）。
        if mode == "off":
            return
        if mode == "mute":
            sysaudio.speaker.mute()
        elif mode == "duck":
            pct = self.cfg.int_("duck_ratio_pct", 25)
            sysaudio.speaker.duck(max(0.05, min(0.5, pct / 100.0)))

    def _restore_audio(self) -> None:
        """録音終了時に消音や音量低下を元に戻す。"""
        sysaudio.speaker.restore()

    def _start_recording(self, *, action: str = "") -> None:
        # メインキー経由の印はここで消費する（開始に失敗しても残さない）。
        via_main_key, self._start_via_main_key = (
            self._start_via_main_key, False)
        # 止める途中のまま居残っていたら、待たずに待機へ戻してから始める。
        # 「何回押しても始まらない」を作らないため。
        if self.stopping:
            waited = time.monotonic() - self._stop_began
            if waited >= 0.8:
                self._force_idle("停止の途中で開始を押された")
        with self._lock:
            if self.recording:
                return
            # ふだんの録音は、いつも変換なしの文字起こしにする。
            # 以前は「AI自動編集」がオンだと、ふだんの録音まで変換の流れに
            # 取られ、話しながら入力する動きが止まっていた。つなぎ言葉の
            # 削除は文字起こし側（remove_fillers）で常に効く。変換は、
            # 文章変換の専用キーを押したときだけ動く。
            if self.engine is None:
                self._notify(t("overlay.no_model"), hold=self.NOTE_WARN)
                self._ui_jobs.put(lambda: self._menu("settings"))
                return
            # 自動格下げは「その発話限り」。前回逃げていたら、
            # 始める前に設定のモデルへ戻す。
            self._restore_auto_downgrade()
            self.session += 1
            if not action:
                # 選択中の変換モードがあればそれを自動適用
                action = self.cfg.str_("active_action", "")
            self.target_hwnd = inject.foreground()
            self.target_focus_hwnd = inject.get_focus_control(self.target_hwnd)
            if not self.target_hwnd and dryrun.enabled():
                self.target_hwnd = 0x1001
                self.target_focus_hwnd = 0x2001
            # アプリ連動プロファイル（開いているアプリに合わせて自動で性格を切替）
            if not action and self.cfg.bool_("app_profiles_enabled", False):
                try:
                    from . import clipdata  # noqa: PLC0415
                    exe = clipdata.exe_of_window(self.target_hwnd).lower()
                    profiles = self.cfg.dict_("app_profiles", {})
                    for pat, act in profiles.items():
                        if pat.lower() in exe:
                            action = act
                            log.info("アプリ連動プロファイル適用: %s -> %s",
                                     exe, action)
                            break
                except Exception:
                    log.debug("アプリ連動プロファイル判定で例外", exc_info=True)
            self._current_action = action
            self._action_pcm = bytearray()
            if action:
                self._action_sessions.add(self.session)
            # モニターが複数あるとき、入力しているウィンドウと
            # 同じ画面に帯を出す（別の画面だと気づけない）
            self.overlay.set_target(self.target_hwnd)
            rec_key = hotkeys.label(self.cfg.str_("hotkey", "ctrl+space"))
            if action:
                act_name = self._action_name(action)
                hint_str = f"【{act_name}】 [{rec_key}] で停止して確定・入力"
            else:
                hint_str = f"[{rec_key}] で停止して確定・入力"
            self.overlay.hint_text = hint_str
            self.recorder.preroll_ms = self.cfg.int_("mic_preroll_ms", 1000)
            try:
                self.recorder.start()
            except Exception:
                log.exception("録音を開始できません")
                self._notify(t("overlay.mic_error"), hold=self.NOTE_WARN)
                return
            self.recording = True
            self.started_at = time.monotonic()
            if via_main_key and not action:
                # 二度押し判定の起点。アクション録音は対象にしない。
                self._dtap.note_start(self.started_at)
            self._last_sound = self.started_at
            self._quiet_test = False
            self._window_warned = 0.0
        self.win.sync_hotkeys()   # 録音中だけ Enter / Esc を登録する
        # 録音中だけマウスを見る。クリックは受け止めず、見るだけ。
        # 同じウィンドウの中（チャットの送信ボタンなど）を押したことは、
        # 画面の見張りでは分からないので、ここで見る必要がある。
        if self.cfg.str_("stop_on_click", "outside") != "off":
            self.mouse.arm(
                interval=max(5, self.cfg.int_("click_poll_ms", 15)) / 1000.0)
        if self.cfg.bool_("polite_priority", True):
            priority.busy()
        self._apply_audio_ducking()
        self._play_sound("start")
        self._tray_state()
        log.info("録音開始 session=%d mode=%s action=%s", self.session,
                 self._mode(), action or "none")
        if action:
            if action == "ai_auto_edit":
                self._notify(t("overlay.action_running_ai_auto_edit"), hold=3.0)
            elif action.startswith("custom_instruction_"):
                inst_id = action.removeprefix("custom_instruction_")
                inst_name = inst_id
                for item in self.cfg.get("ai_custom_instructions") or []:
                    if item.get("id") == inst_id:
                        inst_name = item.get("name") or inst_id
                        break
                self._notify(f"{inst_name}（録音中）", hold=3.0)
            else:
                msg_key = f"overlay.action_running_{action}"
                label = t(msg_key)
                if label != msg_key:
                    self._notify(label, hold=3.0)
        elif self._previews():
            with self._agree_lock:
                self.utterance += 1
                self.agreement.rounds = max(
                    2, self.cfg.int_("stream_agree_rounds", 3))
                self.agreement.min_span = max(
                    0.0, self.cfg.int_("stream_agree_span_ms", 800) / 1000.0)
                self.agreement.reset()
            self.stream_thread = threading.Thread(
                target=self._stream_loop, args=(self.session,),
                name="stream", daemon=True)
            self.stream_thread.start()

    def _stop_recording(self, *, submit: bool) -> None:
        with self._lock:
            if not self.recording:
                if submit:
                    inject.send_submit(self.cfg.str_("send_key", "enter"))
                return
            self.recording = False
            self.stopping = True
            self._stop_began = time.monotonic()
            self._stop_asked = False
            session = self.session
            action = self._current_action
            pcm_bytes = bytes(self._action_pcm)
            self._current_action = ""
            self._long_press_promoted = False
        self.mouse.disarm()
        self._dtap.clear()
        try:
            self.win.sync_hotkeys()   # Enter / Esc の登録を外す
            tail = max(0, self.cfg.int_("post_roll_ms", 400)) / 1000.0
            if tail:
                # 止めたあとも少し録り続ける。最後のひと言が切れるのを防ぐ。
                # ★録り残しのあいだは _tail_capture を立てて _on_audio に
                # 受けさせる。recording は既に False なので、旗が無いと
                # 音はカッターへ届かず、最後の 0.4 秒が消える。
                self._tail_capture = True
                time.sleep(tail)
            try:
                self.recorder.stop()
            except Exception:
                log.exception("録音の停止で例外")
            finally:
                self._tail_capture = False
            if action:
                # 録り残しぶんも含めて取り直す（開始時の控えは古い）。
                with self._lock:
                    pcm_bytes = bytes(self._action_pcm)
            self._restore_audio()
            self._play_sound("stop")
            self._join_stream()
            if action:
                # アクションモードの場合、録音音声全体を一括処理する
                self._work.put((ACTION, (action, pcm_bytes), session))
                self.pending += 1
            else:
                # ★flush の前に、いまの発話の音を控えておく。
                # flush のあとではカッターの中身は空になるため、
                # 「flush が区間を返さなかった」ときに音から聞き直す
                # 材料はここでしか取れない（_finalize_tail 参照）。
                tail_pcm = self.cutter.buffered()
                flushed = self.cutter.flush()
                # 0.15秒未満の極端に短いPCM（キータッチ音や微小ノイズ）は
                # Whisper に渡すとハルシネーション（誤認識文字）の原因になるため除外
                valid_flushed = [
                    p for p in flushed
                    if len(p) >= int(SAMPLE_RATE * 2 * 0.15)
                ]
                if valid_flushed:
                    for pcm in valid_flushed:
                        self._enqueue(pcm, session, final=True)
                elif self._finalize_tail(session, tail_pcm):
                    # 残りの音を実デコードへ回した。末尾は音から確定する。
                    pass
                else:
                    # 音からも確定できない場合の最終保険として、
                    # 話しながらモードでまだ入力欄に送られていない最新テキスト
                    # （pending）があれば、校正・辞書置換・文末整形を施して
                    # 入力キューへ投入する（Enter送信前の取りこぼし・文字乱れ防止）
                    with self._agree_lock:
                        pending_text = self.agreement.pending()
                        group = self.utterance
                        self.agreement.reset()
                    if pending_text and self._types_while_speaking():
                        cleaned = self._clean(pending_text, final=True)
                        if cleaned:
                            log.info(
                                "停止時の未確定文字（pending）を校正して入力します: "
                                "%r -> %r", pending_text, cleaned
                            )
                            self._work.put((TEXT, (cleaned, group), session))
                            self.pending += 1
            if submit:
                self._work.put((SUBMIT, None, session))
                self.pending += 1
            # 音声入力終了時に元の入力欄へフォーカスを自動復帰
            if (self.target_hwnd
                    and self.cfg.bool_("restore_focus_on_finish", True)):
                focus = getattr(self, "target_focus_hwnd", 0)
                inject.activate_window(self.target_hwnd, focus)
        finally:
            # ★必ず待機へ戻す。途中で例外が出ても居残らせない。
            with self._lock:
                self.stopping = False
            try:
                self.win.sync_hotkeys()
            except Exception:
                log.exception("ショートカットの付け直しで例外")
        self._tray_state()
        log.info("録音停止 session=%d 送信=%s", session, submit)

    def _finalize_tail(self, session: int, tail_pcm: bytes) -> bool:
        """停止時、区間として出なかった残りの音を実デコードへ回す。

        ★以前はこの場合（直前に間の区切りで出てしまった／残りが
        短くて flush に捨てられた等）、最後の部分仮説の未確定分を
        整形しただけで入力していた。部分仮説は安定しておらず、
        末尾が崩れたり丸ごと落ちたりする（利用者の「後半が崩れる」
        「言ったはずの文が入っていない」の一因）。

        音が残っているなら必ず音から聞き直す。入力済みとの重なりは
        _handle_audio が remainder で落とすので、二重にはならない。
        戻り値は「音に回したか」。回せなかった場合だけ、呼び出し側が
        部分仮説の保険に落ちる。
        """
        if len(tail_pcm) < int(SAMPLE_RATE * 2 * 0.15):
            return False
        log.info("停止時の残り %.2f 秒を音から確定します",
                 len(tail_pcm) / (SAMPLE_RATE * 2))
        self._enqueue(tail_pcm, session, final=True)
        return True

    def _cancel(self, *, keep_text: bool = False) -> None:
        """録音をやめる。keep_text=True なら、入力済みの文字は残す。

        入力先が変わったときは、まだ入力していない分だけを捨てる
        （すでに入れた文字は、そもそも書き換えられない）。
        """
        with self._lock:
            session = self.session
            was = self.recording
            self.recording = False
            self.cancelled.add(session)
            self._current_action = ""
            if self.cfg.str_("active_action", ""):
                self.cfg.set("active_action", "")
            self._long_press_promoted = False
            self._action_pcm.clear()
            self._stop_asked = False
        self.mouse.disarm()
        self._last_insert_hwnd = 0
        self._last_insert_tail = ""
        self._last_insert_group = -1
        if not was and not self.stopping and not self.pending:
            # 何も走っていないのに Esc が来た。帯だけ残っている時の
            # 逃げ道にする（押せば必ず待機の見た目に戻る）。
            self._force_idle("待機中に Esc")
            return
        self.win.sync_hotkeys()
        if was:
            try:
                self.recorder.stop()
            except Exception:
                log.exception("録音の停止で例外")
        self._restore_audio()
        if was:
            self._play_sound("cancel")
        self._join_stream()
        with self._agree_lock:
            self.utterance += 1
            typed_already = bool(self.agreement.committed)
            self.agreement.reset()
        # 中止した音も捨てない。文字にして履歴にだけ残す（入力はしない）。
        keep = self.cutter.drain() if was else b""
        self.cutter.reset()
        dropped = 0
        while True:
            try:
                self._work.get_nowait()
            except queue.Empty:
                break
            dropped += 1
            self.pending = max(0, self.pending - 1)
        if keep and len(keep) > SAMPLE_RATE:   # 0.5 秒以上あれば
            self._work.put((KEEP, keep, -1))
            self.pending += 1
        self._tray_state()
        if not keep_text:
            # 話しながらモードで、すでに文字が入っていたなら正直に伝える。
            # 入れた文字は書き換えない決まりなので、中止でも消せない。
            self._notify(t("overlay.cancelled_partial") if typed_already
                         else t("overlay.cancelled"), hold=self.NOTE_SHORT)
        log.info("中止 session=%d 破棄=%d件 履歴へ回す=%.2fs",
                 session, dropped, len(keep) / (SAMPLE_RATE * 2))

    @guard
    def _discard_take_and_pick_history(self) -> None:
        """二度押し。今のテイクを捨てて、履歴ピッカーを開く。

        中止（_cancel）と違い、**履歴にも残さない**。始めたばかりの
        テイクは「入れ直しのための合図」であって、記録ではない。
        破棄の作法（セッション無効化・キューの掃除・帯を待機へ）は
        中止と同じにして、走行中の仕事と競合しないようにする。
        """
        target = self.target_hwnd
        with self._lock:
            session = self.session
            was = self.recording
            self.recording = False
            self.cancelled.add(session)
            self._current_action = ""
            self._long_press_promoted = False
            self._action_pcm.clear()
            self._stop_asked = False
        self.mouse.disarm()
        self.win.sync_hotkeys()
        if was:
            try:
                self.recorder.stop()
            except Exception:
                log.exception("録音の停止で例外")
        self._restore_audio()
        self._join_stream()
        with self._agree_lock:
            self.utterance += 1
            self.agreement.reset()
        self.cutter.reset()
        dropped = 0
        while True:
            try:
                self._work.get_nowait()
            except queue.Empty:
                break
            dropped += 1
            self.pending = max(0, self.pending - 1)
        self._dtap.clear()
        self._tray_state()
        log.info("二度押し: テイクを破棄しました session=%d 破棄=%d件",
                 session, dropped)
        self._open_history_picker(target)

    def _open_history_picker(self, target: int) -> None:
        """最近の文字起こしをピッカーで出し、選ばれたら貼る。

        F2 を押された項目は貼らずに「直す」へ渡す（編集ポップ
        アップを開く）。タイトルに、その案内を添える。
        """
        rows = [r for r in self.history.recent(10)
                if not r.get("cancelled")]
        entries = [(str(r.get("text", "")), float(r.get("ts", 0.0)))
                   for r in rows if str(r.get("text", "")).strip()]
        if not entries:
            self._notify(t("history.empty"), hold=self.NOTE_INFO)
            return
        self._picker_target = target
        title = t("historypick.title")
        if self.cfg.bool_("learn_fixes", True):
            title += t("historypick.edit_hint")

        def _run() -> None:
            try:
                got = histpick.open_picker2(entries, title)
            except Exception:
                log.exception("履歴ピッカーで例外")
                return
            if not got:
                return
            action, picked = got
            if action == "edit":
                self._post("fix_edit", text=picked, target=target)
            elif picked:
                self._post("history_pick", text=picked)

        threading.Thread(target=_run, name="history-picker",
                         daemon=True).start()

    @guard
    def _history_pick(self, text: str) -> None:
        """ピッカーで選ばれた文字を、コピーしてその場へ貼る。

        貼り付けは既存の _type に任せ、paste_method の設定を尊重する。
        貼り付けの過程でクリップボードが元へ戻されても、選んだ文字は
        最後に残す（「コピーして貼る」が両方とも成り立つように）。
        """
        if not text:
            return
        target = self._picker_target or self.target_hwnd
        inject.set_clipboard_text(text, keep_out_of_history=False)
        self._type(text, -1, target=target)
        inject.set_clipboard_text(text, keep_out_of_history=False)
        self.last_text = text
        log.info("履歴から貼りました: %s", text[:80])

    # ------------------------------------------------------------ 直す

    # 編集には分かかるので、音声コマンドの取り消し（20 秒）より
    # 長く見る。ただし書き換えは「直前の挿入そのもの」「未送信」
    # 「同じ窓」の 3 条件がそろったときだけ（_replace_last_typed）。
    _FIX_REPLACE_WINDOW = 600.0

    @guard
    def _fix_last(self) -> None:
        """「直前の挿入を直す」キー。最後に入れた文を編集へ渡す。"""
        text = self.last_text
        if not text:
            rows = self.history.recent(1)
            text = str(rows[0].get("text", "")) if rows else ""
        if not text:
            self._notify(t("fix.nothing"), hold=self.NOTE_INFO)
            return
        self._open_fix_editor(text, self.target_hwnd)

    def _open_fix_editor(self, original: str, target: int) -> None:
        """編集ポップアップ（app/fixwin.py）を専用スレッドで開く。"""
        if self.learn_store is None or self.homo_prefs is None:
            self._notify(t("fix.nothing"), hold=self.NOTE_INFO)
            return
        store, prefs = self.learn_store, self.homo_prefs
        enabled = self.cfg.bool_("learn_fixes", True)

        def _run() -> None:
            try:
                result = fixwin.open_editor(
                    original, t("fixwin.title"), store=store,
                    prefs=prefs, learn_enabled=enabled)
            except Exception:
                log.exception("直し窓で例外")
                return
            if result is not None:
                self._post("fix_done", original=original,
                           edited=result.text, pairs=result.pairs,
                           target=target)

        threading.Thread(target=_run, name="fix-editor",
                         daemon=True).start()

    @guard
    def _apply_fix_result(self, original: str, edited: str,
                          pairs: list, target: int) -> None:
        """編集の成果を受ける: 採用ペアを保存し、直した文を戻す。

        戻し方は 2 経路（その場で書き換え／クリップボード＋貼り
        直し）で、どちらになったか通知の文言で分かるようにする。
        """
        learned = 0
        if pairs and self.learn_store is not None \
                and self.cfg.bool_("learn_fixes", True):
            learned = self.learn_store.add_pairs(
                [(str(s), str(d)) for s, d in pairs])
        suffix = t("fix.learned_suffix", n=learned) if learned else ""
        if edited == original:
            if learned:
                self._notify(t("fix.learned_only", n=learned),
                             hold=self.NOTE_INFO)
            else:
                self._notify(t("fix.no_change"), hold=self.NOTE_INFO)
            return
        if self._replace_last_typed(original, edited, target):
            self._notify(t("fix.replaced") + suffix,
                         hold=self.NOTE_INFO)
            return
        # その場で書き換えられないので、履歴ピッカーと同じ作法で
        # クリップボードに入れてカーソルの位置へ貼る。元の文は
        # 残るので、その旨を知らせる（消すのは利用者の判断）。
        inject.set_clipboard_text(edited, keep_out_of_history=False)
        self._type(edited, -1, target=target or None)
        inject.set_clipboard_text(edited, keep_out_of_history=False)
        self.last_text = edited
        self._notify(t("fix.pasted") + suffix, hold=self.NOTE_WARN)
        log.info("直した文を貼り直しました: %s", edited[:80])

    def _replace_last_typed(self, original: str, edited: str,
                            target: int) -> bool:
        """直前の挿入がそのまま残っていれば、その場で書き換える。

        条件（_undo_last_type と同じ考え方。時間だけ編集向け）:
          ・このアプリが最後に入れた文が、直す対象と一致する
          ・送信（Enter）されていない
          ・前面の窓が、その文を入れた窓のまま
          ・入れてから _FIX_REPLACE_WINDOW 秒以内
        書き換えは「元の文字数ぶん Backspace → 新しい文を入れる」。
        """
        if not original or self._last_typed_text != original:
            return False
        if self._last_typed_submitted:
            return False
        if time.monotonic() - self._last_typed_at \
                > self._FIX_REPLACE_WINDOW:
            return False
        hwnd = self._last_typed_hwnd
        now = inject.foreground()
        if hwnd and now and now != hwnd:
            return False
        if not inject.send_backspaces(len(original), target_hwnd=hwnd):
            return False
        self._last_typed_text = ""
        ok = self._type(edited, -1, target=hwnd or target or None)
        if ok:
            log.info("直した文をその場で書き換えました: %s",
                     edited[:80])
        return ok

    @guard
    def _menu(self, name: str) -> None:
        if name == "settings":
            self._ui_jobs.put(lambda: self.open_settings())
        elif name == "dictionary":
            self._ui_jobs.put(lambda: self.open_settings("dictionary"))
        elif name == "history":
            self._ui_jobs.put(lambda: self.open_settings("history"))
        elif name == "repaste":
            self._post("repaste")
        elif name == "copy_last":
            self._copy_last()
        elif name == "clip_open" and self.clip is not None:
            self.clip.open(target=self._last_foreground)
        elif name == "recipe_open" and self.clip is not None:
            self.clip.show_recipes(target=self._last_foreground)
        elif name == "clip_pause" and self.clip is not None:
            paused = self.clip.toggle_pause()
            self._notify(t("clip.paused" if paused else "clip.resumed"),
                         hold=self.NOTE_INFO)
        elif name.startswith("punct:"):
            density = name.split(":", 1)[1]
            self.cfg.set("punctuation_density", density)
            label = {"few": "少なめ", "normal": "標準",
                     "many": "多め"}.get(density, density)
            self._notify(t("overlay.punct_changed", val=label),
                         hold=self.NOTE_INFO)
        elif name.startswith("lang:"):
            lang = name.split(":", 1)[1]
            if lang in ("ja", "en", "auto"):
                self.cfg.set("language", lang)
                label = {"ja": "日本語", "en": "英語",
                         "auto": "自動"}.get(lang, lang)
                self._notify(t("overlay.lang_changed", val=label),
                             hold=self.NOTE_INFO)
        elif name == "voice_commands":
            on = not self.cfg.bool_("voice_commands", True)
            self.cfg.set("voice_commands", on)
            self._notify(t("overlay.commands_on" if on else "overlay.commands_off"),
                         hold=self.NOTE_INFO)
        elif name.startswith("model:"):
            m_key = name.split(":", 1)[1]
            if m_key in catalog.MODELS:
                self.cfg.set("model", m_key)
                m_name = catalog.model(m_key).name
                self._notify(t("overlay.model_changed", name=m_name),
                             hold=self.NOTE_INFO)
        elif name == "slow":
            self.health.mark("利用者が「いま重かった」を押した")
            self._notify(t("overlay.slow_marked"), hold=self.NOTE_INFO)
        elif name == "overlay_text":
            # トレイから 1 回で切り替える（設定の窓を開かずに済むように）
            on = not self.cfg.bool_("overlay_text", True)
            self.cfg.set("overlay_text", on)
            self._notify(t("overlay.text_on" if on else "overlay.text_off"),
                         hold=self.NOTE_INFO)
        elif name == "pause":
            # 録音のショートカットを一時的に手放す。ショートカットが
            # ほかのアプリの操作（Ctrl+O の「開く」など）とぶつかるとき、
            # ゲームの最中などに使う。覚えておかない（起動し直すと戻る）。
            paused = not self.win.paused
            self.win.set_paused(paused)
            self._tray_state()
            log.info("一時停止: %s", "した" if paused else "やめた")
            self._notify(t("overlay.paused" if paused else "overlay.resumed"),
                         hold=self.NOTE_INFO)
        elif name == "log":
            _open(LOG_DIR / "koe-type.log")
        elif name == "restart":
            autostart.relaunch()
            self.root.after(0, self.root.quit)
        elif name == "quit":
            self.root.after(0, self.root.quit)

    # ------------------------------------------------------------ 設定画面

    @guard
    def open_settings(self, category: str | None = None) -> None:
        """設定画面（HTML）を Edge のアプリモードで開く。"""
        if self.settings is None:
            self.settings = SettingsServer(
                Bridge(self.cfg, self.dictionary, self.history,
                       self._settings_action))
        self.settings.open_window(category or "")

    @guard
    def _settings_action(self, name: str, **kw):  # noqa: ANN201
        if name == "settings_closed":
            self.settings = None
        elif name in ("model_changed", "model_downloaded"):
            self._build_engine()
            if self.engine is not None and self.cfg.bool_("warmup", True):
                threading.Thread(target=self._warmup, name="warmup",
                                 daemon=True).start()
        elif name == "config_reset":
            self._apply_hotkeys()
            self._build_engine()
            self.cutter = self._build_cutter()
            self._ui_jobs.put(self._refresh_overlay)
        elif name == "dictionary_changed":
            self.dictionary.reload(force=True)
        elif name == "open_log":
            _open(LOG_DIR / "koe-type.log")
        elif name == "open_folder":
            _open(ROOT)
        elif name == "copy":
            inject.set_clipboard_text(str(kw.get("text", "")))
        elif name == "paste_text":
            text = str(kw.get("text", ""))
            if text:
                self.target_hwnd = 0
                self.last_text = text
                self._type(text, -1)
        elif name == "running_apps":
            return list_windows()
        elif name == "mic_level":
            return float(self.cutter.level if self.recording
                         else self._idle_level)
        elif name == "mic_error":
            return "" if self.recorder.listening else "マイクを開けません"
        elif name == "is_recording":
            return bool(self.recording)
        elif name == "test_overlay":
            def _demo() -> None:
                self._ui_jobs.put(self._refresh_overlay)
                time.sleep(0.1)
                self.overlay.set_state("recording")
                self.overlay.set_pending("こんにちは、koe-type で音声入力中です")
                self.overlay.set_level(0.75)
                time.sleep(2.2)
                self.overlay.set_state("done")
                time.sleep(0.5)
                self.overlay.set_state("idle")
            threading.Thread(target=_demo, name="test_overlay",
                             daemon=True).start()
            return {"ok": True}
        elif name == "open_onboarding":
            self._ui_jobs.put(lambda: self.open_settings("onboarding"))
        elif name == "clip_api":
            if self.clip is None:
                return {"ok": False, "error": "unavailable"}
            return self.clip.api(str(kw.get("api", "")),
                                 dict(kw.get("payload") or {}))
        elif name == "clip_image":
            if self.clip is None:
                return b""
            return self.clip.image_bytes(int(kw.get("id", 0) or 0))
        return None

    # ------------------------------------------------------------ 話しながら

    def _mode(self) -> str:
        return self.cfg.str_("input_mode", "stream")

    def _types_while_speaking(self) -> bool:
        """話している最中に、入力欄へ文字を入れるモードか。"""
        if self._current_action:
            return False
        return self._mode() == "stream"

    def _previews(self) -> bool:
        """帯に先出しするために、話しながら聞き直すモードか。

        "preview" は**帯にだけ**出す。入力欄へは、ひと区切りが
        終わってからまとめて入れる。こうすると

          ・言いよどんだ途中の言葉が入力欄に残らない
          ・前後の言葉がそろってから漢字が選ばれる
          ・入力済みとの重なりを数える必要がなく、二重入力が起きない

        という良いところがあり、待ち時間は「区切りの間」のぶんだけ。
        """
        return self._mode() in ("stream", "preview")

    # 停止のときに待ってよい時間の内訳（合計が stop_timeout_ms を超えないこと）
    #   録り残し post_roll_ms   0.4 秒
    #   聞き直しのスレッド合流  JOIN_STREAM 秒
    #   マイクの停止・区間の掃き出し  ごくわずか
    # 以前ここが 3.0 秒で、録り残しと足すと 3.4 秒。
    # 見張り（3.0 秒）のほうが先に鳴って「停止が終わらない」と誤判定した。
    JOIN_STREAM = 1.2

    def _join_stream(self) -> None:
        thread, self.stream_thread = self.stream_thread, None
        if thread is not None and thread is not threading.current_thread():
            thread.join(timeout=self.JOIN_STREAM)

    def _stream_loop(self, session: int) -> None:
        """録音中、いまの発話を先頭からくり返し文字起こしする。

        連続する 2 回で一致した先頭だけを入力欄へ送る（LocalAgreement）。

        **何本か重ねて走らせる。** 1 回の文字起こしには 0.6 秒ほどの
        固定費（プロセス起動とモデル読み込み）があり、順番に待つと
        候補が 1 秒に 1 回しか出ない。それでは 2 回一致するまでに
        2 秒以上かかってしまう。重ねれば 1 件あたり 0.5 秒ほどで出るので、
        最初の文字が 1.5 秒以内に入る。

        結果は頼んだ順に返ってこないので、**音の長さで順番を守る**。
        自分より長い音の結果がすでに届いていたら、その回は捨てる
        （短い音の結果で上書きすると、入力した文字が巻き戻ってしまう）。
        """
        min_bytes = SAMPLE_RATE * 2 * 35 // 100        # 0.35 秒ぶんは溜める
        interval = self.cfg.int_("stream_interval_ms", 600) / 1000.0
        workers = max(1, min(4, self.cfg.int_("stream_workers", 2)))
        slots = threading.Semaphore(workers)
        # 古さ判定は区間ごと（RoundGate）。録音全体で持ち続けると、
        # 区切りのあとの区間が全部「古い」と捨てられ、後半ほど
        # 部分仮説が更新されなくなる（streaming.RoundGate の説明）。
        gate = RoundGate()
        state = {"rounds": 0}
        state_lock = threading.Lock()
        threads: list[threading.Thread] = []

        def one_round(pcm: bytes, generation: int, index: int) -> None:
            try:
                started = time.perf_counter()
                text = self._transcribe(pcm)
                took = time.perf_counter() - started
                self._watch_speed(took, len(pcm) / (SAMPLE_RATE * 2))
                with self._lock:
                    if session in self.cancelled:
                        return
                with state_lock:
                    if not gate.accept(generation, len(pcm)):
                        log.debug("%d 回目は古いので捨てます (%d バイト)",
                                  index, len(pcm))
                        return
                with self._agree_lock:
                    if generation != self.utterance:
                        # 聞いている間に区間が確定した。この回の結果は捨てる
                        # （入れると、確定した文より後ろに入ってしまう）
                        log.debug("区間が変わったので %d 回目は捨てます", index)
                        return
                    fresh = self.agreement.update(
                        text, len(pcm) / (SAMPLE_RATE * 2))
                    group = self.utterance
                if fresh and self._types_while_speaking():
                    log.info("話しながら確定 %r (%.2fs / %d回目 / %.1f秒ぶん)",
                             fresh, took, index,
                             len(pcm) / (SAMPLE_RATE * 2))
                    self._work.put((TEXT, (fresh, group), session))
                    self.pending += 1
            except Exception:
                log.exception("話しながらの文字起こしで例外")
            finally:
                slots.release()

        while self._stream_alive(session):
            if self.engine is None:
                break
            with self._agree_lock:
                generation = self.utterance
            gate.sync_generation(generation)
            pcm = self.cutter.buffered()
            # 前回と同じ長さなら、聞き直しても結果は変わらない
            if not gate.should_spawn(len(pcm), min_bytes):
                time.sleep(0.06)
                continue
            if not slots.acquire(blocking=False):
                time.sleep(0.04)        # みんな働いている。空くまで待つ
                continue
            gate.note_spawn(len(pcm))
            state["rounds"] += 1
            thread = threading.Thread(
                target=one_round, args=(pcm, generation, state["rounds"]),
                name=f"stream-{state['rounds']}", daemon=True)
            if len(threads) > 16:
                threads = [t for t in threads if t.is_alive()]
            threads.append(thread)
            thread.start()
            # 次の回まで少し待つ。重ねる本数で割って、間隔をつめる。
            time.sleep(max(0.05, interval / workers))

        # 後片づけ。**全部で 1 秒まで**にする。
        # 1 本ずつ 2 秒待つと、最悪 16 秒かかって停止が終わらなくなる
        # （実際に長時間テストで「停止が終わらない」と出た）。
        deadline = time.monotonic() + 1.0
        for thread in threads[-8:]:
            left = deadline - time.monotonic()
            if left <= 0:
                break
            thread.join(timeout=left)

    def _stream_alive(self, session: int) -> bool:
        return (self.recording and session == self.session
                and session not in self.cancelled and not self._stop.is_set())

    def _transcribe(self, pcm: bytes, *, final: bool = False) -> str:
        """PCM を 1 回だけ文字起こしして、整形まで済ませた文字を返す。

        常駐方式なら PCM をそのまま渡せるので、一時 WAV を書かない。
        外部プロセス方式のときだけ、エンジン側で WAV を経由する。
        """
        engine = self.engine
        if engine is None:
            return ""
        started = time.perf_counter()
        try:
            raw = engine.transcribe_pcm(pcm, self._hints())
            self.health.last_transcribe = time.perf_counter() - started
            # 成功したら失敗の数え直し。「続けて失敗」だけを受け皿への
            # 切替条件にするため（累積だと散発的な瞬断でも発動する。
            # 2026-10-31 監査 H1）。
            self._state().note_success()
        except Exception as exc:  # noqa: BLE001
            log.warning("文字起こしに失敗: %s", exc)
            self._engine_trouble(exc)
            return ""
        return self._clean(raw, final=final)

    def _engine_trouble(self, exc: Exception) -> None:
        """エンジンが続けて失敗したら、受け皿のモデルへ切り替える。

        数えるのは「連続」した失敗だけ（成功で数え直す。enginestate
        の note_failure）。以前は累積カウンタで、散発的な瞬断でも
        数日で発動し、しかも通知も復帰経路も無く弱いモデルに
        固定された（2026-10-31 監査 H1）。切替時の通知は
        _switch_engine 側、復帰は _restore_auto_downgrade が持つ。
        """
        if not self._state().note_failure():
            return
        current = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        if current == catalog.FALLBACK_MODEL:
            return
        log.error("エンジンが続けて失敗したので %s に切り替えます (%s)",
                  catalog.FALLBACK_MODEL, exc)
        self._switch_engine(catalog.FALLBACK_MODEL, reason="trouble")

    # ------------------------------------------------------------ 音声

    def _on_audio(self, data: bytes) -> None:
        if not self.recording and not self._tail_capture:
            # 録音していなくても、**設定の窓が開いている間だけ**は
            # 声の大きさを測る。初回の案内の「声が届いているか」で使う。
            # 開いていないときは何もしない（むだに CPU を使わない）。
            # ★_tail_capture のあいだは録音扱いで受ける。停止処理が
            # recording=False にしてから録り残し（post_roll）を待つので、
            # ここで弾くと最後のひと言がカッターに届かず消える。
            if self.settings is not None:
                self._idle_level = _level_of(data)
            return
        session = self.session
        self._action_pcm.extend(data)
        if not self._current_action:
            for pcm in self.cutter.feed(data):
                self._enqueue(pcm, session)

    def _on_idle_audio(self, data: bytes) -> None:
        """録音していないあいだの音。設定の窓が開いているときだけ測る。

        初回の案内の「声が届いているか」の線に使う。窓が閉じていれば
        何もしない（むだに CPU を使わない）。
        """
        if self.settings is not None:
            self._idle_level = _level_of(data)

    def _enqueue(self, pcm: bytes, session: int, *,
                 final: bool = False) -> None:
        """区間が確定した。ここが話しながらモードの区切りにもなる。

        final は「録音を止めたときの、最後の区間」という印。
        「。」を最後だけ付ける設定のために渡す。
        """
        secs = len(pcm) / (SAMPLE_RATE * 2)
        with self._agree_lock:
            # ★区切りの番号は、**進める前の**値を使う。話しながら入れた
            # 文字（TEXT）はこの値で入っているので、残りも同じ番号に
            # しないと「別の区切り」と見なされ、あいだに空白が入る。
            # 実際に「おはようござい ます」と言葉の途中が割れた。
            group = self.utterance
            self.utterance += 1
            # 途中でいちばんよく聞こえた結果（または最新結果）を保険として一緒に渡す
            heard = self.agreement.latest or self.agreement.take_best()
            if self._types_while_speaking():
                typed = self.agreement.take()
            else:
                # 帯に出しただけ。入力欄には何も入れていないので、
                # 区間まるごとを入れる（重なりを数える必要がない）。
                self.agreement.reset()
                typed = ""
        log.info("区間を確定 %.2fs session=%d 入力済み %d 文字",
                 secs, session, len(typed))
        self._work.put((AUDIO, (pcm, typed, heard, final, group), session))
        self.pending += 1
        self._tray_state()

    # ------------------------------------------------------------ 文字起こし

    def _hints(self, engine=None) -> str:  # noqa: ANN001, ANN202
        """語彙ヒント。engine を渡すと、そのエンジン向けに作る。

        最終デコード用の品質エンジンは今のエンジンと別物なので、
        「ヒントを受け付けるか」は渡されたエンジンの仕様で見る。
        SenseVoice はヒントを無視する仕様（catalog の
        supports_hints=False）なので、効くのは Whisper 側だけ。
        """
        target = engine if engine is not None else self.engine
        if not self.cfg.bool_("dictionary_as_hints", True):
            return ""
        if target is None or not target.spec.supports_hints:
            return ""
        user_hints = self.dictionary.hint_string()
        # 頻出アルファベット頭字語をベースヒントとして提供
        base = (
            "USJ、HDMI、FDE、PC、IDE、Wi-Fi、API、URL、CPU、GPU、SSD、"
            "USB、AI、AWS、GCP、SNS、QR、SaaS、FAQ、Q&A"
        )
        parts = [base]
        if user_hints:
            parts.append(user_hints)
        return "、".join(parts)

    def _worker_loop(self) -> None:
        while not self._stop.is_set():
            try:
                kind, payload, session = self._work.get(timeout=0.2)
            except queue.Empty:
                continue
            try:
                if session in self.cancelled:
                    log.debug("中止済み session=%d の仕事を捨てます", session)
                    continue
                if kind is HELD:
                    self._flush_held(str(payload))
                elif kind is KEEP:
                    self._keep_only(bytes(payload))  # type: ignore[arg-type]
                elif kind is ACTION:
                    act_name, act_pcm = payload  # type: ignore[misc]
                    self._handle_action(str(act_name), bytes(act_pcm), session)
                elif kind is TEXT:
                    text, group = payload  # type: ignore[misc]
                    if self._spill(str(text), session, group=int(group),
                                   join=True):
                        continue
                    # 区切りの 1 回目なら、前の区切りとのあいだに空白を
                    # 入れる。入れないと「地雨おはよう」とくっついた。
                    # 同じ区切りの 2 回目からは _joiner が何も足さない。
                    self._type(str(text), session, join=True,
                               group=int(group))
                elif kind is SUBMIT:
                    delay = max(150, self.cfg.int_("enter_delay_ms", 200))
                    time.sleep(delay / 1000)
                    if session in self.cancelled:
                        continue
                    inject.send_submit(self.cfg.str_("send_key", "enter"))
                    # 送ったら入力欄は空になる。次はつなぎ目を入れない。
                    self._last_insert_hwnd = 0
                    self._last_insert_tail = ""
                    self._last_insert_group = -1
                    self._last_typed_submitted = True
                    log.info("送信キーを送りました (%s, delay=%dms)",
                             self.cfg.str_("send_key", "enter"), delay)
                else:
                    pcm, typed, heard, final, group = payload  # type: ignore[misc]
                    self._handle_audio(pcm, typed, session, heard,
                                       final=final, group=int(group))
            except Exception:
                log.exception("文字起こしで例外")
                self._notify(t("overlay.failed"), hold=self.NOTE_WARN)
            finally:
                self.pending = max(0, self.pending - 1)
                self._action_sessions.discard(session)
                self._tray_state()

    def _handle_action(self, action: str, pcm: bytes, session: int) -> None:
        """特定動作（英語翻訳・敬語・ビジネス・要約）を実行する。

        録音された音声全体を文字起こしし、指定された変換を適用して
        一括で入力欄へ貼り付ける。
        """
        if self.engine is None or not pcm:
            return
        if session in self.cancelled:
            log.info("中止済み session=%d のアクション処理をスキップします", session)
            return

        seconds = len(pcm) / (SAMPLE_RATE * 2)
        if seconds < 0.3:
            log.info("音声が短すぎるためアクション処理をスキップします (%.2fs)", seconds)
            if self.cfg.str_("active_action", ""):
                self.cfg.set("active_action", "")
            return

        try:
            started = time.perf_counter()
            log.info("アクション '%s' を開始 session=%d 音声=%.2fs", action, session,
                     seconds)

            act_id = action.removeprefix("custom_instruction_")
            if action.startswith("custom_instruction_"):
                inst_name = act_id
                for item in self.cfg.get("ai_custom_instructions") or []:
                    if item.get("id") == act_id:
                        inst_name = item.get("name") or act_id
                        break
                self._notify(f"{inst_name} 変換中...", hold=self.NOTE_INFO)
            else:
                msg_key = f"overlay.action_running_{action}"
                running_label = t(msg_key)
                if running_label != msg_key:
                    self._notify(running_label, hold=self.NOTE_INFO)

            api_key = self.cfg.str_("ai_api_key", "")
            ai_provider = self.cfg.str_("ai_provider", "auto")
            ai_model = self.cfg.str_("ai_model", "gemini-3.8-flash")
            is_offline = self.cfg.bool_("offline_mode", False)
            use_cloud_ai = bool(api_key and not is_offline)

            raw_text = ""
            translated_text = ""

            # 1. 英語翻訳かつオフライン（または API 未設定）で Whisper 音声翻訳が使える場合
            # （API キーがあるときは直訳ではなく高精度なクラウド LLM による自然な翻訳を優先する）
            if (act_id == "translate_en"
                    and not use_cloud_ai
                    and hasattr(self.engine, "session")
                    and getattr(self.engine, "session", None) is not None):
                try:
                    from .resident import to_float
                    samples = to_float(pcm)
                    res = self.engine.session.run(samples, task="translate",
                                                  language="ja")
                    translated_text = (res.text or "").strip()
                except Exception as exc:
                    log.debug("Whisper 直接音声翻訳に失敗、通常文字起こしへ戻ります: %s",
                              exc)

            # 2. 通常の文字起こし
            if not translated_text:
                # アクションは発話全体の一括デコード＝最終デコード。
                # 自動格下げ中は設定モデルで聞く（_decode_final）。
                raw_text, _took, _quality = self._decode_final(
                    pcm, final=True)
                if not raw_text or is_noise(raw_text):
                    log.info("文字起こし結果が空またはノイズでした: %r", raw_text)
                    return

                junk, why = is_hallucination(
                    raw_text, seconds, language=self.cfg.str_("language", "ja"))
                if junk:
                    log.info("音と関係のない文字なので捨てます: %r（%s）", raw_text, why)
                    return

            # 3. テキストの変換（画面AIアシスタントまたは通常変換）
            target_text = translated_text or raw_text
            cb_text = inject.clipboard_text()
            if action == "ai_auto_edit":
                custom_prompt = self.cfg.str_("ai_auto_edit_prompt", "")
            else:
                custom_prompt = self.cfg.str_("custom_action_prompt", "")
            custom_instructions = self.cfg.get("ai_custom_instructions") or []
            speaker_focus = self.cfg.str_("speaker_focus", "normal")

            # 画面AIアシスタント（ジャービス）または画面/予定連携キーワードの検知
            is_screen_req = (
                action == "screen_assistant"
                or any(k in (raw_text or target_text) for k in (
                    "ジャービス", "画面見て", "画面を見て", "スクリーンショット",
                    "カレンダーに入れて", "予定に入れて", "スケジュールに入れて"
                ))
            )
            final_text = ""
            if is_screen_req:
                try:
                    from . import vision  # noqa: PLC0415
                    import webbrowser  # noqa: PLC0415
                    self._notify(t("overlay.screen_assistant_running"),
                                 hold=self.NOTE_INFO)
                    img = (getattr(self, "_screen_image", None)
                           or vision.capture_window_or_screen(self.target_hwnd))
                    self._screen_image = None
                    mode, ans, cal_url = transform.process_screen_assistant(
                        raw_text or target_text,
                        img,
                        api_key=api_key,
                        provider=ai_provider,
                        model=ai_model,
                        is_offline=is_offline,
                    )
                    if mode == "calendar" and cal_url:
                        webbrowser.open(cal_url)
                        self._notify(t("overlay.calendar_opened"),
                                     hold=self.NOTE_INFO)
                        final_text = f"【カレンダー登録】{ans}"
                    elif mode == "search" and cal_url:
                        webbrowser.open(cal_url)
                        self._notify("Google検索を開きました",
                                     hold=self.NOTE_INFO)
                        final_text = ans
                    else:
                        final_text = ans
                        self._notify(t("overlay.screen_assistant_done"),
                                     hold=self.NOTE_SHORT)
                except Exception as exc:
                    log.warning("画面AIアシスタント処理で例外: %s", exc)
                    final_text = target_text

            if not final_text:
                try:
                    final_text = transform.transform_text(
                        target_text,
                        action,
                        audio_pcm=pcm,
                        session=getattr(self.engine, "session", None),
                        api_key=api_key,
                        provider=ai_provider,
                        model=ai_model,
                        custom_prompt=custom_prompt,
                        custom_instructions=custom_instructions,
                        is_offline=is_offline,
                        speaker_focus=speaker_focus,
                        clipboard_text=cb_text,
                    )
                except transform.ApiRequiredError as exc:
                    log.warning("API キーが必要なアクションです: %s", exc)
                    inst_label = act_id
                    for item in custom_instructions:
                        if item.get("id") == act_id:
                            inst_label = item.get("name") or act_id
                            break
                    self._notify(
                        f"「{inst_label}」には API キーの設定が必要です",
                        hold=self.NOTE_WARN
                    )
                    return

            if not final_text:
                log.info("変換結果が空でした")
                return

            # 4. 履歴へ保存
            self._remember(final_text, pcm, raw_text=raw_text or target_text)

            # 5. 中止チェック
            if session in self.cancelled:
                log.info("中止済みのため貼り付けをスキップします")
                return

            # 6. 入力欄へ一括貼り付け
            if self._spill(final_text, session):
                return
            self._type(final_text, session, join=False)

            # 7. 完了トースト表示
            if action == "ai_auto_edit":
                self._notify(t("overlay.action_done_ai_auto_edit"), hold=self.NOTE_SHORT)
            elif action.startswith("custom_instruction_"):
                inst_id = action.removeprefix("custom_instruction_")
                inst_name = inst_id
                for item in custom_instructions:
                    if item.get("id") == inst_id:
                        inst_name = item.get("name") or inst_id
                        break
                self._notify(f"{inst_name} 完了", hold=self.NOTE_SHORT)
            else:
                done_key = f"overlay.action_done_{action}"
                done_label = t(done_key)
                if done_label != done_key:
                    self._notify(done_label, hold=self.NOTE_SHORT)
            if self.cfg.bool_("sound_feedback"):
                self._play_sound("submit")
            log.info("アクション '%s' 完了: 所要時間=%.2fs 結果=%r",
                     action, time.perf_counter() - started, final_text[:60])
        finally:
            if self.cfg.str_("active_action", ""):
                self.cfg.set("active_action", "")

    def _handle_audio(self, pcm: bytes, typed: str, session: int,
                      heard: str = "", *, final: bool = False,
                      group: int = 0) -> None:
        """区間が確定したときの処理。「文ごと」モードの本体でもある。

        typed は、その区間について**話しながらすでに入力した文字**。
        区間を確定した時点で取り出してあるので、ここでは取り合いが起きない。
        """
        if self.engine is None:
            return
        if session in self._action_sessions:
            log.debug("アクションセッション %d のため通常の区間処理はスキップします",
                      session)
            return
        seconds = len(pcm) / (SAMPLE_RATE * 2)
        # 無音だけの区間はエンジンに渡さない。無音を聞かせると
        # モデルは「う」のような断片を幻聴する（2026-10-26 実証:
        # 停止時の残り 0.32 秒は完全なデジタル無音で、SenseVoice が
        # そこから「う。」を出し、文末に付いた）。post-roll 自体は
        # 発話の尾を守るために必要だが、中身が無音なら最終デコード
        # の対象ではない。カッターの floor と同じ物差しで見る。
        if is_silence(pcm, floor=float(self.cfg.int_("vad_floor", 180))):
            log.info("無音だけの区間（%.2f秒）なので確定しません", seconds)
            return
        text, took, quality = self._decode_final(pcm, final=final)
        if not quality:
            # 品質経路（設定モデルでの最終デコード）の所要時間は
            # 番人の判断材料ではない（_decode_final 参照）。
            self._watch_speed(took, seconds)
        if session in self.cancelled:
            log.info("中止済みなので入力しません")
            return

        # 確定の 1 回が空でも、話しながらの途中で聞こえていたなら
        # それを使う。**聞こえていたのに捨てる**のがいちばん困る壊れ方。
        if (not text or is_noise(text)) and heard.strip():
            log.warning("確定は空でしたが、途中で聞こえていた分を使います: %s",
                        heard[:60])
            text = self._clean(heard, final=final)

        if not text or is_noise(text):
            log.info("入力する文字がありません: %r", text)
            return
        junk, why = is_hallucination(text, seconds,
                                    language=self.cfg.str_("language", "ja"))
        if junk:
            log.info("音と関係のない文字なので捨てます: %r（%s）", text, why)
            return

        # 末尾の断片ガード（無音ガードの補助）。本文が既に確定して
        # いる発話の最後の区間で、0.5 秒未満の音から「う」だけの
        # ような断片が出たら入れない。無音でない物音（クリック等）
        # から断片が出る場合の受け皿。発話全体が「うん」のような
        # 短い応答だけの場合は本文が無いので対象にならない。
        # 閾値 0.5 秒は実例（0.32 秒）を含む値。当初の目安 300ms
        # では実例を取りこぼすため広げたが、通常の単語 1 語
        # （0.3〜0.6 秒）とは本文の有無で区別するので巻き込まない。
        if (final and seconds < 0.5 and is_tail_fragment(text)
                and self._session_body.get(session, 0) >= 10):
            log.info("末尾の断片だけの区間なので入れません: %r（%.2f秒）",
                     text, seconds)
            return

        # 音声コマンドか？（その区間がコマンドそのものだった時だけ）
        if self._run_command(text, typed, session):
            return

        # ★入力の前に履歴へ保存する。貼り付けに失敗しても文字は残る。
        whole = text
        self._remember(whole, pcm, raw_text=heard, session=session)
        # 確定した本文の長さを数える（末尾の断片ガード用）。
        self._session_body[session] = (
            self._session_body.get(session, 0) + len(whole))
        if len(self._session_body) > 32:
            self._session_body.pop(min(self._session_body))

        if typed:
            text = remainder(typed, text)
            if not text:
                log.info("話しながら入力済みなので残りはありません")
                return
        if self._spill(text, session, group=group, join=True):
            return
        self._type(text, session, join=True, group=group)

    def _commands(self):  # noqa: ANN202
        """使える音声コマンドの一覧（設定で止めた分を除く）。"""
        off = set(self.cfg.list_("voice_command_off"))
        extra = self.cfg.get("voice_command_extra") or {}
        symbols = self.cfg.get("symbol_commands",
                               jatext.DEFAULT_SYMBOL_COMMANDS)
        symbol_disabled_words = set()
        symbol_active = []
        if isinstance(symbols, (list, tuple)):
            for s in symbols:
                word = str(s.get("word", ""))
                sym = str(s.get("symbol", ""))
                if not word:
                    continue
                if s.get("enabled", True):
                    symbol_active.append((word, sym))
                else:
                    symbol_disabled_words.add(word)

        out = []
        for cmd in jatext.DEFAULT_COMMANDS:
            name = cmd.phrases[0]
            if name in off or name in symbol_disabled_words:
                continue
            more = extra.get(name) or []
            if more:
                cmd = jatext.Command(
                    tuple(cmd.phrases) + tuple(str(x) for x in more),
                    cmd.kind, cmd.value, cmd.ja, cmd.en)
            out.append(cmd)

        for word, sym in symbol_active:
            if not any(word in c.phrases for c in out):
                label = "改行" if sym == "\n" else sym
                out.append(jatext.Command(
                    (word,), "text", sym,
                    f"{label} を入れる", f"Insert {label}"))
        return out

    def _run_command(self, text: str, typed: str, session: int) -> bool:
        """区間が音声コマンドだったら実行して True を返す。

        話しながらモードですでに文字を入れてしまっていた場合は、
        コマンドとして扱わない。入れた文字は書き換えない決まりなので、
        「改行」という字が残ったまま改行まで入ると二重になる。
        """
        if not self.cfg.bool_("voice_commands", True):
            return False
        if typed:
            return False
        cmd = jatext.match_command(text, self._commands())
        if cmd is None:
            return False
        log.info("音声コマンド: %s (%s)", cmd.phrases[0], cmd.kind)
        if cmd.kind == "text":
            self._type(cmd.value, session)
        elif cmd.kind == "submit":
            self._work.put((SUBMIT, None, session))
            self.pending += 1
        elif cmd.kind == "undo":
            if self._undo_last_type():
                self._notify(t("overlay.undone"), hold=self.NOTE_SHORT)
            else:
                self._notify(t("overlay.nothing_to_undo"),
                             hold=self.NOTE_INFO)
            return True
        elif cmd.kind == "lang_ja":
            self.cfg.set("language", "ja")
            self._notify(t("overlay.lang_changed", val="日本語"),
                         hold=self.NOTE_INFO)
            return True
        elif cmd.kind == "lang_en":
            self.cfg.set("language", "en")
            self._notify(t("overlay.lang_changed", val="英語"),
                         hold=self.NOTE_INFO)
            return True
        elif cmd.kind == "lang_toggle":
            self._toggle_language()
            return True
        self._notify(f"{cmd.phrases[0]}", hold=self.NOTE_SHORT)
        return True

    def _undo_last_type(self) -> bool:
        """直前に入力したテキストを取り消す（Backspace を送る）。

        安全性への配慮：
          ・直前の入力テキストが存在し、送信（Enter）されていないこと
          ・直前の入力から 20 秒以内であること（時間が経ちすぎた誤爆を防ぐ）
          ・入力先の窓と現在の前面窓が一致していること
        """
        text = self._last_typed_text
        if not text:
            log.info("取り消す文字がありません")
            return False
        if self._last_typed_submitted:
            log.info("送信済み（Enter 送信後）なので取り消せません")
            return False
        if time.monotonic() - self._last_typed_at > 20.0:
            log.info("入力から時間が経ちすぎているため取り消せません")
            return False
        target_hwnd = self._last_typed_hwnd
        now_hwnd = inject.foreground()
        if target_hwnd and now_hwnd and now_hwnd != target_hwnd:
            log.warning("前面ウィンドウが変わった（%s != %s）ので"
                        "取り消しません", now_hwnd, target_hwnd)
            return False

        count = len(text)
        ok = inject.send_backspaces(count, target_hwnd=target_hwnd)
        if ok:
            log.info("直前の入力を取り消しました: %r (%d 文字)",
                     text[:60], count)
            self._last_typed_text = ""
            self._last_insert_tail = ""
            return True
        return False

    def _joiner(self, group: int, target: int | None = None) -> str:
        """前の録音の文と、今から入れる文のあいだに置く文字。

        「。」を付けない設定だと、続けて録音したときに
        「ベストテスト今日の天気は」のようにつながってしまう。
        同じ入力欄に続けて入れるときだけ、区切りを 1 文字入れる。

        入れるのは、次の全部が当てはまるときだけ。

          ・この録音で、まだ 1 文字も入れていない（＝録音の 1 文字目）
          ・前に入れた先と**同じ窓**である
          ・前に入れてから、そう時間が経っていない
          ・前に入れた文字の終わりが、句読点・空白・改行でない

        送信（Enter）したあとや、中止したあとは入れない。
        """
        mode = self.cfg.str_("join_separator", "space")
        if mode == "none" or group == self._last_insert_group:
            return ""
        if not self._last_insert_hwnd:
            return ""
        where = self.target_hwnd if target is None else target
        if self._last_insert_hwnd != (where or 0):
            return ""
        gap = self.cfg.int_("join_window_ms", 120000) / 1000.0
        if time.monotonic() - self._last_insert_at > gap:
            return ""
        tail = self._last_insert_tail
        if not tail or tail[-1] in "\u3001\u3002\uff01\uff1f!?,. \u3000\n\t":
            return ""
        return {"space": " ", "comma": "\u3001"}.get(mode, "")

    def _type(self, text: str, session: int, *, join: bool = False,
              group: int = 0, target: int | None = None) -> bool:
        """入力欄へ実際に入れる。貼り付けは worker スレッドだけが行う。

        group は「どの区切りの文字か」。区切りが変わったときだけ、
        前の文とのあいだに区切り（空白など）を入れる。
        同じ区切りの中で何回かに分けて入れる（話しながらモード）ときは
        入れない。
        """
        if not text:
            return False
        target_hwnd = self.target_hwnd if target is None else target
        # よその窓を見ているあいだに出てきた文字は、元の欄の分として
        # 取っておく（戻ったら入れる）。取っておいた分が残っていれば、
        # 順番が入れ替わらないよう、後ろに並べる。
        if (target is None and target_hwnd
                and self.cfg.str_("away_text", "wait") == "wait"
                and ((self._held and self._held_target == target_hwnd)
                     or self._away_from(target_hwnd))):
            self._hold(text, session, group=group, join=join,
                       target=target_hwnd)
            return True
        if join:
            text = self._joiner(group, target_hwnd) + text
        save_cb = self.cfg.str_("save_to_clipboard", "fallback")
        copy_on_fb = (save_cb != "never")
        target_focus = (getattr(self, "target_focus_hwnd", 0)
                        if target is None else 0)
        restore_tgt = self.cfg.bool_("restore_focus_on_finish", True)
        result = inject.paste_text(
            text,
            paste_delay_ms=self.cfg.int_("paste_delay_ms", 70),
            restore_delay_ms=self.cfg.int_("clipboard_restore_ms", 250),
            modifier_timeout_ms=self.cfg.int_("wait_modifier_release_ms", 900),
            target_hwnd=target_hwnd,
            target_focus=target_focus,
            restore_target=restore_tgt,
            method=self.cfg.str_("paste_method", "auto"),
            copy_on_fallback=copy_on_fb,
            abort=lambda: session in self.cancelled,
        )
        if self.settings is not None and not self.cfg.bool_(
                "onboarding_done", False):
            # 初回の案内の「話してみる」画面に出す
            try:
                self.settings.bridge.onboarding.heard(text)
            except Exception:  # noqa: BLE001
                log.debug("練習の画面へ渡せませんでした", exc_info=True)
        if result == inject.PASTED:
            if save_cb == "always":
                try:
                    inject.set_clipboard_text(text, keep_out_of_history=False)
                except Exception:
                    log.debug("クリップボードへの常時保存に失敗しました", exc_info=True)
            self.last_text = text
            self._last_insert_hwnd = target_hwnd or 0
            self._last_insert_at = time.monotonic()
            self._last_insert_tail = text[-4:]
            self._last_insert_group = group
            self._last_typed_text = text
            self._last_typed_hwnd = target_hwnd or 0
            self._last_typed_at = time.monotonic()
            self._last_typed_submitted = False
            log.info("入力しました: %s", text[:200])
            self._notify(text[:18] + ("…" if len(text) > 18 else ""))
            return True
        if result == inject.COPIED:
            # 入力先が変わっていた。勝手に貼らず、コピーしたことを知らせる。
            self.last_text = text
            log.info("貼らずにコピーしました: %s", text[:200])
            self._notify(t("overlay.copied"), hold=self.NOTE_INFO)
            return True
        if not copy_on_fb:
            self.last_text = text
            log.info("貼れませんでしたがクリップボード保存OFFのため履歴のみ: %s",
                     text[:200])
            self._notify(t("overlay.saved_to_history"), hold=self.NOTE_INFO)
            return True
        log.warning("入力に失敗しました")
        self._notify(t("overlay.paste_failed"), hold=self.NOTE_WARN)
        return False

    @guard
    def _repaste(self) -> None:
        """最後の文字起こしをもう一度入力する。

        貼り付けに失敗した時・別の窓に入れ直したい時のため。
        何も覚えていなければ履歴の先頭から取る。
        """
        text = self.last_text
        if not text:
            rows = self.history.recent(1)
            text = rows[0].get("text", "") if rows else ""
        if not text:
            self._notify(t("overlay.nothing_to_repaste"),
                         hold=self.NOTE_INFO)
            return
        # 貼り直しは「いま前面にある窓」が相手。窓が変わったかの確認はしない。
        self.target_hwnd = 0
        self._type(text, -1)

    @guard
    def _copy_last(self) -> None:
        """最後の文字起こしをクリップボードにコピーする。"""
        text = self.last_text
        if not text:
            rows = self.history.recent(1)
            text = rows[0].get("text", "") if rows else ""
        if not text:
            self._notify(t("overlay.nothing_to_repaste"),
                         hold=self.NOTE_INFO)
            return
        inject.set_clipboard_text(text)
        self._notify(t("overlay.copied"), hold=self.NOTE_INFO)

    @guard
    def _keep_only(self, pcm: bytes) -> None:
        """中止した録音を、入力せずに履歴だけへ残す。"""
        if self.engine is None:
            return
        # 無音だけなら、幻聴した文字を履歴に残さない（_handle_audio
        # の無音ガードと同じ理由）。
        if is_silence(pcm, floor=float(self.cfg.int_("vad_floor", 180))):
            return
        text = self._transcribe(pcm)
        if not text or is_noise(text):
            return
        junk, why = is_hallucination(text, len(pcm) / (SAMPLE_RATE * 2),
                                    language=self.cfg.str_("language", "ja"))
        if junk:
            log.info("中止した録音は聞き取れていないので残しません（%s）", why)
            return
        log.info("中止した録音を履歴に残します: %s", text[:80])
        self._remember(text, pcm, raw_text=text, cancelled=True)
        self.last_text = text

    def _ja_options(self) -> jatext.Options:
        words = self.cfg.list_("filler_words")
        return jatext.Options(
            punctuation=self.cfg.str_("punctuation_density", "few"),
            fullwidth_punct=self.cfg.bool_("fullwidth_punct", True),
            questions=self.cfg.str_("question_marks", "never"),
            halfwidth_alnum=self.cfg.bool_("halfwidth_numbers", True),
            spacing=self.cfg.str_("ja_en_spacing", "none"),
            arabic_numbers=self.cfg.bool_("arabic_numbers", False),
            fillers=self.cfg.bool_("remove_fillers", True),
            filler_words=tuple(words) if words else jatext.DEFAULT_FILLERS,
            restatement=self.cfg.bool_("fix_restatement", False),
            full_stops=self.cfg.str_("full_stops", "off"),
            tail_question=self.cfg.bool_("voice_commands", True),
            convert_spelled_alphabet=self.cfg.bool_("convert_spelled_alphabet",
                                                   True),
            repair_mixed_loanwords=self.cfg.bool_("repair_mixed_loanwords",
                                                  True),
            fix_homophones=self.cfg.bool_("fix_homophones", True),
            learned_pairs=self._learned_pairs(),
            symbol_commands=self.cfg.get("symbol_commands",
                                         jatext.DEFAULT_SYMBOL_COMMANDS),
        )

    def _learned_pairs(self) -> tuple[tuple[str, str], ...]:
        """学習ペア（設定がオフ・ストア無しなら空＝効かせない）。"""
        if self.learn_store is None:
            return ()
        if not self.cfg.bool_("learn_fixes", True):
            return ()
        return self.learn_store.pairs()

    def _clean(self, raw: str, *, final: bool = False) -> str:
        """生の結果を、入力できる形に整える。

        順番：まず最低限の片づけ（タグ・改行・分かち書きの空白）→ 辞書の
        置き換え → 日本語としての整え。辞書を先にするのは、置き換えた語に
        対しても句読点や空白の規則を効かせるため。
        """
        opt = self._ja_options()
        text = tidy(raw, punctuation=True, fillers=False,
                    halfwidth=opt.halfwidth_alnum)
        text = self.dictionary.apply(text)
        return jatext.format_text(text, opt, final=final)

    @guard
    def _remember(self, text: str, pcm: bytes, *,
                  raw_text: str = "", cancelled: bool = False,
                  session: int = 0) -> int | None:
        limit = self.cfg.int_("history_limit", 200)
        if limit <= 0:
            return None

        # 録音セッションまとめ機能:
        # 同じ録音セッション（session > 0）で話した複数の区間は、
        # 1行の履歴エントリにまとめて追記する（ぶつ切り防止）。
        if session > 0 and session in getattr(self, "_session_entry_ids", {}):
            eid = self._session_entry_ids[session]
            sep = "、" if self.cfg.str_("join_separator", "space") == "comma" else " "
            if self.history.append(
                eid, text, raw_text=raw_text or text,
                seconds=len(pcm) / (SAMPLE_RATE * 2),
                pcm=pcm if self.cfg.bool_("history_keep_audio") else None,
                sep=sep
            ):
                return eid

        from .history import store_audio
        audio_path = (store_audio(pcm)
                      if self.cfg.bool_("history_keep_audio") else None)
        eid = self.history.add(text, raw_text=raw_text or text,
                               model=self.cfg.str_("model"),
                               seconds=len(pcm) / (SAMPLE_RATE * 2),
                               audio=audio_path, limit=limit,
                               cancelled=cancelled, session_id=session)
        if session > 0 and eid is not None:
            if not hasattr(self, "_session_entry_ids"):
                self._session_entry_ids = {}
            self._session_entry_ids[session] = eid
            if len(self._session_entry_ids) > 32:
                oldest = sorted(self._session_entry_ids.keys())[0]
                self._session_entry_ids.pop(oldest, None)
        return eid


def _level_of(data: bytes) -> float:
    """50ms ぶんの PCM から、0.0〜1.0 の大きさを出す。

    帯の波と同じ尺度にそろえてある（`app/vad.py` と同じ 6000 で割る）。
    """
    if len(data) < 2:
        return 0.0
    frame = array.array("h")
    frame.frombytes(data[:len(data) - len(data) % 2])
    if not frame:
        return 0.0
    total = 0
    step = max(1, len(frame) // 400)      # 全部は見ない（軽くする）
    count = 0
    for i in range(0, len(frame), step):
        total += frame[i] * frame[i]
        count += 1
    rms = math.sqrt(total / max(1, count))
    return min(1.0, rms / 6000.0)


def _open(path) -> None:  # noqa: ANN001
    try:
        os.startfile(str(path))  # noqa: S606
    except Exception:
        log.exception("開けませんでした: %s", path)


# ---------------------------------------------------------------- 多重起動防止


def single_instance(wait: float = 0.0, name: str | None = None) -> bool:
    """多重起動よけの鍵を取る。取れたら True。

    wait 秒まで、先にいるほうが鍵を手放すのを待つ（トレイの「再起動」の
    とき。古いほうはこれから終わる）。待つのは Windows の待ち合わせなので
    CPU は使わない。先にいるほうが落ちていても（鍵が放り出されても）取れる。
    name はテスト用（本物の鍵と重ならない名前で試すため）。
    """
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    kernel32.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    kernel32.WaitForSingleObject.restype = ctypes.c_uint32
    kernel32.CloseHandle.argtypes = [ctypes.c_void_p]
    if name is not None:
        handle = kernel32.CreateMutexW(None, True, name)
        return _take_mutex(kernel32, handle, wait)
    # から打ちモードは鍵の名前を変える。常駐している本物のアプリが
    # 動いていてもテストが起動できるようにするため。
    # さらに設定フォルダごとに分ける。分けないと、検証を 2 つ同時に
    # 走らせたときに、2 つ目が「すでに起動している」と判断して終わる。
    if dryrun.enabled():
        import hashlib
        tag = hashlib.sha1(str(HOME).encode("utf-8")).hexdigest()[:12]
        name = f"Local\\koe-type-dryrun-{tag}"
    else:
        name = "Global\\koe-type-single"
    handle = kernel32.CreateMutexW(None, True, name)
    return _take_mutex(kernel32, handle, wait)


def _take_mutex(kernel32, handle, wait: float) -> bool:  # noqa: ANN001
    """CreateMutexW の結果から、鍵を取れたかを決める。"""
    if not handle:
        return True
    if ctypes.get_last_error() == 183:   # ERROR_ALREADY_EXISTS
        if wait <= 0:
            kernel32.CloseHandle(handle)
            return False
        # 0 = 手放された / 0x80 = 先にいたほうが落ちて放り出された
        got = kernel32.WaitForSingleObject(handle, int(wait * 1000))
        if got not in (0, 0x80):
            kernel32.CloseHandle(handle)
            return False
    single_instance._handle = handle  # type: ignore[attr-defined]
    return True


def _dpi_aware() -> str:
    """「モニターごとの拡大率を自分で扱う」と Windows に伝える。

    ★伝えないと、Windows は帯を 1 倍で描かせてから引き伸ばすので、
    150% や 200% の画面では文字も波もぼやけていた（この PC は 200%）。
    窓を 1 つでも作る前に呼ぶこと（あとからは変えられない）。
    帯の大きさは overlay._dpi_factor で拡大率を掛けて合わせる。
    座標（作業領域・カーソル・クリックした窓）は、すべて同じ
    「実際の画面の点」でそろうので、ほかを直す必要はない。
    """
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    try:
        fn = user32.SetProcessDpiAwarenessContext
        fn.argtypes = [ctypes.c_void_p]
        fn.restype = ctypes.c_int
        # -4 = DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2（Windows 10 1703〜）
        if fn(ctypes.c_void_p(-4)):
            return "per-monitor-v2"
    except AttributeError:
        pass
    try:
        if user32.SetProcessDPIAware():
            return "system"
    except AttributeError:
        pass
    return "unaware"


def main() -> int:
    dpi_mode = _dpi_aware()
    restarted = "--restarted" in sys.argv[1:]
    if not single_instance(wait=20.0 if restarted else 0.0):
        setup_logging("INFO")
        log.warning("すでに起動しているので終了します")
        return 0
    controller = Controller()
    log.info("表示の拡大率の扱い: %s", dpi_mode)
    controller.run()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
