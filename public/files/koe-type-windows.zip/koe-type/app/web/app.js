/* koe-type の設定画面。
 *
 * サーバー（app/websettings.py）から状態をもらって描き、
 * 変更はそのつど /api/set へ送る。保存ボタンはない。
 */
"use strict";

const qs = new URLSearchParams(location.search);
// 合言葉はページの URL と <html data-token> の両方から受け取る。
// インラインの <script> は CSP で止めているので、ここで拾う。
const TOKEN = qs.get("t") || document.documentElement.dataset.token || "";

let STATE = null;
let PAGE = qs.get("page") || "general";
let SEARCH = qs.get("q") || "";   // 設定をさがす言葉。空ならふつうのページ
let DICT = [];
let dictFilter = "";
let historySelection = new Set();
let historyFilter = "";
let historyPlayer = null;     // いま鳴らしている録音（1 つだけ）
let historyPlaying = 0;       // 鳴らしている記録の番号
let SHOW_ADVANCED = false;
try { SHOW_ADVANCED = localStorage.getItem("koe_show_advanced") === "true"; } catch {}

/* ------------------------------------------------------------ 通信 */

async function api(path, body) {
  const options = {
    headers: { "X-Koe-Token": TOKEN, "Content-Type": "application/json" },
  };
  if (body !== undefined) {
    options.method = "POST";
    options.body = JSON.stringify(body);
  }
  const res = await fetch(path + "?t=" + encodeURIComponent(TOKEN), options);
  if (!res.ok) throw new Error(path + " -> " + res.status);
  return res.json();
}

const setValue = (key, value) => api("/api/set", { key, value });
// ★操作の名前は最後に置く。前は { name, ...extra } で、extra に name が
// あると（グループの名前など）操作の名前が上書きされ、本体に「知らない
// 操作」として捨てられていた（「グループを作る」が効かなかった）。
const runAction = (name, extra) => api("/api/action", { ...(extra || {}), name });

// 文字をファイルに保存する。保存先を選べるなら選ばせ、選べない
// ブラウザでは「ダウンロード」として保存する。選ぶのをやめたら false。
async function saveText(name, text) {
  if (window.showSaveFilePicker) {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: name,
        types: [{ description: "Text", accept: { "text/plain": [".txt"] } }],
      });
      const out = await handle.createWritable();
      await out.write(text);
      await out.close();
      return true;
    } catch (err) {
      if (err && err.name === "AbortError") return false;
    }
  }
  const link = document.createElement("a");
  link.href = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  link.download = name;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 5000);
  return true;
}

/* ------------------------------------------------------------ アイコン */

const ICON = (d, extra) =>
  `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"
        stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}${extra || ""}</svg>`;

const ICONS = {
  sliders: ICON(`<path d="M4 7h10M18 7h2M4 17h4M12 17h8"/>
                 <circle cx="16" cy="7" r="2"/><circle cx="10" cy="17" r="2"/>`),
  mic: ICON(`<rect x="9" y="3" width="6" height="11" rx="3"/>
             <path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>`),
  waveform: ICON(`<path d="M3 10v4M7 6v12M11 9v6M15 4v16M19 10v4"/>`),
  book: ICON(`<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H19v15H6.5A2.5 2.5 0 0 0 4 20.5z"/>
              <path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H19v3H6.5"/><path d="M8 7.5h7"/>`),
  monitor: ICON(`<rect x="2.5" y="4" width="19" height="13" rx="2"/>
                 <path d="M8.5 21h7M12 17v4"/>`),
  history: ICON(`<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3 4v4h4"/>
                 <path d="M12 7.5V12l3 1.8"/>`),
  window: ICON(`<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18"/>
                <path d="M6.5 6.5h.01M9.5 6.5h.01"/>`),
  plus: ICON(`<path d="M12 5v14M5 12h14"/>`),
  trash: ICON(`<path d="M4 7h16M10 11v6M14 11v6"/>
               <path d="M6 7l1 13h10l1-13M9 7V4h6v3"/>`),
  search: ICON(`<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>`),
  copy: ICON(`<rect x="9" y="9" width="11" height="11" rx="2"/>
              <path d="M5 15V5a2 2 0 0 1 2-2h8"/>`),
  download: ICON(`<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 20h14"/>`),
  upload: ICON(`<path d="M12 15V4M7.5 8.5 12 4l4.5 4.5M5 20h14"/>`),
  check: ICON(`<path d="M5 13l4.5 4.5L19 7"/>`),
  play: ICON(`<path d="M8 5.5v13l10-6.5z"/>`),
  stop: ICON(`<rect x="7" y="7" width="10" height="10" rx="1.5"/>`),
  info: ICON(`<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 7.6v.4"/>`),
  folder: ICON(`<path d="M3 7a2 2 0 0 1 2-2h4l2 2.5h8a2 2 0 0 1 2 2V18a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>`),
  reset: ICON(`<path d="M20 12a8 8 0 1 1-2.5-5.8"/><path d="M20 4v4h-4"/>`),
  apps: ICON(`<rect x="3.5" y="3.5" width="7" height="7" rx="1.5"/>
              <rect x="13.5" y="3.5" width="7" height="7" rx="1.5"/>
              <rect x="3.5" y="13.5" width="7" height="7" rx="1.5"/>
              <rect x="13.5" y="13.5" width="7" height="7" rx="1.5"/>`),
  type: ICON(`<rect x="2" y="5" width="20" height="14" rx="2"/>
              <path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M8 14h8"/>`),
  sparkles: ICON(`<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3zM5 3v4M3 5h4M19 17v4M17 19h4"/>`),
  edit: ICON(`<path d="M12 20h9M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>`),
  key: ICON(`<path d="m21 2-2 2m-1.5 1.5L14 9l-1.5-1.5-2 2 1.5 1.5L3 20v2h2l9-9 1.5 1.5 2-2-1.5-1.5 3.5-3.5a2.12 2.12 0 0 0 0-3L21 2z"/>`),
  clipboard: ICON(`<rect x="5" y="4.5" width="14" height="16.5" rx="2"/>
                   <path d="M9 4.5V4a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 4v.5"/>
                   <path d="M8.5 10.5h7M8.5 14h7M8.5 17.5h4"/>`),
  up: ICON(`<path d="M6 14.5 12 8.5l6 6"/>`),
  down: ICON(`<path d="M6 9.5l6 6 6-6"/>`),
  left: ICON(`<path d="M14.5 6 8.5 12l6 6"/>`),
  right: ICON(`<path d="M9.5 6l6 6-6 6"/>`),
  compass: ICON(`<circle cx="12" cy="12" r="9"/><polygon points="16 8 13.5 13.5 8 16 10.5 10.5 16 8"/>`),
  pin: ICON(`<path d="M9 4h6l-1 5 3 3v2H7v-2l3-3z"/><path d="M12 14v6"/>`),
  move: ICON(`<path d="M4 12h12M12 7.5 16.5 12 12 16.5"/><path d="M20 5v14"/>`),
  lock: ICON(`<rect x="5" y="10.5" width="14" height="10" rx="2"/>
              <path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>`),
  image: ICON(`<rect x="3.5" y="4.5" width="17" height="15" rx="2"/>
               <circle cx="9" cy="10" r="1.6"/><path d="m4 18 5-5 4 4 2.5-2.5L20 19"/>`),
  link: ICON(`<path d="M10 14a4.5 4.5 0 0 0 6.4 0l3-3a4.5 4.5 0 0 0-6.4-6.4l-1 1"/>
              <path d="M14 10a4.5 4.5 0 0 0-6.4 0l-3 3a4.5 4.5 0 0 0 6.4 6.4l1-1"/>`),
  text: ICON(`<path d="M6 4.5h8l4 4V20a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V5.5a1 1 0 0 1 1-1z"/>
              <path d="M14 4.5V9h4M8.5 13h7M8.5 16.5h5"/>`),
  grip: ICON(`<circle cx="9" cy="6" r="1.5"/><circle cx="15" cy="6" r="1.5"/>
              <circle cx="9" cy="12" r="1.5"/><circle cx="15" cy="12" r="1.5"/>
              <circle cx="9" cy="18" r="1.5"/><circle cx="15" cy="18" r="1.5"/>`),
};

/* ------------------------------------------------------------ 小物 */

const el = (tag, attrs, html) => {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === "on") { for (const [ev, fn] of Object.entries(v)) node.addEventListener(ev, fn); }
    else if (k === "class") node.className = v;
    else node.setAttribute(k, v === true ? "" : String(v));
  }
  if (html !== undefined) node.innerHTML = html;
  return node;
};

const txt = (key) => (STATE && STATE.text[key]) || key;

let toastTimer = 0;
function toast(message) {
  const node = document.getElementById("toast");
  node.textContent = message;
  node.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.remove("show"), 2200);
}

/* 末尾の 0 を落とす。0.70 -> 0.7 / 15.0 -> 15 */
const trim = (n, digits) =>
  n.toFixed(digits).replace(/\.(\d*?)0+$/, (m, keep) => (keep ? "." + keep : ""));

/* 単位つきの表示。人が読む形にする */
function formatValue(item, value) {
  if (!value && item.zero) return item.zero;
  switch (item.unit) {
    case "ms_sec":
      return trim(value / 1000, value < 1000 ? 2 : 1) + " " + txt("web.secs");
    case "ms_min":
      return trim(value / 60000, 1) + " " + txt("web.mins");
    case "count": return value + " " + txt("web.entries");
    case "px": return value + " " + txt("web.px");
    case "mb": return value + " MB";
    default: return String(value);
  }
}

function prettyHotkey(spec) {
  const isJa = STATE?.lang !== "en";
  const nice = { ctrl: "Ctrl", shift: "Shift", alt: "Alt", win: "Win",
                 space: "Space", enter: "Enter", esc: "Esc", tab: "Tab",
                 muhenkan: isJa ? "無変換" : "Muhenkan",
                 henkan: isJa ? "変換" : "Henkan",
                 kana: isJa ? "かな" : "Kana",
                 hankaku: isJa ? "半角/全角" : "Hankaku",
                 capslock: "Caps Lock" };
  return String(spec || "").split("+").filter(Boolean)
    .map((p) => nice[p] || (p.length === 1 ? p.toUpperCase() : p[0].toUpperCase() + p.slice(1)))
    .map((p) => `<kbd>${p}</kbd>`).join(" + ");
}

/* ------------------------------------------------------------ 画面 */

function normDictEntry(r) {
  if (Array.isArray(r)) {
    return { surface: r[1] || "", reading: "", mishearing: r[0] || "", is_regex: false };
  }
  return {
    surface: r.surface || "",
    reading: r.reading || "",
    mishearing: r.mishearing || "",
    is_regex: Boolean(r.is_regex),
  };
}

async function load() {
  STATE = await api("/api/state");
  DICT = (STATE.dictionary || []).map(normDictEntry);
  // ?theme=light|dark は見た目の確認用（スクリーンショットを撮るとき）
  document.documentElement.dataset.theme = qs.get("theme") || STATE.theme;
  document.documentElement.dataset.fontSize = STATE.values?.ui_font_size || "normal";
  document.documentElement.lang = STATE.lang;
  document.documentElement.style.setProperty("--accent", STATE.accent);
  document.title = STATE.text["settings.title"] || "koe-type";
  buildNav();
  render();
}

function buildNav() {
  const nav = document.getElementById("nav");
  nav.replaceChildren();
  nav.append(el("div", { class: "brand" },
    `<img class="mark" src="/icon/idle-64.png?t=${encodeURIComponent(TOKEN)}"
          width="28" height="28" alt="">
     <div><b>SpeakPulse</b><span>${txt("app.tagline")} &middot; ${STATE.version}</span></div>`));
  // 項目が 60 を超え、どのページにあるか探しにくくなったので検索を置く
  const search = el("div", { class: "search nav-search" }, ICONS.search);
  const input = el("input", { type: "search", spellcheck: "false",
                              placeholder: txt("web.search_settings"),
                              "aria-label": txt("web.search_settings"),
                              value: SEARCH });
  input.addEventListener("input", () => { SEARCH = input.value; render(); });
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && SEARCH) {
      e.stopPropagation(); SEARCH = ""; input.value = ""; render();
    }
  });
  search.append(input);
  nav.append(search);

  // 基本設定 / 詳しい設定の切り替え
  const modeSwitch = el("div", { class: "nav-mode-switch", role: "group" });
  const basicBtn = el("button", {
    type: "button",
    "aria-pressed": !SHOW_ADVANCED ? "true" : "false",
    on: { click: () => {
      SHOW_ADVANCED = false;
      try { localStorage.setItem("koe_show_advanced", "false"); } catch {}
      basicBtn.setAttribute("aria-pressed", "true");
      advBtn.setAttribute("aria-pressed", "false");
      render();
    } },
  }, txt("web.mode_basic"));
  const advBtn = el("button", {
    type: "button",
    "aria-pressed": SHOW_ADVANCED ? "true" : "false",
    on: { click: () => {
      SHOW_ADVANCED = true;
      try { localStorage.setItem("koe_show_advanced", "true"); } catch {}
      basicBtn.setAttribute("aria-pressed", "false");
      advBtn.setAttribute("aria-pressed", "true");
      render();
    } },
  }, txt("web.mode_advanced"));
  modeSwitch.append(basicBtn, advBtn);
  nav.append(modeSwitch);

  // 困りごと・やりたいことから探す案内
  const guideItem = el("button", {
    class: "nav-item nav-guide", type: "button",
    title: txt("guide.nav_title") || "困りごとから探す",
    on: { click: () => { PAGE = "guide"; clearSearch(); render(); } },
  }, `${ICONS.compass}<span>${txt("guide.nav_title") || "困りごとから探す"}</span>`);
  guideItem.dataset.key = "guide";
  nav.append(guideItem);

  for (const cat of STATE.categories) {
    const item = el("button", {
      class: "nav-item", type: "button", title: cat.label,
      on: { click: () => { PAGE = cat.key; clearSearch(); render(); } },
    }, `${ICONS[cat.icon] || ICONS.window}<span>${cat.label}</span>`);
    item.dataset.key = cat.key;
    nav.append(item);
  }
  nav.append(el("div", { class: "nav-foot" }, txt("common.autosaved")));
}

function clearSearch() {
  SEARCH = "";
  const box = document.querySelector(".nav-search input");
  if (box) box.value = "";
}

// 項目が言葉に合うか。名前・説明・選択肢の言葉から探す。
function itemMatches(item, words) {
  const hay = [item.label, item.help,
               ...(item.options || []).map((o) => o.label)]
    .filter(Boolean).join(" ").toLowerCase();
  return words.every((w) => hay.includes(w));
}

function renderSearch() {
  for (const node of document.querySelectorAll(".nav-item")) {
    node.removeAttribute("aria-current");
  }
  const words = SEARCH.trim().toLowerCase().split(/\s+/).filter(Boolean);
  const main = document.getElementById("main");
  main.replaceChildren();
  const page = el("div", { class: "page" });
  page.append(el("div", { class: "page-head" },
    `<h1>${escapeHtml(txt("web.search_result").replace("{q}", SEARCH.trim()))}</h1>`));
  let found = 0;
  for (const cat of STATE.categories) {
    const items = [];
    for (const group of cat.groups) {
      for (const item of group.items) {
        // 一覧や表（辞書・履歴など）は、ページごと開いてもらう
        if (item.kind === "custom") continue;
        if (itemMatches(item, words)) items.push(item);
      }
    }
    if (!items.length) continue;
    found += items.length;
    const section = el("div", { class: "group" });
    const head = el("button", {
      class: "search-cat", type: "button",
      on: { click: () => { PAGE = cat.key; clearSearch(); render(); } },
    }, `${escapeHtml(cat.label)} ›`);
    section.append(head);
    const card = el("div", { class: "card" });
    for (const item of items) card.append(...renderItem(item));
    section.append(card);
    page.append(section);
  }
  if (!found) {
    page.append(el("div", { class: "empty pad" }, txt("web.search_none")));
  }
  main.append(page);
}

/* ------------------------------------------------ 設定の案内（困りごと） */

let guideCategoryFilter = "all";
let guideSearchQuery = "";
let selectedChoices = {};
let guideBannerTimer = null;

function getGuideCategoryLabel(tag) {
  const map = {
    text: txt("guide.tab_text") || "文字・認識",
    speed: txt("guide.tab_speed") || "速度・動作",
    shortcut: txt("guide.tab_key") || "キー・操作",
    key: txt("guide.tab_key") || "キー・操作",
    audio: txt("guide.tab_sound") || "音・背景",
    sound: txt("guide.tab_sound") || "音・背景",
    ui: txt("guide.tab_ui") || "画面・表示",
    window: txt("guide.tab_ui") || "画面・表示",
    app: txt("guide.tab_ui") || "画面・表示",
  };
  return map[tag] || tag;
}

function renderGuide() {
  const main = document.getElementById("main");
  main.replaceChildren();
  const page = el("div", { class: "page guide-page" });

  const head = el("div", { class: "page-head guide-header-box" });
  head.append(el("h1", {}, txt("guide.title") || "困りごと・やりたいことから探す"));
  head.append(el("p", {}, txt("guide.subtitle") || "設定項目が多くて迷うときは、ここから選ぶと変えるべき設定と理由がわかります。"));
  page.append(head);

  const tabs = [
    { key: "all", label: txt("guide.tab_all") || "すべて" },
    { key: "text", label: txt("guide.tab_text") || "文字・認識" },
    { key: "speed", label: txt("guide.tab_speed") || "速度・動作" },
    { key: "key", label: txt("guide.tab_key") || "キー・操作" },
    { key: "sound", label: txt("guide.tab_sound") || "音・背景" },
    { key: "ui", label: txt("guide.tab_ui") || "画面・表示" },
  ];
  const tabBox = el("div", { class: "guide-filter-tabs", role: "tablist" });
  for (const tab of tabs) {
    const btn = el("button", {
      class: "guide-tab-btn" + (guideCategoryFilter === tab.key ? " active" : ""),
      type: "button",
      role: "tab",
      "aria-selected": guideCategoryFilter === tab.key ? "true" : "false",
      on: { click: () => { guideCategoryFilter = tab.key; renderGuide(); } },
    }, tab.label);
    tabBox.append(btn);
  }
  page.append(tabBox);

  const filterBox = el("div", { class: "search", style: "margin-bottom: 12px;" }, ICONS.search);
  const filterInput = el("input", {
    type: "search", spellcheck: "false",
    placeholder: txt("guide.search_placeholder") || "困りごとを絞り込む...",
    value: guideSearchQuery,
  });
  filterInput.addEventListener("input", () => {
    guideSearchQuery = filterInput.value;
    renderGuideList(listContainer);
  });
  filterBox.append(filterInput);
  page.append(filterBox);

  const listContainer = el("div", { class: "guide-list" });
  renderGuideList(listContainer);
  page.append(listContainer);

  main.append(page);
  main.scrollTop = 0;
}

function renderGuideList(container) {
  container.replaceChildren();
  const guides = STATE.guides || [];
  const q = guideSearchQuery.trim().toLowerCase();

  const filtered = guides.filter((g) => {
    if (guideCategoryFilter !== "all") {
      if (guideCategoryFilter === "text" && g.category_tag !== "text") return false;
      if (guideCategoryFilter === "speed" && g.category_tag !== "speed") return false;
      if (guideCategoryFilter === "key" && g.category_tag !== "shortcut" && g.category_tag !== "key") return false;
      if (guideCategoryFilter === "sound" && g.category_tag !== "audio" && g.category_tag !== "sound") return false;
      if (guideCategoryFilter === "ui" && g.category_tag !== "ui" && g.category_tag !== "window" && g.category_tag !== "app") return false;
    }
    if (q) {
      const title = (g.title || "").toLowerCase();
      const desc = (g.summary || "").toLowerCase();
      if (!title.includes(q) && !desc.includes(q)) return false;
    }
    return true;
  });

  if (!filtered.length) {
    container.append(el("div", { class: "card pad empty" }, txt("guide.no_match") || "一致する案内が見つかりませんでした。"));
    return;
  }

  for (const g of filtered) {
    const card = el("div", { class: "guide-card" });
    const head = el("div", { class: "guide-card-head" });
    const titleWrap = el("div", {});
    titleWrap.append(el("div", { class: "guide-card-title" }, g.title));
    titleWrap.append(el("div", { class: "guide-card-desc" }, g.summary));
    head.append(titleWrap);

    const tag = el("span", { class: "guide-card-tag" }, getGuideCategoryLabel(g.category_tag));
    head.append(tag);
    card.append(head);

    if (g.choices && g.choices.length > 0) {
      const choiceBox = el("div", { class: "guide-choices" });
      choiceBox.append(el("div", { style: "font-size: 12px; font-weight: 500; color: var(--text-2);" },
        g.question || txt("guide.select_situation") || "当てはまる状況を選んでください:"));

      let activeChoiceId = selectedChoices[g.id] || g.choices[0].id;
      const choicesWrap = el("div", { style: "display: flex; flex-direction: column; gap: 6px;" });
      const resolveWrap = el("div", {});

      const updateResolve = () => {
        resolveWrap.replaceChildren();
        const ch = g.choices.find((c) => c.id === activeChoiceId) || g.choices[0];
        const resolveBox = el("div", { class: "guide-resolve-box" });
        resolveBox.append(el("div", { class: "guide-resolve-reason" },
          `<b>${escapeHtml(txt("guide.why_change") || "なぜこれを変えるか：")}</b> ${escapeHtml(ch.reason)}`));

        const footer = el("div", { class: "guide-resolve-footer" });
        const targetLabel = ch.target_label || getItemLabel(ch.target_key);
        footer.append(el("span", { class: "guide-target-name" },
          `${escapeHtml(txt("guide.target_setting") || "変更する設定：")} <b>${escapeHtml(targetLabel)}</b>`));

        const goBtn = el("button", {
          class: "guide-go-btn",
          type: "button",
          on: { click: () => goToSetting(ch.target_key, ch.reason, null, ch.target_category) },
        }, `${escapeHtml(txt("guide.go_to_setting") || "この設定へ移動する")} ${ICONS.right}`);
        footer.append(goBtn);
        resolveBox.append(footer);
        resolveWrap.append(resolveBox);
      };

      for (const ch of g.choices) {
        const btn = el("button", {
          class: "guide-choice-btn" + (ch.id === activeChoiceId ? " selected" : ""),
          type: "button",
          on: { click: () => {
            activeChoiceId = ch.id;
            selectedChoices[g.id] = ch.id;
            for (const b of choicesWrap.querySelectorAll(".guide-choice-btn")) {
              b.classList.remove("selected");
            }
            btn.classList.add("selected");
            updateResolve();
          } },
        }, `<span>${escapeHtml(ch.label)}</span>`);
        choicesWrap.append(btn);
      }
      choiceBox.append(choicesWrap);
      choiceBox.append(resolveWrap);
      updateResolve();
      card.append(choiceBox);
    } else {
      const resolveBox = el("div", { class: "guide-resolve-box" });
      resolveBox.append(el("div", { class: "guide-resolve-reason" },
        `<b>${escapeHtml(txt("guide.why_change") || "なぜこれを変えるか：")}</b> ${escapeHtml(g.reason)}`));

      const footer = el("div", { class: "guide-resolve-footer" });
      const targetLabel = g.target_label || getItemLabel(g.target_key);
      footer.append(el("span", { class: "guide-target-name" },
        `${escapeHtml(txt("guide.target_setting") || "変更する設定：")} <b>${escapeHtml(targetLabel)}</b>`));

      const goBtn = el("button", {
        class: "guide-go-btn",
        type: "button",
        on: { click: () => goToSetting(g.target_key, g.reason, null, g.target_category) },
      }, `${escapeHtml(txt("guide.go_to_setting") || "この設定へ移動する")} ${ICONS.right}`);
      footer.append(goBtn);
      resolveBox.append(footer);
      card.append(resolveBox);
    }

    container.append(card);
  }
}

function goToSetting(targetKey, reasonText, recommendedValue, targetCategory) {
  let catKey = targetCategory;
  let isAdvanced = false;
  if (!catKey) {
    for (const cat of STATE.categories || []) {
      for (const group of cat.groups || []) {
        for (const item of group.items || []) {
          if (item.key === targetKey || (item.kind === "custom" && item.panel === targetKey)) {
            catKey = cat.key;
            if (item.advanced) isAdvanced = true;
            break;
          }
        }
        if (catKey) break;
      }
      if (catKey) break;
    }
  } else {
    for (const cat of STATE.categories || []) {
      if (cat.key === catKey) {
        for (const group of cat.groups || []) {
          for (const item of group.items || []) {
            if ((item.key === targetKey || item.panel === targetKey) && item.advanced) {
              isAdvanced = true;
              break;
            }
          }
        }
      }
    }
  }

  if (!catKey) catKey = "general";

  if (isAdvanced && !SHOW_ADVANCED) {
    SHOW_ADVANCED = true;
    try { localStorage.setItem("koe_show_advanced", "true"); } catch {}
    const advBtn = document.querySelector(".nav-mode-switch button:last-child");
    const basicBtn = document.querySelector(".nav-mode-switch button:first-child");
    if (advBtn) advBtn.setAttribute("aria-pressed", "true");
    if (basicBtn) basicBtn.setAttribute("aria-pressed", "false");
  }

  PAGE = catKey;
  clearSearch();
  render();

  setTimeout(() => {
    document.querySelectorAll(".guided-target").forEach((el) => el.classList.remove("guided-target"));
    document.querySelectorAll(".guide-reason-banner").forEach((el) => el.remove());
    if (guideBannerTimer) { clearTimeout(guideBannerTimer); guideBannerTimer = null; }

    const targetElem = document.getElementById("item-" + targetKey)
      || document.querySelector(`[data-key="${targetKey}"]`)
      || document.querySelector(`[data-panel="${targetKey}"]`);

    if (targetElem) {
      targetElem.classList.add("guided-target");
      targetElem.scrollIntoView({ behavior: "smooth", block: "center" });

      const banner = el("div", { class: "guide-reason-banner" });
      banner.append(el("div", { class: "guide-banner-icon" }, ICONS.compass));
      const body = el("div", { class: "guide-banner-body" });
      body.append(el("div", { class: "guide-banner-title" }, txt("guide.guided_from")));
      const rec = (recommendedValue !== undefined && recommendedValue !== null)
        ? ` (${txt("guide.recommend") || "推奨"}: ${recommendedValue})` : "";
      body.append(el("div", { class: "guide-banner-desc" }, `${reasonText}${rec}`));
      banner.append(body);

      const closeBtn = el("button", {
        class: "guide-banner-close",
        type: "button",
        title: txt("common.close") || "閉じる",
        on: { click: () => {
          banner.remove();
          targetElem.classList.remove("guided-target");
          if (guideBannerTimer) { clearTimeout(guideBannerTimer); guideBannerTimer = null; }
        } },
      }, "✕");
      banner.append(closeBtn);

      targetElem.parentNode.insertBefore(banner, targetElem);

      guideBannerTimer = setTimeout(() => {
        banner.remove();
        targetElem.classList.remove("guided-target");
      }, 12000);
    }
  }, 60);
}

function render() {
  if (SEARCH.trim()) { renderSearch(); return; }
  for (const node of document.querySelectorAll(".nav-item")) {
    node.toggleAttribute("aria-current", node.dataset.key === PAGE);
    if (node.dataset.key === PAGE) node.setAttribute("aria-current", "page");
    else node.removeAttribute("aria-current");
  }
  if (PAGE === "guide") {
    renderGuide();
    return;
  }
  const cat = STATE.categories.find((c) => c.key === PAGE) || STATE.categories[0];
  const main = document.getElementById("main");
  main.replaceChildren();
  const page = el("div", { class: "page" });
  page.append(el("div", { class: "page-head" },
    `<h1>${cat.label}</h1>${cat.sub ? `<p>${cat.sub}</p>` : ""}`));

  // 「よく使う設定」では、隠している項目の数をその場で知らせる。
  // 何も書かないと、2 つのモードの違いが分からなかった。
  if (!SHOW_ADVANCED) {
    const hidden = cat.groups.reduce(
      (n, g) => n + g.items.filter((i) => i.advanced).length, 0);
    if (hidden) {
      const more = el("button", {
        class: "basic-note", type: "button",
        on: { click: () => document.querySelector(".nav-mode-switch button:last-child")?.click() },
      });
      more.innerHTML = `${ICONS.info}<span>${escapeHtml(
        txt("web.basic_hidden").replace("{n}", String(hidden)))}</span>`;
      page.append(more);
    }
  }

  for (const group of cat.groups) {
    const items = group.items.filter((i) => SHOW_ADVANCED || !i.advanced);
    if (!items.length) continue;
    const section = el("div", { class: "group" });
    if (group.label) section.append(el("h2", {}, group.label));
    const custom = items.find((i) => i.kind === "custom");
    const card = el("div", { class: "card" + (custom ? " plain" : "") });
    for (const item of items) card.append(...renderItem(item));
    section.append(card);
    page.append(section);
  }
  main.append(page);
  main.scrollTop = 0;
}

function renderItem(item) {
  if (item.kind === "custom") {
    const panels = { models: panelModels, dictionary: panelDictionary,
                     history: panelHistory, about: panelAbout,
                     fillers: panelFillers, commands: panelCommands,
                     symbols: panelSymbols, selfcheck: panelSelfcheck,
                     ai_editor: panelAiEditor, clip_groups: panelClipGroups,
                     clip_tab_order: panelClipTabOrder,
                     clip_stats: panelClipStats, presets: panelPresets,
                     overlay_preview: panelOverlayPreview };
    const build = panels[item.panel];
    if (!build) {
      // 知らないパネルでも画面全体を壊さない（空の枠を出して先へ進む）
      console.warn("知らないパネル:", item.panel);
      return [el("div", { class: "card pad empty" }, item.panel)];
    }
    // 見出しと説明を先に出す。ここを飛ばしていたせいで、
    // 「消すつなぎ言葉」などが名無しの固まりに見えていた。
    const out = [];
    if (item.label) {
      const head = el("div", { class: "panel-head" });
      const itemKey = item.key || item.panel;
      if (itemKey) {
        head.id = "item-" + itemKey;
        head.dataset.key = itemKey;
      }
      head.append(el("div", { class: "label" }, item.label));
      if (item.help) head.append(el("div", { class: "help" }, item.help));
      out.push(head);
    }
    out.push(build());
    return out;
  }
  const row = el("div", { class: "row" + (item.inactive ? " inactive" : "") });
  if (item.key) {
    row.id = "item-" + item.key;
    row.dataset.key = item.key;
  }
  const left = el("div", {});
  left.append(el("div", { class: "label" }, item.label));
  if (item.help) left.append(el("div", { class: "help" }, item.help));
  if (item.inactive) {
    // いま効かない設定。理由をその場に書く（黙って無反応にしない）
    left.append(el("div", { class: "note" },
      `${ICONS.info}${item.inactive}`));
  }
  if (item.restart) {
    left.append(el("div", { class: "note" },
      `${ICONS.info}${txt("common.restart_needed")}`));
  }
  if (item.key === "long_press_action") {
    const isHoldMode = STATE.values.shortcut_mode === "hold";
    if (isHoldMode) {
      left.append(el("div", { class: "note", style: "color: #eab308; margin-top: 6px; font-size: 12px; line-height: 1.4;" },
        `${ICONS.info}「ショートカットの動作」が「長押しの間だけ」なので、長押しはふつうの録音になります。変換は、一覧のショートカットか、下の「変換用のショートカット」で使えます。`));
    } else {
      left.append(el("div", { class: "note", style: "color: var(--fg-muted); margin-top: 6px; font-size: 12px; line-height: 1.4;" },
        `${ICONS.info}起動キーを0.5秒以上長押しすると、ここで選んだ動作へ自動昇格します。`));
    }
  }
  const control = el("div", { class: "control" });
  control.append(...buildControl(item));

  // 初期値と異なっている場合、個別リセットボタンを出す
  if (item.kind !== "custom" && item.kind !== "action" && item.key && item.default !== undefined) {
    const isModified = JSON.stringify(STATE.values[item.key]) !== JSON.stringify(item.default);
    if (isModified) {
      const resetBtn = el("button", {
        class: "btn quiet icon btn-reset-item", type: "button",
        title: (txt("settings.reset_item") || "初期値に戻す").replace("{default}", String(item.default)),
        "aria-label": (txt("settings.reset_item") || "初期値に戻す").replace("{default}", String(item.default)),
        on: { click: async (e) => {
          e.stopPropagation();
          const r = await runAction("reset_item", { key: item.key });
          if (r && r.ok) {
            STATE.values[item.key] = r.value;
            render();
            toast(txt("settings.item_reset_done"));
          }
        } },
      }, ICONS.reset);
      control.append(resetBtn);
    }
  }

  row.append(left, control);
  if (item.inactive) {
    // 本当に押せなくする（見た目を薄くするだけでは Tab で触れてしまう）
    for (const node of control.querySelectorAll(
        "button, input, select, textarea")) {
      node.disabled = true;
      node.setAttribute("aria-disabled", "true");
      node.tabIndex = -1;
    }
  }
  return [row];
}

// 録音中の色は、名前のボタンではなく色の見本を並べて選ぶ
// （9 色を名前で並べると、行に収まらなかった）
const SWATCH = { red: "#e0483a", orange: "#f0883e", green: "#4cc38a",
                 teal: "#2fb6c1", blue: "#4c9aff", navy: "#5c5cc0",
                 pink: "#f06aa0", gray: "#9a9aac", accent: "var(--accent)" };

function swatchControl(item, value) {
  const wrap = el("div", { class: "swatches", role: "radiogroup",
                           "aria-label": item.label });
  for (const option of item.options) {
    const button = el("button", {
      type: "button", class: "swatch", role: "radio", title: option.label,
      "aria-label": option.label,
      "aria-checked": option.value === value ? "true" : "false",
    });
    button.style.setProperty("--swatch", SWATCH[option.value] || option.value);
    button.addEventListener("click", async () => {
      for (const sibling of wrap.children) sibling.setAttribute("aria-checked", "false");
      button.setAttribute("aria-checked", "true");
      STATE.values[item.key] = option.value;
      await setValue(item.key, option.value);
      afterChange(item.key);
      toast(option.label);
    });
    wrap.append(button);
  }
  return wrap;
}

function buildControl(item) {
  const value = STATE.values[item.key];
  if (item.key === "overlay_color") return [swatchControl(item, value)];
  switch (item.kind) {
    case "bool": return [switchControl(item, value)];
    case "segments": return [segmentsControl(item, value)];
    case "choice": return [selectControl(item, value)];
    case "int": return [sliderControl(item, value)];
    case "hotkey": return [hotkeyControl(item, value)];
    case "str":
    case "text": return [textControl(item, value)];
    case "textarea": return [textareaControl(item, value)];
    case "applist": return [];     // 行を置き換えるので別で描く
    case "action": return [actionControl(item)];
    default: return [];
  }
}

function switchControl(item, value) {
  const node = el("button", {
    class: "switch", type: "button", role: "switch",
    "aria-checked": value ? "true" : "false",
    "aria-label": item.label,
  });
  node.addEventListener("click", async () => {
    const next = node.getAttribute("aria-checked") !== "true";
    node.setAttribute("aria-checked", next ? "true" : "false");
    STATE.values[item.key] = next;
    await setValue(item.key, next);
    afterChange(item.key);
  });
  return node;
}

function segmentsControl(item, value) {
  const wrap = el("div", { class: "segments", role: "group",
                           "aria-label": item.label });
  // 近い値を選ぶ（感度のように数値が飛び飛びの場合に備える）
  let chosen = item.options.find((o) => o.value === value);
  if (!chosen && typeof value === "number") {
    chosen = item.options.reduce((best, o) =>
      Math.abs(o.value - value) < Math.abs(best.value - value) ? o : best);
  }
  for (const option of item.options) {
    const button = el("button", {
      type: "button",
      "aria-pressed": option === chosen ? "true" : "false",
    }, option.label);
    button.addEventListener("click", async () => {
      for (const sibling of wrap.children) sibling.setAttribute("aria-pressed", "false");
      button.setAttribute("aria-pressed", "true");
      STATE.values[item.key] = option.value;
      await setValue(item.key, option.value);
      afterChange(item.key);
    });
    wrap.append(button);
  }
  return wrap;
}

function selectControl(item, value) {
  const node = el("select", { class: "select", "aria-label": item.label });
  for (const option of item.options || []) {
    node.append(el("option", { value: option.value,
                               selected: option.value === value }, option.label));
  }
  node.addEventListener("change", async () => {
    STATE.values[item.key] = node.value;
    await setValue(item.key, node.value);
    afterChange(item.key);
  });
  return node;
}

function textControl(item, value) {
  const node = el("input", {
    type: "text", class: "text-input",
    value: value || "", placeholder: item.placeholder || "",
    "aria-label": item.label,
  });
  node.addEventListener("change", async () => {
    STATE.values[item.key] = node.value;
    await setValue(item.key, node.value);
    afterChange(item.key);
  });
  return node;
}

function textareaControl(item, value) {
  const node = el("textarea", {
    class: "textarea-input", rows: "4",
    placeholder: item.placeholder || "",
    "aria-label": item.label,
  });
  node.value = value || "";
  node.addEventListener("change", async () => {
    STATE.values[item.key] = node.value;
    await setValue(item.key, node.value);
    afterChange(item.key);
  });
  return node;
}

function sliderControl(item, value) {
  const wrap = el("div", { class: "slider-wrap" });
  if (item.presets) {
    const presets = el("div", { class: "segments" });
    for (const preset of item.presets) {
      presets.append(el("button", {
        type: "button",
        "aria-pressed": preset.value === value ? "true" : "false",
        on: { click: () => { input.value = preset.value; commit(true); } },
      }, preset.label));
    }
    wrap.append(presets);
  }
  const input = el("input", {
    class: "slider", type: "range", min: item.min, max: item.max,
    step: item.step, value, "aria-label": item.label,
  });
  const label = el("div", { class: "value" }, formatValue(item, value));

  const paint = () => {
    const pct = ((input.value - item.min) / (item.max - item.min)) * 100;
    input.style.setProperty("--fill", pct + "%");
    label.textContent = formatValue(item, Number(input.value));
    if (item.presets) {
      // いちばん近いものを光らせる。ちょうど一致だけを見ていたので、
      // 途中の数にすると「どれも選ばれていない」状態に見えていた。
      const now = Number(input.value);
      let nearest = 0;
      let best = Infinity;
      item.presets.forEach((preset, i) => {
        const gap = Math.abs(preset.value - now);
        if (gap < best) { best = gap; nearest = i; }
      });
      // 離れすぎている（いちばん近いものより、隣との差のほうが小さい）
      // ときは、どれも光らせない
      const span = item.max - item.min;
      const close = best <= span * 0.04;
      [...wrap.querySelectorAll(".segments button")].forEach((b, i) =>
        b.setAttribute("aria-pressed",
          close && i === nearest ? "true" : "false"));
    }
  };
  const commit = async (repaint) => {
    if (repaint) paint();
    const next = Number(input.value);
    STATE.values[item.key] = next;
    await setValue(item.key, next);
    afterChange(item.key);
  };
  input.addEventListener("input", paint);
  input.addEventListener("change", () => commit(false));
  wrap.append(input, label);
  paint();
  return wrap;
}

// 押されたキーを "ctrl+alt+v" のような指定にする。修飾キーだけなら "".
// ショートカットの欄と、クリップボードのグループ用のキーで共通に使う。
function hotkeySpecFromEvent(event) {
  const mods = ["Control", "Shift", "Alt", "Meta", "OS"];
  if (mods.includes(event.key)) return "";
  const parts = [];
  if (event.ctrlKey) parts.push("ctrl");
  if (event.shiftKey) parts.push("shift");
  if (event.altKey) parts.push("alt");
  if (event.metaKey) parts.push("win");
  const named = {
    " ": "space", Enter: "enter", Escape: "esc", Tab: "tab",
    Backspace: "backspace", Delete: "delete", Insert: "insert",
    Home: "home", End: "end", PageUp: "pageup", PageDown: "pagedown",
    ArrowLeft: "left", ArrowRight: "right", ArrowUp: "up", ArrowDown: "down",
    NonConvert: "muhenkan", Convert: "henkan", KanaMode: "kana",
    HankakuZenkaku: "hankaku", ZenkakuHankaku: "hankaku",
  };
  let key = named[event.key];
  if (!key && (event.code === "NonConvert" || event.keyCode === 29)) key = "muhenkan";
  if (!key && (event.code === "Convert" || event.keyCode === 28)) key = "henkan";
  if (!key && (event.code === "KanaMode" || event.keyCode === 242)) key = "kana";
  if (!key && /^F\d{1,2}$/.test(event.key)) key = event.key.toLowerCase();
  // Alt を押していると event.key が別の文字になることがあるので、
  // 英字・数字は物理キー（event.code）から取る
  if (!key && /^Key[A-Z]$/.test(event.code)) key = event.code.slice(3).toLowerCase();
  if (!key && /^Digit\d$/.test(event.code)) key = event.code.slice(5);
  if (!key && event.key.length === 1) key = event.key.toLowerCase();
  if (!key) return "";
  return [...parts, key].join("+");
}

function hotkeyControl(item, value) {
  const node = el("button", { class: "btn hotkey", type: "button" });
  const paint = () => { node.innerHTML = prettyHotkey(STATE.values[item.key]); };
  paint();

  const onKey = async (event) => {
    event.preventDefault();
    if (event.key === "Escape" && !event.ctrlKey && !event.altKey) { stop(); return; }
    const spec = hotkeySpecFromEvent(event);
    if (!spec) return;
    const before = STATE.values[item.key];
    STATE.values[item.key] = spec;
    stop();
    const res = await setValue(item.key, spec);
    if (res && res.ok === false) {
      // 録音と一覧のキーが同じ、などで断られた。元に戻して理由を出す
      STATE.values[item.key] = before;
      paint();
      toast(res.error || "");
      return;
    }
    afterChange(item.key);
  };
  const stop = () => {
    node.classList.remove("capturing");
    window.removeEventListener("keydown", onKey, true);
    paint();
  };
  node.addEventListener("click", () => {
    if (node.classList.contains("capturing")) { stop(); return; }
    node.classList.add("capturing");
    node.textContent = txt("settings.press_keys");
    window.addEventListener("keydown", onKey, true);
    node.addEventListener("blur", stop, { once: true });
  });

  const wrap = el("div", { class: "hotkey-wrap" });
  wrap.append(node);

  // hotkey の場合、初心者やシニアが押しやすいおすすめキーをワンクリック選択できるようにする
  if (item.key === "hotkey" || item.key === "clip_hotkey"
      || item.key === "recipe_hotkey") {
    const isJa = STATE?.lang !== "en";
    const quicks = item.key === "hotkey" ? [
      { spec: "muhenkan", label: isJa ? "無変換（親指ワンタッチ）" : "Muhenkan" },
      { spec: "henkan", label: isJa ? "変換" : "Henkan" },
      { spec: "ctrl+space", label: "Ctrl+Space (標準)" },
    ] : item.key === "recipe_hotkey" ? [
      { spec: "alt+r", label: isJa ? "Alt+R (標準)" : "Alt+R (default)" },
      { spec: "ctrl+alt+r", label: "Ctrl+Alt+R" },
      { spec: "win+alt+r", label: "Win+Alt+R" },
    ] : [
      // Ctrl+Shift+V は使わない：ターミナルの貼り付けで、koe-type 自身も
      // 送るキー。登録すると音声入力がターミナルに貼れなくなる。
      { spec: "alt+v", label: isJa ? "Alt+V (標準)" : "Alt+V (default)" },
      { spec: "ctrl+alt+v", label: "Ctrl+Alt+V" },
      { spec: "win+alt+v", label: "Win+Alt+V" },
    ];
    const quickGroup = el("div", { class: "hotkey-quicks", role: "group", "aria-label": "おすすめキー" });
    for (const q of quicks) {
      const qBtn = el("button", {
        type: "button", class: "btn quiet btn-quick-key",
        "aria-pressed": STATE.values[item.key] === q.spec ? "true" : "false",
        title: isJa ? `クリックで ${q.label} に設定` : `Set to ${q.label}`,
        on: { click: async () => {
          const res = await setValue(item.key, q.spec);
          if (res && res.ok === false) { toast(res.error || ""); return; }
          STATE.values[item.key] = q.spec;
          paint();
          for (const s of quickGroup.children) s.setAttribute("aria-pressed", "false");
          qBtn.setAttribute("aria-pressed", "true");
          afterChange(item.key);
        } }
      }, q.label);
      quickGroup.append(qBtn);
    }
    wrap.append(quickGroup);
  }
  return wrap;
}

function actionControl(item) {
  const isReset = item.panel === "reset";
  const isClearAll = item.panel === "clear_all_data";
  const danger = isReset || isClearAll;
  const icons = { open_log: ICONS.info, open_folder: ICONS.folder,
                  reset: ICONS.reset, clear_all_data: ICONS.trash,
                  diagnostics: ICONS.copy,
                  onboarding: ICONS.book, check_update: ICONS.info,
                  config_export: ICONS.download, config_import: ICONS.upload,
                  test_sound: ICONS.play, clip_history_clear: ICONS.trash,
                  clip_export: ICONS.download, clip_import: ICONS.upload };
  const node = el("button", {
    class: "btn" + (danger || item.panel === "clip_history_clear" ? " danger" : ""),
    type: "button",
  }, `${icons[item.panel] || ""}${item.label}`);
  node.addEventListener("click", async () => {
    if (item.panel === "clip_history_clear") {
      if (!(await confirmDialog(item.label, txt("cweb.clear_confirm")))) return;
      const res = await runAction("clip_history_clear", { keep_pinned: true });
      toast(txt("cweb.cleared").replace("{n}", String(res.removed || 0)));
      render();
      return;
    }
    if (item.panel === "clip_export") {
      const choice = await new Promise((resolve) => {
        openDialog((body, close) => {
          body.append(el("h3", {}, escapeHtml(item.label)));
          body.append(el("p", {}, escapeHtml(txt("cweb.export_secrets"))));
          const buttons = el("div", { class: "buttons" });
          buttons.append(el("button", { class: "btn", type: "button",
            on: { click: () => { close(); resolve(null); } } }, txt("common.cancel")));
          buttons.append(el("button", { class: "btn", type: "button",
            on: { click: () => { close(); resolve(false); } } }, txt("cweb.export_without")));
          buttons.append(el("button", { class: "btn accent", type: "button",
            on: { click: () => { close(); resolve(true); } } }, txt("cweb.export_with")));
          body.append(buttons);
        });
      });
      if (choice === null) return;
      const res = await runAction("clip_export", { include_secrets: choice });
      if (res && res.ok) {
        await saveText(res.name, res.text);
        toast(txt("web.done"));
      }
      return;
    }
    if (item.panel === "clip_import") {
      const input = el("input", { type: "file", accept: ".json" });
      input.addEventListener("change", async () => {
        const file = input.files[0];
        if (!file) return;
        const res = await runAction("clip_import", { text: await file.text() });
        if (res && res.ok) {
          toast(txt("cweb.imported").replace("{groups}", res.groups)
            .replace("{items}", res.items));
          render();
        } else {
          toast(txt("cweb.import_failed").replace("{err}", (res && res.error) || ""));
        }
      });
      input.click();
      return;
    }
    if (item.panel === "test_sound") {
      await runAction("test_sound");
      toast(item.label + " ♪");
      return;
    }

    if (isReset) {
      const yes = await confirmDialog(item.label, txt("settings.reset_confirm"));
      if (!yes) return;
      await runAction("reset");
      await load();
      toast(txt("settings.reset_done"));
      return;
    }

    if (isClearAll) {
      const yes = await confirmDialog(item.label,
        txt("settings.clear_all_confirm") ||
        "履歴・録音・ユーザー辞書・ログが完全に削除され、設定も初期値に戻ります。この操作は取り消せません。本当によろしいですか？");
      if (!yes) return;
      await runAction("clear_all_data");
      await load();
      toast(txt("settings.clear_all_done") || "すべての利用データを削除しました。");
      return;
    }

    // 設定を書き出す
    if (item.panel === "config_export") {
      const res = await runAction("config_export");
      if (res && res.ok) {
        await saveText(res.name || "koe-type-settings.json", res.text);
        toast(txt("settings.export_done"));
      }
      return;
    }

    // 設定を読み込む
    if (item.panel === "config_import") {
      const input = el("input", { type: "file", accept: ".json" });
      input.addEventListener("change", async () => {
        const file = input.files[0];
        if (!file) return;
        const text = await file.text();
        const yes = await confirmDialog(item.label,
          txt("settings.import_confirm"));
        if (!yes) return;
        const res = await runAction("config_import", { text });
        if (res && res.ok) {
          await load();
          toast((txt("settings.import_done") || "{n} 件読み込みました")
            .replace("{n}", res.count));
        } else {
          toast((txt("settings.import_failed") || "失敗")
            .replace("{err}", res.error || ""));
        }
      });
      input.click();
      return;
    }

    // 診断情報：外し忘れがあればサーバー側でコピーを止めている
    if (item.panel === "diagnostics") {
      const res = await runAction("diagnostics");
      if (res && res.ok) {
        toast("コピーしました（" + (res.chars || 0) +
              " 文字）。不具合報告にそのまま貼れます。");
      } else {
        toast("コピーできませんでした" +
              (res && res.error ? "：" + res.error : ""));
      }
      return;
    }

    // 初回の案内：同じ窓で開き直す
    if (item.panel === "onboarding") {
      await runAction("onboarding");
      location.href = "/onboarding?t=" + encodeURIComponent(TOKEN);
      return;
    }

    // 新しい版：結果をそのまま見せる
    if (item.panel === "check_update") {
      node.disabled = true;
      let res = null;
      try {
        res = await runAction("check_update");
      } finally {
        node.disabled = false;
      }
      const info = (res && res.update) || {};
      if (!info.ok) {
        await tellDialog("新しい版",
          info.error || "確かめられませんでした。");
      } else if (info.newer) {
        const ok = await confirmDialog("新しい版があります",
          "いまの版より新しい " + info.latest + " が出ています。\n" +
          "今すぐ自動でアップデートして再起動しますか？\n（設定や辞書、履歴はそのまま引き継がれます）",
          "今すぐアップデート", "あとで");
        if (ok) {
          node.disabled = true;
          const upRes = await runAction("apply_update");
          if (upRes && upRes.ok) {
            await tellDialog("アップデート中",
              "最新版をダウンロードして入れ替えています。完了後、自動で再起動します。");
          } else {
            node.disabled = false;
            await tellDialog("エラー",
              (upRes && upRes.error) || "アップデートに失敗しました。");
          }
        }
      } else {
        await tellDialog("新しい版",
          "いまのが最新です（" + (info.latest || "?") + "）。");
      }
      return;
    }

    await runAction(item.panel);
  });
  return node;
}

function afterChange(key) {
  if (key === "theme" || key === "ui_language") load();
  if (key === "ui_font_size") {
    document.documentElement.dataset.fontSize = STATE.values.ui_font_size || "normal";
  }
  if (key.startsWith("overlay_")) {
    updateOverlayPreview();
  }
}

/* ------------------------------------------------- 使わないアプリ */

function applistRow(item) {
  const row = el("div", { class: "row stack" });
  const head = el("div", {});
  head.append(el("div", { class: "label" }, item.label));
  if (item.help) head.append(el("div", { class: "help" }, item.help));
  row.append(head);

  const list = el("div", { class: "applist" });
  const save = async (next) => {
    STATE.values[item.key] = next;
    await setValue(item.key, next);
    paint();
  };
  const paint = () => {
    list.replaceChildren();
    const values = STATE.values[item.key] || [];
    if (!values.length) list.append(el("div", { class: "empty" }, txt("web.no_apps")));
    for (const name of values) {
      const entry = el("div", { class: "entry" });
      entry.append(el("span", {}, name));
      entry.append(el("button", {
        class: "btn quiet icon", type: "button", title: txt("common.delete"),
        "aria-label": `${name} ${txt("common.delete")}`,
        on: { click: () => save(values.filter((v) => v !== name)) },
      }, ICONS.trash));
      list.append(entry);
    }
    const adder = el("div", { class: "adder" });
    const input = el("input", { type: "text", placeholder: txt("web.app_placeholder"),
                                spellcheck: "false" });
    const add = () => {
      const name = input.value.trim();
      if (!name) return;
      if (!values.includes(name)) save([...values, name]);
      input.value = "";
    };
    input.addEventListener("keydown", (e) => { if (e.key === "Enter") add(); });
    adder.append(input);
    adder.append(el("button", { class: "btn", type: "button", on: { click: add } },
      `${ICONS.plus}${txt("web.add_app")}`));
    adder.append(el("button", {
      class: "btn", type: "button",
      on: { click: () => pickAppDialog(values, save) },
    }, `${ICONS.apps}${txt("web.pick_app")}`));
    list.append(adder);
  };
  paint();
  row.append(list);
  return row;
}

async function pickAppDialog(current, save) {
  const result = await runAction("running_apps");
  const apps = (result.apps || []).filter((a) => !current.includes(a.exe));
  openDialog((body, close) => {
    body.append(el("h3", {}, txt("web.pick_app_title")));
    const list = el("div", { class: "picklist" });
    if (!apps.length) list.append(el("div", { class: "empty" }, txt("web.no_apps")));
    for (const app of apps) {
      list.append(el("button", {
        type: "button",
        on: { click: () => { save([...current, app.exe]); close(); } },
      }, `<span>${escapeHtml(app.exe)}</span><small>${escapeHtml(app.title)}</small>`));
    }
    body.append(list);
    const buttons = el("div", { class: "buttons" });
    buttons.append(el("button", { class: "btn", type: "button", on: { click: close } },
      txt("common.cancel")));
    body.append(buttons);
  });
}

const escapeHtml = (s) => String(s).replace(/[&<>"]/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* ------------------------------------------------- モデル */

let moreModelsOpen = false;

function panelModels() {
  const wrap = el("div", { class: "models" });
  const paint = () => {
    wrap.replaceChildren();
    // ふだん使うのは常駐の 3 つ。旧方式と CPU 向けは畳んでおく
    // （6 つ並ぶと、はじめての人にはどれを選べばよいか分からない）。
    for (const model of STATE.models) {
      if (!model.legacy) wrap.append(modelCard(model));
    }
    const legacy = STATE.models.filter((m) => m.legacy);
    if (legacy.length) {
      const more = el("details", { class: "more-models" });
      // ダウンロード中は 1 秒ごとに描き直すので、開け閉めを覚えておく
      more.open = moreModelsOpen || legacy.some((m) => m.chosen);
      more.addEventListener("toggle", () => { moreModelsOpen = more.open; });
      more.append(el("summary", {}, txt("web.more_models")));
      const inner = el("div", { class: "models" });
      for (const model of legacy) inner.append(modelCard(model));
      more.append(inner);
      wrap.append(more);
    }
    wrap.append(el("div", { class: "hint" },
      txt("web.measured") + " " + txt("web.model_source")));
  };
  paint();
  wrap.dataset.refresh = "models";
  return wrap;
}

function modelCard(model) {
  const card = el("div", { class: "model" + (model.chosen ? " chosen" : "") });
  const dots = (n) => `<span class="dots">${
    [1, 2, 3, 4, 5].map((i) => `<i class="${i <= n ? "on" : ""}"></i>`).join("")}</span>`;

  const badge = model.chosen
    ? `<span class="badge on">${ICONS.check}${txt("common.inuse")}</span>`
    : model.ready
      ? `<span class="badge ready">${txt("common.installed")}</span>`
      : `<span class="badge">${txt("common.notinstalled")}</span>`;

  card.append(el("div", { class: "top" },
    `<h3>${escapeHtml(model.name)}</h3>${badge}`));
  card.append(el("p", {}, escapeHtml(model.summary)));
  card.append(el("p", { class: "note" }, escapeHtml(model.note)));
  card.append(el("div", { class: "meta" },
    `<span><b>${txt("model.cer_label")}</b>
       <em>${model.cer ? model.cer.toFixed(1) + "%" : "\u2014"}</em></span>
     <span><b>${txt("model.speed")}</b>${dots(model.speed)}</span>
     <span><b>${txt("model.size")}</b>${model.size}</span>
     <span><b>${txt("web.license")}</b>${escapeHtml(model.license)}</span>`));

  const actions = el("div", { class: "actions" });
  if (model.progress !== null && model.progress !== undefined) {
    const pct = Math.round(model.progress * 100);
    actions.append(el("div", { class: "bar" }, `<i style="width:${pct}%"></i>`));
    actions.append(el("span", { class: "value" },
      (STATE.text["model.downloading"] || "{pct}%").replace("{pct}", pct)));
  } else if (!model.ready) {
    actions.append(el("button", {
      class: "btn accent", type: "button",
      on: { click: async () => { await runAction("download_model", { model: model.key });
                                 refreshModels(); } },
    }, `${ICONS.download}${txt("common.download")}`));
  } else if (model.chosen) {
    // 使用中のモデルは消せない（消すと文字起こしができなくなるため）
    actions.append(el("span", { class: "inuse" },
      `${ICONS.check}${txt("web.inuse_note")}`));
  } else {
    actions.append(el("button", {
      class: "btn", type: "button",
      on: { click: async () => { await runAction("use_model", { model: model.key });
                                 refreshModels(); } },
    }, txt("common.use")));
    actions.append(el("button", {
      class: "btn quiet icon", type: "button", title: txt("common.delete"),
      "aria-label": `${model.name} ${txt("common.delete")}`,
      on: {
        click: async () => {
          const message = (STATE.text["model.delete_confirm"] || "")
            .replace("{name}", model.name);
          if (!(await confirmDialog(model.name, message))) return;
          await runAction("delete_model", { model: model.key });
          refreshModels();
        },
      },
    }, ICONS.trash));
  }
  const link = el("a", { href: model.source || model.licenseUrl, target: "_blank",
                         rel: "noreferrer noopener" }, txt("web.source"));
  link.style.marginLeft = "auto";
  actions.append(link);
  card.append(actions);
  return card;
}

async function refreshModels() {
  const data = await api("/api/poll");
  STATE.models = data.models;
  for (const model of STATE.models) {
    model.progress = data.progress[model.key];
  }
  if (PAGE === "transcription") render();
}

/* ------------------------------------------------- 辞書 */

function toHiraganaClient(text) {
  return String(text || "")
    .replace(/[\u30a1-\u30f6]/g, (m) => String.fromCharCode(m.charCodeAt(0) - 0x60))
    .replace(/ヴ/g, "ぶ");
}

function panelDictionary() {
  const wrap = el("div", {});
  const toolbar = el("div", { class: "toolbar" });
  const search = el("div", { class: "search" }, ICONS.search);
  const input = el("input", { type: "search", spellcheck: "false",
                              placeholder: txt("web.search_placeholder"),
                              value: dictFilter });
  input.addEventListener("input", () => { dictFilter = input.value; paint(); });
  search.append(input);
  toolbar.append(search);
  toolbar.append(el("button", {
    class: "btn accent", type: "button",
    on: { click: () => editEntry(null) },
  }, `${ICONS.plus}${txt("common.add")}`));

  const picker = el("input", { type: "file", accept: ".txt,.csv,text/plain",
                               hidden: "" });
  picker.addEventListener("change", async () => {
    const file = picker.files && picker.files[0];
    picker.value = "";
    if (!file) return;
    const r = await runAction("dict_import", { text: await file.text() });
    await reloadDict();
    toast(r.added > 0 ? `+${r.added}` : txt("web.import_none"));
  });
  const starterBtn = el("button", {
    class: "btn secondary", type: "button",
    title: txt("dict.add_starter_hint") || "Gmail、Slack、ChatGPT、ビジネス頻出フレーズなど50語以上を一括登録",
    on: { click: async () => {
      starterBtn.disabled = true;
      try {
        const r = await runAction("add_starter_words");
        if (r && r.ok) {
          await reloadDict();
          toast(r.added > 0 ? `定番・AI単語を ${r.added} 件追加しました！` : "すべて登録済みです");
        } else {
          toast(r?.error || "追加できませんでした");
        }
      } catch (e) {
        toast("通信エラーが発生しました");
      } finally {
        starterBtn.disabled = false;
      }
    } },
  }, `✨ ${txt("dict.add_starter") || "定番・AI単語パックを追加"}`);
  toolbar.append(starterBtn);
  toolbar.append(picker);
  toolbar.append(el("button", {
    class: "btn", type: "button",
    on: { click: () => picker.click() },
  }, txt("common.import")));
  toolbar.append(el("button", {
    class: "btn", type: "button",
    on: { click: async () => {
      const r = await runAction("dict_export");
      if (await saveText(r.name, r.text || "")) toast(txt("web.done"));
    } },
  }, txt("common.export")));
  const count = el("div", { class: "count" });
  toolbar.append(count);

  const card = el("div", { class: "card" });
  const table = el("div", { class: "table" });
  card.append(table);

  const paint = () => {
    const query = dictFilter.trim().toLowerCase();
    const rows = DICT.filter((e) => {
      if (!query) return true;
      return (e.surface && e.surface.toLowerCase().includes(query)) ||
             (e.reading && e.reading.toLowerCase().includes(query)) ||
             (e.mishearing && e.mishearing.toLowerCase().includes(query));
    });
    count.textContent = (STATE.text["dict.count"] || "{n}").replace("{n}", DICT.length);
    table.replaceChildren();

    const html = `<table><thead><tr>
        <th>${txt("dict.to")}</th>
        <th>${txt("dict.reading")}</th>
        <th>${txt("dict.from")}</th>
        <th>${txt("dict.type")}</th>
        <th></th>
      </tr></thead><tbody></tbody></table>`;
    table.innerHTML = html;
    if (!DICT.length) {
      table.append(el("div", { class: "empty pad" }, txt("dict.empty")));
      return;
    }
    const body = table.querySelector("tbody");
    for (const entry of rows) {
      const tr = el("tr", {});
      tr.append(el("td", { class: "bold" }, escapeHtml(entry.surface)));
      tr.append(el("td", {}, escapeHtml(entry.reading || "—")));
      tr.append(el("td", { class: "quiet-text" },
        escapeHtml(entry.mishearing || (entry.is_regex ? "正規表現" : "—"))));
      const typeBadge = el("td", {});
      const isDirect = Boolean(entry.mishearing || entry.is_regex);
      typeBadge.append(el("span", {
        class: "badge " + (isDirect ? "badge-direct" : "badge-auto")
      }, isDirect ? txt("dict.type_direct") : txt("dict.type_auto")));
      tr.append(typeBadge);

      const actions = el("td", { class: "actions" });
      actions.append(el("button", {
        class: "btn quiet icon", type: "button", title: txt("common.delete"),
        on: { click: (e) => { e.stopPropagation(); removeEntry(entry); } },
      }, ICONS.trash));
      tr.append(actions);
      tr.addEventListener("dblclick", () => editEntry(entry));
      body.append(tr);
    }
  };

  const reloadDict = async () => {
    const fresh = await api("/api/state");
    DICT = (fresh.dictionary || []).map(normDictEntry);
    paint();
  };
  const save = async () => {
    await runAction("dict_save", { rows: DICT });
    paint();
  };
  const removeEntry = (entry) => {
    DICT = DICT.filter((r) => r !== entry);
    save();
  };
  const editEntry = (entry) => {
    openDialog((body, close) => {
      body.append(el("h3", {}, entry ? txt("common.edit") : txt("common.add")));
      const fields = el("div", { class: "fields" });

      const surfaceInput = el("input", {
        type: "text", spellcheck: "false",
        placeholder: "例: サイバーエージェント、オープンLabo",
        value: entry ? entry.surface : ""
      });
      const readingInput = el("input", {
        type: "text", spellcheck: "false",
        placeholder: "例: さいばーえーじぇんと、きょうそうらぼ",
        value: entry ? entry.reading : ""
      });
      let autoReading = !entry;

      surfaceInput.addEventListener("input", () => {
        if (autoReading) {
          readingInput.value = toHiraganaClient(surfaceInput.value.trim());
        }
      });
      readingInput.addEventListener("input", () => {
        autoReading = false;
      });

      const wrapSurface = el("div", {}, `<label>${txt("dict.to")}</label>`);
      wrapSurface.append(surfaceInput);
      const wrapReading = el("div", {}, `<label>${txt("dict.reading")}</label>`);
      wrapReading.append(readingInput);
      fields.append(wrapSurface, wrapReading);

      // 上級者向け：特定の聞き間違い指定
      const advWrap = el("div", { class: "dict-adv-wrap" });
      const advCheck = el("input", { type: "checkbox", id: "dict_adv_toggle" });
      if (entry && entry.mishearing) advCheck.checked = true;
      const advLabel = el("label", { for: "dict_adv_toggle", class: "check-label" },
        txt("dict.advanced"));
      advWrap.append(advCheck, advLabel);

      const mishearingField = el("div", { class: "field-group" });
      mishearingField.hidden = !advCheck.checked;
      const mishearingInput = el("input", {
        type: "text", spellcheck: "false",
        placeholder: "例: 裁判エージェント",
        value: entry ? entry.mishearing : ""
      });
      mishearingField.append(el("label", {}, txt("dict.from")), mishearingInput);

      advCheck.addEventListener("change", () => {
        mishearingField.hidden = !advCheck.checked;
        if (advCheck.checked) mishearingInput.focus();
      });

      fields.append(advWrap, mishearingField);
      body.append(fields);

      const buttons = el("div", { class: "buttons" });
      buttons.append(el("button", { class: "btn", type: "button",
                                    on: { click: close } }, txt("common.cancel")));
      const confirm = el("button", { class: "btn accent", type: "button" },
        txt("common.save"));

      const apply = () => {
        const s = surfaceInput.value.trim();
        if (!s) { surfaceInput.focus(); return; }
        const r = readingInput.value.trim() || toHiraganaClient(s);
        const m = advCheck.checked ? mishearingInput.value.trim() : "";

        if (entry) {
          entry.surface = s;
          entry.reading = r;
          entry.mishearing = m;
        } else {
          if (DICT.some((x) => x.surface === s && x.mishearing === m)) {
            toast(txt("dict.dup"));
            return;
          }
          DICT.push({ surface: s, reading: r, mishearing: m, is_regex: false });
        }
        close();
        save();
      };
      confirm.addEventListener("click", apply);
      surfaceInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") readingInput.focus();
      });
      readingInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") {
          if (advCheck.checked) mishearingInput.focus();
          else apply();
        }
      });
      mishearingInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter") apply();
      });
      buttons.append(confirm);
      body.append(buttons);
      setTimeout(() => surfaceInput.focus(), 30);
    });
  };

  paint();
  wrap.append(toolbar, card);
  wrap.append(el("div", { class: "hint" }, txt("web.dict_hint")));
  return wrap;
}

/* ------------------------------------------------- 履歴 */

function panelHistory() {
  const wrap = el("div", {});
  const toolbar = el("div", { class: "toolbar" });
  const copy = el("button", {
    class: "btn", type: "button", disabled: true,
    on: { click: () => {
      const picked = STATE.history.filter((h) => historySelection.has(h.id));
      // 時系列順（古い順＝話した順）に並べ替えて自然に連結する
      picked.sort((a, b) => a.id - b.id);
      const combined = picked.map((h) => h.text).join(" ");
      runAction("copy", { text: combined });
      toast(txt("history.copied"));
    } },
  }, `${ICONS.copy}${txt("common.copy")}`);
  const merge = el("button", {
    class: "btn", type: "button", disabled: true,
    on: { click: async () => {
      if (historySelection.size < 2) return;
      const res = await runAction("history_merge", { ids: [...historySelection] });
      if (res && res.ok) {
        historySelection.clear();
        if (res.id) historySelection.add(res.id);
        await reload();
        toast(txt("history.merged"));
      }
    } },
  }, `${ICONS.link}${txt("history.merge")}`);
  const remove = el("button", {
    class: "btn danger", type: "button", disabled: true,
    on: { click: async () => {
      await runAction("history_delete", { ids: [...historySelection] });
      historySelection.clear();
      await reload();
    } },
  }, `${ICONS.trash}${txt("common.delete")}`);
  const clear = el("button", {
    class: "btn danger", type: "button", disabled: true,
    on: { click: async () => {
      if (!(await confirmDialog(txt("common.clear"), txt("history.clear_confirm")))) return;
      await runAction("history_clear");
      historySelection.clear();
      await reload();
    } },
  }, txt("common.clear"));
  const count = el("div", { class: "count" });
  // 昔言ったことを探せるように（200 件たまると目では探せない）
  const search = el("div", { class: "search" }, ICONS.search);
  const input = el("input", { type: "search", spellcheck: "false",
                              placeholder: txt("history.search"),
                              value: historyFilter });
  input.addEventListener("input", () => { historyFilter = input.value; paint(); });
  search.append(input);
  toolbar.append(search, copy, merge, remove, clear, count);

  const card = el("div", { class: "card" });
  const table = el("div", { class: "table" });
  card.append(table);

  // 録音をその場で聞き直す。聞き違いか、言い間違いかを確かめるため。
  const play = (entry) => {
    if (historyPlayer) { historyPlayer.pause(); historyPlayer = null; }
    if (historyPlaying === entry.id) { historyPlaying = 0; paint(); return; }
    const url = "/api/history_audio?t=" + encodeURIComponent(TOKEN)
      + "&id=" + entry.id;
    historyPlayer = new Audio(url);
    historyPlaying = entry.id;
    historyPlayer.addEventListener("ended", () => {
      historyPlaying = 0; historyPlayer = null; paint();
    });
    historyPlayer.play().catch(() => {
      historyPlaying = 0; historyPlayer = null;
      toast(txt("history.play_failed")); paint();
    });
    paint();
  };

  // 聞き違えた言葉を、そのまま辞書の置き換えに登録する。
  // 行の中で一部を選んでいれば、その部分を「元」に入れる。
  const toDictionary = (entry) => {
    const picked = String(window.getSelection() || "").trim();
    const source = picked && entry.text.includes(picked) ? picked : "";
    openDialog((body, close) => {
      body.append(el("h3", {}, txt("history.to_dict_title")));
      body.append(el("p", { class: "dialog-note" },
        escapeHtml(txt("history.to_dict_hint"))));
      body.append(el("p", { class: "dialog-quote" }, escapeHtml(entry.text)));
      const fields = el("div", { class: "fields" });
      const from = el("input", { type: "text", spellcheck: "false",
                                 value: source });
      const to = el("input", { type: "text", spellcheck: "false" });
      const wrapFrom = el("div", {}, `<label>${txt("dict.from")}</label>`);
      wrapFrom.append(from);
      const wrapTo = el("div", {}, `<label>${txt("dict.to")}</label>`);
      wrapTo.append(to);
      fields.append(wrapFrom, wrapTo);
      body.append(fields);
      const buttons = el("div", { class: "buttons" });
      buttons.append(el("button", { class: "btn", type: "button",
                                    on: { click: close } }, txt("common.cancel")));
      const save = el("button", { class: "btn accent", type: "button" },
        txt("common.save"));
      const apply = async () => {
        const a = from.value.trim();
        const b = to.value.trim();
        if (!a && !b) { from.focus(); return; }
        const r = await runAction("dict_add", {
          from: a,
          to: b || a,
          reading: toHiraganaClient(b || a),
        });
        close();
        toast(r.ok ? txt("history.to_dict_done") : txt("dict.dup"));
      };
      save.addEventListener("click", apply);
      from.addEventListener("keydown", (e) => { if (e.key === "Enter") to.focus(); });
      to.addEventListener("keydown", (e) => { if (e.key === "Enter") apply(); });
      buttons.append(save);
      body.append(buttons);
      setTimeout(() => (source ? to : from).focus(), 30);
    });
  };

  const paint = () => {
    const all = STATE.history;
    const query = historyFilter.trim().toLowerCase();
    const rows = query
      ? all.filter((h) => h.text.toLowerCase().includes(query))
      : all;
    // 0 件のときに押せると、無意味で怖い確認が出てしまう
    clear.disabled = all.length === 0;
    count.textContent = (STATE.text["dict.count"] || "{n}").replace("{n}", rows.length);
    copy.disabled = remove.disabled = historySelection.size === 0;
    merge.disabled = historySelection.size < 2;
    table.replaceChildren();
    if (!rows.length) {
      const message = query ? txt("history.no_match")
        : STATE.values.history_limit > 0
          ? txt("history.empty") : txt("history.off");
      table.append(el("div", { class: "empty pad" }, message));
      return;
    }
    table.innerHTML = `<table><thead><tr>
        <th>${txt("history.time")}</th><th>${txt("history.text")}</th><th></th>
      </tr></thead><tbody></tbody></table>`;
    const body = table.querySelector("tbody");
    for (const entry of rows) {
      const tr = el("tr", { "aria-selected": historySelection.has(entry.id) });
      tr.append(el("td", { class: "time" }, entry.time));

      // テキスト欄（整形前との差分があれば表示）
      const textTd = el("td", { class: "text" });
      textTd.append(el("div", { class: "history-final" }, escapeHtml(entry.text)));
      if (entry.raw_text && entry.raw_text !== entry.text) {
        textTd.append(el("div", { class: "history-raw quiet-text" },
          `${txt("history.raw_label")}: ${escapeHtml(entry.raw_text)}`));
      }
      tr.append(textTd);

      const actions = el("td", { class: "actions wide" });
      // クリップボードへコピー
      actions.append(el("button", {
        class: "btn quiet icon", type: "button",
        title: txt("history.copy_item"), "aria-label": txt("history.copy_item"),
        on: { click: (e) => {
          e.stopPropagation();
          runAction("copy", { text: entry.text });
          toast(txt("history.copied"));
        } },
      }, ICONS.copy));
      // 前面のアプリにもう一度入力（貼り直し）
      actions.append(el("button", {
        class: "btn quiet icon", type: "button",
        title: txt("history.paste_item"), "aria-label": txt("history.paste_item"),
        on: { click: (e) => {
          e.stopPropagation();
          runAction("paste_text", { text: entry.text });
          toast(txt("history.pasted"));
        } },
      }, ICONS.type));
      if (entry.audio) {
        const playing = historyPlaying === entry.id;
        actions.append(el("button", {
          class: "btn quiet icon", type: "button",
          title: txt(playing ? "history.stop" : "history.play"),
          "aria-label": txt(playing ? "history.stop" : "history.play"),
          on: { click: (e) => { e.stopPropagation(); play(entry); } },
        }, playing ? ICONS.stop : ICONS.play));
      }
      actions.append(el("button", {
        class: "btn quiet icon", type: "button",
        title: txt("history.to_dict"), "aria-label": txt("history.to_dict"),
        on: { click: (e) => { e.stopPropagation(); toDictionary(entry); } },
      }, ICONS.book));
      tr.append(actions);
      tr.addEventListener("click", () => {
        // 文字を選んでいる最中のクリックは、行の選択にしない
        if (String(window.getSelection() || "").trim()) return;
        if (historySelection.has(entry.id)) historySelection.delete(entry.id);
        else historySelection.add(entry.id);
        paint();
      });
      body.append(tr);
    }
  };
  const reload = async () => {
    const fresh = await api("/api/state");
    STATE.history = fresh.history;
    paint();
  };

  paint();
  wrap.append(toolbar, card);
  wrap.append(el("div", { class: "hint" }, txt("web.history_hint")));
  return wrap;
}

/* ------------------------------------------------- 情報 */

function panelAbout() {
  return el("div", { class: "about" },
    `<b>SpeakPulse ${STATE.version}</b><br>${txt("web.about_line")}<br>
     ${txt("web.about_folder")}`);
}

/* ------------------------------------------------- ダイアログ */

function openDialog(build) {
  const scrim = document.getElementById("scrim");
  const dialog = document.getElementById("dialog");
  dialog.replaceChildren();
  // 前のダイアログが付けた見た目（広い窓など）を残さない
  dialog.className = "dialog";
  const close = () => {
    scrim.hidden = true;
    window.removeEventListener("keydown", onEsc, true);
  };
  const onEsc = (e) => { if (e.key === "Escape") { e.stopPropagation(); close(); } };
  window.addEventListener("keydown", onEsc, true);
  build(dialog, close);
  scrim.hidden = false;
}

function tellDialog(title, message) {
  // 知らせるだけ（「はい／いいえ」ではなく「閉じる」1 つ）
  return new Promise((resolve) => {
    openDialog((body, close) => {
      body.append(el("h3", {}, title));
      body.append(el("p", {}, message));
      const buttons = el("div", { class: "buttons" });
      buttons.append(el("button", {
        class: "btn accent", type: "button",
        on: { click: () => { close(); resolve(true); } },
      }, txt("common.close") || "閉じる"));
      body.append(buttons);
    });
  });
}

function confirmDialog(title, message) {
  return new Promise((resolve) => {
    openDialog((body, close) => {
      body.append(el("h3", {}, title));
      body.append(el("p", {}, message));
      const buttons = el("div", { class: "buttons" });
      buttons.append(el("button", {
        class: "btn", type: "button",
        on: { click: () => { close(); resolve(false); } },
      }, txt("common.cancel")));
      buttons.append(el("button", {
        class: "btn accent", type: "button",
        on: { click: () => { close(); resolve(true); } },
      }, txt("web.confirm")));
      body.append(buttons);
    });
  });
}

/* ------------------------------------------------- 常時 */

let _serverToken = null;
let _wasDisconnected = false;

// アプリ側へ「まだ開いています」と伝える。切れたらアプリがサーバーを閉じる。
// アプリが再起動（ホットリロード）されたら自動で画面を再読み込みして最新設定を反映する。
setInterval(() => {
  api("/api/beat", {}).then((res) => {
    if (res && res.token) {
      if (_serverToken === null) {
        _serverToken = res.token;
      } else if (_serverToken !== res.token || _wasDisconnected) {
        location.reload();
      }
    }
    _wasDisconnected = false;
  }).catch(() => {
    _wasDisconnected = true;
  });
}, 2000);

// ダウンロードの進み具合などを拾う
setInterval(async () => {
  if (!STATE) return;
  try {
    const data = await api("/api/poll");
    let changed = false;
    for (const model of STATE.models) {
      const next = data.progress[model.key];
      if (next !== model.progress) { changed = true; }
    }
    for (const event of data.events) {
      if (event.type === "download_done") {
        changed = true;
        toast(event.error
          ? (STATE.text["model.download_failed"] || "{err}").replace("{err}", event.error)
          : txt("web.done"));
      } else if (event.type === "navigate" && event.page === "onboarding") {
        // 案内は別のページ。この画面の中には描けない（描くと空になる）
        location.href = "/onboarding?t=" + encodeURIComponent(TOKEN);
      } else if (event.type === "navigate" && event.page) {
        PAGE = event.page;
        render();
      } else if (event.type === "clip_edit" && event.id) {
        // クリップボードの一覧で「編集」を選んだ
        PAGE = "clipboard"; clearSearch(); render();
        openClipItemDialog({ id: event.id });
      } else if (event.type === "clip_new_group") {
        PAGE = "clipboard"; clearSearch(); render();
        clipNewGroupDialog();
      }
    }
    if (changed) { await refreshModels(); }
  } catch { /* 閉じている最中 */ }
}, 900);

window.addEventListener("pagehide", () => {
  navigator.sendBeacon?.("/api/close?t=" + encodeURIComponent(TOKEN), "{}");
});

// 「使わないアプリ」は行ごと差し替えるので、描画のあとで入れ替える
const originalRender = render;
render = function () {
  originalRender();
  const cat = STATE.categories.find((c) => c.key === PAGE);
  if (!cat) return;
  for (const group of cat.groups) {
    for (const item of group.items) {
      if (item.kind !== "applist") continue;
      const rows = [...document.querySelectorAll(".row")];
      const target = rows.find((r) =>
        r.querySelector(".label")?.textContent === item.label);
      if (target) target.replaceWith(applistRow(item));
    }
  }
};


/* ------------------------------------------------- つなぎ言葉の一覧 */

function panelFillers() {
  const wrap = el("div", {});
  const card = el("div", { class: "card pad" });
  const chips = el("div", { class: "chips" });
  const row = el("div", { class: "inline" });
  const input = el("input", {
    type: "text", spellcheck: "false",
    placeholder: txt("fillers.placeholder"),
  });
  const add = el("button", { class: "btn accent", type: "button" },
                 `${ICONS.plus}${txt("common.add")}`);

  const current = () => (STATE.values.filler_words || []).slice();

  const save = async (list) => {
    await setValue("filler_words", list);
    STATE.values.filler_words = list;
    paint();
  };

  const paint = () => {
    const list = current();
    chips.replaceChildren();
    if (!list.length) {
      chips.append(el("div", { class: "empty" }, txt("fillers.default")));
    }
    for (const word of list) {
      const chip = el("span", { class: "chip" }, escapeHtml(word));
      chip.append(el("button", {
        class: "chip-x", type: "button", title: txt("common.delete"),
        on: { click: () => save(list.filter((w) => w !== word)) },
      }, "\u00d7"));
      chips.append(chip);
    }
  };

  const commit = () => {
    const word = input.value.trim();
    if (!word) return;
    const list = current();
    if (!list.includes(word)) list.push(word);
    input.value = "";
    save(list);
  };
  add.addEventListener("click", commit);
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); commit(); }
  });

  row.append(input, add);
  const reset = el("button", { class: "btn", type: "button",
    on: { click: () => save([]) } }, txt("fillers.reset"));
  card.append(chips, row, reset);
  wrap.append(card);
  paint();
  return wrap;
}

/* ------------------------------------------------- 音声コマンド */

function panelCommands() {
  const wrap = el("div", {});
  const card = el("div", { class: "card" });
  const table = el("div", { class: "table" });
  card.append(table);

  const off = () => (STATE.values.voice_command_off || []).slice();

  const toggle = async (name, on) => {
    let list = off();
    list = on ? list.filter((n) => n !== name) : list.concat([name]);
    await setValue("voice_command_off", list);
    STATE.values.voice_command_off = list;
    paint();
  };

  const paint = () => {
    const disabled = off();
    table.innerHTML = `<table><thead><tr>
        <th>${txt("commands.say")}</th><th>${txt("commands.does")}</th>
        <th>${txt("commands.on")}</th>
      </tr></thead><tbody></tbody></table>`;
    const body = table.querySelector("tbody");
    for (const cmd of (STATE.commands || [])) {
      const tr = el("tr", {});
      tr.append(el("td", {}, escapeHtml(cmd.phrases.join(" / "))));
      tr.append(el("td", {}, escapeHtml(cmd.label)));
      const cell = el("td", { class: "actions" });
      const on = !disabled.includes(cmd.name);
      const sw = el("button", {
        class: "switch" + (on ? " on" : ""), type: "button",
        role: "switch", "aria-checked": on ? "true" : "false",
        on: { click: () => toggle(cmd.name, !on) },
      }, '<span class="knob"></span>');
      cell.append(sw);
      tr.append(cell);
      body.append(tr);
    }
  };
  paint();
  wrap.append(card);
  return wrap;
}

/* ------------------------------------------------- 記号の呼び方 */

function panelSymbols() {
  const wrap = el("div", {});
  const card = el("div", { class: "card" });
  const table = el("div", { class: "table" });
  const addRow = el("div", { class: "toolbar pad" });

  const getList = () => {
    const raw = STATE.values.symbol_commands;
    if (Array.isArray(raw)) return raw.slice();
    return [];
  };

  const save = async (list) => {
    STATE.values.symbol_commands = list;
    await setValue("symbol_commands", list);
    paint();
  };

  const toggle = (idx) => {
    const list = getList();
    if (list[idx]) {
      list[idx].enabled = !list[idx].enabled;
      save(list);
    }
  };

  const remove = (idx) => {
    const list = getList();
    list.splice(idx, 1);
    save(list);
  };

  const add = (word, symbol) => {
    word = (word || "").trim();
    symbol = symbol || "";
    if (!word || !symbol) return;
    const list = getList();
    list.push({ word, symbol, enabled: true });
    save(list);
  };

  const inputWord = el("input", {
    type: "text",
    placeholder: txt("symbols.word_placeholder") || "言葉（例：びっくり）",
    style: "max-width: 160px;",
  });
  const inputSymbol = el("input", {
    type: "text",
    placeholder: txt("symbols.symbol_placeholder") || "記号（例：！）",
    style: "max-width: 120px;",
  });
  const btnAdd = el("button", {
    class: "btn primary",
    type: "button",
    on: {
      click: () => {
        add(inputWord.value, inputSymbol.value);
        inputWord.value = "";
        inputSymbol.value = "";
      },
    },
  }, txt("symbols.add") || "追加");

  inputWord.addEventListener("keydown", (e) => {
    if (e.key === "Enter") inputSymbol.focus();
  });
  inputSymbol.addEventListener("keydown", (e) => {
    if (e.key === "Enter") btnAdd.click();
  });

  addRow.append(inputWord, inputSymbol, btnAdd);

  const paint = () => {
    const list = getList();
    table.innerHTML = `<table><thead><tr>
        <th>${txt("symbols.say") || "言葉"}</th>
        <th>${txt("symbols.symbol") || "記号"}</th>
        <th>${txt("symbols.on") || "使う"}</th>
        <th></th>
      </tr></thead><tbody></tbody></table>`;
    const body = table.querySelector("tbody");
    if (list.length === 0) {
      const tr = el("tr", {});
      tr.append(el("td", { colspan: "4", class: "empty-note" },
        txt("symbols.empty") || "登録されている言葉はありません"));
      body.append(tr);
    } else {
      list.forEach((item, idx) => {
        const tr = el("tr", {});
        tr.append(el("td", {}, escapeHtml(item.word)));
        const symLabel = item.symbol === "\n" ? "改行" : item.symbol;
        tr.append(el("td", { class: "mono" }, escapeHtml(symLabel)));
        const cellSw = el("td", { class: "actions" });
        const on = Boolean(item.enabled);
        const sw = el("button", {
          class: "switch" + (on ? " on" : ""), type: "button",
          role: "switch", "aria-checked": on ? "true" : "false",
          on: { click: () => toggle(idx) },
        }, '<span class="knob"></span>');
        cellSw.append(sw);
        tr.append(cellSw);

        const cellDel = el("td", { class: "actions" });
        const btnDel = el("button", {
          class: "btn quiet", type: "button",
          on: { click: () => remove(idx) },
        }, "×");
        cellDel.append(btnDel);
        tr.append(cellDel);

        body.append(tr);
      });
    }
  };

  paint();
  card.append(table, addRow);
  wrap.append(card);
  return wrap;
}

/* ------------------------------------------------- 動作チェック */

function panelSelfcheck() {
  // 既定は結果を 1 行だけ出す。初めて使う人に、技術的な一覧を
  // いきなり見せないため。問題がある行だけは畳まずに出す。
  const wrap = el("div", {});
  const card = el("div", { class: "card" });
  const list = el("div", { class: "checks", hidden: true });
  const bar = el("div", { class: "toolbar pad" });
  const verdict = el("div", { class: "verdict" }, txt("doctor.running"));
  const more = el("button", { class: "btn quiet", type: "button",
                              hidden: true }, txt("doctor.details"));
  const run = el("button", { class: "btn", type: "button" },
                 txt("doctor.again"));
  bar.append(verdict, more, run);
  card.append(bar, list);
  wrap.append(card);

  const MARK = { ok: "\u2713", warn: "!", bad: "\u00d7", info: "i" };
  let open = false;
  let latest = null;

  const row = (r) => {
    const item = el("div", { class: "check " + r.status });
    item.append(el("span", { class: "check-mark" }, MARK[r.status] || "?"));
    const body = el("div", { class: "check-body" });
    body.append(el("div", { class: "label" }, escapeHtml(r.title)));
    if (r.detail) {
      body.append(el("div", { class: "help" }, escapeHtml(r.detail)));
    }
    if (r.fix && (r.status === "warn" || r.status === "bad")) {
      body.append(el("div", { class: "fix" },
        `${ICONS.info}${escapeHtml(r.fix)}`));
    }
    item.append(body);
    return item;
  };

  const paintList = () => {
    if (!latest) return;
    // 畳んでいるときは、問題のある行だけ見せる
    const rows = open ? latest.results
      : latest.results.filter((r) => r.status === "warn" || r.status === "bad");
    list.replaceChildren(...rows.map(row));
    list.hidden = rows.length === 0;
    more.textContent = open ? txt("doctor.hide") : txt("doctor.details");
  };

  const paint = (data) => {
    latest = data;
    const c = data.summary.counts;
    const key = c.bad ? "doctor.some_bad"
      : (c.warn ? "doctor.some_warn" : "doctor.all_ok");
    verdict.textContent = (STATE.text[key] || "")
      .replace("{n}", data.summary.checked || data.results.length)
      .replace("{warn}", c.warn).replace("{bad}", c.bad);
    verdict.className = "verdict " + data.summary.overall;
    more.hidden = false;
    paintList();
  };

  const go = async () => {
    run.disabled = true;
    verdict.textContent = txt("doctor.running");
    try {
      paint(await runAction("selfcheck"));
    } catch (err) {
      verdict.textContent = String(err);
    } finally {
      run.disabled = false;
      run.textContent = txt("doctor.again");
    }
  };
  more.addEventListener("click", () => { open = !open; paintList(); });
  run.addEventListener("click", go);
  go();
  return wrap;
}

/* ------------------------------------------------------------ AI自動編集・カスタム指示 */

// 最初から入っている変換（schema の既定値）。指示文を元に戻すときに使う。
function builtinInstructions() {
  for (const cat of STATE.categories) {
    for (const group of cat.groups) {
      for (const item of group.items) {
        if (item.key === "ai_custom_instructions") return item.default || [];
      }
    }
  }
  return [];
}

function panelAiEditor() {
  const wrap = el("div", { class: "ai-editor-page" });

  const getInstructions = () => {
    return (STATE.values.ai_custom_instructions || []).map((x) => ({ ...x }));
  };

  const saveInstructions = async (list) => {
    STATE.values.ai_custom_instructions = list;
    await setValue("ai_custom_instructions", list);
    paint();
  };

  // APIキー & プロバイダー設定ダイアログ
  const openApiKeyDialog = () => {
    openDialog((body, close) => {
      body.classList.add("dialog-wide");
      body.append(el("h3", {}, "AI (LLM) 連携・プロバイダー設定"));

      const PROVIDERS = [
        {
          id: "gemini",
          name: "Google Gemini",
          desc: "無料枠充実・超高速",
          placeholder: "AIzaSy...",
          hint: "Google AI Studio で無料取得した API キーを入力してください。クレジットカード不要で即座に発行でき、高速かつ自然に文章を整えます。",
          link: "https://aistudio.google.com/app/apikey",
          linkText: "Google AI Studio でキーを取得（無料） ›",
          defaultModel: "gemini-3.8-flash",
          models: [
            { id: "gemini-3.8-flash", name: "Gemini 3.8 Flash（推奨・最新超高速・思考対応）" },
            { id: "gemini-3.6-flash", name: "Gemini 3.6 Flash（高速・安定）" },
            { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash（軽量高速・高互換）" },
            { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro（長文・最高精度）" },
            { id: "custom", name: "自由に入力（手動指定）…" },
          ],
        },
        {
          id: "openrouter",
          name: "OpenRouter",
          desc: "Claude / GPT-4o / DeepSeek 対応",
          placeholder: "sk-or-v1-...",
          hint: "OpenRouter の API キーを設定すると、Claude 3.5 Sonnet、GPT-4o、DeepSeek、Llama など世界の主要モデルを 1 つのキーで自由に選んで使えます。",
          link: "https://openrouter.ai/keys",
          linkText: "OpenRouter でキーを取得 ›",
          defaultModel: "google/gemini-2.0-flash-001",
          models: [
            { id: "google/gemini-2.0-flash-001", name: "Gemini 2.0 Flash（超高速・最安・画像解析対応）" },
            { id: "anthropic/claude-3.5-sonnet", name: "Claude 3.5 Sonnet（最高峰の文章力・知性）" },
            { id: "openai/gpt-4o-mini", name: "GPT-4o Mini（高速・低コスト）" },
            { id: "deepseek/deepseek-chat", name: "DeepSeek V3 / Chat（超高コスパ・優秀）" },
            { id: "meta-llama/llama-3.3-70b-instruct", name: "Llama 3.3 70B（オープンモデル最高峰）" },
            { id: "custom", name: "自由に入力（手動指定）…" },
          ],
        },
        {
          id: "claude",
          name: "Anthropic Claude",
          desc: "公式 API 直接接続",
          placeholder: "sk-ant-...",
          hint: "Anthropic Console で取得した API キーを入力してください。極めて自然な日本語と文脈理解力を発揮します。",
          link: "https://console.anthropic.com/settings/keys",
          linkText: "Anthropic Console でキーを取得 ›",
          defaultModel: "claude-3-5-haiku-20241022",
          models: [
            { id: "claude-3-5-haiku-20241022", name: "Claude 3.5 Haiku（推奨・爆速・低コスト）" },
            { id: "claude-3-5-sonnet-20241022", name: "Claude 3.5 Sonnet（最高峰の知性）" },
          ],
        },
      ];

      let curProvId = STATE.values.ai_provider || "gemini";
      if (curProvId === "auto") {
        const k = (STATE.values.ai_api_key || "").trim();
        if (k.startsWith("sk-or-")) curProvId = "openrouter";
        else if (k.startsWith("sk-ant-")) curProvId = "claude";
        else curProvId = "gemini";
      }

      // プロバイダー切り替えタブ
      const tabsWrap = el("div", { class: "ai-prov-tabs", role: "tablist" });
      const container = el("div", { class: "ai-prov-container", style: "margin-top: 14px;" });

      const renderProv = (provId) => {
        curProvId = provId;
        const prov = PROVIDERS.find((p) => p.id === provId) || PROVIDERS[0];
        tabsWrap.querySelectorAll(".ai-prov-tab").forEach((t) => {
          t.classList.toggle("active", t.dataset.id === provId);
        });

        container.replaceChildren();

        const pDesc = el("p", { class: "hint", style: "margin-bottom: 12px;" });
        pDesc.innerHTML = `${prov.hint}<br><a href="${prov.link}" target="_blank" rel="noreferrer" style="color: var(--accent); text-decoration: underline;">${prov.linkText}</a>`;

        const fields = el("div", { class: "fields" });

        // API キー入力（表示/非表示トグル付き）
        const keyRow = el("div", { style: "position: relative;" });
        const keyLabel = el("label", {}, `${prov.name} API キー`);
        const keyWrap = el("div", { style: "display: flex; gap: 8px;" });
        const keyInput = el("input", {
          type: "password",
          spellcheck: "false",
          placeholder: prov.placeholder,
          value: STATE.values.ai_api_key || "",
          style: "flex: 1;",
        });
        const toggleEyeBtn = el("button", {
          class: "btn icon quiet",
          type: "button",
          title: "パスワード表示切替",
          on: {
            click: () => {
              keyInput.type = keyInput.type === "password" ? "text" : "password";
            },
          },
        });
        toggleEyeBtn.innerHTML = ICONS.eye || "👁";
        keyWrap.append(keyInput, toggleEyeBtn);
        keyRow.append(keyLabel, keyWrap);

        // モデル選択
        const modelRow = el("div", { style: "margin-top: 10px;" });
        const modelLabel = el("label", {}, "使用する AI モデル");
        const modelSelect = el("select", { class: "select", style: "width: 100%;" });

        const savedModel = STATE.values.ai_model || prov.defaultModel;
        let isKnown = false;
        prov.models.forEach((m) => {
          const opt = el("option", { value: m.id }, m.name);
          if (m.id === savedModel) {
            opt.selected = true;
            isKnown = true;
          }
          modelSelect.append(opt);
        });

        const customInput = el("input", {
          type: "text",
          placeholder: "例: deepseek/deepseek-r1 や gpt-4o",
          value: isKnown ? "" : savedModel,
          style: `margin-top: 6px; width: 100%; display: ${(!isKnown && savedModel) || modelSelect.value === "custom" ? "block" : "none"};`,
        });

        if (!isKnown && savedModel) {
          modelSelect.value = "custom";
        }

        modelSelect.addEventListener("change", () => {
          if (modelSelect.value === "custom") {
            customInput.style.display = "block";
            customInput.focus();
          } else {
            customInput.style.display = "none";
          }
        });

        modelRow.append(modelLabel, modelSelect, customInput);

        // 接続テストエリア
        const testArea = el("div", { class: "ai-test-area", style: "margin-top: 14px;" });
        const testResultBox = el("div", { class: "ai-test-result", style: "display: none; margin-top: 8px;" });

        const btnTest = el("button", {
          class: "btn secondary",
          type: "button",
          on: {
            click: async () => {
              const k = keyInput.value.trim();
              if (!k) {
                testResultBox.style.display = "block";
                testResultBox.className = "ai-test-result error";
                testResultBox.textContent = "⚠ 先に API キーを入力してください";
                return;
              }
              const m = modelSelect.value === "custom" ? customInput.value.trim() : modelSelect.value;
              btnTest.disabled = true;
              btnTest.textContent = "接続テスト中…";
              testResultBox.style.display = "block";
              testResultBox.className = "ai-test-result pending";
              testResultBox.textContent = `📡 ${prov.name} (${m}) に接続テストを送信中…`;

              try {
                const res = await runAction("test_api", {
                  provider: prov.id,
                  api_key: k,
                  model: m,
                });
                if (res && res.ok) {
                  testResultBox.className = "ai-test-result success";
                  let warnHtml = "";
                  if (res.warning) {
                    warnHtml = `<br><span style="font-size: 11px; color: #ffb74d;">⚠️ ${escapeHtml(res.warning)}</span>`;
                  }
                  testResultBox.innerHTML = `<strong>✓ 接続成功！</strong>（モデル: ${escapeHtml(res.model || m)} / 応答: ${res.latency_ms}ms）${warnHtml}<br><span style="font-size: 11px; opacity: 0.9;">AI応答: 「${escapeHtml(res.response || "")}」</span>`;

                  // 接続に成功したモデルを選択肢へ自動同期
                  if (res.model && res.model !== m) {
                    let foundOpt = false;
                    for (let i = 0; i < modelSelect.options.length; i++) {
                      if (modelSelect.options[i].value === res.model) {
                        modelSelect.selectedIndex = i;
                        customInput.style.display = "none";
                        foundOpt = true;
                        break;
                      }
                    }
                    if (!foundOpt) {
                      modelSelect.value = "custom";
                      customInput.value = res.model;
                      customInput.style.display = "block";
                    }
                  }
                } else {
                  testResultBox.className = "ai-test-result error";
                  testResultBox.textContent = `✗ 接続失敗: ${res?.error || "接続できませんでした"}`;
                }
              } catch (err) {
                testResultBox.className = "ai-test-result error";
                testResultBox.textContent = `✗ エラー: ${err.message || String(err)}`;
              } finally {
                btnTest.disabled = false;
                btnTest.textContent = "🔌 接続テストを実行";
              }
            },
          },
        }, "🔌 接続テストを実行");

        testArea.append(btnTest, testResultBox);
        fields.append(keyRow, modelRow, testArea);
        container.append(pDesc, fields);

        // 保存ハンドラ用にインプット参照を保持
        container._getValues = () => {
          const k = keyInput.value.trim();
          let m = modelSelect.value;
          if (m === "custom") {
            m = customInput.value.trim() || prov.defaultModel;
          }
          return { provider: prov.id, apiKey: k, model: m };
        };
      };

      PROVIDERS.forEach((prov) => {
        const tabBtn = el("button", {
          class: `btn quiet ai-prov-tab ${prov.id === curProvId ? "active" : ""}`,
          type: "button",
          "data-id": prov.id,
          on: { click: () => renderProv(prov.id) },
        });
        tabBtn.innerHTML = `<strong>${escapeHtml(prov.name)}</strong><span class="ai-prov-tab-sub">${escapeHtml(prov.desc)}</span>`;
        tabsWrap.append(tabBtn);
      });

      body.append(tabsWrap, container);

      renderProv(curProvId);

      const buttons = el("div", { class: "buttons", style: "margin-top: 20px;" });
      buttons.append(el("button", { class: "btn", type: "button", on: { click: close } }, txt("common.cancel")));
      const saveBtn = el("button", {
        class: "btn accent",
        type: "button",
        on: {
          click: async () => {
            const vals = container._getValues ? container._getValues() : null;
            if (!vals) return;
            saveBtn.disabled = true;
            saveBtn.textContent = "保存中…";
            try {
              STATE.values.ai_provider = vals.provider;
              STATE.values.ai_api_key = vals.apiKey;
              STATE.values.ai_model = vals.model;

              await setValue("ai_provider", vals.provider);
              await setValue("ai_api_key", vals.apiKey);
              await setValue("ai_model", vals.model);

              close();
              paint();
              toast("AI連携設定を保存しました");
            } catch (err) {
              toast("保存に失敗しました: " + (err.message || String(err)));
              saveBtn.disabled = false;
              saveBtn.textContent = txt("common.save");
            }
          },
        },
      }, txt("common.save"));
      buttons.append(saveBtn);
      body.append(buttons);
    });
  };

  // ホットキー割り当てキャプチャモーダル
  const openHotkeyCaptureModal = (inst, index) => {
    const instructions = getInstructions();
    openDialog((body, close) => {
      body.append(el("h3", {}, `「${inst.name}」のショートカット設定`));
      const p = el("p", { class: "hint" }, "割り当てたいキーの組み合わせ（例: Ctrl+Shift+E や Alt+1 など）をキーボードで直接押してください。");
      body.append(p);

      const box = el("div", { class: "hotkey-capture-box", tabindex: "0" });
      box.textContent = inst.hotkey ? inst.hotkey.toUpperCase() : "キーを押してください…";
      
      let captured = inst.hotkey || "";

      box.addEventListener("keydown", (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (["Control", "Shift", "Alt", "Meta"].includes(e.key)) return;
        
        const mods = [];
        if (e.ctrlKey) mods.push("ctrl");
        if (e.altKey) mods.push("alt");
        if (e.shiftKey) mods.push("shift");
        if (e.metaKey) mods.push("win");

        let keyName = e.key.toLowerCase();
        if (keyName === " ") keyName = "space";
        if (keyName === "escape") keyName = "esc";
        
        captured = [...mods, keyName].join("+");
        box.textContent = captured.toUpperCase();
        box.classList.add("captured");
      });

      body.append(box);

      const buttons = el("div", { class: "buttons" });
      const clearBtn = el("button", {
        class: "btn danger sm", type: "button",
        on: {
          click: () => {
            captured = "";
            box.textContent = "未設定";
            box.classList.remove("captured");
          }
        }
      }, "解除");
      buttons.append(clearBtn);
      buttons.append(el("button", { class: "btn", type: "button", on: { click: close } }, txt("common.cancel")));
      const saveBtn = el("button", {
        class: "btn primary", type: "button",
        on: {
          click: async () => {
            instructions[index].hotkey = captured;
            await saveInstructions(instructions);
            close();
            toast("ショートカットを更新しました");
          }
        }
      }, txt("common.save"));
      buttons.append(saveBtn);
      body.append(buttons);

      setTimeout(() => box.focus(), 50);
    });
  };

  // カスタム指示編集・新規作成モーダル
  const openInstructionModal = (inst, index = -1) => {
    const isNew = inst === null;
    const instructions = getInstructions();
    const current = isNew
      ? { id: "custom_" + Date.now(), name: "", desc: "", prompt: "以下の音声を自然な文章に整えてください:\n\n{text}", hotkey: "", enabled: true }
      : { ...inst };

    openDialog((body, close) => {
      const title = el("h3", {});
      title.textContent = isNew ? "変換を追加" : `「${current.name}」を書きかえる`;
      body.append(title);
      
      const fields = el("div", { class: "fields" });

      // 名前
      const nameInput = el("input", {
        type: "text", spellcheck: "false",
        placeholder: "例: 英語に翻訳、ターミナルヘルパー、敬語変換",
        value: current.name || ""
      });
      fields.append(el("div", {}, `<label>指示の名前</label>`), nameInput);

      // 説明
      const descInput = el("input", {
        type: "text", spellcheck: "false",
        placeholder: "例: あらゆる言語を自然で流暢な英語に翻訳します。",
        value: current.desc || ""
      });
      fields.append(el("div", { style: "margin-top: 8px;" }, `<label>説明（用途）</label>`), descInput);

      // ショートカット
      const hkInput = el("input", {
        type: "text", spellcheck: "false",
        placeholder: "例: ctrl+shift+e, alt+1",
        value: current.hotkey || ""
      });
      fields.append(el("div", { style: "margin-top: 8px;" }, `<label>ショートカットキー（直接指定または空白）</label>`), hkInput);

      // プロンプト
      const promptArea = el("textarea", {
        rows: 5,
        placeholder: "指示プロンプトを入力してください。{text} が話した音声のプレースホルダーになります。",
        style: "width: 100%; font-family: monospace; font-size: 13px; line-height: 1.5; padding: 8px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg-input); color: var(--fg);"
      });
      promptArea.value = current.prompt || "";

      const promptLabelRow = el("div", { style: "display: flex; justify-content: space-between; align-items: center; margin-top: 8px;" });
      promptLabelRow.append(el("label", {}, "指示文（{text} のところに、話した内容が入ります）"));
      // 最初から入っている変換なら、出荷時の指示文にいつでも戻せる
      const factory = builtinInstructions().find((d) => d.id === current.id);
      if (!isNew && factory) {
        const revertBtn = el("button", {
          class: "btn quiet sm", type: "button",
          style: "font-size: 11px; padding: 2px 6px;",
          on: {
            click: () => {
              promptArea.value = factory.prompt;
              toast("最初の指示文を入れました。「保存」で確定します");
            }
          }
        }, "最初の文に戻す");
        promptLabelRow.append(revertBtn);
      }
      fields.append(promptLabelRow, promptArea);

      // 有効化トグル
      const enableWrap = el("div", { style: "margin-top: 12px; display: flex; align-items: center; gap: 8px;" });
      const enableCheck = el("input", { type: "checkbox", id: "inst_enable_check" });
      enableCheck.checked = current.enabled !== false;
      const enableLabel = el("label", { for: "inst_enable_check", style: "cursor: pointer;" }, "この変換を使う");
      enableWrap.append(enableCheck, enableLabel);
      fields.append(enableWrap);

      body.append(fields);

      const buttons = el("div", { class: "buttons" });
      buttons.append(el("button", { class: "btn", type: "button", on: { click: close } }, txt("common.cancel")));
      const saveBtn = el("button", {
        class: "btn primary", type: "button",
        on: {
          click: async () => {
            const name = nameInput.value.trim();
            if (!name) {
              toast("指示の名前を入力してください");
              nameInput.focus();
              return;
            }
            current.name = name;
            current.desc = descInput.value.trim();
            current.hotkey = hkInput.value.trim().toLowerCase();
            current.prompt = promptArea.value.trim();
            current.enabled = enableCheck.checked;

            if (isNew) {
              instructions.push(current);
            } else {
              instructions[index] = current;
            }

            await saveInstructions(instructions);
            close();
            toast(isNew ? "変換を追加しました" : "変換を保存しました");
          }
        }
      }, txt("common.save"));
      buttons.append(saveBtn);
      body.append(buttons);
    });
  };

  const paint = () => {
    wrap.replaceChildren();

    // 1. トップ：APIキー & モデル設定バー
    const apiKey = (STATE.values.ai_api_key || "").trim();
    let provName = "Google Gemini";
    const curP = STATE.values.ai_provider || "gemini";
    if (curP === "openrouter" || (curP === "auto" && apiKey.startsWith("sk-or-"))) {
      provName = "OpenRouter";
    } else if (curP === "claude" || (curP === "auto" && apiKey.startsWith("sk-ant-"))) {
      provName = "Anthropic Claude";
    }

    const topBar = el("div", { class: "ai-top-status" });
    const statusBadge = apiKey
      ? `<span class="badge on">${ICONS.check}${provName} 連携中</span>`
      : `<span class="badge on">${ICONS.check}この PC の中だけで変換中（簡易版）</span>`;

    const leftStatus = el("div", { class: "ai-top-status-left" });
    leftStatus.innerHTML = `
      ${statusBadge}
      <span class="ai-top-model-label">${apiKey ? `モデル: <strong>${escapeHtml(STATE.values.ai_model || "gemini-2.0-flash")}</strong>` : `<span style="color: var(--fg-muted); font-size: 12px;">API キーを入れると、指示文どおりに AI が変換します</span>`}</span>
    `;
    const keyBtn = el("button", {
      class: "btn sm", type: "button",
      on: { click: () => openApiKeyDialog() }
    }, `${ICONS.key}${apiKey ? "プロバイダー・API設定" : "AI連携・APIキーを設定"}`);
    topBar.append(leftStatus, keyBtn);
    wrap.append(topBar);

    // 2. ショートカットの説明（被りを完全に無くす）
    const note = el("div", { class: "card pad ai-note" });
    const recKey = prettyHotkey(STATE.values.hotkey || "ctrl+space");
    const actKey = prettyHotkey(STATE.values.action_hotkey || "ctrl+shift+space");
    
    note.innerHTML = `
      <div style="display: flex; flex-direction: column; gap: 8px;">
        <div>
          <strong>🎤 ふだんの録音:</strong> ${recKey}
          <span style="color: var(--fg-muted); margin-left: 8px;">話した内容をそのまま文字起こし（変換なし）</span>
        </div>
        <div>
          <strong>⚡ AI変換録音（英語翻訳・ビジネスなど）:</strong> ${actKey}
          <span style="color: var(--fg-muted); margin-left: 8px;">このキーで話すと、AI変換されて入力されます</span>
        </div>
        <div style="font-size: 13px; color: var(--fg-muted); border-top: 1px solid var(--border); padding-top: 6px;">
          💡 <strong>停止方法:</strong> もう一度同じキーを押すか、普段の ${recKey} を押せばどちらでも停止・変換されます！
        </div>
      </div>
    `;
    wrap.append(note);

    // 3. セクション：カスタム指示 (Custom Instructions)
    const customSection = el("div", { class: "card ai-card" });
    const customHead = el("div", { class: "ai-header-row" });
    const customTitleGroup = el("div", { class: "ai-title-group" });
    customTitleGroup.innerHTML = `
      <div class="ai-section-title">
        <span class="ai-icon-title">${ICONS.sliders}</span>
        <h2>変換の一覧</h2>
      </div>
      <p class="ai-section-desc">ショートカットを押して話す → 変換した文章が入ります。</p>
    `;
    const addBtn = el("button", {
      class: "btn primary", type: "button",
      on: { click: () => openInstructionModal(null) }
    }, `${ICONS.plus}変換を追加`);
    customHead.append(customTitleGroup, addBtn);
    customSection.append(customHead);

    // プリセットカード一覧
    const instructions = getInstructions();
    const listContainer = el("div", { class: "ai-instructions-list" });

    if (!instructions.length) {
      listContainer.append(el("div", { class: "empty pad" }, "変換がありません。「変換を追加」から作れます。"));
    } else {
      instructions.forEach((inst, index) => {
        const itemCard = el("div", { class: "ai-instruction-card" + (inst.enabled ? "" : " disabled") });
        
        const topRow = el("div", { class: "ai-inst-top" });
        const nameBlock = el("div", { class: "ai-inst-name-block" });
        const nameHeading = el("span", { class: "ai-inst-name" });
        nameHeading.textContent = inst.name || "名前なし";
        const statusBadge = el("span", { class: "badge " + (inst.enabled ? "on" : "off") }, inst.enabled ? "有効" : "無効");
        nameBlock.append(nameHeading, statusBadge);

        const actionsBlock = el("div", { class: "ai-inst-actions" });
        
        // ショートカットボタン
        const hkBadge = el("button", {
          class: "badge-hotkey" + (inst.hotkey ? " set" : " unset"),
          type: "button",
          title: inst.hotkey ? `${inst.hotkey.toUpperCase()}（クリックして変更）` : "クリックしてショートカットキーを設定",
          on: { click: () => openHotkeyCaptureModal(inst, index) }
        }, inst.hotkey ? `${inst.hotkey.toUpperCase()} ✕` : `＋ ショートカット録画`);
        
        if (inst.hotkey) {
          hkBadge.addEventListener("click", (e) => {
            if (e.offsetX > hkBadge.offsetWidth - 24) {
              e.stopPropagation();
              inst.hotkey = "";
              saveInstructions(instructions);
              toast("ショートカットを解除しました");
            }
          });
        }

        const isActive = (STATE.values.active_action || "") === inst.id;
        const defaultModeBtn = el("button", {
          class: "btn sm " + (isActive ? "accent" : "quiet"),
          type: "button",
          style: "font-weight: 500;",
          title: isActive ? "クリックで通常入力（変換なし）に戻します" : "クリックすると、ふだんの録音キーでこの変換が自動適用されます",
          on: {
            click: async () => {
              const nextVal = isActive ? "" : inst.id;
              STATE.values.active_action = nextVal;
              await setValue("active_action", nextVal);
              paint();
              toast(nextVal ? `「${inst.name}」をふだんの録音モードに設定しました！` : "通常の文字入力（変換なし）に戻しました");
            }
          }
        }, isActive ? `${ICONS.check} 選択中（ふだん使う）` : `⚡ ふだんの録音で使う`);

        const editBtn = el("button", {
          class: "btn sm", type: "button",
          on: { click: () => openInstructionModal(inst, index) }
        }, `${ICONS.edit}編集`);
        actionsBlock.append(defaultModeBtn);

        const toggleBtn = el("button", {
          class: "btn sm " + (inst.enabled ? "" : "quiet"),
          type: "button",
          title: inst.enabled ? "無効にする" : "有効にする",
          on: {
            click: () => {
              inst.enabled = !inst.enabled;
              saveInstructions(instructions);
            }
          }
        }, inst.enabled ? "無効化" : "有効化");

        const deleteBtn = el("button", {
          class: "btn sm icon-only danger", type: "button",
          title: "削除",
          on: {
            click: async () => {
              if (await confirmDialog("削除の確認", `「${inst.name}」を削除してもよろしいですか？`)) {
                instructions.splice(index, 1);
                saveInstructions(instructions);
                toast("削除しました");
              }
            }
          }
        }, ICONS.trash);

        actionsBlock.append(hkBadge, editBtn, toggleBtn, deleteBtn);
        topRow.append(nameBlock, actionsBlock);

        const descRow = el("div", { class: "ai-inst-desc" });
        descRow.textContent = inst.desc || "";
        
        // 内部プロンプトの可視化（初期はコンパクト表示、クリックで展開/編集）
        const promptBox = el("div", { class: "ai-inst-prompt-box", title: "クリックで展開 / 編集" });
        const promptHeader = el("div", { class: "ai-inst-prompt-header" });
        const headerLabel = el("span", {}, "指示文（プロンプト）");
        const toggleIcon = el("span", { style: "font-size: 10px; opacity: 0.7;" }, "▼ 展開・編集");
        promptHeader.append(headerLabel, toggleIcon);

        const promptCode = el("pre", { class: "ai-inst-prompt-code collapsed" });
        promptCode.textContent = inst.prompt || "";
        promptBox.append(promptHeader, promptCode);

        promptBox.addEventListener("click", () => {
          if (promptCode.classList.contains("collapsed")) {
            promptCode.classList.remove("collapsed");
            toggleIcon.textContent = "▲ 閉じる（クリックで編集モーダル）";
          } else {
            openInstructionModal(inst, index);
          }
        });

        itemCard.append(topRow, descRow, promptBox);
        listContainer.append(itemCard);
      });
    }

    customSection.append(listContainer);
    wrap.append(customSection);
  };

  paint();
  if (location.search.includes("open=api")
      || location.hash.includes("open-api")) {
    setTimeout(openApiKeyDialog, 150);
  }
  return wrap;
}

/* ------------------------------------------------- クリップボード */

// いま見ているグループ（0 = 履歴）。?clipgroup= は見た目の確認用
let clipGroup = Number(qs.get("clipgroup") || 0) || 0;
let clipFilter = "";
let clipRefresh = null;   // 開いているパネルを描き直す関数
let clipManual = true;    // グループの並び順が「自分で並べた順」か

const clipKeyText = () => String(STATE.values.clip_hotkey || "alt+v")
  .split("+").map((p) => (p.length === 1 ? p.toUpperCase()
    : p[0].toUpperCase() + p.slice(1))).join("+");

/* -------------------------------------- クリップボード：タブ並び替え */

function panelClipTabOrder() {
  const wrap = el("div", { class: "clip-tab-order-panel" });
  const listEl = el("div", { class: "clip-tab-order-list" });
  const flowBar = el("div", { class: "clip-tab-flow-bar" });
  const hintEl = el("div", { class: "clip-tab-order-hint" },
    "💡 カードを上下にドラッグ（長押しして掴んで移動）するか、"
    + "右端の ▲▼ ボタンで直感的に並び替えられます。");
  wrap.append(listEl, flowBar, hintEl);

  const TAB_DEFS = {
    history: {
      key: "history",
      name: txt("cweb.tab_history") || "履歴",
      icon: "🕒",
      desc: txt("cweb.tab_history_desc")
        || "直近にコピーした文字・画像・ファイルの一覧",
      badge: "必須",
      canDisable: false,
    },
    frequent: {
      key: "frequent",
      name: txt("cweb.tab_frequent") || "🤖よく使っている",
      icon: "🤖",
      desc: txt("cweb.tab_frequent_desc")
        || "直近で頻繁に使った定型文やパスワードの自動集計",
      canDisable: true,
      isEnabled: () => STATE.values.clip_show_frequent !== false,
      setEnabled: async (val) => {
        STATE.values.clip_show_frequent = val;
        await setValue("clip_show_frequent", val);
        afterChange("clip_show_frequent");
        renderFlow();
      },
    },
    groups: {
      key: "groups",
      name: txt("cweb.tab_groups") || "自作グループ",
      icon: "📁",
      desc: txt("cweb.tab_groups_desc")
        || "メール・住所・定型文・パスワードなどの保存グループ",
      badge: "定型文",
      canDisable: false,
    },
    downloads: {
      key: "downloads",
      name: txt("cweb.tab_downloads") || "ダウンロード",
      icon: "📥",
      desc: txt("cweb.tab_downloads_desc")
        || "ダウンロード・デスクトップ・OneDriveの最近のファイル",
      canDisable: true,
      isEnabled: () => STATE.values.clip_downloads !== "off",
      setEnabled: async (val) => {
        const nextVal = val ? "end" : "off";
        STATE.values.clip_downloads = nextVal;
        await setValue("clip_downloads", nextVal);
        afterChange("clip_downloads");
        renderFlow();
      },
    },
  };

  const getOrder = () => {
    let order = STATE.values.clip_tab_order;
    if (!Array.isArray(order) || !order.length) {
      order = ["history", "frequent", "groups", "downloads"];
    }
    const knownKeys = ["history", "frequent", "groups", "downloads"];
    const res = [...order.filter((k) => knownKeys.includes(k))];
    for (const k of knownKeys) {
      if (!res.includes(k)) res.push(k);
    }
    return res;
  };

  const saveOrder = async (newOrder) => {
    STATE.values.clip_tab_order = newOrder;
    renderCards();
    renderFlow();
    try {
      await setValue("clip_tab_order", newOrder);
      toast(txt("cweb.tab_reordered") || "タブの並び順を更新しました");
    } catch (e) {
      console.error("タブ順の保存失敗:", e);
    }
  };

  const moveItem = (index, delta) => {
    const order = getOrder();
    const targetIndex = index + delta;
    if (targetIndex < 0 || targetIndex >= order.length) return;
    const temp = order[index];
    order[index] = order[targetIndex];
    order[targetIndex] = temp;
    saveOrder(order);
  };

  const renderFlow = () => {
    flowBar.replaceChildren();
    const label = el("span", { class: "clip-tab-flow-label" },
      txt("cweb.tab_cycle_flow") || "現在のタブ巡回順:");
    flowBar.append(label);
    const order = getOrder();
    order.forEach((key, idx) => {
      const def = TAB_DEFS[key];
      if (!def) return;
      const isOff = def.canDisable && !def.isEnabled();
      const chip = el("span", {
        class: `clip-tab-flow-chip${isOff ? " is-disabled" : ""}`,
        title: isOff ? `${def.name}（非表示）` : def.name,
      }, `${def.icon} ${def.name}${isOff ? " (OFF)" : ""}`);
      flowBar.append(chip);
      if (idx < order.length - 1) {
        flowBar.append(el("span", { class: "clip-tab-flow-arrow" }, "→"));
      }
    });
  };

  let dragSourceKey = null;

  const renderCards = () => {
    listEl.replaceChildren();
    const order = getOrder();

    order.forEach((key, index) => {
      const def = TAB_DEFS[key];
      if (!def) return;

      const card = el("div", {
        class: "clip-tab-card",
        "data-key": key,
        "data-index": String(index),
        draggable: "true",
      });

      // ドラッグハンドル
      const handle = el("div", {
        class: "clip-tab-handle",
        title: "ドラッグまたは長押しして上下に移動",
      });
      handle.innerHTML = ICONS.grip;

      // アイコン
      const icon = el("div", { class: "clip-tab-icon" }, def.icon);

      // 情報（タイトル・説明）
      const info = el("div", { class: "clip-tab-info" });
      const titleRow = el("div", { class: "clip-tab-title-row" });
      titleRow.append(el("span", { class: "clip-tab-title" }, def.name));
      if (def.badge) {
        titleRow.append(el("span", { class: "clip-tab-badge" }, def.badge));
      }
      info.append(titleRow, el("div", { class: "clip-tab-desc" }, def.desc));

      // スイッチ（有効/無効）と移動ボタン
      const rightWrap = el("div", { class: "clip-tab-right" });
      if (def.canDisable) {
        const enabled = def.isEnabled();
        const sw = el("button", {
          class: "switch small",
          type: "button",
          role: "switch",
          "aria-checked": enabled ? "true" : "false",
          title: enabled ? "このタブを表示中（クリックで非表示）"
            : "このタブは非表示（クリックで表示）",
          on: {
            click: (e) => {
              e.stopPropagation();
              const next = sw.getAttribute("aria-checked") !== "true";
              sw.setAttribute("aria-checked", next ? "true" : "false");
              def.setEnabled(next);
            },
          },
        });
        rightWrap.append(sw);
      }

      // ▲ / ▼ ボタン
      const btnUp = el("button", {
        class: "btn icon quiet btn-tab-up",
        type: "button",
        title: "上へ移動",
        disabled: index === 0,
        on: {
          click: (e) => {
            e.stopPropagation();
            moveItem(index, -1);
          },
        },
      });
      btnUp.innerHTML = ICONS.up;

      const btnDown = el("button", {
        class: "btn icon quiet btn-tab-down",
        type: "button",
        title: "下へ移動",
        disabled: index === order.length - 1,
        on: {
          click: (e) => {
            e.stopPropagation();
            moveItem(index, 1);
          },
        },
      });
      btnDown.innerHTML = ICONS.down;

      const actions = el("div", { class: "clip-tab-actions" });
      actions.append(btnUp, btnDown);
      rightWrap.append(actions);

      card.append(handle, icon, info, rightWrap);

      // ---- HTML5 Drag & Drop イベント
      card.addEventListener("dragstart", (e) => {
        dragSourceKey = key;
        card.classList.add("is-dragging");
        e.dataTransfer.effectAllowed = "move";
        e.dataTransfer.setData("text/plain", key);
      });

      card.addEventListener("dragend", () => {
        dragSourceKey = null;
        card.classList.remove("is-dragging");
        listEl.querySelectorAll(".clip-tab-card").forEach((c) => {
          c.classList.remove("drop-target-above", "drop-target-below");
        });
      });

      card.addEventListener("dragover", (e) => {
        e.preventDefault();
        e.dataTransfer.dropEffect = "move";
        if (dragSourceKey === key) return;
        const rect = card.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;
        if (e.clientY < midY) {
          card.classList.add("drop-target-above");
          card.classList.remove("drop-target-below");
        } else {
          card.classList.add("drop-target-below");
          card.classList.remove("drop-target-above");
        }
      });

      card.addEventListener("dragleave", () => {
        card.classList.remove("drop-target-above", "drop-target-below");
      });

      card.addEventListener("drop", (e) => {
        e.preventDefault();
        card.classList.remove("drop-target-above", "drop-target-below");
        if (!dragSourceKey || dragSourceKey === key) return;
        const currentOrder = getOrder();
        const srcIdx = currentOrder.indexOf(dragSourceKey);
        if (srcIdx < 0) return;
        currentOrder.splice(srcIdx, 1);
        const rect = card.getBoundingClientRect();
        const midY = rect.top + rect.height / 2;
        let dstIdx = currentOrder.indexOf(key);
        if (e.clientY >= midY) {
          dstIdx += 1;
        }
        currentOrder.splice(dstIdx, 0, dragSourceKey);
        saveOrder(currentOrder);
      });

      // ---- PointerEvents による長押しドラッグ（マウス・タッチ両用）
      let holdTimer = null;
      let isPointerDragging = false;
      let startY = 0;

      const clearHold = () => {
        if (holdTimer) {
          clearTimeout(holdTimer);
          holdTimer = null;
        }
      };

      handle.addEventListener("pointerdown", (e) => {
        if (e.button !== 0) return;
        startY = e.clientY;
        clearHold();
        holdTimer = setTimeout(() => {
          isPointerDragging = true;
          dragSourceKey = key;
          card.classList.add("is-dragging");
          try { handle.setPointerCapture(e.pointerId); } catch {}
        }, 150);
      });

      handle.addEventListener("pointermove", (e) => {
        if (!isPointerDragging) {
          if (Math.abs(e.clientY - startY) > 8) {
            clearHold();
          }
          return;
        }
        e.preventDefault();
        const elAtPoint = document.elementFromPoint(e.clientX, e.clientY);
        const targetCard = elAtPoint ? elAtPoint.closest(".clip-tab-card") : null;
        listEl.querySelectorAll(".clip-tab-card").forEach((c) => {
          c.classList.remove("drop-target-above", "drop-target-below");
        });
        if (targetCard && targetCard !== card) {
          const rect = targetCard.getBoundingClientRect();
          if (e.clientY < rect.top + rect.height / 2) {
            targetCard.classList.add("drop-target-above");
          } else {
            targetCard.classList.add("drop-target-below");
          }
        }
      });

      const onPointerEnd = (e) => {
        clearHold();
        if (isPointerDragging) {
          isPointerDragging = false;
          card.classList.remove("is-dragging");
          const elAtPoint = document.elementFromPoint(e.clientX, e.clientY);
          const targetCard = elAtPoint ? elAtPoint.closest(".clip-tab-card") : null;
          listEl.querySelectorAll(".clip-tab-card").forEach((c) => {
            c.classList.remove("drop-target-above", "drop-target-below");
          });
          if (targetCard && targetCard !== card) {
            const targetKey = targetCard.dataset.key;
            const currentOrder = getOrder();
            const srcIdx = currentOrder.indexOf(key);
            currentOrder.splice(srcIdx, 1);
            const rect = targetCard.getBoundingClientRect();
            let dstIdx = currentOrder.indexOf(targetKey);
            if (e.clientY >= rect.top + rect.height / 2) {
              dstIdx += 1;
            }
            currentOrder.splice(dstIdx, 0, key);
            saveOrder(currentOrder);
          }
          try { handle.releasePointerCapture(e.pointerId); } catch {}
        }
      };

      handle.addEventListener("pointerup", onPointerEnd);
      handle.addEventListener("pointercancel", onPointerEnd);

      listEl.append(card);
    });
  };

  renderCards();
  renderFlow();
  return wrap;
}

function panelClipGroups() {
  const wrap = el("div", { class: "clip-panel" });
  const tabs = el("div", { class: "clip-tabs", role: "tablist" });
  const head = el("div", { class: "clip-head" });
  const toolbar = el("div", { class: "toolbar" });
  const card = el("div", { class: "card clip-list" });
  wrap.append(tabs, head, toolbar, card);
  let overview = { groups: [], history: 0 };
  let items = [];

  const group = () => overview.groups.find((g) => g.id === clipGroup);

  const load = async () => {
    // 本体側が使えないとき（起動の途中など）でも、画面は壊さない
    const res0 = await runAction("clip_overview").catch(() => null);
    overview = res0 && res0.ok ? res0 : { groups: [], history: 0 };
    if (clipGroup && !group()) clipGroup = 0;
    const res = await runAction("clip_items", { group_id: clipGroup }).catch(() => null);
    items = (res && res.items) || [];
    // 並べ替えの ↑↓ は「自分で並べた順」のときだけ出す
    clipManual = !res || res.manual !== false;
    paint();
  };
  clipRefresh = load;

  const paint = () => {
    // --- グループの切り替え
    tabs.replaceChildren();
    const tab = (id, label, count) => {
      const b = el("button", {
        class: "clip-tab", type: "button", role: "tab",
        "aria-selected": id === clipGroup ? "true" : "false",
        on: { click: () => { clipGroup = id; clipFilter = ""; load(); } },
      }, `<span>${escapeHtml(label)}</span>${count ? `<small>${count}</small>` : ""}`);
      tabs.append(b);
    };
    tab(0, txt("cweb.history"), overview.history);
    for (const g of overview.groups) tab(g.id, g.name, g.count);
    tabs.append(el("button", {
      class: "clip-tab add", type: "button",
      on: { click: () => clipNewGroupDialog() },
    }, `${ICONS.plus}<span>${txt("cweb.new_group")}</span>`));

    // --- グループの操作（名前・並び・専用のキー・削除）
    head.replaceChildren();
    const g = group();
    if (g) {
      const left = el("div", { class: "clip-head-left" });
      left.append(el("button", {
        class: "btn quiet", type: "button",
        on: { click: () => clipRenameDialog(g) },
      }, `${ICONS.edit}${txt("cweb.rename")}`));
      left.append(el("button", {
        class: "btn quiet icon", type: "button", title: txt("cweb.move_left"),
        "aria-label": txt("cweb.move_left"),
        on: { click: async () => { await runAction("clip_group_reorder", { id: g.id, delta: -1 }); load(); } },
      }, ICONS.left));
      left.append(el("button", {
        class: "btn quiet icon", type: "button", title: txt("cweb.move_right"),
        "aria-label": txt("cweb.move_right"),
        on: { click: async () => { await runAction("clip_group_reorder", { id: g.id, delta: 1 }); load(); } },
      }, ICONS.right));
      head.append(left);
      const keyWrap = el("div", { class: "clip-head-key", title: txt("cweb.group_hotkey_hint") });
      keyWrap.append(el("span", {}, txt("cweb.group_hotkey")));
      keyWrap.append(clipGroupHotkey(g, load));
      head.append(keyWrap);
      head.append(el("button", {
        class: "btn quiet danger", type: "button",
        on: { click: async () => {
          const msg = txt("cweb.delete_group_confirm").replace("{name}", g.name)
            .replace("{n}", String(g.count));
          if (!(await confirmDialog(txt("cweb.delete_group"), msg))) return;
          await runAction("clip_group_delete", { id: g.id });
          clipGroup = 0;
          load();
        } },
      }, `${ICONS.trash}${txt("cweb.delete_group")}`));
    }

    // --- 探す・足す
    toolbar.replaceChildren();
    const search = el("div", { class: "search" }, ICONS.search);
    const input = el("input", { type: "search", spellcheck: "false",
                                placeholder: txt("cweb.search"), value: clipFilter });
    input.addEventListener("input", () => { clipFilter = input.value; paintList(); });
    search.append(input);
    toolbar.append(search);
    if (g) {
      toolbar.append(el("button", {
        class: "btn accent", type: "button",
        on: { click: () => openClipItemDialog({ group_id: g.id }) },
      }, `${ICONS.plus}${txt("cweb.add_item")}`));
    }
    toolbar.append(el("div", { class: "count" }));
    paintList();
  };

  const paintList = () => {
    const words = clipFilter.trim().toLowerCase().split(/\s+/).filter(Boolean);
    const rows = items.filter((it) => {
      const hay = [it.title, it.text, it.app, ...(it.files || [])].join(" ").toLowerCase();
      return words.every((w) => hay.includes(w));
    });
    const count = toolbar.querySelector(".count");
    if (count) count.textContent = (STATE.text["dict.count"] || "{n}").replace("{n}", rows.length);
    card.replaceChildren();
    if (!rows.length) {
      const msg = clipFilter ? txt("history.no_match")
        : txt(clipGroup ? "cweb.empty_group" : "cweb.empty_history").replace("{hotkey}", clipKeyText());
      card.append(el("div", { class: "empty pad" }, escapeHtml(msg)));
      return;
    }
    for (const it of rows) card.append(clipRow(it, load));
  };

  load();
  return wrap;
}

function clipRow(it, reload) {
  const row = el("div", { class: "clip-row" });
  const lead = el("div", { class: "clip-lead" });
  if (it.kind === "image") {
    lead.append(el("img", {
      src: `/api/clip_image?t=${encodeURIComponent(TOKEN)}&id=${it.id}`,
      alt: "", loading: "lazy",
    }));
  } else {
    const icon = { secret: ICONS.lock, link: ICONS.link, files: ICONS.folder,
                   image: ICONS.image }[it.look] || ICONS.text;
    lead.innerHTML = icon;
  }
  row.append(lead);

  const body = el("div", { class: "clip-body" });
  let first = it.title;
  let second = "";
  if (it.kind === "image") {
    first = it.title || `${txt("cweb.image")}  ${it.width} × ${it.height}`;
  } else if (it.kind === "files") {
    first = it.title || (it.files || []).map((f) => f.split("\\").pop()).join(", ");
    second = txt("cweb.files").replace("{n}", (it.files || []).length);
  } else if (it.secret) {
    second = "••••••••••";
  } else {
    const lines = it.text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (first) second = lines[0] || "";
    else { first = lines[0] || ""; second = lines[1] || ""; }
  }
  body.append(el("div", { class: "clip-title" }, escapeHtml(first || "")));
  const meta = [];
  if (!it.group_id) { if (it.app) meta.push(it.app); meta.push(it.time); }
  if (it.used > 1) meta.push(`${it.used}×`);
  const sub = el("div", { class: "clip-sub" });
  sub.append(el("span", { class: "clip-second" }, escapeHtml(second)));
  if (meta.length) sub.append(el("span", { class: "clip-meta" }, escapeHtml(meta.join(" · "))));
  body.append(sub);
  row.append(body);

  const badges = el("div", { class: "clip-badges" });
  if (it.secret) badges.append(el("span", { class: "badge" }, txt("cweb.secret_badge")));
  if (it.pinned) badges.append(el("span", { class: "badge" }, txt("cweb.pinned_badge")));
  row.append(badges);

  const actions = el("div", { class: "clip-actions" });
  const act = (icon, label, fn, extra) => {
    actions.append(el("button", {
      class: "btn quiet icon" + (extra || ""), type: "button", title: label,
      "aria-label": label, on: { click: (e) => { e.stopPropagation(); fn(); } },
    }, icon));
  };
  if (it.kind === "text" || it.group_id) {
    act(ICONS.edit, txt("cweb.edit_item"), () => openClipItemDialog({ id: it.id }));
  }
  if (it.group_id && clipManual) {
    act(ICONS.up, txt("cweb.move_up"), async () => {
      await runAction("clip_item_reorder", { id: it.id, delta: -1 }); reload();
    });
    act(ICONS.down, txt("cweb.move_down"), async () => {
      await runAction("clip_item_reorder", { id: it.id, delta: 1 }); reload();
    });
  } else if (!it.group_id) {
    act(ICONS.pin, txt(it.pinned ? "cweb.unpin" : "cweb.pin"), async () => {
      await runAction("clip_item_pin", { ids: [it.id], pinned: !it.pinned }); reload();
    }, it.pinned ? " on" : "");
  }
  act(ICONS.move, txt("cweb.move_to"), () => clipMoveDialog(it, reload));
  act(ICONS.trash, txt("common.delete"), async () => {
    await runAction("clip_item_delete", { ids: [it.id] });
    toast(txt("cweb.deleted"));
    reload();
  });
  row.append(actions);
  row.addEventListener("dblclick", () => {
    if (it.kind === "text" || it.group_id) openClipItemDialog({ id: it.id });
  });
  return row;
}

// グループを直接開くキー（押して決める。Esc でやめる。「なし」で外す）
function clipGroupHotkey(g, reload) {
  const wrap = el("div", { class: "hotkey-wrap" });
  const node = el("button", { class: "btn hotkey", type: "button" });
  const paint = () => {
    node.innerHTML = g.hotkey ? prettyHotkey(g.hotkey) : txt("cweb.group_hotkey_none");
  };
  paint();
  const onKey = async (event) => {
    event.preventDefault();
    if (event.key === "Escape" && !event.ctrlKey && !event.altKey) { stop(); return; }
    const spec = hotkeySpecFromEvent(event);
    if (!spec) return;
    stop();
    const res = await runAction("clip_group_hotkey", { id: g.id, hotkey: spec });
    if (res && res.ok === false) { toast(res.error || txt("cweb.hotkey_conflict")); return; }
    g.hotkey = spec;
    paint();
    reload();
  };
  const stop = () => {
    node.classList.remove("capturing");
    window.removeEventListener("keydown", onKey, true);
    paint();
  };
  node.addEventListener("click", () => {
    if (node.classList.contains("capturing")) { stop(); return; }
    node.classList.add("capturing");
    node.textContent = txt("cweb.press_keys");
    window.addEventListener("keydown", onKey, true);
    node.addEventListener("blur", stop, { once: true });
  });
  wrap.append(node);
  if (g.hotkey) {
    wrap.append(el("button", {
      class: "btn quiet", type: "button",
      on: { click: async () => {
        await runAction("clip_group_hotkey", { id: g.id, hotkey: "" });
        g.hotkey = ""; paint(); reload();
      } },
    }, txt("cweb.group_hotkey_none")));
  }
  return wrap;
}

function clipNameDialog(title, value) {
  return new Promise((resolve) => {
    openDialog((body, close) => {
      body.append(el("h3", {}, escapeHtml(title)));
      const fields = el("div", { class: "fields" });
      const input = el("input", { type: "text", spellcheck: "false", maxlength: "40",
                                  placeholder: txt("cweb.group_name_ph"), value: value || "" });
      const wrapName = el("div", {}, `<label>${txt("cweb.group_name")}</label>`);
      wrapName.append(input);
      fields.append(wrapName);
      body.append(fields);
      const buttons = el("div", { class: "buttons" });
      buttons.append(el("button", { class: "btn", type: "button",
        on: { click: () => { close(); resolve(null); } } }, txt("common.cancel")));
      const ok = el("button", { class: "btn accent", type: "button" }, txt("common.save"));
      const done = () => {
        const name = input.value.trim();
        if (!name) { input.focus(); return; }
        close(); resolve(name);
      };
      ok.addEventListener("click", done);
      input.addEventListener("keydown", (e) => { if (e.key === "Enter") done(); });
      buttons.append(ok);
      body.append(buttons);
      setTimeout(() => { input.focus(); input.select(); }, 30);
    });
  });
}

async function clipNewGroupDialog() {
  const name = await clipNameDialog(txt("cweb.new_group_title"), "");
  if (!name) return;
  const res = await runAction("clip_group_add", { group_name: name });
  if (res && res.ok) {
    clipGroup = res.id;
    if (clipRefresh) clipRefresh();
  }
}

async function clipRenameDialog(g) {
  const name = await clipNameDialog(txt("cweb.rename"), g.name);
  if (!name || name === g.name) return;
  await runAction("clip_group_rename", { id: g.id, group_name: name });
  if (clipRefresh) clipRefresh();
}

async function clipMoveDialog(it, reload) {
  const overview = await runAction("clip_overview");
  const targets = [{ id: 0, name: txt("cweb.history") }, ...overview.groups]
    .filter((g) => g.id !== it.group_id);
  openDialog((body, close) => {
    body.append(el("h3", {}, escapeHtml(txt("cweb.move_to"))));
    const list = el("div", { class: "picklist" });
    for (const g of targets) {
      list.append(el("button", {
        type: "button",
        on: { click: async () => {
          close();
          await runAction("clip_item_move", { ids: [it.id], group_id: g.id });
          toast(txt("cweb.moved"));
          reload();
        } },
      }, `<span>${escapeHtml(g.name)}</span>${g.count ? `<small>${g.count}</small>` : ""}`));
    }
    list.append(el("button", {
      type: "button",
      on: { click: async () => {
        close();
        const name = await clipNameDialog(txt("cweb.new_group_title"), "");
        if (!name) return;
        const res = await runAction("clip_group_add", { group_name: name });
        if (res && res.ok) {
          await runAction("clip_item_move", { ids: [it.id], group_id: res.id });
          toast(txt("cweb.moved"));
          reload();
        }
      } },
    }, `${ICONS.plus}<span>${escapeHtml(txt("cweb.new_group"))}</span>`));
    body.append(list);
    const buttons = el("div", { class: "buttons" });
    buttons.append(el("button", { class: "btn", type: "button", on: { click: close } },
      txt("common.cancel")));
    body.append(buttons);
  });
}

// 言葉を足す／直す。{id} なら今のものを読んで直す。{group_id} なら新しく足す。
async function openClipItemDialog(opts) {
  let item = { title: "", text: "", secret: false, kind: "text",
               group_id: opts.group_id || 0 };
  if (opts.id) {
    const res = await runAction("clip_item_get", { id: opts.id });
    if (!res || !res.ok) return;
    item = res.item;
  }
  openDialog((body, close) => {
    body.classList.add("wide");
    body.append(el("h3", {}, escapeHtml(opts.id ? txt("cweb.edit_item") : txt("cweb.add_item"))));
    const fields = el("div", { class: "fields" });
    const title = el("input", { type: "text", spellcheck: "false", maxlength: "200",
                                placeholder: txt("cweb.item_title_ph"), value: item.title || "" });
    const wrapTitle = el("div", {}, `<label>${txt("cweb.item_title")}</label>`);
    wrapTitle.append(title);
    fields.append(wrapTitle);
    let text = null;
    let secret = null;
    if (item.kind === "text") {
      const wrapText = el("div", { class: "clip-text-field" },
        `<label>${txt("cweb.item_text")}</label>`);
      text = el("textarea", { rows: "6", spellcheck: "false" });
      text.value = item.text || "";
      const reveal = el("button", { class: "btn quiet reveal", type: "button" });
      let masked = Boolean(item.secret);
      const paintMask = () => {
        text.classList.toggle("masked", masked && secret.getAttribute("aria-checked") === "true");
        reveal.textContent = txt(masked ? "cweb.show" : "cweb.hide");
        reveal.hidden = secret.getAttribute("aria-checked") !== "true";
      };
      reveal.addEventListener("click", () => { masked = !masked; paintMask(); });
      wrapText.append(text, reveal);
      fields.append(wrapText);
      fields.append(el("div", { class: "help clip-vars" }, escapeHtml(txt("cweb.vars_hint"))));
      const secretRow = el("div", { class: "clip-secret" });
      secret = el("button", { class: "switch", type: "button", role: "switch",
                              "aria-checked": item.secret ? "true" : "false" });
      secret.addEventListener("click", () => {
        const on = secret.getAttribute("aria-checked") !== "true";
        secret.setAttribute("aria-checked", on ? "true" : "false");
        masked = on;
        paintMask();
      });
      secretRow.append(secret, el("span", {}, escapeHtml(txt("cweb.item_secret"))));
      fields.append(secretRow);
      paintMask();
    } else if (item.kind === "image") {
      fields.append(el("img", {
        class: "clip-preview",
        src: `/api/clip_image?t=${encodeURIComponent(TOKEN)}&id=${item.id}`, alt: "",
      }));
    }
    body.append(fields);
    const buttons = el("div", { class: "buttons" });
    buttons.append(el("button", { class: "btn", type: "button", on: { click: close } },
      txt("common.cancel")));
    const save = el("button", { class: "btn accent", type: "button" }, txt("common.save"));
    save.addEventListener("click", async () => {
      const payload = { title: title.value };
      if (opts.id) payload.id = opts.id;
      else payload.group_id = item.group_id;
      if (text) {
        if (!text.value.trim() && !title.value.trim()) { text.focus(); return; }
        payload.text = text.value;
        payload.secret = secret.getAttribute("aria-checked") === "true";
      }
      const res = await runAction("clip_item_save", payload);
      close();
      toast(res && res.ok ? txt("cweb.saved") : txt("cweb.save_failed"));
      if (clipRefresh) clipRefresh();
    });
    buttons.append(save);
    body.append(buttons);
    setTimeout(() => (text && !opts.id ? text : title).focus(), 30);
  });
}

function panelClipStats() {
  const wrap = el("div", { class: "clip-stats" });
  runAction("clip_overview").then((res) => {
    const s = (res && res.stats) || {};
    const mb = ((s.bytes || 0) / 1024 / 1024).toFixed(1) + " MB";
    let line = txt("cweb.stats");
    for (const [k, v] of Object.entries({ history: s.history || 0, pinned: s.pinned || 0,
                                          groups: s.groups || 0, items: s.items || 0,
                                          images: s.images || 0, size: mb })) {
      line = line.replace(`{${k}}`, String(v));
    }
    wrap.append(el("div", { class: "help" }, escapeHtml(line)));
    if (res && res.paused) {
      wrap.append(el("div", { class: "note" }, `${ICONS.info}${escapeHtml(txt("cweb.paused_note"))}`));
    }
    wrap.append(el("button", {
      class: "btn", type: "button",
      on: { click: () => runAction("clip_open") },
    }, `${ICONS.clipboard}${txt("cweb.try_open")}`));
  });
  return wrap;
}

function panelPresets() {
  const wrap = el("div", { class: "presets-panel" });
  const presets = STATE.presets || [];
  if (!presets.length) return wrap;

  const grid = el("div", { class: "presets-grid" });

  for (const p of presets) {
    const card = el("div", { class: "preset-card" });
    const isCurrent = Object.entries(p.settings || {}).every(
      ([k, v]) => STATE.values[k] === v
    );

    if (isCurrent) card.classList.add("active");

    const head = el("div", { class: "preset-card-head" });
    const iconSpan = el("span", { class: "preset-icon" });
    const iconMap = {
      chat: "💬",
      writing: "📝",
      terminal: "💻",
      shield: "🔰",
      sliders: "🎛️",
    };
    iconSpan.textContent = iconMap[p.icon] || "✨";

    const titleWrap = el("div", { class: "preset-title-wrap" });
    titleWrap.append(el("div", { class: "preset-name" }, p.name));

    if (p.badge) {
      const badge = el("span", { class: "preset-badge" }, p.badge);
      if (isCurrent) {
        badge.classList.add("active-badge");
        badge.textContent = txt("presets.current") || "現在適用中";
      }
      head.append(iconSpan, titleWrap, badge);
    } else {
      head.append(iconSpan, titleWrap);
    }

    const desc = el("div", { class: "preset-desc" }, p.desc);
    const tags = el("div", { class: "preset-tags" });
    const s = p.settings || {};

    if (s.enter_sends !== undefined) {
      tags.append(el("span", { class: "preset-tag" },
        s.enter_sends ? "Enterで即送信" : "Enter送信オフ"));
    }
    if (s.enter_delay_ms !== undefined && s.enter_sends) {
      tags.append(el("span", { class: "preset-tag" },
        `待ち ${s.enter_delay_ms}ms`));
    }
    if (s.stop_on_click !== undefined) {
      const clickMap = {
        outside: "外クリックで停止",
        any: "どこでも停止",
        off: "クリック停止なし",
      };
      tags.append(el("span", { class: "preset-tag" },
        clickMap[s.stop_on_click] || s.stop_on_click));
    }
    if (s.full_stops !== undefined) {
      const stopMap = {
        off: "句点『。』なし",
        all: "文末『。』あり",
        smart: "スマート句点",
      };
      tags.append(el("span", { class: "preset-tag" },
        stopMap[s.full_stops] || s.full_stops));
    }
    if (s.paste_method === "direct") {
      tags.append(el("span", { class: "preset-tag" }, "直接キー入力"));
    }

    const applyBtn = el("button", {
      class: "btn" + (isCurrent ? " secondary disabled" : " primary"),
      type: "button",
      on: {
        click: async () => {
          if (isCurrent) return;
          applyBtn.disabled = true;
          try {
            const res = await runAction("apply_preset", { preset: p.id });
            if (res && res.ok) {
              toast(`「${p.name}」スタイルを適用しました！`);
              Object.assign(STATE.values, p.settings);
              render();
            } else {
              toast(res?.error || "適用に失敗しました");
            }
          } catch (e) {
            toast("通信エラーが発生しました");
          } finally {
            applyBtn.disabled = false;
          }
        },
      },
    }, isCurrent ? (txt("presets.is_active") || "✓ 適用中") : (txt("presets.apply") || "このスタイルを適用"));

    card.append(head, desc, tags, applyBtn);
    grid.append(card);
  }

  wrap.append(grid);
  return wrap;
}

/* ------------------------------------------------- オーバーレイ・プレビュー */

let overlayPreviewWrap = null;

function panelOverlayPreview() {
  const wrap = el("div", { class: "overlay-preview-container" });
  overlayPreviewWrap = wrap;

  const head = el("div", { class: "overlay-preview-head" });
  const titleGroup = el("div", { class: "overlay-preview-title-group" });
  titleGroup.append(el("span", { class: "overlay-preview-icon" }, "👁️"));
  const titleText = el("div", {});
  titleText.append(el("div", { class: "overlay-preview-title" },
    txt("overlay.preview_title") || "見た目のプレビュー（リアルタイム）"));
  titleText.append(el("div", { class: "overlay-preview-sub" },
    txt("overlay.preview_hint") || "上の「表示のかたち」「大きさ」「色」を変えるとリアルタイムに反映されます"));
  titleGroup.append(titleText);
  head.append(titleGroup);

  const testBtn = el("button", {
    class: "btn secondary", type: "button",
    title: "実際の画面上に現在の設定でオーバーレイを3秒間表示してテストします",
    on: { click: async () => {
      testBtn.disabled = true;
      try {
        await runAction("test_overlay");
        toast("画面上にテスト表示を出しました！");
      } catch (e) {
        toast("表示テストに失敗しました");
      } finally {
        setTimeout(() => { testBtn.disabled = false; }, 2500);
      }
    } },
  }, `🚀 ${txt("overlay.test_btn") || "実際の画面でテスト表示（3秒）"}`);
  head.append(testBtn);
  wrap.append(head);

  const stage = el("div", { class: "overlay-preview-stage" });
  const widgetWrap = el("div", { class: "overlay-preview-widget-wrap" });
  stage.append(widgetWrap);
  wrap.append(stage);

  const foot = el("div", { class: "overlay-preview-foot" });
  wrap.append(foot);

  renderOverlayPreviewContent(widgetWrap, foot);
  return wrap;
}

function updateOverlayPreview() {
  if (!overlayPreviewWrap) return;
  const widgetWrap = overlayPreviewWrap.querySelector(".overlay-preview-widget-wrap");
  const foot = overlayPreviewWrap.querySelector(".overlay-preview-foot");
  if (widgetWrap && foot) {
    renderOverlayPreviewContent(widgetWrap, foot);
  }
}

function renderOverlayPreviewContent(widgetWrap, foot) {
  const values = STATE.values || {};
  const design = values.overlay_design || "pill";
  const size = values.overlay_size || "medium";
  const color = values.overlay_color || "red";
  const showText = values.overlay_text !== false;
  const pos = values.overlay_position || "bottom";

  const colorHexMap = {
    red: "#E0483A",
    orange: "#E87C20",
    green: "#2DA44E",
    teal: "#1B9AAA",
    blue: "#1F6FEB",
    navy: "#242460",
    pink: "#D03592",
    gray: "#6E7681",
    accent: "#388BFD",
  };
  const activeColor = colorHexMap[color] || "#E0483A";

  // プレビュー上で視覚的にサイズの違いがはっきりと実感できる倍率
  const scaleMap = { small: 0.76, medium: 1.0, large: 1.30, xlarge: 1.65 };
  const scale = scaleMap[size] || 1.0;

  const posLabelMap = {
    bottom: "下の中央（固定）",
    "bottom-right": "右下（固定）",
    top: "上の中央（固定）",
    cursor: "文字入力カーソルの近く（自動追従）",
  };

  const existingWidget = widgetWrap.querySelector(".opw-box");
  const currentDesign = existingWidget?.dataset.design;
  const currentShowText = existingWidget?.dataset.showText;

  if (!existingWidget || currentDesign !== design
      || currentShowText !== String(showText)) {
    widgetWrap.replaceChildren();

    const widget = el("div", {
      class: `opw-box opw-${design}`,
      "data-design": design,
      "data-show-text": String(showText),
      style: `--opw-accent: ${activeColor}; transform: scale(${scale}); `
        + `transform-origin: center center;`,
    });

    const makeEqualizer = (barCount = 7) => {
      const eq = el("div", { class: "opw-eq" });
      for (let i = 0; i < barCount; i++) {
        const b = el("span", {
          class: "opw-bar",
          style: `animation-delay: ${(i * 0.12).toFixed(2)}s;`,
        });
        eq.append(b);
      }
      return eq;
    };

    const samplePending = showText ? "こんにちは、SpeakPulse で入力中です" : "";

    if (design === "pill") {
      const led = el("span", { class: "opw-led" });
      const status = el("span", { class: "opw-status" }, "聞いています");
      const eq = makeEqualizer(7);
      widget.append(led, status, eq);
      if (samplePending) {
        widget.append(el("span", { class: "opw-text" }, samplePending));
      }
      widget.append(el("span", { class: "opw-clock" }, "0:04"));
    } else if (design === "wave") {
      const topWave = el("div", { class: "opw-wave-top" });
      for (let i = 0; i < 32; i++) {
        const b = el("span", {
          class: "opw-wave-bar",
          style: `animation-delay: ${(i * 0.05).toFixed(2)}s;`,
        });
        topWave.append(b);
      }
      const bottomRow = el("div", { class: "opw-wave-bottom" });
      const led = el("span", { class: "opw-led" });
      const status = el("span", { class: "opw-status" }, "聞いています");
      bottomRow.append(led, status);
      if (samplePending) {
        bottomRow.append(el("span", { class: "opw-text" }, samplePending));
      }
      bottomRow.append(el("span", { class: "opw-clock" }, "0:04"));
      widget.append(topWave, bottomRow);
    } else if (design === "card") {
      const topRow = el("div", { class: "opw-card-top" });
      const badge = el("div", { class: "opw-card-badge" });
      badge.append(el("span", { class: "opw-led" }));
      badge.append(el("span", { class: "opw-status" }, "聞いています"));
      topRow.append(badge);
      topRow.append(el("span", { class: "opw-clock" }, "0:04"));

      const textRow = el("div", { class: "opw-card-text" },
        samplePending || "（文字非表示）");
      const waveRow = makeEqualizer(24);
      const hintRow = el("div", { class: "opw-card-hint" },
        "Ctrl+Space で止める　・　Esc で取り消し");
      widget.append(topRow, textRow, waveRow, hintRow);
    } else if (design === "dot") {
      const led = el("span", { class: "opw-led" });
      const clock = el("span", { class: "opw-clock-bold" }, "0:04");
      const eq = makeEqualizer(5);
      widget.append(led, clock, eq);
    } else if (design === "caption") {
      const led = el("span", { class: "opw-led" });
      const tag = el("span", { class: "opw-caption-tag" }, "LIVE");
      const text = el("span", { class: "opw-caption-text" },
        samplePending || "聞いています…");
      const clock = el("span", { class: "opw-clock" }, "0:04");
      widget.append(led, tag, text, clock);
    }

    widgetWrap.append(widget);
  } else {
    // 形状が同じで「大きさ」や「色」が変更された時は、
    // DOMを破棄せずスタイルを更新して滑らかな拡大縮小アニメーションを発火させる
    existingWidget.style.setProperty("--opw-accent", activeColor);
    existingWidget.style.transform = `scale(${scale})`;
  }

  foot.replaceChildren();
  const sizeNames = { small: "小", medium: "中", large: "大", xlarge: "特大" };
  const approxWidthMap = {
    pill: Math.round(360 * scale),
    wave: Math.round(380 * scale),
    card: Math.round(320 * scale),
    dot: Math.round(180 * scale),
    caption: Math.round(460 * scale),
  };
  const approxW = approxWidthMap[design] || Math.round(360 * scale);

  foot.append(el("span", { class: "opw-info-badge" },
    `📍 表示位置: ${posLabelMap[pos] || pos}`));
  foot.append(el("span", { class: "opw-info-badge opw-badge-size" },
    `📏 大きさ: ${sizeNames[size] || size} (${scale}x / 横幅約 ${approxW}px)`));
  foot.append(el("span", { class: "opw-info-badge" },
    `🎨 録音中の色: ${color}`));
}

load().catch((err) => {
  document.body.textContent = String(err);
});
