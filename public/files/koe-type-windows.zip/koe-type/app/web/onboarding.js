/* koe-type の初回の案内（6 画面）。
 *
 * サーバー（app/websettings.py の Onboarding）から状態をもらって描く。
 * 画面を閉じても、どこまで進んだかは設定に残る。
 */
"use strict";

const qs = new URLSearchParams(location.search);
const TOKEN = qs.get("t") || document.documentElement.dataset.token || "";

let S = null;            // サーバーからの状態
let step = Number(qs.get("step") || 0);
let first = true;
let busy = false;
let timer = null;

const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => (
  { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(path, body) {
  const options = {
    headers: { "X-Koe-Token": TOKEN, "Content-Type": "application/json" },
  };
  if (body !== undefined) {
    options.method = "POST";
    options.body = JSON.stringify(body);
  }
  const res = await fetch(path + "?t=" + encodeURIComponent(TOKEN), options);
  if (!res.ok) throw new Error(path + " -> " + res.status);
  return res.json();
}

const act = (name, extra) => api("/api/onboarding", { name, ...(extra || {}) });

function toast(text) {
  const el = $("toast");
  el.textContent = text;
  el.classList.add("on");
  setTimeout(() => el.classList.remove("on"), 2600);
}

/* ------------------------------------------------------------ 画面たち */

const STEPS = [
  { id: "welcome", title: "ようこそ" },
  { id: "pc", title: "この PC を調べる" },
  { id: "model", title: "モデルを用意する" },
  { id: "mic", title: "試し書き" },
  { id: "keys", title: "ショートカット" },
  { id: "try", title: "話してみる" },
];

function pageWelcome() {
  return `
    <div class="ob-page">
      <h1 class="ob-title">SpeakPulse をはじめましょう</h1>
      <p class="ob-lead">
        キーを 1 つ押して話すと、いま入力しているところに文字が入ります。
        Word でもチャットでもブラウザでも、文字が打てる場所ならどこでも。
      </p>
      <div class="ob-card">
        <h3>覚えておくこと</h3>
        <ul class="ob-list">
          <li><span class="ob-kbd">${esc(S.hotkey_label || "Ctrl + Space")}</span>
              で録音を始め、もう一度押すと止まります</li>
          <li>話している途中から文字が入っていきます</li>
          <li><span class="ob-kbd">Esc</span> で取り消せます</li>
        </ul>
      </div>
      <div class="ob-card">
        <h3>外に送りません</h3>
        <p class="ob-note">
          文字起こしは、この PC の中だけで行います。話した内容も、
          文字にしたものも、インターネットには出ません。
          料金もかかりません。<br>
          通信するのは「モデルのダウンロード」と、設定で許したときの
          「新しい版の確認」だけです。
        </p>
      </div>
      <p class="ob-note">
        この案内は 5 分ほどで終わります。あとで
        「設定 → アプリ → 初回の案内をもう一度」から開き直せます。
      </p>
    </div>`;
}

function pagePc() {
  const p = S.profile;
  if (!p) {
    return `
      <div class="ob-page">
        <h1 class="ob-title">この PC を調べます</h1>
        <p class="ob-lead">
          CPU・メモリ・GPU・空き容量を調べ、短い試し計測をして、
          この PC に合うモデルを選びます。調べるだけで、何も変えません。
        </p>
        <div class="ob-card">
          <button class="ob-btn ob-primary" data-do="probe">調べる</button>
          <p class="ob-note" style="margin-top:10px">
            10 秒ほどかかります。
          </p>
        </div>
      </div>`;
  }
  const rows = (S.rows || []).map((r) => `
    <div class="ob-row">
      <span class="k">${esc(r.label_ja)}</span>
      <span class="v">${esc(r.value)}</span>
      <span class="ob-pip" data-s="${esc(r.state)}" title="${esc(r.state)}"></span>
    </div>`).join("");
  const notes = (p.notes || []).map((n) =>
    `<li class="ob-warn">${esc(n)}</li>`).join("");
  return `
    <div class="ob-page">
      <h1 class="ob-title">この PC の力</h1>
      <p class="ob-lead">調べ終わりました。結果はこちらです。</p>
      <div class="ob-card">
        <div class="ob-rows">${rows}</div>
        ${notes ? `<ul class="ob-list">${notes}</ul>` : ""}
      </div>
      <div class="ob-card">
        <h3>おすすめのモデル</h3>
        <p class="ob-note" style="color:var(--text)">
          <b>${esc(S.advice.name)}</b><br>${esc(S.advice.reason_ja)}
        </p>
      </div>
      <button class="ob-btn ob-ghost" data-do="probe">もう一度調べる</button>
    </div>`;
}

function pageModel() {
  const picked = S.model;
  const prog = S.download || {};
  const list = (S.models || []).map((m) => `
    <button class="ob-choice" data-pick="${esc(m.key)}"
            aria-pressed="${m.key === picked}">
      <div class="n">${esc(m.name)}${m.recommended ? "　（おすすめ）" : ""}</div>
      <div class="d">${esc(m.note)}${m.ready ? "　・ 用意できています" : ""}</div>
    </button>`).join("");
  let box = "";
  if (prog.state === "running") {
    const pct = Math.round((prog.fraction || 0) * 100);
    box = `
      <div class="ob-card">
        <h3>ダウンロードしています</h3>
        <div class="ob-bar"><i style="width:${pct}%"></i></div>
        <div class="ob-sub">${pct}%　${esc(prog.detail || "")}</div>
        <p class="ob-note" style="margin-top:10px">
          途中で止まっても、次に開いたときに続きから再開します。
        </p>
      </div>`;
  } else if (prog.state === "error") {
    box = `
      <div class="ob-card">
        <h3 class="ob-bad">うまくいきませんでした</h3>
        <p class="ob-note">${esc(prog.detail || "")}</p>
        <ul class="ob-list">
          <li>インターネットにつながっているか確かめてください</li>
          <li>会社の PC では、社内のネットワーク設定で止められることがあります</li>
          <li>空き容量が足りているか確かめてください</li>
        </ul>
        <button class="ob-btn ob-primary" data-do="download"
                style="margin-top:12px">もう一度ためす</button>
      </div>`;
  } else if (S.ready) {
    box = `
      <div class="ob-card">
        <h3 class="ob-ok">用意できました</h3>
        <p class="ob-note">${esc(S.ready_note || "")}</p>
      </div>`;
  } else {
    box = `
      <div class="ob-card">
        <h3>まだダウンロードしていません</h3>
        <p class="ob-note">
          大きさは ${esc(S.size_note || "")}。
          1 度だけダウンロードすれば、あとはずっとこの PC の中で動きます。
        </p>
        <button class="ob-btn ob-primary" data-do="download"
                style="margin-top:12px">ダウンロードする</button>
      </div>`;
  }
  return `
    <div class="ob-page">
      <h1 class="ob-title">モデルを用意する</h1>
      <p class="ob-lead">
        話した声を文字にするための「耳」です。1 つだけ選びます。
        あとから設定で変えられます。
      </p>
      ${box}
      <div class="ob-card">
        <h3>どれを使いますか</h3>
        ${list}
      </div>
    </div>`;
}

function pageMic() {
  const list = (S.microphones || []).map((m) =>
    `<option value="${esc(m)}"${m === S.microphone ? " selected" : ""}>
       ${esc(m || "既定のマイク")}</option>`).join("");
  const hotkey = S.hotkey_label || "Ctrl + Space";
  return `
    <div class="ob-page">
      <h1 class="ob-title">試し書きをしてみましょう</h1>
      <p class="ob-lead">
        メモ帳のように、いま選ばれている入力欄に文字が入ります。
        下の枠をクリックしてから、声を出してみてください。
      </p>
      <div class="ob-card">
        <h3>ここをクリック → <span class="ob-kbd">${esc(hotkey)}</span> → 話す → もう一度 <span class="ob-kbd">${esc(hotkey)}</span></h3>
        <textarea class="ob-text ob-notepad" id="practice_pad"
          placeholder="ここをクリックして、${esc(hotkey)} を押してから話してください…"></textarea>
        <div id="practice_success" class="ob-success-box" style="display:none; margin-top:12px;">
          <h3 class="ob-ok" style="margin:0">✓ できました！文字が入りました</h3>
          <p class="ob-note" style="margin-top:4px">
            文字が入るのが確認できました。この調子で、どのアプリでも使えます。
          </p>
        </div>
      </div>
      <div class="ob-card">
        <details id="mic_details">
          <summary style="cursor:pointer; font-weight:600; font-size:14px; color:var(--text-2);">
            うまく入らないとき（マイクを選び直す）
          </summary>
          <div style="margin-top:12px">
            <label for="micpick" style="display:block; font-size:13px; margin-bottom:6px; color:var(--text-2)">
              使うマイク
            </label>
            <select class="ob-select" id="micpick">
              <option value="">既定のマイク</option>${list}
            </select>
            <p class="ob-note" style="margin-top:8px">
              マイクを替えたら、上の枠をクリックしてもう一度試してみてください。
            </p>
            ${S.mic_error ? `
              <p class="ob-bad" style="margin-top:8px">${esc(S.mic_error)}</p>
              <ul class="ob-list">
                <li>Windows の設定 → プライバシーとセキュリティ → マイク で、
                    「アプリがマイクにアクセスできるようにする」を入れてください</li>
                <li>ほかのアプリがマイクを使っていないか確かめてください</li>
              </ul>` : ""}
          </div>
        </details>
      </div>
      <div style="display:flex; justify-content:flex-end; margin-top:12px;">
        <button class="ob-btn ob-ghost" id="skip_practice" type="button">
          あとで試す（スキップ）
        </button>
      </div>
    </div>`;
}

function pageKeys() {
  const c = S.hotkey_check || {};
  const state = c.state || "ok";
  const cls = state === "ok" ? "ob-ok" : (state === "warn" ? "ob-warn" : "ob-bad");
  const others = (S.other_apps || []).map((a) =>
    `<li>${esc(a)}</li>`).join("");
  return `
    <div class="ob-page">
      <h1 class="ob-title">ショートカット</h1>
      <p class="ob-lead">録音を始めるキーです。ほかのアプリとぶつかっていないか調べました。</p>
      <div class="ob-card">
        <h3>録音の開始・停止</h3>
        <p style="font-size:18px;margin:4px 0 12px">
          <span class="ob-kbd">${esc(S.hotkey_label || "Ctrl + Space")}</span>
        </p>
        <p class="ob-note ${cls}">${esc(c.detail || "ぶつかりは見つかりませんでした。")}</p>
        ${c.hint ? `<p class="ob-note">${esc(c.hint)}</p>` : ""}
      </div>
      <div class="ob-card">
        <h3>ほかに選べるキー</h3>
        ${(S.hotkey_options || []).map((o) => `
          <button class="ob-choice" data-key="${esc(o.spec)}"
                  aria-pressed="${o.spec === S.hotkey}">
            <div class="n">${esc(o.label)}</div>
            <div class="d">${esc(o.note)}</div>
          </button>`).join("")}
      </div>
      ${others ? `<div class="ob-card">
        <h3>いま動いている、ほかの音声入力</h3>
        <ul class="ob-list">${others}</ul>
        <p class="ob-note">同じキーを使っていると、どちらも動いてしまいます。</p>
      </div>` : ""}
      <div class="ob-card">
        <h3>取り消しと送信</h3>
        <p class="ob-note">
          録音中だけ <span class="ob-kbd">Esc</span> で取り消し、
          <span class="ob-kbd">Enter</span> で「入力して送信」になります。
          録音していないときは、ふだんどおりのキーです。
        </p>
      </div>
    </div>`;
}

function pageTry() {
  const heard = S.practice || "";
  return `
    <div class="ob-page">
      <h1 class="ob-title">話してみましょう</h1>
      <p class="ob-lead">
        <span class="ob-kbd">${esc(S.hotkey_label || "Ctrl + Space")}</span>
        を押して、なにか話してみてください。
        ここに聞こえた文字が出ます（この画面では、ほかの場所には入りません）。
      </p>
      <div class="ob-card">
        <h3>聞こえたもの</h3>
        <textarea class="ob-text" id="practice" readonly
          placeholder="ここに出ます">${esc(heard)}</textarea>
        <p class="ob-sub" id="trytip" style="margin-top:10px">
          ${S.recording ? "聞いています…" : "待っています"}
        </p>
      </div>
      <div class="ob-card">
        <h3>これだけ覚えれば使えます</h3>
        <ul class="ob-list">
          <li><span class="ob-kbd">${esc(S.hotkey_label || "Ctrl + Space")}</span>
              … 録音の開始と停止</li>
          <li><span class="ob-kbd">Esc</span> … 取り消し</li>
          <li><span class="ob-kbd">Enter</span>（録音中）… 入力して送信</li>
          <li>10 秒黙っていると、自分で止まります</li>
          <li>文の終わりに「はてな」と続けて言うと「？」になります</li>
          <li>録音中にクリックすると止まります（残りの文字はクリップボードへ。Ctrl+V で貼れます）</li>
        </ul>
      </div>
      <div class="ob-card">
        <h3>困ったら</h3>
        <p class="ob-note">
          タスクトレイの絵を右クリック → 設定 → アプリ。
          「動作チェック」で、うまく動かない原因を調べられます。
        </p>
      </div>
    </div>`;
}

const PAGES = [pageWelcome, pagePc, pageModel, pageMic, pageKeys, pageTry];

/* ------------------------------------------------------------ 描く */

function renderSteps() {
  $("steps").innerHTML = STEPS.map((s, i) =>
    `<li data-on="${i < step ? "done" : (i === step ? "now" : "")}"
         title="${esc(s.title)}"></li>`).join("");
}

function render() {
  renderSteps();
  $("main").innerHTML = PAGES[step]();
  $("back").disabled = step === 0;
  $("next").textContent = step === STEPS.length - 1 ? "はじめる" : "つぎへ";
  $("skip").hidden = step === STEPS.length - 1;
  // 次へ進めるか
  let can = true;
  if (step === 1) can = !!S.profile;
  if (step === 2) can = !!S.ready;
  $("next").disabled = !can || busy;
  $("main").focus();
}

/* ------------------------------------------------------------ 動き */

async function refresh() {
  try {
    S = await api("/api/onboarding");
    if (first) {
      first = false;
      // 画面を撮るときや、開き直したときのために、
      // どこから始めるかを URL とサーバーの両方から受け取る
      if (!qs.get("step")) step = Number(S.step || 0);
      const theme = qs.get("theme") || S.theme;
      if (theme) document.documentElement.dataset.theme = theme;
    }
    render();
  } catch (err) {
    console.error(err);
  }
}

async function poll() {
  if (step !== 2 && step !== 5) return;
  try {
    const fresh = await api("/api/onboarding");
    const changed = JSON.stringify(fresh) !== JSON.stringify(S);
    S = fresh;
    if (changed) {
      render();
    }
  } catch (err) { /* 画面が閉じられた */ }
}

function paintMeter() {}

$("main").addEventListener("click", async (ev) => {
  const doer = ev.target.closest("[data-do]");
  const pick = ev.target.closest("[data-pick]");
  const key = ev.target.closest("[data-key]");
  const skipPractice = ev.target.closest("#skip_practice");
  if (skipPractice) {
    if (step < STEPS.length - 1) {
      step += 1;
      onStep();
    }
    return;
  }
  if (doer) {
    const what = doer.dataset.do;
    busy = true;
    doer.disabled = true;
    doer.textContent = what === "probe" ? "調べています…" : "始めています…";
    try {
      await act(what);
    } catch (err) { toast("うまくいきませんでした"); }
    busy = false;
    await refresh();
  } else if (pick) {
    await act("choose", { model: pick.dataset.pick });
    await refresh();
  } else if (key) {
    await act("hotkey", { spec: key.dataset.key });
    await refresh();
  }
});

$("main").addEventListener("input", (ev) => {
  if (ev.target.id === "practice_pad") {
    const success = $("practice_success");
    if (success) {
      if (ev.target.value.trim().length > 0) {
        success.style.display = "block";
      }
    }
  }
});

$("main").addEventListener("change", async (ev) => {
  if (ev.target.id === "micpick") {
    await act("microphone", { value: ev.target.value });
    await refresh();
  }
});

$("back").addEventListener("click", () => {
  if (step > 0) { step -= 1; onStep(); }
});

$("next").addEventListener("click", async () => {
  if (step < STEPS.length - 1) { step += 1; onStep(); return; }
  await act("finish");
  document.body.innerHTML =
    '<div class="ob-shell"><main class="ob-main"><div class="ob-page">' +
    '<h1 class="ob-title">準備ができました</h1>' +
    '<p class="ob-lead">この窓は閉じてかまいません。' +
    esc(S.hotkey_label || "Ctrl + Space") +
    ' を押せば、どこでも話して入力できます。</p>' +
    "</div></main></div>";
  setTimeout(() => api("/api/close", {}).catch(() => {}), 600);
});

$("skip").addEventListener("click", async () => {
  await act("finish", { skipped: true });
  api("/api/close", {}).catch(() => {});
  document.body.innerHTML =
    '<div class="ob-shell"><main class="ob-main"><div class="ob-page">' +
    '<h1 class="ob-title">またあとで</h1>' +
    '<p class="ob-lead">設定 → アプリ → 「初回の案内をもう一度」から開けます。</p>' +
    "</div></main></div>";
});

async function onStep() {
  await act("step", { step });
  await refresh();
}

refresh();
timer = setInterval(poll, 180);
window.addEventListener("beforeunload", () => clearInterval(timer));
