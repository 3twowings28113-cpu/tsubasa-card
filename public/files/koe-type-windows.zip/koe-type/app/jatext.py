"""日本語に向き合うための整形。

このアプリの一番の売り。どの競合も、ここまで日本語を細かく扱っていない。

扱うもの
  ・句読点の量（少なめ／標準／多め）と、記号の全角そろえ
  ・英数字の半角そろえ、日本語と英単語のあいだの空白、数字の書き方
  ・つなぎ言葉（えー、あのー）の除去。一覧は利用者が編集できる
  ・言い直し（「〜じゃなくて〜」）の処理。**初期はオフ**
  ・日本語の音声コマンド（改行・まる・送って）

決め事
  ・**勝手に直さない。** 要約・敬語化・翻訳はしない。
  ・音声コマンドは、**その区間がコマンドそのものだった時だけ**反応する。
    「まるい」の中の「まる」に反応して句点を入れたりしない。
  ・言い直しの処理は誤作動しうるので、初期値はオフ。
"""

from __future__ import annotations

import logging
import re
import unicodedata
from dataclasses import dataclass
from typing import Any

from .learnfix import apply_pairs
from .spelling import (convert_spelled_alphabet, correct_homophones,
                       repair_mixed_loanwords)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------- 句読点


# 読点を増やす位置の候補：助詞のうしろ。
# 直後に句読点や閉じ括弧があるところには入れない。
_COMMA_AFTER = ("ので", "けれど", "けれども", "ですが", "ますが",
                "したら", "すると", "ため", "から", "まで", "ので",
                "ですし", "ますし", "ところ", "ながら", "つつ")
_COMMA_PARTICLES = ("は", "が", "も", "を", "に", "で", "と", "へ", "や")

_PUNCT_ALL = "、。，．！？!?"
_CLOSERS = "」』）)】〕］]｝}\"'"


def _char_class(ch: str) -> str:
    if "぀" <= ch <= "ゟ":
        return "hira"
    if "゠" <= ch <= "ヿ":
        return "kata"
    if "一" <= ch <= "鿿":
        return "kanji"
    if ch.isascii() and ch.isalnum():
        return "ascii"
    return "other"


def thin_commas(text: str, keep_every: int = 14) -> str:
    """読点（、）を減らす。句点（。）は触らない。

    近すぎる読点だけを落とすので、文の意味が変わる位置は残る。
    """
    out: list[str] = []
    since = keep_every        # 最初の読点は残す
    for ch in text:
        if ch == "、":
            if since < keep_every:
                continue      # 直前の読点から近すぎるので落とす
            since = 0
        else:
            since += 1
        out.append(ch)
    return "".join(out)


def add_commas(text: str, min_run: int = 10) -> str:
    """読点（、）を増やす。助詞のうしろで、間隔が空いている所だけ。

    読みやすさのための足し算なので、意味が変わる足し方はしない
    （助詞の直後に限り、しかも前後に十分な長さがある時だけ）。
    """
    result: list[str] = []
    since = 0                 # 直前の区切りからの文字数
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        result.append(ch)
        if ch in _PUNCT_ALL:
            since = 0
            i += 1
            continue
        since += 1
        nxt = text[i + 1] if i + 1 < n else ""
        if nxt and (nxt in _PUNCT_ALL or nxt in _CLOSERS):
            i += 1
            continue
        if since >= min_run and nxt:
            tail = "".join(result)
            hit = next((w for w in _COMMA_AFTER if tail.endswith(w)), "")
            if not hit and ch in _COMMA_PARTICLES:
                # 助詞 1 文字。直前が漢字・カタカナ・英数字なら区切りとみなす
                prev = text[i - 1] if i else ""
                if prev and _char_class(prev) in ("kanji", "kata", "ascii"):
                    hit = ch
            # 残りが短いなら足さない（文末直前に読点を置かない）
            if hit and n - i - 1 >= 4:
                result.append("、")
                since = 0
        i += 1
    return "".join(result)


_WIDE_PUNCT = {"，": "、", "．": "。", ",": "、", ".": "。",
               "!": "！", "?": "？", "：": "：", "；": "；"}


def unify_punct(text: str, *, fullwidth: bool = True) -> str:
    """句読点をそろえる。日本語の文では全角が既定。

    半角のカンマとピリオドは、**数字や英単語の中では触らない**
    （1,000 や 3.14 や example.com を壊さないため）。
    全角の句読点にしたときは、そのうしろの半角空白をのみ込む
    （「晴れ、 明後日」のような不自然な空きを残さないため）。
    """
    out: list[str] = []
    n = len(text)
    i = 0
    while i < n:
        ch = text[i]
        if ch in (",", "."):
            prev = text[i - 1] if i else ""
            nxt = text[i + 1] if i + 1 < n else ""
            if (prev.isascii() and prev.isalnum()) and \
                    (nxt.isascii() and nxt.isalnum()):
                out.append(ch)         # 1,000 / 3.14 / a.b はそのまま
                i += 1
                continue
        if fullwidth and ch in _WIDE_PUNCT:
            wide = _WIDE_PUNCT[ch]
            out.append(wide)
            i += 1
            if wide in "、。！？":
                while i < n and text[i] in " \t":
                    i += 1
            continue
        if not fullwidth and ch in ("、", "。"):
            out.append("," if ch == "、" else ".")
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


# 「ます」「です」の直前の句読点。日本語ではここに区切りは来ない。
# SenseVoice は、少し伸ばして話すと「おはようござ、います」のように
# 言葉の途中へ句読点を入れてくる（2026-10-05 の立ち会いテストで実際に
# 出た）。「はい、ですから」のように文の頭に立つ「です〜」は残す。
_SPLIT_BEFORE_AUX = re.compile(
    r"(?<=[ぁ-ゟァ-ヿ一-鿿])"
    r"[、。][ 	　]*"
    r"(?=い?ま(?:す|した|せん|しょう)"
    r"|でし(?:た|ょう)"
    r"|です(?!から|が|けど|けれど|ので|のに|し(?!た)))")


def join_split_words(text: str) -> str:
    """言葉の途中に入った句読点を取る（「ござ、います」→「ございます」）。"""
    return _SPLIT_BEFORE_AUX.sub("", text)


def tidy_spaces(text: str) -> str:
    """日本語の句読点のまわりの空白を片づける。"""
    text = re.sub(r"[ \t]+([、。！？，．])", r"\1", text)
    text = re.sub(r"([、。！？])[ \t]+", r"\1", text)
    return text


# 書き言葉の接続詞。文の頭のこれらのうしろの読点は残す
_KEEP_AFTER_WORDS = (
    "しかし", "ただ", "ただし", "また", "なお", "つまり", "例えば", "たとえば",
    "だから", "なので", "でも", "そして", "さらに", "一方", "ちなみに",
    "要するに", "ところで", "それで", "それから", "まず", "次に", "最後に",
    "結果", "特に", "もし", "もちろん")
# 文と文のつなぎ目（接続助詞など）。このうしろの読点は、前後が十分
# 長ければ残す
_CLAUSE_ENDS = (
    "けれども", "けれど", "けど", "ので", "から", "のに", "ても", "でも",
    "たら", "なら", "れば", "えば", "ながら", "つつ", "ため", "し", "が",
    "て", "で", "と", "ず", "ずに", "けど",
    # 長い主題（〜においては、〜には、）のあとも、書き言葉では打つ
    "は")
# 読点の前後をつなぐと 1 つの言葉になるもの。言葉を割っている読点は落とす
# （「ファイルと、かって」→ とか、「止まっちゃってる、のも」→ のも）
_SPLIT_PAIRS = ("とか", "のも", "のが", "のは", "ので", "のに", "かも",
                "かな", "でも", "ても", "けど", "って")
# 話し言葉の口ぐせ。このうしろの読点は落とす
_SPOKEN_HEADS = ("あと", "で", "なんか", "まあ", "その", "えっと", "あの",
                 "うん", "それで", "はい", "ええ")


def natural_commas(text: str, *, clause_min: int = 8, long_run: int = 14,
                   tail_min: int = 6) -> str:
    """読点を、日本語の文章の決まりに沿って必要なところだけ残す。

    ★モデルは息つぎのたびに読点を付ける。利用者から「変に多すぎる。
    できるだけ少なく、でも付けるべきところには付けてほしい」と
    頼まれた（2026-10-06）。AI へのプロンプトにも使うので、文の切れ目は
    残したい。モデルが付けた読点を 1 つずつ見て、

      残す：書き言葉の接続詞のあと（ただ、しかし、つまり…）
            文と文のつなぎ目（〜けど、〜ので、〜たら、〜て、…）の
            あと。前が clause_min 文字以上、後ろが tail_min 文字以上
            読点なしで long_run 文字以上続いたところ（長い文を読みやすく）
      落とす：話し言葉の口ぐせのあと（あと、で、なんか、…）
            短い言葉のすぐあと（「止まっちゃってる、のも」）

    新しく読点を足すことはしない（言葉を変えない）。
    """
    if "、" not in text:
        return text
    parts = text.split("、")
    out = parts[0]
    clause = parts[0]           # 直前に残した区切りからの文字
    for i, nxt in enumerate(parts[1:], 1):
        head = re.split(r"[。！？!?]", clause)[-1].strip()
        # 次の読点か文末までの長さ
        ahead = re.split(r"[。！？!?]", nxt)[0]
        if i < len(parts) - 1:
            pass                # ahead は次の読点まで（split 済み）
        keep = False
        if head and nxt and (head[-1] + nxt[:1]) in _SPLIT_PAIRS:
            keep = False         # 言葉を割っている
        elif head in _KEEP_AFTER_WORDS:
            keep = True
        elif head in _SPOKEN_HEADS:
            keep = False
        elif len(head) >= clause_min and len(ahead) >= tail_min and (
                head.endswith(_CLAUSE_ENDS) or len(head) >= long_run):
            keep = True
        if keep:
            out += "、" + nxt
            clause = nxt
        else:
            out += nxt
            clause += nxt
    return out


def punctuation(text: str, density: str = "normal", *,
                fullwidth: bool = True) -> str:
    """句読点の量と形をそろえる。

    density: "none"（取る）/ "few"（少なめ）/ "normal" / "many"（多め）
    """
    density = (density or "normal").lower()
    if density == "none":
        return re.sub(r"[、。，．]", "", text)
    text = unify_punct(text, fullwidth=fullwidth)
    if density == "few":
        # 文章の決まりに沿って必要なところだけ残す（前は近すぎる読点を
        # 落とすだけで、利用者の文ではほとんど減らなかった）
        text = natural_commas(text)
    elif density == "many":
        text = add_commas(text)
    return text


# ---------------------------------------------------------------- 空白と数字


def space_between(text: str, mode: str = "none") -> str:
    """日本語と英単語のあいだの空白。

    mode: "none"（入れない・既定）/ "space"（半角空白を入れる）
    """
    if (mode or "none").lower() != "space":
        return text
    def latin(c: str) -> bool:
        # 数字は対象にしない。「午前 10 時」ではなく「午前10時」が自然。
        return c.isascii() and c.isalpha()

    out: list[str] = []
    ja = ("hira", "kata", "kanji")
    for i, ch in enumerate(text):
        if i:
            prev = text[i - 1]
            a, b = _char_class(prev), _char_class(ch)
            if (latin(prev) and b in ja) or (a in ja and latin(ch)):
                if out and out[-1] != " ":
                    out.append(" ")
        out.append(ch)
    return "".join(out)


_KANJI_DIGITS = {"〇": 0, "零": 0, "一": 1, "二": 2, "三": 3, "四": 4,
                 "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
_KANJI_UNITS = {"十": 10, "百": 100, "千": 1000}
# 漢数字のまま残す語。数ではなく言い回しなので、数字にすると意味が壊れる。
_KEEP_KANJI = (
    "一つ", "二つ", "三つ", "四つ", "五つ", "六つ", "七つ", "八つ", "九つ",
    "一人", "二人", "一番", "一度", "一部", "一方", "一応", "一緒", "一体",
    "一見", "一生", "一瞬", "一同", "一切", "一例", "一式", "一通り",
    "二度", "三度", "四月", "七月", "八月", "十分", "千葉", "九州",
    "十字", "百聞", "千円札", "万一", "三脚", "四角", "五感", "六法",
)
_KANJI_NUM_RE = re.compile(r"[〇零一二三四五六七八九十百千]{1,8}")


def _kanji_to_int(s: str) -> int | None:
    """「三十二」→ 32。読み解けなければ None。"""
    total = 0
    section = 0
    digit: int | None = None
    for ch in s:
        if ch in _KANJI_DIGITS:
            digit = _KANJI_DIGITS[ch]
        elif ch in _KANJI_UNITS:
            unit = _KANJI_UNITS[ch]
            section += (digit if digit is not None else 1) * unit
            digit = None
        else:
            return None
    total = section + (digit or 0)
    return total if total or s in ("〇", "零") else None


def _keep_spans(text: str) -> list[tuple[int, int]]:
    """漢数字のままにする語が、どこにあるか。"""
    spans: list[tuple[int, int]] = []
    for word in _KEEP_KANJI:
        start = text.find(word)
        while start >= 0:
            spans.append((start, start + len(word)))
            start = text.find(word, start + 1)
    return spans


def arabic_numbers(text: str, enabled: bool = False) -> str:
    """漢数字を半角数字にする（初期はオフ）。

    「一つ」「一番」「十分」のような言い回しは変えない。
    残す語の判定は**位置の重なり**で見る。語の一部でも重なっていたら
    触らない（「三十二人」の「二人」に引っぱられて何もしない、
    という取り違えを避けるため、重なりは数字の側だけを見る）。
    """
    if not enabled:
        return text
    keep = _keep_spans(text)

    def repl(m: re.Match[str]) -> str:
        s = m.group(0)
        start, end = m.start(), m.end()
        for ks, ke in keep:
            # 残す語が、この漢数字を**含んでいる**時だけ手を出さない。
            # 「二人」は「三十二」を含まないので、32 への変換は進む。
            if ks <= start and end <= ke:
                return s
        value = _kanji_to_int(s)
        return str(value) if value is not None else s

    return _KANJI_NUM_RE.sub(repl, text)


# ---------------------------------------------------------------- つなぎ言葉


DEFAULT_FILLERS = (
    "えーと", "えーっと", "ええと", "えっと", "えーとですね", "エート", "エット",
    "あのー", "アノー", "あの〜", "あのう", "そのー", "その〜", "そのう",
    "なんか", "まあ", "ええ", "うーん", "ウーン", "う〜ん",
    "んーと", "ん〜と", "ンート", "んー", "ん〜",
    "えー", "エー", "え〜", "あー", "アー", "あ〜",
)

# 前後に読点がなくても、文頭や区切り直後なら安全に削れるフィラー。
# 単語そのものがフィラー確定のもの（長音連続語への誤爆がないもの）。
_COMPOUND_FILLERS = {
    "えーとですね", "えーっと", "えーと", "ええと", "えっと", "エート", "エット",
    "あのー", "アノー", "あの〜", "あのう", "そのー", "その〜", "そのう",
    "うーん", "ウーン", "う〜ん", "んーと", "ん〜と", "ンート",
}

# 短音のフィラー（ひらがな）。直後が「けーびー」などの長音連続語でなければ削る。
_SHORT_HIRA_FILLERS = {
    "あー", "えー", "あ〜", "え〜", "んー", "ん〜",
}

# 短音のフィラー（カタカナ）。直後が別のカタカナ（アーチェリー、エース等）
# でなければ削る。
_SHORT_KATA_FILLERS = {
    "アー", "エー",
}

_PURE_FILLERS = _COMPOUND_FILLERS | _SHORT_HIRA_FILLERS | _SHORT_KATA_FILLERS


def compile_fillers(words) -> tuple[re.Pattern[str], ...] | None:  # noqa: ANN001
    """つなぎ言葉の正規表現を組む。

    Whisper や SenseVoice は「えー今日は」「あーそうですね」「あーラーメン」
    のように、つなぎ言葉の直後に読点を打たずに続けることが多い。
    以前は後続文に長音（「キーボード」「ラーメン」等）が1つでも含まれると
    フィラーが一切削れなくなる不具合があったため、直後の文字種と境界を
    正確に見て安全に削る。

    「アーチェリー」「エース」等のカタカナ一般名詞は守りつつ、
    「あーけーびー」などの略語読みも誤って削らないようにする。
    """
    clean_words = [w.strip() for w in words if w and w.strip()]
    if not clean_words:
        return None

    edge = r"、。，．！？,.!?\s"
    comp_list = [w for w in clean_words if w in _COMPOUND_FILLERS]
    hira_list = [w for w in clean_words if w in _SHORT_HIRA_FILLERS]
    kata_list = [w for w in clean_words if w in _SHORT_KATA_FILLERS]
    context_list = [w for w in clean_words if w not in _PURE_FILLERS]

    patterns: list[re.Pattern[str]] = []

    # 1. 複合フィラー（えーと、あのー等）：直後が長音単体でなければ安全に削る
    if comp_list:
        body = "|".join(re.escape(w) for w in
                        sorted(comp_list, key=len, reverse=True))
        patterns.append(re.compile(
            rf"(?:\A|(?<=[{edge}]))(?:{body})(?:[{edge}]+|(?=[^ー\s]|\Z))"
        ))

    # 2. ひらがな短音フィラー（あー、えー等）：「あーけーびー」等の長音連続を
    # 避けつつ削る
    if hira_list:
        body = "|".join(re.escape(w) for w in
                        sorted(hira_list, key=len, reverse=True))
        patterns.append(re.compile(
            rf"(?:\A|(?<=[{edge}]))(?:{body})(?:[{edge}]+|(?![ぁ-ん]ー)(?=[^ー\s]|\Z))"
        ))

    # 3. カタカナ短音フィラー（アー、エー）：直後が別のカタカナ（アーチェリー、
    # エース等）でなければ削る
    if kata_list:
        body = "|".join(re.escape(w) for w in
                        sorted(kata_list, key=len, reverse=True))
        patterns.append(re.compile(
            rf"(?:\A|(?<=[{edge}]))(?:{body})(?:[{edge}]+|(?![ァ-ヴー])(?=[^ー\s]|\Z))"
        ))

    # 4. 文の途中のフィラー（「今日はあー雨です」「それでえー次は」）。
    # モデルは文中のつなぎ言葉の前後に読点を打たないことが多く、1〜3 の
    # 「文頭か区切りの直後だけ」では残っていた。助詞のすぐ後ろに来たときだけ
    # 削る。助詞の前にも文字があることを条件にして、文頭のため息
    # （「はあー疲れた」）は残す。「ね」は「ねえー」を壊すので入れない。
    # 「あーいう」「あーして」「あーなる」は「ああいう」の書きかたなので残す。
    mid_list = [w for w in comp_list + hira_list
                if not re.search(r"[ァ-ヴ]", w)]
    if mid_list:
        body = "|".join(re.escape(w) for w in
                        sorted(mid_list, key=len, reverse=True))
        patterns.append(re.compile(
            rf"(?<=[^{edge}][はがをにでとも])(?:{body})"
            rf"(?:[{edge}]+|\Z|(?![ぁ-ん]ー|い[うっえ]|し[てたな]|す[るれ]|な[るっ])"
            rf"(?=[^ー〜\s]))"
        ))

    # 5. 文脈依存フィラー（なんか、まあ等）：前後が区切り文字のときだけ削る
    if context_list:
        body = "|".join(re.escape(w) for w in
                        sorted(context_list, key=len, reverse=True))
        patterns.append(re.compile(
            rf"(?:\A|(?<=[{edge}]))(?:{body})(?=\Z|[{edge}])"
        ))

    return tuple(patterns) if patterns else None


def remove_fillers(text: str,
                   patterns: tuple[re.Pattern[str], ...] | re.Pattern[str] | None
                   ) -> str:
    if patterns is None:
        return text
    pats = (patterns,) if isinstance(patterns, re.Pattern) else patterns
    out = text
    for pat in pats:
        out = pat.sub("", out)
    # 残った「、、」や行頭・末尾の読点を片づける
    out = re.sub(r"[、，]{2,}", "、", out)
    out = re.sub(r"^[、，\s]+|[、，\s]+$", "", out)
    return out


# ---------------------------------------------------------------- 言い直し


# 「〜じゃなくて〜」の形。前半を捨てて後半を残す。
_RESTATE = re.compile(
    r"(?:^|[、。])([^、。]{2,30}?)"
    r"(?:じゃなくて|ではなくて|ではなく|じゃなく|ではない|じゃない、)"
    r"\s*([^、。]{1,40})")


def fix_restatement(text: str, enabled: bool = False) -> str:
    """「AじゃなくてB」を B にする（初期はオフ）。

    便利だが取り違えもある（「冗談じゃなくて本当です」を縮めてしまう）ので、
    既定ではそのまま残す。
    """
    if not enabled or not text:
        return text

    def repl(m: re.Match[str]) -> str:
        head = m.group(0)[0] if m.group(0)[0] in "、。" else ""
        return head + m.group(2)

    out = _RESTATE.sub(repl, text)
    if out != text:
        log.info("言い直しを整えました: %r -> %r", text[:60], out[:60])
    return out


# ---------------------------------------------------------------- 音声コマンド


@dataclass(frozen=True)
class Command:
    """音声コマンド 1 つ。

    kind は "text"（value を入れる）/ "submit"（送信）/ "undo"（取り消し）。
    """
    phrases: tuple[str, ...]
    kind: str
    value: str = ""
    ja: str = ""
    en: str = ""


DEFAULT_COMMANDS = (
    Command(("改行", "かいぎょう", "新しい行", "行を変えて"), "text", "\n",
            "改行を入れる", "Insert a line break"),
    Command(("段落", "新しい段落"), "text", "\n\n",
            "段落を変える", "Start a new paragraph"),
    Command(("まる", "丸", "句点"), "text", "。",
            "句点（。）を入れる", "Insert a full stop"),
    Command(("てん", "点", "読点"), "text", "、",
            "読点（、）を入れる", "Insert a comma"),
    Command(("はてな", "ハテナ", "疑問符", "クエスチョン", "はてなマーク",
             "クエスチョンマーク"), "text", "？",
            "疑問符（？）を入れる", "Insert a question mark"),
    Command(("かっこ", "括弧"), "text", "「」",
            "かぎ括弧を入れる", "Insert quote brackets"),
    Command(("送って", "送信", "送信して", "そうしん"), "submit", "",
            "そのまま送信する", "Send it"),
    Command(("取り消し", "取消", "とりけし", "やっぱりなし"), "undo", "",
            "直前の入力を取り消す", "Undo the last typing"),
    Command(("日本語モード", "日本語入力", "にほんごもーど"), "lang_ja", "",
            "日本語入力に切り替える", "Switch to Japanese"),
    Command(("英語モード", "英語入力", "えいごもーど"), "lang_en", "",
            "英語入力に切り替える", "Switch to English"),
    Command(("言語切り替え", "言語切替", "モード切り替え"), "lang_toggle", "",
            "認識言語を順に切り替える", "Toggle recognition language"),
)

_TRIM = re.compile(r"[、。，．！？!?\s　]+")


def normalise_command(text: str) -> str:
    """コマンドと見比べるための形にそろえる。"""
    return _TRIM.sub("", unicodedata.normalize("NFKC", text)).lower()


def match_command(text: str, commands=DEFAULT_COMMANDS):  # noqa: ANN001, ANN201
    """区間まるごとがコマンドだったら、その Command を返す。

    **一部分には反応しない。** 「まるいテーブル」の「まる」に反応して
    句点を入れてしまわないようにするため。言うときは、前後に少し間を置いて
    「改行」だけを言う。
    """
    key = normalise_command(text)
    if not key or len(key) > 12:
        return None
    for cmd in commands:
        for phrase in cmd.phrases:
            if key == normalise_command(phrase):
                return cmd
    return None


# ---------------------------------------------------------------- まとめ


@dataclass
class Options:
    """整形の設定をひとまとめにしたもの。"""
    punctuation: str = "normal"      # none / few / normal / many
    fullwidth_punct: bool = True
    halfwidth_alnum: bool = True
    spacing: str = "none"            # none / space
    arabic_numbers: bool = False
    questions: str = "never"      # 疑問符の付けかた（既定は付けない）
    full_stops: str = "off"       # 「。」の付けかた off / end / model
    fillers: bool = True
    filler_words: tuple[str, ...] = DEFAULT_FILLERS
    restatement: bool = False
    # 文の終わりの「はてな」を「？」にする（音声コマンドが有効なとき）
    tail_question: bool = True
    symbol_commands: tuple[dict[str, Any], ...] | list[dict[str, Any]] = ()
    # アルファベット読み（「エフディーイー」等）を大文字英語（「FDE」）に変換
    convert_spelled_alphabet: bool = True
    # 外来語の混在崩れ（「アニnotion」等）を元の外来語に戻す
    repair_mixed_loanwords: bool = True
    # 同音異義語・同訓異義語の文脈自動補正（「機械/機会」「暑い/熱い」等）
    fix_homophones: bool = True
    # 利用者が直して採用した学習ペア（src → dst）。整形の最後に当てる
    learned_pairs: tuple[tuple[str, str], ...] = ()


# 記号の呼び方の初期設定（「はてな → ？」のみ初期値で有効）
DEFAULT_SYMBOL_COMMANDS: tuple[dict[str, Any], ...] = (
    {"word": "はてな", "symbol": "？", "enabled": True},
    {"word": "クエスチョン", "symbol": "？", "enabled": True},
    {"word": "はてなマーク", "symbol": "？", "enabled": True},
    {"word": "びっくり", "symbol": "！", "enabled": False},
    {"word": "感嘆符", "symbol": "！", "enabled": False},
    {"word": "改行", "symbol": "\n", "enabled": False},
    {"word": "まる", "symbol": "。", "enabled": False},
    {"word": "てん", "symbol": "、", "enabled": False},
)

# 文の終わりで「？」に替える言い方。音声コマンドの「はてな」と同じ仲間。
# ★それだけを区切って言ったときしか効かなかったが、自然には
# 「ご機嫌どうかなはてな」と続けて言う（2026-10-05 立ち会いテスト）。
TAIL_QUESTION_WORDS = ("はてなマーク", "ハテナマーク", "はてな", "ハテナ",
                       "クエスチョンマーク", "クエスチョン", "疑問符")
_TAIL_QUESTION = re.compile(
    r"[、。，．\s　]*(?:" + "|".join(TAIL_QUESTION_WORDS) + r")"
    r"[、。？?！!\s　]*$")


def tail_symbols(text: str,
                 symbols: list[dict[str, Any]] | tuple[dict[str, Any], ...] | None = None) -> str:
    """文の終わりの記号の言葉（「はてな」など）を記号（「？」など）にする。

    **文の終わりだけ**にする。途中の「はてなブログ」は触らない。
    言葉だけの区間は音声コマンドのほうで扱うので、ここでは
    前に言葉があるときだけ替える。
    """
    if not text:
        return text
    if symbols is None:
        symbols = DEFAULT_SYMBOL_COMMANDS

    active = [s for s in symbols
              if s.get("enabled", True) and s.get("word")
              and s.get("symbol") is not None]
    if not active:
        return text

    # 長い言葉から順に試す（部分一致での先行誤爆を防ぐ）
    active.sort(key=lambda s: len(str(s["word"])), reverse=True)

    for s in active:
        w = re.escape(str(s["word"]))
        pat = re.compile(rf"[、。，．\s　]*(?:{w})[、。？?！!\s　]*$")
        m = pat.search(text)
        if m and m.start() > 0:
            sym = str(s["symbol"])
            return text[:m.start()] + sym

    return text


def tail_question(text: str) -> str:
    """文の終わりの「はてな」などを「？」にする（互換用）。"""
    return tail_symbols(text)


def format_text(text: str, opt: Options, *, final: bool = False) -> str:
    """文字起こしの生の結果を、入力できる形に整える。

    順番が大事。**先に記号をそろえてから**つなぎ言葉を消す。
    そうしないと「えーと, 明日は」の半角カンマが境目と見なされず、
    つなぎ言葉が残ってしまう。

    final は「これが録音の最後の区間」という印。
    「。」を最後だけ付ける設定で使う。
    """
    if not text:
        return text
    # 1. 記号の形をそろえる（数の中のカンマは触らない）
    text = unify_punct(text, fullwidth=opt.fullwidth_punct)
    text = tidy_spaces(text)
    text = join_split_words(text)
    # 2. つなぎ言葉を消す
    if opt.fillers:
        text = remove_fillers(text, compile_fillers(opt.filler_words))
    # 3. 言い直し（既定はオフ）
    text = fix_restatement(text, opt.restatement)
    # 4. 句読点の量と、付けすぎの疑問符
    text = punctuation(text, opt.punctuation, fullwidth=opt.fullwidth_punct)
    text = question_marks(text, opt.questions)
    text = full_stops(text, opt.full_stops, final=final)
    # 「？」を付けない設定でも、自分で言った「はてな」は「？」にする。
    # だから疑問符と句点をそろえたあとで行う。
    if opt.tail_question:
        symbols = opt.symbol_commands if opt.symbol_commands else None
        text = tail_symbols(text, symbols)
    # 5. 外来語の混在崩れの修復（アニnotion -> アニメーション）。
    #    アルファベット読み変換より先に行う。崩れた形のままでは、
    #    そちらの英字アンカー処理（英字＋カナの混在解決）に触れて
    #    形が変わるおそれがあるため。また、手順6の space_between
    #    （空白を入れる設定）より前でないと、空白が挟まって
    #    「カタカナ＋英単語」の融合した形そのものが壊れてしまう。
    if opt.repair_mixed_loanwords:
        text = repair_mixed_loanwords(text)
    # 5b. アルファベット読みの変換（エフディーイー -> FDE）
    if opt.convert_spelled_alphabet:
        text = convert_spelled_alphabet(text)
    # 5c. 同音異義語・同訓異義語の文脈自動補正（機械/機会、暑い/熱いなど）
    if opt.fix_homophones:
        text = correct_homophones(text)
    # 6. 数字と空白
    text = arabic_numbers(text, opt.arabic_numbers)
    text = space_between(text, opt.spacing)
    text = tidy_spaces(text)
    # 7. 学習ペア（利用者が直して採用した置き換え）。
    #    「元の形」は整形後の最終形を見て直されたものなので、
    #    全ての整形が済んだここで当てる。辞書や文脈補正より
    #    後に効く＝本人の確定した直しが推測に勝つ、という順序
    #    （app/learnfix.py の冒頭の説明も参照）。
    if opt.learned_pairs:
        text = apply_pairs(text, opt.learned_pairs)
    return text.strip(" \t　")

# ---------------------------------------------------------------- 疑問符


# 日本語で「質問している」と分かる言い方。
# これが無いのに「？」が付いていたら、モデルの付けすぎとみなす。
#
# ★「の」だけは外した。「隣りの？」のような**途中で切れた言葉**にも
# 当たってしまい、疑問でないところに「？」が残った。
# 「なぜそうなるの？」は疑問詞のほうで拾えるので、取りこぼさない。
_QUESTION_TAIL = re.compile(
    r"(?:"
    r"か|かな|かね|かい|かしら|っけ|だろうか|でしょうか|ますか|ですか"
    r"|のか|ないか|ないの|ませんか|ましょうか"
    r")[\s]*[？?]\s*$")

# 疑問詞。文のどこかにあれば質問とみなす。
_QUESTION_WORDS = re.compile(
    r"(?:なに|何|なん|だれ|誰|どなた|いつ|どこ|どちら|どっち|どれ|どの"
    r"|どう|どんな|なぜ|なんで|どうして|いくら|いくつ|どのくらい|どれくらい)")

# 言い切りの「？」を何に替えるか
_Q_REPLACE = "。"


def question_marks(text: str, mode: str = "never") -> str:
    """付けすぎの「？」を落とす。

    SenseVoice は、質問でないものにも「？」を付けてくる。
    実際の利用で、認識結果 258 件のうち **92 件（36%）** が「？」で
    終わっていた。同じ音でも回ごとに「テスト？」「テスト。」と揺れる。

    mode
      "model"  モデルの出したまま
      "smart"  質問の言い方のときだけ残す（既定）
      "never"  いつも落とす
    """
    mode = (mode or "smart").lower()
    if mode == "model" or "？" not in text and "?" not in text:
        return text
    if mode == "never":
        return re.sub(r"[？?]+", _Q_REPLACE, text)

    out = []
    for part in re.split(r"(?<=[。！？?])", text):
        if not part:
            continue
        if part.rstrip().endswith(("？", "?")):
            keep = bool(_QUESTION_TAIL.search(part)
                        or _QUESTION_WORDS.search(part))
            if not keep:
                part = re.sub(r"[？?]+\s*$", _Q_REPLACE, part.rstrip())
        out.append(part)
    return "".join(out)


# ---------------------------------------------------------------- 句点

# モデルは、言葉を切るたびに「。」を付けてくる。
# 「導入した後に。うまいこといかなかったんだよ」のように、
# 文の途中で切れてしまうので、ふだんは付けないのを既定にする。

_DOTS = "。"               # 。
_KEEP_TAIL = "？！?!"  # ？ ！ は残す


def full_stops(text: str, mode: str = "off", *,
               final: bool = False) -> str:
    """「。」の付けかたをそろえる。

    mode
      "off"    付けない（既定）。モデルが付けた「。」を全部取る。
      "end"    録音の最後だけ付ける。途中の区切りでは付けない。
      "model"  モデルのまま。

    「、」には触らない。文の中の区切りとしては自然に働くので。
    """
    if not text:
        return text
    mode = (mode or "off").lower()
    if mode == "model":
        return text

    body = text.replace(_DOTS, "")
    body = re.sub(r"[ \t\u3000]{2,}", " ", body).strip(" \t\u3000")
    if mode == "end" and final and body and body[-1] not in _KEEP_TAIL:
        body += _DOTS
    return body
