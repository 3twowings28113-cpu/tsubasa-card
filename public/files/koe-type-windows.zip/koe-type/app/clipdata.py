"""クリップボードの中身を読む・書く。

読むもの（どれも HGLOBAL のメモリブロック。GDI のハンドルの形式には
**触らない**。inject.py の snapshot_clipboard と同じ理由で、
CF_BITMAP などに GlobalLock を使うとヒープが壊れて即死する）

  ・CF_UNICODETEXT … 文字
  ・"HTML Format" / "Rich Text Format" … 書式（あれば一緒に残す）
  ・"PNG" / CF_DIB / CF_DIBV5 … 画像（PNG があればそれを優先。透明が残る）
  ・CF_HDROP … エクスプローラーでコピーしたファイル

記録しないもの

  ・パスワード管理アプリなどが「記録しないで」と印を付けたもの
    （ExcludeClipboardContentFromMonitorProcessing /
     Clipboard Viewer Ignore / CanIncludeInClipboardHistory = 0）
  ・koe-type 自身が音声入力のために一時的に置いたもの

`KOE_TYPE_DRY_RUN=1` のときは、クリップボードへ**1 回も書かない**。
何を書くはずだったかを dryrun に記録するだけにする。
"""

from __future__ import annotations

import ctypes
import hashlib
import logging
import struct
import time
from ctypes import wintypes
from dataclasses import dataclass, field
from pathlib import Path

from . import dryrun

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)

CF_UNICODETEXT = 13
CF_DIB = 8
CF_DIBV5 = 17
CF_HDROP = 15
GMEM_MOVEABLE = 0x0002
GMEM_INVALID_HANDLE = 0x8000

_vp = ctypes.c_void_p
user32.OpenClipboard.argtypes = [wintypes.HWND]
user32.OpenClipboard.restype = wintypes.BOOL
user32.CloseClipboard.restype = wintypes.BOOL
user32.EmptyClipboard.restype = wintypes.BOOL
user32.GetClipboardData.argtypes = [wintypes.UINT]
user32.GetClipboardData.restype = _vp
user32.SetClipboardData.argtypes = [wintypes.UINT, _vp]
user32.SetClipboardData.restype = _vp
user32.IsClipboardFormatAvailable.argtypes = [wintypes.UINT]
user32.IsClipboardFormatAvailable.restype = wintypes.BOOL
user32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
user32.RegisterClipboardFormatW.restype = wintypes.UINT
user32.GetClipboardSequenceNumber.restype = wintypes.DWORD
user32.GetClipboardOwner.restype = wintypes.HWND
user32.GetForegroundWindow.restype = wintypes.HWND
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                            ctypes.POINTER(wintypes.DWORD)]
user32.AddClipboardFormatListener.argtypes = [wintypes.HWND]
user32.AddClipboardFormatListener.restype = wintypes.BOOL
user32.RemoveClipboardFormatListener.argtypes = [wintypes.HWND]
user32.RemoveClipboardFormatListener.restype = wintypes.BOOL
kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
kernel32.GlobalAlloc.restype = _vp
kernel32.GlobalLock.argtypes = [_vp]
kernel32.GlobalLock.restype = _vp
kernel32.GlobalUnlock.argtypes = [_vp]
kernel32.GlobalUnlock.restype = wintypes.BOOL
kernel32.GlobalFree.argtypes = [_vp]
kernel32.GlobalFree.restype = _vp
kernel32.GlobalSize.argtypes = [_vp]
kernel32.GlobalSize.restype = ctypes.c_size_t
kernel32.GlobalFlags.argtypes = [_vp]
kernel32.GlobalFlags.restype = wintypes.UINT
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL,
                                 wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
kernel32.QueryFullProcessImageNameW.argtypes = [
    wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR,
    ctypes.POINTER(wintypes.DWORD)]
shell32.DragQueryFileW.argtypes = [_vp, wintypes.UINT, wintypes.LPWSTR,
                                   wintypes.UINT]
shell32.DragQueryFileW.restype = wintypes.UINT

_formats: dict[str, int] = {}


def fmt(name: str) -> int:
    """名前つきのクリップボード形式の番号（覚えておく）。"""
    if name not in _formats:
        _formats[name] = int(user32.RegisterClipboardFormatW(name) or 0)
    return _formats[name]


def sequence() -> int:
    """クリップボードが書き換わるたびに増える番号。"""
    return int(user32.GetClipboardSequenceNumber())


# ---------------------------------------------------------------- 読む


@dataclass
class Captured:
    """クリップボードから読んだもの。"""

    kind: str = ""                   # text / image / files（空なら記録しない）
    text: str = ""
    html: bytes = b""
    rtf: bytes = b""
    png: bytes = b""                 # "PNG" 形式（あれば）
    dib: bytes = b""                 # CF_DIB（PNG がないとき）
    files: list[str] = field(default_factory=list)
    app: str = ""
    skipped: str = ""                # 記録しない理由
    seq: int = 0

    def hash(self) -> str:
        """同じものかどうかを見分けるための指紋。"""
        h = hashlib.sha1()
        if self.kind == "text":
            h.update(("t:" + self.text).encode("utf-8"))
        elif self.kind == "image":
            h.update(b"i:")
            h.update(self.png if self.png else self.dib)
        elif self.kind == "files":
            h.update(("f:" + "\n".join(self.files)).encode("utf-8"))
        return h.hexdigest()


def _global_bytes(handle: int | None, limit: int) -> bytes | None:
    """メモリブロックの中身を読む。メモリブロックでなければ None。"""
    if not handle:
        return None
    if kernel32.GlobalFlags(handle) == GMEM_INVALID_HANDLE:
        return None
    size = kernel32.GlobalSize(handle)
    if not size or size > limit:
        return None
    ptr = kernel32.GlobalLock(handle)
    if not ptr:
        return None
    try:
        return ctypes.string_at(ptr, size)
    finally:
        kernel32.GlobalUnlock(handle)


def _decode_text(raw: bytes) -> str:
    text = raw.decode("utf-16-le", "replace")
    end = text.find("\x00")
    return text[:end] if end >= 0 else text


def exe_of_window(hwnd: int) -> str:
    """その窓を持つアプリの実行ファイル名（例 "chrome.exe"）。"""
    if not hwnd:
        return ""
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value:
        return ""
    handle = kernel32.OpenProcess(0x1000, False, pid.value)
    if not handle:
        return ""
    try:
        size = wintypes.DWORD(260)
        buf = ctypes.create_unicode_buffer(size.value)
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf,
                                               ctypes.byref(size)):
            return Path(buf.value).name
    finally:
        kernel32.CloseHandle(handle)
    return ""


def source_app() -> str:
    """いまのクリップボードを置いたアプリ。分からなければ前面のアプリ。"""
    try:
        name = exe_of_window(int(user32.GetClipboardOwner() or 0))
        if name:
            return name
        return exe_of_window(int(user32.GetForegroundWindow() or 0))
    except Exception:
        return ""


def marked_private() -> str:
    """「記録しないで」の印が付いていれば、その印の名前。

    開かずに調べられるものは開かずに調べる（速く・相手を待たせない）。
    """
    for name in ("ExcludeClipboardContentFromMonitorProcessing",
                 "Clipboard Viewer Ignore"):
        number = fmt(name)
        if number and user32.IsClipboardFormatAvailable(number):
            return name
    return ""


def _open(hwnd: int, tries: int = 1) -> bool:
    for i in range(max(1, tries)):
        if user32.OpenClipboard(hwnd):
            return True
        if i + 1 < tries:
            time.sleep(0.015)
    return False


def read(hwnd: int, *, images: bool = True, files: bool = True,
         formatting: bool = True, honor_private: bool = True,
         max_text_bytes: int = 4 * 1024 * 1024,
         max_image_bytes: int = 64 * 1024 * 1024) -> Captured | None:
    """いまのクリップボードを読む。開けなければ None（あとでもう一度）。

    **開いている時間を短くする。** 開いているあいだ、ほかのアプリは
    クリップボードを使えない。PNG への変換などの重い仕事は、閉じて
    から別のスレッドで行う。
    """
    out = Captured(seq=sequence())
    if honor_private:
        out.skipped = marked_private()
        if out.skipped:
            return out
    if not _open(hwnd):
        return None
    try:
        if honor_private:
            number = fmt("CanIncludeInClipboardHistory")
            if number and user32.IsClipboardFormatAvailable(number):
                raw = _global_bytes(user32.GetClipboardData(number), 64)
                if raw and len(raw) >= 4 and not struct.unpack_from(
                        "<I", raw)[0]:
                    out.skipped = "CanIncludeInClipboardHistory"
                    return out
        if user32.IsClipboardFormatAvailable(CF_HDROP):
            handle = user32.GetClipboardData(CF_HDROP)
            if handle and files:
                count = shell32.DragQueryFileW(handle, 0xFFFFFFFF, None, 0)
                names = []
                for i in range(min(count, 500)):
                    length = shell32.DragQueryFileW(handle, i, None, 0)
                    buf = ctypes.create_unicode_buffer(length + 1)
                    shell32.DragQueryFileW(handle, i, buf, length + 1)
                    if buf.value:
                        names.append(buf.value)
                if names:
                    out.kind = "files"
                    out.files = names
                    return out
            elif not files:
                out.skipped = "files_off"
                return out
        if user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
            raw = _global_bytes(user32.GetClipboardData(CF_UNICODETEXT),
                                max_text_bytes)
            if raw is None and kernel32.GlobalSize(
                    user32.GetClipboardData(CF_UNICODETEXT) or 0) \
                    > max_text_bytes:
                out.skipped = "too_large"
                return out
            if raw:
                out.text = _decode_text(raw)
        if out.text.strip():
            out.kind = "text"
            if formatting:
                for name, attr in (("HTML Format", "html"),
                                   ("Rich Text Format", "rtf")):
                    number = fmt(name)
                    if number and user32.IsClipboardFormatAvailable(number):
                        raw = _global_bytes(user32.GetClipboardData(number),
                                            4 * 1024 * 1024)
                        if raw:
                            setattr(out, attr, raw.rstrip(b"\x00"))
            return out
        if not images:
            if (user32.IsClipboardFormatAvailable(CF_DIB)
                    or user32.IsClipboardFormatAvailable(fmt("PNG"))):
                out.skipped = "images_off"
            return out
        number = fmt("PNG")
        if number and user32.IsClipboardFormatAvailable(number):
            raw = _global_bytes(user32.GetClipboardData(number),
                                max_image_bytes)
            if raw and raw[:8] == b"\x89PNG\r\n\x1a\n":
                out.kind = "image"
                out.png = raw
                return out
        for number in (CF_DIB, CF_DIBV5):
            if user32.IsClipboardFormatAvailable(number):
                raw = _global_bytes(user32.GetClipboardData(number),
                                    max_image_bytes)
                if raw and len(raw) > 40:
                    out.kind = "image"
                    out.dib = raw
                    return out
                if raw is None:
                    out.skipped = "too_large"
                    return out
        return out
    finally:
        user32.CloseClipboard()


# ---------------------------------------------------------------- 書く


def _alloc(data: bytes) -> int:
    handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, max(1, len(data)))
    if not handle:
        return 0
    ptr = kernel32.GlobalLock(handle)
    if not ptr:
        kernel32.GlobalFree(handle)
        return 0
    ctypes.memmove(ptr, data, len(data))
    kernel32.GlobalUnlock(handle)
    return handle


def hdrop(paths: list[str]) -> bytes:
    """CF_HDROP（DROPFILES ＋ 名前の並び）を作る。"""
    names = "".join(p + "\x00" for p in paths) + "\x00"
    # DROPFILES: pFiles(20) / pt(0,0) / fNC(0) / fWide(1)
    return struct.pack("<IiiII", 20, 0, 0, 0, 1) + names.encode("utf-16-le")


def private_marks() -> list[tuple[int, bytes]]:
    """Win+V の履歴・クラウド・ほかの記録アプリに残さない印。"""
    out = []
    for name in ("CanIncludeInClipboardHistory",
                 "CanUploadToCloudClipboard"):
        number = fmt(name)
        if number:
            out.append((number, (0).to_bytes(4, "little")))
    number = fmt("ExcludeClipboardContentFromMonitorProcessing")
    if number:
        out.append((number, b"\x00"))
    return out


def write(hwnd: int, *, text: str | None = None, html: bytes = b"",
          rtf: bytes = b"", dib: bytes = b"", png: bytes = b"",
          files: list[str] | None = None, private: bool = False) -> int:
    """クリップボードに置く。置いたあとの番号（失敗は 0）。

    private=True なら、Win+V の履歴やクラウドに残さない印を付ける
    （パスワードなど「秘密」にした項目）。
    """
    items: list[tuple[int, bytes]] = []
    if text is not None:
        items.append((CF_UNICODETEXT,
                      text.encode("utf-16-le") + b"\x00\x00"))
    if html:
        items.append((fmt("HTML Format"), html + b"\x00"))
    if rtf:
        items.append((fmt("Rich Text Format"), rtf + b"\x00"))
    if dib:
        items.append((CF_DIB, dib))
    if png:
        items.append((fmt("PNG"), png))
    if files:
        items.append((CF_HDROP, hdrop(files)))
        # エクスプローラーで貼ったときに「移動」ではなく「コピー」にする
        items.append((fmt("Preferred DropEffect"),
                      (1).to_bytes(4, "little")))
    if private:
        items += private_marks()
    if dryrun.enabled():
        dryrun.record("clip_put", text=text, html=bool(html), rtf=bool(rtf),
                      image=bool(dib or png), files=list(files or []),
                      private=private)
        # 「書けた」ことにして、そのあとの流れ（秘密を消すなど）も試せる
        # ようにする。本物の番号とぶつからない値にしておく。
        return 1
    if not _open(hwnd, tries=12):
        log.warning("クリップボードを開けませんでした（ほかのアプリが使用中）")
        return 0
    try:
        user32.EmptyClipboard()
        for number, data in items:
            if not number:
                continue
            handle = _alloc(data)
            if handle and not user32.SetClipboardData(number, handle):
                kernel32.GlobalFree(handle)
    finally:
        user32.CloseClipboard()
    return sequence()


def clear_if(seq: int, hwnd: int) -> bool:
    """まだ自分が置いたままなら、クリップボードを空にする。

    秘密の項目を貼ったあと、しばらくしてから消すために使う。
    ほかのものがコピーされていたら、何もしない。
    """
    if dryrun.enabled():
        dryrun.record("clip_clear", seq=seq)
        return True
    if not seq or sequence() != seq:
        return False
    if not _open(hwnd, tries=5):
        return False
    try:
        user32.EmptyClipboard()
    finally:
        user32.CloseClipboard()
    return True


def listen(hwnd: int) -> bool:
    return bool(user32.AddClipboardFormatListener(hwnd))


def unlisten(hwnd: int) -> None:
    try:
        user32.RemoveClipboardFormatListener(hwnd)
    except Exception:
        pass
