"""モデルを**常駐**させる文字起こし。

これまでは、聞き取るたびに exe を起動してモデルを読み直していた。
実測で**1 回につき約 0.6 秒**がその固定費で、計算そのものは
30 秒の音でも 0.5 秒ほどしかかかっていなかった。
つまり遅さの原因は計算ではなく、毎回モデルを読み直すことだった。

ここでは `transcribe.dll`（transcribe.cpp / MIT）を ctypes で読み、
**モデルをメモリに置いたまま**何度でも使う。固定費が消えるので、
「話しながら」の聞き直しを 0.2 秒ごとに回せる。

決め事
  ・**既定ではモデルを外さない。** 使っていない間も置いたままにする
    （Handy が数分でモデルを外し、次に使う時に待たされるのを見て決めた）。
  ・外す設定にした場合も、録音を始めた瞬間に読み込みを始める。
  ・読み込みは別スレッドで行い、**待っている間も本体は止まらない**。
  ・DLL が読めない（Smart App Control に止められた等）場合は、
    これまでの exe を起こす方式へ自動で戻る。

この PC での実測（Intel Arc 140V / Vulkan）
  SenseVoice Small  : 4.5 秒の音を 0.1 秒台（常駐）
  whisper-large-v3-turbo: 同じ音を約 1.15 秒
  Fun-ASR-MLT-Nano  : **Vulkan では結果が壊れる**（1 トークンの繰り返し）。
                      CPU なら正しいが 6.8 秒かかるので使わない。
"""

from __future__ import annotations

import array
import logging
import os
import sys
import threading
import time
from pathlib import Path

from .util import BIN_DIR, MODEL_DIR, ROOT

log = logging.getLogger(__name__)

# transcribe.cpp の実体を置く場所（リポジトリには含めない）
NATIVE_DIRS = (
    BIN_DIR / "transcribe-cpp" / "transcribe-native-windows-x86_64-cpu-vulkan",
    BIN_DIR / "transcribe-cpp",
)
VENDOR = ROOT / "vendor"

SAMPLE_RATE = 16000


class ResidentError(RuntimeError):
    pass


# ---------------------------------------------------------------- 読み込み


_tcpp = None            # 読み込んだ transcribe_cpp モジュール
_tcpp_error = ""        # 読めなかった理由
_import_lock = threading.Lock()


def _where() -> str:
    """置き場所の案内。ROOT の外を指していても落ちないようにする。"""
    target = NATIVE_DIRS[0]
    try:
        return str(target.relative_to(ROOT))
    except ValueError:
        return str(target)


def native_dir() -> Path | None:
    """transcribe.dll があるフォルダ。なければ None。"""
    for folder in NATIVE_DIRS:
        if (folder / "transcribe.dll").is_file():
            return folder
    return None


def available() -> tuple[bool, str]:
    """常駐方式が使えるか。(使えるか, 理由) を返す。"""
    if os.environ.get("KOE_TYPE_NO_RESIDENT"):
        # 検証用の差し替え：常駐エンジンがない PC のふるまいを再現する
        return False, "常駐エンジンを使わない設定で動いています（検証用）"
    folder = native_dir()
    if folder is None:
        return False, (f"transcribe.dll が見つかりません（{_where()} に置きます）")
    if not (VENDOR / "transcribe_cpp" / "__init__.py").is_file():
        return False, "vendor/transcribe_cpp がありません"
    try:
        load_binding()
    except ResidentError as exc:
        return False, str(exc)
    return True, ""


def load_binding():  # noqa: ANN201
    """transcribe_cpp を読み込む（1 回だけ）。"""
    global _tcpp, _tcpp_error
    with _import_lock:
        if _tcpp is not None:
            return _tcpp
        if _tcpp_error:
            raise ResidentError(_tcpp_error)
        folder = native_dir()
        if folder is None:
            _tcpp_error = "transcribe.dll が見つかりません"
            raise ResidentError(_tcpp_error)
        try:
            # DLL の置き場所を先に教える（依存 DLL もここから読む）
            os.environ["TRANSCRIBE_LIBRARY"] = str(folder / "transcribe.dll")
            os.add_dll_directory(str(folder))
            if str(VENDOR) not in sys.path:
                sys.path.insert(0, str(VENDOR))
            import transcribe_cpp  # noqa: PLC0415
            _tcpp = transcribe_cpp
            _route_log(transcribe_cpp)
            log.info("常駐方式を使えます（transcribe.cpp %s）",
                     getattr(transcribe_cpp, "__version__", "?"))
            return _tcpp
        except Exception as exc:
            # Smart App Control に止められた場合もここに来る
            _tcpp_error = f"transcribe.dll を読めません: {exc}"
            if not _has_msvcp():
                # ★エンジンの DLL はすべて MSVCP140.dll に頼っている。
                # まっさらな PC には無いことがあり、そのときの Windows の
                # 言葉（「依存するモジュールが見つかりません」）では、
                # 何を入れればよいか分からない。
                _tcpp_error = (
                    "Visual C++ ランタイム（msvcp140.dll）が見つからない"
                    "ため、文字起こしのエンジンを読めません。"
                    "持ち運べる版（runtime フォルダに同梱）を使うか、"
                    "Microsoft の「Visual C++ 再頒布可能パッケージ」を"
                    "入れてください。")
            log.warning("常駐方式は使えません: %s", exc)
            raise ResidentError(_tcpp_error) from exc


def _has_msvcp() -> bool:
    """Visual C++ ランタイム（msvcp140.dll）を読めるか。"""
    import ctypes  # noqa: PLC0415
    try:
        ctypes.WinDLL("msvcp140.dll")
        return True
    except OSError:
        return False


def _route_log(tcpp) -> None:  # noqa: ANN001
    """エンジンのつぶやきを、画面ではなく自分のログへ流す。

    何もしないと ggml が標準出力へ直接書き、コンソールのない常駐アプリでは
    行き場のない出力になる（最悪、窓が一瞬出る）。
    """
    levels = {1: logging.INFO, 2: logging.WARNING, 3: logging.ERROR,
              4: logging.DEBUG, 5: logging.DEBUG}

    def sink(level: int, text: str) -> None:
        message = (text or "").rstrip()
        if message:
            log.log(levels.get(level, logging.DEBUG), "[engine] %s", message)

    try:
        tcpp.set_log_callback(sink)
    except Exception:
        log.debug("エンジンのログを引き取れませんでした", exc_info=True)


# ---------------------------------------------------------------- 音の変換


def to_float(pcm: bytes) -> array.array:
    """16bit の PCM を、エンジンが受け取る float32 の並びにする。"""
    ints = array.array("h")
    ints.frombytes(pcm[:len(pcm) - len(pcm) % 2])
    return array.array("f", (s / 32768.0 for s in ints))


# ---------------------------------------------------------------- 本体


class Resident:
    """1 つのモデルを常駐させて、何度でも文字起こしする。

    スレッドから同時に呼ばれても安全。エンジン側の 1 つのセッションを
    鍵で守る（同時に走らせても GPU の取り合いで速くならないため）。
    """

    def __init__(self, model_path: Path, *, backend: str = "vulkan",
                 language: str = "ja", n_threads: int = 0) -> None:
        self.path = Path(model_path)
        self.backend = backend
        self.language = language
        self.n_threads = n_threads
        self._model = None
        self._session = None
        self._lock = threading.RLock()
        # セッションの世代と、その世代の実行を直列化する鍵。
        # 実行がハングしたら世代ごと捨てて作り直す（transcribe_pcm）。
        # 世代を分けると、詰まった鍵を後続が待たずに済む。
        self._gen = 0
        self._run_lock = threading.Lock()
        self._loading = threading.Event()
        self._load_error = ""
        self.load_seconds = 0.0
        self.runs = 0
        self.total_seconds = 0.0
        self.last_seconds = 0.0

    # ------------------------------------------------------------ 読み込み

    @property
    def ready(self) -> bool:
        return self._session is not None

    @property
    def session(self):  # noqa: ANN201
        """transcribe_cpp の Session。Whisper の直接音声翻訳で使う。"""
        self.load()
        return self._session

    @property
    def error(self) -> str:
        return self._load_error

    def load(self) -> None:
        """モデルを読み込む。すでに読んであれば何もしない。"""
        with self._lock:
            if self._session is not None:
                return
            if not self.path.is_file():
                self._load_error = f"モデルがありません: {self.path.name}"
                raise ResidentError(self._load_error)
            tcpp = load_binding()
            t0 = time.perf_counter()
            try:
                model = tcpp.Model(self.path, backend=self.backend)
                session = tcpp.Session(model, n_threads=self.n_threads)
            except Exception as exc:
                self._load_error = f"{self.path.name} を読めません: {exc}"
                log.error("常駐モデルの読み込みに失敗: %s", exc)
                raise ResidentError(self._load_error) from exc
            self._model = model
            self._session = session
            self.load_seconds = time.perf_counter() - t0
            self._load_error = ""
            log.info("常駐モデルを読みました %s (%s) %.2fs arch=%s",
                     self.path.name, self.backend, self.load_seconds,
                     getattr(model, "arch", "?"))

    def load_async(self) -> None:
        """読み込みを別スレッドで始める（本体を止めない）。"""
        if self._session is not None or self._loading.is_set():
            return
        self._loading.set()

        def run() -> None:
            try:
                self.load()
            except Exception:
                log.debug("非同期の読み込みに失敗", exc_info=True)
            finally:
                self._loading.clear()

        threading.Thread(target=run, name="model-load", daemon=True).start()

    def unload(self) -> None:
        """メモリから外す。既定では呼ばない。"""
        with self._lock:
            session, self._session = self._session, None
            model, self._model = self._model, None
            # 世代も進める。実行がハングしたまま unload されても、
            # 次の読み込みが詰まった世代の鍵を待たないため。
            self._gen += 1
            self._run_lock = threading.Lock()
        for obj in (session, model):
            try:
                if obj is not None:
                    obj.close()
            except Exception:
                log.debug("後片付けで例外", exc_info=True)
        if session is not None:
            log.info("常駐モデルを外しました: %s", self.path.name)

    # ------------------------------------------------------------ 文字起こし

    def transcribe_pcm(self, pcm: bytes, *, vocabulary=None,  # noqa: ANN001
                       timeout: float = 30.0) -> str:
        """16bit PCM を文字にする。空の結果もあり得る。

        ★timeout は飾りではない（2026-10-31 第三者監査 H2 で実効化）。
        以前は session.run を状態の鍵の中で直接呼んでいたため、DLL や
        GPU がハングすると鍵を握ったまま全認識が永久に止まり、
        unload() すら同じ鍵待ちで回復手段が無かった。
        いまは実行を別スレッドへ出し、timeout を過ぎたらその世代の
        セッションを捨てて作り直し、呼び出し側へエラーを返す。
        ハングしたスレッド自体は DLL の中では止められないので、
        世代を進めて後続が二度とその鍵・セッションを待たない形にする。
        """
        if not pcm:
            return ""
        if timeout is None:
            timeout = 30.0
        self.load()
        samples = to_float(pcm)
        if not len(samples):
            return ""
        tcpp = load_binding()
        kw: dict = {"language": self.language}
        if vocabulary:
            kw["vocabulary"] = list(vocabulary)
        t0 = time.perf_counter()
        with self._lock:
            gen, session = self._gen, self._session
            run_lock = self._run_lock
        if session is None:
            raise ResidentError("モデルが読み込まれていません")
        outcome: dict = {}
        started = threading.Event()

        def work() -> None:
            # 前の実行が詰まったままなら、ここで長く待たず諦める。
            # 呼び出し側も同じ timeout で見張っており、世代を作り直す。
            if not run_lock.acquire(timeout=max(0.05, timeout)):
                outcome["stuck"] = True
                started.set()
                return
            try:
                started.set()
                try:
                    outcome["result"] = session.run(samples, **kw)
                except tcpp.errors.UnsupportedRequest:
                    # 語彙ヒントを受け付けないモデルだった。
                    # 無しでやり直す。
                    kw.pop("vocabulary", None)
                    outcome["result"] = session.run(samples, **kw)
            except BaseException as exc:  # noqa: BLE001
                # 呼び出し側のスレッドで、そのままの形で扱う
                outcome["error"] = exc
            finally:
                run_lock.release()

        worker = threading.Thread(target=work, name="resident-run",
                                  daemon=True)
        worker.start()
        if not started.wait(timeout):
            # 実行が始まらない（前の実行が鍵を握ったまま等）。
            self._abandon(gen, timeout)
            raise ResidentError(
                f"認識が {timeout:.1f} 秒を超えたので、"
                "セッションを作り直しました")
        # 始まったあとは、実行そのものに timeout を与える
        worker.join(timeout)
        if worker.is_alive() or outcome.get("stuck"):
            # 終わらない／鍵が取れなかった。どちらもこの世代は
            # 詰んでいるので作り直して失敗を返す。
            self._abandon(gen, timeout)
            raise ResidentError(
                f"認識が {timeout:.1f} 秒を超えたので、"
                "セッションを作り直しました")
        error = outcome.get("error")
        if isinstance(error, tcpp.errors.OutputRepetition):
            # 同じ字をくり返して止まった。入力には回さない。
            # ★計時は統計へ入れる。失敗した実行ほど抜け落ちると
            # average_seconds が実態より速く見え、速度番人の判断が
            # ずれる（2026-10-31 第三者監査 L12）。
            self._note_run(t0)
            log.warning("結果がくり返しになったので捨てます（%.1f秒ぶん）",
                        len(samples) / SAMPLE_RATE)
            return ""
        if error is not None:
            raise error
        result = outcome["result"]
        self._note_run(t0)
        text = (result.text or "").strip()
        log.info("認識 %.3fs (%s / 常駐): %s", self.last_seconds,
                 self.path.stem, text.replace("\n", " ")[:160])
        return text

    def _note_run(self, t0: float) -> None:
        """実行 1 回ぶんの計時を統計へ反映する。

        成功時だけでなく、結果を捨てる実行（繰り返し検出）でも
        呼ぶ。実行した事実と所要時間はどちらも同じだからである。
        """
        self.last_seconds = time.perf_counter() - t0
        self.runs += 1
        self.total_seconds += self.last_seconds

    def _abandon(self, gen: int, timeout: float) -> None:
        """詰まった世代のセッションを捨て、新しい世代を用意する。

        ハングした実行スレッドと、そのセッションは閉じない（DLL の
        実行中に閉じると二重に壊しかねない）。参照を手放すだけにし、
        モデルは使い回してセッションだけ作り直す。世代が既に進んで
        いたら、ほかのスレッドが先に作り直したので何もしない。
        """
        with self._lock:
            if gen != self._gen:
                return
            log.error("認識が %.1f 秒を超えたのでセッションを作り"
                      "直します（世代 %d を破棄）", timeout, gen)
            self._gen += 1
            self._run_lock = threading.Lock()
            self._session = None
            if self._model is None:
                return
            try:
                tcpp = load_binding()
                self._session = tcpp.Session(self._model,
                                             n_threads=self.n_threads)
                self._load_error = ""
                log.info("セッションを作り直しました: %s",
                         self.path.name)
            except Exception as exc:
                self._load_error = f"セッションを作り直せません: {exc}"
                log.error("セッションの作り直しに失敗: %s", exc)

    @property
    def average_seconds(self) -> float:
        return self.total_seconds / self.runs if self.runs else 0.0

    def warmup(self, long_seconds: float = 0.0) -> None:
        """読み込みと、最初の 1 回を済ませておく。

        long_seconds を渡すと、速く動く PC では、その長さの無音でも
        1 回空回しする。★エンジンは作業用のメモリを「それまでで最長の
        音」に合わせて取り、長い音が来るたびに一段大きく取り直す。
        使っている途中で取り直すと、長時間テストで「メモリが +17MB
        増えた」ように見え（2026-10-05。最長の区切りが 3.55 → 3.60 秒に
        なった瞬間と一致）、その 1 回は少し待たされる。最初に最長ぶんを
        取っておけば、あとは使い回すだけになる。
        """
        try:
            self.load()
            self.transcribe_pcm(bytes(SAMPLE_RATE))      # 0.5 秒の無音
            short = self.last_seconds
            # GPU がない PC では長い空回しに数秒かかり、起動直後に話し
            # 始めた人を待たせるので、速いときだけにする
            if long_seconds > 0 and short < 0.25:
                self.transcribe_pcm(bytes(int(SAMPLE_RATE * 2
                                              * long_seconds)))
                log.info("長い音のぶんも用意しました（%.0f 秒 / %.3fs）",
                         long_seconds, self.last_seconds)
            log.info("ウォームアップ完了 %s（読み込み %.2fs / 1回 %.3fs）",
                     self.path.stem, self.load_seconds, short)
        except Exception as exc:
            log.warning("ウォームアップできませんでした: %s", exc)


# ---------------------------------------------------------------- 置き場所


def model_file(name: str) -> Path:
    return MODEL_DIR / name
