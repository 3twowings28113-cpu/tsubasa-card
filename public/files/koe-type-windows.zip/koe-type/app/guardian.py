"""見張り役。koe-type が落ちたり固まったりしたら、起動し直す。

本体とは**別のプロセス**で動く。本体が固まっても、こちらは動き続ける。
やることは 2 つだけなので、とても軽い（5 秒に 1 回ファイルを見るだけ）。

  1. 本体の「心拍」が止まっていないか見る
  2. 止まっていたら、古いほうを終わらせて起動し直す

起動し直したことは、短く知らせる（タスクトレイの吹き出し）。

    pythonw -m app.guardian          # 見張りを始める
    python -m app.guardian --once    # 1 回だけ見る（検証用）
"""

from __future__ import annotations

import argparse
import ctypes
import logging
import os
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.restartguard import RestartGuard  # noqa: E402
from app.util import LOG_DIR, setup_logging  # noqa: E402

log = logging.getLogger("guardian")

HEARTBEAT = LOG_DIR / "heartbeat"
STALE_SECONDS = 30            # これだけ心拍が止まったら、固まったとみなす
STUCK_SECONDS = 20            # 「止める途中」がこれだけ続いたら異常
CHECK_SECONDS = 5
# ★再起動の上限・間隔は restartguard が一元管理する（2026-10-24 改修）。
# 以前は RESTART_GAP=60 / MAX_RESTARTS=5 をこのプロセスのメモリで数えて
# いたため、見張り役や本体が作り直されるたびに数が 0 に戻り、歯止めが
# 効かないまま再起動が無限に続いた。いまはファイルに残し、全経路
# （guardian / reloader / 自動更新）合計で数える。
GUARD_PATH = LOG_DIR / "restart-guard.json"
# 見張り自体を止める逃げ道：このファイルがある間は見張りを始めない。
# 環境変数 KOE_TYPE_NO_GUARDIAN=1 でも同じ。
DISABLE_PATH = LOG_DIR / "guardian.off"

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.OpenMutexW.argtypes = [wintypes.DWORD, wintypes.BOOL,
                                wintypes.LPCWSTR]
kernel32.OpenMutexW.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

MUTEX_NAME = "Global\\koe-type-single"
SYNCHRONIZE = 0x00100000


def app_running() -> bool:
    """本体が起動しているか（多重起動よけの鍵を見る）。"""
    handle = kernel32.OpenMutexW(SYNCHRONIZE, False, MUTEX_NAME)
    if handle:
        kernel32.CloseHandle(handle)
        return True
    return False


def heartbeat_age() -> float:
    """心拍が最後に打たれてからの秒数。ないときは大きな数。"""
    try:
        return max(0.0, time.time() - HEARTBEAT.stat().st_mtime)
    except OSError:
        return 1e9


def heartbeat_fields() -> dict:
    """心拍に書かれた「いまの状態」。読めないときは空。

    1 行目は時刻。2 行目から `名前=値` が並ぶ。
    """
    try:
        text = HEARTBEAT.read_text("utf-8", "replace")
    except OSError:
        return {}
    out = {}
    for line in text.splitlines()[1:]:
        if "=" in line:
            key, _, value = line.partition("=")
            out[key.strip()] = value.strip()
    return out


def stuck_seconds() -> float:
    """「止める途中」のまま、何秒経っているか。

    本体は 3 秒で自分から待機へ戻す作りになっている。それでも戻れて
    いないなら、本体の中で何かが固まっている。
    """
    try:
        return float(heartbeat_fields().get("stopping", 0.0))
    except ValueError:
        return 0.0


def launch() -> bool:
    """本体を起動する。"""
    pythonw = Path(sys.executable)
    if pythonw.name.lower().startswith("python") and \
            not pythonw.name.lower().startswith("pythonw"):
        candidate = pythonw.with_name("pythonw.exe")
        if candidate.is_file():
            pythonw = candidate
    target = ROOT / "koe-type.pyw"
    if not target.is_file():
        log.error("起動するものが見つかりません: %s", target)
        return False
    try:
        # --restarted：止めた古いほうが消えきる前でも、待ってから動く
        # （待たないと「すでに起動している」で自分から終わってしまう）
        subprocess.Popen(  # noqa: S603
            [str(pythonw), str(target), "--restarted"], cwd=str(ROOT),
            creationflags=0x08000000)       # CREATE_NO_WINDOW
        log.warning("koe-type を起動し直しました")
        return True
    except Exception:
        log.exception("起動し直せませんでした")
        return False


WM_CLOSE = 0x0010
PROCESS_TERMINATE = 0x0001

user32 = ctypes.WinDLL("user32", use_last_error=True)
user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
user32.FindWindowW.restype = wintypes.HWND
user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND,
                                            ctypes.POINTER(wintypes.DWORD)]
user32.GetWindowThreadProcessId.restype = wintypes.DWORD
user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT,
                                ctypes.c_void_p, ctypes.c_void_p]
kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL,
                                 wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]

HIDDEN_CLASS = "KoeTypeHiddenWindow"


def stop_app(*, wait: float = 6.0) -> bool:
    """固まった本体を終わらせる。**まず穏やかに頼み、それでも駄目なら切る。**

    ここに来るのは「心拍は打っているのに、止める途中のまま
    20 秒以上戻れない」ときだけ。放っておくと利用者は
    Ctrl+Space が効かないまま取り残される。
    """
    hwnd = user32.FindWindowW(HIDDEN_CLASS, None)
    if not hwnd:
        return False
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    log.warning("本体（pid=%d）に終了をお願いします", pid.value)
    user32.PostMessageW(hwnd, WM_CLOSE, None, None)

    deadline = time.time() + wait
    while time.time() < deadline:
        if not app_running():
            log.info("穏やかに終わりました")
            return True
        time.sleep(0.3)

    if not pid.value:
        return False
    log.error("終われないので、プロセス（pid=%d）を切ります", pid.value)
    handle = kernel32.OpenProcess(PROCESS_TERMINATE, False, pid.value)
    if not handle:
        log.error("プロセスを開けませんでした")
        return False
    try:
        kernel32.TerminateProcess(handle, 1)
    finally:
        kernel32.CloseHandle(handle)
    time.sleep(1.0)
    return not app_running()


def _guard(state: dict) -> RestartGuard:
    """再起動の門番を返す（テストでは差し替えられるよう state に持つ）。"""
    guard = state.get("guard")
    if guard is None:
        guard = RestartGuard(GUARD_PATH)
        state["guard"] = guard
    return guard


def _try_restart(state: dict, source: str) -> bool:
    """門番の許可が出たときだけ記録して True。許可は全経路で共有される。

    ★以前は「止める途中」経路に上限チェック自体が無く、もう一方の経路も
    プロセス内メモリで数えていたため、実質無制限だった（2026-10-24）。
    """
    ok, why = _guard(state).try_acquire(source)
    if not ok:
        if not state.get("gave_up"):
            state["gave_up"] = True
            log.error("再起動を止めます: %s。"
                      "直したら手で起動し直してください", why)
        return False
    return True


def check(state: dict) -> str:
    """1 回だけ見る。戻り値は何をしたか。"""
    running = app_running()
    age = heartbeat_age()

    if running and age < STALE_SECONDS:
        state["bad"] = 0
        state["gave_up"] = False
        state["seen_beat"] = True
        # ★メインループが生きているか（心拍の ticks が増えているか）を
        # 先に見る（2026-10-24 追加修正）。心拍ファイルは health スレッドが
        # 1 秒ごとに書くので、ファイルが新しいだけではメインループが
        # 生きている証拠にならない。逆に ticks が増えているなら、文字
        # 起こしの停止処理が長引いていても「処理中」なだけで異常ではない。
        # 以前は stopping の継続秒数だけで kill していたため、重い文字
        # 起こしのセッション終了を「プロセス異常終了」と誤認して
        # 起動し直し続けていた（初回文字起こし後にだけ暴走する症状）。
        try:
            ticks_now = int(float(heartbeat_fields().get("ticks", "")))
        except (TypeError, ValueError):
            ticks_now = None
        if ticks_now is not None:
            if state.get("last_ticks") is not None and \
                    ticks_now != state["last_ticks"]:
                state["last_ticks"] = ticks_now
                state["stuck"] = 0
                return "ok"
            state["last_ticks"] = ticks_now
        # 心拍は打っているが、「止める途中」で居残っていないか。
        # 本体は 3 秒で自分から戻る作りなので、ここに来るのは異常。
        stuck = stuck_seconds()
        if stuck >= STUCK_SECONDS:
            state["stuck"] = state.get("stuck", 0) + 1
            if state["stuck"] >= 2:
                state["stuck"] = 0
                if _try_restart(state, "guardian-stuck"):
                    log.error("止める途中で %.0f 秒止まっています → "
                              "起動し直します", stuck)
                    stop_app()
                    return "起動し直しました" if launch() else "起動し直せません"
                return "起動し直しを止めました（上限に達しました）"
            return f"中途半端なまま {stuck:.0f} 秒（様子見）"
        state["stuck"] = 0
        return "ok"

    if running and not HEARTBEAT.exists():
        # 心拍を書かない版が動いている（古い版など）。
        # 「固まった」と決めつけて起動し直すと、かえって迷惑になる。
        state["bad"] = 0
        return "心拍のない版が動いています（何もしません）"

    why = "動いていません" if not running else f"心拍が {age:.0f} 秒止まっています"
    state["bad"] = state.get("bad", 0) + 1
    if state["bad"] < 2:
        # 1 回だけなら様子を見る（起動の途中かもしれない）
        return f"様子見（{why}）"

    if not _try_restart(state, "guardian"):
        return "起動し直しを止めました（上限に達しました）"
    state["bad"] = 0
    log.warning("%s → 起動し直します", why)
    return "起動し直しました" if launch() else "起動し直せませんでした"


GUARDIAN_MUTEX = "Local\\koe-type-guardian"
_mutex_handle = None
kernel32.CreateMutexW.argtypes = [ctypes.c_void_p, wintypes.BOOL,
                                  wintypes.LPCWSTR]
kernel32.CreateMutexW.restype = wintypes.HANDLE


def _only_one() -> bool:
    """見張り役の鍵を取る。もう誰かが持っていれば False。

    鍵はプロセスが終わるまで持ち続ける（終われば Windows が外す）。
    """
    global _mutex_handle
    handle = kernel32.CreateMutexW(None, False, GUARDIAN_MUTEX)
    if not handle:
        return True               # 調べられないときは、今までどおり動く
    if ctypes.get_last_error() == 183:          # ERROR_ALREADY_EXISTS
        kernel32.CloseHandle(handle)
        return False
    _mutex_handle = handle
    return True


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--once", action="store_true", help="1 回だけ見る")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    # 本体と同じファイルを開くと、Windows ではログを回せなくなり、
    # 本体のログが途中から 1 行も残らなかった（2026-10-06）。別にする。
    setup_logging("INFO", name="guardian.log")
    state: dict = {}

    if os.environ.get("KOE_TYPE_NO_GUARDIAN") or DISABLE_PATH.exists():
        # 逃げ道：見張りを止めたいときは logs/guardian.off を置くか
        # 環境変数 KOE_TYPE_NO_GUARDIAN=1。暴走時に本体ごと止められる。
        log.warning("見張りは無効化されています（guardian.off / "
                    "KOE_TYPE_NO_GUARDIAN）")
        return 0

    if not args.once and not _only_one():
        # ★見張り役はひとりでよい。本体は起動のたびに見張り役を起こす
        # ので、ホットリロードや再起動のたびに 1 つずつ増え、終わらずに
        # 46 個たまっていた（2026-10-11 発覚）。本体が落ちたときに
        # 全員が同時に起動し直そうとする恐れもあった。
        log.info("見張り役はもう動いているので、終わります")
        return 0

    if args.once:
        result = check(state)
        print(f"本体: {'動いている' if app_running() else '動いていない'} / "
              f"心拍: {heartbeat_age():.1f} 秒前 / 判定: {result}")
        return 0

    log.info("見張りを始めます（%d 秒ごと）", CHECK_SECONDS)
    # 起動直後は本体の立ち上がりを待つ
    time.sleep(CHECK_SECONDS * 2)
    while True:
        try:
            result = check(state)
            if result != "ok" and not args.quiet:
                log.info("見張り: %s", result)
        except Exception:
            log.exception("見張りで例外")
        time.sleep(CHECK_SECONDS)


if __name__ == "__main__":
    raise SystemExit(main())
