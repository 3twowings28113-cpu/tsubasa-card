"""マイク入力。Windows 標準の winmm.dll(waveIn) を ctypes で直接叩く。

外部ライブラリを入れずに済ませるため。16kHz / 16bit / モノラルで取り込む。
Smart App Control が有効な環境でも、OS 標準 DLL なのでブロックされない。
"""

from __future__ import annotations

import collections
import ctypes
import logging
import os
import threading
import time
import wave
from ctypes import wintypes
from pathlib import Path

log = logging.getLogger(__name__)

winmm = ctypes.WinDLL("winmm.dll")

SAMPLE_RATE = 16000
SAMPLE_WIDTH = 2
CHANNELS = 1
CHUNK_MS = 50
CHUNK_BYTES = SAMPLE_RATE * SAMPLE_WIDTH * CHUNK_MS // 1000
N_BUFFERS = 12

WAVE_MAPPER = 0xFFFFFFFF
WAVE_FORMAT_PCM = 1
CALLBACK_NULL = 0x00000000
WHDR_DONE = 0x00000001
MMSYSERR_NOERROR = 0


class WAVEFORMATEX(ctypes.Structure):
    _fields_ = [
        ("wFormatTag", wintypes.WORD),
        ("nChannels", wintypes.WORD),
        ("nSamplesPerSec", wintypes.DWORD),
        ("nAvgBytesPerSec", wintypes.DWORD),
        ("nBlockAlign", wintypes.WORD),
        ("wBitsPerSample", wintypes.WORD),
        ("cbSize", wintypes.WORD),
    ]


class WAVEHDR(ctypes.Structure):
    pass


WAVEHDR._fields_ = [
    ("lpData", ctypes.c_void_p),
    ("dwBufferLength", wintypes.DWORD),
    ("dwBytesRecorded", wintypes.DWORD),
    ("dwUser", ctypes.c_void_p),
    ("dwFlags", wintypes.DWORD),
    ("dwLoops", wintypes.DWORD),
    ("lpNext", ctypes.POINTER(WAVEHDR)),
    ("reserved", ctypes.c_void_p),
]

HWAVEIN = ctypes.c_void_p

winmm.waveInOpen.argtypes = [
    ctypes.POINTER(HWAVEIN), wintypes.UINT, ctypes.POINTER(WAVEFORMATEX),
    ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD,
]
winmm.waveInPrepareHeader.argtypes = [HWAVEIN, ctypes.POINTER(WAVEHDR), wintypes.UINT]
winmm.waveInUnprepareHeader.argtypes = [HWAVEIN, ctypes.POINTER(WAVEHDR), wintypes.UINT]
winmm.waveInAddBuffer.argtypes = [HWAVEIN, ctypes.POINTER(WAVEHDR), wintypes.UINT]
winmm.waveInStart.argtypes = [HWAVEIN]
winmm.waveInStop.argtypes = [HWAVEIN]
winmm.waveInReset.argtypes = [HWAVEIN]
winmm.waveInClose.argtypes = [HWAVEIN]


def _err(code: int, what: str) -> None:
    if code != MMSYSERR_NOERROR:
        buf = ctypes.create_unicode_buffer(256)
        try:
            winmm.waveInGetErrorTextW(code, buf, 256)
            detail = buf.value
        except Exception:
            detail = ""
        raise OSError(f"{what} が失敗しました (code={code}) {detail}")


class WAVEINCAPS(ctypes.Structure):
    _fields_ = [
        ("wMid", wintypes.WORD),
        ("wPid", wintypes.WORD),
        ("vDriverVersion", wintypes.UINT),
        ("szPname", wintypes.WCHAR * 32),
        ("dwFormats", wintypes.DWORD),
        ("wChannels", wintypes.WORD),
        ("wReserved1", wintypes.WORD),
    ]


winmm.waveInGetDevCapsW.argtypes = [ctypes.c_size_t, ctypes.POINTER(WAVEINCAPS),
                                    wintypes.UINT]


def devices() -> list[tuple[int, str]]:
    """使えるマイクの一覧 [(番号, 名前)]。WAVE_MAPPER は含めない。"""
    if os.environ.get("KOE_TYPE_NO_MIC"):
        return []          # 検証用の差し替え：マイクがない PC を再現する
    out: list[tuple[int, str]] = []
    try:
        for i in range(int(winmm.waveInGetNumDevs())):
            caps = WAVEINCAPS()
            if winmm.waveInGetDevCapsW(i, ctypes.byref(caps),
                                       ctypes.sizeof(WAVEINCAPS)) == 0:
                out.append((i, caps.szPname))
    except Exception:
        log.exception("マイクの一覧を取得できませんでした")
    return out


def resolve_device(name: str) -> int:
    """設定に入っているマイク名から番号を引く。空や見つからない時は既定。"""
    if not name:
        return WAVE_MAPPER
    for index, label in devices():
        if label == name:
            return index
    log.warning("マイク '%s' が見つからないので既定のマイクを使います", name)
    return WAVE_MAPPER


class Recorder:
    """録音を開始/停止し、50ms ごとの PCM ブロックをコールバックへ渡す。

    `preroll_ms` を正の値にすると「待ち受け」ができる。マイクを開いたまま
    直近の音だけを輪っか状のバッファに置いておき、録音を始めた瞬間に
    その分を先に流し込む。**押す前に話し始めても出だしが切れない。**
    輪っかの音はメモリの上だけで、保存も文字起こしもしない。
    """

    def __init__(self, on_chunk) -> None:  # noqa: ANN001
        self._on_chunk = on_chunk
        self.device_name = ""
        self.preroll_ms = 0
        self._handle: HWAVEIN | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._headers: list[WAVEHDR] = []
        self._buffers: list[ctypes.Array] = []
        self._fake: threading.Thread | None = None
        self._lock = threading.Lock()
        self._deliver = False
        # 録音していないあいだの音を見たい人（声の大きさの表示用）。
        # ★前は取り置き（話し始めを逃さない用）にしか流しておらず、
        # 初回の案内の「声が届いているか」の線が動かなかった（2026-10-06）。
        self.on_idle = None
        self._ring: collections.deque[bytes] = collections.deque()
        self._last_data = 0.0
        self._fail = 0

    @property
    def active(self) -> bool:
        """録音中（コールバックへ渡している）か。"""
        return self._deliver or self._fake is not None

    @property
    def listening(self) -> bool:
        """マイクを開いて待ち受けているか。"""
        return self._handle is not None

    @property
    def silent_for(self) -> float:
        """最後に音が届いてからの秒数。0 は未計測。"""
        return (time.monotonic() - self._last_data) if self._last_data else 0.0

    # ---------------------------------------------------------- 待ち受け

    def listen(self) -> None:
        """マイクを開いて、直近の音だけをためておく（録音はしない）。"""
        if os.environ.get("KOE_TYPE_FAKE_MIC", ""):
            return
        if self.preroll_ms <= 0:
            return
        try:
            self._open()
        except Exception:
            log.warning("待ち受けのためのマイクを開けませんでした", exc_info=True)

    def unlisten(self) -> None:
        """待ち受けをやめてマイクを閉じる。"""
        if not self._deliver:
            self._close()

    def _ring_limit(self) -> int:
        return max(1, int(self.preroll_ms / CHUNK_MS) + 1)

    def _ring_bytes(self) -> bytes:
        return b"".join(self._ring)

    def start(self) -> None:
        fake = os.environ.get("KOE_TYPE_FAKE_MIC", "")
        if fake:
            self._start_fake(Path(fake))
            return
        self._open()
        with self._lock:
            if self._deliver:
                return
            head = self._ring_bytes()
            self._ring.clear()
            self._deliver = True
        if head:
            log.info("押す前の %.2f 秒を先に渡します",
                     len(head) / (SAMPLE_RATE * SAMPLE_WIDTH))
            try:
                self._on_chunk(head)
            except Exception:
                log.exception("プリロールの処理で例外")
        log.info("録音を開始しました")

    def _open(self) -> None:
        """マイクを開く（すでに開いていれば何もしない）。"""
        if os.environ.get("KOE_TYPE_NO_MIC"):
            raise OSError("マイクがありません（検証用の差し替え）")
        with self._lock:
            if self._handle is not None:
                return
            fmt = WAVEFORMATEX(
                wFormatTag=WAVE_FORMAT_PCM,
                nChannels=CHANNELS,
                nSamplesPerSec=SAMPLE_RATE,
                nAvgBytesPerSec=SAMPLE_RATE * SAMPLE_WIDTH * CHANNELS,
                nBlockAlign=SAMPLE_WIDTH * CHANNELS,
                wBitsPerSample=SAMPLE_WIDTH * 8,
                cbSize=0,
            )
            handle = HWAVEIN()
            device = resolve_device(self.device_name)
            rc = winmm.waveInOpen(ctypes.byref(handle), device,
                                  ctypes.byref(fmt), None, None, CALLBACK_NULL)
            if rc != MMSYSERR_NOERROR and device != WAVE_MAPPER:
                log.warning("選んだマイクを開けなかったので既定のマイクを使います")
                rc = winmm.waveInOpen(ctypes.byref(handle), WAVE_MAPPER,
                                      ctypes.byref(fmt), None, None,
                                      CALLBACK_NULL)
            _err(rc, "waveInOpen")
            self._handle = handle
            self._headers = []
            self._buffers = []
            for _ in range(N_BUFFERS):
                buf = ctypes.create_string_buffer(CHUNK_BYTES)
                hdr = WAVEHDR(
                    lpData=ctypes.cast(buf, ctypes.c_void_p),
                    dwBufferLength=CHUNK_BYTES,
                    dwBytesRecorded=0, dwUser=None, dwFlags=0, dwLoops=0,
                )
                _err(winmm.waveInPrepareHeader(handle, ctypes.byref(hdr),
                                               ctypes.sizeof(WAVEHDR)),
                     "waveInPrepareHeader")
                _err(winmm.waveInAddBuffer(handle, ctypes.byref(hdr),
                                           ctypes.sizeof(WAVEHDR)),
                     "waveInAddBuffer")
                self._headers.append(hdr)
                self._buffers.append(buf)
            self._stop.clear()
            _err(winmm.waveInStart(handle), "waveInStart")
            self._last_data = time.monotonic()
            self._thread = threading.Thread(target=self._pump, name="audio",
                                            daemon=True)
            self._thread.start()
            log.info("マイクを開きました (device=%s)",
                     self.device_name or "既定")

    def _pump(self) -> None:
        """WHDR_DONE になったバッファを順番に回収して再投入する。

        録音中でないときは、直近の音だけを輪っかに置いて捨てる。
        待っている間は 20ms 間隔にして、CPU をほとんど使わない。
        """
        index = 0
        handle = self._handle
        while not self._stop.is_set():
            hdr = self._headers[index]
            if hdr.dwFlags & WHDR_DONE:
                n = hdr.dwBytesRecorded
                if n:
                    # c_char_p だと ctypes が NUL 終端の bytes に変換してしまうので、
                    # 自分で持っているバッファから直接取り出す。
                    data = self._buffers[index].raw[:n]
                    self._last_data = time.monotonic()
                    if self._deliver:
                        try:
                            self._on_chunk(data)
                        except Exception:
                            log.exception("音声ブロックの処理で例外")
                    else:
                        self._ring.append(data)
                        while len(self._ring) > self._ring_limit():
                            self._ring.popleft()
                        idle = self.on_idle
                        if idle is not None:
                            try:
                                idle(data)
                            except Exception:
                                log.exception("待機中の音の処理で例外")
                # WHDR_PREPARED は残す。消すと waveInAddBuffer が
                # WAVERR_UNPREPARED で失敗し、以後 1 ブロックも届かなくなる。
                hdr.dwFlags &= ~WHDR_DONE
                hdr.dwBytesRecorded = 0
                if handle is not None and not self._stop.is_set():
                    rc = winmm.waveInAddBuffer(handle, ctypes.byref(hdr),
                                               ctypes.sizeof(WAVEHDR))
                    if rc != MMSYSERR_NOERROR:
                        log.error("waveInAddBuffer が失敗しました code=%d", rc)
                        self._fail += 1
                        self._stop.set()
                index = (index + 1) % N_BUFFERS
            else:
                time.sleep(0.005 if self._deliver else 0.02)

    # ---------------------------------------------------------------- 検証用

    def _start_fake(self, path: Path) -> None:
        """マイクの代わりに WAV を実時間で流し込む（テスト専用）。

        環境変数 KOE_TYPE_FAKE_MIC に wav のパスを入れると有効になる。
        スピーカーもマイクも使わずに通し検証ができる。
        """
        with self._lock:
            if self._fake is not None:
                return
            try:
                with wave.open(str(path)) as w:
                    if (w.getframerate(), w.getnchannels(), w.getsampwidth())                             != (SAMPLE_RATE, 1, 2):
                        raise ValueError("16kHz / モノラル / 16bit の wav が必要です")
                    pcm = w.readframes(w.getnframes())
            except Exception as exc:
                raise OSError(f"検証用の音声を読めません: {exc}") from exc
            self._stop.clear()
            self._fake = threading.Thread(target=self._pump_fake, args=(pcm,),
                                          name="audio-fake", daemon=True)
            self._fake.start()
            log.warning("検証用の音声で録音を代用します: %s", path)

    def _pump_fake(self, pcm: bytes) -> None:
        """WAV を実時間で流し込む。

        待ち時間は**最初からの通算**で決める。`sleep` を積み上げると、
        PC が混んでいるときに少しずつ遅れて、実時間より遅く流れてしまう。
        それでは「混んでいても速いか」を測るときに、アプリではなく
        この流し込みの遅さを測ってしまう。
        """
        step = CHUNK_BYTES
        silence = bytes(step)
        position = 0
        started = time.perf_counter()
        sent = 0
        while not self._stop.is_set():
            if position < len(pcm):
                chunk = pcm[position:position + step]
                position += step
                if len(chunk) < step:
                    chunk += silence[len(chunk):]
            else:
                chunk = silence
            try:
                self._on_chunk(chunk)
            except Exception:
                log.exception("音声ブロックの処理で例外")
            sent += 1
            # 通算の予定時刻まで待つ（遅れていれば待たない）
            behind = (started + sent * CHUNK_MS / 1000.0) - time.perf_counter()
            if behind > 0:
                time.sleep(behind)

    # ----------------------------------------------------------------

    def stop(self) -> None:
        """録音をやめる。待ち受けが有効ならマイクは開いたままにする。"""
        self._deliver = False
        if self._fake is not None:
            self._stop.set()
            fake, self._fake = self._fake, None
            fake.join(timeout=1.0)
            log.info("録音を停止しました")
            return
        self._ring.clear()
        if self.preroll_ms > 0 and self._fail == 0:
            log.info("録音を停止しました（待ち受けは続けます）")
            return
        self._close()
        log.info("録音を停止しました")

    def recover(self) -> bool:
        """マイクが消えた・差し替わった時に開き直す。

        スリープ復帰やマイクの抜き差しのあと、音が来なくなっていたら
        閉じて開き直す。戻り値は開き直したかどうか。
        """
        if self._fake is not None:
            return False
        stalled = (self._handle is not None
                   and self.silent_for > 3.0)
        if not (self._fail or stalled or self._stop.is_set()):
            return False
        log.warning("マイクが応答しないので開き直します "
                    "(失敗=%d 無音=%.1fs)", self._fail, self.silent_for)
        deliver = self._deliver
        self._close()
        self._fail = 0
        try:
            self._open()
        except Exception:
            log.exception("マイクを開き直せませんでした")
            return False
        self._deliver = deliver
        return True

    def shutdown(self) -> None:
        """終了時。待ち受けも含めて完全に閉じる。"""
        self._deliver = False
        self._close()

    def _close(self) -> None:
        with self._lock:
            handle, self._handle = self._handle, None
            if handle is None:
                return
            self._stop.set()
        thread = self._thread
        self._thread = None
        if thread is not None:
            thread.join(timeout=1.0)
        try:
            winmm.waveInStop(handle)
            winmm.waveInReset(handle)
            for hdr in self._headers:
                winmm.waveInUnprepareHeader(handle, ctypes.byref(hdr),
                                            ctypes.sizeof(WAVEHDR))
            winmm.waveInClose(handle)
        except Exception:
            log.exception("録音の停止で例外")
        finally:
            self._headers = []
            self._buffers = []
            log.info("マイクを閉じました")


def device_count() -> int:
    try:
        return int(winmm.waveInGetNumDevs())
    except Exception:
        return 0
