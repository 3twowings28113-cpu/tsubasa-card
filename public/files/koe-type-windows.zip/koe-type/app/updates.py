"""新しい版が出ていないか確かめ、ボタン 1 つで入れ替える。

## 決まり

- **確かめにいくのは、設定で許したときだけ。** 既定はオフ。
  それ以外の通信は一切しない（文字起こしはこの PC の中だけ）。
- 見にいくのは **GitHub の Releases の一覧だけ**。
  こちらから送るものは何もない（どの PC かも分からない）。
- 入れ替えは **利用者がボタンを押したときだけ**。勝手には入れ替えない。
- **設定・辞書・履歴はそのまま。** 入れ替えるのはプログラムだけ。
- **失敗したら元に戻す。** 入れ替えの直前に、いまの中身を丸ごと
  `backup/` へ退避し、新しい版が起動できなければ書き戻す。

## 入れ替えのしくみ

koe-type 自身が自分のファイルを置き換えることはできない（動いている
ので）。そこで

  1. 新しい zip を `update/` に落とし、**SHA256 を確かめる**
  2. 展開して中身を確かめる（`app/main.py` があるか等）
  3. 小さな `.cmd` を書き、koe-type を終わらせてから
     「退避 → 置き換え → 起動」を順に行わせる
  4. 起動できなければ、退避したものを書き戻す

`.cmd` は Windows 標準の `cmd.exe` が走らせる。新しい exe は作らない。
"""

from __future__ import annotations

import hashlib
import json
import logging
import re
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

from .util import ROOT, VERSION

log = logging.getLogger(__name__)

API = "https://api.github.com/repos/{repo}/releases/latest"
DEFAULT_REPO = "koe-type/koe-type"
TIMEOUT = 20
UA = f"koe-type/{VERSION}"

UPDATE_DIR = ROOT / "update"
BACKUP_DIR = ROOT / "backup"

# 置き換える対象。利用者のものは**触らない**。
REPLACE = ("app", "vendor", "tools", "docs", "assets",
           "koe-type.pyw", "setup.cmd", "setup.ps1", "install.cmd",
           "uninstall.cmd", "koe-type.cmd", "README.md", "README.en.md",
           "CHANGELOG.md", "THIRD_PARTY_NOTICES.md", "LICENSE")
KEEP = ("config.json", "dictionary.txt", "data", "logs", "models",
        "engines", "runtime")


def _version_tuple(text: str) -> tuple:
    nums = re.findall(r"\d+", str(text))
    return tuple(int(n) for n in nums[:4]) or (0,)


def newer(latest: str, current: str = VERSION) -> bool:
    return _version_tuple(latest) > _version_tuple(current)


# ---------------------------------------------------------------- 調べる


def check(repo: str = DEFAULT_REPO) -> dict:
    """新しい版があるか調べる。**送るものは何もない。**

    戻り値の形
        {"ok": True, "latest": "1.5.0", "newer": True,
         "url": "...zip", "sha256": "...", "notes": "...", "size": 123}
    """
    from . import downloads  # noqa: PLC0415
    if downloads.is_offline():
        return {"ok": False, "error": "通信が遮断されています（オフラインモード）"}
    url = API.format(repo=repo)
    req = urllib.request.Request(url, headers={  # noqa: S310
        "User-Agent": UA, "Accept": "application/vnd.github+json"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as res:  # noqa: S310
            data = json.loads(res.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            return {"ok": False, "error": "まだ公開されていません"}
        return {"ok": False, "error": f"確かめられません（{exc.code}）"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"確かめられません（{exc}）"}

    tag = str(data.get("tag_name") or "").lstrip("vV")
    assets = data.get("assets") or []
    zip_url = ""
    size = 0
    sha_url = ""
    for a in assets:
        name = str(a.get("name") or "")
        if name.endswith(".zip"):
            zip_url = str(a.get("browser_download_url") or "")
            size = int(a.get("size") or 0)
        elif name.lower().endswith(("sha256", "sha256sums.txt",
                                    "sha256sums")):
            sha_url = str(a.get("browser_download_url") or "")
    return {"ok": True, "latest": tag, "newer": newer(tag),
            "url": zip_url, "sha_url": sha_url, "size": size,
            "notes": str(data.get("body") or "")[:4000],
            "page": str(data.get("html_url") or "")}


# ---------------------------------------------------------------- 落とす


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def download(info: dict, progress=None) -> Path:  # noqa: ANN001
    """zip を落として、SHA256 を確かめる。合わなければ例外。"""
    if not info.get("url"):
        raise RuntimeError("ダウンロードするものがありません")
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    dest = UPDATE_DIR / f"koe-type-{info.get('latest', 'new')}.zip"
    part = dest.with_suffix(".part")
    done = part.stat().st_size if part.is_file() else 0
    total = int(info.get("size") or 0)

    headers = {"User-Agent": UA}
    if done:
        # 途中から再開する
        headers["Range"] = f"bytes={done}-"
        log.info("途中から再開します（%.1f MB まで）", done / 1e6)
    req = urllib.request.Request(info["url"], headers=headers)  # noqa: S310
    mode = "ab" if done else "wb"
    with urllib.request.urlopen(req, timeout=TIMEOUT) as res:  # noqa: S310
        if res.status == 200:
            mode, done = "wb", 0      # 再開が効かなかった
        with part.open(mode) as f:
            while True:
                block = res.read(1 << 18)
                if not block:
                    break
                f.write(block)
                done += len(block)
                if progress and total:
                    progress(min(1.0, done / total))
    part.replace(dest)

    want = str(info.get("sha256") or "")
    if not want and info.get("sha_url"):
        try:
            with urllib.request.urlopen(  # noqa: S310
                    urllib.request.Request(info["sha_url"],
                                           headers={"User-Agent": UA}),
                    timeout=TIMEOUT) as res:
                for line in res.read().decode("utf-8", "replace").splitlines():
                    if dest.name in line:
                        want = line.split()[0]
                        break
        except Exception as exc:  # noqa: BLE001
            log.warning("SHA256 を取れませんでした: %s", exc)
    if want:
        got = _sha256(dest)
        if got.lower() != want.lower():
            dest.unlink(missing_ok=True)
            raise RuntimeError("ダウンロードしたものが壊れています"
                               "（SHA256 が合いません）")
        log.info("SHA256 を確かめました: %s", got[:16])
    else:
        log.warning("SHA256 が無いので、中身の形だけ確かめます")
    return dest


def inspect(zip_path: Path) -> Path:
    """zip を展開して、ちゃんと koe-type かどうか確かめる。"""
    out = UPDATE_DIR / "staged"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    with zipfile.ZipFile(zip_path) as zf:
        for name in zf.namelist():
            # zip の外へ書き出させない
            target = (out / name).resolve()
            if not str(target).startswith(str(out.resolve())):
                raise RuntimeError(f"zip の中身がおかしいです: {name}")
        zf.extractall(out)
    root = out
    inner = [p for p in out.iterdir() if p.is_dir()]
    if not (root / "app" / "main.py").is_file() and len(inner) == 1:
        root = inner[0]
    for must in ("app/main.py", "koe-type.pyw"):
        if not (root / must).is_file():
            raise RuntimeError(f"中身が足りません: {must}")
    return root


# ---------------------------------------------------------------- 入れ替え


SWAP = """@echo off
rem koe-type の入れ替え。koe-type が終わるのを待ってから動きます。
rem 失敗したら、退避したものを書き戻します。
setlocal
set "APP={app}"
set "NEW={new}"
set "BAK={bak}"
set "PY={py}"

echo koe-type が終わるのを待っています...
"%PY%" -c "import time,sys;[time.sleep(0.5) for _ in range(6)]"

if exist "%BAK%" rmdir /s /q "%BAK%"
mkdir "%BAK%"
{backup_lines}
{copy_lines}

echo 起動を確かめています...
"%PY%" -c "import sys;sys.path.insert(0,r'%APP%');import app.main" 1>nul 2>nul
if errorlevel 1 goto rollback

echo 入れ替えました。
rem --restarted：古いほうがまだ終わりきっていなくても、待ってから動く
start "" "%PY_W%" "%APP%\\koe-type.pyw" --restarted
goto done

:rollback
echo うまくいかなかったので、元に戻します。
{restore_lines}
start "" "%PY_W%" "%APP%\\koe-type.pyw" --restarted

:done
endlocal
"""


def write_swap_script(staged: Path, app: Path = ROOT) -> Path:
    """入れ替え用の .cmd を書く（走らせるのは呼んだ側）。"""
    UPDATE_DIR.mkdir(parents=True, exist_ok=True)
    script = UPDATE_DIR / "swap.cmd"
    backup, copy, restore = [], [], []
    for name in REPLACE:
        src = staged / name
        if not src.exists():
            continue
        here = app / name
        if here.is_dir():
            backup.append(f'if exist "%APP%\\{name}" '
                          f'robocopy "%APP%\\{name}" "%BAK%\\{name}" /E /NFL '
                          f'/NDL /NJH /NJS /NP >nul')
            copy.append(f'robocopy "%NEW%\\{name}" "%APP%\\{name}" /MIR /NFL '
                        f'/NDL /NJH /NJS /NP >nul')
            restore.append(f'robocopy "%BAK%\\{name}" "%APP%\\{name}" /MIR '
                           f'/NFL /NDL /NJH /NJS /NP >nul')
        else:
            backup.append(f'if exist "%APP%\\{name}" '
                          f'copy /y "%APP%\\{name}" "%BAK%\\{name}" >nul')
            copy.append(f'copy /y "%NEW%\\{name}" "%APP%\\{name}" >nul')
            restore.append(f'if exist "%BAK%\\{name}" '
                           f'copy /y "%BAK%\\{name}" "%APP%\\{name}" >nul')

    python = Path(sys.executable)
    pythonw = python.with_name("pythonw.exe")
    text = SWAP.format(
        app=app, new=staged, bak=BACKUP_DIR, py=python,
        backup_lines="\n".join(backup),
        copy_lines="\n".join(copy),
        restore_lines="\n".join(restore))
    text = text.replace("%PY_W%", str(pythonw if pythonw.is_file() else python))
    script.write_text(text, "utf-8")
    return script


def apply(staged: Path) -> subprocess.Popen:
    """入れ替えを始める。**この関数のあと、すぐアプリを終わらせること。**"""
    script = write_swap_script(staged)
    log.warning("入れ替えを始めます: %s", script)
    return subprocess.Popen(  # noqa: S603
        ["cmd.exe", "/c", str(script)], cwd=str(ROOT),
        creationflags=0x08000000)


def cleanup() -> None:
    """落としたものと退避を片づける（入れ替えが終わったあと）。"""
    for folder in (UPDATE_DIR, BACKUP_DIR):
        shutil.rmtree(folder, ignore_errors=True)


def perform_update(info: dict, progress=None) -> subprocess.Popen:
    """ダウンロードから入れ替え開始までを一括で行う。"""
    zip_path = download(info, progress=progress)
    staged = inspect(zip_path)
    return apply(staged)
