"""クリップボードの窓を描くための道具と、画像の読み書き。

文字は **GDI（DrawTextW・ClearType）** で、角丸・線・画像は **GDI+** で描く。

  ・GDI+ の文字は、日本語が少しにじみ、ほかのアプリと見た目がそろわない。
    GDI の DrawTextW は Windows の標準の描き方そのもので、和文の
    フォントの代わり（フォントリンク）も効く
  ・この窓はふつうの（半透明でない）窓なので、GDI の文字が透明度を
    持たないことは問題にならない

画像は data/clips/ に PNG で置く。PNG への変換・縮小も GDI+ で行う。
どれも OS 標準の DLL（gdi32 / gdiplus / ole32）だけで、依存は増えない。
"""

from __future__ import annotations

import ctypes
import logging
import struct
import threading
from ctypes import wintypes
from pathlib import Path

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
gdiplus = ctypes.WinDLL("gdiplus", use_last_error=True)
ole32 = ctypes.WinDLL("ole32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


class RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class SIZE(ctypes.Structure):
    _fields_ = [("cx", ctypes.c_long), ("cy", ctypes.c_long)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wintypes.DWORD), ("biWidth", ctypes.c_long),
                ("biHeight", ctypes.c_long), ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD),
                ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", ctypes.c_long),
                ("biYPelsPerMeter", ctypes.c_long),
                ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD)]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [("bmiHeader", BITMAPINFOHEADER),
                ("bmiColors", wintypes.DWORD * 3)]


class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [("GdiplusVersion", ctypes.c_uint32),
                ("DebugEventCallback", ctypes.c_void_p),
                ("SuppressBackgroundThread", wintypes.BOOL),
                ("SuppressExternalCodecs", wintypes.BOOL)]


class GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


class GpRect(ctypes.Structure):
    _fields_ = [("X", ctypes.c_int), ("Y", ctypes.c_int),
                ("Width", ctypes.c_int), ("Height", ctypes.c_int)]


class BitmapData(ctypes.Structure):
    _fields_ = [("Width", ctypes.c_uint), ("Height", ctypes.c_uint),
                ("Stride", ctypes.c_int), ("PixelFormat", ctypes.c_int),
                ("Scan0", ctypes.c_void_p), ("Reserved", ctypes.c_void_p)]


def guid(text: str) -> GUID:
    """"557CF406-1A04-11D3-9A73-0000F81EF32E" を GUID にする。"""
    parts = text.strip("{}").split("-")
    tail = bytes.fromhex(parts[3] + parts[4])
    return GUID(int(parts[0], 16), int(parts[1], 16), int(parts[2], 16),
                (ctypes.c_ubyte * 8)(*tail))


PNG_ENCODER = guid("557CF406-1A04-11D3-9A73-0000F81EF32E")

PIXEL_24RGB = 0x00021808
PIXEL_32RGB = 0x00022009
PIXEL_32ARGB = 0x0026200A
PIXEL_32PARGB = 0x000E200B
INTERP_HQ_BICUBIC = 7
LOCK_READ = 1

_vp = ctypes.c_void_p
_pvp = ctypes.POINTER(ctypes.c_void_p)
_f = ctypes.c_float
_i = ctypes.c_int

for _name, _args, _ret in (
    ("GdiplusStartup", [_pvp, ctypes.POINTER(GdiplusStartupInput), _vp],
     _i),
    ("GdipCreateFromHDC", [wintypes.HDC, _pvp], _i),
    ("GdipDeleteGraphics", [_vp], _i),
    ("GdipFlush", [_vp, _i], _i),
    ("GdipSetSmoothingMode", [_vp, _i], _i),
    ("GdipSetPixelOffsetMode", [_vp, _i], _i),
    ("GdipSetInterpolationMode", [_vp, _i], _i),
    ("GdipSetCompositingQuality", [_vp, _i], _i),
    ("GdipGraphicsClear", [_vp, ctypes.c_uint32], _i),
    ("GdipSetClipRectI", [_vp, _i, _i, _i, _i, _i], _i),
    ("GdipResetClip", [_vp], _i),
    ("GdipCreateSolidFill", [ctypes.c_uint32, _pvp], _i),
    ("GdipDeleteBrush", [_vp], _i),
    ("GdipCreatePen1", [ctypes.c_uint32, _f, _i, _pvp], _i),
    ("GdipDeletePen", [_vp], _i),
    ("GdipFillRectangle", [_vp, _vp, _f, _f, _f, _f], _i),
    ("GdipFillEllipse", [_vp, _vp, _f, _f, _f, _f], _i),
    ("GdipDrawEllipse", [_vp, _vp, _f, _f, _f, _f], _i),
    ("GdipDrawLine", [_vp, _vp, _f, _f, _f, _f], _i),
    ("GdipCreatePath", [_i, _pvp], _i),
    ("GdipDeletePath", [_vp], _i),
    ("GdipAddPathArc", [_vp, _f, _f, _f, _f, _f, _f], _i),
    ("GdipAddPathLine", [_vp, _f, _f, _f, _f], _i),
    ("GdipClosePathFigure", [_vp], _i),
    ("GdipFillPath", [_vp, _vp, _vp], _i),
    ("GdipDrawPath", [_vp, _vp, _vp], _i),
    ("GdipCreateBitmapFromGdiDib", [_vp, _vp, _pvp], _i),
    ("GdipCreateBitmapFromStream", [_vp, _pvp], _i),
    ("GdipCreateBitmapFromScan0", [_i, _i, _i, _i, _vp, _pvp], _i),
    ("GdipGetImageWidth", [_vp, ctypes.POINTER(ctypes.c_uint)], _i),
    ("GdipGetImageHeight", [_vp, ctypes.POINTER(ctypes.c_uint)], _i),
    ("GdipGetImageGraphicsContext", [_vp, _pvp], _i),
    ("GdipDisposeImage", [_vp], _i),
    ("GdipSaveImageToFile", [_vp, wintypes.LPCWSTR, ctypes.POINTER(GUID),
                             _vp], _i),
    ("GdipBitmapLockBits", [_vp, ctypes.POINTER(GpRect), ctypes.c_uint, _i,
                            ctypes.POINTER(BitmapData)], _i),
    ("GdipBitmapUnlockBits", [_vp, ctypes.POINTER(BitmapData)], _i),
    ("GdipDrawImageRectI", [_vp, _vp, _i, _i, _i, _i], _i),
):
    _fn = getattr(gdiplus, _name)
    _fn.argtypes = _args
    _fn.restype = _ret

ole32.CreateStreamOnHGlobal.argtypes = [_vp, wintypes.BOOL, _pvp]
ole32.CreateStreamOnHGlobal.restype = ctypes.c_long
kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
kernel32.GlobalAlloc.restype = _vp
kernel32.GlobalLock.argtypes = [_vp]
kernel32.GlobalLock.restype = _vp
kernel32.GlobalUnlock.argtypes = [_vp]
kernel32.GlobalFree.argtypes = [_vp]
kernel32.GlobalFree.restype = _vp

gdi32.CreateCompatibleDC.argtypes = [wintypes.HDC]
gdi32.CreateCompatibleDC.restype = wintypes.HDC
gdi32.DeleteDC.argtypes = [wintypes.HDC]
gdi32.CreateDIBSection.argtypes = [wintypes.HDC, ctypes.POINTER(BITMAPINFO),
                                   wintypes.UINT, _pvp, wintypes.HANDLE,
                                   wintypes.DWORD]
gdi32.CreateDIBSection.restype = wintypes.HBITMAP
gdi32.SelectObject.argtypes = [wintypes.HDC, wintypes.HGDIOBJ]
gdi32.SelectObject.restype = wintypes.HGDIOBJ
gdi32.DeleteObject.argtypes = [wintypes.HGDIOBJ]
gdi32.SetBkMode.argtypes = [wintypes.HDC, ctypes.c_int]
gdi32.SetTextColor.argtypes = [wintypes.HDC, wintypes.COLORREF]
gdi32.CreateFontW.argtypes = [
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.LPCWSTR]
gdi32.CreateFontW.restype = wintypes.HFONT
gdi32.GetTextExtentPoint32W.argtypes = [wintypes.HDC, wintypes.LPCWSTR,
                                        ctypes.c_int, ctypes.POINTER(SIZE)]
gdi32.GetTextExtentPoint32W.restype = wintypes.BOOL
gdi32.BitBlt.argtypes = [wintypes.HDC, _i, _i, _i, _i, wintypes.HDC, _i, _i,
                         wintypes.DWORD]
user32.DrawTextW.argtypes = [wintypes.HDC, wintypes.LPCWSTR, ctypes.c_int,
                             ctypes.POINTER(RECT), wintypes.UINT]
user32.DrawTextW.restype = ctypes.c_int
user32.GetDC.argtypes = [wintypes.HWND]
user32.GetDC.restype = wintypes.HDC
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]

DT_LEFT, DT_CENTER, DT_RIGHT = 0x0, 0x1, 0x2
DT_VCENTER, DT_BOTTOM = 0x4, 0x8
DT_WORDBREAK, DT_SINGLELINE = 0x10, 0x20
DT_NOCLIP, DT_CALCRECT, DT_NOPREFIX = 0x100, 0x400, 0x800
DT_EDITCONTROL = 0x2000
DT_END_ELLIPSIS = 0x8000
DT_WORD_ELLIPSIS = 0x40000
SRCCOPY = 0x00CC0020
TRANSPARENT = 1
ANTIALIASED_QUALITY = 4
CLEARTYPE_QUALITY = 5
FW_NORMAL, FW_SEMIBOLD = 400, 600

UI_FONTS = ("Yu Gothic UI", "Meiryo UI", "Segoe UI")
ICON_FONTS = ("Segoe Fluent Icons", "Segoe MDL2 Assets")

_token = ctypes.c_void_p()
_started = False
_start_lock = threading.Lock()


def start() -> bool:
    """GDI+ を始める（何度呼んでもよい）。"""
    global _started
    with _start_lock:
        if _started:
            return True
        info = GdiplusStartupInput(1, None, False, False)
        if gdiplus.GdiplusStartup(ctypes.byref(_token), ctypes.byref(info),
                                  None) == 0:
            _started = True
        else:
            log.error("GDI+ を始められませんでした")
        return _started


def argb(hex_colour: str, alpha: float = 1.0) -> int:
    h = hex_colour.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    a = int(max(0.0, min(1.0, alpha)) * 255)
    return (a << 24) | (r << 16) | (g << 8) | b


def colorref(hex_colour: str) -> int:
    """GDI の色（0x00BBGGRR）。"""
    h = hex_colour.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return r | (g << 8) | (b << 16)


def mix(a: str, b: str, t: float) -> str:
    """2 色を t（0〜1）の割合で混ぜる。半透明を使わずに薄い色を作る。"""
    ha, hb = a.lstrip("#"), b.lstrip("#")
    out = []
    for i in (0, 2, 4):
        x, y = int(ha[i:i + 2], 16), int(hb[i:i + 2], 16)
        out.append(round(x + (y - x) * max(0.0, min(1.0, t))))
    return "#%02x%02x%02x" % tuple(out)


# ---------------------------------------------------------------- フォント


class Fonts:
    """GDI のフォントを、大きさ・太さごとに 1 つだけ作って使い回す。"""

    def __init__(self) -> None:
        self._cache: dict[tuple[str, int, int], int] = {}
        self._face: str | None = None
        self._icon_face: str | None = None

    def _pick(self, candidates: tuple[str, ...]) -> str:
        """入っているフォントのうち最初のもの。"""
        hdc = user32.GetDC(None)
        try:
            for face in candidates:
                font = gdi32.CreateFontW(-14, 0, 0, 0, FW_NORMAL, 0, 0, 0,
                                         1, 0, 0, CLEARTYPE_QUALITY, 0,
                                         face)
                if not font:
                    continue
                old = gdi32.SelectObject(hdc, font)
                buf = ctypes.create_unicode_buffer(64)
                gdi32.GetTextFaceW.argtypes = [wintypes.HDC, ctypes.c_int,
                                               wintypes.LPWSTR]
                gdi32.GetTextFaceW(hdc, 64, buf)
                gdi32.SelectObject(hdc, old)
                gdi32.DeleteObject(font)
                if buf.value.lower() == face.lower():
                    return face
        finally:
            user32.ReleaseDC(None, hdc)
        return candidates[-1]

    @property
    def face(self) -> str:
        if self._face is None:
            self._face = self._pick(UI_FONTS)
        return self._face

    @property
    def icon_face(self) -> str:
        if self._icon_face is None:
            self._icon_face = self._pick(ICON_FONTS)
        return self._icon_face

    def get(self, px: int, *, weight: int = FW_NORMAL,
            icon: bool = False) -> int:
        face = self.icon_face if icon else self.face
        key = (face, max(6, int(px)), weight)
        font = self._cache.get(key)
        if not font:
            # 記号は白黒のなめらかさで描く。ClearType だと細い縦線に
            # 赤や緑のにじみが出て、「＋」が緑色に見えた。
            quality = ANTIALIASED_QUALITY if icon else CLEARTYPE_QUALITY
            font = gdi32.CreateFontW(-key[1], 0, 0, 0, weight, 0, 0, 0, 1,
                                     0, 0, quality, 0, face)
            self._cache[key] = font or 0
        return font or 0

    def clear(self) -> None:
        for font in self._cache.values():
            if font:
                gdi32.DeleteObject(font)
        self._cache.clear()


# ---------------------------------------------------------------- 描く


class Canvas:
    """メモリ上の絵（32bit DIB）。窓へは blit() で写す。"""

    def __init__(self, width: int, height: int) -> None:
        self.width = max(1, width)
        self.height = max(1, height)
        self.dc = gdi32.CreateCompatibleDC(None)
        info = BITMAPINFO()
        info.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        info.bmiHeader.biWidth = self.width
        info.bmiHeader.biHeight = -self.height        # 上から下へ
        info.bmiHeader.biPlanes = 1
        info.bmiHeader.biBitCount = 32
        self.bits = ctypes.c_void_p()
        self.bitmap = gdi32.CreateDIBSection(self.dc, ctypes.byref(info), 0,
                                             ctypes.byref(self.bits), None,
                                             0)
        if not self.bitmap:
            gdi32.DeleteDC(self.dc)
            raise OSError("CreateDIBSection に失敗")
        self._old = gdi32.SelectObject(self.dc, self.bitmap)

    def close(self) -> None:
        if self.dc:
            gdi32.SelectObject(self.dc, self._old)
            gdi32.DeleteObject(self.bitmap)
            gdi32.DeleteDC(self.dc)
            self.dc = 0

    def blit(self, hdc: int, x: int = 0, y: int = 0) -> None:
        gdi32.BitBlt(hdc, x, y, self.width, self.height, self.dc, 0, 0,
                     SRCCOPY)

    def save_png(self, path: Path) -> bool:
        """そのまま PNG にする（試験の画像用）。透明度は無視する。"""
        start()
        bmp = ctypes.c_void_p()
        if gdiplus.GdipCreateBitmapFromScan0(
                self.width, self.height, self.width * 4, PIXEL_32RGB,
                self.bits, ctypes.byref(bmp)) != 0:
            return False
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            return gdiplus.GdipSaveImageToFile(
                bmp, str(path), ctypes.byref(PNG_ENCODER), None) == 0
        finally:
            gdiplus.GdipDisposeImage(bmp)


class Painter:
    """1 回の描画。図形は GDI+、文字は GDI。

    GDI+ は描く命令をためることがあるので、GDI で文字を描く前に
    必ず flush する（しないと、文字の上に背景が後から塗られる）。
    """

    def __init__(self, canvas: Canvas, fonts: Fonts) -> None:
        start()
        self.canvas = canvas
        self.dc = canvas.dc
        self.fonts = fonts
        self.g = ctypes.c_void_p()
        if gdiplus.GdipCreateFromHDC(self.dc, ctypes.byref(self.g)) != 0:
            raise OSError("GdipCreateFromHDC に失敗")
        gdiplus.GdipSetSmoothingMode(self.g, 4)          # AntiAlias
        gdiplus.GdipSetPixelOffsetMode(self.g, 2)        # HighQuality
        gdiplus.GdipSetInterpolationMode(self.g, INTERP_HQ_BICUBIC)
        gdi32.SetBkMode(self.dc, TRANSPARENT)
        self._dirty = False

    def close(self) -> None:
        if self.g:
            gdiplus.GdipDeleteGraphics(self.g)
            self.g = ctypes.c_void_p()

    def _flush(self) -> None:
        if self._dirty:
            gdiplus.GdipFlush(self.g, 1)
            self._dirty = False

    # ---- 図形

    def clear(self, colour: str) -> None:
        gdiplus.GdipGraphicsClear(self.g, argb(colour))
        self._dirty = True

    def rect(self, x: float, y: float, w: float, h: float, colour: str,
             alpha: float = 1.0) -> None:
        if w <= 0 or h <= 0:
            return
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(argb(colour, alpha), ctypes.byref(brush))
        gdiplus.GdipFillRectangle(self.g, brush, x, y, w, h)
        gdiplus.GdipDeleteBrush(brush)
        self._dirty = True

    def _path(self, x: float, y: float, w: float, h: float,
              r: float) -> ctypes.c_void_p:
        path = ctypes.c_void_p()
        gdiplus.GdipCreatePath(0, ctypes.byref(path))
        r = max(0.0, min(r, w / 2, h / 2))
        if r <= 0.5:
            gdiplus.GdipAddPathLine(path, x, y, x + w, y)
            gdiplus.GdipAddPathLine(path, x + w, y, x + w, y + h)
            gdiplus.GdipAddPathLine(path, x + w, y + h, x, y + h)
        else:
            d = r * 2
            gdiplus.GdipAddPathArc(path, x, y, d, d, 180, 90)
            gdiplus.GdipAddPathArc(path, x + w - d, y, d, d, 270, 90)
            gdiplus.GdipAddPathArc(path, x + w - d, y + h - d, d, d, 0, 90)
            gdiplus.GdipAddPathArc(path, x, y + h - d, d, d, 90, 90)
        gdiplus.GdipClosePathFigure(path)
        return path

    def round_rect(self, x: float, y: float, w: float, h: float, r: float,
                   fill: str | None = None, stroke: str | None = None,
                   width: float = 1.0, alpha: float = 1.0) -> None:
        if w <= 0 or h <= 0:
            return
        path = self._path(x, y, w, h, r)
        try:
            if fill:
                brush = ctypes.c_void_p()
                gdiplus.GdipCreateSolidFill(argb(fill, alpha),
                                            ctypes.byref(brush))
                gdiplus.GdipFillPath(self.g, brush, path)
                gdiplus.GdipDeleteBrush(brush)
            if stroke:
                pen = ctypes.c_void_p()
                gdiplus.GdipCreatePen1(argb(stroke, alpha), width, 2,
                                       ctypes.byref(pen))
                gdiplus.GdipDrawPath(self.g, pen, path)
                gdiplus.GdipDeletePen(pen)
        finally:
            gdiplus.GdipDeletePath(path)
        self._dirty = True

    def line(self, x1: float, y1: float, x2: float, y2: float, colour: str,
             width: float = 1.0, alpha: float = 1.0) -> None:
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(argb(colour, alpha), width, 2,
                               ctypes.byref(pen))
        gdiplus.GdipDrawLine(self.g, pen, x1, y1, x2, y2)
        gdiplus.GdipDeletePen(pen)
        self._dirty = True

    def circle(self, cx: float, cy: float, r: float, colour: str,
               alpha: float = 1.0) -> None:
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(argb(colour, alpha), ctypes.byref(brush))
        gdiplus.GdipFillEllipse(self.g, brush, cx - r, cy - r, r * 2, r * 2)
        gdiplus.GdipDeleteBrush(brush)
        self._dirty = True

    def image(self, bitmap: int, x: int, y: int, w: int, h: int) -> None:
        if bitmap:
            gdiplus.GdipDrawImageRectI(self.g, bitmap, x, y, w, h)
            self._dirty = True

    def clip(self, x: int, y: int, w: int, h: int) -> None:
        gdiplus.GdipSetClipRectI(self.g, x, y, w, h, 0)

    def unclip(self) -> None:
        gdiplus.GdipResetClip(self.g)

    # ---- 文字（GDI）

    def text(self, text: str, x: int, y: int, w: int, h: int, *,
             colour: str, px: int, weight: int = FW_NORMAL,
             align: str = "left", valign: str = "center",
             wrap: bool = False, icon: bool = False,
             ellipsis: bool = True) -> None:
        if not text or w <= 0 or h <= 0:
            return
        self._flush()
        font = self.fonts.get(px, weight=weight, icon=icon)
        old = gdi32.SelectObject(self.dc, font)
        gdi32.SetTextColor(self.dc, colorref(colour))
        flags = DT_NOPREFIX
        flags |= {"left": DT_LEFT, "center": DT_CENTER,
                  "right": DT_RIGHT}.get(align, DT_LEFT)
        if wrap:
            flags |= DT_WORDBREAK | DT_EDITCONTROL
            if ellipsis:
                flags |= DT_END_ELLIPSIS
        else:
            flags |= DT_SINGLELINE
            if ellipsis:
                flags |= DT_END_ELLIPSIS
            flags |= {"center": DT_VCENTER, "bottom": DT_BOTTOM}.get(valign,
                                                                     0)
        rect = RECT(int(x), int(y), int(x + w), int(y + h))
        user32.DrawTextW(self.dc, text, len(text), ctypes.byref(rect), flags)
        gdi32.SelectObject(self.dc, old)

    def measure(self, text: str, *, px: int, weight: int = FW_NORMAL,
                icon: bool = False) -> tuple[int, int]:
        """1 行で描いたときの幅と高さ。"""
        return measure(self.dc, self.fonts, text, px=px, weight=weight,
                       icon=icon)

    def wrapped_height(self, text: str, width: int, *, px: int,
                       weight: int = FW_NORMAL) -> int:
        """折り返して描いたときの高さ。"""
        if not text:
            return 0
        self._flush()
        font = self.fonts.get(px, weight=weight)
        old = gdi32.SelectObject(self.dc, font)
        rect = RECT(0, 0, max(1, width), 0)
        user32.DrawTextW(self.dc, text, len(text), ctypes.byref(rect),
                         DT_CALCRECT | DT_WORDBREAK | DT_EDITCONTROL
                         | DT_NOPREFIX)
        gdi32.SelectObject(self.dc, old)
        return rect.bottom - rect.top


def measure(dc: int, fonts: Fonts, text: str, *, px: int,
            weight: int = FW_NORMAL, icon: bool = False) -> tuple[int, int]:
    if not text:
        return (0, 0)
    font = fonts.get(px, weight=weight, icon=icon)
    old = gdi32.SelectObject(dc, font)
    size = SIZE()
    gdi32.GetTextExtentPoint32W(dc, text, len(text), ctypes.byref(size))
    gdi32.SelectObject(dc, old)
    return (size.cx, size.cy)


# ---------------------------------------------------------------- 画像


def _release(com_ptr: ctypes.c_void_p) -> None:
    """COM の Release を呼ぶ（vtable の 3 番目）。"""
    if not com_ptr:
        return
    vtbl = ctypes.cast(com_ptr, ctypes.POINTER(ctypes.POINTER(
        ctypes.c_void_p))).contents
    release = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
    release(com_ptr)


def _bitmap_from_bytes(data: bytes) -> ctypes.c_void_p | None:
    """PNG などのバイト列から、**完全に読み込んだ** GDI+ の絵を作る。

    GDI+ は元のストリームを読みながら使うので、ストリームを先に
    閉じると絵が壊れる。ここでは別の絵に描き写してから閉じる。
    """
    if not data or not start():
        return None
    handle = kernel32.GlobalAlloc(0x0002, len(data))     # GMEM_MOVEABLE
    if not handle:
        return None
    ptr = kernel32.GlobalLock(handle)
    if not ptr:
        kernel32.GlobalFree(handle)
        return None
    ctypes.memmove(ptr, data, len(data))
    kernel32.GlobalUnlock(handle)
    stream = ctypes.c_void_p()
    if ole32.CreateStreamOnHGlobal(handle, True, ctypes.byref(stream)) != 0:
        kernel32.GlobalFree(handle)
        return None
    src = ctypes.c_void_p()
    try:
        if gdiplus.GdipCreateBitmapFromStream(stream,
                                              ctypes.byref(src)) != 0:
            return None
        w, h = image_size(src)
        if not w or not h:
            gdiplus.GdipDisposeImage(src)
            return None
        out = _scaled_copy(src, w, h)
        gdiplus.GdipDisposeImage(src)
        return out
    finally:
        _release(stream)


def image_size(bitmap: ctypes.c_void_p | int) -> tuple[int, int]:
    w, h = ctypes.c_uint(), ctypes.c_uint()
    gdiplus.GdipGetImageWidth(bitmap, ctypes.byref(w))
    gdiplus.GdipGetImageHeight(bitmap, ctypes.byref(h))
    return (int(w.value), int(h.value))


def _scaled_copy(src: ctypes.c_void_p | int, w: int, h: int,
                 *, background: str | None = None) -> ctypes.c_void_p | None:
    """src を w×h に描き写した、新しい絵。"""
    out = ctypes.c_void_p()
    fmt = PIXEL_24RGB if background else PIXEL_32PARGB
    if gdiplus.GdipCreateBitmapFromScan0(max(1, w), max(1, h), 0, fmt,
                                         None, ctypes.byref(out)) != 0:
        return None
    g = ctypes.c_void_p()
    if gdiplus.GdipGetImageGraphicsContext(out, ctypes.byref(g)) != 0:
        gdiplus.GdipDisposeImage(out)
        return None
    try:
        if background:
            gdiplus.GdipGraphicsClear(g, argb(background))
        gdiplus.GdipSetInterpolationMode(g, INTERP_HQ_BICUBIC)
        gdiplus.GdipSetPixelOffsetMode(g, 2)
        gdiplus.GdipDrawImageRectI(g, src, 0, 0, max(1, w), max(1, h))
    finally:
        gdiplus.GdipDeleteGraphics(g)
    return out


def fit(w: int, h: int, max_w: int, max_h: int) -> tuple[int, int]:
    """縦横比を保って、枠に収まる大きさ（大きくはしない）。"""
    if w <= 0 or h <= 0:
        return (0, 0)
    scale = min(1.0, max_w / w, max_h / h)
    return (max(1, round(w * scale)), max(1, round(h * scale)))


def load_scaled(path: Path, max_w: int, max_h: int) -> tuple[int, int, int]:
    """PNG を読み、枠に収まる大きさの絵にする。(絵, 幅, 高さ)。

    使い終わったら dispose() すること。読めなければ (0, 0, 0)。
    """
    try:
        data = path.read_bytes()
    except OSError:
        return (0, 0, 0)
    src = _bitmap_from_bytes(data)
    if not src:
        return (0, 0, 0)
    w, h = image_size(src)
    tw, th = fit(w, h, max_w, max_h)
    if (tw, th) == (w, h):
        return (int(src.value), w, h)
    out = _scaled_copy(src, tw, th)
    gdiplus.GdipDisposeImage(src)
    if not out:
        return (0, 0, 0)
    return (int(out.value), tw, th)


def dispose(bitmap: int) -> None:
    if bitmap:
        gdiplus.GdipDisposeImage(ctypes.c_void_p(bitmap))


def png_size(data: bytes) -> tuple[int, int]:
    """PNG の頭（IHDR）から大きさを読む。読み込まずに済むので速い。"""
    if len(data) >= 24 and data[:8] == b"\x89PNG\r\n\x1a\n":
        return struct.unpack(">II", data[16:24])
    return (0, 0)


def dib_bits_offset(dib: bytes) -> int:
    """CF_DIB の中で、色の並び（ピクセル）が始まる位置。

    頭の大きさ＋（BI_BITFIELDS なら色の仕分け 12 バイト）＋パレット。
    ここを 1 つ間違えると、画像が斜めにずれたり色がおかしくなる。
    """
    if len(dib) < 40:
        return 0
    size, _w, _h, _planes, bits, comp = struct.unpack_from("<IiiHHI", dib)
    used = struct.unpack_from("<I", dib, 32)[0]
    offset = size
    if comp == 3 and size == 40:          # BI_BITFIELDS
        offset += 12
    elif comp == 6 and size == 40:        # BI_ALPHABITFIELDS
        offset += 16
    if bits <= 8:
        offset += 4 * (used or (1 << bits))
    elif used:
        offset += 4 * used
    return offset


def dib_size(dib: bytes) -> tuple[int, int]:
    if len(dib) < 40:
        return (0, 0)
    _size, w, h = struct.unpack_from("<Iii", dib)
    return (abs(w), abs(h))


def dib_to_png(dib: bytes, out: Path) -> tuple[int, int]:
    """CF_DIB のバイト列を PNG ファイルにする。(幅, 高さ)。失敗は (0, 0)。"""
    if not start():
        return (0, 0)
    offset = dib_bits_offset(dib)
    if not offset or offset >= len(dib):
        return (0, 0)
    buf = ctypes.create_string_buffer(dib, len(dib))
    base = ctypes.addressof(buf)
    bmp = ctypes.c_void_p()
    if gdiplus.GdipCreateBitmapFromGdiDib(ctypes.c_void_p(base),
                                          ctypes.c_void_p(base + offset),
                                          ctypes.byref(bmp)) != 0:
        return (0, 0)
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        if gdiplus.GdipSaveImageToFile(bmp, str(out),
                                       ctypes.byref(PNG_ENCODER),
                                       None) != 0:
            return (0, 0)
        return image_size(bmp)
    finally:
        gdiplus.GdipDisposeImage(bmp)
        del buf


def save_preview(src: Path, out: Path, max_w: int, max_h: int) -> bool:
    """大きな画像の「小さめの版」を作る。小さい画像なら何もしない。"""
    try:
        data = src.read_bytes()
    except OSError:
        return False
    w, h = png_size(data)
    if w and h and w <= max_w and h <= max_h:
        return False
    bmp, _tw, _th = load_scaled(src, max_w, max_h)
    if not bmp:
        return False
    try:
        return gdiplus.GdipSaveImageToFile(
            ctypes.c_void_p(bmp), str(out), ctypes.byref(PNG_ENCODER),
            None) == 0
    finally:
        dispose(bmp)


def png_to_dib(path: Path) -> bytes:
    """PNG を、貼り付け用の CF_DIB（24bit・下から上）にする。

    透明なところは白にする。透明度を持てない貼り先（ペイントなど）で
    真っ黒にならないように。透明度は "PNG" 形式のほうで渡す。
    """
    try:
        data = path.read_bytes()
    except OSError:
        return b""
    src = _bitmap_from_bytes(data)
    if not src:
        return b""
    w, h = image_size(src)
    flat = _scaled_copy(src, w, h, background="#ffffff")
    gdiplus.GdipDisposeImage(src)
    if not flat:
        return b""
    try:
        rect = GpRect(0, 0, w, h)
        bd = BitmapData()
        if gdiplus.GdipBitmapLockBits(flat, ctypes.byref(rect), LOCK_READ,
                                      PIXEL_24RGB, ctypes.byref(bd)) != 0:
            return b""
        try:
            row = ((w * 3 + 3) // 4) * 4
            stride = bd.Stride
            rows = []
            for y in range(h - 1, -1, -1):        # 下の行から
                start_at = bd.Scan0 + y * stride
                rows.append(ctypes.string_at(start_at, row))
            pixels = b"".join(rows)
        finally:
            gdiplus.GdipBitmapUnlockBits(flat, ctypes.byref(bd))
        header = struct.pack("<IiiHHIIiiII", 40, w, h, 1, 24, 0,
                             len(pixels), 3780, 3780, 0, 0)
        return header + pixels
    finally:
        gdiplus.GdipDisposeImage(flat)
