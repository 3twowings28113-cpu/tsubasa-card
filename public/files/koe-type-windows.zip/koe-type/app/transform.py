"""特定動作（英語翻訳、敬語変換、ビジネス丁寧語、要約）の変換エンジン。

起動キー長押しや専用アクションキーで起動されたときに、文字起こし結果に対して
指定された変換を実行する。

設計の柱：
  ・**完全オフラインで動作する。** 外部 API がなくてもローカルの規則・辞書、
    または Whisper の `task="translate"` で変換できる。
  ・**オプショナルな AI 連携。** 利用者が設定画面で Gemini API キーを
    入力した場合に限り、クラウド LLM を使ったより高度で自然な翻訳・要約も選べる。
    ただし `offline_mode`（通信完全遮断）がオンのときは通信を絶対に試みない。
  ・**元の言葉を失わない。** 変換に失敗しても元の文字起こしテキストをそのまま返す。
  ・Python 標準ライブラリ（urllib, json, re）のみで書き、pip パッケージを追加しない。
"""

from __future__ import annotations

import base64
import datetime
import json
import logging
import re
import urllib.error
import urllib.parse
import urllib.request
from typing import Final

log = logging.getLogger(__name__)

# ------------------------------------------------------------ 敬語変換（です・ます）

# 常体（くだけた口調・だ・である）から敬語（です・ます）への変換ルール
_POLITE_SUBSTITUTIONS: Final[list[tuple[re.Pattern[str], str]]] = [
    # 接続・語彙
    (re.compile(r"(?:俺|僕)(?=[はがをもにでとへや、。\s]|\b|$)"), "私"),
    (re.compile(r"すいません"), "すみません"),
    (re.compile(r"ちょっと(?=[、\s]|(?=[^a-zA-Z0-9]))"), "少々"),
    (re.compile(r"あとで(?=[、\s]|(?=[^a-zA-Z0-9]))"), "後ほど"),
    # 文末：だ・である
    (re.compile(r"じゃないか(?=[。！？\s]|$)", re.MULTILINE), "ではないでしょうか"),
    (re.compile(r"じゃない(?=[。！？\s]|$)", re.MULTILINE), "ではありません"),
    (re.compile(r"ではない(?=[。！？\s]|$)", re.MULTILINE), "ではありません"),
    (re.compile(r"だった(?=[。！？\s]|$)", re.MULTILINE), "でした"),
    (re.compile(r"だ(?=[。！？\s]|$)", re.MULTILINE), "です"),
    (re.compile(r"である(?=[。！？\s]|$)", re.MULTILINE), "です"),
    (re.compile(r"であった(?=[。！？\s]|$)", re.MULTILINE), "でした"),
    # 文末：する・した・しない
    (re.compile(r"する(?=[。！？\s]|$)", re.MULTILINE), "します"),
    (re.compile(r"(?<!ま)(?<!で)した(?=[。！？\s]|$)", re.MULTILINE), "しました"),
    (re.compile(r"しない(?=[。！？\s]|$)", re.MULTILINE), "しません"),
    (re.compile(r"しなかった(?=[。！？\s]|$)", re.MULTILINE), "しませんでした"),
    # 文末：できる・できた
    (re.compile(r"できる(?=[。！？\s]|$)", re.MULTILINE), "できます"),
    (re.compile(r"できた(?=[。！？\s]|$)", re.MULTILINE), "できました"),
    (re.compile(r"できない(?=[。！？\s]|$)", re.MULTILINE), "できません"),
    (re.compile(r"できなかった(?=[。！？\s]|$)", re.MULTILINE),
     "できませんでした"),
    # 文末：ない・なかった
    (re.compile(r"ない(?=[。！？\s]|$)", re.MULTILINE), "ありません"),
    (re.compile(r"なかった(?=[。！？\s]|$)", re.MULTILINE), "ありませんでした"),
    # 文末：行く・来る・言う・思う・見る
    (re.compile(r"行く(?=[。！？\s]|$)", re.MULTILINE), "いきます"),
    (re.compile(r"行った(?=[。！？\s]|$)", re.MULTILINE), "いきました"),
    (re.compile(r"来る(?=[。！？\s]|$)", re.MULTILINE), "きます"),
    (re.compile(r"来た(?=[。！？\s]|$)", re.MULTILINE), "きました"),
    (re.compile(r"言う(?=[。！？\s]|$)", re.MULTILINE), "言います"),
    (re.compile(r"言った(?=[。！？\s]|$)", re.MULTILINE), "言いました"),
    (re.compile(r"思う(?=[。！？\s]|$)", re.MULTILINE), "思います"),
    (re.compile(r"思った(?=[。！？\s]|$)", re.MULTILINE), "思いました"),
    (re.compile(r"見る(?=[。！？\s]|$)", re.MULTILINE), "見ます"),
    (re.compile(r"見た(?=[。！？\s]|$)", re.MULTILINE), "見ました"),
    (re.compile(r"分かる(?=[。！？\s]|$)", re.MULTILINE), "分かります"),
    (re.compile(r"分かった(?=[。！？\s]|$)", re.MULTILINE), "分かりました"),
    (re.compile(r"分からない(?=[。！？\s]|$)", re.MULTILINE), "分かりません"),
    # 文末：依頼・希望
    (re.compile(r"してくれ(?=[。！？\s]|$)", re.MULTILINE), "してください"),
    (re.compile(r"してほしい(?=[。！？\s]|$)", re.MULTILINE),
     "していただけますと幸いです"),
    (re.compile(r"したい(?=[。！？、,\s]|$)", re.MULTILINE), "したいです"),
    (re.compile(r"したかった(?=[。！？、,\s]|$)", re.MULTILINE), "したかったです"),
    # 文末：意志・勧誘（〜う・よう → 〜ましょう）
    (re.compile(r"行こう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "行きましょう"),
    (re.compile(r"しよう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "しましょう"),
    (re.compile(r"食べよう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE),
     "食べましょう"),
    (re.compile(r"見よう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "見ましょう"),
    (re.compile(r"話そう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "話しましょう"),
    (re.compile(r"始めよう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE),
     "始めましょう"),
    (re.compile(r"やろう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "やりましょう"),
    (re.compile(r"帰ろう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "帰りましょう"),
    (re.compile(r"買おう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "買いましょう"),
    (re.compile(r"待とう(?:ぜ|よ)?(?=[。！？、,\s]|$)", re.MULTILINE), "待ちましょう"),
    # 文末：口語・砕けた終助詞（ぜ、ぞ、じゃん、よな等）
    (re.compile(r"(?:長すいた|長すぎた)(?:ぜ|ぞ)?(?=[。！？、,\s]|$)", re.MULTILINE),
     "長すぎました"),
    (re.compile(r"すぎた(?:ぜ|ぞ)?(?=[。！？、,\s]|$)", re.MULTILINE), "すぎました"),
    (re.compile(r"すぎる(?:ぜ|ぞ)?(?=[。！？、,\s]|$)", re.MULTILINE), "すぎます"),
    (re.compile(r"(?:だ)?ぜ(?=[。！？、,\s]|$)", re.MULTILINE), "です"),
    (re.compile(r"(?:だ)?ぞ(?=[。！？、,\s]|$)", re.MULTILINE), "です"),
    (re.compile(r"じゃん(?=[。！？、,\s]|$)", re.MULTILINE), "ですね"),
    (re.compile(r"(?:だ)?よな(?=[。！？、,\s]|$)", re.MULTILINE), "ですね"),
    (re.compile(r"だな(?=[。！？、,\s]|$)", re.MULTILINE), "ですね"),
    # 文末：略語・進行・完了（〜てる、〜ちゃう、〜とく）
    (re.compile(r"してる(?=[。！？、,\s]|$)", re.MULTILINE), "しています"),
    (re.compile(r"してた(?=[。！？、,\s]|$)", re.MULTILINE), "していました"),
    (re.compile(r"言ってる(?=[。！？、,\s]|$)", re.MULTILINE), "言っています"),
    (re.compile(r"言ってた(?=[。！？、,\s]|$)", re.MULTILINE), "言っていました"),
    (re.compile(r"知ってる(?=[。！？、,\s]|$)", re.MULTILINE), "知っています"),
    (re.compile(r"知ってた(?=[。！？、,\s]|$)", re.MULTILINE), "知っていました"),
    (re.compile(r"分かってる(?=[。！？、,\s]|$)", re.MULTILINE), "分かっています"),
    (re.compile(r"分かってた(?=[。！？、,\s]|$)", re.MULTILINE), "分かっていました"),
    (re.compile(r"待ってる(?=[。！？、,\s]|$)", re.MULTILINE), "待っています"),
    (re.compile(r"やってる(?=[。！？、,\s]|$)", re.MULTILINE), "やっています"),
    (re.compile(r"やっちゃった(?=[。！？、,\s]|$)", re.MULTILINE),
     "やってしまいました"),
    (re.compile(r"やっちゃう(?=[。！？、,\s]|$)", re.MULTILINE), "やってしまいます"),
    (re.compile(r"しちゃった(?=[。！？、,\s]|$)", re.MULTILINE), "してしまいました"),
    (re.compile(r"しちゃう(?=[。！？、,\s]|$)", re.MULTILINE), "してしまいます"),
    (re.compile(r"置いとく(?=[。！？、,\s]|$)", re.MULTILINE), "置いておきます"),
    (re.compile(r"しとく(?=[。！？、,\s]|$)", re.MULTILINE), "しておきます"),
    # 文末：日常動詞
    (re.compile(r"食べる(?=[。！？、,\s]|$)", re.MULTILINE), "食べます"),
    (re.compile(r"食べた(?=[。！？、,\s]|$)", re.MULTILINE), "食べました"),
    (re.compile(r"食べない(?=[。！？、,\s]|$)", re.MULTILINE), "食べません"),
    (re.compile(r"終わる(?=[。！？、,\s]|$)", re.MULTILINE), "終わります"),
    (re.compile(r"終わった(?=[。！？、,\s]|$)", re.MULTILINE), "終わりました"),
    (re.compile(r"始める(?=[。！？、,\s]|$)", re.MULTILINE), "始めます"),
    (re.compile(r"始めた(?=[。！？、,\s]|$)", re.MULTILINE), "始めました"),
    (re.compile(r"買う(?=[。！？、,\s]|$)", re.MULTILINE), "買います"),
    (re.compile(r"買った(?=[。！？、,\s]|$)", re.MULTILINE), "買いました"),
    (re.compile(r"使う(?=[。！？、,\s]|$)", re.MULTILINE), "使います"),
    (re.compile(r"使った(?=[。！？、,\s]|$)", re.MULTILINE), "使いました"),
    (re.compile(r"待つ(?=[。！？、,\s]|$)", re.MULTILINE), "待ちます"),
    (re.compile(r"待った(?=[。！？、,\s]|$)", re.MULTILINE), "待ちました"),
    (re.compile(r"送る(?=[。！？、,\s]|$)", re.MULTILINE), "送ります"),
    (re.compile(r"送った(?=[。！？、,\s]|$)", re.MULTILINE), "送りました"),
    (re.compile(r"書く(?=[。！？、,\s]|$)", re.MULTILINE), "書きます"),
    (re.compile(r"書いた(?=[。！？、,\s]|$)", re.MULTILINE), "書きました"),
    (re.compile(r"知る(?=[。！？、,\s]|$)", re.MULTILINE), "知ります"),
    (re.compile(r"知った(?=[。！？、,\s]|$)", re.MULTILINE), "知りました"),
    (re.compile(r"要る(?=[。！？、,\s]|$)", re.MULTILINE), "要ります"),
    (re.compile(r"いらない(?=[。！？、,\s]|$)", re.MULTILINE), "いりません"),
    (re.compile(r"ほしい(?=[。！？、,\s]|$)|欲しい(?=[。！？、,\s]|$)", re.MULTILINE),
     "欲しいです"),
    # 文末：依頼・指示
    (re.compile(r"して(?=[。！？、,\s]|$)", re.MULTILINE), "してください"),
    (re.compile(r"やって(?=[。！？、,\s]|$)", re.MULTILINE), "やってください"),
    (re.compile(r"教えて(?=[。！？、,\s]|$)", re.MULTILINE), "教えてください"),
    (re.compile(r"見て(?=[。！？、,\s]|$)", re.MULTILINE), "見てください"),
    (re.compile(r"待って(?=[。！？、,\s]|$)", re.MULTILINE), "待ってください"),
    (re.compile(r"送って(?=[。！？、,\s]|$)", re.MULTILINE), "送ってください"),
    (re.compile(r"頼む(?=[。！？、,\s]|$)", re.MULTILINE), "お願いします"),
    # 文末：形容詞（〜い → 〜いです）
    (re.compile(r"いい(?=[。！？\s]|$)", re.MULTILINE), "いいです"),
    (re.compile(r"よい(?=[。！？\s]|$)|良い(?=[。！？\s]|$)", re.MULTILINE),
     "良いです"),
    (re.compile(r"よかった(?=[。！？\s]|$)|良かった(?=[。！？\s]|$)",
                re.MULTILINE), "良かったです"),
    (re.compile(r"すごい(?=[。！？\s]|$)", re.MULTILINE), "すごいです"),
    (re.compile(r"多い(?=[。！？\s]|$)", re.MULTILINE), "多いです"),
    (re.compile(r"少ない(?=[。！？\s]|$)", re.MULTILINE), "少ないです"),
    (re.compile(r"高い(?=[。！？\s]|$)", re.MULTILINE), "高いです"),
    (re.compile(r"低い(?=[。！？\s]|$)", re.MULTILINE), "低いです"),
    # 文末：義務・必要（〜なきゃ、〜しないと）
    (re.compile(r"(?:しなきゃ|せねば)(?=[。！？、,\s]|$)", re.MULTILINE),
     "しなければなりません"),
    (re.compile(r"しないと(?=[。！？、,\s]|$)", re.MULTILINE),
     "する必要があります"),
    (re.compile(r"行かなきゃ(?=[。！？、,\s]|$)", re.MULTILINE),
     "行かなければなりません"),
    # 文末：推量・願望・様態
    (re.compile(r"たいな(?=[。！？、,\s]|$)", re.MULTILINE), "たいです"),
    (re.compile(r"かも(?:しれない)?(?=[。！？、,\s]|$)", re.MULTILINE),
     "かもしれません"),
    (re.compile(r"はずだ(?=[。！？、,\s]|$)", re.MULTILINE), "はずです"),
    (re.compile(r"つもりだ(?=[。！？、,\s]|$)", re.MULTILINE), "つもりです"),
    (re.compile(r"ようだ(?=[。！？、,\s]|$)", re.MULTILINE), "ようです"),
    (re.compile(r"そうだ(?=[。！？、,\s]|$)", re.MULTILINE), "そうです"),
    (re.compile(r"らしい(?=[。！？、,\s]|$)", re.MULTILINE), "らしいです"),
    (re.compile(r"わけだ(?=[。！？、,\s]|$)", re.MULTILINE), "わけです"),
    # 接続詞・強調・副詞
    (re.compile(r"マジで|まじで|ガチで|がちで"), "本当に"),
    (re.compile(r"めっちゃ|超(?=[あ-んア-ン])"), "とても"),
    (re.compile(r"やばい(?=[。！？\s]|$)"), "大変です"),
]


def to_polite(text: str) -> str:
    """テキストを丁寧語（です・ます調）に変換する（完全オフライン）。"""
    if not text:
        return text
    result = text
    for pat, rep in _POLITE_SUBSTITUTIONS:
        result = pat.sub(rep, result)
    return result


# ------------------------------------------------------------ ビジネス丁寧語

_BUSINESS_SUBSTITUTIONS: Final[list[tuple[re.Pattern[str], str]]] = [
    # 挨拶・感謝
    (re.compile(r"ありがとう(ございます)?(?=[。！？\s]|$)"),
     "誠にありがとうございます"),
    (re.compile(r"よろしく(お願いします)?(?=[。！？\s]|$)"),
     "何卒よろしくお願い申し上げます"),
    (re.compile(r"すいません|すみません"), "大変恐れ入ります"),
    (re.compile(r"ごめん(なさい)?"), "大変申し訳ございません"),
    # 依頼
    (re.compile(r"(?:確認して|見て|チェックして)(?:ください)?(?=[。！？\s]|$)"),
     "ご確認いただけますと幸いです"),
    (re.compile(r"(?:送って|送付して)(?:ください)?(?=[。！？\s]|$)"),
     "ご送付いただけますと幸甚に存じます"),
    (re.compile(r"(?:教えて|連絡して)(?:ください)?(?=[。！？\s]|$)"),
     "ご教示いただけますと幸いです"),
    # 動詞の謙譲語・丁寧化
    (re.compile(r"(?:言いました|いいました)(?=[。！？\s]|$)", re.MULTILINE),
     "申し上げました"),
    (re.compile(r"(?:言います|いいます)(?=[。！？\s]|$)", re.MULTILINE),
     "申し上げます"),
    (re.compile(r"(?:行きました|いきました)(?=[。！？\s]|$)", re.MULTILINE),
     "伺いました"),
    (re.compile(r"(?:行きます|いきます)(?=[。！？\s]|$)", re.MULTILINE),
     "伺います"),
    (re.compile(r"(?:見ました|みました)(?=[。！？\s]|$)", re.MULTILINE),
     "拝見いたしました"),
    (re.compile(r"(?:見ます|みます)(?=[。！？\s]|$)", re.MULTILINE),
     "拝見いたします"),
    (re.compile(r"(?:思いました|おもいました)(?=[。！？\s]|$)", re.MULTILINE),
     "存じました"),
    (re.compile(r"(?:思います|おもいます)(?=[。！？\s]|$)", re.MULTILINE),
     "存じます"),
    (re.compile(r"(?:知っています|しっています)(?=[。！？\s]|$)", re.MULTILINE),
     "存じております"),
    (re.compile(r"(?:知りません|しりません)(?=[。！？\s]|$)", re.MULTILINE),
     "存じ上げません"),
    (re.compile(r"できます(?=[。！？\s]|$)", re.MULTILINE), "可能でございます"),
    (re.compile(r"できません(?=[。！？\s]|$)", re.MULTILINE), "対応いたしかねます"),
    (re.compile(r"(?:いいです|良いです)(?=[。！？\s]|$)", re.MULTILINE),
     "問題ございません"),
    # 承諾・返答
    (re.compile(r"(?:わかりました|分かりました|了解です|了解いたしました)(?=[。！？\s]|$)"),
     "承知いたしました"),
    (re.compile(r"すいませんでした|すみませんでした(?=[。！？\s]|$)"),
     "大変申し訳ございませんでした"),
    # 依頼・伺い
    (re.compile(r"(?:してもらえますか|してくれますか)(?=[。！？\s]|$)"),
     "していただけますでしょうか"),
    (re.compile(r"(?:待ってください|待って)(?=[。！？\s]|$)"),
     "少々お待ちいただけますでしょうか"),
    (re.compile(r"(?:連絡してください|教えてください)(?=[。！？\s]|$)"),
     "ご連絡いただけますと幸いです"),
    (re.compile(r"(?:質問があります|聞きたいです)(?=[。！？\s]|$)"),
     "ご質問させていただきたく存じます"),
    (re.compile(r"(?:相談があります|相談したいです)(?=[。！？\s]|$)"),
     "ご相談させていただけますでしょうか"),
    (re.compile(r"(?:助かります|助かる)(?=[。！？\s]|$)"),
     "大変助かります"),
    (re.compile(r"どうですか(?=[。！？\s]|$)"), "いかがでしょうか"),
    (re.compile(r"いいですか(?=[。！？\s]|$)"), "よろしいでしょうか"),
]


def to_business(text: str) -> str:
    """テキストをビジネス丁寧語・メール調に変換する（完全オフライン）。"""
    if not text:
        return text
    # 先に通常の敬語化を適用してから、ビジネス定型句へ昇格
    result = to_polite(text)
    for pat, rep in _BUSINESS_SUBSTITUTIONS:
        result = pat.sub(rep, result)
    return result


# ------------------------------------------------------------ 要約（箇条書き）


def to_summary(text: str) -> str:
    """テキストの要点を簡潔な箇条書きにまとめる（完全オフライン）。"""
    if not text:
        return text
    # 句点や改行で文に分割
    sentences = [s.strip() for s in re.split(r"[。\n]+", text) if s.strip()]
    if not sentences:
        return text
    if len(sentences) == 1:
        return f"・{sentences[0]}"
    # 複数文を箇条書き形式に
    lines = [f"・{s}" for s in sentences]
    return "\n".join(lines)


# ------------------------------------------------------------ 業務報告（Slack風）


def to_slack_report(text: str) -> str:
    """テキストをSlackやTeams等の業務報告フォーマットに整形する（完全オフライン）。"""
    if not text:
        return text
    sentences = [s.strip() for s in re.split(r"[。\n]+", text) if s.strip()]
    if not sentences:
        return text
    items = "\n".join(f"・{s}" for s in sentences)
    return f"【進捗・共有事項】\n{items}"


# ------------------------------------------------------------ 英語翻訳（オフライン）

# よくある日常会話・定型フレーズのオフライン対訳辞書
_BASIC_TRANSLATIONS: Final[dict[str, str]] = {
    # 挨拶・別れ
    "こんにちは": "Hello.",
    "おはようございます": "Good morning.",
    "おはよう": "Good morning.",
    "こんばんは": "Good evening.",
    "さようなら": "Goodbye.",
    "じゃあね": "See you.",
    "またね": "See you later.",
    "お疲れ様です": "Thank you for your hard work.",
    "おつかれさまです": "Thank you for your hard work.",
    "初めまして": "Nice to meet you.",
    "はじめまして": "Nice to meet you.",
    "よろしくお願いします": "Nice to meet you.",
    "よろしく": "Best regards.",
    # 感謝・謝罪
    "ありがとうございます": "Thank you very much.",
    "ありがとう": "Thank you.",
    "どうもありがとう": "Thank you so much.",
    "すみません": "Excuse me.",
    "すいません": "Excuse me.",
    "ごめんなさい": "I'm sorry.",
    "申し訳ありません": "I am terribly sorry.",
    "失礼します": "Excuse me.",
    # 返答・相槌
    "はい": "Yes.",
    "いいえ": "No.",
    "わかりました": "Understood.",
    "分かりました": "Understood.",
    "わかりません": "I don't know.",
    "分かりません": "I don't understand.",
    "了解です": "Got it.",
    "了解": "Understood.",
    "オッケーです": "OK.",
    "オッケー": "OK.",
    "問題ありません": "No problem.",
    "大丈夫です": "It's okay.",
    "大丈夫": "All good.",
    "なるほど": "I see.",
    "そうですか": "Is that so?",
    "そうですね": "That's right.",
    "その通りです": "Exactly.",
    "確かに": "Indeed.",
    "本当ですか": "Really?",
    "マジで": "Seriously?",
    "いいね": "Sounds good.",
    "いいですね": "That sounds great.",
    # 依頼・質問
    "お願いします": "Please.",
    "助けてください": "Please help me.",
    "教えてください": "Please tell me.",
    "確認してください": "Please check.",
    "見てください": "Please take a look.",
    "待ってください": "Please wait a moment.",
    "少々お待ちください": "Please wait a moment.",
    "どう思いますか": "What do you think?",
    "どういうことですか": "What do you mean?",
    "何ですか": "What is it?",
    "どこですか": "Where is it?",
    "いつですか": "When is it?",
    # 日常・作業
    "テストです": "This is a test.",
    "テスト": "Test.",
    "完了しました": "Completed.",
    "終わりました": "Finished.",
    "できました": "Done.",
    "始めます": "Let's begin.",
    "行きます": "I'm coming.",
    "ご飯行こう": "Let's go have a meal.",
    "ご飯行きましょう": "Let's go have a meal.",
    "飲みに行こう": "Let's go for a drink.",
    "お腹すいた": "I'm hungry.",
    "眠い": "I'm sleepy.",
    "疲れた": "I'm tired.",
    "暑い": "It's hot.",
    "寒い": "It's cold.",
    # 天気・予定
    "明日は晴れです": "It will be sunny tomorrow.",
    "明日は晴れ": "It will be sunny tomorrow.",
    "明日は雨です": "It will be rainy tomorrow.",
    "明日は雨": "It will be rainy tomorrow.",
    "今日は晴れです": "It is sunny today.",
    "今日は晴れ": "It is sunny today.",
    "今日は雨です": "It is raining today.",
    "今日は雨": "It is raining today.",
    "いい天気ですね": "Nice weather, isn't it?",
    "良い天気ですね": "Nice weather, isn't it?",
}


def to_english_offline(text: str) -> str:
    """オフライン辞書・定型パターンによる英語翻訳（完全オフライン）。

    単文の完全一致だけでなく、文頭の挨拶＋日常文の組み合わせ
    （例: 「おはようございます明日は晴れです」）も分割して翻訳する。
    """
    if not text:
        return text

    is_q = text.rstrip().endswith(("？", "?"))
    clean = text.strip("。、 \t　？?")
    if clean in _BASIC_TRANSLATIONS:
        res = _BASIC_TRANSLATIONS[clean]
        if is_q and res.endswith("."):
            res = res[:-1] + "?"
        return res

    # 句読点や空白で区切られている場合の分割翻訳
    parts = [p.strip("。、 \t　？?") for p in re.split(r"[。、\s]+", text)
             if p.strip("。、 \t　？?")]
    if len(parts) >= 2 and all(p in _BASIC_TRANSLATIONS for p in parts):
        return " ".join(_BASIC_TRANSLATIONS[p] for p in parts)

    # 句読点がない複合文（例: "おはようございます明日は晴れです"）
    # 最長一致で先頭フレーズと後半フレーズを切り出して翻訳を試みる
    for k in sorted(_BASIC_TRANSLATIONS.keys(), key=len, reverse=True):
        if clean.startswith(k):
            rest = clean[len(k):].strip("。、 \t　？?")
            if rest in _BASIC_TRANSLATIONS:
                first = _BASIC_TRANSLATIONS[k]
                second = _BASIC_TRANSLATIONS[rest]
                if is_q and second.endswith("."):
                    second = second[:-1] + "?"
                return f"{first} {second}"

    return text


# ------------------------------------------------------------ オフライン AI 自動編集・各モード

_ADVANCED_FILLERS: Final[tuple[re.Pattern[str], ...]] = (
    re.compile(r"(?:^|[、。\s])(?:えーと|えっと|ええと|あのー?|まあ|なんか|うーん|そのー?|ほら|えー)(?:[、\s]+|(?=[^a-zA-Z0-9]))"),
    re.compile(r"(?:^|[、。\s])(?:で(?:えーと|あのー?|まあ|なんか))(?:[、\s]+|(?=[^a-zA-Z0-9]))"),
)

_REPAIR_PATTERNS: Final[list[re.Pattern[str]]] = [
    re.compile(r"([^、。\n]+?)(?:[、,\s]+)*(?:いや待って(?:、|,|\s)*|いや(?:、|,|\s)+|じゃなくて(?:、|,|\s)*|ではなく(?:、|,|\s)*|やっぱり(?:、|,|\s)*|というか(?:、|,|\s)*)([^、。\n]+)"),
]


def remove_advanced_fillers(text: str) -> str:
    """テキストから高度なフィラー語を取り除く（完全オフライン）。"""
    from .textproc import tidy
    res = tidy(text, fillers=True)
    for pat in _ADVANCED_FILLERS:
        res = pat.sub("、", res)
    res = re.sub(r"^[、,\s]+|[、,\s]+$", "", res)
    res = re.sub(r"[、,]{2,}", "、", res)
    return res.strip()


def fix_speech_repair(text: str) -> str:
    """言い直し・自己訂正を検出し、最新の正しい意図を反映する（完全オフライン）。"""
    res = text
    for pat in _REPAIR_PATTERNS:
        for _ in range(3):
            m = pat.search(res)
            if not m:
                break
            after = m.group(2).strip()
            res = res[:m.start()] + after + res[m.end():]
    return res.strip()


def structure_speech_lists(text: str) -> str:
    """タスクや複数項目の列挙を検出し、自動で番号付きリストに構造化する（完全オフライン）。"""
    split_words = (
        r"(?:まずは|最初(?:は|に)|１つ目(?:は|に)|ひとつめ(?:は|に)|"
        r"次に|つぎに|２つ目(?:は|に)|ふたつめ(?:は|に)|"
        r"それから|そのあと|３つ目(?:は|に)|みっつめ(?:は|に)|"
        r"あと(?:は|で)?|最後(?:は|に)|４つ目(?:は|に)|よっつめ(?:は|に))"
    )
    parts = [p.strip() for p in re.split(rf"(?:[、。\s]*{split_words}[、:\s]*)", text)
             if p.strip()]

    # 「〜3つあって」「タスクは」等の列挙トリガー
    has_trigger = any(kw in text for kw in ("タスク", "やること", "予定", "3つ", "３つ", "まずは", "次に"))
    if len(parts) >= 2 and has_trigger:
        header = "今日のタスク："
        if "予定" in text:
            header = "予定："
        elif "3つ" in text or "３つ" in text:
            header = "今日の3つのタスク："

        # 最初の要素にヘッダーっぽい言葉が含まれていれば削る
        cleaned_parts: list[str] = []
        for p in parts:
            cp = re.sub(r"^(?:今日の|明日の)?(?:3つ|３つ|[0-9]+つ)?(?:の)?(?:タスク|やること|予定|仕事)?(?:は|が)?(?:3つあって|３つあって|[0-9]+つあって)?[、。\s]*", "", p).strip()
            if cp:
                cleaned_parts.append(cp)

        items = cleaned_parts if len(cleaned_parts) >= 2 else parts
        formatted = [f"{i}. {it.strip('、。\n ')}" for i, it in enumerate(items, 1) if it.strip()]
        if formatted:
            return f"{header}\n" + "\n".join(formatted)

    return text


def to_ai_auto_edit_offline(text: str) -> str:
    """Speakly 風の AI 自動編集を完全オフラインで高速実行する。"""
    step1 = remove_advanced_fillers(text)
    step2 = fix_speech_repair(step1)
    step3 = structure_speech_lists(step2)
    return step3.strip()


def to_terminal_helper_offline(text: str) -> str:
    """話した内容を実行可能なターミナルコマンドにオフライン変換する。"""
    cleaned = text.strip("。、 \t　")
    lowered = cleaned.lower()

    if any(w in lowered for w in ("移動", "いどう", "cd", "チェンジディレクトリ")):
        if "親" in lowered or "一つ上" in lowered or "1つ上" in lowered:
            return "cd .."
        if "デスクトップ" in lowered:
            return "cd ~/Desktop"
        if "ダウンロード" in lowered:
            return "cd ~/Downloads"
        m = re.search(r"([a-zA-Z0-9_\-\./\\]+)(?:フォルダ|ディレクトリ)?(?:に|へ)?(?:移動|いどう)", cleaned)
        if m:
            return f"cd {m.group(1)}"
        return "cd ."

    if any(w in lowered for w in ("一覧", "ファイル一覧", "中身", "ls", "dir")):
        return "ls -la"
    if "ステータス" in lowered or "状況" in lowered or "status" in lowered:
        return "git status"
    if "コミット" in lowered or "commit" in lowered:
        m = re.search(r"[「『\"]([^」』\"]+)[」』\"]", cleaned)
        msg = m.group(1) if m else "update"
        return f'git commit -m "{msg}"'
    if "プッシュ" in lowered or "push" in lowered:
        return "git push"
    if "プル" in lowered or "pull" in lowered:
        return "git pull"
    if "ブランチ" in lowered or "branch" in lowered:
        return "git branch"
    if "ログ" in lowered or "履歴" in lowered or "log" in lowered:
        return "git log --oneline -n 10"
    if "ステージ" in lowered or "add" in lowered:
        return "git add ."
    if "インストール" in lowered or "install" in lowered:
        if "pip" in lowered or "パイソン" in lowered:
            return "pip install -r requirements.txt"
        return "npm install"
    if "ビルド" in lowered or "build" in lowered:
        return "npm run build"
    if "テスト" in lowered or "test" in lowered:
        return "npm test"
    if "開始" in lowered or "起動" in lowered or "start" in lowered or "dev" in lowered:
        return "npm run dev"
    if "クリア" in lowered or "画面消して" in lowered:
        return "clear"

    return cleaned


def to_chaos_mode_offline(text: str) -> str:
    """カオスモード（ミーム・ハイテンション）へのオフライン変換。"""
    cleaned = text.strip("。、 \t　")
    res = re.sub(r"(?:です|ます)(?=[。！？\s]|$)", "で草www", cleaned)
    res = re.sub(r"(?:だ|である)(?=[。！？\s]|$)", "とかマジ神なんだが🔥", res)
    if not res.endswith(("w", "🔥", "！")):
        res += " ₍₍ (ง ˘ω˘ )ว ⁾⁾ 完全に理解した"
    return res


def to_buzzword_mode_offline(text: str) -> str:
    """バズワードモード（ビジネスカタカナ語満載）へのオフライン変換。"""
    cleaned = text.strip("。、 \t　")
    reps = [
        ("賛成", "アグリー"), ("合意", "コンセンサス"),
        ("協力", "シナジー"), ("責任", "コミット"),
        ("詳細", "解像度"), ("保留", "ペンディング"),
        ("次の予定", "ネクストアクション"), ("優先", "プライオリティ"),
        ("課題", "イシュー"), ("目的", "アジェンダ"),
    ]
    res = cleaned
    for ja, buzz in reps:
        res = res.replace(ja, buzz)
    return f"{res}（解像度高くコミットしていきましょう）"



def to_reply_generator_offline(text: str, clipboard_text: str = "") -> str:
    """相手のメッセージに対する返信文を作成する（完全オフライン）。"""
    polite_body = to_polite(text.strip("。、 \t　"))
    if not polite_body.endswith(("です", "ます", "でした", "でしょうか", "幸いです", "存じます")):
        polite_body += "です。"
    elif not polite_body.endswith("。"):
        polite_body += "。"
    if clipboard_text.strip():
        return f"ご連絡ありがとうございます。\n\n{polite_body}\n\n何卒よろしくお願い申し上げます。"
    return f"ご連絡ありがとうございます。\n\n{polite_body}\n\n引き続きよろしくお願いいたします。"


def to_meeting_minutes_offline(text: str) -> str:
    """話した内容から議事録を作成する（完全オフライン）。"""
    sentences = [s.strip("、 \t　") for s in re.split(r"[。\n]+", text) if s.strip("、 \t　")]
    if not sentences:
        return text

    decisions: list[str] = []
    actions: list[str] = []
    topics: list[str] = []

    for s in sentences:
        lowered = s.lower()
        if any(w in lowered for w in ("決定", "決まり", "確定", "することにした", "方針", "合意")):
            decisions.append(s)
        elif any(w in lowered for w in ("やる", "タスク", "作成", "確認", "提出", "担当", "まで", "予定", "進める", "対応")):
            actions.append(s)
        else:
            topics.append(s)

    lines: list[str] = []
    if decisions:
        lines.append("【決定事項】")
        lines.extend(f"・{d}" for d in decisions)
    if actions:
        if lines:
            lines.append("")
        lines.append("【ネクストアクション】")
        lines.extend(f"・{a}" for a in actions)
    if topics or not lines:
        if lines:
            lines.append("")
        lines.append("【共有事項・協議メモ】")
        lines.extend(f"・{t}" for t in (topics or sentences))

    return "\n".join(lines)


def to_proofread_offline(text: str) -> str:
    """文章の誤字脱字・不自然な表現を推敲・校正する（完全オフライン）。"""
    cleaned = text.strip()
    reps = [
        (re.compile(r"こんにちわ"), "こんにちは"),
        (re.compile(r"こんばんわ"), "こんばんは"),
        (re.compile(r"そうゆう"), "そういう"),
        (re.compile(r"どうゆう"), "どういう"),
        (re.compile(r"こうゆう"), "こういう"),
        (re.compile(r"てゆうか"), "というか"),
        (re.compile(r"見れる"), "見られる"),
        (re.compile(r"来れる"), "来られる"),
        (re.compile(r"食べれる"), "食べられる"),
        (re.compile(r"出れる"), "出られる"),
        (re.compile(r"的を得る"), "的を射る"),
        (re.compile(r"違かった"), "違っていた"),
        (re.compile(r"全然大丈夫"), "全く問題ありません"),
        (re.compile(r"(?<![0-9])一応(?![0-9])"), "念のため"),
    ]
    res = cleaned
    for pat, rep in reps:
        res = pat.sub(rep, res)
    return res


def to_standardize_offline(text: str) -> str:
    """口語・方言・スラングを標準語・公用文向けに整える（完全オフライン）。"""
    cleaned = text.strip()
    reps = [
        (re.compile(r"じゃん(?=[。！？、\s]|$)"), "ではないでしょうか"),
        (re.compile(r"だよね(?=[。！？、\s]|$)"), "ですね"),
        (re.compile(r"〜っしょ|っしょ(?=[。！？、\s]|$)"), "でしょう"),
        (re.compile(r"やん(?:か)?(?=[。！？、\s]|$)"), "ではないですか"),
        (re.compile(r"〜けん|けん(?=[。！？、\s]|$)"), "ので"),
        (re.compile(r"マジで|まじで|ガチで|がちで"), "本当に"),
        (re.compile(r"めっちゃ|超(?=[あ-んア-ン])|すごく|すげー"), "非常に"),
        (re.compile(r"ヤバい|やばい"), "非常に重要な状況です"),
        (re.compile(r"〜しなきゃ|しなきゃ"), "しなければなりません"),
        (re.compile(r"〜しないと|しないと(?=[。！？、\s]|$)"), "する必要があります"),
    ]
    res = cleaned
    for pat, rep in reps:
        res = pat.sub(rep, res)
    return to_polite(res)


def to_brainstorm_offline(text: str) -> str:
    """アイデアの断片を企画骨子に構造化する（完全オフライン）。"""
    sentences = [s.strip("、 \t　") for s in re.split(r"[。\n]+", text) if s.strip("、 \t　")]
    if not sentences:
        return text

    concept = sentences[0]
    details = sentences[1:] if len(sentences) > 1 else [concept]

    lines = [
        "【コアコンセプト】",
        f"・{concept}",
        "",
        "【具体的な施策・アイデア骨子】",
    ]
    lines.extend(f"・{d}" for d in details)
    lines.append("")
    lines.append("【期待される効果・提供価値】")
    lines.append(f"・{concept}を通じた業務効率化および体験価値の向上")

    return "\n".join(lines)


def to_smart_calc_offline(text: str) -> str:
    """四則演算・税込税抜・割引・相対日付をオフラインで計算・変換する。"""
    if not text:
        return text

    clean = text.strip()

    # --- 1. 相対日付・時刻の解析 ---
    now = datetime.datetime.now()
    today = now.date()

    # 今日の日時・時間
    if any(w in clean for w in ("現在の日時", "いまの日時", "今の日時")):
        return now.strftime("%Y年%m月%d日 %H:%M")
    if any(w in clean for w in
           ("現在の時刻", "現在の時間", "今の時刻", "今の時間", "今何時",
            "いま何時")):
        return now.strftime("%H:%M")

    # 日付表現
    if clean in ("今日", "きょう", "本日の日付", "今日の日付"):
        return today.strftime("%Y年%m月%d日")
    if clean in ("明日", "あした", "明日の日付"):
        return (today + datetime.timedelta(days=1)).strftime("%Y年%m月%d日")
    if clean in ("明後日", "あさって", "明後日の日付"):
        return (today + datetime.timedelta(days=2)).strftime("%Y年%m月%d日")
    if clean in ("昨日", "きのう", "昨日の日付"):
        return (today - datetime.timedelta(days=1)).strftime("%Y年%m月%d日")
    if clean in ("一昨日", "おととい"):
        return (today - datetime.timedelta(days=2)).strftime("%Y年%m月%d日")

    # 来週の曜日 (月:0, 火:1, 水:2, 木:3, 金:4, 土:5, 日:6)
    weekdays = {"月": 0, "火": 1, "水": 2, "木": 3, "金": 4, "土": 5, "日": 6}
    m_week = re.search(r"来週の?([月火水木金土日])曜?", clean)
    if m_week:
        target_wd = weekdays[m_week.group(1)]
        days_ahead = (target_wd - today.weekday()) + 7
        target_date = today + datetime.timedelta(days=days_ahead)
        return target_date.strftime("%Y年%m月%d日")

    # 今週の曜日
    m_this_week = re.search(r"今週の?([月火水木金土日])曜?", clean)
    if m_this_week:
        target_wd = weekdays[m_this_week.group(1)]
        days_diff = target_wd - today.weekday()
        target_date = today + datetime.timedelta(days=days_diff)
        return target_date.strftime("%Y年%m月%d日")

    # --- 0. 万単位の前処理（例: 1万円 -> 10000円） ---
    def _parse_man(m: re.Match[str]) -> str:
        man = int(m.group(1)) * 10000
        rem = int(m.group(2)) if m.group(2) else 0
        return f"{man + rem}円"

    clean = re.sub(r"(\d+)万(?:(\d+))?円?", _parse_man, clean)

    # --- 2. 税込・税抜計算（標準税率10%） ---
    tax_in_pat = (
        r"(?:(?:消費税[込込]|税込[み]?)\s*(\d+)|"
        r"(\d+)\s*円?の?(?:消費税[込込]|税込[み]?))"
    )
    m_tax_in = re.search(tax_in_pat, clean)
    if m_tax_in:
        val_str = m_tax_in.group(1) or m_tax_in.group(2)
        val = int(val_str)
        res = int(round(val * 1.10))
        return f"{res:,}円（税込）"

    tax_ex_pat = (
        r"(?:(?:税[抜別]|消費税[抜別き]+)\s*(\d+)|"
        r"(\d+)\s*円?の?(?:税[抜別]|消費税[抜別き]+))"
    )
    m_tax_ex = re.search(tax_ex_pat, clean)
    if m_tax_ex:
        val_str = m_tax_ex.group(1) or m_tax_ex.group(2)
        val = int(val_str)
        res = int(round(val / 1.10))
        return f"{res:,}円（税抜）"

    # --- 3. 割引・パーセントオフ・半額 ---
    m_half = re.search(r"(\d+)\s*円?の?半額", clean)
    if m_half:
        val = int(m_half.group(1))
        res = int(round(val / 2.0))
        return f"{res:,}円（半額）"

    m_disc_pct = re.search(
        r"(\d+)\s*円?の?(\d+)\s*(?:%|パーセント)\s*(?:オフ|引き)?", clean)
    if m_disc_pct:
        val = int(m_disc_pct.group(1))
        pct = int(m_disc_pct.group(2))
        res = int(round(val * (1 - pct / 100.0)))
        return f"{res:,}円（{pct}%オフ）"

    m_disc_wari = re.search(r"(\d+)\s*円?の?([1-9])\s*割\s*(?:引き)?", clean)
    if m_disc_wari:
        val = int(m_disc_wari.group(1))
        wari = int(m_disc_wari.group(2))
        res = int(round(val * (1 - wari / 10.0)))
        return f"{res:,}円（{wari}割引）"

    # --- 4. 四則演算 ---
    calc_text = clean
    calc_text = re.sub(r"かける|×|\*", "*", calc_text)
    calc_text = re.sub(r"わる|÷|/", "/", calc_text)
    calc_text = re.sub(r"プラス|足す|\+", "+", calc_text)
    calc_text = re.sub(r"マイナス|引く|ー|-", "-", calc_text)

    m_op = re.search(r"(\d+(?:\.\d+)?)\s*([\+\-\*\/])\s*(\d+(?:\.\d+)?)",
                     calc_text)
    if m_op:
        n1 = float(m_op.group(1))
        op = m_op.group(2)
        n2 = float(m_op.group(3))
        if op == "+":
            ans = n1 + n2
        elif op == "-":
            ans = n1 - n2
        elif op == "*":
            ans = n1 * n2
        elif op == "/":
            ans = n1 / n2 if n2 != 0 else 0
        else:
            ans = 0
        if ans == int(ans):
            return f"{int(ans):,}"
        return f"{ans:,.2f}"

    return clean


def clean_ai_output(text: str) -> str:
    """LLM の応答から、マークダウン装飾、定型的な前置き、引用符を除去する。"""
    if not text:
        return ""
    t = text.strip()

    # 1. コードブロック (```...```) の除去
    m_block = re.match(r"^```(?:[a-zA-Z0-9_\-]+)?\r?\n([\s\S]*?)\r?\n```$", t)
    if m_block:
        t = m_block.group(1).strip()
    elif t.startswith("```") and t.endswith("```"):
        t = t.strip("`").strip()

    # 2. 先頭の前置き行（「はい、〜」「以下は〜」等）の除去
    lines = t.splitlines()
    if len(lines) > 1:
        first = lines[0].strip()
        intro_patterns = [
            r"^(?:承知いたしました|了解いたしました|かしこまりました)[。！!]*$",
            r"^(?:はい[、,]|はい。).*(?:作成|通り|変換|お作り|回答|結果|ご提示).*[：:。]?$",
            r"^以下(?:は|が)?(?:作成|変換|編集|提案)?(?:した)?(?:文章|テキスト|結果|回答|プロンプト|内容|返信|案)?(?:です|になります)?[：:。]?$",
            r"^(?:Here is|Here's) (?:the )?(?:translated|created|edited|rewritten)?.*[:：]?$",
            r"^(?:Sure|Certainly)[,!.]? (?:here is|here's)?.*[:：]?$",
        ]
        for pat in intro_patterns:
            if re.match(pat, first, re.IGNORECASE):
                t = "\n".join(lines[1:]).strip()
                break

    # 3. 外側の余計な引用符（"...", '...', 「...」, 『...』）のストリップ
    if len(t) >= 2:
        quotes = [('"', '"'), ("'", "'"), ("「", "」"), ("『", "』"), ("“", "”")]
        for open_q, close_q in quotes:
            if t.startswith(open_q) and t.endswith(close_q):
                inner = t[len(open_q):-len(close_q)].strip()
                if close_q not in inner or open_q not in inner:
                    t = inner
                    break

    return t

# ------------------------------------------------------------ クラウド AI 連携

API_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models"


class ApiRequiredError(RuntimeError):
    """API キーが必須のアクションで、API キーが未設定の場合の例外。"""
    pass


def detect_provider(provider: str, api_key: str, model: str) -> str:
    """プロバイダー名（gemini / claude / openrouter）を判定する。"""
    p = (provider or "").strip().lower()
    if p in ("gemini", "google"):
        return "gemini"
    if p in ("claude", "anthropic"):
        return "claude"
    if p in ("openrouter", "openai"):
        return "openrouter"

    k = (api_key or "").strip()
    m = (model or "").strip().lower()

    if k.startswith("sk-ant-") or "claude" in m:
        return "claude"
    if k.startswith("sk-or-") or "/" in m:
        return "openrouter"
    if k.startswith("AIzaSy") or "gemini" in m:
        return "gemini"

    return "gemini"


DEFAULT_GEMINI_MODEL: Final[str] = "gemini-3.8-flash"
_GEMINI_FALLBACK_MODELS: Final[tuple[str, ...]] = (
    "gemini-3.8-flash",
    "gemini-3.6-flash",
    "gemini-1.5-flash",
)


def call_gemini(prompt: str, *, api_key: str,
                model: str = DEFAULT_GEMINI_MODEL,
                timeout: float = 15.0) -> str:
    """Gemini API を使ってテキストを変換する。標準ライブラリのみ使用。

    指定モデルが 404（提供終了・非対応）の場合は、最新の推奨モデルへ
    自動でフォールバックして再試行する。
    """
    if not api_key:
        raise ValueError("Gemini API キーが設定されていません")

    models_to_try = [model]
    for fb in _GEMINI_FALLBACK_MODELS:
        if fb not in models_to_try:
            models_to_try.append(fb)

    last_exc: Exception | None = None
    for cur_model in models_to_try:
        url = f"{API_ENDPOINT}/{cur_model}:generateContent?key={api_key}"
        payload = {
            "contents": [{
                "parts": [{"text": prompt}]
            }],
            "generationConfig": {
                "temperature": 0.2,
                "maxOutputTokens": 1024,
            }
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8")
                parsed = json.loads(body)
                candidates = parsed.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    if parts:
                        return clean_ai_output(
                            str(parts[0].get("text", "")).strip()
                        )
            return ""
        except urllib.error.HTTPError as e:
            last_exc = e
            if e.code == 404:
                log.warning(
                    "Gemini モデル %s が 404 のため代替モデルを試行します",
                    cur_model
                )
                continue
            raise

    if last_exc:
        raise last_exc
    return ""


def call_gemini_multimodal(prompt: str, image_bytes: bytes, *,
                           api_key: str,
                           model: str = DEFAULT_GEMINI_MODEL,
                           timeout: float = 20.0) -> str:
    """Gemini API を使って画像とテキストを同時に送信・解析する。"""
    if not api_key:
        raise ValueError("Gemini API キーが設定されていません")
    if not image_bytes:
        return call_gemini(prompt, api_key=api_key, model=model,
                           timeout=timeout)

    models_to_try = [model]
    for fb in _GEMINI_FALLBACK_MODELS:
        if fb not in models_to_try:
            models_to_try.append(fb)

    b64_img = base64.b64encode(image_bytes).decode("ascii")
    payload = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {
                    "inline_data": {
                        "mime_type": "image/jpeg",
                        "data": b64_img,
                    }
                }
            ]
        }],
        "generationConfig": {
            "temperature": 0.2,
            "maxOutputTokens": 1024,
        }
    }
    data = json.dumps(payload).encode("utf-8")

    last_exc: Exception | None = None
    for cur_model in models_to_try:
        url = f"{API_ENDPOINT}/{cur_model}:generateContent?key={api_key}"
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = resp.read().decode("utf-8")
                parsed = json.loads(body)
                candidates = parsed.get("candidates", [])
                if candidates:
                    parts = candidates[0].get("content", {}).get("parts", [])
                    if parts:
                        return clean_ai_output(
                            str(parts[0].get("text", "")).strip()
                        )
            return ""
        except urllib.error.HTTPError as e:
            last_exc = e
            if e.code == 404:
                log.warning(
                    "Gemini マルチモーダル %s が 404 のためフォールバックします",
                    cur_model
                )
                continue
            raise

    if last_exc:
        raise last_exc
    return ""


def build_google_calendar_url(title: str, start_dt: str, end_dt: str = "",
                              details: str = "", location: str = "") -> str:
    """Google カレンダーの予定作成リンク（Web URL）を生成する。"""
    s = re.sub(r"[^\dTZ]", "", start_dt)
    e = re.sub(r"[^\dTZ]", "", end_dt) if end_dt else s
    dates = f"{s}/{e}" if s else ""
    base = "https://calendar.google.com/calendar/render?action=TEMPLATE"
    params = [f"text={urllib.parse.quote(title or '予定')}"]
    if dates:
        params.append(f"dates={dates}")
    if details:
        params.append(f"details={urllib.parse.quote(details)}")
    if location:
        params.append(f"location={urllib.parse.quote(location)}")
    return f"{base}&{'&'.join(params)}"


def process_screen_assistant(speech_text: str, image_bytes: bytes, *,
                             api_key: str,
                             provider: str = "auto",
                             model: str = DEFAULT_GEMINI_MODEL,
                             action_type: str = "auto",
                             is_offline: bool = False) -> tuple[str, str, str]:
    """画面キャプチャと音声指示をもとに AI で解析する（かこって検索・ジャービス機能）。

    戻り値: (action, text, url)
      action: "calendar" | "search" | "ocr" | "translate" | "answer"
      text: 表示・入力・コピー用テキスト
      url: カレンダー登録または Google 検索の URL
    """
    speech = speech_text.strip()
    is_ocr = (action_type == "ocr" or any(w in speech for w in (
        "文字", "テキスト", "OCR", "ocr", "書き起こし", "文字起こし",
        "読み取", "コピー", "抽出"
    )))
    is_translate = (action_type == "translate" or any(w in speech for w in (
        "翻訳", "ほんやく", "訳して", "英語にして", "日本語にして", "translate"
    )))
    is_calendar = (action_type == "calendar" or any(w in speech for w in (
        "カレンダー", "予定", "スケジュール", "アポ", "ミーティング",
        "日程", "入れて", "追加"
    )))
    is_search = (action_type == "search" or any(w in speech for w in (
        "検索", "調べて", "Google", "グーグル", "探して", "調査", "レンズ"
    )))

    # API キーがない場合の処理（Google検索や親切な案内）
    if is_offline or not api_key:
        if is_search:
            q = speech if speech and speech not in (
                "Googleで検索するためのキーワードを出力してください", "検索",
                "Googleで検索"
            ) else ""
            if q:
                search_url = f"https://www.google.com/search?q={urllib.parse.quote(q)}"
                return ("search", f"🔍 Google検索を開きます: {q}", search_url)
            return ("search", "🔍 Googleレンズを開きます", "https://lens.google.com/")
        if is_ocr:
            return (
                "ocr",
                "⚠️ 高精度な文字抽出（OCR）には Gemini などの無料 API キーが必要です。\n"
                "設定画面からキーを登録してください。\n"
                "（囲んだ画像はクリップボードにコピーされました）",
                ""
            )
        return (
            "answer",
            "✨ 画面AIアシスタント（かこって検索 / 画像解析）\n\n"
            "AI による高精度な文字抽出（OCR）・画像認識・翻訳・質問への回答には、"
            "無料の Google Gemini などの API キーが必要です。\n"
            "設定画面（右上の「⚙️ 設定」）からキーを登録すると、すべての機能が有効になります。\n\n"
            "※APIキーが未登録の場合でも、左下の「🔍 画像検索」ボタンから Google で直接検索できます。",
            ""
        )

    if is_ocr:
        prompt = (
            "あなたは画像から文字を書き起こす最高精度のOCRエンジンです。\n"
            "囲まれた画像内に含まれるすべての文字・テキストを、改行や表記、"
            "レイアウトを保ってそのまま正確に出力してください。\n\n"
            "【厳守事項】\n"
            "・前置き、挨拶、解説、「画像内のテキストは以下の通りです」等の"
            "不要な文言は一切含めないでください。\n"
            "・画像内の文字のみを純粋に出力してください。"
        )
        res = call_llm_multimodal(prompt, image_bytes, api_key=api_key,
                                  provider=provider, model=model).strip()
        return ("ocr", res, "")

    elif is_translate:
        prompt = (
            "あなたは優秀な多言語翻訳アシスタントです。\n"
            "囲まれた画像内の文章や単語を読み取り、自然で正確な日本語に翻訳してください。\n"
            "（もし画像内の文章がすでに日本語である場合は、自然な英語に翻訳してください）\n\n"
            "【厳守事項】\n"
            "・前置きや解説は省き、翻訳結果のテキストのみを出力してください。"
        )
        res = call_llm_multimodal(prompt, image_bytes, api_key=api_key,
                                  provider=provider, model=model).strip()
        return ("translate", res, "")

    elif is_calendar:
        prompt = (
            "あなたは優秀なパーソナルアシスタント（ジャービス）です。\n"
            "画面の画像（チャット、メール、案内など）と以下の音声指示から、"
            "登録すべき予定（イベント）の情報を抽出してください。\n"
            f"ユーザーの音声指示: {speech_text}\n\n"
            "必ず以下の純粋な JSON 形式のみを出力してください:\n"
            "{\n"
            '  "title": "予定の件名",\n'
            '  "start": "YYYYMMDDTHHMMSS",\n'
            '  "end": "YYYYMMDDTHHMMSS",\n'
            '  "details": "詳細メモや元メッセージの要約",\n'
            '  "location": "場所またはオンラインURL"\n'
            "}\n"
            "※年は現在の年（2026年など）を補完し、終了時刻が不明なら"
            "開始の1時間後としてください。"
        )
        res = call_llm_multimodal(prompt, image_bytes, api_key=api_key,
                                  provider=provider, model=model)
        try:
            m = re.search(r"\{[\s\S]*\}", res)
            if m:
                ev = json.loads(m.group(0))
                url = build_google_calendar_url(
                    title=str(ev.get("title", "予定")),
                    start_dt=str(ev.get("start", "")),
                    end_dt=str(ev.get("end", "")),
                    details=str(ev.get("details", "")),
                    location=str(ev.get("location", ""))
                )
                disp = (f"【カレンダー登録】{ev.get('title', '予定')} "
                        f"({ev.get('start', '')})")
                return ("calendar", disp, url)
        except Exception:
            log.exception("カレンダー JSON パースに失敗しました")
        return ("answer", res, "")

    elif is_search:
        prompt = (
            "あなたは Galaxy S25 のかこって検索アシスタントです。\n"
            "囲まれた画面の画像を見て、ユーザーが探している対象を特定し、"
            "Google で検索するための最も的確でシンプルな検索キーワード"
            "（1〜3単語程度）のみを出力してください。\n"
            f"ユーザーの指示: {speech_text}\n\n"
            "出力は検索キーワードのみとし、余計な説明・前置き・記号は省いてください。"
        )
        res = call_llm_multimodal(prompt, image_bytes, api_key=api_key,
                                  provider=provider,
                                  model=model).strip().strip('"').strip("'")
        query = res.splitlines()[0] if res else speech_text
        encoded = urllib.parse.quote(query)
        search_url = f"https://www.google.com/search?q={encoded}"
        disp = f"【Google検索】{query}"
        return ("search", disp, search_url)

    else:
        prompt = (
            "あなたは親切で極めて優秀なAIアシスタント（ジャービス）です。\n"
            "画面の画像を見て、ユーザーの指示に的確に回答してください。\n"
            f"ユーザーの指示: {speech or 'この画像について詳しく解説・説明してください'}\n\n"
            "・前置きや過剰な挨拶は省き、結論・要点を分かりやすく明瞭に"
            "回答してください。"
        )
        res = call_llm_multimodal(prompt, image_bytes, api_key=api_key,
                                  provider=provider, model=model)
        return ("answer", res, "")





def call_claude(prompt: str, *, api_key: str,
                model: str = "claude-3-5-haiku-20241022",
                timeout: float = 15.0) -> str:
    """Anthropic Claude API を使ってテキストを変換する。標準ライブラリのみ使用。"""
    if not api_key:
        raise ValueError("Anthropic API キーが設定されていません")

    url = "https://api.anthropic.com/v1/messages"
    actual_model = (model if "claude" in model.lower()
                    else "claude-3-5-haiku-20241022")
    payload = {
        "model": actual_model,
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": prompt}],
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
            "User-Agent": "koe-type/1.4.0",
        },
        method="POST"
    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
        parsed = json.loads(body)
        content = parsed.get("content", [])
        if content and isinstance(content, list):
            for block in content:
                if block.get("type") == "text":
                    return clean_ai_output(str(block.get("text", "")).strip())
    return ""


def call_openrouter(prompt: str, *, api_key: str,
                    model: str = "google/gemini-2.0-flash-001",
                    timeout: float = 15.0) -> str:
    """OpenRouter API（OpenAI 互換）を使ってテキストを変換する。標準ライブラリのみ使用。"""
    if not api_key:
        raise ValueError("OpenRouter API キーが設定されていません")

    url = "https://openrouter.ai/api/v1/chat/completions"
    actual_model = (model if ("/" in model or "gpt" in model or "claude" in model)
                    else "google/gemini-2.0-flash-001")
    payload = {
        "model": actual_model,
        "max_tokens": 1024,
        "messages": [{"role": "user", "content": prompt}],
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://koe-type.local",
            "X-Title": "koe-type",
            "User-Agent": "koe-type/1.4.0",
        },
        method="POST"
    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
        parsed = json.loads(body)
        choices = parsed.get("choices", [])
        if choices and isinstance(choices, list):
            msg = choices[0].get("message", {})
            return clean_ai_output(str(msg.get("content", "")).strip())
    return ""


def call_openrouter_multimodal(prompt: str, image_bytes: bytes, *,
                               api_key: str,
                               model: str = "google/gemini-2.0-flash-001",
                               timeout: float = 20.0) -> str:
    """OpenRouter API（OpenAI 互換）を使って画像とテキストを同時に送信・解析する。"""
    if not api_key:
        raise ValueError("OpenRouter API キーが設定されていません")
    if not image_bytes:
        return call_openrouter(prompt, api_key=api_key, model=model,
                               timeout=timeout)

    b64_img = base64.b64encode(image_bytes).decode("ascii")
    url = "https://openrouter.ai/api/v1/chat/completions"
    actual_model = (model if ("/" in model or "gpt" in model or "claude" in model)
                    else "google/gemini-2.0-flash-001")
    payload = {
        "model": actual_model,
        "max_tokens": 1024,
        "messages": [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": prompt},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{b64_img}"
                        }
                    }
                ]
            }
        ],
    }
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://koe-type.local",
            "X-Title": "koe-type",
            "User-Agent": "koe-type/1.4.0",
        },
        method="POST"
    )

    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read().decode("utf-8")
        parsed = json.loads(body)
        choices = parsed.get("choices", [])
        if choices and isinstance(choices, list):
            msg = choices[0].get("message", {})
            return clean_ai_output(str(msg.get("content", "")).strip())
    return ""


def call_llm(prompt: str, *, api_key: str,
             provider: str = "auto",
             model: str = "gemini-2.0-flash",
             timeout: float = 15.0) -> str:
    """設定されたプロバイダー（Gemini / Claude / OpenRouter）へリクエストを送る。"""
    target_prov = detect_provider(provider, api_key, model)
    if target_prov == "claude":
        res = call_claude(prompt, api_key=api_key, model=model,
                          timeout=timeout)
    elif target_prov == "openrouter":
        res = call_openrouter(prompt, api_key=api_key, model=model,
                              timeout=timeout)
    else:
        res = call_gemini(prompt, api_key=api_key, model=model, timeout=timeout)
    return clean_ai_output(res)


def call_llm_multimodal(prompt: str, image_bytes: bytes, *,
                        api_key: str,
                        provider: str = "auto",
                        model: str = "gemini-2.0-flash",
                        timeout: float = 20.0) -> str:
    """設定されたプロバイダーへ画像とテキストを送信して解析する。"""
    target_prov = detect_provider(provider, api_key, model)
    if target_prov == "openrouter":
        res = call_openrouter_multimodal(prompt, image_bytes, api_key=api_key,
                                         model=model, timeout=timeout)
    else:
        # Gemini
        res = call_gemini_multimodal(prompt, image_bytes, api_key=api_key,
                                     model=model, timeout=timeout)
    return clean_ai_output(res)


def test_api_connection(api_key: str, *,
                        provider: str = "auto",
                        model: str = "",
                        timeout: float = 10.0) -> dict[str, object]:
    """設定されたプロバイダーとモデルへの接続をテストする。標準ライブラリのみ使用。"""
    import time

    k = (api_key or "").strip()
    if not k:
        return {"ok": False, "error": "API キーが入力されていません"}

    target_prov = detect_provider(provider, k, model)
    test_prompt = "Say hello in 3 words or less."
    t0 = time.perf_counter()
    fallback_used = ""

    try:
        if target_prov == "claude":
            actual_model = model or "claude-3-5-haiku-20241022"
            res = call_claude(test_prompt, api_key=k, model=actual_model,
                              timeout=timeout)
        elif target_prov == "openrouter":
            actual_model = model or "google/gemini-2.0-flash-001"
            res = call_openrouter(test_prompt, api_key=k, model=actual_model,
                                  timeout=timeout)
        else:
            actual_model = model or DEFAULT_GEMINI_MODEL
            try:
                # まず指定モデル（またはデフォルト）で直接試行
                url = f"{API_ENDPOINT}/{actual_model}:generateContent?key={k}"
                payload = {
                    "contents": [{"parts": [{"text": test_prompt}]}],
                    "generationConfig": {"temperature": 0.2, "maxOutputTokens": 30}
                }
                data = json.dumps(payload).encode("utf-8")
                req = urllib.request.Request(
                    url,
                    data=data,
                    headers={"Content-Type": "application/json"},
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    parsed = json.loads(resp.read().decode("utf-8"))
                    cand = parsed.get("candidates", [])
                    p = cand[0].get("content", {}).get("parts", []) if cand else []
                    res = clean_ai_output(str(p[0].get("text", "")).strip()) if p else ""
            except urllib.error.HTTPError as e:
                if e.code == 404:
                    # 指定モデルが 404 の場合、フォールバックモデルで再試行
                    for fb in _GEMINI_FALLBACK_MODELS:
                        if fb == actual_model:
                            continue
                        try:
                            res = call_gemini(test_prompt, api_key=k,
                                              model=fb, timeout=timeout)
                            fallback_used = fb
                            break
                        except Exception:
                            continue
                    if not fallback_used:
                        raise
                else:
                    raise

        latency_ms = int((time.perf_counter() - t0) * 1000)
        ret: dict[str, object] = {
            "ok": True,
            "provider": target_prov,
            "model": fallback_used or actual_model,
            "latency_ms": latency_ms,
            "response": res,
        }
        if fallback_used:
            ret["warning"] = (
                f"モデル '{actual_model}' は提供終了または非対応（HTTP 404）のため、"
                f"自動的に最新の '{fallback_used}' で接続しました。"
            )
        return ret
    except urllib.error.HTTPError as e:
        status = e.code
        err_msg = f"HTTP {status}"
        if status == 401:
            err_msg = "認証エラー（APIキーが無効または期限切れです / HTTP 401）"
        elif status == 403:
            err_msg = "アクセス拒否（権限がないか、地域制限または残高不足です / HTTP 403）"
        elif status == 404:
            err_msg = (
                f"モデルが見つかりません（HTTP 404）。"
                f"指定モデル（{actual_model}）が提供終了または非対応の可能性があります。"
                f"Gemini 2.5 Flash など最新モデルを選択してください。"
            )
        elif status == 429:
            err_msg = "レート制限（利用上限または無料枠上限に達しました / HTTP 429）"
        else:
            try:
                body = e.read().decode("utf-8", errors="replace")
                err_msg = f"APIエラー（HTTP {status}）: {body[:140]}"
            except Exception:
                pass
        return {"ok": False, "error": err_msg, "status": status,
                "provider": target_prov}
    except urllib.error.URLError as e:
        reason = getattr(e, "reason", str(e))
        return {"ok": False,
                "error": f"通信エラー（ネットワークを確認してください）: {reason}",
                "provider": target_prov}
    except TimeoutError:
        return {"ok": False,
                "error": f"接続タイムアウト（{int(timeout)}秒以内に応答なし）",
                "provider": target_prov}
    except Exception as e:
        return {"ok": False, "error": f"エラー: {e}", "provider": target_prov}



# ------------------------------------------------------------ 指示文（プロンプト）

# 設定画面の一覧での ID と、昔からある動作名の対応。
# 「ビジネス丁寧語」は動作名が business、一覧の ID が professional。
_INSTRUCTION_ALIASES: Final[dict[str, str]] = {"business": "professional"}


def instruction_prompt(custom_instructions: list[dict] | None,
                       action: str) -> str:
    """利用者の一覧から、その動作の指示文を探す。なければ空文字。"""
    want = action.removeprefix("custom_instruction_").lower()
    want = _INSTRUCTION_ALIASES.get(want, want)
    for inst in custom_instructions or []:
        if (isinstance(inst, dict)
                and str(inst.get("id", "")).lower() == want):
            return str(inst.get("prompt") or "").strip()
    return ""


def fill_prompt(template: str, text: str, clipboard_text: str = "") -> str:
    """{text} や {clipboard} を置きかえる。{text} がなければ末尾に足す。"""
    template = template.strip()
    if "{clipboard}" in template:
        template = template.replace("{clipboard}", clipboard_text or "（なし）")
    if "{text}" in template:
        return template.replace("{text}", text)
    return f"{template}\n\n{text}"


# ------------------------------------------------------------ 統合変換エントリ


def transform_text(text: str, action: str, *,
                   audio_pcm: bytes = b"",
                   session=None,  # noqa: ANN001
                   api_key: str = "",
                   provider: str = "auto",
                   model: str = "gemini-2.0-flash",
                   custom_prompt: str = "",
                   custom_instructions: list[dict] | None = None,
                   is_offline: bool = False,
                   speaker_focus: str = "off",
                   clipboard_text: str = "") -> str:
    """テキストを指定されたアクションに応じて変換する。

    action:
      - "ai_auto_edit": AI自動編集（フィラー削除・言い直し反映・構造化）
      - "translate_en": 英語に翻訳
      - "prompt_creator": AIプロンプト作成（AIへの指示文）
      - "polite": 敬語（です・ます調）に変換
      - "business" / "professional": ビジネス敬語に変換
      - "summary": 要約（箇条書き）に変換
      - "task_list": タスク・箇条書き整理
      - "slack_report": Slack業務報告風に整理
      - "terminal_helper": ターミナルコマンド
      - "custom": カスタム指示で変換
      - 登録済みカスタム指示 ID
      - "none" / "": 何もしない
    """
    if not text or not action or action == "none":
        return text

    action = action.lower()
    clean_action = action.removeprefix("custom_instruction_")

    # 一覧で書きかえた指示文があればそれを使う
    user_tmpl = instruction_prompt(custom_instructions, clean_action)

    # カスタム指示一覧からプロンプトを探す
    matched_prompt = ""
    if custom_instructions:
        for inst in custom_instructions:
            if str(inst.get("id", "")).lower() == clean_action:
                matched_prompt = inst.get("prompt", "")
                break
    if not matched_prompt and action.startswith("custom_instruction_"):
        from . import schema
        for inst in getattr(schema, "_DEFAULT_CUSTOM_INSTRUCTIONS", []):
            if str(inst.get("id", "")).lower() == clean_action:
                matched_prompt = inst.get("prompt", "")
                break

    target_prompt = matched_prompt or user_tmpl or custom_prompt

    # ユーザー独自のカスタム指示、または AI 必須アクションの判定
    builtins = (
        "translate_en", "polite", "professional", "business",
        "summary", "task_list", "slack_report", "terminal_helper",
        "ai_auto_edit", "chaos_mode", "buzzword_mode",
        "reply_generator", "meeting_minutes", "proofread",
        "standardize", "brainstorm",
    )
    is_api_required = (
        clean_action in ("prompt_creator", "instruct")
        or action == "custom"
        or (action.startswith("custom_instruction_")
            and clean_action not in builtins)
    )

    # --- 1. オンライン AI (Gemini / Claude / OpenRouter) が使える場合 ---
    if api_key and not is_offline:
        prompt = ""
        if target_prompt:
            prompt = fill_prompt(target_prompt, text, clipboard_text=clipboard_text)
        elif clean_action == "translate_en":
            prompt = (
                "あなたはプロフェッショナルなバイリンガル翻訳エキスパートです。\n"
                "以下の音声を、文脈に最も適した極めて自然で流暢な英語に翻訳してください。\n"
                "・直訳を避け、ネイティブが実際に使う自然なイディオムや表現を用いてください。\n"
                "・ビジネス・日常会話の適切なニュアンスと敬意を維持してください。\n"
                "・前置き、挨拶、解説、引用符などは一切含めず、翻訳後の英文のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "instruct":
            prompt = (
                "あなたはユーザー専属の最高峰文章作成エキスパートです。\n"
                "ユーザーが話した以下の音声を【文章作成の要望・指示】として解釈し、"
                "ユーザーが求めている意図に100%合致した完成文章・テキストを作成してください。\n"
                "・「〜〜の文章を作って」「〜〜について書いて」「〜〜宛のメールにして」"
                "「〜〜風にして」「〜〜を要約して」など、ユーザーが発言した要望・条件・トーン・文体に"
                "完璧に従って文章を作成してください。\n"
                "・指示と対象のテキストが混ざっている場合（例：「これをもっと柔らかく断る文章にして、明日は都合が悪いです」）は、"
                "指示を反映した完成形のみを出力してください。\n"
                "・挨拶、前置き、「以下が作成した文章です」などの返答、解説、思考プロセスは絶対に含めず、"
                "入力欄に直接入れるべき完成した文章のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "prompt_creator":
            prompt = (
                "あなたは世界最高峰のプロンプトエンジニアです。\n"
                "ユーザーが話した以下の要望・アイデア・指示内容をもとに、"
                "ChatGPTやClaudeなどの高性能AIが最高の回答を生成できるように設計された、"
                "洗練された高品質なプロンプトを作成してください。\n"
                "・目的・前提・具体的要件・制約条件・期待する出力フォーマットを論理的に構造化してください。\n"
                "・解説や前置き、「プロンプトを作成しました」等の発言は一切含めず、"
                "入力欄に貼り付けてそのままAIに送信できるプロンプト本文のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "polite":
            prompt = (
                "あなたは文章推敲のエキスパートです。\n"
                "以下の話し言葉・くだけた表現の日本語音声を、"
                "親しみやすく好印象な自然な「です・ます調（丁寧語）」に整えてください。\n"
                "・堅苦しすぎず、チャットや連絡で心地よい自然な表現にしてください。\n"
                "・解説や前置き、引用符は一切含めず、整えたテキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action in ("business", "professional"):
            prompt = (
                "あなたはエグゼクティブビジネスコミュニケーションの専門家です。\n"
                "以下の日本語音声を、社内外のビジネスチャットやメールでそのまま使える、"
                "洗練された信頼感のあるビジネス敬語の文章に書き直してください。\n"
                "・適切な敬語体系（尊敬語・謙譲語・丁寧語）を正しく使い分け、二重敬語を避けてください。\n"
                "・依頼には適切なクッション言葉を添え、角の立たない論理的な文章にしてください。\n"
                "・前置きや解説は含めず、結果のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "summary":
            prompt = (
                "あなたは一流のビジネスアナリストです。\n"
                "以下の日本語音声の要点を抽出し、一目で理解できる簡潔で分かりやすい箇条書きでまとめてください。\n"
                "・不要な重複やつなぎ言葉は排除し、情報密度を高めてください。\n"
                "・解説や前置きは含めず、箇条書きのテキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "task_list":
            prompt = (
                "以下の音声から重要ポイントややるべきタスク・TODOを整理し、"
                "実行順序がわかる見やすい番号付きリストまたは箇条書き形式に構造化してください。\n"
                "・主語とアクションを明確にしてください。\n"
                "・前置きや解説は含めず、結果のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "slack_report":
            prompt = (
                "以下の音声を、SlackやTeams等の業務チャットでそのまま送れる"
                "簡潔で整理された報告文（【進捗・共有事項】【詳細】【ネクストアクション】の見出し・箇条書き）"
                "に整形してください。解説や前置きは含めず、本文のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "terminal_helper":
            prompt = (
                "以下の指示を実行可能な正確で安全なシェル/ターミナルコマンド"
                "（PowerShellまたはBash/Linux）に変換してください。\n"
                "・マークダウンのコードブロックや解説は含めず、コマンド文字列のみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "ai_auto_edit":
            prompt = (
                "以下の音声を自然で読みやすい文章に自動編集してください。\n"
                "・「えーと」「あの」「まあ」などのフィラーを削除する\n"
                "・言い直しや自己訂正を検出し、最終的な意図を反映する\n"
                "・タスク一覧や箇条書きの意図がある場合はリスト化・構造化して読みやすくフォーマットする\n"
                "・解説や前置き、引用符などは一切含めず、編集後のテキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "reply_generator":
            prompt = (
                "あなたはビジネスおよびチャットコミュニケーションの達人です。\n"
                "相手からのメッセージに対して、ユーザーの意図を汲み取った失礼のない完璧な返信文を作成してください。\n"
                f"【相手からのメッセージ】\n{clipboard_text or '（相手メッセージなし）'}\n\n"
                f"【ユーザーからの返信要望・要件】\n{text}\n\n"
                "・相手への敬意と文脈（ビジネスメール、Slack/Teams、カジュアルチャット等）に合わせた適切なトーンで作成してください。\n"
                "・挨拶や前置き、解説、「以下が返信文です」等は絶対に含めず、相手にそのまま送信できる返信本文のみを出力してください:"
            )
        elif clean_action == "meeting_minutes":
            prompt = (
                "あなたは一流のプロジェクトマネージャーです。\n"
                "以下の音声（会議や打ち合わせの発言・要件）を、誰が見ても一目で状況が把握できる構造化された議事録にまとめてください。\n"
                "・【決定事項】\n"
                "・【検討事項・保留】\n"
                "・【ネクストアクション（タスク・担当・期限）】\n"
                "・解説や前置きは含めず、構造化された議事録テキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "proofread":
            prompt = (
                "あなたは最高峰の文章校正・エディターです。\n"
                "以下の音声書き起こしテキストを、意味や主張を変えずに、最も美しく自然で読みやすい日本語に推敲・校正してください。\n"
                "・誤字脱字、てにをは（助詞）の誤り、主語と述語のねじれを修正する。\n"
                "・同じ語尾の連続（〜です。〜です。）や冗長な重複表現を避けてスムーズにする。\n"
                "・解説や前置き、引用符は一切含めず、推敲後のテキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "standardize":
            prompt = (
                "あなたは公用文・ビジネス文書の校閲官です。\n"
                "以下の音声に含まれる方言、俗語、スラング、砕けた口語表現を、"
                "公的な文書や社内報告で通じる端正で格調高い標準語・共通語の文体に書き換えてください。\n"
                "・前置きや解説は含めず、整えたテキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "brainstorm":
            prompt = (
                "あなたは新規事業・企画立案のエキスパートです。\n"
                "ユーザーが話した以下のアイデアの断片やメモから、実現可能性の高いロジカルな企画骨子に構造化・展開してください。\n"
                "・【コアコンセプト】（一言で表す価値）\n"
                "・【背景とターゲット課題】\n"
                "・【具体的な施策・アイデアの骨子】\n"
                "・【期待される効果・ベネフィット】\n"
                "・前置きや解説は含めず、企画骨子のテキストのみを出力してください:\n\n"
                f"{text}"
            )
        elif clean_action == "smart_calc":
            prompt = (
                "あなたは優秀な計算・日付変換アシスタントです。\n"
                "ユーザーが話した以下の内容から、四則演算、税込・税抜計算、"
                "割引計算、単位換算、または日付（今日、明日、来週の曜日など）を"
                "正確に計算・特定し、結果の数値・テキストのみを出力してください。\n"
                "・前置き、挨拶、解説は絶対に含めず、結果のみを出力してください:\n\n"
                f"{text}"
            )

        if prompt:
            if speaker_focus != "off":
                prompt += (
                    "\n\n【話者分離と第三者発話の除去】\n"
                    "周囲の人物の雑談、通りがかりの人の声、遠くの会話、"
                    "主話者（PC操作者）とは無関係な相づちや割り込み発話が"
                    "混入している場合は、それらを完全に除去し、"
                    "主話者本人が意図した発言内容のみを抽出・整形してください。"
                )
            try:
                res = call_llm(prompt, api_key=api_key, provider=provider,
                               model=model)
                if res:
                    return res
            except Exception as exc:
                log.warning("クラウド AI 変換 (%s / %s) に失敗したためローカルへ: %s",
                            provider, clean_action, exc)

    # --- 2. オフライン（または AI 失敗時）のローカル専用処理 ---
    # カスタム指示や AI 必須指示は、API なしでは意図と異なる入力になるため拒否する
    if is_api_required:
        raise ApiRequiredError(
            f"変換 '{clean_action}' は AI 専用のため API キーが必要です"
        )

    lowered_act = clean_action.lower()
    lowered_prompt = target_prompt.lower()

    # (A) 英語翻訳：Whisper 音声翻訳（最優先）→ オフライン対訳辞書
    if (lowered_act == "translate_en"
            or any(w in lowered_prompt
                   for w in ("英", "english", "translate", "翻訳"))):
        if session is not None and audio_pcm:
            try:
                from .resident import to_float
                samples = to_float(audio_pcm)
                res = session.run(samples, task="translate", language="ja")
                t = (res.text or "").strip()
                if t:
                    return t
            except Exception as exc:
                log.debug("Whisper 音声翻訳は使用できませんでした: %s", exc)
        return to_english_offline(text)

    # (B) 敬語変換（です・ます調）
    if lowered_act in ("polite", "丁寧語", "敬語"):
        return to_polite(text)

    # (C) ビジネス敬語
    if lowered_act in ("business", "professional", "ビジネス"):
        return to_business(text)

    # (D) ターミナルコマンド
    if (lowered_act == "terminal_helper"
            or any(w in lowered_prompt
                   for w in ("ターミナル", "コマンド", "terminal",
                             "cli", "bash", "powershell"))):
        return to_terminal_helper_offline(text)

    # (E) タスク・箇条書き整理
    if (lowered_act == "task_list"
            or any(w in lowered_prompt
                   for w in ("タスク", "箇条書き", "リスト",
                             "bullet", "todo"))):
        return structure_speech_lists(remove_advanced_fillers(text))

    # (F) 要約
    if (lowered_act == "summary"
            or any(w in lowered_prompt for w in ("要約", "まとめ"))):
        return to_summary(text)

    # (G) Slack 業務報告
    if (lowered_act == "slack_report"
            or any(w in lowered_prompt for w in ("slack", "業務", "報告"))):
        return to_slack_report(text)

    # (H) カオスモード
    if (lowered_act == "chaos_mode"
            or any(w in lowered_prompt for w in ("カオス", "ミーム", "chaos"))):
        return to_chaos_mode_offline(text)

    # (I) バズワードモード
    if (lowered_act == "buzzword_mode"
            or any(w in lowered_prompt
                   for w in ("バズワード", "buzzword", "カタカナ語"))):
        return to_buzzword_mode_offline(text)

    # (J) プロンプトキーワードからの意図推測（敬語・ビジネス）
    if any(w in lowered_prompt for w in ("ビジネス", "プロフェッショナル")):
        return to_business(text)
    if any(w in lowered_prompt for w in ("敬語", "丁寧", "です", "ます")):
        return to_polite(text)

    # (K) AI 自動編集（言い直し・フィラー除去）
    if lowered_act == "ai_auto_edit":
        return to_ai_auto_edit_offline(text)
    # (L) 返信文作成
    if (lowered_act == "reply_generator"
            or any(w in lowered_prompt for w in ("返信", "返事", "reply"))):
        return to_reply_generator_offline(text, clipboard_text)

    # (M) 議事録・ミーティング要約
    if (lowered_act == "meeting_minutes"
            or any(w in lowered_prompt for w in ("議事録", "打ち合わせ", "meeting", "minutes"))):
        return to_meeting_minutes_offline(text)

    # (N) 文章推敲・校正
    if (lowered_act == "proofread"
            or any(w in lowered_prompt for w in ("推敲", "校正", "誤字", "proofread"))):
        return to_proofread_offline(text)

    # (O) 標準語・公用文化
    if (lowered_act == "standardize"
            or any(w in lowered_prompt for w in ("標準語", "方言", "スラング", "standardize"))):
        return to_standardize_offline(text)

    # (P) アイデア・ブレスト企画化
    if (lowered_act == "brainstorm"
            or any(w in lowered_prompt for w in ("企画", "ブレスト", "アイデア", "brainstorm"))):
        return to_brainstorm_offline(text)

    # (Q) スマート計算・日付・便利ツール
    if (lowered_act == "smart_calc"
            or any(w in lowered_prompt
                   for w in ("計算", "税込", "税抜", "割引", "日付",
                             "smart_calc"))):
        return to_smart_calc_offline(text)

    return text
