"""不具合を知らせるための「診断情報」をまとめる。

設定画面の「診断情報をコピー」で使う。GitHub の不具合報告の
ひな形に、そのまま貼れる形で返す。

## 入れないもの（いちばん大事）

- **文字起こしの中身**（話した内容そのもの）
- **ユーザー名**（`C:\\Users\\たろう` → `C:\\Users\\<user>`）
- **パスの詳しい中身**（`<app>` `<home>` に置き換える）
- 辞書に登録した言葉、履歴、録音

「何が起きたか」を伝えるのに要らないものは、全部落とす。
落としたことは出力にも書いてあるので、貼る人が確かめられる。
"""

from __future__ import annotations

import json
import os
import platform
import re
import sys
from pathlib import Path

from .util import HOME, LOG_DIR, ROOT, VERSION

# ログから落とす行（話した中身が入っているもの）
SECRET_LINES = (
    "入力しました", "話しながら確定", "認識 ", "貼らずにコピーしました",
    "残りをクリップボードに入れました", "空だったので聞き直したら",
    "区間を確定", "音声コマンド", "辞書",
)

# 設定のうち、人が特定できそうなもの。API キーは鍵そのもの。
# 文章変換の指示文には、利用者が自分で書いた文が入る。
SECRET_KEYS = ("microphone", "voice_command_extra", "filler_words",
               "excluded_apps", "ai_api_key", "ai_custom_instructions",
               "custom_action_prompt", "ai_auto_edit_prompt")


def _mask(text: str) -> str:
    """パスとユーザー名を伏せる。"""
    user = os.environ.get("USERNAME", "")
    out = text
    out = out.replace(str(ROOT), "<app>")
    out = out.replace(str(HOME), "<home>")
    if user:
        out = re.sub(re.escape(user), "<user>", out, flags=re.IGNORECASE)
    out = re.sub(r"[A-Za-z]:\\\\Users\\\\[^\\\\\s\"']+", r"C:\\Users\\<user>",
                 out)
    out = re.sub(r"[A-Za-z]:\\Users\\[^\\\s\"']+", r"C:\\Users\\<user>", out)
    return out


def _log_tail(lines: int = 120) -> str:
    """ログの終わりのほう。**話した中身の行は落とす。**"""
    path = LOG_DIR / "koe-type.log"
    if not path.is_file():
        return "（ログがありません）"
    try:
        text = path.read_text("utf-8", "replace")
    except OSError as exc:
        return f"（ログを読めません: {exc}）"
    kept = []
    dropped = 0
    for line in text.splitlines():
        if any(word in line for word in SECRET_LINES):
            dropped += 1
            continue
        kept.append(line)
    tail = kept[-lines:]
    head = (f"（話した内容が入っている行 {dropped} 本は外しました）\n"
            if dropped else "")
    return head + _mask("\n".join(tail))


def _settings(cfg) -> str:  # noqa: ANN001
    """設定。人が特定できそうな項目は外す。"""
    try:
        values = dict(cfg.as_dict())
    except Exception:  # noqa: BLE001
        return "（設定を読めません）"
    for key in SECRET_KEYS:
        if key in values:
            values[key] = "<外しました>"
    return _mask(json.dumps(values, ensure_ascii=False, indent=1,
                            sort_keys=True))


def _machine() -> str:
    from . import hardware  # noqa: PLC0415
    try:
        p = hardware.profile(bench=False)
    except Exception as exc:  # noqa: BLE001
        return f"（調べられません: {exc}）"
    return "\n".join([
        f"OS        : {p.windows}",
        f"CPU       : {p.cpu_name}（{p.cpu_cores} 個 / "
        f"AVX2 {'あり' if p.avx2 else 'なし'}）",
        f"メモリ    : {p.memory_gb:.1f} GB",
        f"空き容量  : {p.free_gb:.1f} GB",
        f"GPU       : {p.gpu_name or 'なし'}"
        f"（Vulkan {'使える' if p.vulkan else '使えない'}）",
        f"Python    : {p.python}（{platform.architecture()[0]}）",
        f"koe-type  : {VERSION}",
        f"同梱 Python: {'はい' if (ROOT / 'runtime').is_dir() else 'いいえ'}",
    ])


def _health() -> str:
    """重かったときの記録（metrics.jsonl）の終わり。

    ★時刻を読める形にして、何分前の記録かも添える。Unix 時刻のまま
    だと、何時間も前の記録を「コピーした瞬間に 1.2GB に跳ねた」と
    読み違えた（2026-10-05。実際は朝にモデルを替えたときの記録）。
    """
    import json  # noqa: PLC0415
    import time  # noqa: PLC0415
    path = LOG_DIR / "metrics.jsonl"
    if not path.is_file():
        return "（記録がありません）"
    try:
        rows = path.read_text("utf-8", "replace").splitlines()[-6:]
    except OSError:
        return "（記録を読めません）"
    out = []
    now = time.time()
    for row in rows:
        try:
            data = json.loads(row)
            stamp = float(data.pop("t"))
        except (ValueError, KeyError, TypeError, AttributeError):
            out.append(row)
            continue
        when = time.strftime("%m-%d %H:%M:%S", time.localtime(stamp))
        ago = max(0, int((now - stamp) / 60))
        body = " ".join(f"{k}={v}" for k, v in data.items())
        out.append(f"{when}（{ago} 分前） {body}")
    return _mask("\n".join(out))


def _selfcheck() -> str:
    from . import selfcheck  # noqa: PLC0415
    try:
        results = selfcheck.run_all()
    except Exception as exc:  # noqa: BLE001
        return f"（動作チェックを走らせられません: {exc}）"
    lines = []
    for r in results:
        mark = {"ok": "OK  ", "warn": "注意", "bad": "NG  ",
                "info": "参考"}.get(r.status, "?   ")
        lines.append(f"{mark} {r.title_ja}: {_mask(r.detail_ja)}")
    return "\n".join(lines)


TEMPLATE = """<!-- koe-type の診断情報です。そのまま貼れます。
     話した内容・ユーザー名・パスは外してあります。 -->

## 何が起きましたか

<!-- ここに書いてください -->

## どうすると起きますか

1.
2.
3.

## この PC

```
{machine}
```

## 動作チェック

```
{selfcheck}
```

## 設定

<details><summary>設定（個人に関わる項目は外してあります）</summary>

```json
{settings}
```

</details>

## ログ（終わりの {lines} 行）

<details><summary>ログ</summary>

```
{log}
```

</details>

## 直前の様子

```
{health}
```
"""


def report(cfg, *, lines: int = 120) -> str:  # noqa: ANN001
    """貼り付けられる形の診断情報を作って返す。"""
    return TEMPLATE.format(
        machine=_machine(),
        selfcheck=_selfcheck(),
        settings=_settings(cfg),
        log=_log_tail(lines),
        health=_health(),
        lines=lines,
    )


def contains_secret(text: str) -> list:
    """念のための自己点検。見つけてはいけないものが残っていないか。"""
    bad = []
    user = os.environ.get("USERNAME", "")
    if user and len(user) > 2 and user.lower() in text.lower():
        bad.append("ユーザー名")
    if str(ROOT) in text:
        bad.append("アプリのパス")
    if str(HOME) in text:
        bad.append("設定のパス")
    for word in ("入力しました:", "話しながら確定"):
        if word in text:
            bad.append(f"話した内容（{word}）")
    return bad


if __name__ == "__main__":        # python -m app.diagnostics
    sys.path.insert(0, str(ROOT))
    from .configstore import Config
    text = report(Config())
    print(text)
    leaks = contains_secret(text)
    print("\n--- 自己点検 ---")
    print("問題なし" if not leaks else f"残っています: {leaks}")
