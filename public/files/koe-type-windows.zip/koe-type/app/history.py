"""文字起こし履歴。このPCの中だけに保存する（sqlite3 は標準ライブラリ）。"""

from __future__ import annotations

import logging
import sqlite3
import threading
import time
from pathlib import Path

from .util import DATA_DIR

log = logging.getLogger(__name__)

DB_PATH = DATA_DIR / "history.db"
AUDIO_DIR = DATA_DIR / "audio"


class History:
    def __init__(self, path: Path = DB_PATH) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._conn: sqlite3.Connection | None = None
        self._open()

    def _open(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self.path), check_same_thread=False)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS entries (
                    id      INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts      REAL NOT NULL,
                    text    TEXT NOT NULL,
                    model   TEXT,
                    seconds REAL,
                    audio   TEXT
                )""")
            # 古い版のデータベースにも列を足す（中身は消さない）
            have = {row[1] for row in conn.execute("PRAGMA table_info(entries)")}
            for column, decl in (("cancelled", "INTEGER DEFAULT 0"),
                                 ("raw_text", "TEXT DEFAULT ''"),
                                 ("session_id", "INTEGER DEFAULT 0")):
                if column not in have:
                    log.info("履歴に列 %s を足します", column)
                    conn.execute(f"ALTER TABLE entries ADD COLUMN "
                                 f"{column} {decl}")
            conn.commit()
            self._conn = conn
        except Exception:
            log.exception("履歴データベースを開けませんでした")
            self._conn = None

    # ------------------------------------------------------------------

    def add(self, text: str, *, raw_text: str = "", model: str = "",
            seconds: float = 0.0, audio: Path | None = None,
            limit: int = 200, cancelled: bool = False,
            session_id: int = 0) -> int | None:
        """1 件足す。cancelled は「中止した録音」の印。

        raw_text は整形（辞書・句読点・フィラー除去）前の生テキスト。
        前後比較（差分表示）のために保存する。
        追加したレコードの ID を返す。
        """
        if limit <= 0 or not text or self._conn is None:
            return None
        with self._lock:
            try:
                cur = self._conn.execute(
                    "INSERT INTO entries "
                    "(ts, text, raw_text, model, seconds, audio, cancelled, session_id) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (time.time(), text, raw_text or text, model, seconds,
                     str(audio) if audio else None, int(cancelled), session_id))
                row_id = cur.lastrowid
                self._conn.commit()
                self._trim(limit)
                return row_id
            except Exception:
                log.exception("履歴を保存できませんでした")
                return None

    def append(self, row_id: int, text: str, *, raw_text: str = "",
               seconds: float = 0.0, pcm: bytes | None = None,
               sep: str = " ") -> bool:
        """既存の履歴行にテキストを追記・連結する（同一セッションまとめ用）。"""
        if self._conn is None or not text or row_id <= 0:
            return False
        with self._lock:
            try:
                row = self._conn.execute(
                    "SELECT text, raw_text, seconds, audio FROM entries WHERE id = ?",
                    (row_id,)
                ).fetchone()
                if not row:
                    return False
                old_text, old_raw, old_sec, old_audio = row
                old_text = old_text or ""
                old_raw = old_raw or old_text
                old_sec = float(old_sec or 0.0)

                joined_text = _join_texts(old_text, text, sep=sep)
                joined_raw = _join_texts(old_raw, raw_text or text, sep=sep)

                if pcm and old_audio:
                    _append_wav(Path(old_audio), pcm)

                self._conn.execute(
                    "UPDATE entries SET text = ?, raw_text = ?, seconds = ?, ts = ? "
                    "WHERE id = ?",
                    (joined_text, joined_raw, old_sec + seconds, time.time(), row_id)
                )
                self._conn.commit()
                return True
            except Exception:
                log.exception("履歴の追記・結合で例外")
                return False

    def merge(self, ids: list[int], sep: str = " ") -> int | None:
        """指定した複数の履歴行を時系列順に1行に合体する。"""
        if self._conn is None or len(ids) < 2:
            return None
        with self._lock:
            try:
                marks = ",".join("?" * len(ids))
                rows = self._conn.execute(
                    f"SELECT id, ts, text, raw_text, seconds, audio FROM entries "
                    f"WHERE id IN ({marks}) ORDER BY ts ASC, id ASC",
                    ids
                ).fetchall()
                if len(rows) < 2:
                    return None

                base_id = rows[0][0]
                merged_text = rows[0][2]
                merged_raw = rows[0][3] or merged_text
                total_sec = float(rows[0][4] or 0.0)
                other_ids = [r[0] for r in rows[1:]]

                for r in rows[1:]:
                    merged_text = _join_texts(merged_text, r[2], sep=sep)
                    merged_raw = _join_texts(merged_raw, r[3] or r[2], sep=sep)
                    total_sec += float(r[4] or 0.0)
                    if r[5]:
                        _unlink(r[5])

                self._conn.execute(
                    "UPDATE entries SET text = ?, raw_text = ?, seconds = ? WHERE id = ?",
                    (merged_text, merged_raw, total_sec, base_id)
                )
                other_marks = ",".join("?" * len(other_ids))
                self._conn.execute(
                    f"DELETE FROM entries WHERE id IN ({other_marks})",
                    other_ids
                )
                self._conn.commit()
                return base_id
            except Exception:
                log.exception("履歴の結合で例外")
                return None

    def purge_audio(self, days: int) -> int:
        """古い録音だけを消す。文字の記録は残す。

        録音は、聞き間違いの原因を調べるのに役立つが、そのぶん
        利用者の声が PC に残る。期限を決めて自動で消す。
        """
        if days <= 0 or self._conn is None:
            return 0
        cutoff = time.time() - days * 86400
        removed = 0
        with self._lock:
            try:
                rows = self._conn.execute(
                    "SELECT id, audio FROM entries "
                    "WHERE audio IS NOT NULL AND audio != '' AND ts < ?",
                    (cutoff,)).fetchall()
                for row_id, audio in rows:
                    _unlink(audio)
                    self._conn.execute(
                        "UPDATE entries SET audio = NULL WHERE id = ?",
                        (row_id,))
                    removed += 1
                if rows:
                    self._conn.commit()
            except Exception:
                log.exception("古い録音を消せませんでした")
        if removed:
            log.info("%d 日より古い録音 %d 件を消しました", days, removed)
        return removed

    def _trim(self, limit: int) -> None:
        assert self._conn is not None
        rows = self._conn.execute(
            "SELECT id, audio FROM entries ORDER BY id DESC LIMIT -1 OFFSET ?",
            (limit,)).fetchall()
        for row_id, audio in rows:
            _unlink(audio)
            self._conn.execute("DELETE FROM entries WHERE id = ?", (row_id,))
        if rows:
            self._conn.commit()

    def recent(self, limit: int = 500) -> list[dict]:
        """新しい順に取り出す。"""
        if self._conn is None:
            return []
        cols = ("id", "ts", "text", "raw_text", "model", "audio", "seconds",
                "cancelled")
        with self._lock:
            try:
                rows = self._conn.execute(
                    "SELECT id, ts, text, COALESCE(raw_text, text), "
                    "COALESCE(model,''), COALESCE(audio,''), "
                    "COALESCE(seconds,0), COALESCE(cancelled,0) "
                    "FROM entries ORDER BY id DESC LIMIT ?", (limit,))
                return [dict(zip(cols, r)) for r in rows]
            except Exception:
                log.exception("履歴を読めませんでした")
                return []

    def audio_path(self, row_id: int) -> Path | None:
        """その記録に残した録音の場所。無ければ None。"""
        if self._conn is None:
            return None
        with self._lock:
            try:
                row = self._conn.execute(
                    "SELECT audio FROM entries WHERE id = ?",
                    (int(row_id),)).fetchone()
            except Exception:
                log.exception("履歴を読めませんでした")
                return None
        if not row or not row[0]:
            return None
        return Path(row[0])

    def delete(self, ids: list[int]) -> None:
        if self._conn is None or not ids:
            return
        with self._lock:
            try:
                marks = ",".join("?" * len(ids))
                for (audio,) in self._conn.execute(
                        f"SELECT audio FROM entries WHERE id IN ({marks})", ids):
                    _unlink(audio)
                self._conn.execute(
                    f"DELETE FROM entries WHERE id IN ({marks})", ids)
                self._conn.commit()
            except Exception:
                log.exception("履歴を削除できませんでした")

    def clear(self) -> None:
        if self._conn is None:
            return
        with self._lock:
            try:
                for (audio,) in self._conn.execute(
                        "SELECT audio FROM entries WHERE audio IS NOT NULL"):
                    _unlink(audio)
                self._conn.execute("DELETE FROM entries")
                self._conn.commit()
            except Exception:
                log.exception("履歴を空にできませんでした")

    def count(self) -> int:
        if self._conn is None:
            return 0
        with self._lock:
            try:
                return int(self._conn.execute(
                    "SELECT COUNT(*) FROM entries").fetchone()[0])
            except Exception:
                return 0

    def close(self) -> None:
        """データベース接続を閉じる。"""
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except Exception:
                    pass
                self._conn = None


def _unlink(audio: str | None) -> None:
    if not audio:
        return
    try:
        Path(audio).unlink(missing_ok=True)
    except OSError:
        pass


def store_audio(pcm: bytes, rate: int = 16000) -> Path | None:
    """履歴用に音声を残す。失敗しても処理は続ける。"""
    import wave
    try:
        AUDIO_DIR.mkdir(parents=True, exist_ok=True)
        path = AUDIO_DIR / f"{int(time.time() * 1000)}.wav"
        with wave.open(str(path), "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(rate)
            w.writeframes(pcm)
        return path
    except Exception:
        log.exception("履歴用の音声を保存できませんでした")
        return None


def _join_texts(a: str, b: str, sep: str = " ") -> str:
    """前後のテキストを自然に結合する。"""
    if not a:
        return b
    if not b:
        return a
    if a[-1] in "、。！？!?…\n":
        return a + b
    if a[-1].isascii() and a[-1].isalnum() and b[0].isascii():
        return a + " " + b
    if sep:
        return a + sep + b
    return a + b


def _append_wav(path: Path, pcm: bytes) -> None:
    """既存のWAVファイルにPCMデータを追記する。"""
    import wave
    try:
        if not path.is_file() or not pcm:
            return
        with wave.open(str(path), "rb") as r:
            params = r.getparams()
            frames = r.readframes(r.getnframes())
        with wave.open(str(path), "wb") as w:
            w.setparams(params)
            w.writeframes(frames + pcm)
    except Exception:
        log.debug("音声ファイルの追記に失敗しました: %s", path, exc_info=True)

