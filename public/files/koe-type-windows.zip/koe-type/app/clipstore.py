"""クリップボード履歴と、グループ（よく使う言葉）の保存。

このPCの中だけに保存する（sqlite3 は標準ライブラリ）。
画像は data/clips/ に PNG で置き、データベースには名前だけを持つ。

  ・group_id 0 が「履歴」。1 以上が利用者のグループ
  ・パスワードなど「秘密」にした項目は、Windows の DPAPI（crypt32）で
    包んでから保存する。同じ Windows のユーザーでしか元に戻せない。
    **包めなかったときは保存しない**（平文で残すよりまし）

一覧に出す・探すための文字は、本文の頭 2000 文字（snippet）だけを読む。
1MB の文字をコピーした人がいても、開くたびに全部を読まないため。
"""

from __future__ import annotations

import ctypes
import json
import logging
import sqlite3
import threading
import time
from ctypes import wintypes
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .util import DATA_DIR

log = logging.getLogger(__name__)

DB_PATH = DATA_DIR / "clips.db"
IMAGE_DIR = DATA_DIR / "clips"
HISTORY = 0                     # 履歴の group_id
DOWNLOADS = -1                  # 「ダウンロード」タブ（保存しない。実ファイル）
FREQUENT = -2                   # 「🤖よく使っている」タブ（直近1週間の頻出項目）
SNIPPET_CHARS = 2000
SCHEMA_VERSION = 1

# 並べ方
SORT_COPY = "copy"              # コピーした順（使っても動かない）
SORT_USE = "use"                # コピーか貼り付けで使った順
SORT_COUNT = "count"            # よく使う順
SORT_MANUAL = "manual"          # 自分で並べた順（グループ用）
SORT_NAME = "name"              # 名前順（グループ用）

KINDS = ("text", "image", "files")


# ---------------------------------------------------------------- DPAPI

class _Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD),
                ("pbData", ctypes.POINTER(ctypes.c_char))]


_crypt32 = None
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
_kernel32.LocalFree.argtypes = [ctypes.c_void_p]
_kernel32.LocalFree.restype = ctypes.c_void_p
CRYPTPROTECT_UI_FORBIDDEN = 0x1
# 同じ PC のほかのアプリが、同じ利用者の権限で読み出しにくくするための塩。
# 秘密そのものではない（DPAPI の守りは Windows のログオンに結びつく）。
_ENTROPY = b"koe-type clipboard v1"


def _crypt() -> Any:
    global _crypt32
    if _crypt32 is None:
        lib = ctypes.WinDLL("crypt32", use_last_error=True)
        for name in ("CryptProtectData", "CryptUnprotectData"):
            fn = getattr(lib, name)
            fn.argtypes = [ctypes.POINTER(_Blob), ctypes.c_void_p,
                           ctypes.POINTER(_Blob), ctypes.c_void_p,
                           ctypes.c_void_p, wintypes.DWORD,
                           ctypes.POINTER(_Blob)]
            fn.restype = wintypes.BOOL
        _crypt32 = lib
    return _crypt32


def _blob(data: bytes) -> tuple[_Blob, Any]:
    buf = ctypes.create_string_buffer(data, len(data))
    ptr = ctypes.cast(buf, ctypes.POINTER(ctypes.c_char))
    return _Blob(len(data), ptr), buf


def protect(text: str) -> bytes | None:
    """文字を DPAPI で包む。できなければ None。"""
    try:
        src, keep1 = _blob(text.encode("utf-8"))
        ent, keep2 = _blob(_ENTROPY)
        out = _Blob()
        if not _crypt().CryptProtectData(
                ctypes.byref(src), None, ctypes.byref(ent), None, None,
                CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
            log.error("秘密の項目を包めませんでした err=%s",
                      ctypes.get_last_error())
            return None
        try:
            return ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))
            del keep1, keep2
    except Exception:
        log.exception("秘密の項目を包めませんでした")
        return None


def unprotect(blob: bytes) -> str | None:
    """DPAPI で包んだものを戻す。戻せなければ None。"""
    if not blob:
        return ""
    try:
        src, keep1 = _blob(bytes(blob))
        ent, keep2 = _blob(_ENTROPY)
        out = _Blob()
        if not _crypt().CryptUnprotectData(
                ctypes.byref(src), None, ctypes.byref(ent), None, None,
                CRYPTPROTECT_UI_FORBIDDEN, ctypes.byref(out)):
            log.error("秘密の項目を開けませんでした err=%s",
                      ctypes.get_last_error())
            return None
        try:
            raw = ctypes.string_at(out.pbData, out.cbData)
        finally:
            _kernel32.LocalFree(ctypes.cast(out.pbData, ctypes.c_void_p))
            del keep1, keep2
        return raw.decode("utf-8", "replace")
    except Exception:
        log.exception("秘密の項目を開けませんでした")
        return None


# ---------------------------------------------------------------- 形


@dataclass
class Clip:
    """一覧に出す 1 件。本文は頭 2000 文字（snippet）だけ持つ。"""

    id: int
    group_id: int
    kind: str
    title: str = ""
    snippet: str = ""
    image: str = ""
    width: int = 0
    height: int = 0
    files: list[str] = field(default_factory=list)
    app: str = ""
    created: float = 0.0
    last_used: float = 0.0
    use_count: int = 0
    pinned: bool = False
    secret: bool = False
    position: int = 0
    size: int = 0
    chars: int = 0
    has_format: bool = False
    hash: str = ""
    # 「ダウンロード」タブの項目だけが使う。実ファイルの場所と、
    # OneDrive のクラウドだけにあるか（中身を読まない印）
    path: str = ""
    cloud: bool = False

    @property
    def touched(self) -> float:
        """最後にコピーしたか貼ったときの時刻。"""
        return max(self.created, self.last_used)


@dataclass
class Group:
    id: int
    name: str
    position: int = 0
    hotkey: str = ""
    count: int = 0


@dataclass
class Payload:
    """貼り付けに使う中身一式。"""

    kind: str
    text: str = ""
    html: bytes = b""
    rtf: bytes = b""
    image_path: Path | None = None
    files: list[str] = field(default_factory=list)
    secret: bool = False


_COLUMNS = ("id, group_id, kind, title, substr(text, 1, %d), image, width, "
            "height, files, app, created, last_used, use_count, pinned, "
            "secret IS NOT NULL, position, size, length(text), "
            "(html IS NOT NULL OR rtf IS NOT NULL), hash" % SNIPPET_CHARS)


def _row_to_clip(row: tuple) -> Clip:
    return Clip(
        id=row[0], group_id=row[1], kind=row[2], title=row[3] or "",
        snippet=row[4] or "", image=row[5] or "", width=row[6] or 0,
        height=row[7] or 0,
        files=[f for f in (row[8] or "").split("\n") if f],
        app=row[9] or "", created=row[10] or 0.0,
        last_used=row[11] or 0.0, use_count=row[12] or 0,
        pinned=bool(row[13]), secret=bool(row[14]), position=row[15] or 0,
        size=row[16] or 0, chars=row[17] or 0, has_format=bool(row[18]),
        hash=row[19] or "")


def _order(sort: str, pinned_first: bool) -> str:
    touched = "MAX(created, last_used)"
    keys = {
        SORT_COPY: "created DESC, id DESC",
        SORT_USE: f"{touched} DESC, id DESC",
        SORT_COUNT: f"use_count DESC, {touched} DESC, id DESC",
        SORT_MANUAL: "position ASC, id ASC",
        SORT_NAME: ("lower(CASE WHEN title != '' THEN title "
                    "ELSE substr(text, 1, 200) END) ASC, id ASC"),
    }
    body = keys.get(sort, keys[SORT_USE])
    return f"pinned DESC, {body}" if pinned_first else body


# ---------------------------------------------------------------- 保存


class ClipStore:
    """履歴とグループ。どのスレッドから呼んでもよい（中で順番待ちする）。"""

    def __init__(self, path: Path = DB_PATH,
                 image_dir: Path = IMAGE_DIR) -> None:
        self.path = path
        self.image_dir = image_dir
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None
        self.revision = 0         # 中身が変わるたびに増える（画面の更新用）
        self._open()

    # ------------------------------------------------------------ 開く

    def _open(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.image_dir.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(str(self.path), check_same_thread=False,
                                   timeout=5.0)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS groups (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    name      TEXT NOT NULL,
                    position  INTEGER NOT NULL DEFAULT 0,
                    hotkey    TEXT NOT NULL DEFAULT '',
                    created   REAL NOT NULL DEFAULT 0
                )""")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS clips (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    group_id  INTEGER NOT NULL DEFAULT 0,
                    kind      TEXT NOT NULL,
                    title     TEXT NOT NULL DEFAULT '',
                    text      TEXT NOT NULL DEFAULT '',
                    secret    BLOB,
                    html      BLOB,
                    rtf       BLOB,
                    image     TEXT NOT NULL DEFAULT '',
                    width     INTEGER NOT NULL DEFAULT 0,
                    height    INTEGER NOT NULL DEFAULT 0,
                    files     TEXT NOT NULL DEFAULT '',
                    hash      TEXT NOT NULL DEFAULT '',
                    app       TEXT NOT NULL DEFAULT '',
                    created   REAL NOT NULL DEFAULT 0,
                    last_used REAL NOT NULL DEFAULT 0,
                    use_count INTEGER NOT NULL DEFAULT 0,
                    pinned    INTEGER NOT NULL DEFAULT 0,
                    position  INTEGER NOT NULL DEFAULT 0,
                    size      INTEGER NOT NULL DEFAULT 0
                )""")
            conn.execute("CREATE INDEX IF NOT EXISTS clips_group_hash "
                         "ON clips(group_id, hash)")
            conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
            conn.commit()
            self._conn = conn
        except Exception:
            log.exception("クリップボードのデータベースを開けませんでした")
            self._conn = None

    @property
    def ok(self) -> bool:
        return self._conn is not None

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                try:
                    self._conn.close()
                except Exception:
                    pass
                self._conn = None

    def _exec(self, sql: str, args: tuple = ()) -> sqlite3.Cursor | None:
        if self._conn is None:
            return None
        return self._conn.execute(sql, args)

    def _changed(self) -> None:
        if self._conn is not None:
            self._conn.commit()
        self.revision += 1

    # ------------------------------------------------------------ 履歴

    def find_hash(self, hash_: str, group_id: int = HISTORY) -> Clip | None:
        with self._lock:
            cur = self._exec(f"SELECT {_COLUMNS} FROM clips WHERE "
                             "group_id = ? AND hash = ? LIMIT 1",
                             (group_id, hash_))
            row = cur.fetchone() if cur else None
        return _row_to_clip(row) if row else None

    def bump(self, clip_id: int, *, app: str = "") -> None:
        """同じものをもう一度コピーした。いちばん新しくする。"""
        with self._lock:
            now = time.time()
            if app:
                self._exec("UPDATE clips SET created = ?, app = ? "
                           "WHERE id = ?", (now, app, clip_id))
            else:
                self._exec("UPDATE clips SET created = ? WHERE id = ?",
                           (now, clip_id))
            self._changed()

    def add(self, *, kind: str, hash_: str, text: str = "",
            html: bytes = b"", rtf: bytes = b"", image: str = "",
            width: int = 0, height: int = 0, files: list[str] | None = None,
            app: str = "", group_id: int = HISTORY, title: str = "",
            size: int = 0, secret: bool = False) -> int:
        """1 件足す。足した id を返す（失敗は 0）。

        履歴に同じものがあれば、足さずに新しくするだけ（重ねない）。
        """
        if kind not in KINDS:
            raise ValueError(kind)
        with self._lock:
            if self._conn is None:
                return 0
            if group_id == HISTORY and hash_:
                same = self.find_hash(hash_, HISTORY)
                if same is not None:
                    self.bump(same.id, app=app)
                    return same.id
            blob = None
            if secret:
                blob = protect(text)
                if blob is None:
                    return 0
                text = ""
            now = time.time()
            position = self._next_position(group_id)
            cur = self._exec(
                "INSERT INTO clips (group_id, kind, title, text, secret, "
                "html, rtf, image, width, height, files, hash, app, "
                "created, last_used, use_count, pinned, position, size) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, "
                "?, ?)",
                (group_id, kind, title, text, blob, html or None,
                 rtf or None, image, width, height,
                 "\n".join(files or []), hash_, app, now, position,
                 size or len(text.encode("utf-8"))))
            self._changed()
            return int(cur.lastrowid) if cur else 0

    def _next_position(self, group_id: int) -> int:
        cur = self._exec("SELECT COALESCE(MAX(position), 0) + 1 FROM clips "
                         "WHERE group_id = ?", (group_id,))
        return int(cur.fetchone()[0]) if cur else 0

    def items(self, group_id: int = HISTORY, *, sort: str = SORT_USE,
              pinned_first: bool = True, limit: int = 0) -> list[Clip]:
        with self._lock:
            sql = (f"SELECT {_COLUMNS} FROM clips WHERE group_id = ? "
                   f"ORDER BY {_order(sort, pinned_first)}")
            if limit > 0:
                sql += f" LIMIT {int(limit)}"
            cur = self._exec(sql, (group_id,))
            rows = cur.fetchall() if cur else []
        return [_row_to_clip(r) for r in rows]

    def frequent_items(self, *, days: int = 7, min_count: int = 1,
                       limit: int = 60) -> list[Clip]:
        """直近（既定7日以内）によく使われた項目を取得する。

        貼り付け利用された回数（use_count）が多い順、同数の場合は
        最近触られた順に並べる。履歴およびグループ内の全項目が対象。
        """
        with self._lock:
            cutoff = time.time() - (days * 86400)
            sql = (
                f"SELECT {_COLUMNS} FROM clips WHERE "
                "(last_used >= ? OR (created >= ? AND use_count >= ?)) "
                "ORDER BY use_count DESC, MAX(created, last_used) DESC "
                "LIMIT ?"
            )
            cur = self._exec(sql, (cutoff, cutoff, min_count, limit))
            rows = cur.fetchall() if cur else []
        return [_row_to_clip(r) for r in rows]

    def get(self, clip_id: int) -> Clip | None:
        with self._lock:
            cur = self._exec(f"SELECT {_COLUMNS} FROM clips WHERE id = ?",
                             (clip_id,))
            row = cur.fetchone() if cur else None
        return _row_to_clip(row) if row else None

    def full_text(self, clip_id: int) -> str:
        """本文をすべて（秘密なら戻して）返す。"""
        with self._lock:
            cur = self._exec("SELECT text, secret FROM clips WHERE id = ?",
                             (clip_id,))
            row = cur.fetchone() if cur else None
        if not row:
            return ""
        if row[1] is not None:
            return unprotect(row[1]) or ""
        return row[0] or ""

    def payload(self, clip_id: int) -> Payload | None:
        """貼り付けに使う中身一式。"""
        with self._lock:
            cur = self._exec("SELECT kind, text, secret, html, rtf, image, "
                             "files FROM clips WHERE id = ?", (clip_id,))
            row = cur.fetchone() if cur else None
        if not row:
            return None
        kind, text, secret, html, rtf, image, files = row
        if secret is not None:
            opened = unprotect(secret)
            if opened is None:
                return None
            text = opened
        return Payload(
            kind=kind, text=text or "", html=bytes(html or b""),
            rtf=bytes(rtf or b""),
            image_path=(self.image_dir / image) if image else None,
            files=[f for f in (files or "").split("\n") if f],
            secret=secret is not None)

    def mark_used(self, ids: list[int]) -> None:
        with self._lock:
            now = time.time()
            for clip_id in ids:
                self._exec("UPDATE clips SET last_used = ?, "
                           "use_count = use_count + 1 WHERE id = ?",
                           (now, clip_id))
            self._changed()

    def set_pinned(self, ids: list[int], pinned: bool) -> None:
        with self._lock:
            for clip_id in ids:
                self._exec("UPDATE clips SET pinned = ? WHERE id = ?",
                           (1 if pinned else 0, clip_id))
            self._changed()

    def move(self, ids: list[int], group_id: int) -> int:
        """別のグループ（または履歴）へ移す。移した数を返す。

        履歴へ戻すときに同じものがあれば、重ねずに片方だけ残す。
        """
        moved = 0
        with self._lock:
            if group_id != HISTORY and not self.group(group_id):
                return 0
            for clip_id in ids:
                clip = self.get(clip_id)
                if clip is None or clip.group_id == group_id:
                    continue
                if group_id == HISTORY and clip.hash:
                    same = self.find_hash(clip.hash, HISTORY)
                    if same is not None and same.id != clip_id:
                        # 同じ中身が履歴にある。付けた名前や「秘密」が
                        # 消えないよう、移すほうを残して履歴の古いほうを消す
                        self.delete([same.id], keep_files=False)
                self._exec("UPDATE clips SET group_id = ?, position = ? "
                           "WHERE id = ?",
                           (group_id, self._next_position(group_id),
                            clip_id))
                moved += 1
            self._changed()
        return moved

    def update_item(self, clip_id: int, *, title: str | None = None,
                    text: str | None = None,
                    secret: bool | None = None) -> bool:
        """名前・本文・秘密かどうかを書き換える。"""
        with self._lock:
            clip = self.get(clip_id)
            if clip is None:
                return False
            if title is not None:
                self._exec("UPDATE clips SET title = ? WHERE id = ?",
                           (title.strip(), clip_id))
            if clip.kind == "text" and (text is not None
                                        or secret is not None):
                body = self.full_text(clip_id) if text is None else text
                hide = clip.secret if secret is None else bool(secret)
                hash_ = text_hash(body)
                if hide:
                    blob = protect(body)
                    if blob is None:
                        return False
                    self._exec("UPDATE clips SET text = '', secret = ?, "
                               "html = NULL, rtf = NULL, hash = ?, "
                               "size = ? WHERE id = ?",
                               (blob, hash_, len(body.encode("utf-8")),
                                clip_id))
                else:
                    changed = body != self.full_text(clip_id)
                    self._exec("UPDATE clips SET text = ?, secret = NULL, "
                               "hash = ?, size = ? WHERE id = ?",
                               (body, hash_, len(body.encode("utf-8")),
                                clip_id))
                    if changed:
                        # 書き換えた文に、元の書式（HTML など）は合わない
                        self._exec("UPDATE clips SET html = NULL, "
                                   "rtf = NULL WHERE id = ?", (clip_id,))
            self._changed()
            return True

    def reorder(self, clip_id: int, delta: int, *,
                pinned_first: bool = False) -> bool:
        """グループの中で 1 つ上（-1）・下（+1）へ。

        pinned_first は一覧の見え方に合わせる。合わせないと、固定した
        項目があるときに、見えていない相手と入れ替わった（レビューで発覚）。
        """
        with self._lock:
            clip = self.get(clip_id)
            if clip is None:
                return False
            rows = self.items(clip.group_id, sort=SORT_MANUAL,
                              pinned_first=pinned_first)
            ids = [r.id for r in rows]
            i = ids.index(clip_id)
            j = i + (1 if delta > 0 else -1)
            if not 0 <= j < len(ids):
                return False
            ids[i], ids[j] = ids[j], ids[i]
            for pos, cid in enumerate(ids, start=1):
                self._exec("UPDATE clips SET position = ? WHERE id = ?",
                           (pos, cid))
            self._changed()
            return True

    def delete(self, ids: list[int], *,
               keep_files: bool = False) -> list[dict[str, Any]]:
        """消す。元に戻すための行を返す。

        keep_files=True なら画像ファイルは残す（「元に戻す」のため）。
        あとで purge_files() で消す。
        """
        out: list[dict[str, Any]] = []
        with self._lock:
            if self._conn is None:
                return out
            for clip_id in ids:
                cur = self._exec("SELECT * FROM clips WHERE id = ?",
                                 (clip_id,))
                row = cur.fetchone() if cur else None
                if not row:
                    continue
                names = [d[0] for d in cur.description]
                out.append(dict(zip(names, row)))
                self._exec("DELETE FROM clips WHERE id = ?", (clip_id,))
            self._changed()
        if not keep_files:
            self.purge_files(out)
        return out

    def restore(self, rows: list[dict[str, Any]]) -> int:
        """delete() で消したものを戻す。"""
        done = 0
        with self._lock:
            if self._conn is None:
                return 0
            for row in rows:
                keys = list(row)
                marks = ", ".join("?" for _ in keys)
                try:
                    self._exec(f"INSERT INTO clips ({', '.join(keys)}) "
                               f"VALUES ({marks})",
                               tuple(row[k] for k in keys))
                    done += 1
                except sqlite3.IntegrityError:
                    log.debug("戻そうとした項目はもうありました")
            self._changed()
        return done

    def purge_files(self, rows: list[dict[str, Any]]) -> None:
        """消した行の画像ファイルを消す（ほかの行が使っていなければ）。"""
        for row in rows:
            name = str(row.get("image") or "")
            if not name:
                continue
            with self._lock:
                cur = self._exec("SELECT 1 FROM clips WHERE image = ? "
                                 "LIMIT 1", (name,))
                used = bool(cur.fetchone()) if cur else True
            if used:
                continue
            for path in (self.image_dir / name,
                         self.image_dir / preview_name(name)):
                try:
                    path.unlink(missing_ok=True)
                except OSError:
                    log.debug("画像を消せませんでした: %s", path.name)

    def trim(self, *, max_items: int, keep_days: int) -> int:
        """履歴を、件数と日数の上限まで減らす。固定したものは残す。"""
        removed: list[dict[str, Any]] = []
        with self._lock:
            if self._conn is None:
                return 0
            ids: list[int] = []
            if keep_days > 0:
                limit = time.time() - keep_days * 86400
                cur = self._exec(
                    "SELECT id FROM clips WHERE group_id = 0 AND "
                    "pinned = 0 AND MAX(created, last_used) < ?", (limit,))
                ids += [r[0] for r in (cur.fetchall() if cur else [])]
            if max_items > 0:
                cur = self._exec(
                    "SELECT id FROM clips WHERE group_id = 0 AND pinned = 0 "
                    "ORDER BY MAX(created, last_used) DESC, id DESC "
                    "LIMIT -1 OFFSET ?", (max_items,))
                ids += [r[0] for r in (cur.fetchall() if cur else [])]
            if ids:
                removed = self.delete(sorted(set(ids)), keep_files=True)
        self.purge_files(removed)
        if removed:
            log.info("クリップボード履歴を %d 件整理しました", len(removed))
        return len(removed)

    def clear_history(self, *, keep_pinned: bool = True) -> int:
        with self._lock:
            sql = "SELECT id FROM clips WHERE group_id = 0"
            if keep_pinned:
                sql += " AND pinned = 0"
            cur = self._exec(sql)
            ids = [r[0] for r in (cur.fetchall() if cur else [])]
        return len(self.delete(ids))

    def orphan_images(self) -> int:
        """どの行も使っていない画像ファイルを消す（落ちたときの残り）。"""
        if not self.image_dir.is_dir():
            return 0
        with self._lock:
            cur = self._exec("SELECT image FROM clips WHERE image != ''")
            used = {r[0] for r in (cur.fetchall() if cur else [])}
        removed = 0
        for path in self.image_dir.glob("*.png"):
            base = path.name.replace(".prev.png", ".png")
            if base in used:
                continue
            # いま書いている途中かもしれないので、新しいものは残す
            try:
                if time.time() - path.stat().st_mtime < 120:
                    continue
                path.unlink()
                removed += 1
            except OSError:
                pass
        return removed

    # ------------------------------------------------------------ グループ

    def groups(self) -> list[Group]:
        with self._lock:
            cur = self._exec(
                "SELECT g.id, g.name, g.position, g.hotkey, "
                "(SELECT COUNT(*) FROM clips c WHERE c.group_id = g.id) "
                "FROM groups g ORDER BY g.position ASC, g.id ASC")
            rows = cur.fetchall() if cur else []
        return [Group(id=r[0], name=r[1], position=r[2], hotkey=r[3] or "",
                      count=r[4]) for r in rows]

    def group(self, group_id: int) -> Group | None:
        for g in self.groups():
            if g.id == group_id:
                return g
        return None

    def history_count(self) -> int:
        with self._lock:
            cur = self._exec("SELECT COUNT(*) FROM clips WHERE group_id = 0")
            return int(cur.fetchone()[0]) if cur else 0

    def add_group(self, name: str) -> int:
        name = name.strip()[:40] or "グループ"
        with self._lock:
            cur = self._exec("SELECT COALESCE(MAX(position), 0) + 1 "
                             "FROM groups")
            pos = int(cur.fetchone()[0]) if cur else 1
            cur = self._exec("INSERT INTO groups (name, position, created) "
                             "VALUES (?, ?, ?)", (name, pos, time.time()))
            self._changed()
            return int(cur.lastrowid) if cur else 0

    def rename_group(self, group_id: int, name: str) -> bool:
        name = name.strip()[:40]
        if not name:
            return False
        with self._lock:
            self._exec("UPDATE groups SET name = ? WHERE id = ?",
                       (name, group_id))
            self._changed()
        return True

    def set_group_hotkey(self, group_id: int, hotkey: str) -> None:
        with self._lock:
            self._exec("UPDATE groups SET hotkey = ? WHERE id = ?",
                       (hotkey.strip().lower(), group_id))
            self._changed()

    def delete_group(self, group_id: int) -> int:
        """グループと、その中身を消す。消した項目の数を返す。"""
        with self._lock:
            cur = self._exec("SELECT id FROM clips WHERE group_id = ?",
                             (group_id,))
            ids = [r[0] for r in (cur.fetchall() if cur else [])]
            removed = self.delete(ids, keep_files=True)
            self._exec("DELETE FROM groups WHERE id = ?", (group_id,))
            self._changed()
        self.purge_files(removed)
        return len(removed)

    def reorder_group(self, group_id: int, delta: int) -> bool:
        with self._lock:
            ids = [g.id for g in self.groups()]
            if group_id not in ids:
                return False
            i = ids.index(group_id)
            j = i + (1 if delta > 0 else -1)
            if not 0 <= j < len(ids):
                return False
            ids[i], ids[j] = ids[j], ids[i]
            for pos, gid in enumerate(ids, start=1):
                self._exec("UPDATE groups SET position = ? WHERE id = ?",
                           (pos, gid))
            self._changed()
            return True

    def ensure_default_groups(self, names: list[str]) -> bool:
        """はじめて使うときだけ、最初のグループを作る。

        利用者が全部消したあとに勝手に作り直さないよう、
        「作ったことがある」印をデータベースに残す。
        """
        with self._lock:
            if self._conn is None:
                return False
            self._exec("CREATE TABLE IF NOT EXISTS meta "
                       "(key TEXT PRIMARY KEY, value TEXT)")
            cur = self._exec("SELECT value FROM meta WHERE key = "
                             "'default_groups'")
            if cur and cur.fetchone():
                return False
            for name in names:
                self.add_group(name)
            self._exec("INSERT OR REPLACE INTO meta VALUES "
                       "('default_groups', '1')")
            self._changed()
            return True

    # ------------------------------------------------------------ その他

    def stats(self) -> dict[str, int]:
        with self._lock:
            def one(sql: str) -> int:
                cur = self._exec(sql)
                return int(cur.fetchone()[0] or 0) if cur else 0
            out = {
                "history": one("SELECT COUNT(*) FROM clips "
                               "WHERE group_id = 0"),
                "pinned": one("SELECT COUNT(*) FROM clips "
                              "WHERE group_id = 0 AND pinned = 1"),
                "items": one("SELECT COUNT(*) FROM clips "
                             "WHERE group_id != 0"),
                "groups": one("SELECT COUNT(*) FROM groups"),
                "images": one("SELECT COUNT(*) FROM clips "
                              "WHERE kind = 'image'"),
            }
        total = 0
        if self.image_dir.is_dir():
            for path in self.image_dir.glob("*.png"):
                try:
                    total += path.stat().st_size
                except OSError:
                    pass
        try:
            total += self.path.stat().st_size
        except OSError:
            pass
        out["bytes"] = total
        return out

    def export_json(self, *, include_secrets: bool = False) -> str:
        """グループと中身（文字だけ）を JSON にする。

        秘密の項目は、頼まれたときだけ中身を書く。
        書かないときは名前だけ残し、読み込み側で空の項目になる。
        """
        out: list[dict[str, Any]] = []
        for g in self.groups():
            items = []
            for clip in self.items(g.id, sort=SORT_MANUAL,
                                   pinned_first=False):
                if clip.kind != "text":
                    continue
                row: dict[str, Any] = {"title": clip.title}
                if clip.secret:
                    row["secret"] = True
                    if include_secrets:
                        row["text"] = self.full_text(clip.id)
                else:
                    row["text"] = self.full_text(clip.id)
                items.append(row)
            out.append({"name": g.name, "hotkey": g.hotkey,
                        "items": items})
        return json.dumps({"koe_type_clips": 1, "groups": out},
                          ensure_ascii=False, indent=2)

    def import_json(self, text: str) -> dict[str, int]:
        """export_json() の形を読み込む。同じ名前のグループには足す。"""
        data = json.loads(text)
        if not isinstance(data, dict) or not isinstance(
                data.get("groups"), list):
            raise ValueError("形が違います")
        added_groups = added_items = 0
        by_name = {g.name: g.id for g in self.groups()}
        for g in data["groups"]:
            if not isinstance(g, dict):
                continue
            name = str(g.get("name") or "").strip()
            if not name:
                continue
            gid = by_name.get(name)
            if gid is None:
                gid = self.add_group(name)
                by_name[name] = gid
                added_groups += 1
                # キーは読み込まない。ほかのショートカットとのぶつかりを
                # 確かめられないため（設定画面でつけ直してもらう）
            have = {c.hash for c in self.items(gid, sort=SORT_MANUAL)}
            for item in g.get("items") or []:
                if not isinstance(item, dict):
                    continue
                body = str(item.get("text") or "")
                title = str(item.get("title") or "")
                if not body and not title:
                    continue
                hash_ = text_hash(body)
                if body and hash_ in have:
                    continue
                if self.add(kind="text", hash_=hash_, text=body,
                            group_id=gid, title=title,
                            secret=bool(item.get("secret")) and bool(body)):
                    added_items += 1
                    have.add(hash_)
        return {"groups": added_groups, "items": added_items}


# ---------------------------------------------------------------- 小物


def text_hash(text: str) -> str:
    import hashlib  # noqa: PLC0415
    return hashlib.sha1(("t:" + text).encode("utf-8")).hexdigest()


def preview_name(name: str) -> str:
    """画像の「小さめの版」のファイル名。"""
    return name[:-4] + ".prev.png" if name.endswith(".png") else name
