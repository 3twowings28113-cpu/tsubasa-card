"""無音の切れ目を見つけて発話区間を切り出す。

モデルを使わない振幅ベースの判定。暗騒音の大きさを少しずつ学習し、
その数倍を超えたら発話とみなす。所定の長さ静かになったら区間を確定する。
"""

from __future__ import annotations

import array
import logging
import math
import threading

log = logging.getLogger(__name__)

FRAME_MS = 20


def is_silence(pcm: bytes, *, floor: float,
               sample_rate: int = 16000) -> bool:
    """音が実質「無音だけ」かどうか。25ms ごとの RMS の最大で見る。

    基準の floor はカッターの「これ未満は音として数えない」と
    同じ物差し（設定 vad_floor）。1 フレームでも超えれば音がある。

    停止時の残り（post-roll 窓）や確定待ちの端数はカッターの
    発話判定を通らないため、無音のまま最終デコードへ回ることが
    ある。無音を聞かせるとモデルは断片を幻聴する（2026-10-26
    実証）ので、呼び出し側はこれが True の区間をエンジンへ
    渡さない／結果を採用しない。
    """
    if not pcm:
        return True
    frame = max(1, sample_rate * 25 // 1000)
    samples = array.array("h")
    samples.frombytes(pcm[:len(pcm) - len(pcm) % 2])
    for i in range(0, len(samples), frame):
        chunk = samples[i:i + frame]
        if not chunk:
            break
        rms = math.sqrt(sum(s * s for s in chunk) / len(chunk))
        if rms >= floor:
            return False
    return True


class SegmentCutter:
    """50ms ごとの PCM を食わせると、発話区間の bytes を返す。"""

    def __init__(self, sample_rate: int, *, pause_ms: int, min_speech_ms: int,
                 max_segment_ms: int, preroll_ms: int, tail_ms: int,
                 sensitivity: float, floor: float,
                 merge_short_ms: int = 1000,
                 hold_release_ms: int = 1500,
                 speaker_focus: str = "normal") -> None:
        self.rate = sample_rate
        self.frame_samples = sample_rate * FRAME_MS // 1000
        self.pause_frames = max(1, pause_ms // FRAME_MS)
        self.min_speech_frames = max(1, min_speech_ms // FRAME_MS)
        self.max_frames = max(1, max_segment_ms // FRAME_MS)
        self.preroll_frames = max(0, preroll_ms // FRAME_MS)
        self.tail_frames = max(0, tail_ms // FRAME_MS)
        self.sensitivity = sensitivity
        self.floor = floor
        self.speaker_focus = speaker_focus  # off / normal / strong
        # 短い区間は、その場で出さずに**次の区間の頭に付ける**。
        # 「隣の…（ためらい）…隣の客はよく柿食う客だ」のように
        # 言いよどむと、「隣りの」だけが先に入ってしまっていた。
        self.merge_short_frames = max(0, merge_short_ms // FRAME_MS)
        # 付ける相手が来ないまま、これだけ静かなら、ひとりで出す。
        self.hold_release_frames = max(1, hold_release_ms // FRAME_MS)

        self._held = bytearray()       # 次の区間の頭に付ける音
        self._held_speech = 0          # そのうち喋っていたフレーム数
        self._held_wait = 0            # 付ける相手を待っているフレーム数
        self._noise = floor
        self._peak_rms = 0.0           # 主話者のピーク音量（遠くの声を落とす基準）
        self._frames: list[array.array] = []   # 直近のフレーム列
        self._flags: list[bool] = []
        self._pending = bytearray()            # フレーム長に満たない端数
        self._speech_frames = 0
        self._silence_run = 0
        self._in_speech = False
        self._level = 0.0
        self._lock = threading.Lock()

    # -------------------------------------------------------------- 計測用

    @property
    def level(self) -> float:
        """0.0〜1.0 の入力レベル（表示用）。"""
        return self._level

    @property
    def in_speech(self) -> bool:
        return self._in_speech

    def buffered(self) -> bytes:
        """まだ区間として出していない音をまとめて返す。

        話しながら文字起こしするモードが、いまの発話の先頭から
        毎回やり直すために使う。
        """
        with self._lock:
            # ためてある短い区間も、いまの発話の一部として渡す。
            # そうしないと、帯の先出しが途中から始まってしまう。
            out = bytearray(self._held)
            for f in self._frames:
                out.extend(f.tobytes())
            out.extend(self._pending)
            return bytes(out)

    # -------------------------------------------------------------- 本体

    def reset(self) -> None:
        with self._lock:
            self._reset_locked()

    def _reset_locked(self) -> None:
        self._frames.clear()
        self._flags.clear()
        self._pending.clear()
        self._held.clear()
        self._held_speech = 0
        self._held_wait = 0
        self._peak_rms = 0.0
        self._speech_frames = 0
        self._silence_run = 0
        self._in_speech = False
        self._level = 0.0

    def feed(self, data: bytes) -> list[bytes]:
        """PCM を追加し、確定した発話区間を返す（0〜複数個）。"""
        with self._lock:
            self._pending.extend(data)
            out: list[bytes] = []
            step = self.frame_samples * 2
            while len(self._pending) >= step:
                raw = bytes(self._pending[:step])
                del self._pending[:step]
                frame = array.array("h")
                frame.frombytes(raw)
                out.extend(self._push_frame(frame))
            return out

    def _push_frame(self, frame: array.array) -> list[bytes]:
        total = 0
        for s in frame:
            total += s * s
        rms = math.sqrt(total / len(frame)) if frame else 0.0
        self._level = min(1.0, rms / 6000.0)

        focus = self.speaker_focus
        if focus == "strong":
            effective_floor = max(self.floor * 2.2, 420.0)
            threshold = max(
                effective_floor, self._noise * (self.sensitivity * 1.15)
            )
        elif focus == "normal":
            effective_floor = max(self.floor * 1.4, 260.0)
            threshold = max(effective_floor, self._noise * self.sensitivity)
        else:
            effective_floor = self.floor
            threshold = max(effective_floor, self._noise * self.sensitivity)

        speech = rms > threshold
        if speech:
            self._peak_rms = max(self._peak_rms, rms)
        elif self._peak_rms > 0:
            self._peak_rms *= 0.99  # 音が切れると少しずつ減衰

        # 遠くの人の相づちや小声の割り込みをカット（主話者ピーク比で判定）
        if speech and self._peak_rms > effective_floor:
            ratio = (0.28 if focus == "strong"
                     else (0.16 if focus == "normal" else 0.0))
            if ratio > 0 and rms < (self._peak_rms * ratio):
                speech = False

        # 暗騒音の追従。**話している最中（区間の中）は動かさない。**
        # ★前は区間の中でも、基準を下回った音節（＝少し小さい声）で
        # 見積もりを 5% ずつ声の大きさへ引き上げていた。すると基準が
        # 上がって、ふつうの声まで「無音」と数え、さらに見積もりが上がる、
        # の悪循環で、**話している最中に区切られ、残りの声が捨てられた**
        # （2026-10-06。6 秒話した音が 4 秒で切られ、2 秒ぶん消えた。
        # 利用者の「話の最後が文字にならない」の正体）。
        if not self._in_speech:
            if speech:
                self._noise += (rms - self._noise) * 0.001
            else:
                self._noise += (rms - self._noise) * 0.05
            self._noise = max(1.0, min(self._noise, 4000.0))

        self._frames.append(frame)
        self._flags.append(speech)

        if speech:
            self._speech_frames += 1
            self._silence_run = 0
            if self._speech_frames >= 2:
                self._in_speech = True
        else:
            if self._in_speech:
                self._silence_run += 1
            else:
                # まだ発話に入っていない間は、先頭の余白分だけ残して捨てる。
                # 話し始めの微弱な子音や立ち上がりを逃さないよう、
                # +6フレーム（約120ms）余裕を持たせる。
                margin = self.preroll_frames + 6
                if len(self._frames) > margin:
                    self._frames.pop(0)
                    self._flags.pop(0)
                self._speech_frames = 0

        if not self._in_speech:
            # ためてある短い区間を、いつまでも持っていない。
            # 続きが来ないなら、ひとりで出す。
            if self._held:
                self._held_wait += 1
                if self._held_wait >= self.hold_release_frames:
                    return self._release_held()
            return []

        if self._silence_run >= self.pause_frames:
            return self._finish()
        if len(self._frames) >= self.max_frames:
            log.info("最大長に達したので区間を強制確定します")
            return self._finish(forced=True)
        return []

    def _finish(self, *, forced: bool = False) -> list[bytes]:
        speech_count = sum(self._flags)
        if speech_count < self.min_speech_frames:
            log.debug("短すぎる音（%dフレーム）なので捨てます", speech_count)
            self._frames.clear()
            self._flags.clear()
            self._speech_frames = 0
            self._silence_run = 0
            self._in_speech = False
            return []

        # 末尾の無音を tail_frames だけ残して落とす
        keep = len(self._frames)
        if not forced:
            trim = max(0, self._silence_run - self.tail_frames)
            keep = max(1, len(self._frames) - trim)

        buf = bytearray()
        for f in self._frames[:keep]:
            buf.extend(f.tobytes())

        self._frames.clear()
        self._flags.clear()
        self._speech_frames = 0
        self._silence_run = 0
        self._in_speech = False

        # ためてあった短い区間を、頭に付ける
        if self._held:
            buf = bytearray(self._held) + buf
            speech_count += self._held_speech
            self._held.clear()
            self._held_speech = 0
            self._held_wait = 0

        # 短いままなら、まだ出さずにためる。
        # 言いよどみの「隣りの」だけが先に入るのを防ぐ。
        if (not forced and self.merge_short_frames
                and speech_count < self.merge_short_frames):
            self._held = buf
            self._held_speech = speech_count
            self._held_wait = 0
            log.debug("短い区間（喋り %dフレーム）は次につなげます",
                      speech_count)
            return []
        return [bytes(buf)]

    def _release_held(self) -> list[bytes]:
        """ためてあった短い区間を、ひとりで出す。"""
        out = bytes(self._held)
        log.debug("続きが来ないので、短い区間をそのまま出します")
        self._held.clear()
        self._held_speech = 0
        self._held_wait = 0
        return [out] if out else []

    def drain(self) -> bytes:
        """ためている音をすべて返す（長さの判定をしない）。

        中止したときに、録った音を捨てずに履歴へ残すために使う。
        """
        with self._lock:
            out = bytearray()
            for f in self._frames:
                out.extend(f.tobytes())
            out.extend(self._pending)
            self._reset_locked()
            return bytes(out)

    def flush(self) -> list[bytes]:
        """録音終了時。残っている音を区間として出す。"""
        with self._lock:
            return self._flush_locked()

    def _flush_locked(self) -> list[bytes]:
        held = bytes(self._held)
        self._held.clear()
        self._held_speech = 0
        self._held_wait = 0
        out = self._flush_body()
        if held:
            # ためてある分は、必ず頭に付けて出す（捨てない）
            if out:
                return [held + out[0]] + out[1:]
            return [held]
        return out

    def _flush_body(self) -> list[bytes]:
        if self._pending:
            frame = array.array("h")
            pad = len(self._pending) - len(self._pending) % 2
            frame.frombytes(bytes(self._pending[:pad]))
            if frame:
                self._frames.append(frame)
                self._flags.append(True)
            self._pending.clear()
        if not self._frames:
            self._reset_locked()
            return []
        if sum(self._flags) < self.min_speech_frames:
            self._reset_locked()
            return []
        buf = bytearray()
        for f in self._frames:
            buf.extend(f.tobytes())
        self._reset_locked()
        return [bytes(buf)]
