"""同音異義語のテーブルと、候補の好みの記録。

音声認識の結果は「読み」を持たない（出てくるのは表記だけ）。
だから「しかい」と聞こえた場所が本文のどこかは分からず、
**自動で表記を差し替えることはできない**。ここでやるのは、

  ・本文に出てきた表記が、同じ読みの別表記を持っているかを示す
  ・利用者が過去に選んだ表記を、その読みの候補の先頭に出す

まで。実際に差し替えるのは、編集ポップアップの中で利用者が
選んだときだけ（app/fixwin.py）。

テーブルは「読み（ひらがな）→ 表記の並び」。収録は頻出のものに
限り、読みが複数ある表記（例: 解除 = かいじょ / かいじょう）は
代表の読み 1 つにだけ載せる（逆引きが一意でないと、候補の
並びを決められないため）。
"""

from __future__ import annotations

import json
import logging
import threading
from dataclasses import dataclass
from pathlib import Path

from .util import DATA_DIR

log = logging.getLogger(__name__)

PREFS_PATH = DATA_DIR / "homophone_prefs.json"


# ---------------------------------------------------------------- テーブル

# 読み → 表記。並びは「ふだん多いと思う順」の初期値で、利用者の
# 好み（Prefs）が付いた読みでは、好みの表記が先頭へ動く。
TABLE: dict[str, tuple[str, ...]] = {
    "しかい": ("司会", "視界", "市会"),
    "はし": ("橋", "箸", "端"),
    "あめ": ("雨", "飴"),
    "きく": ("聞く", "効く", "利く", "菊"),
    "かく": ("書く", "描く", "欠く", "掻く"),
    "つくる": ("作る", "造る", "創る"),
    "あう": ("会う", "合う", "遭う"),
    "うつす": ("写す", "映す", "移す"),
    "とる": ("取る", "撮る", "採る", "捕る"),
    "きる": ("着る", "切る"),
    "かける": ("掛ける", "欠ける", "駆ける"),
    "あける": ("開ける", "空ける", "明ける"),
    "へんしゅう": ("編集", "編修"),
    "かんしん": ("感心", "関心"),
    "いし": ("医師", "石", "意志"),
    "こうしょう": ("交渉", "高尚", "公証", "考証"),
    "しょうかい": ("紹介", "照会"),
    "かいとう": ("回答", "解答", "解凍"),
    "せいさく": ("制作", "製作", "政策"),
    "かんじ": ("漢字", "感じ", "幹事", "監事"),
    "きかん": ("期間", "機関", "帰還", "気管"),
    "きかい": ("機械", "機会", "奇怪"),
    "いがい": ("以外", "意外", "遺骸"),
    "こうどう": ("行動", "講堂", "坑道"),
    "かんり": ("管理", "官吏"),
    "せいり": ("整理", "生理"),
    "しんこう": ("信仰", "進行", "新興", "親交"),
    "こうえん": ("講演", "公園", "後援"),
    "えんぎ": ("演技", "縁起"),
    "かいぎ": ("会議", "懐疑"),
    "かみ": ("紙", "神", "髪"),
    "くも": ("雲", "蜘蛛"),
    "さく": ("咲く", "裂く"),
    "なく": ("泣く", "鳴く"),
    "のぼる": ("上る", "登る", "昇る"),
    "おりる": ("降りる", "下りる"),
    "なおす": ("直す", "治す"),
    "あつい": ("暑い", "熱い", "厚い"),
    "おさめる": ("収める", "納める", "治める", "修める"),
    "はかる": ("計る", "測る", "量る", "図る"),
    "つく": ("着く", "付く", "就く"),
    "とめる": ("止める", "泊める", "留める"),
    "かた": ("型", "形", "方"),
    "あし": ("足", "脚", "芦"),
    "こし": ("腰", "輿"),
    "せん": ("線", "千", "栓", "銭"),
    "しんせい": ("申請", "新生", "真正"),
    "かいせい": ("改正", "快晴", "改姓"),
    "てんき": ("天気", "転機", "転記"),
    "きしょう": ("気象", "起床", "希少"),
    "かんせい": ("完成", "感性", "慣性", "管制"),
    "せんせい": ("先生", "宣誓"),
    "どうき": ("動機", "同期"),
    "ゆうき": ("勇気", "有機"),
    "しかく": ("資格", "四角", "視覚", "死角"),
    "さんかく": ("三角", "参画"),
    "かいしん": ("改新", "会心"),
    "しゅうし": ("終始", "収支"),
    "こじん": ("個人", "故人"),
    "かじん": ("歌人", "佳人", "家人"),
    "かんてい": ("鑑定", "官邸", "艦艇"),
    "ていじ": ("提示", "定時"),
    "じしょ": ("辞書", "自書", "地所"),
    "さいき": ("再起", "才気"),
    "さいしょ": ("最初", "妻子"),
    "ほしょう": ("保証", "保障", "補償"),
    "しょうがい": ("障害", "生涯"),
    "しょうごう": ("照合", "称号"),
    "へんこう": ("変更", "偏光", "偏向"),
    "へんかん": ("変換", "返還"),
    "かんりょう": ("完了", "官僚"),
    "かんしゅう": ("慣習", "監修", "観衆"),
    "かんしょう": ("干渉", "感傷", "鑑賞"),
    "かんそう": ("感想", "乾燥", "完走"),
    "かんせつ": ("関節", "間接"),
    "れんけい": ("連携", "連係"),
    "きょうりょく": ("協力", "強力"),
    "きょうちょう": ("強調", "協調"),
    "きょく": ("曲", "局"),
    "しりょう": ("資料", "史料", "試料", "飼料"),
    "しけん": ("試験", "私見"),
    "たいしょう": ("対象", "対照", "大将", "対症"),
    "たいしょ": ("対処", "退所"),
    "にんしょう": ("認証", "人証"),
    "ほんたい": ("本体", "本隊"),
    "そうさ": ("操作", "捜査"),
    "そうぞう": ("想像", "創造"),
    "そうてい": ("想定", "装丁"),
    "かいてい": ("改定", "改訂", "海底"),
    "かいせつ": ("解説", "開設"),
    "かいほう": ("解放", "開放"),
    "かいふく": ("回復", "開腹"),
    "かいしゅう": ("回収", "改修"),
    "かいじょう": ("会場", "解除", "海上", "開錠"),
    "かいだん": ("会談", "階段", "怪談"),
    "えき": ("駅", "益", "液", "役"),
    "えん": ("円", "園", "縁", "塩", "宴"),
    "えんちょう": ("延長", "園長"),
    "えいせい": ("衛生", "衛星", "永世"),
    "えいり": ("営利", "鋭利"),
    "えいき": ("英気", "鋭気"),
    "おうきゅう": ("応急", "王宮"),
    "おうとう": ("応答", "桜桃"),
    "おうしゅう": ("応酬", "欧州"),
    "おす": ("押す", "推す"),
    "おもい": ("思い", "重い"),
    "おり": ("折り", "檻"),
    "おん": ("音", "恩", "温"),
    "かい": ("回", "階", "貝"),
    "かいきん": ("皆勤", "解禁"),
    "かいこ": ("解雇", "回顧"),
    "かいしゃく": ("解釈", "介錯"),
    "かいしょう": ("解消", "快勝"),
    "かいせき": ("解析", "会席"),
    "かいそう": ("回想", "海藻", "改装", "階層"),
    "かいちょう": ("会長", "快調", "開帳"),
    "かいてん": ("回転", "開店"),
    "かいにん": ("解任", "懐妊"),
    "かいひ": ("回避", "会費"),
    "かいへい": ("開閉", "海兵"),
    "かいめい": ("解明", "改名"),
    "かいめん": ("海面", "界面"),
    "かいよう": ("海洋", "潰瘍"),
    "かいり": ("乖離", "解離", "海里"),
    "かいりゅう": ("回流", "海流"),
    "かいろ": ("回路", "海路", "懐炉"),
    "かう": ("買う", "飼う"),
    "かえす": ("返す", "帰す"),
    "かえる": ("帰る", "変える", "換える", "替える", "蛙"),
    "かき": ("柿", "牡蠣", "垣"),
    "かぎ": ("鍵", "鉤"),
    "かくしゅ": ("各種", "核種"),
    "かくしん": ("確信", "核心", "革新"),
    "かくち": ("各地", "角地"),
    "かくど": ("角度", "確度"),
    "かくりつ": ("確率", "確立"),
    "かげ": ("影", "陰"),
    "かげき": ("歌劇", "過激"),
    "かげん": ("加減", "下限"),
    "かこう": ("加工", "火口", "河口", "下行"),
    "かさ": ("傘", "笠"),
    "かさん": ("加算", "家産"),
    "かし": ("貸し", "菓子", "歌詞", "樫", "瑕疵"),
    "かしつ": ("過失", "加湿"),
    "かしん": ("家臣", "過信"),
    "かじ": ("舵", "鍛冶", "火事"),
    "かじつ": ("果実", "過日", "佳日"),
    "かじゅう": ("果汁", "荷重"),
    "かじょう": ("過剰", "箇条"),
    "かす": ("貸す", "粕"),
    "かせい": ("化成", "火星", "家政"),
    "かせつ": ("仮説", "架設"),
    "かせん": ("河川", "化繊", "寡占"),
    "かぜ": ("風", "風邪"),
    "かそう": ("仮想", "火葬", "家相", "下層"),
    "かたい": ("硬い", "固い", "堅い"),
    "かたき": ("敵", "仇"),
    "かたん": ("加担", "下端"),
    "かち": ("勝ち", "価値"),
    "かちょう": ("課長", "家長"),
    "かっき": ("活気", "画期"),
    "かっこ": ("括弧", "確固", "各個"),
    "かっぱ": ("合羽", "河童"),
    "かつら": ("桂", "鬘"),
    "かてい": ("家庭", "過程", "仮定"),
    "かどう": ("稼働", "華道", "可動"),
    "かなう": ("叶う", "適う"),
}

# 表記 → 読みの逆引き。表記が 2 つの読みに現れることは無い
# （モジュール末尾で検査し、テストでも固定する）。
SURFACE_TO_READING: dict[str, str] = {}
for _reading, _surfaces in TABLE.items():
    for _surface in _surfaces:
        SURFACE_TO_READING[_surface] = _reading


# ---------------------------------------------------------------- 出現


@dataclass(frozen=True)
class Occurrence:
    """本文に出てきた同音異義語 1 件。

    candidates は候補の表記（好みの順）。index は同じ表記が
    複数回出てくるときの通し番号（0 始まり）で、「n 番目の
    出現だけ差し替える」ために使う。
    """
    start: int
    end: int
    surface: str
    reading: str
    candidates: tuple[str, ...]
    index: int


def order_candidates(reading: str,
                     preferred: str = "") -> tuple[str, ...]:
    """候補の並び。好みの表記があれば先頭へ。"""
    surfaces = TABLE.get(reading, ())
    if preferred and preferred in surfaces:
        return (preferred,) + tuple(s for s in surfaces
                                     if s != preferred)
    return tuple(surfaces)


def find_occurrences(text: str,
                     prefs: "Prefs | None" = None) -> list[Occurrence]:
    """本文から同音異義語の表記を探す（出現順）。

    長い表記から先に押さえる。「会場」の中の「会」のような
    部分一致を、別の語の出現として二重に数えないため。
    """
    if not text:
        return []
    surfaces = sorted(SURFACE_TO_READING, key=len, reverse=True)
    found: list[tuple[int, int, str]] = []
    occupied = [False] * len(text)
    for surface in surfaces:
        start = text.find(surface)
        while start >= 0:
            end = start + len(surface)
            if not any(occupied[start:end]):
                for i in range(start, end):
                    occupied[i] = True
                found.append((start, end, surface))
            start = text.find(surface, start + 1)
    found.sort()
    counts: dict[str, int] = {}
    out: list[Occurrence] = []
    for start, end, surface in found:
        reading = SURFACE_TO_READING[surface]
        index = counts.get(surface, 0)
        counts[surface] = index + 1
        preferred = prefs.preferred(reading) if prefs else ""
        out.append(Occurrence(
            start=start, end=end, surface=surface, reading=reading,
            candidates=order_candidates(reading, preferred),
            index=index))
    return out


def replace_occurrence(text: str, occ: Occurrence,
                       new_surface: str) -> str:
    """出現 1 件（occ の位置）だけを差し替えた本文を返す。

    位置が本文と合っていない（編集でずれた）ときは、index 番目の
    出現を探し直す。それも無ければ本文をそのまま返す。
    """
    if new_surface not in TABLE.get(occ.reading, ()):
        return text
    if text[occ.start:occ.end] == occ.surface:
        return text[:occ.start] + new_surface + text[occ.end:]
    seen = 0
    start = text.find(occ.surface)
    while start >= 0:
        if seen == occ.index:
            return (text[:start] + new_surface
                    + text[start + len(occ.surface):])
        seen += 1
        start = text.find(occ.surface, start + 1)
    return text


# ---------------------------------------------------------------- 好み


class Prefs:
    """読みごとに「前回選んだ表記」を覚える小さな保存。

    辞書（Dictionary）と同じ流儀で、ファイルが変わっていたら
    読み直す。保存先はアプリホームの data/homophone_prefs.json。
    """

    def __init__(self, path: Path = PREFS_PATH) -> None:
        self.path = path
        self._lock = threading.Lock()
        self._mtime = -1.0
        self._prefs: dict[str, str] = {}
        self.reload(force=True)

    def reload(self, *, force: bool = False) -> bool:
        try:
            mtime = self.path.stat().st_mtime
        except OSError:
            if force:
                self._prefs = {}
            return False
        if not force and mtime == self._mtime:
            return False
        self._mtime = mtime
        try:
            data = json.loads(self.path.read_text("utf-8"))
            prefs = data.get("prefs", {}) if isinstance(data, dict) else {}
            self._prefs = {str(k): str(v) for k, v in prefs.items()
                           if k in TABLE and v in TABLE.get(k, ())}
        except Exception:
            log.exception("同音異義語の好みを読めませんでした")
            self._prefs = {}
            return False
        return True

    def preferred(self, reading: str) -> str:
        """その読みで前回選んだ表記（無ければ空）。"""
        self.reload()
        return self._prefs.get(reading, "")

    def choose(self, reading: str, surface: str) -> None:
        """差し替えで選んだ表記を、その読みの好みとして記録する。"""
        if surface not in TABLE.get(reading, ()):
            return
        with self._lock:
            self.reload()
            if self._prefs.get(reading) == surface:
                return
            self._prefs[reading] = surface
            self._save()

    def _save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".json.tmp")
            tmp.write_text(
                json.dumps({"prefs": self._prefs},
                           ensure_ascii=False, indent=1), "utf-8")
            tmp.replace(self.path)
            self._mtime = self.path.stat().st_mtime
        except OSError:
            log.exception("同音異義語の好みを保存できませんでした")
