"""テストから操作を流し込むための台本。

**本物のキーを送らずに**、アプリ本体の処理を端から端まで動かすための仕組み。
`KOE_TYPE_TEST_SCRIPT` に台本ファイルのパスを入れて起動すると、
書いてある時刻に、ショートカットを押したのと同じ操作を内側から起こす。

これがないと、録音を始めさせるために本物の Ctrl+Space を送るしかなく、
過去に起きた「利用者の LINE や Vivaldi に文字が入る」事故につながる。

**から打ちモード（KOE_TYPE_DRY_RUN=1）でないと動かない。**
うっかり本番で台本が動いてしまわないようにするため。

台本の書き方（JSON）

    [
      {"at": 0.4, "event": "hotkey_down"},
      {"at": 6.0, "event": "stop"},
      {"at": 9.0, "event": "quit"}
    ]

`at` は起動からの秒数。`event` は control スレッドが受け取る操作名
（hotkey_down / hotkey_up / stop / send / cancel / repaste / click_stop /
focus_changed / silence / quit）と、トレイのメニュー（menu:settings など）。

`at` と `event` 以外のキーは、そのまま操作の引数として渡される。

    {"at": 3.0, "event": "focus_changed", "hwnd": 12345}
"""

from __future__ import annotations

import json
import logging
import os
import threading
import time
from pathlib import Path

from . import dryrun

log = logging.getLogger(__name__)

_ENV = "KOE_TYPE_TEST_SCRIPT"


def script_path() -> Path | None:
    raw = os.environ.get(_ENV, "")
    if not raw:
        return None
    if not dryrun.enabled():
        log.error("台本は、から打ちモード（%s=1）でないと動かしません",
                  dryrun._ENV)
        return None
    path = Path(raw)
    if not path.is_file():
        log.error("台本が見つかりません: %s", path)
        return None
    return path


def load() -> list[dict]:
    path = script_path()
    if path is None:
        return []
    try:
        rows = json.loads(path.read_text("utf-8"))
    except Exception:
        log.exception("台本を読めません: %s", path)
        return []
    if not isinstance(rows, list):
        log.error("台本は配列で書いてください")
        return []
    out = []
    for row in rows:
        if isinstance(row, dict) and row.get("event"):
            extra = {k: v for k, v in row.items()
                     if k not in ("at", "event")}
            out.append({"at": float(row.get("at", 0.0)),
                        "event": str(row["event"]), "kw": extra})
    out.sort(key=lambda r: r["at"])
    return out


def start(post, quit_fn) -> threading.Thread | None:  # noqa: ANN001
    """台本があれば、それを流すスレッドを始める。

    post(event, **kw) は Controller._post。quit_fn は終了処理。
    """
    rows = load()
    if not rows:
        return None
    log.warning("テストの台本で動かします（%d 手）", len(rows))
    dryrun.record("script", steps=len(rows))

    def run() -> None:
        begin = time.monotonic()
        for row in rows:
            delay = row["at"] - (time.monotonic() - begin)
            if delay > 0:
                time.sleep(delay)
            event = row["event"]
            log.info("台本: %.2fs %s", row["at"], event)
            dryrun.record("event", event=event, at=row["at"])
            if event == "quit":
                quit_fn()
                return
            if event.startswith("menu:"):
                post("menu", name=event[5:])
            elif event == "focus_changed":
                # 本物の前面の窓は変わっていない。模擬だと伝えて、
                # 「まだ元の窓のまま」と見なされないようにする。
                post(event, simulated=True, **row.get("kw", {}))
            else:
                post(event, **row.get("kw", {}))
        log.info("台本が終わりました")

    thread = threading.Thread(target=run, name="testdrive", daemon=True)
    thread.start()
    return thread
