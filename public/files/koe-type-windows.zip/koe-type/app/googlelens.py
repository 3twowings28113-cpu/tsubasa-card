"""Google アプリ（PC版）の Google レンズ連携の土台。

かこって検索の検索そのものは、画像検索の質で自前実装が本家に
追いつけないため、Google アプリのレンズに任せる方針にした
（2026-10-25 の方針転換。経緯は GOOGLE_LENS_PIVOT.md）。
ただし全面依存はしない。内蔵版（app/snipping.py）は受け皿として
残し、設定 `snip_engine` が "google" のときにこちらへ回す。
既定は "google"（2026-10-25 に既定化）。Google アプリが無いときは
呼び出し側（main）が内蔵版を開く。

このファイルにあるのは「土台」だけ:

  ・入っているか / 動いているかの検出
  ・未導入のときに公式インストーラを落として入れる
  ・入っていて動いていないときに裏で起動する
  ・レンズ用のショートカットを送る（設定されているときだけ）

★インストーラは必ず「タグ付き URL」から落とすこと。
タグ無しの素の URL でもファイルは落ちるが、実行すると終了コード
75009 で即失敗し何も入らない（2026-10-25 AI PC 実機で確認）。
サーバがダウンロード時に Omaha タグをファイル末尾へ刻印する
方式で、素のファイルは「どのアプリを入れるか」を持たないため。
URL の組み立ては、実機で導入に成功したものをそのまま再現する
（末尾に appguid がもう一度付く形も含め、勝手に整形しない）。

★レンズ直行ショートカットの既定の組み合わせは
`ctrl+alt+shift+l`。利用者の Google アプリはこの組み合わせで
レンズが開く構成になっており、実地で動作している（2026-10-25）。
設定 `google_lens_hotkey` で変更できる: Google アプリ側の
レンズ用ショートカットを変えたら、こちらも合わせること。
空にしたときはキー送信をしない（合っていないキーを他アプリへ
送る事故につながるため）。

★OS に触る処理は小さな関数に分け、winreg / WinDLL は
関数の中で遅れて読む。単体テスト（Linux でも動く）では
それらを差し替えて、実際のレジストリ・プロセス・キー送信を
一切起こさない（AGENTS.md の自動テストの決まり）。
"""

from __future__ import annotations

import enum
import logging
import os
import subprocess
import time
import urllib.parse
import uuid
from pathlib import Path

from .util import DATA_DIR

log = logging.getLogger(__name__)

# ------------------------------------------------------------ 定数

# Google アプリのアプリ GUID（実機の登録情報から確定）。
APP_GUID = "{06A8089E-0B65-445D-B5C4-10B0D1B540F2}"
# 導入の目印になるレジストリ（どちらも HKCU、ユーザー単位導入）。
APP_REG_KEY = r"Software\Google\Google"
UNINSTALL_REG_KEY = (
    r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
    r"\{06a8089e-0b65-445d-b5c4-10b0d1b540f2}")
# 実行ファイルは %LOCALAPPDATA% からの相対位置で決まる。
EXE_RELATIVE = Path("Google") / "Google" / "latest" / "google.exe"
PROCESS_NAME = "google.exe"
INSTALLER_NAME = "GoogleAppInstaller.exe"
_DOWNLOAD_BASE = "https://dl.google.com/tag/s"
_DOWNLOAD_TAIL = "windows-google-app/GoogleAppInstaller.exe"
# タグの中身のうち実証で使った固定値（lang / browser も含め、
# 成功した組み合わせを変えない）。
_TAG_LANG = "en"
_TAG_BROWSER = "4"
# 修飾キーの並び順（app/hotkeys.py の MODS と同じ順にそろえる）。
_MOD_ORDER = ("ctrl", "shift", "alt", "win")


class LensStatus(enum.Enum):
    """open_lens() の結果。呼び出し側はこれで表示を分ける。"""

    NOT_INSTALLED = "not_installed"
    NOT_RUNNING_THEN_LAUNCHED = "not_running_then_launched"
    HOTKEY_NOT_CONFIGURED = "hotkey_not_configured"
    READY = "ready"
    # 起動を試みたが失敗した。「起動した」と偽らないための別状態。
    LAUNCH_FAILED = "launch_failed"


# ------------------------------------------------------------ 検出

def _local_app_data() -> Path:
    """%LOCALAPPDATA% の場所。環境変数が無ければ推定する。"""
    base = os.environ.get("LOCALAPPDATA", "")
    if base:
        return Path(base)
    return Path.home() / "AppData" / "Local"


def exe_path() -> Path:
    """Google アプリ本体（google.exe）の場所。"""
    return _local_app_data() / EXE_RELATIVE


def _registry_installed() -> bool:
    """HKCU\\Software\\Google\\Google の installed=1 を見る。

    winreg は関数の中で読む（Linux のテスト環境でもこの
    モジュールを import できるようにするため。app/selfcheck.py
    の遅延 import と同じ流儀）。
    """
    try:
        import winreg  # noqa: PLC0415
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            APP_REG_KEY) as key:
            value, _ = winreg.QueryValueEx(key, "installed")
        return value in (1, "1")
    except Exception:  # noqa: BLE001
        return False


def _uninstall_key_exists() -> bool:
    """アンインストール登録のキーがあるかを見る（検出の補助）。"""
    try:
        import winreg  # noqa: PLC0415
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            UNINSTALL_REG_KEY):
            return True
    except Exception:  # noqa: BLE001
        return False


def _exe_exists() -> bool:
    """実行ファイルそのものがあるかを見る（検出の最後の補助）。"""
    try:
        return exe_path().is_file()
    except OSError:
        return False


def is_installed() -> bool:
    """Google アプリが入っているか。

    レジストリ 2 か所と実行ファイルの有無のどれか 1 つでも
    当たれば「入っている」とする。レジストリだけに頼ると、
    登録が欠けた導入でも見逃すため（実機検証の提案どおり）。
    """
    return bool(_registry_installed() or _uninstall_key_exists()
                or _exe_exists())


def _running_exe_names() -> set[str]:
    """いま動いているプロセスの実行ファイル名（小文字）。

    app/winthread.py の running_exes() と同じく、kernel32 の
    Toolhelp スナップショットだけを使う（新しい依存を増やさない、
    低レベルフックも使わない）。WinDLL は関数の中で作るので、
    Windows でない環境では空集合を返すだけになる。
    """
    try:
        import ctypes  # noqa: PLC0415
        from ctypes import wintypes  # noqa: PLC0415

        class _Entry(ctypes.Structure):
            _fields_ = [
                ("dwSize", wintypes.DWORD),
                ("cntUsage", wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
                ("th32ModuleID", wintypes.DWORD),
                ("cntThreads", wintypes.DWORD),
                ("th32ParentProcessID", wintypes.DWORD),
                ("pcPriClassBase", wintypes.LONG),
                ("dwFlags", wintypes.DWORD),
                ("szExeFile", ctypes.c_char * 260),
            ]

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel32.CreateToolhelp32Snapshot.argtypes = [
            wintypes.DWORD, wintypes.DWORD]
        kernel32.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        kernel32.Process32First.argtypes = [
            wintypes.HANDLE, ctypes.POINTER(_Entry)]
        kernel32.Process32Next.argtypes = [
            wintypes.HANDLE, ctypes.POINTER(_Entry)]
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        snapshot = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
        if not snapshot or snapshot == wintypes.HANDLE(-1).value:
            return set()
        out: set[str] = set()
        try:
            entry = _Entry()
            entry.dwSize = ctypes.sizeof(_Entry)
            if not kernel32.Process32First(snapshot,
                                           ctypes.byref(entry)):
                return out
            while True:
                name = entry.szExeFile.decode("mbcs", "replace")
                if name:
                    out.add(name.lower())
                if not kernel32.Process32Next(snapshot,
                                              ctypes.byref(entry)):
                    break
        finally:
            kernel32.CloseHandle(snapshot)
        return out
    except Exception:  # noqa: BLE001
        return set()


def is_running() -> bool:
    """Google アプリが常駐しているか（プロセス名で見る）。"""
    try:
        return PROCESS_NAME in _running_exe_names()
    except Exception:  # noqa: BLE001
        return False


# ------------------------------------------------------------ 導入

def _format_iid(iid: str | None) -> str:
    """ダウンロード毎の iid を {GUID}（大文字）の形にそろえる。

    省略されたら、その都度新しい GUID を作る。固定値を使い回すと
    配布元の集計を壊す恐れがあるのと、実証でも毎回生成されていた
    ため。壊れた値が来たら黙って作り直さず ValueError にする
    （呼び出し側の間違いに早く気づくため）。
    """
    if iid is None or not str(iid).strip():
        return "{%s}" % str(uuid.uuid4()).upper()
    text = str(iid).strip().strip("{}")
    return "{%s}" % str(uuid.UUID(text)).upper()


def build_installer_url(iid: str | None = None) -> str:
    """公式インストーラのタグ付き URL を組み立てる。

    タグ無し URL はインストールが失敗する（終了コード 75009）ので
    絶対に返さない。並び順・値・二重エンコード（appname の空白）
    まで、実機で成功した URL の再現にする。
    """
    tag = (
        f"appguid={APP_GUID}"
        f"&iid={_format_iid(iid)}"
        f"&lang={_TAG_LANG}"
        f"&browser={_TAG_BROWSER}"
        "&usagestats=1"
        "&appname=Google%20App"
        "&needsadmin=False"
        "&ap=ga"
        f"&referral=google.search{APP_GUID}"
    )
    quoted = urllib.parse.quote(tag, safe="")
    return f"{_DOWNLOAD_BASE}/{quoted}/{_DOWNLOAD_TAIL}"


def installer_path() -> Path:
    """インストーラの保存先。

    利用者データの置き場所（app/util.py の DATA_DIR。KOE_TYPE_HOME
    で移せる）の下に置く。モデルやエンジンの置き場所（ROOT 側）と
    混ぜないのは、これは一度使えば要らない配布物だから。
    """
    return DATA_DIR / "google-app" / INSTALLER_NAME


def _download_file(url: str, dest: Path) -> None:
    """URL からファイルを落とす。downloads の既存の口を再利用する。

    自前で urllib を書くと、オフライン遮断（downloads.is_offline）
    や .part 経由の入れ替えといった既存の安全策から外れてしまう
    ため、app/downloads.py の _fetch に寄せる。
    """
    from . import downloads  # noqa: PLC0415
    downloads._fetch(url, dest, 0, dest.name, None, None)  # noqa: SLF001


def _run_installer(path: Path) -> int:
    """インストーラを --silent で実行し、終了コードを返す。

    --silent で GUI の確認なしに導入できることは実機で確認済み
    （約 17 秒、終了コード 0）。ユーザー単位の導入なので
    管理者権限（UAC）は要らない。
    """
    result = subprocess.run(  # noqa: S603
        [str(path), "--silent"], timeout=600, check=False)
    return int(result.returncode)


def download_and_install() -> bool:
    """公式インストーラを取得して導入する。成否を返す。

    再配布はしない。落とすのは公式 dl.google.com からで、
    導入するかどうかは呼び出し側（利用者のボタン操作）が決める。
    """
    dest = installer_path()
    try:
        _download_file(build_installer_url(), dest)
    except Exception:  # noqa: BLE001
        log.exception("Google アプリのインストーラを取得できませんでした")
        return False
    try:
        code = _run_installer(dest)
    except Exception:  # noqa: BLE001
        log.exception("Google アプリのインストーラを実行できませんでした")
        return False
    if code != 0:
        # 75009 はタグ無しファイルを実行したときの失敗コード。
        # ここで出たら URL の組み立ての退行を疑う。
        log.warning("インストーラが終了コード %d で終わりました", code)
        return False
    if not is_installed():
        log.warning("導入が終わったはずですが検出できませんでした")
        return False
    log.info("Google アプリを導入しました")
    return True


# ------------------------------------------------------------ 起動

def _start_google_app() -> bool:
    """google.exe を --start_hidden で起動する（常駐の開始）。

    引数はログオン時自動起動の Run キーに登録されているものと
    同じ。✕で閉じて常駐が落ちていても、これで肩代わりできる
    （本人が過去に踏んだ「閉じたら死ぬ」問題への恒久対策）。
    """
    try:
        subprocess.Popen(  # noqa: S603
            [str(exe_path()), "--start_hidden"],
            creationflags=0x08000000)  # CREATE_NO_WINDOW（guardian と同じ）
        return True
    except Exception:  # noqa: BLE001
        log.exception("Google アプリを起動できませんでした")
        return False


def ensure_running() -> bool:
    """入っていて止まっているなら起動する。常駐していれば True。"""
    if not is_installed():
        return False
    if is_running():
        return True
    return _start_google_app()


# ------------------------------------------- レンズのショートカット

def _hotkey_spec(source: object = None) -> str:
    """設定の置き場所（Config / dict / 文字列）から組み合わせを取る。"""
    if source is None:
        return ""
    if isinstance(source, str):
        return source
    if isinstance(source, dict):
        return str(source.get("google_lens_hotkey", "") or "")
    getter = getattr(source, "str_", None)
    if callable(getter):
        return str(getter("google_lens_hotkey", "") or "")
    getter = getattr(source, "get", None)
    if callable(getter):
        return str(getter("google_lens_hotkey", "") or "")
    return ""


def _spec_is_complete(spec: str) -> bool:
    """組み合わせとして成立しているか（本体のキーがあるか）。

    app/hotkeys.py の parse と同じ考え方: 修飾キー（Ctrl 等）
    だけでは組み合わせにならない。本体のキーが 1 つ要る。
    """
    parts = [p.strip().lower()
             for p in str(spec or "").split("+") if p.strip()]
    rest = [p for p in parts if p not in _MOD_ORDER]
    return bool(rest)


def lens_hotkey_configured(source: object = None) -> bool:
    """レンズのショートカットが設定済みか。

    空では False。そのあいだ open_lens() はキーを送らない。
    引数は設定の文字列そのもの、dict、Config のどれでもよい。
    """
    return _spec_is_complete(_hotkey_spec(source))


def _send_hotkey(spec: str) -> bool:
    """組み合わせを送る。実際の送信は app/inject.py に任せる。

    inject._send はから打ちモード（KOE_TYPE_DRY_RUN=1）では
    SendInput を一切呼ばず記録だけするので、自動テストから
    呼ばれても本物のキーは飛ばない。解決（parse）は
    app/hotkeys.py の既存のものを使う。
    """
    from . import hotkeys, inject  # noqa: PLC0415
    vk, mods = hotkeys.parse(spec)
    if not vk:
        log.warning("レンズのショートカット '%s' を読み取れません", spec)
        return False
    mod_vks = {"ctrl": inject.VK_CONTROL, "shift": inject.VK_SHIFT,
               "alt": inject.VK_MENU, "win": inject.VK_LWIN}
    keys: list[tuple[int, bool]] = []
    for name in _MOD_ORDER:
        if name in mods:
            keys.append((mod_vks[name], False))
    keys.append((vk, False))
    keys.append((vk, True))
    for name in reversed(_MOD_ORDER):
        if name in mods:
            keys.append((mod_vks[name], True))
    inject._send(*keys)  # noqa: SLF001
    return True


def open_lens(cfg: object = None, *,
              hotkey_spec: str | None = None) -> LensStatus:
    """Google レンズを開ける状態か調べ、開けるならキーを送る。

    返す状態の意味:
      NOT_INSTALLED              未導入。呼び出し側が導入案内を出す。
      HOTKEY_NOT_CONFIGURED      ショートカット未設定。キーは送らない。
      NOT_RUNNING_THEN_LAUNCHED  止まっていたので起動した。常駐が
                                 立ち上がるまでキーは送らず、この
                                 回はここまで（次回呼び出しで送る）。
      LAUNCH_FAILED              起動そのものに失敗した。
      READY                      起動中で設定もあり、キーを送った。

    未設定のときに起動まで進めないのは、送り先が決まっていない
    のに常駐だけ起こしても利用者に何も起きないため。
    """
    spec = (_hotkey_spec(cfg) if hotkey_spec is None
            else str(hotkey_spec or ""))
    if not is_installed():
        log.info("Google アプリが入っていません")
        return LensStatus.NOT_INSTALLED
    if not _spec_is_complete(spec):
        log.info("レンズのショートカットが未設定なので送りません")
        return LensStatus.HOTKEY_NOT_CONFIGURED
    if not is_running():
        if ensure_running():
            log.info("Google アプリを起動しました（キーは次回送ります）")
            return LensStatus.NOT_RUNNING_THEN_LAUNCHED
        return LensStatus.LAUNCH_FAILED
    if not _send_hotkey(spec):
        return LensStatus.HOTKEY_NOT_CONFIGURED
    return LensStatus.READY


# 常駐の立ち上がりを待つ上限と間隔（open_lens_when_ready 用）。
# 上限は、止まっていたアプリを裏で起こしてから画面検索が
# 出るまでの体感が、Google アプリを直接使うときと大きく
# ずれない範囲に置く。
WAIT_LIMIT = 20.0    # 秒。これ以上は待たず、状態を返す
WAIT_POLL = 0.3      # 起動を見に行く間隔（秒）
WAIT_GRACE = 1.0     # プロセスが見えてから送るまでの猶予（秒）


def open_lens_when_ready(cfg: object = None, *,
                         hotkey_spec: str | None = None,
                         sleep=time.sleep,
                         now=time.monotonic) -> LensStatus:
    """open_lens() に「起動待ち」を足した、呼び出し側の入口。

    Google アプリが止まっていたら起動し、常駐が立ち上がる
    まで待ってからキーを送る。利用者から見れば「キーを
    1 回押せば画面検索が出る」で、Google アプリを直接使う
    ときと同じになる。それ以外の状態（未導入・未設定・
    起動失敗）は open_lens() の 1 回目の結果をそのまま返す。
    プロセスが見えるようになってから少し置くのは、常駐が
    ショートカットを受け付けられるようになるまでの猶予。
    上限まで待っても起動しなければ
    NOT_RUNNING_THEN_LAUNCHED を返す（知らせるのは
    呼び出し側の役目）。sleep / now はテスト用の差し替え口。
    """
    status = open_lens(cfg, hotkey_spec=hotkey_spec)
    if status is not LensStatus.NOT_RUNNING_THEN_LAUNCHED:
        return status
    deadline = now() + WAIT_LIMIT
    while now() < deadline:
        if is_running():
            sleep(WAIT_GRACE)
            return open_lens(cfg, hotkey_spec=hotkey_spec)
        sleep(WAIT_POLL)
    return LensStatus.NOT_RUNNING_THEN_LAUNCHED


__all__ = [
    "LensStatus",
    "build_installer_url",
    "download_and_install",
    "ensure_running",
    "exe_path",
    "installer_path",
    "is_installed",
    "is_running",
    "lens_hotkey_configured",
    "open_lens",
    "open_lens_when_ready",
]
