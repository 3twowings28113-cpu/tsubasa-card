"""ショートカットの解釈と、ぶつかりの警告。

「ショートカットが効かない」は、この種のアプリでいちばん多い不満。
原因はほとんど、**ほかの何かが同じキーを先に取っている**こと。
登録するときに気づけるよう、知っている組み合わせを並べて警告する。

警告するだけで、勝手に変えることはしない（利用者の選択を尊重する）。
"""

from __future__ import annotations

import ctypes
import logging
from ctypes import wintypes

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)

MODS = ("ctrl", "shift", "alt", "win")

# 日本語キーボードの特別なキー。音声入力の切り替えに向く
# （ふだん使わないのに押しやすい位置にある）。
SPECIAL_KEYS = {
    "muhenkan": (0x1D, "無変換", "Muhenkan (non-conversion)"),
    "henkan": (0x1C, "変換", "Henkan (conversion)"),
    "kana": (0x15, "かな", "Kana"),
    "hankaku": (0xF3, "半角/全角", "Hankaku/Zenkaku"),
    "capslock": (0x14, "Caps Lock", "Caps Lock"),
    "rctrl": (0xA3, "右 Ctrl", "Right Ctrl"),
    "rshift": (0xA1, "右 Shift", "Right Shift"),
    "ralt": (0xA5, "右 Alt", "Right Alt"),
    "f13": (0x7C, "F13", "F13"),
    "scrolllock": (0x91, "Scroll Lock", "Scroll Lock"),
    "pause": (0x13, "Pause", "Pause"),
}

# Windows が握っていて、横取りできない（または横取りすると困る）組み合わせ。
RESERVED = {
    "win+l": ("bad", "Windows の画面ロックです。横取りできません。",
              "This locks Windows and cannot be intercepted."),
    "win+d": ("bad", "デスクトップの表示です。横取りできません。",
              "This shows the desktop and cannot be intercepted."),
    "ctrl+alt+delete": ("bad", "Windows が独占しています。使えません。",
                        "Windows owns this combination."),
    "win+tab": ("bad", "タスクビューです。横取りできません。",
                "Task view; cannot be intercepted."),
    "alt+tab": ("bad", "窓の切り替えです。横取りできません。",
                "Window switching; cannot be intercepted."),
    "win+h": ("warn", "Windows 標準の音声入力と同じです。両方が反応します。",
              "Same as Windows' own dictation; both will trigger."),
    "win+v": ("warn", "クリップボードの履歴と同じです。",
              "Same as the clipboard history."),
    "win+space": ("warn", "入力方式（IME）の切り替えと同じです。",
                  "Same as switching the input method."),
    "ctrl+c": ("bad", "コピーです。使うと作業ができなくなります。",
               "This is Copy; using it would break everyday work."),
    "ctrl+v": ("bad", "貼り付けです。このアプリ自身が使います。",
               "This is Paste, which koe-type itself uses."),
    "ctrl+x": ("bad", "切り取りです。", "This is Cut."),
    "ctrl+z": ("bad", "取り消しです。", "This is Undo."),
    "ctrl+a": ("bad", "すべて選択です。", "This is Select All."),
    "ctrl+s": ("bad", "保存です。", "This is Save."),
    "enter": ("bad", "Enter そのものは使えません。",
              "Enter on its own cannot be used."),
    "esc": ("bad", "Esc そのものは、録音の中止に使われています。",
            "Esc on its own is already the cancel key."),
}

# ほかのアプリがよく使う組み合わせ。
OTHER_APPS = {
    "ctrl+l": ("warn", "Handy（常駐の音声入力）が使っています。",
               "Handy, a resident dictation app, uses this."),
    "ctrl+shift+space": ("warn", "Handy が使っています。",
                         "Handy uses this."),
    "ctrl+space": ("warn",
                   "VS Code などの入力補完と同じです。"
                   "「koe-type を使わないアプリ」に入れておけば、そのアプリでは素通りします。",
                   "Same as code completion in VS Code and similar editors. "
                   "Add those apps to the exclusion list so the shortcut "
                   "passes through there."),
    "ctrl+shift+p": ("warn", "多くのエディタのコマンド入力と同じです。",
                     "Same as the command palette in many editors."),
    "ctrl+alt+h": ("warn", "一部のアプリが使っています。",
                   "Some apps use this."),
}


def parse(spec: str) -> tuple[int, frozenset[str]]:
    """"ctrl+space" を (仮想キーコード, 修飾キーの集合) にする。"""
    parts = [p.strip().lower() for p in str(spec).split("+") if p.strip()]
    mods = {p for p in parts if p in MODS}
    rest = [p for p in parts if p not in MODS]
    key = rest[-1] if rest else ""
    return vk_of(key), frozenset(mods)


def vk_of(key: str) -> int:
    key = (key or "").strip().lower()
    if not key:
        return 0
    if key in SPECIAL_KEYS:
        return SPECIAL_KEYS[key][0]
    named = {"space": 0x20, "esc": 0x1B, "escape": 0x1B, "enter": 0x0D,
             "return": 0x0D, "tab": 0x09, "backspace": 0x08,
             "insert": 0x2D, "delete": 0x2E, "home": 0x24, "end": 0x23,
             "pageup": 0x21, "pagedown": 0x22,
             "left": 0x25, "up": 0x26, "right": 0x27, "down": 0x28}
    if key in named:
        return named[key]
    if len(key) == 1:
        return ord(key.upper())
    if key.startswith("f") and key[1:].isdigit():
        number = int(key[1:])
        if 1 <= number <= 24:
            return 0x70 + number - 1
    return 0


def normalise(spec: str) -> str:
    """"Space+Ctrl" を "ctrl+space" にそろえる（比較用）。"""
    parts = [p.strip().lower() for p in str(spec).split("+") if p.strip()]
    mods = [m for m in MODS if m in parts]
    rest = [p for p in parts if p not in MODS]
    return "+".join(mods + rest)


def label(spec: str, lang: str = "ja") -> str:
    """画面に出す表記。"ctrl+muhenkan" → "Ctrl + 無変換"。"""
    parts = [p.strip().lower() for p in str(spec).split("+") if p.strip()]
    nice = {"ctrl": "Ctrl", "shift": "Shift", "alt": "Alt", "win": "Win",
            "space": "Space", "esc": "Esc", "enter": "Enter"}
    out = []
    for p in parts:
        if p in SPECIAL_KEYS:
            out.append(SPECIAL_KEYS[p][1 if lang == "ja" else 2])
        elif p in nice:
            out.append(nice[p])
        else:
            out.append(p.upper() if len(p) == 1 else p.title())
    return " + ".join(out)


def conflicts(spec: str) -> list[tuple[str, str, str, str, str]]:
    """ぶつかりを調べる。

    返すのは (重さ, 日本語の説明, 英語の説明, 日本語の直し方, 英語の直し方)。
    重さは "bad"（使えない）か "warn"（使えるが注意）。
    """
    key = normalise(spec)
    out = []
    fix_ja = ("「一般」のページでショートカットを変えてください。"
              "無変換キーや変換キーは、ふだん使わないので向いています。")
    fix_en = ("Change the shortcut on the General page. The Muhenkan and "
              "Henkan keys on a Japanese keyboard are good choices because "
              "nothing else uses them.")
    for table in (RESERVED, OTHER_APPS):
        hit = table.get(key)
        if hit:
            out.append((hit[0], hit[1], hit[2], fix_ja, fix_en))
    vk, mods = parse(spec)
    if not vk:
        out.append(("bad", f"'{spec}' は読み取れません。",
                    f"Cannot read '{spec}'.", fix_ja, fix_en))
    elif not mods and vk not in [v[0] for v in SPECIAL_KEYS.values()]:
        out.append(("warn",
                    "修飾キー（Ctrl など）なしの 1 キーです。"
                    "ふつうの文字入力ができなくなります。",
                    "A single key with no modifier. This would block normal "
                    "typing of that key.", fix_ja, fix_en))
    return out


def suggest() -> list[tuple[str, str, str]]:
    """ぶつかりにくいおすすめ。(指定, 日本語, 英語)。"""
    return [
        ("muhenkan", "無変換キー（ぶつかりにくい）",
         "Muhenkan key (conflict-free)"),
        ("henkan", "変換キー（ぶつかりにくい）", "Henkan key (conflict-free)"),
        ("ctrl+alt+space", "Ctrl + Alt + Space", "Ctrl + Alt + Space"),
        ("ctrl+shift+d", "Ctrl + Shift + D", "Ctrl + Shift + D"),
        ("f13", "F13（あるキーボードなら）", "F13 (if your keyboard has it)"),
    ]
