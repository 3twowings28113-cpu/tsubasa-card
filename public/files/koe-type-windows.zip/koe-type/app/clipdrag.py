"""クリップボードの窓から、ほかのアプリへドラッグして渡す。

Windows のシェルの仕組みだけを使う（新しい依存は増やさない）。

  ・SHCreateDataObject で「空の入れ物」を作り、SetData で中身を入れる
    （文字なら CF_UNICODETEXT、画像やファイルなら CF_HDROP）
  ・SHDoDragDrop にドロップ元を渡さなければ、Windows が標準のものを使う。
    自前の COM オブジェクトを Python で作らずに済む

画像は、元の PNG を一時フォルダに**分かりやすい名前で**置いてから渡す。
保存用の名前（数字の羅列）のまま渡すと、アップロード先やエクスプローラー
にその名前が出てしまうため。

この処理は、マウスを実際に動かさないと最後まで試せない。自動の試験では
入れ物を作るところまで（make_data_object）を確かめる。
"""

from __future__ import annotations

import ctypes
import logging
import os
import shutil
import tempfile
import time
from ctypes import wintypes
from pathlib import Path

from . import clipdata

log = logging.getLogger(__name__)

shell32 = ctypes.WinDLL("shell32", use_last_error=True)
ole32 = ctypes.WinDLL("ole32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

_vp = ctypes.c_void_p


class GUID(ctypes.Structure):
    _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16),
                ("Data3", ctypes.c_uint16), ("Data4", ctypes.c_ubyte * 8)]


def _guid(text: str) -> GUID:
    parts = text.strip("{}").split("-")
    tail = bytes.fromhex(parts[3] + parts[4])
    return GUID(int(parts[0], 16), int(parts[1], 16), int(parts[2], 16),
                (ctypes.c_ubyte * 8)(*tail))


IID_IDataObject = _guid("0000010e-0000-0000-C000-000000000046")


class FORMATETC(ctypes.Structure):
    _fields_ = [("cfFormat", wintypes.WORD), ("ptd", _vp),
                ("dwAspect", wintypes.DWORD), ("lindex", wintypes.LONG),
                ("tymed", wintypes.DWORD)]


class STGMEDIUM(ctypes.Structure):
    _fields_ = [("tymed", wintypes.DWORD), ("hGlobal", _vp),
                ("pUnkForRelease", _vp)]


TYMED_HGLOBAL = 1
DVASPECT_CONTENT = 1
DROPEFFECT_NONE, DROPEFFECT_COPY = 0, 1
DROPEFFECT_MOVE, DROPEFFECT_LINK = 2, 4
DRAGDROP_S_DROP = 0x00040100
DRAGDROP_S_CANCEL = 0x00040101

shell32.SHCreateDataObject.argtypes = [_vp, wintypes.UINT, _vp, _vp,
                                       ctypes.POINTER(GUID),
                                       ctypes.POINTER(_vp)]
shell32.SHCreateDataObject.restype = ctypes.c_long
shell32.SHDoDragDrop.argtypes = [wintypes.HWND, _vp, _vp, wintypes.DWORD,
                                 ctypes.POINTER(wintypes.DWORD)]
shell32.SHDoDragDrop.restype = ctypes.c_long
ole32.OleInitialize.argtypes = [_vp]
ole32.OleInitialize.restype = ctypes.c_long
ole32.OleUninitialize.argtypes = []
kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
kernel32.GlobalAlloc.restype = _vp
kernel32.GlobalLock.argtypes = [_vp]
kernel32.GlobalLock.restype = _vp
kernel32.GlobalUnlock.argtypes = [_vp]
kernel32.GlobalFree.argtypes = [_vp]
kernel32.GlobalFree.restype = _vp

DRAG_DIR = Path(tempfile.gettempdir()) / "koe-type-drag"


def _method(obj: _vp, index: int, restype, *argtypes):  # noqa: ANN001, ANN202
    """COM の vtable から index 番目の関数を取り出す。"""
    vtbl = ctypes.cast(obj, ctypes.POINTER(ctypes.POINTER(_vp))).contents
    proto = ctypes.WINFUNCTYPE(restype, _vp, *argtypes)
    return proto(vtbl[index])


def _release(obj: _vp) -> None:
    if obj:
        _method(obj, 2, ctypes.c_ulong)(obj)


def _set_hglobal(obj: _vp, cf: int, data: bytes) -> bool:
    """IDataObject::SetData（vtable の 7 番目）で中身を 1 つ入れる。"""
    if not cf:
        return False
    handle = kernel32.GlobalAlloc(0x0002, max(1, len(data)))
    if not handle:
        return False
    ptr = kernel32.GlobalLock(handle)
    if not ptr:
        kernel32.GlobalFree(handle)
        return False
    ctypes.memmove(ptr, data, len(data))
    kernel32.GlobalUnlock(handle)
    fmt = FORMATETC(cf, None, DVASPECT_CONTENT, -1, TYMED_HGLOBAL)
    medium = STGMEDIUM(TYMED_HGLOBAL, handle, None)
    set_data = _method(obj, 7, ctypes.c_long, ctypes.POINTER(FORMATETC),
                       ctypes.POINTER(STGMEDIUM), wintypes.BOOL)
    # fRelease=TRUE：入れ物が handle を受け持つ（こちらでは解放しない）
    hr = set_data(obj, ctypes.byref(fmt), ctypes.byref(medium), True)
    if hr != 0:
        kernel32.GlobalFree(handle)
        log.debug("SetData に失敗 cf=%d hr=%#x", cf, hr & 0xFFFFFFFF)
        return False
    return True


def init_thread() -> bool:
    """このスレッドで OLE を使えるようにする（ドラッグに要る）。"""
    hr = ole32.OleInitialize(None)
    # S_OK / S_FALSE（すでに初期化済み）なら使える
    return hr in (0, 1)


def done_thread() -> None:
    try:
        ole32.OleUninitialize()
    except Exception:
        pass


def friendly_copy(src: Path, name: str) -> Path | None:
    """渡すための、分かりやすい名前の写し。同じドライブならリンクで済ます。"""
    try:
        DRAG_DIR.mkdir(parents=True, exist_ok=True)
        dest = DRAG_DIR / name
        if dest.exists():
            dest.unlink()
        try:
            os.link(src, dest)
        except OSError:
            shutil.copy2(src, dest)
        return dest
    except OSError:
        log.exception("ドラッグ用の写しを作れませんでした")
        return None


def clean_drag_dir(older_than: float = 3600.0) -> None:
    """前に渡した写しを片付ける（相手が読み終わったあとで）。"""
    if not DRAG_DIR.is_dir():
        return
    limit = time.time() - older_than
    for path in DRAG_DIR.iterdir():
        try:
            if path.stat().st_mtime < limit:
                path.unlink()
        except OSError:
            pass


def make_data_object(*, text: str | None = None,
                     files: list[str] | None = None) -> _vp | None:
    """渡す中身を入れた IDataObject を作る。使い終わったら release()。"""
    obj = _vp()
    hr = shell32.SHCreateDataObject(None, 0, None, None,
                                    ctypes.byref(IID_IDataObject),
                                    ctypes.byref(obj))
    if hr != 0 or not obj:
        log.warning("ドラッグの入れ物を作れません hr=%#x", hr & 0xFFFFFFFF)
        return None
    ok = False
    if files:
        ok = _set_hglobal(obj, clipdata.CF_HDROP, clipdata.hdrop(files))
        _set_hglobal(obj, clipdata.fmt("Preferred DropEffect"),
                     (DROPEFFECT_COPY).to_bytes(4, "little"))
    if text is not None:
        ok = _set_hglobal(obj, clipdata.CF_UNICODETEXT,
                          text.encode("utf-16-le") + b"\x00\x00") or ok
    if not ok:
        _release(obj)
        return None
    return obj


def release(obj: _vp | None) -> None:
    _release(obj)


def _do_drag_drop(hwnd: int, obj: _vp, allowed: int) -> tuple[int, int]:
    """SHDoDragDrop を呼び、(戻り値, 決まった効果) を返す。

    効果を受け取る DWORD は呼び出しの前にこちらで用意し、その
    ポインタを渡す（以前は未定義の名前 effect を渡していて、
    ドラッグを始めるたびに NameError で死に、窓からのドラッグは
    全面的に動いていなかった）。テストではこの関数を差し替える。
    """
    effect = wintypes.DWORD(DROPEFFECT_NONE)
    hr = shell32.SHDoDragDrop(hwnd, obj, None, allowed,
                               ctypes.byref(effect))
    return hr, int(effect.value)


def drag(hwnd: int, *, text: str | None = None,
         files: list[str] | None = None) -> str:
    """ドラッグを始め、離されるまで待つ。"dropped" / "cancelled" / "error"。

    SHDoDragDrop は離されるまで戻らない（その間もメッセージは回る）。
    """
    obj = make_data_object(text=text, files=files)
    if obj is None:
        return "error"
    try:
        ok_effects = DROPEFFECT_COPY | DROPEFFECT_MOVE | DROPEFFECT_LINK
        hr, effect = _do_drag_drop(hwnd, obj, ok_effects)
        if hr == DRAGDROP_S_DROP and effect != DROPEFFECT_NONE:
            return "dropped"
        if hr in (DRAGDROP_S_CANCEL, DRAGDROP_S_DROP, 0):
            return "cancelled"
        log.warning("ドラッグに失敗 hr=%#x", hr & 0xFFFFFFFF)
        return "error"
    finally:
        _release(obj)
