"""履歴クイックピッカーと、録音キーの二度押し判定。

利用者の困りごと（2026-10-26）: 音声入力したのに文字が入力欄へ
入らなかったことがたまにあり、そのたびにアプリを開いて履歴から
コピーし直すのが面倒。そこで

  ・録音キーを押してから 400ms 以内に**もう一度**押したら、
    いまのテイクは捨てて（履歴にも残さない）、
  ・最近の文字起こしを小さな一覧で出し、
  ・選んだらその場へ貼れる

ようにした。二度押しの判定（DoubleTapGate）は判断だけの純粋な
部品にして、テストで固定する。窓はこのモジュールが専用スレッドで
開く（呼び出し側は結果の文字列だけを受け取る）。

キー入力の扱いは、**自分の窓のメッセージループの中だけ**で見る。
低レベルフックは使わない（AGENTS.md の決まり。PC 全体の入力を
止めかねないため）。
"""

from __future__ import annotations

import ctypes
import logging
import threading
import time
from ctypes import wintypes

from . import dryrun

# snipping.py と同じ互換シム（標準 ctypes.wintypes に HCURSOR が無い）
if not hasattr(wintypes, "HCURSOR"):
    wintypes.HCURSOR = wintypes.HANDLE  # type: ignore[attr-defined]

log = logging.getLogger(__name__)


# ---------------------------------------------------------------- 判定

class DoubleTapGate:
    """録音キーの二度押し判定（状態機械）。

    1 回目の押下では**従来どおり即座に録音が始まる**（開始を遅らせて
    二度押しを待つ作りにはしない。それだと全ての録音開始が遅れる）。
    録音開始から `window` 秒以内に 2 回目が来たときだけ、それを
    「停止」ではなく「テイクを捨てて履歴を開く合図」と解釈する。

    判定は 1 回だけ消費する。3 回目の押下を誤って拾わないため。
    長い録音のあとの 2 回目（通常の停止）は、開始時刻が古いので
    決して引っかからない。
    """

    def __init__(self, window: float = 0.4) -> None:
        self.window = max(0.0, window)
        self._started_at: float | None = None

    def note_start(self, now: float) -> None:
        """メインの録音キーで録音が始まったときに呼ぶ。"""
        self._started_at = now

    def clear(self) -> None:
        self._started_at = None

    def classify(self, now: float, *, recording: bool,
                 enabled: bool) -> bool:
        """いまの押下が「二度押し（ピッカーを開く）」かどうか。

        True を返したときだけ、その押下は停止として扱わず、
        呼び出し側がテイク破棄＋ピッカー表示を行う。
        """
        if not recording or not enabled:
            return False
        if self._started_at is None:
            return False
        # 時刻の差は浮動小数でわずかに膨らむ（0.40 が 0.4000000000000057
        # になる）ので、境界ちょうどを「以内」に含めるため余裕を見る。
        if now - self._started_at > self.window + 1e-9:
            return False          # ふつうの停止。開始記録は残す
        self._started_at = None   # 消費する
        return True


# ---------------------------------------------------------------- 窓

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

_CLASS_NAME = "KoeTypeHistoryPicker"

WS_POPUP = 0x80000000
WS_VISIBLE = 0x10000000
WS_CHILD = 0x40000000
WS_BORDER = 0x00800000
WS_TABSTOP = 0x00010000
BS_LEFT = 0x00000100
WS_EX_TOPMOST = 0x00000008
WS_EX_TOOLWINDOW = 0x00000080
SW_SHOW = 5

WM_CREATE = 0x0001
WM_DESTROY = 0x0002
WM_ACTIVATE = 0x0006
WM_CLOSE = 0x0010
WM_SETFONT = 0x0030
WM_KEYDOWN = 0x0100
WM_COMMAND = 0x0111
WM_SYSKEYDOWN = 0x0104

VK_ESCAPE = 0x1B
VK_RETURN = 0x0D
VK_F2 = 0x71
VK_UP = 0x26
VK_DOWN = 0x28
VK_0 = 0x30
VK_1 = 0x31
VK_9 = 0x39

BN_CLICKED = 0
BN_SETFOCUS = 4
WA_INACTIVE = 0

_MAX_ITEMS = 10
_BTN_BASE = 1000

WNDPROC = ctypes.WINFUNCTYPE(
    ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
    wintypes.WPARAM, wintypes.LPARAM)


class _WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("style", wintypes.UINT),
        ("lpfnWndProc", ctypes.c_void_p),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HCURSOR),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HICON),
    ]


class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


class _MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", _RECT),
                ("rcWork", _RECT), ("dwFlags", wintypes.DWORD)]


class _MSG(ctypes.Structure):
    _fields_ = [("hwnd", wintypes.HWND), ("message", wintypes.UINT),
                ("wParam", wintypes.WPARAM), ("lParam", wintypes.LPARAM),
                ("time", wintypes.DWORD), ("pt", _POINT)]


# 64bit 環境でハンドルが切り捨てられないよう、使う関数には宣言を付ける
# （snipping.py の教訓: 宣言なしだと HWND が化けて無言で失敗する）。
user32.DefWindowProcW.restype = ctypes.c_ssize_t
user32.DefWindowProcW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.CreateWindowExW.restype = wintypes.HWND
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HANDLE, wintypes.HINSTANCE, ctypes.c_void_p]
user32.RegisterClassExW.restype = wintypes.ATOM
user32.RegisterClassExW.argtypes = [ctypes.POINTER(_WNDCLASSEXW)]
user32.GetMessageW.restype = wintypes.BOOL
user32.GetMessageW.argtypes = [
    ctypes.c_void_p, wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.TranslateMessage.restype = wintypes.BOOL
user32.TranslateMessage.argtypes = [ctypes.c_void_p]
user32.DispatchMessageW.restype = ctypes.c_ssize_t
user32.DispatchMessageW.argtypes = [ctypes.c_void_p]
user32.DestroyWindow.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [wintypes.HWND]
user32.PostQuitMessage.restype = None
user32.PostQuitMessage.argtypes = [ctypes.c_int]
user32.PostMessageW.restype = wintypes.BOOL
user32.PostMessageW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.SendMessageW.restype = ctypes.c_ssize_t
user32.SendMessageW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.ShowWindow.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.SetForegroundWindow.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.SetFocus.restype = wintypes.HWND
user32.SetFocus.argtypes = [wintypes.HWND]
user32.GetCursorPos.restype = wintypes.BOOL
user32.GetCursorPos.argtypes = [ctypes.POINTER(_POINT)]
user32.MonitorFromPoint.restype = wintypes.HANDLE
user32.MonitorFromPoint.argtypes = [_POINT, wintypes.DWORD]
user32.GetMonitorInfoW.restype = wintypes.BOOL
user32.GetMonitorInfoW.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(_MONITORINFO)]
user32.LoadCursorW.restype = wintypes.HCURSOR
user32.LoadCursorW.argtypes = [wintypes.HINSTANCE, wintypes.LPCWSTR]
kernel32.GetModuleHandleW.restype = wintypes.HINSTANCE
kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
gdi32.CreateFontW.restype = wintypes.HFONT
gdi32.CreateFontW.argtypes = [
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
    wintypes.LPCWSTR]
gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.DeleteObject.argtypes = [ctypes.c_void_p]

_active: "_Picker | None" = None
_registered = False
_open_lock = threading.Lock()


def _global_proc(hwnd: int, msg: int, wparam: int, lparam: int) -> int:
    if _active is not None:
        return _active._proc(hwnd, msg, wparam, lparam)
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


_static_proc = WNDPROC(_global_proc)


def _preview(text: str) -> str:
    """一覧の 1 行に出す形（改行を潰し、長いものは切る）。"""
    flat = " ".join(text.split())
    if len(flat) > 56:
        flat = flat[:56] + "…"
    # ボタンの文字では & がニーモニック扱いになるので二重にする
    return flat.replace("&", "&&")


def _ui_scale() -> float:
    """画面の拡大率（snipping.py と同じ考え方、範囲もそろえる）。"""
    try:
        get_dpi = getattr(user32, "GetDpiForSystem", None)
        if get_dpi is not None:
            dpi = int(get_dpi())
            if dpi > 0:
                return max(1.0, min(2.5, dpi / 96.0))
    except Exception:
        pass
    return 1.0


class _Picker:
    def __init__(self, entries: list[tuple[str, float]], title: str) -> None:
        self.entries = entries[:_MAX_ITEMS]
        self.title = title
        self.result: str | None = None
        self.action = "pick"        # pick（貼る）/ edit（直す）
        self.selected = 0
        self._hwnd = 0
        self._buttons: list[int] = []
        self._font = 0
        self._done = False
        self._shown_at = 0.0

    # ------------------------------------------------------------ 開く

    def run(self) -> str | None:
        global _registered
        scale = _ui_scale()
        row_h = int(30 * scale)
        title_h = int(26 * scale)
        width = int(620 * scale)
        height = title_h + row_h * len(self.entries) + int(10 * scale)

        if not _registered:
            wc = _WNDCLASSEXW()
            wc.cbSize = ctypes.sizeof(_WNDCLASSEXW)
            wc.style = 0x0002 | 0x0001          # CS_HREDRAW | CS_VREDRAW
            wc.lpfnWndProc = ctypes.cast(_static_proc, ctypes.c_void_p)
            wc.hInstance = kernel32.GetModuleHandleW(None)
            wc.hCursor = user32.LoadCursorW(
                None, ctypes.cast(32512, wintypes.LPCWSTR))  # IDC_ARROW
            wc.hbrBackground = ctypes.c_void_p(5 + 1)        # COLOR_WINDOW
            wc.lpszClassName = _CLASS_NAME
            if user32.RegisterClassExW(ctypes.byref(wc)):
                _registered = True

        x, y = self._place(width, height)
        hwnd = user32.CreateWindowExW(
            WS_EX_TOPMOST | WS_EX_TOOLWINDOW, _CLASS_NAME, self.title,
            WS_POPUP | WS_BORDER | WS_VISIBLE, x, y, width, height,
            0, 0, kernel32.GetModuleHandleW(None), None)
        if not hwnd:
            log.warning("履歴ピッカーの窓を作れませんでした")
            return None
        self._hwnd = hwnd
        self._build_children(scale, width, title_h, row_h)
        user32.ShowWindow(hwnd, SW_SHOW)
        user32.SetForegroundWindow(hwnd)
        if self._buttons:
            user32.SetFocus(self._buttons[0])
        self._shown_at = time.monotonic()

        msg = _MSG()
        while user32.GetMessageW(ctypes.byref(msg), 0, 0, 0) > 0:
            if (msg.message in (WM_KEYDOWN, WM_SYSKEYDOWN)
                    and self._is_ours(msg.hwnd)
                    and self._on_key(int(msg.wParam))):
                continue            # 自分で処理したキーは流さない
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        if self._font:
            gdi32.DeleteObject(self._font)
            self._font = 0
        return self.result

    def _place(self, width: int, height: int) -> tuple[int, int]:
        """マウスカーソルのある画面の作業領域に収まる位置。"""
        pt = _POINT()
        x, y = 0, 0
        try:
            if user32.GetCursorPos(ctypes.byref(pt)):
                x, y = pt.x + 12, pt.y + 12
                mon = user32.MonitorFromPoint(pt, 2)  # NEAREST
                info = _MONITORINFO()
                info.cbSize = ctypes.sizeof(_MONITORINFO)
                if mon and user32.GetMonitorInfoW(
                        mon, ctypes.byref(info)):
                    work = info.rcWork
                    x = max(work.left, min(x, work.right - width))
                    y = max(work.top, min(y, work.bottom - height))
        except Exception:
            log.debug("ピッカーの表示位置を決められませんでした",
                      exc_info=True)
        return x, y

    def _build_children(self, scale: float, width: int,
                        title_h: int, row_h: int) -> None:
        self._font = gdi32.CreateFontW(
            -int(14 * scale), 0, 0, 0, 400, 0, 0, 0, 1, 0, 0, 0, 0,
            "Yu Gothic UI")
        pad = int(5 * scale)
        title_hwnd = user32.CreateWindowExW(
            0, "STATIC", self.title, WS_CHILD | WS_VISIBLE,
            pad, int(4 * scale), width - pad * 2, title_h,
            self._hwnd, 0, kernel32.GetModuleHandleW(None), None)
        if title_hwnd and self._font:
            user32.SendMessageW(title_hwnd, WM_SETFONT, self._font, 1)
        for i, (text, _ts) in enumerate(self.entries):
            number = (i + 1) % 10        # 10 件目は 0
            label = f"{number}  {_preview(text)}"
            btn = user32.CreateWindowExW(
                0, "BUTTON", label,
                WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_LEFT,
                pad, title_h + i * row_h, width - pad * 2, row_h - 2,
                self._hwnd, _BTN_BASE + i,
                kernel32.GetModuleHandleW(None), None)
            if btn:
                if self._font:
                    user32.SendMessageW(btn, WM_SETFONT, self._font, 1)
                self._buttons.append(btn)

    def _is_ours(self, hwnd: int) -> bool:
        return hwnd == self._hwnd or hwnd in self._buttons

    # ------------------------------------------------------------ 操作

    def _on_key(self, vk: int) -> bool:
        """自分で処理するキー。処理したら True（既定処理へ流さない）。"""
        if vk == VK_ESCAPE:
            self._finish(None)
            return True
        if vk in (VK_UP, VK_DOWN):
            step = -1 if vk == VK_UP else 1
            self.selected = max(
                0, min(len(self.entries) - 1, self.selected + step))
            if self._buttons:
                user32.SetFocus(self._buttons[self.selected])
            return True
        if vk == VK_RETURN:
            self._finish(self.entries[self.selected][0])
            return True
        if vk == VK_F2:
            # 選ばずに「直す」へ渡す（編集ポップアップを開く合図）
            self._finish(self.entries[self.selected][0], action="edit")
            return True
        if VK_0 <= vk <= VK_9:
            index = (vk - VK_0 + 9) % 10   # 1→0番目 … 9→8番目, 0→9番目
            if index < len(self.entries):
                self._finish(self.entries[index][0])
            return True
        return False

    def _finish(self, text: str | None, *, action: str = "pick") -> None:
        if self._done:
            return
        self._done = True
        self.result = text
        self.action = action
        if self._hwnd:
            user32.DestroyWindow(self._hwnd)

    # ------------------------------------------------------------ 本体

    def _proc(self, hwnd: int, msg: int, wparam: int,
              lparam: int) -> int:
        try:
            if msg == WM_COMMAND:
                code = (int(wparam) >> 16) & 0xFFFF
                ident = int(wparam) & 0xFFFF
                if code == BN_CLICKED and _BTN_BASE <= ident < (
                        _BTN_BASE + len(self.entries)):
                    self._finish(self.entries[ident - _BTN_BASE][0])
                    return 0
                if code == BN_SETFOCUS and _BTN_BASE <= ident < (
                        _BTN_BASE + len(self.entries)):
                    self.selected = ident - _BTN_BASE
                return 0
            if msg == WM_ACTIVATE:
                # よその窓へ移ったら閉じる（選ばずに終わる）。
                # 表示直後の行き来で誤って閉じないよう少しだけ猶予。
                if ((int(wparam) & 0xFFFF) == WA_INACTIVE
                        and not self._done
                        and time.monotonic() - self._shown_at > 0.25):
                    self._finish(None)
                    return 0
                return 0
            if msg == WM_CLOSE:
                self._finish(None)
                return 0
            if msg == WM_DESTROY:
                user32.PostQuitMessage(0)
                return 0
        except Exception:
            log.exception("履歴ピッカーの処理で例外")
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


def open_picker(entries: list[tuple[str, float]], title: str) -> str | None:
    """履歴の一覧を出し、選ばれた文字を返す（閉じたら None）。"""
    got = open_picker2(entries, title)
    return got[1] if got else None


def open_picker2(entries: list[tuple[str, float]],
                 title: str) -> tuple[str, str] | None:
    """履歴の一覧を出し、(どうするか, 文字) を返す。

    どうするかは "pick"（そのまま貼る）か "edit"（直してから
    使う。F2 を押したとき）。閉じたら None。呼んだスレッドで
    メッセージループを回すので、専用スレッドから呼ぶこと。
    同時に 2 つは開かない。から打ち（テスト）では窓を一切
    開かず None を返す。
    """
    global _active
    if dryrun.enabled():
        log.info("から打ちのため履歴ピッカーは開きません")
        return None
    if not entries:
        return None
    if not _open_lock.acquire(blocking=False):
        log.info("履歴ピッカーはすでに開いています")
        return None
    try:
        picker = _Picker(entries, title)
        _active = picker
        try:
            picked = picker.run()
        finally:
            _active = None
        if picked is None:
            return None
        return picker.action, picked
    finally:
        _open_lock.release()
