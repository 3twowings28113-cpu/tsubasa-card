"""文章変換の「レシピ一覧」。ショートカットで出し、選ぶと録音が始まる。

利用者の頼み（2026-10-11）：変換ごとに専用のキーを決めるのは大変。
キー 1 つで一覧を出し、使う変換を選んで話し、録音のキーをもう一度
押したら、その変換で入力してほしい。

窓そのもの（出す場所・前面の受け渡し・IME・拡大率）は、クリップボードの
一覧と同じものを使う（app/clipwin.py の ClipService が持っている）。
ここにあるのは「中身と操作の決まり」と「見た目」だけ。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Final

from .clipgfx import FW_SEMIBOLD, Canvas, Painter, mix
from .clipmodel import (VK_BACK, VK_DELETE, VK_DOWN, VK_END, VK_ESCAPE,
                        VK_HOME, VK_LEFT, VK_NEXT, VK_PRIOR, VK_RETURN,
                        VK_RIGHT, VK_TAB, VK_UP, SearchBox, norm)
from .clipview import GLYPH, PALETTES, Box, FONT_SCALES, Layout
from .hotkeys import label as key_label
from .i18n import t

CATEGORIES: Final[tuple[tuple[str, str], ...]] = (
    ("all", "recipe.cat_all"),
    ("text", "recipe.cat_text"),
    ("tools", "recipe.cat_tools"),
)


@dataclass
class Recipe:
    id: str
    name: str
    desc: str = ""
    hotkey: str = ""
    category: str = "text"


class RecipeModel:
    """レシピの並び・検索・選択。決めるだけで、窓も録音も知らない。"""

    def __init__(self, load: Callable[[], list[Recipe]]) -> None:
        self._load = load
        self.items: list[Recipe] = []
        self.view: list[Recipe] = []
        self.sel = 0
        self.top = 0
        self.page = 6
        self.category = "all"
        self.cat_index = 0
        self.search = SearchBox()

    def open(self) -> None:
        self.items = self._load()
        self.search.clear()
        self.category = "all"
        self.cat_index = 0
        self.sel = 0
        self.top = 0
        self._filter()

    def set_category_index(self, index: int) -> None:
        if 0 <= index < len(CATEGORIES):
            self.cat_index = index
            self.category = CATEGORIES[index][0]
            self.sel = 0
            self.top = 0
            self._filter()

    def next_category(self, delta: int = 1) -> None:
        new_index = (self.cat_index + delta) % len(CATEGORIES)
        self.set_category_index(new_index)

    def _filter(self) -> None:
        cat = self.category
        if cat == "all":
            pool = self.items
        elif cat == "tools":
            pool = [r for r in self.items
                    if r.category == "tools" or r.id == "normal"]
        else:  # "text"
            pool = [r for r in self.items
                    if r.category == "text" or r.id == "normal"]

        words = norm(self.search.text).split()
        if words:
            self.view = [r for r in pool if all(
                w in norm(f"{r.name} {r.desc}") for w in words)]
        else:
            self.view = list(pool)
        self.sel = min(self.sel, max(0, len(self.view) - 1))
        self._scroll()

    def _scroll(self) -> None:
        page = max(1, self.page)
        if self.sel < self.top:
            self.top = self.sel
        elif self.sel >= self.top + page:
            self.top = self.sel - page + 1
        self.top = max(0, min(self.top, max(0, len(self.view) - page)))

    def current(self) -> Recipe | None:
        return self.view[self.sel] if 0 <= self.sel < len(self.view) else None

    def select(self, index: int) -> None:
        if self.view:
            self.sel = max(0, min(len(self.view) - 1, index))
            self._scroll()

    def scroll(self, rows: int) -> None:
        page = max(1, self.page)
        self.top = max(0, min(self.top + rows,
                              max(0, len(self.view) - page)))

    def key(self, vk: int, *, ctrl: bool = False, shift: bool = False,
            alt: bool = False) -> tuple[str, str] | None:
        """("pick", id) / ("close", "") / ("repaint", "") / None。"""
        s = self.search
        if vk == VK_ESCAPE:
            if s.text:
                s.clear()
                self._filter()
                return ("repaint", "")
            return ("close", "")
        if vk == VK_RETURN:
            item = self.current()
            return ("pick", item.id) if item else None
        if vk in (VK_UP, VK_DOWN):
            self.select(self.sel + (1 if vk == VK_DOWN else -1))
            return ("repaint", "")
        if vk in (VK_PRIOR, VK_NEXT):
            step = max(1, self.page - 1)
            self.select(self.sel + (step if vk == VK_NEXT else -step))
            return ("repaint", "")
        if vk in (VK_HOME, VK_END) and (ctrl or not s.text):
            self.select(0 if vk == VK_HOME else len(self.view) - 1)
            return ("repaint", "")
        if vk in (VK_HOME, VK_END):
            s.move(0 if vk == VK_HOME else len(s.text), shift)
            return ("repaint", "")
        if vk == VK_TAB:
            self.next_category(-1 if shift else 1)
            return ("repaint", "")
        if vk in (VK_LEFT, VK_RIGHT):
            if not s.text:
                self.next_category(-1 if vk == VK_LEFT else 1)
            elif vk == VK_LEFT:
                s.left(shift, ctrl)
            else:
                s.right(shift, ctrl)
            return ("repaint", "")
        if vk == VK_BACK:
            s.backspace(word=ctrl)
            self._filter()
            return ("repaint", "")
        if vk == VK_DELETE:
            s.delete(word=ctrl)
            self._filter()
            return ("repaint", "")
        # 1〜9：検索が空なら（または Ctrl を押していれば）その番号を選ぶ
        if 0x31 <= vk <= 0x39 and not alt and (ctrl or not s.text):
            index = vk - 0x31
            if index < len(self.view):
                return ("pick", self.view[index].id)
            return None
        if ctrl and vk == ord("A"):
            s.select_all()
            return ("repaint", "")
        return None

    def char(self, ch: str) -> bool:
        if not ch or ord(ch[0]) < 0x20 or ch == "\x7f":
            return False
        # 検索が空のときの数字は key() が選ぶ。ここでは入れない
        if not self.search.text and ch in "123456789":
            return False
        self.search.insert(ch)
        self.sel = 0
        self._filter()
        return True

    def click(self, index: int) -> tuple[str, str] | None:
        if 0 <= index < len(self.view):
            self.select(index)
            return ("pick", self.view[index].id)
        return None


@dataclass
class RecipeLayout:
    width: int = 0
    height: int = 0
    s: float = 1.0
    title: Box = field(default_factory=Box)
    tab_bar: Box = field(default_factory=Box)
    tabs: list[Box] = field(default_factory=list)
    search: Box = field(default_factory=Box)
    note: Box = field(default_factory=Box)
    listing: Box = field(default_factory=Box)
    footer: Box = field(default_factory=Box)
    row_h: int = 0
    caret: tuple[int, int, int] = (0, 0, 0)


class RecipeView:
    """レシピ一覧の見た目。クリップボードの一覧と色・形をそろえる。"""

    def __init__(self, clip_view) -> None:  # noqa: ANN001
        # 色・フォント・アクセントは、クリップボードの見た目から借りる
        self.base = clip_view
        self.layout = RecipeLayout()
        self.record_key = "Ctrl+Space"
        self.api_ready = False

    @property
    def fonts(self):  # noqa: ANN201
        return self.base.fonts

    def px(self, size: float, s: float) -> int:
        return self.base.px(size, s)

    def arrange(self, width: int, height: int, s: float,
                model: RecipeModel) -> RecipeLayout:
        lay = RecipeLayout(width=width, height=height, s=s)
        pad = round(14 * s)
        scale = max(1.0, self.base.font_scale * 0.95)
        title_h = round(34 * s * scale)
        lay.title = Box(pad, round(6 * s), width - pad * 2, title_h)
        tab_h = round(30 * s * scale)
        lay.tab_bar = Box(pad, lay.title.bottom, width - pad * 2, tab_h)
        field_h = round(34 * s * scale)
        lay.search = Box(pad, lay.tab_bar.bottom + round(4 * s),
                         width - pad * 2, field_h)
        note_h = round(26 * s * scale)
        lay.note = Box(pad, lay.search.bottom + round(4 * s),
                       width - pad * 2, note_h)
        foot_h = round(30 * s * scale)
        lay.footer = Box(0, height - foot_h, width, foot_h)
        top = lay.note.bottom + round(4 * s)
        lay.listing = Box(0, top, width, lay.footer.y - top)
        main = self.px(13.5, s)
        sub = self.px(11.5, s)
        lay.row_h = round(main * 1.5 + sub * 1.5 + 16 * s)
        model.page = max(1, (lay.listing.h - round(6 * s)) // lay.row_h)
        self.layout = lay
        return lay

    def hit(self, x: int, y: int, model: RecipeModel) -> tuple[str, int]:
        lay = self.layout
        for i, box in enumerate(lay.tabs):
            if box.has(x, y):
                return ("tab", i)
        if lay.search.has(x, y):
            return ("search", 0)
        if lay.listing.has(x, y):
            row = (y - lay.listing.y - round(3 * lay.s)) // max(1, lay.row_h)
            index = model.top + row
            if 0 <= row < model.page and index < len(model.view):
                return ("row", index)
            return ("list", -1)
        if y < lay.listing.y:
            return ("caption", 0)
        return ("", -1)

    def paint(self, canvas: Canvas, model: RecipeModel, s: float, *,
              focused: bool = True, note: str = "") -> None:
        lay = self.arrange(canvas.width, canvas.height, s, model)
        p = Painter(canvas, self.fonts)
        try:
            c = self.base.c
            p.clear(c["bg"])
            title_px = self.px(14.5, s)
            p.text(GLYPH["text"], lay.title.x, lay.title.y,
                   round(26 * s), lay.title.h, colour=self.base.accent_fg,
                   px=self.px(14, s), icon=True)
            p.text(t("recipe.title"), lay.title.x + round(28 * s),
                   lay.title.y, lay.title.w, lay.title.h, colour=c["fg"],
                   px=title_px, weight=FW_SEMIBOLD)
            self._paint_tabs(p, model, lay)
            self._paint_search(p, model, lay, focused)
            hint = t("recipe.how", hotkey=self.record_key)
            if not self.api_ready:
                hint += "  " + t("recipe.offline")
            p.text(hint, lay.note.x + round(2 * s), lay.note.y,
                   lay.note.w, lay.note.h, colour=c["fg3"],
                   px=self.px(11.5, s))
            p.line(0, lay.listing.y - 1, lay.width, lay.listing.y - 1,
                   c["line"])
            self._paint_list(p, model, lay)
            self._paint_footer(p, lay)
            if note:
                self.base._paint_toast(p, Layout(
                    width=lay.width, height=lay.height, s=s,
                    footer=lay.footer), note)
        finally:
            p.close()

    def _paint_tabs(self, p: Painter, model: RecipeModel,
                    lay: RecipeLayout) -> None:
        c, s = self.base.c, lay.s
        bar = lay.tab_bar
        tab_px = self.px(12.5, s)
        tx = bar.x
        lay.tabs = []
        for i, (_cat_key, label_key) in enumerate(CATEGORIES):
            active = (i == model.cat_index)
            label = t(label_key)
            weight = FW_SEMIBOLD if active else 400
            text_w = p.measure(label, px=tab_px, weight=weight)[0]
            box_w = text_w + round(18 * s)
            box = Box(tx, bar.y, box_w, bar.h)
            lay.tabs.append(box)

            col = c["fg"] if active else c["fg3"]
            p.text(label, box.x, box.y, box.w, box.h,
                   colour=col, px=tab_px, weight=weight,
                   align="center", ellipsis=False)

            if active:
                bar_w = max(round(16 * s), box.w - round(8 * s))
                p.round_rect(box.x + (box.w - bar_w) / 2,
                             box.bottom - round(2.5 * s), bar_w,
                             round(2.5 * s), round(1.2 * s),
                             fill=self.base.accent_fg)

            tx += box_w + round(8 * s)

    def _paint_search(self, p: Painter, model: RecipeModel,
                      lay: RecipeLayout, focused: bool) -> None:
        c, s = self.base.c, lay.s
        box = lay.search
        r = round(5 * s)
        p.round_rect(box.x, box.y, box.w, box.h, r, fill=c["field"],
                     stroke=c["field_line"], width=max(1.0, s * 0.8))
        if focused:
            p.rect(box.x + r * 0.6, box.bottom - round(2 * s),
                   box.w - r * 1.2, round(2 * s), self.base.accent_fg)
        icon_w = round(34 * s)
        p.text(GLYPH["search"], box.x + round(4 * s), box.y, icon_w, box.h,
               colour=c["fg3"], px=self.px(14, s), icon=True,
               align="center")
        tx = box.x + icon_w + round(2 * s)
        text_px = self.px(13.5, s)
        sb = model.search
        if sb.text:
            p.text(sb.text, tx, box.y, box.w - icon_w - round(12 * s),
                   box.h, colour=c["fg"], px=text_px, ellipsis=False)
            caret_x = tx + p.measure(sb.text[:sb.caret], px=text_px)[0]
        else:
            p.text(t("recipe.search"), tx, box.y, box.w - icon_w, box.h,
                   colour=c["faint"], px=text_px)
            caret_x = tx
        caret_h = round(text_px * 1.25)
        caret_y = box.y + (box.h - caret_h) // 2
        lay.caret = (int(caret_x), int(caret_y), int(caret_h))
        if focused:
            p.rect(caret_x, caret_y, max(1, round(1.2 * s)), caret_h,
                   c["fg"])

    def _paint_list(self, p: Painter, model: RecipeModel,
                    lay: RecipeLayout) -> None:
        c, s = self.base.c, lay.s
        area = lay.listing
        if not model.view:
            p.text(t("recipe.empty") if not model.search.text
                   else t("clip.no_match"),
                   area.x + round(24 * s), area.y + round(30 * s),
                   area.w - round(48 * s), round(80 * s), colour=c["fg3"],
                   px=self.px(12.5, s), align="center", wrap=True)
            return
        p.clip(area.x, area.y, area.w, area.h)
        y = area.y + round(3 * s)
        for index in range(model.top, min(len(model.view),
                                          model.top + model.page)):
            item = model.view[index]
            self._paint_row(p, model, item, index,
                            Box(area.x, y, area.w, lay.row_h), s)
            y += lay.row_h
        p.unclip()

    def _paint_row(self, p: Painter, model: RecipeModel, item: Recipe,
                   index: int, box: Box, s: float) -> None:
        c = self.base.c
        inset = round(8 * s)
        if index == model.sel:
            strength = 0.24 if self.base.theme == "dark" else 0.13
            p.round_rect(box.x + inset, box.y + round(1 * s),
                         box.w - inset * 2, box.h - round(2 * s),
                         round(6 * s),
                         fill=mix(c["bg"], self.base.accent, strength))
            p.round_rect(box.x + inset, box.y + box.h * 0.28,
                         round(3 * s), box.h * 0.44, round(1.5 * s),
                         fill=self.base.accent_fg)
        x = box.x + inset + round(12 * s)
        right = box.right - inset - round(12 * s)
        # 1〜9 の番号（押すだけで選べる）は、四角い札で目立たせる
        if index < 9:
            d = round(22 * s)
            cy = box.y + (box.h - d) / 2
            p.round_rect(x, cy, d, d, round(5 * s),
                         fill=c["chip"])
            p.text(str(index + 1), x, cy, d, d, colour=c["chip_fg"],
                   px=self.px(11.5, s), weight=FW_SEMIBOLD,
                   align="center")
        x += round(34 * s)
        key_w = 0
        if item.hotkey:
            label = key_label(item.hotkey).replace(" ", "")
            key_px = self.px(10.5, s)
            key_w = p.measure(label, px=key_px)[0] + round(12 * s)
            chip_h = round(key_px * 1.8)
            p.round_rect(right - key_w, box.y + (box.h - chip_h) / 2, key_w,
                         chip_h, round(4 * s), fill=c["chip"])
            p.text(label, right - key_w, box.y + (box.h - chip_h) / 2,
                   key_w, chip_h, colour=c["chip_fg"], px=key_px,
                   align="center", ellipsis=False)
            key_w += round(10 * s)
        main = self.px(13.5, s)
        sub = self.px(11.5, s)
        line_h = round(main * 1.5)
        y = box.y + round(8 * s)
        if not item.desc:
            y = box.y + (box.h - line_h) // 2
        p.text(item.name, x, y, right - x - key_w, line_h, colour=c["fg"],
               px=main, weight=FW_SEMIBOLD if index == model.sel else 400)
        if item.desc:
            p.text(item.desc, x, y + line_h, right - x - key_w,
                   round(sub * 1.5), colour=c["fg3"], px=sub)

    def _paint_footer(self, p: Painter, lay: RecipeLayout) -> None:
        c, s = self.base.c, lay.s
        box = lay.footer
        p.rect(box.x, box.y, box.w, box.h, c["panel"])
        p.line(0, box.y, box.w, box.y, c["line"])
        key_px = self.px(10.5, s)
        label_px = self.px(11, s)
        chip_h = round(key_px * 1.75)
        cy = box.y + (box.h - chip_h) // 2
        x = round(12 * s)
        for key, label in (("Enter", t("recipe.hint_pick")),
                           ("1〜9", t("recipe.hint_number")),
                           ("Tab", t("recipe.hint_category")),
                           ("Esc", t("recipe.hint_close"))):
            kw = p.measure(key, px=key_px)[0] + round(10 * s)
            lw = p.measure(label, px=label_px)[0]
            if x + kw + lw > box.w - round(12 * s):
                break
            p.round_rect(x, cy, kw, chip_h, round(4 * s), fill=c["chip"])
            p.text(key, x, cy, kw, chip_h, colour=c["chip_fg"], px=key_px,
                   align="center", ellipsis=False)
            x += kw + round(5 * s)
            p.text(label, x, box.y, lw + round(2 * s), box.h,
                   colour=c["fg3"], px=label_px, ellipsis=False)
            x += lw + round(14 * s)


def categorize_recipe(recipe_id: str) -> str:
    """レシピIDから所属カテゴリ（text: 文章作成, tools: 便利ツール）を返す。"""
    tools_ids = {
        "smart_calc", "screen_assistant", "terminal_helper",
        "task_list", "chaos_mode", "buzzword_mode"
    }
    return "tools" if recipe_id in tools_ids else "text"


def from_config(rows: list[dict] | None, lang: str = "ja") -> list[Recipe]:
    """設定 ai_custom_instructions から、使うレシピの一覧。"""
    out = [
        Recipe(id="normal",
               name="通常の文字起こし（変換なし）" if lang != "en"
               else "Normal input (no conversion)",
               desc="話した内容をそのまま入力します" if lang != "en"
               else "Transcribe speech as-is",
               hotkey="", category="tools")
    ]
    for row in rows or []:
        if not isinstance(row, dict) or not row.get("id"):
            continue
        if row.get("enabled") is False:
            continue
        rid = str(row["id"])
        name = str(row.get("name") or rid)
        desc = str(row.get("desc") or "")
        if lang == "en":
            name = str(row.get("name_en") or name)
            desc = str(row.get("desc_en") or desc)
        out.append(Recipe(id=rid, name=name, desc=desc,
                          hotkey=str(row.get("hotkey") or ""),
                          category=categorize_recipe(rid)))
    # Galaxy S25風の「画面AI・かこって検索」を標準ツールとして提供
    has_screen = any(r.id == "screen_assistant" for r in out)
    if not has_screen:
        out.append(Recipe(
            id="screen_assistant",
            name="画面AI・かこって検索（Galaxy風）" if lang != "en"
            else "Screen AI · Circle to Search",
            desc="画面を囲んでGeminiに質問・要約やGoogle検索" if lang != "en"
            else "Circle screen area to ask Gemini or search Google",
            hotkey="ctrl+alt+j",
            category="tools",
        ))
    return out


__all__ = ["Recipe", "RecipeModel", "RecipeView", "from_config",
           "FONT_SCALES", "PALETTES"]
