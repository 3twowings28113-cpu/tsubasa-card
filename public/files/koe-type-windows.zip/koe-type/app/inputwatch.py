"""ショートカットと、画面の切り替わりの見張り。**入力を止めない作り。**

## なぜ作り直したか

以前は、キーもマウスも**低レベルのフック**（`WH_KEYBOARD_LL` /
`WH_MOUSE_LL`）で見ていた。これが PC 全体を重くした。

低レベルのフックのコールバックは、Python では **GIL（実行権）を取れるまで
動けない**。文字起こしが GIL を持っているあいだ、コールバックは待たされる。
そのあいだ **Windows は PC 全体のキー・マウス入力を止めて待つ**。
カーソルがカクつき、待ちすぎると Windows がフックを黙って外す。
実際に利用者の PC がほぼ固まり、再起動が必要になった。

## 作り直した方針

**入力の流れの中に割り込まない方法だけを使う。**

| 見たいもの | 使うもの | なぜ安全か |
|---|---|---|
| Ctrl+Space（録音の開始・停止） | `RegisterHotKey` | OS が押された時だけ `WM_HOTKEY` を**投げてくれる**。こちらが遅くても、他のアプリの入力は止まらない |
| 録音中の Enter / Esc | `RegisterHotKey`（録音中だけ登録） | 同上。録音していない間は登録しないので、ふだんの Enter / Esc は一切触らない |
| 画面の切り替わり・クリック | `SetWinEventHook`（`WINEVENT_OUTOFCONTEXT`） | 出来事を**メッセージとして受け取る**だけ。相手のアプリは待たされない |

`WINEVENT_OUTOFCONTEXT` が肝で、こちらのプロセスに DLL を注入せず、
イベントを**あとから**メッセージキューに届ける。送り手は待たない。

## 使わないと決めたもの

- **低レベルのフック**（録音中の長押しモードを除く。後述）
- **クリックを受け止めて待つ**こと。送信ボタンの押下を止めて文字を
  入れ終わるまで待つ、という作りは魅力的だったが、入力の流れを
  止めるので**二度とやらない**。言葉の最後が欠けるのは、
  文字を入れるのを速くすることで防ぐ。
"""

from __future__ import annotations

import ctypes
import logging
import threading
from ctypes import wintypes

log = logging.getLogger(__name__)

user32 = ctypes.WinDLL("user32", use_last_error=True)

# --- RegisterHotKey
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
MOD_WIN = 0x0008
MOD_NOREPEAT = 0x4000

WM_HOTKEY = 0x0312

MODS = {"alt": MOD_ALT, "ctrl": MOD_CONTROL,
        "shift": MOD_SHIFT, "win": MOD_WIN}

# ショートカットごとの番号（WM_HOTKEY の wParam で返ってくる）
ID_RECORD = 0xA001
ID_CANCEL = 0xA002
ID_SEND = 0xA003
ID_TOGGLE_LANG = 0xA004
ID_ACTION = 0xA005
ID_ASSISTANT = 0xA006
ID_FIX = 0xA007        # 直前の挿入を直す
ID_CUSTOM_BASE = 0xA100  # カスタム指示ホットキー用（0xA100〜）

ERROR_HOTKEY_ALREADY_REGISTERED = 1409

# --- SetWinEventHook
EVENT_SYSTEM_FOREGROUND = 0x0003
EVENT_OBJECT_FOCUS = 0x8005
WINEVENT_OUTOFCONTEXT = 0x0000
WINEVENT_SKIPOWNPROCESS = 0x0002

WINEVENTPROC = ctypes.WINFUNCTYPE(
    None, wintypes.HANDLE, wintypes.DWORD, wintypes.HWND,
    wintypes.LONG, wintypes.LONG, wintypes.DWORD, wintypes.DWORD)

user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int,
                                  wintypes.UINT, wintypes.UINT]
user32.RegisterHotKey.restype = wintypes.BOOL
user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
user32.UnregisterHotKey.restype = wintypes.BOOL
user32.SetWinEventHook.argtypes = [wintypes.DWORD, wintypes.DWORD,
                                   wintypes.HMODULE, WINEVENTPROC,
                                   wintypes.DWORD, wintypes.DWORD,
                                   wintypes.DWORD]
user32.SetWinEventHook.restype = wintypes.HANDLE
user32.UnhookWinEvent.argtypes = [wintypes.HANDLE]
user32.UnhookWinEvent.restype = wintypes.BOOL
user32.GetForegroundWindow.restype = wintypes.HWND


# ---------------------------------------------------------------- ショートカット


class Hotkeys:
    """`RegisterHotKey` でショートカットを登録する。

    登録・解除は、**メッセージループを持つスレッドから**呼ぶこと
    （`WM_HOTKEY` はそのスレッドに届く）。
    """

    def __init__(self, hwnd: int) -> None:
        self.hwnd = hwnd
        self._held: dict[int, tuple[int, int]] = {}   # id -> (mods, vk)
        self._lock = threading.Lock()
        self.failures: dict[int, str] = {}

    # ------------------------------------------------------------------

    def register(self, key_id: int, mods: set[str], vk: int, *,
                 quiet: bool = False) -> bool:
        """ひとつ登録する。すでに同じ内容なら何もしない。

        quiet は、見張りが定期的に付け直すとき用。失敗の記録は残すが、
        ログは出さない（最初の失敗で 1 回出れば十分で、付け直しのたびに
        出すとログが埋まる）。
        """
        if not vk:
            return False
        flags = MOD_NOREPEAT
        for name in mods:
            flags |= MODS.get(name, 0)
        with self._lock:
            if self._held.get(key_id) == (flags, vk):
                return True
            if key_id in self._held:
                user32.UnregisterHotKey(self.hwnd, key_id)
                self._held.pop(key_id, None)
            if user32.RegisterHotKey(self.hwnd, key_id, flags, vk):
                self._held[key_id] = (flags, vk)
                self.failures.pop(key_id, None)
                return True
            err = ctypes.get_last_error()
            reason = ("ほかのアプリが先に使っています"
                      if err == ERROR_HOTKEY_ALREADY_REGISTERED
                      else f"エラー {err}")
            self.failures[key_id] = reason
            if not quiet:
                log.warning("ショートカットを登録できません "
                            "(id=%#x vk=%#x): %s", key_id, vk, reason)
            return False

    def unregister(self, key_id: int) -> None:
        with self._lock:
            if key_id in self._held:
                user32.UnregisterHotKey(self.hwnd, key_id)
                self._held.pop(key_id, None)

    def clear(self) -> None:
        with self._lock:
            for key_id in list(self._held):
                user32.UnregisterHotKey(self.hwnd, key_id)
            self._held.clear()
            # ★失敗の記録も消す。残しておくと、対象から外れたキーの
            # 失敗が滞留して clipwin 側の付け直し走査（2 秒間隔）が
            # 空回りし、「失敗があるか」の判定材料も濁る
            # （2026-10-31 第三者監査 A1 / L22）。
            self.failures.clear()

    def is_held(self, key_id: int) -> bool:
        with self._lock:
            return key_id in self._held

    def held_ids(self) -> set[int]:
        with self._lock:
            return set(self._held)

    def reassert(self) -> int:
        """登録が外れていないか確かめ、外れていたら付け直す。

        戻り値は付け直した数。
        （Windows が外すことは本来ないが、念のため見張る）
        """
        with self._lock:
            want = dict(self._held)
        fixed = 0
        for key_id, (flags, vk) in want.items():
            # 登録済みのものをもう一度登録すると失敗する。
            # いったん外してから付け直して、確かに持っていることを確かめる。
            user32.UnregisterHotKey(self.hwnd, key_id)
            if not user32.RegisterHotKey(self.hwnd, key_id, flags, vk):
                err = ctypes.get_last_error()
                reason = ("ほかのアプリが先に使っています"
                          if err == ERROR_HOTKEY_ALREADY_REGISTERED
                          else f"エラー {err}")
                with self._lock:
                    self._held.pop(key_id, None)
                    # ★失敗を failures へ残す。付け直し（clipwin の
                    # リトライ）は failures 駆動なので、ここへ入れないと
                    # 外れたキーは二度と戻らず、喪失に誰も気づけない
                    # （2026-10-31 第三者監査 A2）。
                    self.failures[key_id] = reason
                log.warning("ショートカット %#x を付け直せませんでした: %s",
                            key_id, reason)
            else:
                fixed += 1
        return fixed


# ---------------------------------------------------------------- 画面の見張り


class FocusWatch:
    """前面のウィンドウ・入力先が変わったことを知る。

    `SetWinEventHook` を `WINEVENT_OUTOFCONTEXT` で使う。
    出来事は**メッセージとして届く**だけなので、相手のアプリは待たされない。
    クリックそのものは見ないが、クリックで入力先が変われば分かる。
    """

    def __init__(self, on_change) -> None:  # noqa: ANN001
        self._on_change = on_change
        self._handles: list[int] = []
        self._proc = WINEVENTPROC(self._cb)
        self.events = 0

    def install(self) -> bool:
        if self._handles:
            return True
        hooks = ((EVENT_SYSTEM_FOREGROUND, "前面ウィンドウの切り替わり"),
                 (EVENT_OBJECT_FOCUS, "入力先の変化"))
        missing: list[str] = []
        for event, name in hooks:
            handle = user32.SetWinEventHook(
                event, event, None, self._proc, 0, 0,
                WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS)
            if handle:
                self._handles.append(handle)
            else:
                missing.append(name)
        if not self._handles:
            log.warning("画面の見張りを付けられません err=%s",
                        ctypes.get_last_error())
            return False
        if missing:
            # ★片方だけ付いた状態を「付けました」で済ませない。
            # 取れない出来事があることに気づけるよう、部分成功は
            # 警告として残す（2026-10-31 第三者監査 A3）。
            # 戻り値は True のまま（付いた側だけでも見張りは続ける）。
            log.warning("画面の見張りが一部だけ付きました"
                        "（付かなかった: %s）", "、".join(missing))
        else:
            log.info("画面の見張りを付けました（入力を止めない方式）")
        return True

    def remove(self) -> None:
        for handle in self._handles:
            user32.UnhookWinEvent(handle)
        self._handles.clear()

    def _cb(self, handle, event, hwnd, obj, child, thread, when) -> None:  # noqa: ANN001
        # ここは**何もしない**のが大事。数えて、本体へ知らせるだけ。
        try:
            self.events += 1
            self._on_change(int(hwnd or 0), int(event))
        except Exception:
            log.exception("画面の見張りで例外")
