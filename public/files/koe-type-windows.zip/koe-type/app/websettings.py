"""設定画面。HTML/CSS を Microsoft Edge のアプリモードで専用の窓として開く。

なぜこうしたか
  tkinter の標準部品では、スライダーやプルダウンの見た目が Windows 11 に
  まったくなじまない。Edge は Windows 11 に最初から入っており、
  **新しい依存も未署名の exe も増やさずに**まともな UI を作れる。

安全のための決まり
  ・待ち受けは 127.0.0.1 のみ。外から触れない
  ・起動のたびにランダムな合言葉（token）を作り、合わない要求は全部断る
  ・Origin / Referer が自分以外の要求も断る（ほかのサイトから設定を変えられない）
  ・Edge は専用の一時プロフィールで開く。ふだんの履歴やログインに触らない
  ・窓を閉じたらサーバーも止める（見失っても心拍が途切れたら止まる）
"""

from __future__ import annotations

import json
import logging
import mimetypes
import os
import secrets
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

from . import audio, catalog, downloads, i18n, schema, theme
from .i18n import pick, t
from .util import DATA_DIR, LOG_DIR, ROOT, VERSION

log = logging.getLogger(__name__)

WEB_DIR = Path(__file__).resolve().parent / "web"
ICON_PNG_DIR = ROOT / "assets" / "icon" / "png"
HEARTBEAT_TIMEOUT = 12.0        # 秒。心拍が止まったら窓が閉じたとみなす
# 「閉じます」が届いてから、本当に閉じるまで待つ秒数。そのあいだに
# 次のページから要求が来たら、ページを移っただけとみなして閉じない。
CLOSE_GRACE = 1.5

EDGE_CANDIDATES = (
    Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"))
    / "Microsoft/Edge/Application/msedge.exe",
    Path(os.environ.get("ProgramFiles", r"C:\Program Files"))
    / "Microsoft/Edge/Application/msedge.exe",
)


def find_edge() -> Path | None:
    for path in EDGE_CANDIDATES:
        if path.exists():
            return path
    try:
        import winreg
        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Windows\CurrentVersion"
                r"\App Paths\msedge.exe") as key:
            found = Path(winreg.QueryValueEx(key, "")[0])
            if found.exists():
                return found
    except OSError:
        pass
    return None


# ---------------------------------------------------------------- サーバー


class _QuietServer(ThreadingHTTPServer):
    """通信が切れたときに、長い赤い文字を出さないサーバー。

    設定の窓を閉じると相手がいきなり切る。これは**ふつうのこと**。
    標準のままだと画面いっぱいに例外が出て、「壊れた」ように見える。
    """

    daemon_threads = True

    def handle_error(self, request, client_address) -> None:  # noqa: ANN001
        log.debug("設定画面の通信が切れました（%s）", client_address,
                  exc_info=True)


class SettingsServer:
    """設定画面のための小さなローカルサーバー。1 つだけ立てる。"""

    def __init__(self, bridge: "Bridge") -> None:
        self.bridge = bridge
        self.token = secrets.token_urlsafe(24)
        self.httpd: ThreadingHTTPServer | None = None
        self.port = 0
        self.last_beat = time.monotonic()
        self._stop = threading.Event()
        self._profile: Path | None = None
        self._browser: subprocess.Popen | None = None
        # スクリーンショットを撮るときなど、窓が閉じてもサーバーを残したい場合
        self.keep_open = False

    # ------------------------------------------------------------------

    @property
    def running(self) -> bool:
        return self.httpd is not None and not self._stop.is_set()

    def url(self, category: str = "") -> str:
        query = f"t={self.token}"
        path = "/"
        if category == "onboarding":
            path = "/onboarding"
        elif category:
            query += f"&page={urllib.parse.quote(category)}"
        return f"http://127.0.0.1:{self.port}{path}?{query}"

    def start(self) -> None:
        if self.running:
            return
        handler = _make_handler(self)
        self.httpd = _QuietServer(("127.0.0.1", 0), handler)
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self._stop.clear()
        threading.Thread(target=self.httpd.serve_forever, name="settings-http",
                         daemon=True).start()
        threading.Thread(target=self._watchdog, name="settings-watch",
                         daemon=True).start()
        log.info("設定画面のサーバーを 127.0.0.1:%d で開きました", self.port)

    def open_window(self, category: str = "") -> bool:
        """Edge のアプリモードで開く。見つからなければ既定のブラウザ。"""
        self.start()
        self.beat()
        edge = find_edge()
        if edge is None:
            log.warning("Edge が見つからないので既定のブラウザで開きます")
            import webbrowser
            webbrowser.open(self.url(category))
            return False
        if self.page_alive():
            # すでに開いている。新しい窓は作らず、ページ側に知らせる
            # （起動したプロセスが生きているかでは見ない。上の見張りと同じ理由）
            self.bridge.push({"type": "navigate", "page": category})
            self._focus_existing()
            return True
        self._profile = Path(tempfile.mkdtemp(prefix="koe-type-edge-"))
        args = [
            str(edge),
            f"--app={self.url(category)}",
            f"--user-data-dir={self._profile}",
            "--window-size=1060,720",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-extensions",
            "--disable-background-networking",
            "--disable-sync",
            "--disable-features=Translate,EdgeCollections,msEdgeShoppingAssistant",
            "--app-auto-launched",
        ]
        try:
            self._browser = subprocess.Popen(
                args, creationflags=0x08000000)  # CREATE_NO_WINDOW
            log.info("設定画面を Edge のアプリモードで開きました")
            return True
        except Exception:
            log.exception("Edge を起動できませんでした")
            import webbrowser
            webbrowser.open(self.url(category))
            return False

    def _focus_existing(self) -> None:
        """すでに開いている設定窓を前に出す。"""
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.WinDLL("user32", use_last_error=True)
            user32.SetForegroundWindow.argtypes = [wintypes.HWND]
            user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
            enum = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND,
                                      wintypes.LPARAM)
            target = []

            # ★起動した msedge.exe の番号では探せない（すぐ終わって、
            # 本当の窓は別のプロセスが持つ）。窓の題名で探す。
            # 題名は index.html／onboarding.html の <title>。
            titles = ("SpeakPulse", "SpeakPulse をはじめる",
                      "koe-type", "koe-type をはじめる")

            def cb(hwnd, _):  # noqa: ANN001
                if not user32.IsWindowVisible(hwnd):
                    return True
                buf = ctypes.create_unicode_buffer(256)
                user32.GetWindowTextW(hwnd, buf, 256)
                cls = ctypes.create_unicode_buffer(64)
                user32.GetClassNameW(hwnd, cls, 64)
                if (buf.value in titles
                        and cls.value.startswith("Chrome_WidgetWin")):
                    target.append(hwnd)
                    return False
                return True

            user32.EnumWindows(enum(cb), 0)
            if target:
                user32.ShowWindow(target[0], 9)       # SW_RESTORE
                user32.SetForegroundWindow(target[0])
        except Exception:
            log.debug("設定窓を前に出せませんでした", exc_info=True)

    # ------------------------------------------------------------------

    def beat(self) -> None:
        self.last_beat = time.monotonic()

    def page_beat(self) -> None:
        """ページから要求が届いた（＝窓が本当に開いている）。"""
        now = time.monotonic()
        self.last_beat = now
        self.last_page = now

    def page_alive(self) -> bool:
        """設定の窓が、いま開いているか（ページから心拍が届いているか）。"""
        return (self.running
                and time.monotonic() - getattr(self, "last_page", 0.0)
                < HEARTBEAT_TIMEOUT)

    def close_soon(self) -> None:
        """ページから「閉じます」が届いた。少し待ってから閉じる。

        ★すぐ閉じてはいけない。ページは**別のページへ移るときにも**
        「閉じます」を送る（pagehide）。前は 0.2 秒後に無条件で閉じて
        いたので、「初回の案内をもう一度」を押した瞬間に、案内へ移る
        途中で窓ごと消えていた（2026-10-05 立ち会いテスト）。
        待つあいだに次のページから要求が来れば（beat が進めば）閉じない。
        """
        asked = time.monotonic()

        def later() -> None:
            if self.last_beat > asked:
                log.info("ページを移っただけなので、設定画面は閉じません")
                return
            log.info("設定画面が閉じられたのでサーバーを止めます")
            self.stop()

        threading.Timer(CLOSE_GRACE, later).start()

    def _watchdog(self) -> None:
        """ページからの心拍が途切れたら、窓が閉じたとみなして片付ける。"""
        while not self._stop.is_set():
            time.sleep(1.0)
            if self.keep_open:
                self.beat()
                continue
            # ★起動した msedge.exe が終わったことは、もう「閉じた」の
            # しるしにしない。Edge の更新（2026-10-05）から、msedge.exe は
            # すぐ終わって本当の窓を別のプロセスに任せる。前はそれを
            # 「閉じた」と見てすぐサーバーを止め、設定の窓が「接続が
            # 拒否されました」になっていた。ページの心拍だけで決める。
            stale = time.monotonic() - self.last_beat > HEARTBEAT_TIMEOUT
            if stale:
                log.info("設定画面が閉じられたのでサーバーを止めます")
                self.stop()
                return

    def stop(self) -> None:
        if self._stop.is_set():
            return
        self._stop.set()
        httpd, self.httpd = self.httpd, None
        if httpd is not None:
            def shut() -> None:
                httpd.shutdown()
                httpd.server_close()
            threading.Thread(target=shut, daemon=True).start()
        if self._browser is not None and self._browser.poll() is None:
            try:
                self._browser.terminate()
            except Exception:
                pass
        self._browser = None
        if self._profile is not None:
            profile, self._profile = self._profile, None
            threading.Timer(2.0, lambda: shutil.rmtree(
                profile, ignore_errors=True)).start()
        self.bridge.on_closed()


# ---------------------------------------------------------------- 受け口


class Bridge:
    """ページからの要求をアプリ側へつなぐ。

    ここに来るのはすべて合言葉を確かめたあとの要求だけ。
    """

    def __init__(self, config, dictionary, history,
                 action: Callable[..., Any]) -> None:
        self.cfg = config
        self.dictionary = dictionary
        self.history = history
        self.action = action
        downloads.set_offline(self.cfg.bool_("offline_mode"))
        self._events: list[dict] = []
        self._lock = threading.Lock()
        self._downloading: dict[str, float] = {}
        # 初回の案内。使うときに作る（ふだんは何も持たない）
        self._onboarding = None

    # ---------------------------------------------------------- 送る

    def push(self, event: dict) -> None:
        with self._lock:
            self._events.append(event)

    def drain(self) -> list[dict]:
        with self._lock:
            out, self._events = self._events, []
        return out

    def on_closed(self) -> None:
        self.action("settings_closed")

    # ------------------------------------------------- 本体に聞くこと

    def microphones(self) -> list:
        """使えるマイクの名前。"""
        try:
            from .audio import devices  # noqa: PLC0415
            return [name for _index, name in devices()]
        except Exception:  # noqa: BLE001
            return []

    def mic_level(self) -> float:
        """いま聞こえている声の大きさ（0.0〜1.0）。"""
        try:
            return float(self.action("mic_level") or 0.0)
        except Exception:  # noqa: BLE001
            return 0.0

    def mic_error(self) -> str:
        try:
            return str(self.action("mic_error") or "")
        except Exception:  # noqa: BLE001
            return ""

    def is_recording(self) -> bool:
        try:
            return bool(self.action("is_recording"))
        except Exception:  # noqa: BLE001
            return False

    @property
    def onboarding(self):  # noqa: ANN201
        """初回の案内。初めて聞かれたときに作る。"""
        if self._onboarding is None:
            from .firstrun import Onboarding  # noqa: PLC0415
            self._onboarding = Onboarding(self)
        return self._onboarding

    # ---------------------------------------------------------- 状態

    def state(self) -> dict:
        i18n.set_language(self.cfg.str_("ui_language", "ja"))
        return {
            "lang": i18n.language(),
            "theme": theme.resolve(self.cfg.str_("theme", "system")),
            "themeSetting": self.cfg.str_("theme", "system"),
            "accent": theme.accent_color(),
            "version": VERSION,
            "folder": str(ROOT),
            "categories": self._categories(),
            "values": self.cfg.as_dict(),
            "models": self._models(),
            "dictionary": self.dictionary.detailed_entries(),
            "history": self._history(),
            "commands": self._commands(),
            "guides": self._guides(),
            "presets": self._presets(),
            "recovered": getattr(self.cfg, "recovered", ""),
            "text": self._strings(),
        }

    def _guides(self) -> list[dict]:
        """「困りごとから探す」の案内一覧。

        設定項目が多くて迷う利用者が、自分のやりたいこと・困っていることから
        変えるべき設定と理由にたどり着けるようにする。
        """
        from . import guide  # noqa: PLC0415
        return guide.serialize_guides()

    def _commands(self) -> list[dict]:
        """音声コマンドの一覧（画面に出す形）。"""
        from . import jatext  # noqa: PLC0415
        lang = i18n.language()
        out = []
        for cmd in jatext.DEFAULT_COMMANDS:
            out.append({
                "name": cmd.phrases[0],
                "phrases": list(cmd.phrases),
                "kind": cmd.kind,
                "label": cmd.ja if lang == "ja" else cmd.en,
            })
        return out

    def _presets(self) -> list[dict]:
        """おすすめ使用感プリセットの一覧。"""
        from . import schema  # noqa: PLC0415
        lang = i18n.language()
        out = []
        for p in schema.PRESETS:
            out.append({
                "id": p["id"],
                "name": p["name"] if lang == "ja" else p["name_en"],
                "desc": p["desc"] if lang == "ja" else p["desc_en"],
                "icon": p.get("icon", "sliders"),
                "badge": p["badge"] if lang == "ja" else p.get("badge_en", ""),
                "settings": dict(p["settings"]),
            })
        return out

    def _categories(self) -> list[dict]:
        out = []
        for cat in schema.CATEGORIES:
            groups = []
            for group in cat.groups:
                groups.append({
                    "label": pick(group.ja, group.en),
                    "items": [self._item(i) for i in group.items],
                })
            out.append({
                "key": cat.key, "icon": cat.icon,
                "label": pick(cat.ja, cat.en),
                "sub": pick(cat.sub_ja, cat.sub_en),
                "groups": groups,
            })
        return out

    def _item(self, item: schema.Item) -> dict:
        data: dict[str, Any] = {
            "key": item.key, "kind": item.kind,
            "label": pick(item.ja, item.en),
            "help": pick(item.help_ja, item.help_en),
            "restart": item.restart, "panel": item.panel,
            "default": item.default,
            "advanced": item.advanced,
        }
        if item.options_from == "microphones":
            rows = [{"value": "", "label": t("common.default")}]
            rows += [{"value": name, "label": name} for _i, name in audio.devices()]
            data["options"] = rows
        elif item.options_from == "instructions":
            data["options"] = self._instruction_options(item)
        elif item.options:
            data["options"] = [{"value": o.value, "label": pick(o.ja, o.en)}
                               for o in item.options]
        if item.presets:
            data["presets"] = [{"value": p.value, "label": pick(p.ja, p.en)}
                               for p in item.presets]
        if item.kind == "int":
            data.update(min=item.minimum, max=item.maximum, step=item.step,
                        unit=item.unit,
                        zero=pick(item.zero_ja, item.zero_en))
        reason = self._inactive(item.key)
        if reason:
            data["inactive"] = reason
        return data

    def _instruction_options(self, item: schema.Item) -> list[dict]:
        """「文章変換」の一覧から選択肢を作る。

        以前は選択肢を固定で書いていたため、一覧で足した変換や、
        名前を変えた変換を、長押しや専用キーに割り当てられなかった。
        """
        rows = [{"value": o.value, "label": pick(o.ja, o.en)}
                for o in item.options]
        for inst in self.cfg.get("ai_custom_instructions") or []:
            if not isinstance(inst, dict) or not inst.get("id"):
                continue
            if inst.get("enabled") is False:
                continue
            name = inst.get("name") or inst["id"]
            name = pick(name, inst.get("name_en") or name)
            rows.append({"value": inst["id"], "label": name})
        # 古い値（"business" "custom" など）や、止めた変換を選んだままでも、
        # 画面で空欄に見えないように残す
        current = self.cfg.get(item.key)
        if current and all(r["value"] != current for r in rows):
            rows.append({"value": current, "label": str(current)})
        return rows

    def _inactive(self, key: str) -> str:
        """いまの組み合わせでは効かない設定の、その理由。

        「オンなのに何も起きない」は、初めて使う人がいちばん戸惑うので、
        その場で理由を書く。
        """
        if key == "dictionary_as_hints":
            spec = catalog.MODELS.get(self.cfg.str_("model"))
            if spec is not None and not spec.supports_hints:
                return t("dict.hints_unsupported", model=spec.name)
        if key in ("stream_interval_ms", "stream_agree_rounds",
                   "stream_workers"):
            if self.cfg.str_("input_mode", "stream") != "stream":
                return t("settings.stream_only")
        return ""

    def _models(self) -> list[dict]:
        chosen = self.cfg.str_("model", catalog.DEFAULT_MODEL)
        out = []
        for key, spec in catalog.MODELS.items():
            runtime = catalog.RUNTIMES[spec.runtime]
            extra = sum(a.size for a in runtime.assets
                        if not catalog.asset_path(a).exists())
            ready = (catalog.model_ready(key)
                     and catalog.runtime_ready(spec.runtime))
            out.append({
                "key": key, "name": spec.name,
                "summary": pick(spec.ja, spec.en),
                "note": pick(spec.note_ja, spec.note_en),
                "accuracy": spec.accuracy, "speed": spec.speed,
                "cer": spec.cer,
                "size": catalog.human_size(spec.size + extra),
                "license": spec.license, "licenseUrl": spec.license_url,
                "source": spec.source,
                "ready": ready, "chosen": key == chosen,
                # 旧方式（使うたびに読み込む）と CPU 向け。ふだんは畳む
                "legacy": not catalog.is_resident(key),
                "progress": self._downloading.get(key),
            })
        return out

    def _history(self) -> list[dict]:
        rows = []
        for row in self.history.recent(400):
            rows.append({
                "id": row["id"],
                "time": time.strftime("%Y/%m/%d %H:%M",
                                      time.localtime(row["ts"])),
                "text": row["text"],
                "raw_text": row.get("raw_text") or row["text"],
                "seconds": round(row.get("seconds") or 0.0, 1),
                "cancelled": bool(row.get("cancelled")),
                # 録音が残っていれば、画面で聞き直せる
                "audio": bool(row.get("audio"))
                and Path(row["audio"]).is_file(),
            })
        return rows

    def _strings(self) -> dict:
        keys = [
            "dict.hints_unsupported", "settings.stream_only",
            "model.cer_label", "doctor.again", "doctor.all_ok",
            "doctor.some_warn", "doctor.some_bad", "doctor.details",
            "doctor.hide",
            "fillers.hint", "fillers.placeholder", "fillers.default",
            "fillers.reset", "commands.hint", "commands.say",
            "commands.does", "commands.on",
            "symbols.say", "symbols.symbol", "symbols.on", "symbols.add",
            "symbols.empty", "symbols.word_placeholder",
            "symbols.symbol_placeholder",
            "doctor.run", "doctor.idle",
            "doctor.running", "doctor.counts",
            "app.name", "app.tagline", "common.add", "common.edit",
            "common.delete", "common.cancel", "common.save", "common.search",
            "common.import", "common.export", "common.copy", "common.clear",
            "common.download", "common.use", "common.inuse",
            "common.installed", "common.notinstalled", "common.restart_needed",
            "common.autosaved", "common.default", "settings.title",
            "settings.press_keys", "settings.reset_confirm",
            "settings.reset_done", "settings.clear_all_confirm",
            "settings.clear_all_done",
            "dict.from", "dict.to", "dict.empty",
            "dict.reading", "dict.type", "dict.type_auto", "dict.type_direct",
            "dict.advanced",
            "dict.count", "dict.dup", "history.time", "history.text",
            "history.empty", "history.off", "history.clear_confirm",
            "history.copy_item", "history.paste_item", "history.raw_label",
            "history.copied", "history.pasted", "history.merge", "history.merged",
            "model.accuracy", "model.speed", "model.size",
            "model.downloading", "model.download_failed",
            "model.delete_confirm", "web.pick_app", "web.pick_app_title",
            "web.no_apps", "web.add_app", "web.app_placeholder",
            "web.selected", "web.license", "web.source", "web.cer",
            "web.inuse_note", "web.measured", "web.search_placeholder",
            "web.dict_hint", "web.history_hint", "web.about_line",
            "web.about_folder", "web.secs", "web.ms", "web.mins",
            "web.entries", "web.px", "web.done", "web.confirm",
            "web.close", "web.model_source", "web.import_none",
            "web.more_models", "history.search", "history.no_match",
            "web.search_settings", "web.search_result", "web.search_none",
            "web.mode_basic", "web.mode_advanced", "web.basic_hidden",
            "history.play", "history.stop", "history.play_failed",
            "history.to_dict", "history.to_dict_title",
            "history.to_dict_hint", "history.to_dict_done",
        ]
        out = {k: t(k) for k in keys}
        # クリップボードや案内・プリセット・表示・辞書の言葉はまとめて渡す
        for key in i18n.STRINGS:
            if key.startswith(("cweb.", "clip.kind_", "guide.", "presets.", "overlay.", "dict.")):
                out[key] = t(key)
        return out

    # ---------------------------------------------------------- 変更

    # 画面の項目一覧には出さないが、専用の窓（文章変換の API キー）から
    # 書きかえる設定。以前は一覧にないため「unknown key」で弾かれ、
    # API キーを入れても保存されていなかった。
    _HIDDEN_TEXT_KEYS = ("ai_api_key", "ai_model", "ai_provider")
    # たがいに同じキーにしてはいけないショートカット
    _SHORTCUT_KEYS = ("hotkey", "clip_hotkey", "recipe_hotkey")

    def set_value(self, key: str, value: Any) -> dict:
        if key in self._HIDDEN_TEXT_KEYS:
            self.cfg.set(key, str(value or "").strip())
            return {"ok": True}
        item = schema.find(key)
        if item is None:
            return {"ok": False, "error": f"unknown key: {key}"}
        if key in self._SHORTCUT_KEYS and value:
            # 録音・クリップボード・変換の一覧・グループのキーが同じだと、
            # あとから登録したほうが効かなくなる。選んだ時点で断る。
            checked = self.action("clip_api", api="clip_key_check",
                                  payload={"spec": str(value),
                                           "setting": key})
            if isinstance(checked, dict) and not checked.get("ok", True):
                return {"ok": False, "error": checked.get("error")
                        or t("cweb.hotkey_same")}
            from . import hotkeys  # noqa: PLC0415
            mine = hotkeys.normalise(str(value))
            for other in self._SHORTCUT_KEYS:
                if other != key and mine == hotkeys.normalise(
                        self.cfg.str_(other, "")):
                    return {"ok": False, "error": t("cweb.hotkey_same")}
        if item.kind == "int":
            try:
                value = max(item.minimum, min(item.maximum, int(value)))
            except (TypeError, ValueError):
                return {"ok": False, "error": "not a number"}
        elif item.kind == "bool":
            value = bool(value)
        elif item.kind == "applist":
            value = [str(v).strip() for v in (value or []) if str(v).strip()]
        self.cfg.set(key, value)
        if key == "offline_mode":
            downloads.set_offline(bool(value))
        return {"ok": True}

    def run_action(self, name: str, payload: dict) -> dict:
        if name.startswith("clip_"):
            # クリップボード履歴（グループの編集など）は clipwin に任せる
            result = self.action("clip_api", api=name, payload=payload)
            return result if isinstance(result, dict) else {
                "ok": False, "error": "unavailable"}
        if name == "apply_preset":
            pid = str(payload.get("preset", ""))
            preset = next((p for p in schema.PRESETS if p["id"] == pid), None)
            if not preset:
                return {"ok": False, "error": f"unknown preset: {pid}"}
            updates = dict(preset["settings"])
            self.cfg.update(updates)
            log.info("プリセット '%s' を適用しました: %s", pid, updates)
            return {"ok": True, "preset": pid, "applied": list(updates.keys())}
        if name == "test_overlay":
            # 実際のオーバーレイを画面上で 3 秒間テスト表示
            self.action("test_overlay")
            return {"ok": True}
        if name == "test_api":
            from . import transform  # noqa: PLC0415
            prov = str(payload.get("provider",
                                   self.cfg.str_("ai_provider", "auto")))
            key = str(payload.get("api_key",
                                  self.cfg.str_("ai_api_key", "")))
            mdl = str(payload.get("model",
                                  self.cfg.str_("ai_model", "")))
            return transform.test_api_connection(key, provider=prov, model=mdl)
        if name == "add_starter_words":
            # dictionary.sample.txt から定番語（AI、ITツール、頻出フレーズ）を追加
            from .util import SAMPLE_DICT_PATH  # noqa: PLC0415
            if not SAMPLE_DICT_PATH.exists():
                return {"ok": False, "error": "sample dictionary not found"}
            sample_text = SAMPLE_DICT_PATH.read_text("utf-8")
            added = self.dictionary.import_text(sample_text, replace=False)
            self.action("dictionary_changed")
            return {"ok": True, "added": added}
        if name == "diagnostics":
            from . import diagnostics  # noqa: PLC0415
            text = diagnostics.report(self.cfg)
            leaks = diagnostics.contains_secret(text)
            if leaks:
                # 外し忘れがあれば**コピーしない**。
                log.error("診断情報に個人の情報が残っています: %s", leaks)
                return {"ok": False, "error": "個人の情報が残っています"}
            self.action("copy", text=text)
            return {"ok": True, "chars": len(text)}
        if name == "check_update":
            from . import updates  # noqa: PLC0415
            if downloads.is_offline():
                return {"ok": False,
                        "error": "通信が遮断されています（オフラインモード）"}
            info = updates.check(self.cfg.str_("update_repo",
                                               updates.DEFAULT_REPO))
            return {"ok": True, "update": info}
        if name == "apply_update":
            from . import updates  # noqa: PLC0415
            if downloads.is_offline():
                return {"ok": False,
                        "error": "通信が遮断されています（オフラインモード）"}
            info = updates.check(self.cfg.str_("update_repo",
                                               updates.DEFAULT_REPO))
            if not info.get("ok") or not info.get("newer"):
                return {"ok": False, "error": "利用可能な新しい版がありません"}

            def _run_swap():
                import time
                time.sleep(0.5)
                try:
                    updates.perform_update(info)
                    self.action("quit")
                except Exception:
                    log.exception("アップデートの適用に失敗しました")

            threading.Thread(target=_run_swap, daemon=True).start()
            return {"ok": True}
        if name == "onboarding":
            self.cfg.set("onboarding_done", False)
            self.action("open_onboarding")
            return {"ok": True}
        if name == "open_log":
            self.action("open_log")
        elif name == "open_folder":
            self.action("open_folder")
        elif name == "reset":
            self.cfg.reset()
            self.action("config_reset")
            return {"ok": True, "reload": True}
        elif name == "clear_all_data":
            # 1. 履歴と録音音声の完全削除
            self.history.clear()
            from . import history as _hist  # noqa: PLC0415
            if _hist.AUDIO_DIR.exists():
                for p in _hist.AUDIO_DIR.glob("*.wav"):
                    try:
                        p.unlink(missing_ok=True)
                    except OSError:
                        pass
            # 2. 辞書を初期化（空に）
            self.dictionary.save([])
            self.action("dictionary_changed")
            # 3. ログファイルを空に
            for log_file in LOG_DIR.glob("*"):
                if log_file.is_file():
                    try:
                        log_file.write_text("", encoding="utf-8")
                    except OSError:
                        pass
            # 4. 設定を初期値に戻す
            self.cfg.reset()
            self.action("config_reset")
            return {"ok": True, "reload": True}
        elif name == "test_sound":
            from . import sysaudio  # noqa: PLC0415
            theme_val = self.cfg.str_("sound_theme", "default")
            vol_val = self.cfg.int_("sound_volume", 80)
            sysaudio.play("start", theme=theme_val, volume=vol_val)
            return {"ok": True}
        elif name == "dict_save":
            rows = payload.get("rows", [])
            self.dictionary.save(rows)
            self.action("dictionary_changed")
            return {"ok": True}
        elif name == "dict_add":
            # 履歴などから「ユーザー辞書へ追加」
            surface = str(payload.get("to", payload.get("surface", ""))).strip()
            mishearing = str(payload.get("from", payload.get("mishearing", ""))).strip()
            reading = str(payload.get("reading", "")).strip()
            if not surface and mishearing:
                surface = mishearing
                mishearing = ""
            if not surface:
                return {"ok": False}
            rows = self.dictionary.detailed_entries()
            if mishearing:
                if any(r.get("mishearing", "") == mishearing for r in rows):
                    return {"ok": False}
            else:
                if any(r.get("surface") == surface and not r.get("mishearing")
                       for r in rows):
                    return {"ok": False}
            rows.append({"surface": surface, "reading": reading,
                         "mishearing": mishearing})
            self.dictionary.save(rows)
            self.action("dictionary_changed")
            return {"ok": True}
        elif name == "dict_export":
            # ファイルを選ぶのは画面（ブラウザ）の側。ここは中身を返すだけ。
            # アプリ側で窓を出すと tkinter が要り、埋め込み用 Python で
            # 動かせなかった（ROADMAP 6.14）。
            return {"ok": True, "text": self.dictionary.export_text(),
                    "name": "koe-type-dictionary.txt"}
        elif name == "dict_import":
            text = str(payload.get("text", ""))
            if not text.strip():
                return {"ok": True, "added": 0}
            added = self.dictionary.import_text(text)
            self.action("dictionary_changed")
            return {"ok": True, "added": added}
        elif name == "config_export":
            text = json.dumps(self.cfg.as_dict(), ensure_ascii=False, indent=2)
            return {"ok": True, "text": text,
                    "name": "koe-type-settings.json"}
        elif name == "config_import":
            raw = str(payload.get("text", "")).strip()
            if not raw:
                return {"ok": False, "error": "empty"}
            try:
                data = json.loads(raw)
            except Exception as e:
                return {"ok": False, "error": str(e)}
            if not isinstance(data, dict):
                return {"ok": False, "error": "not a dictionary"}
            valid_defaults = schema.defaults()
            count = 0
            for k, v in data.items():
                if k in valid_defaults:
                    self.cfg.set(k, v)
                    count += 1
            self.action("config_reset")
            return {"ok": True, "count": count}
        elif name == "reset_item":
            key = str(payload.get("key", "")).strip()
            item = schema.find(key)
            if item is None and key not in schema.defaults():
                return {"ok": False, "error": "not found"}
            val = (item.default if item is not None
                   else schema.defaults().get(key))
            self.cfg.set(key, val)
            return {"ok": True, "value": val}
        elif name == "history_delete":
            self.history.delete([int(i) for i in payload.get("ids", [])])
        elif name == "history_clear":
            self.history.clear()
        elif name == "history_merge":
            ids = [int(i) for i in payload.get("ids", []) if str(i).isdigit()]
            merged_id = self.history.merge(ids)
            return {"ok": bool(merged_id), "id": merged_id}
        elif name == "copy":
            self.action("copy", text=str(payload.get("text", "")))
        elif name == "paste_text":
            self.action("paste_text", text=str(payload.get("text", "")))
            return {"ok": True}
        elif name == "use_model":
            self.cfg.set("model", str(payload.get("model", "")))
            self.action("model_changed")
        elif name == "delete_model":
            key = str(payload.get("model", ""))
            spec = catalog.MODELS.get(key)
            if key == self.cfg.str_("model"):
                # 使用中のモデルは消せない（消すと文字起こしができなくなる）
                log.info("使用中のモデルなので削除しません: %s", key)
                return {"ok": False, "error": "in use"}
            if spec is not None:
                downloads.remove_assets(list(spec.assets))
        elif name == "download_model":
            self._download(str(payload.get("model", "")))
        elif name == "running_apps":
            return {"ok": True, "apps": self.action("running_apps") or []}
        elif name == "selfcheck":
            return self._selfcheck()
        else:
            return {"ok": False, "error": f"unknown action: {name}"}
        return {"ok": True}

    def _selfcheck(self) -> dict:
        """動作チェックを走らせて、画面に出す形で返す。

        調べるだけで、設定も Windows も書き換えない。
        """
        from . import selfcheck  # noqa: PLC0415
        lang = i18n.language()
        results = selfcheck.run_all(
            model_key=self.cfg.str_("model"),
            hotkey=self.cfg.str_("hotkey", "ctrl+space"),
            excluded=tuple(self.cfg.list_("excluded_apps")))
        rows = []
        for r in results:
            rows.append({
                "key": r.key, "status": r.status,
                "title": r.title_ja if lang == "ja" else r.title_en,
                "detail": r.detail_ja if lang == "ja" else r.detail_en,
                "fix": r.fix_ja if lang == "ja" else r.fix_en,
            })
        return {"ok": True, "results": rows,
                "summary": selfcheck.summary(results)}

    def _download(self, key: str) -> None:
        if downloads.is_offline():
            self.push({"type": "download_done", "model": key,
                       "error": "通信が遮断されています（オフラインモード）"})
            return
        if key in self._downloading or key not in catalog.MODELS:
            return
        missing = catalog.missing_assets(key)
        if not missing:
            return
        self._downloading[key] = 0.0

        total = sum(a.size for a in missing) or 1
        index_of = {"n": 0}

        def progress(_name: str, frac: float) -> None:
            """ファイルごとの進み具合を、全体の割合にならす。"""
            n = index_of["n"]
            got = sum(a.size for a in missing[:n]) + missing[n].size * frac
            self._downloading[key] = min(0.999, got / total)

        def worker() -> None:
            error = ""
            try:
                for index, asset in enumerate(missing):
                    index_of["n"] = index
                    downloads.fetch_asset(asset, progress)
                self._downloading[key] = 1.0
            except Exception as exc:  # noqa: BLE001
                error = str(exc)
                log.exception("モデルのダウンロードに失敗: %s", key)
            self._downloading.pop(key, None)
            self.push({"type": "download_done", "model": key, "error": error})
            if not error:
                self.action("model_downloaded", model=key)

        threading.Thread(target=worker, name="download", daemon=True).start()

    def progress(self) -> dict[str, float]:
        return dict(self._downloading)


# ---------------------------------------------------------------- HTTP


def _make_handler(server: SettingsServer):
    bridge = server.bridge

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "koe-type"
        sys_version = ""

        # --- 共通 ---

        def log_message(self, fmt: str, *args) -> None:  # noqa: ANN002
            log.debug("http %s", fmt % args)

        def handle_one_request(self) -> None:
            # 窓を閉じると、相手がいきなり切る。これは**ふつうのこと**
            # なので、黙って終わる。以前はここで長い赤い文字が出て、
            # 「壊れた」ように見えていた。
            try:
                super().handle_one_request()
            except (ConnectionResetError, ConnectionAbortedError,
                    BrokenPipeError, TimeoutError):
                self.close_connection = True

        def handle_error(self, *_args) -> None:  # noqa: ANN002
            log.debug("設定画面の通信が切れました", exc_info=True)

        def _authorised(self, query: dict) -> bool:
            token = (query.get("t", [""])[0]
                     or self.headers.get("X-Koe-Token", ""))
            if not secrets.compare_digest(token, server.token):
                log.warning("合言葉が合いません: %s", self.path)
                return False
            host = (self.headers.get("Host") or "").split(":")[0]
            if host not in ("127.0.0.1", "localhost"):
                log.warning("Host が不正: %r", self.headers.get("Host"))
                return False
            origin = self.headers.get("Origin")
            if origin and origin not in (f"http://127.0.0.1:{server.port}",
                                         f"http://localhost:{server.port}"):
                log.warning("Origin が不正: %r", origin)
                return False
            return True

        def _send(self, code: int, body: bytes, ctype: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header(
                "Content-Security-Policy",
                "default-src 'none'; script-src 'self'; style-src 'self'; "
                "img-src 'self' data:; connect-src 'self'; font-src 'self'")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionAbortedError):
                pass

        def _json(self, payload: Any, code: int = 200) -> None:
            self._send(code, json.dumps(payload, ensure_ascii=False)
                       .encode("utf-8"), "application/json; charset=utf-8")

        def _deny(self) -> None:
            self._send(403, b"forbidden", "text/plain; charset=utf-8")

        # --- GET ---

        def do_GET(self) -> None:  # noqa: N802
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            if not self._authorised(query):
                self._deny()
                return
            path = parsed.path
            server.page_beat()

            if path == "/" or path == "/index.html":
                self._file("index.html")
            elif path == "/onboarding":
                self._file("onboarding.html")
            elif path == "/api/onboarding":
                self._json(bridge.onboarding.state())
            elif path == "/api/state":
                self._json(bridge.state())
            elif path == "/api/poll":
                self._json({"events": bridge.drain(),
                            "progress": bridge.progress(),
                            "models": bridge._models()})
            elif path == "/api/history_audio":
                self._history_audio(query)
            elif path == "/api/clip_image":
                self._clip_image(query)
            elif path.startswith("/assets/"):
                self._file(path[len("/assets/"):])
            elif path.startswith("/icon/"):
                self._icon(path[len("/icon/"):])
            else:
                self._send(404, b"not found", "text/plain; charset=utf-8")

        def _history_audio(self, query: dict) -> None:
            """履歴に残した録音（WAV）を返す。画面でその場で聞き直すため。

            渡すのは履歴の録音フォルダの中のファイルだけ。番号から
            場所を引くので、画面から任意のパスを指定させない。
            """
            from .history import AUDIO_DIR  # noqa: PLC0415
            try:
                row_id = int(query.get("id", ["0"])[0])
            except ValueError:
                row_id = 0
            path = bridge.history.audio_path(row_id) if row_id else None
            try:
                inside = (path is not None and path.is_file()
                          and AUDIO_DIR.resolve() in path.resolve().parents)
            except OSError:
                inside = False
            if not inside:
                self._send(404, b"not found", "text/plain; charset=utf-8")
                return
            self._send(200, path.read_bytes(), "audio/wav")

        def _clip_image(self, query: dict) -> None:
            """クリップボード履歴の画像。番号から引くので、任意の場所は
            読ませない（history_audio と同じ考え方）。"""
            try:
                clip_id = int(query.get("id", ["0"])[0])
            except ValueError:
                clip_id = 0
            data = bridge.action("clip_image", id=clip_id) if clip_id else b""
            if not data:
                self._send(404, b"not found", "text/plain; charset=utf-8")
                return
            self._send(200, data, "image/png")

        def _icon(self, name: str) -> None:
            """assets/icon/png の PNG だけを配る。"""
            safe = Path(name).name
            path = ICON_PNG_DIR / safe
            if safe.endswith(".png") and path.is_file():
                self._send(200, path.read_bytes(), "image/png")
            else:
                self._send(404, b"not found", "text/plain; charset=utf-8")

        def _file(self, name: str) -> None:
            safe = Path(name).name          # ディレクトリ移動を許さない
            path = WEB_DIR / safe
            if not path.is_file():
                self._send(404, b"not found", "text/plain; charset=utf-8")
                return
            ctype = mimetypes.guess_type(safe)[0] or "application/octet-stream"
            if ctype.startswith("text/") or safe.endswith((".js", ".css")):
                ctype += "; charset=utf-8"
            body = path.read_bytes()
            if safe in ("index.html", "onboarding.html"):
                body = body.replace(b"__TOKEN__", server.token.encode())
            self._send(200, body, ctype)

        # --- POST ---

        def do_POST(self) -> None:  # noqa: N802
            parsed = urllib.parse.urlparse(self.path)
            query = urllib.parse.parse_qs(parsed.query)
            if not self._authorised(query):
                self._deny()
                return
            server.page_beat()
            length = int(self.headers.get("Content-Length") or 0)
            try:
                payload = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                self._json({"ok": False, "error": "bad json"}, 400)
                return

            path = parsed.path
            try:
                if path == "/api/set":
                    self._json(bridge.set_value(payload.get("key", ""),
                                                payload.get("value")))
                elif path == "/api/action":
                    self._json(bridge.run_action(payload.get("name", ""),
                                                 payload))
                elif path == "/api/onboarding":
                    self._json(bridge.onboarding.run(
                        str(payload.get("name", "")), payload))
                elif path == "/api/beat":
                    self._json({"ok": True, "token": server.token})
                elif path == "/api/close":
                    self._json({"ok": True})
                    if not server.keep_open:
                        server.close_soon()
                else:
                    self._json({"ok": False, "error": "unknown"}, 404)
            except Exception as exc:  # noqa: BLE001
                log.exception("設定画面の要求で例外: %s", path)
                self._json({"ok": False, "error": str(exc)}, 500)

    return Handler
