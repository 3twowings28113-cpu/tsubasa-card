"""Galaxy S25風「かこって検索 / 画面AIオーバーレイ」ウィンドウ。

画面全体を薄く暗転させ、マウスで囲んだ範囲（矩形領域）をキャプチャ。
囲んだその場に Galaxy S25 風の「質問・検索オーバーレイパネル」を展開し、
音声や文字でその場で直接 AI に質問したり、Google検索を実行できる。
また、囲まなくても長押しで即座にGeminiが立ち上がり、専用の録音ボタンと
波形パルスアニメーションで音声指示をリアルタイムに受け付ける。

Smart App Control 適合（ctypes + 標準ライブラリのみ、pip 追加一切なし）。
`KOE_TYPE_DRY_RUN=1` のときは画面に触らず、テスト用の領域・回答を返す。
"""

from __future__ import annotations

import ctypes
import logging
import math
import threading
import time
import urllib.parse
from ctypes import c_float, c_uint32, wintypes
from pathlib import Path
from typing import Callable, Final

from . import audio
from . import clipdata
from . import clipgfx
from . import dryrun
from . import vision
from .i18n import t

# 互換シム: 標準 CPython の ctypes.wintypes には HCURSOR が無い
# （HICON / HBRUSH はあるのにカーソル型だけ欠けている）。無いままだと
# 下の _WNDCLASSEXW の定義時点で AttributeError になり、かこって検索が
# import 時点で起動不能になる（2026-10-24 AI PC 実機で確認）。
# 無い環境では、同じハンドル型である HANDLE で代替する。
if not hasattr(wintypes, "HCURSOR"):
    wintypes.HCURSOR = wintypes.HANDLE  # type: ignore[attr-defined]

log = logging.getLogger(__name__)


def _u16len(s: str) -> int:
    """文字列の UTF-16 コード単位数。

    DrawTextW の文字数引数は Python の len()（コードポイント数）では
    なく UTF-16 単位数で数える。サロゲートペアの絵文字が混ざると
    len() では末尾が欠ける（2026-10-25 実機で確認: 「🔍 検索」が
    「検」だけ、「📋 コピー」が「コピ」だけ表示された）。
    """
    return len(s.encode("utf-16-le")) // 2

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32", use_last_error=True)
gdiplus = ctypes.WinDLL("gdiplus", use_last_error=True)

# Win32 定数
WS_POPUP: Final[int] = 0x80000000
WS_VISIBLE: Final[int] = 0x10000000
WS_CHILD: Final[int] = 0x40000000
WS_EX_TOPMOST: Final[int] = 0x00000008
WS_EX_TOOLWINDOW: Final[int] = 0x00000080
SW_SHOW: Final[int] = 5
SW_HIDE: Final[int] = 0

WM_DESTROY: Final[int] = 0x0002
WM_PAINT: Final[int] = 0x000F
WM_ERASEBKGND: Final[int] = 0x0014
WM_KEYDOWN: Final[int] = 0x0100
WM_LBUTTONDOWN: Final[int] = 0x0201
WM_LBUTTONUP: Final[int] = 0x0202
WM_MOUSEMOVE: Final[int] = 0x0200
WM_RBUTTONUP: Final[int] = 0x0205
WM_TIMER: Final[int] = 0x0113

WM_USER: Final[int] = 0x0400
WM_AI_DONE: Final[int] = WM_USER + 101
WM_TRANS_DONE: Final[int] = WM_USER + 102

VK_ESCAPE: Final[int] = 0x1B
VK_RETURN: Final[int] = 0x0D
CS_HREDRAW: Final[int] = 0x0002
CS_VREDRAW: Final[int] = 0x0001
IDC_CROSS: Final[int] = 32515
IDC_ARROW: Final[int] = 32512
IDC_HAND: Final[int] = 32649

SM_XVIRTUALSCREEN: Final[int] = 76
SM_YVIRTUALSCREEN: Final[int] = 77
SM_CXVIRTUALSCREEN: Final[int] = 78
SM_CYVIRTUALSCREEN: Final[int] = 79

ANIM_TIMER_ID: Final[int] = 1001

WNDPROC = ctypes.WINFUNCTYPE(
    ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
    wintypes.WPARAM, wintypes.LPARAM
)

_CLASS_NAME = "KoeTypeSnippingOverlay"
_registered = False
_active_snipper: ScreenSnipper | None = None

# ★多重起動よけ（2026-10-24 改修）。ホットキーの連打や、クリップボード
# 画面とトレイなど複数経路からの同時起動で、全画面オーバーレイと
# マイク録音が重なって開くのを防ぐ。前回の起動から 2 秒以内の再起動も
# 誤爆として捨てる。
_open_lock = threading.Lock()
_last_open_at = 0.0
MIN_REOPEN_GAP_SEC = 2.0


def _global_snipper_proc(hwnd: int, msg: int, wparam: int, lparam: int) -> int:
    global _active_snipper
    if _active_snipper is not None:
        return _active_snipper._proc(hwnd, msg, wparam, lparam)
    return user32.DefWindowProcW(hwnd, msg, wparam, lparam)


_static_wnd_proc = WNDPROC(_global_snipper_proc)


class _WNDCLASSEXW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("style", wintypes.UINT),
        ("lpfnWndProc", ctypes.c_void_p),
        ("cbClsExtra", ctypes.c_int),
        ("cbWndExtra", ctypes.c_int),
        ("hInstance", wintypes.HINSTANCE),
        ("hIcon", wintypes.HICON),
        ("hCursor", wintypes.HCURSOR),
        ("hbrBackground", wintypes.HBRUSH),
        ("lpszMenuName", wintypes.LPCWSTR),
        ("lpszClassName", wintypes.LPCWSTR),
        ("hIconSm", wintypes.HICON),
    ]


class PAINTSTRUCT(ctypes.Structure):
    # 標準 CPython の ctypes.wintypes には PAINTSTRUCT も無い（HCURSOR と
    # 同じ欠落）。_paint が wintypes.PAINTSTRUCT を参照すると WM_PAINT の
    # たびに AttributeError になり、例外は ctypes コールバックに飲まれて
    # 画面が一切描画されなかった（2026-10-25 AI PC 実機で確認: ドラッグ
    # 選択の内部状態は「選択完了」まで進むのに、枠もパネルも出なかった）。
    # clipwin.py と同じく自前の定義を使う。
    _fields_ = [
        ("hdc", wintypes.HDC),
        ("fErase", wintypes.BOOL),
        ("rcPaint", wintypes.RECT),
        ("fRestore", wintypes.BOOL),
        ("fIncUpdate", wintypes.BOOL),
        ("rgbReserved", ctypes.c_byte * 32),
    ]


# user32 のプロトタイプ宣言。宣言が無いと ctypes は戻り値・引数を
# C int (32bit) として扱うため、64bit 環境では HWND の切り捨て
# （self._hwnd が化けて SetTimer 等が無言で失敗する）や、上位ビットが
# 立った LPARAM を渡したときの OverflowError が起きる（未処理
# メッセージを DefWindowProcW へ委譲する経路で実発生を確認済み）。
user32.BeginPaint.restype = wintypes.HDC
user32.BeginPaint.argtypes = [wintypes.HWND, ctypes.POINTER(PAINTSTRUCT)]
user32.EndPaint.restype = wintypes.BOOL
user32.EndPaint.argtypes = [wintypes.HWND, ctypes.POINTER(PAINTSTRUCT)]
user32.DefWindowProcW.restype = ctypes.c_ssize_t
user32.DefWindowProcW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.CreateWindowExW.restype = wintypes.HWND
user32.CreateWindowExW.argtypes = [
    wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
    ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
    wintypes.HWND, wintypes.HANDLE, wintypes.HINSTANCE, ctypes.c_void_p]
user32.GetDC.restype = ctypes.c_void_p
user32.GetDC.argtypes = [wintypes.HWND]
user32.ReleaseDC.restype = ctypes.c_int
user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
user32.DrawTextW.restype = ctypes.c_int
user32.DrawTextW.argtypes = [
    wintypes.HDC, wintypes.LPCWSTR, ctypes.c_int, ctypes.c_void_p,
    wintypes.UINT]
user32.InvalidateRect.restype = wintypes.BOOL
user32.InvalidateRect.argtypes = [
    wintypes.HWND, ctypes.c_void_p, wintypes.BOOL]
user32.SetTimer.restype = ctypes.c_size_t
user32.SetTimer.argtypes = [
    wintypes.HWND, ctypes.c_size_t, wintypes.UINT, ctypes.c_void_p]
user32.KillTimer.restype = wintypes.BOOL
user32.KillTimer.argtypes = [wintypes.HWND, ctypes.c_size_t]
user32.PostMessageW.restype = wintypes.BOOL
user32.PostMessageW.argtypes = [
    wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
user32.DestroyWindow.restype = wintypes.BOOL
user32.DestroyWindow.argtypes = [wintypes.HWND]
user32.SetCapture.restype = wintypes.HWND
user32.SetCapture.argtypes = [wintypes.HWND]
user32.ReleaseCapture.restype = wintypes.BOOL
user32.ReleaseCapture.argtypes = []
user32.SetForegroundWindow.restype = wintypes.BOOL
user32.SetForegroundWindow.argtypes = [wintypes.HWND]
user32.ShowWindow.restype = wintypes.BOOL
user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
user32.UpdateWindow.restype = wintypes.BOOL
user32.UpdateWindow.argtypes = [wintypes.HWND]
user32.GetMessageW.restype = wintypes.BOOL
user32.GetMessageW.argtypes = [
    ctypes.c_void_p, wintypes.HWND, wintypes.UINT, wintypes.UINT]
user32.TranslateMessage.restype = wintypes.BOOL
user32.TranslateMessage.argtypes = [ctypes.c_void_p]
user32.DispatchMessageW.restype = ctypes.c_ssize_t
user32.DispatchMessageW.argtypes = [ctypes.c_void_p]

# gdi32 も同様。HDC/HFONT は 64bit 環境では 2^31 を超える値になり得て、
# 宣言なしの呼び出しでは OverflowError で描画が途中停止した
# （2026-10-25 AI PC 実機: CreateCompatibleDC / SelectObject で確認）。
_vp = ctypes.c_void_p
_i = ctypes.c_int
gdi32.CreateCompatibleDC.restype = _vp
gdi32.CreateCompatibleDC.argtypes = [_vp]
gdi32.CreateCompatibleBitmap.restype = _vp
gdi32.CreateCompatibleBitmap.argtypes = [_vp, _i, _i]
gdi32.SelectObject.restype = _vp
gdi32.SelectObject.argtypes = [_vp, _vp]
gdi32.DeleteObject.restype = wintypes.BOOL
gdi32.DeleteObject.argtypes = [_vp]
gdi32.DeleteDC.restype = wintypes.BOOL
gdi32.DeleteDC.argtypes = [_vp]
gdi32.BitBlt.restype = wintypes.BOOL
gdi32.BitBlt.argtypes = [_vp, _i, _i, _i, _i, _vp, _i, _i, wintypes.DWORD]
gdi32.StretchBlt.restype = wintypes.BOOL
gdi32.StretchBlt.argtypes = [
    _vp, _i, _i, _i, _i, _vp, _i, _i, _i, _i, wintypes.DWORD]
gdi32.SetBkMode.restype = _i
gdi32.SetBkMode.argtypes = [_vp, _i]
gdi32.SetTextColor.restype = wintypes.DWORD
gdi32.SetTextColor.argtypes = [_vp, wintypes.DWORD]

# GDI+ で生の HDC を渡すのは GdipCreateFromHDC だけ（他は c_void_p
# インスタンスと c_float 等で包んだ値を渡すので宣言なしでも壊れない）。
gdiplus.GdipCreateFromHDC.restype = ctypes.c_int
gdiplus.GdipCreateFromHDC.argtypes = [wintypes.HDC, ctypes.c_void_p]


class ScreenSnipper:
    """Galaxy S25風の全画面かこって検索＆対話オーバーレイ。"""

    def __init__(self, cfg=None, engine=None, on_notify=None,
                 interactive: bool = True,
                 ui_scale: float | None = None) -> None:
        self.cfg = cfg
        self.engine = engine
        self._notify = on_notify or (lambda _m, **_kw: None)
        self.interactive = interactive

        # UI 拡大率（パネル・バー・文字などの寸法に掛ける倍率）。
        # 通常は開くときにモニターの DPI から決める（_resolve_ui_scale）。
        # ui_scale 引数はテスト等からの固定用で、実測より優先する。
        self._ui_scale_arg: float | None = ui_scale
        self._ui_scale: float = (
            self._clamp_ui_scale(ui_scale) if ui_scale is not None
            else 1.0)

        self.result: tuple[int, int, int, int] | None = None
        self._hwnd: int = 0

        self._phase: str = "selecting"      # "selecting" | "selected"
        self._ai_status: str = "listening"  # "listening" | "recognizing" | "busy" | "done" | "idle"
        self._ai_answer: str = ""
        self._question_text: str = ""

        # マイク・音声指示管理
        self._recorder: audio.Recorder | None = None
        self._audio_chunks: list[bytes] = []
        self._mic_level: float = 0.0
        self._anim_tick: int = 0
        self._has_speech: bool = False
        self._speech_last_time: float = 0.0

        self._dragging: bool = False
        self._start_x: int = 0
        self._start_y: int = 0
        self._cur_x: int = 0
        self._cur_y: int = 0

        self._screen_x: int = 0
        self._screen_y: int = 0
        self._screen_w: int = 0
        self._screen_h: int = 0
        self._screen_hbm: int = 0
        self._screen_dc: int = 0

        self._selected_rect: tuple[int, int, int, int] = (0, 0, 0, 0)
        self._thumb_img: bytes = b""
        self._hover_btn: str = ""
        self._fonts: clipgfx.Fonts | None = None

        # ボタン領域キャッシュ: name -> (x, y, w, h)
        self._hit_rects: dict[str, tuple[float, float, float, float]] = {}

    @staticmethod
    def _clamp_ui_scale(v: float) -> float:
        """拡大率を現実的な範囲（等倍〜3倍）に収める。"""
        return max(1.0, min(3.0, float(v)))

    def _resolve_ui_scale(self) -> float:
        """このオーバーレイを描く拡大率を決める（開くときに1回）。

        ★なぜ要るか: プロセスは「モニターごとの DPI を自分で扱う」
        と宣言している（main._dpi_aware）ので、座標はすべて物理px。
        200%（192dpi）の画面で寸法をそのまま使うと、パネルも文字も
        半分の大きさに見えてしまう（利用者の 2880x1800 機で
        「ちっちゃすぎる」と判明した）。overlay._dpi_factor と同じく
        自分の窓の DPI から倍率を作り、取れなければ等倍に倒す
        （96dpi の画面では今までと完全に同じ描画になる）。
        """
        if self._ui_scale_arg is not None:
            return self._clamp_ui_scale(self._ui_scale_arg)
        dpi = 0
        try:
            if self._hwnd and hasattr(user32, "GetDpiForWindow"):
                dpi = int(user32.GetDpiForWindow(self._hwnd))
            if not dpi and hasattr(user32, "GetDpiForSystem"):
                dpi = int(user32.GetDpiForSystem())
        except Exception:  # noqa: BLE001
            dpi = 0
        return self._clamp_ui_scale(dpi / 96.0) if dpi else 1.0

    def _s(self, v: float) -> float:
        """寸法に UI 拡大率を掛ける（1.0 のときは渡した値そのもの）。"""
        return v * self._ui_scale

    def _font_px(self, px: float) -> int:
        """フォントの大きさ（px）に UI 拡大率を掛けた整数px。"""
        return max(6, int(round(px * self._ui_scale)))

    def _font(self, px: float, *, weight: int = 400) -> int:
        """拡大率を掛けた大きさのフォントを返す（未用意なら 0）。

        描画側が self._fonts を用意してから呼ぶ前提で、今までどおり
        フォントが無ければ 0 を返し、描かない経路に倒す。
        """
        if self._fonts is None:
            return 0
        return self._fonts.get(self._font_px(px), weight=weight)

    def _ensure_class(self) -> bool:
        global _registered
        if _registered:
            return True
        hcursor = user32.LoadCursorW(0, IDC_CROSS)

        wc = _WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(_WNDCLASSEXW)
        wc.style = CS_HREDRAW | CS_VREDRAW
        wc.lpfnWndProc = ctypes.cast(_static_wnd_proc, ctypes.c_void_p).value
        wc.cbClsExtra = 0
        wc.cbWndExtra = 0
        wc.hInstance = 0
        wc.hIcon = 0
        wc.hCursor = hcursor
        wc.hbrBackground = 0
        wc.lpszMenuName = None
        wc.lpszClassName = _CLASS_NAME
        wc.hIconSm = 0

        atom = user32.RegisterClassExW(ctypes.byref(wc))
        if atom or ctypes.get_last_error() == 1410:
            _registered = True
            return True
        log.warning("スニッピングウィンドウクラスの登録失敗: %s",
                    ctypes.get_last_error())
        return False

    def _capture_screen_to_bitmap(self) -> None:
        """初期画面のキャプチャを保持する。"""
        self._screen_x = user32.GetSystemMetrics(SM_XVIRTUALSCREEN)
        self._screen_y = user32.GetSystemMetrics(SM_YVIRTUALSCREEN)
        self._screen_w = max(100, user32.GetSystemMetrics(SM_CXVIRTUALSCREEN))
        self._screen_h = max(100, user32.GetSystemMetrics(SM_CYVIRTUALSCREEN))

        hdc_screen = user32.GetDC(0)
        self._screen_dc = gdi32.CreateCompatibleDC(hdc_screen)
        self._screen_hbm = gdi32.CreateCompatibleBitmap(
            hdc_screen, self._screen_w, self._screen_h
        )
        gdi32.SelectObject(self._screen_dc, self._screen_hbm)

        SRCCOPY_CAPTUREBLT = 0x00CC0020 | 0x40000000
        gdi32.BitBlt(
            self._screen_dc, 0, 0, self._screen_w, self._screen_h,
            hdc_screen, self._screen_x, self._screen_y, SRCCOPY_CAPTUREBLT
        )
        user32.ReleaseDC(0, hdc_screen)

    # ---------------------------------------------------------------- 音声入力
    def _start_listening(self) -> None:
        """マイク録音を開始し、リアルタイム音声指示を受付。"""
        self._audio_chunks.clear()
        self._has_speech = False
        self._speech_last_time = 0.0
        self._ai_status = "listening"

        device_name = self.cfg.str_("audio_device", "") if self.cfg else ""
        try:
            self._recorder = audio.Recorder(on_chunk=self._on_audio_chunk)
            self._recorder.device_name = device_name
            self._recorder.preroll_ms = 100
            self._recorder.start()
            log.info("画面AIオーバーレイ: 音声指示受付を開始しました")
        except Exception as exc:
            log.warning("画面AIオーバーレイ: マイク起動失敗: %s", exc)
            self._ai_status = "idle"

    def _on_audio_chunk(self, chunk: bytes) -> None:
        """録音ブロックを受信し、音量を計算。"""
        if not chunk or self._ai_status != "listening":
            return
        self._audio_chunks.append(chunk)

        # 簡易 RMS 音量計算
        step = max(2, (len(chunk) // 200) * 2)
        tot = 0
        cnt = 0
        for i in range(0, len(chunk) - 1, step):
            val = int.from_bytes(chunk[i:i + 2], byteorder="little", signed=True)
            tot += val * val
            cnt += 1
        rms = math.sqrt(tot / max(1, cnt))
        cur_lvl = min(1.0, max(0.0, (rms - 150) / 3200.0))
        # 滑らかに減衰
        self._mic_level = self._mic_level * 0.35 + cur_lvl * 0.65

        if cur_lvl > 0.12:
            self._has_speech = True
            self._speech_last_time = time.monotonic()

    def _stop_listening_and_transcribe(self) -> None:
        """音声入力を完了し、音声認識エンジンで文字化してAIへ送る。"""
        if self._recorder is not None:
            try:
                self._recorder.stop()
            except Exception:
                pass
            self._recorder = None

        self._ai_status = "recognizing"
        if self._hwnd:
            user32.InvalidateRect(self._hwnd, None, False)

        def _worker() -> None:
            pcm = b"".join(self._audio_chunks)
            text = ""
            if pcm and self.engine and hasattr(self.engine, "transcribe_pcm"):
                try:
                    text = self.engine.transcribe_pcm(pcm)
                except Exception as exc:
                    log.warning("音声認識エラー: %s", exc)

            if not text:
                text = self._question_text or "この画面について詳しく解説・検索してください"

            self._question_text = text
            if self._hwnd:
                user32.PostMessageW(self._hwnd, WM_TRANS_DONE, 0, 0)
            self._submit_question(text)

        threading.Thread(target=_worker, name="snipping-transcribe",
                         daemon=True).start()

    def _proc(self, hwnd: int, msg: int, wparam: int, lparam: int) -> int:
        if msg == WM_ERASEBKGND:
            return 1

        if msg == WM_TIMER:
            if wparam == ANIM_TIMER_ID:
                self._anim_tick += 1
                if (self._ai_status in ("idle", "done")
                        and not self._dragging
                        and self._phase == "selecting"):
                    # 待機中は何も動いていないので再描画しない
                    # （全画面 GDI+ 再描画はこの画面で一番重い処理）
                    return 0
                # 音声認識自動トリガー（話し終わって1.8秒経過）
                if (self._ai_status == "listening" and self._has_speech
                        and self._speech_last_time > 0
                        and (time.monotonic() - self._speech_last_time > 1.8)):
                    self._stop_listening_and_transcribe()
                user32.InvalidateRect(hwnd, None, False)
                return 0

        elif msg == WM_KEYDOWN:
            if wparam == VK_ESCAPE:
                user32.DestroyWindow(hwnd)
                return 0
            if wparam == VK_RETURN:
                if self._ai_status == "listening":
                    self._stop_listening_and_transcribe()
                    return 0
                prompt = self._question_text or "この画像について解説してください"
                self._submit_question(prompt)
                return 0

        elif msg == 0x0102:  # WM_CHAR
            if self._ai_status not in ("busy", "recognizing"):
                ch = chr(wparam & 0xFFFF)
                if ch in ("\r", "\n"):
                    prompt = self._question_text or "この画像について解説してください"
                    self._submit_question(prompt)
                    return 0
                elif ch == "\b":
                    if self._question_text:
                        self._question_text = self._question_text[:-1]
                        user32.InvalidateRect(hwnd, None, False)
                    return 0
                elif ord(ch) >= 32:
                    self._question_text += ch
                    user32.InvalidateRect(hwnd, None, False)
                    return 0

        elif msg == WM_TRANS_DONE:
            user32.InvalidateRect(hwnd, None, False)
            return 0

        elif msg == WM_AI_DONE:
            self._ai_status = "done"
            user32.InvalidateRect(hwnd, None, False)
            return 0

        elif msg == WM_RBUTTONUP:
            if self._phase == "selected":
                # 再度選択モードに戻す
                self._phase = "selecting"
                self._ai_status = "idle"
                self._ai_answer = ""
                user32.InvalidateRect(hwnd, None, False)
                return 0
            user32.DestroyWindow(hwnd)
            return 0

        elif msg == WM_LBUTTONDOWN:
            x = ctypes.c_short(lparam & 0xFFFF).value
            y = ctypes.c_short((lparam >> 16) & 0xFFFF).value

            # ボタンクリック判定
            clicked = self._hit_test(x, y)
            if clicked:
                self._on_button_click(clicked)
                return 0

            if self._phase == "selected":
                # シートの外側をクリックしたら閉じる
                sheet_rect = self._hit_rects.get("sheet")
                if sheet_rect:
                    sx, sy, sw, sh = sheet_rect
                    if not (sx <= x <= sx + sw and sy <= y <= sy + sh):
                        user32.DestroyWindow(hwnd)
                        return 0
                return 0

            # 囲み選択の開始
            self._dragging = True
            self._start_x = x
            self._start_y = y
            self._cur_x = x
            self._cur_y = y
            user32.SetCapture(hwnd)
            return 0

        elif msg == WM_MOUSEMOVE:
            x = ctypes.c_short(lparam & 0xFFFF).value
            y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
            if self._dragging:
                self._cur_x = x
                self._cur_y = y
                user32.InvalidateRect(hwnd, None, False)
                return 0

            prev_hover = self._hover_btn
            self._hover_btn = self._hit_test(x, y)
            if self._hover_btn != prev_hover:
                user32.InvalidateRect(hwnd, None, False)
            return 0

        elif msg == WM_LBUTTONUP:
            if self._dragging:
                self._dragging = False
                user32.ReleaseCapture()
                x = ctypes.c_short(lparam & 0xFFFF).value
                y = ctypes.c_short((lparam >> 16) & 0xFFFF).value
                rx = min(self._start_x, x)
                ry = min(self._start_y, y)
                rw = abs(x - self._start_x)
                rh = abs(y - self._start_y)

                if rw < 12 and rh < 12:
                    # ★単なるクリックは「やめる」（2026-10-24 改修）。
                    # 以前は全画面選択として処理され、ボタンの押し間違いや
                    # 誤クリック 1 回で全画面キャプチャ＋AI 実行に進む
                    # 暴発経路になっていた。本家（Galaxy のかこって検索）
                    # でも、選択は囲む操作でのみ確定する。
                    user32.DestroyWindow(hwnd)
                    return 0

                self._selected_rect = (rx, ry, max(1, rw), max(1, rh))
                self.result = (self._screen_x + rx, self._screen_y + ry,
                               max(1, rw), max(1, rh))

                if not self.interactive:
                    user32.DestroyWindow(hwnd)
                    return 0

                # 選択完了フェーズへ移行！
                self._phase = "selected"
                self._prepare_thumbnail()

                # 囲みながら話していた場合のみ音声指示を処理し、それ以外は操作待ち
                if self._ai_status == "listening" and self._has_speech:
                    self._stop_listening_and_transcribe()
                else:
                    self._ai_status = "idle"
                    self._ai_answer = (
                        "囲んだ領域を選択しました。\n"
                        "枠下のボタンで「文字コピー」や「画像検索」、\n"
                        "右のシートからマイクや文字で質問できます。"
                    )
                user32.InvalidateRect(hwnd, None, False)
            return 0

        elif msg == WM_PAINT:
            self._paint(hwnd)
            return 0

        elif msg == WM_DESTROY:
            user32.KillTimer(hwnd, ANIM_TIMER_ID)
            if self._recorder is not None:
                try:
                    self._recorder.stop()
                except Exception:
                    pass
                self._recorder = None
            user32.PostQuitMessage(0)
            return 0

        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    def _prepare_thumbnail(self) -> None:
        """選択領域から生の画面DCをもとにJPEG画像を抽出する。"""
        rx, ry, rw, rh = self._selected_rect
        if rw <= 0 or rh <= 0 or not self._screen_dc:
            return
        self._thumb_img = vision.capture_dc_rect(
            self._screen_dc, rx, ry, rw, rh, max_dimension=1600
        )

    def _hit_test(self, x: int, y: int) -> str:
        for name, (bx, by, bw, bh) in self._hit_rects.items():
            if name == "sheet":
                continue
            if bx <= x <= bx + bw and by <= y <= by + bh:
                return name
        return ""

    def _copy_image_to_clipboard(self) -> None:
        """選択範囲の画像をクリップボードにPNGとして保存する。"""
        rx, ry, rw, rh = self._selected_rect
        if rw <= 0 or rh <= 0 or not self._screen_dc:
            return
        try:
            png_bytes = vision.capture_dc_png(self._screen_dc, rx, ry, rw, rh)
            if png_bytes:
                clipdata.write(0, png=png_bytes)
        except Exception as exc:
            log.warning("画像クリップボード保存エラー: %s", exc)

    def _on_button_click(self, name: str) -> None:
        if name == "close":
            user32.DestroyWindow(self._hwnd)
        elif name == "btn_mic":
            self._toggle_voice_input()
        elif name == "btn_submit":
            prompt = self._question_text or "この画像について解説してください"
            self._submit_question(prompt, action_type="ask")
        elif name == "btn_search":
            self._copy_image_to_clipboard()
            self._submit_question(
                "Googleで検索するためのキーワードを出力してください",
                action_type="search"
            )
        elif name == "float_lens":
            self._on_google_lens_search()
        elif name in ("btn_ask",):
            self._submit_question("この画像について詳しく解説・説明してください",
                                  action_type="ask")
        elif name in ("btn_ocr", "float_ocr"):
            self._on_ocr_copy()
        elif name in ("btn_translate", "float_translate"):
            self._submit_question(
                "画像内の外国語を日本語に自然に翻訳してください",
                action_type="translate"
            )
        elif name == "btn_copy":
            self._copy_answer()
        elif name == "btn_open_google":
            self._open_in_google()
        elif name == "btn_settings":
            self._open_settings_page()

    def _on_ocr_copy(self) -> None:
        """囲んだ画像内の文字を抽出し、クリップボードに即座にコピーする。"""
        self._copy_image_to_clipboard()
        self._submit_question(
            "画像内の文字を正確にすべて書き起こしてください",
            action_type="ocr"
        )

    def _on_google_lens_search(self) -> None:
        """Google 画像検索 / レンズを開く。"""
        import webbrowser
        self._copy_image_to_clipboard()
        webbrowser.open("https://images.google.com/")
        self._notify("🔍 画像をクリップボードに保存し、Google画像検索を開きました")

    def _open_in_google(self) -> None:
        """ブラウザで Google 検索を開く。"""
        import webbrowser
        q = self._question_text or "画像検索"
        url = f"https://www.google.com/search?q={urllib.parse.quote(q)}"
        webbrowser.open(url)

    def _open_settings_page(self) -> None:
        """設定画面を開く。"""
        from . import websettings
        websettings.open_settings("api")

    def _copy_answer(self) -> None:
        if not self._ai_answer:
            return
        clipdata.write(0, text=self._ai_answer)
        self._notify("📋 クリップボードにコピーしました")

    def _toggle_voice_input(self) -> None:
        if self._ai_status == "listening":
            self._stop_listening_and_transcribe()
        else:
            self._start_listening()
            user32.InvalidateRect(self._hwnd, None, False)
            self._notify("🎙️ 話しかけてください（話し終わると自動送信）")

    def _submit_question(self, prompt: str, action_type: str = "ask") -> None:
        if not prompt:
            prompt = "この画像について詳しく解説・検索してください"
        self._question_text = prompt
        self._ai_status = "busy"
        if action_type == "ocr":
            self._ai_answer = "📋 画像内の文字を読み取っています..."
        elif action_type == "translate":
            self._ai_answer = "🌐 画像内のテキストを翻訳しています..."
        else:
            self._ai_answer = "✨ AI が画像を解析しています..."
        if self._hwnd:
            user32.InvalidateRect(self._hwnd, None, False)

        threading.Thread(
            target=self._query_ai_worker,
            args=(prompt, action_type),
            daemon=True
        ).start()

    def _query_ai_worker(self, prompt: str, action_type: str) -> None:
        from . import transform  # noqa: PLC0415
        import webbrowser  # noqa: PLC0415

        rx, ry, rw, rh = self._selected_rect
        if not self._thumb_img and self._screen_dc:
            self._thumb_img = vision.capture_dc_rect(
                self._screen_dc, rx, ry, max(1, rw), max(1, rh)
            )
        img_bytes = self._thumb_img or vision.capture_window_or_screen()

        api_key = self.cfg.str_("ai_api_key", "") if self.cfg else ""
        provider = self.cfg.str_("ai_provider", "auto") if self.cfg else "auto"
        model = (self.cfg.str_("ai_model", transform.DEFAULT_GEMINI_MODEL)
                 if self.cfg else transform.DEFAULT_GEMINI_MODEL)
        is_offline = (self.cfg.bool_("offline_mode", False)
                      if self.cfg else False)

        try:
            mode, ans, url = transform.process_screen_assistant(
                prompt,
                img_bytes,
                api_key=api_key,
                provider=provider,
                model=model,
                is_offline=is_offline,
                action_type=action_type,
            )
            if action_type == "ocr" and ans:
                # OCR の場合は自動でクリップボードに抽出テキストをコピー！
                clipdata.write(0, text=ans)
                self._notify(f"📋 {len(ans)} 文字をコピーしました")
                self._ai_answer = f"📋 文字をコピーしました:\n\n{ans}"
            elif mode == "search" and url and action_type == "search":
                webbrowser.open(url)
                self._ai_answer = f"🔍 Google検索を開きました:\n{ans}"
            elif mode == "calendar" and url:
                webbrowser.open(url)
                self._ai_answer = f"📅 Googleカレンダーを開きました:\n{ans}"
            else:
                self._ai_answer = ans
        except Exception as exc:
            log.warning("AI問い合わせエラー: %s", exc)
            self._ai_answer = f"エラーが発生しました: {exc}"

        if self._hwnd:
            user32.PostMessageW(self._hwnd, WM_AI_DONE, 0, 0)

    # ---------------------------------------------------------------- 描画
    def _paint(self, hwnd: int) -> None:
        ps = PAINTSTRUCT()
        hdc = user32.BeginPaint(hwnd, ctypes.byref(ps))
        if not hdc:
            return

        w, h = self._screen_w, self._screen_h
        mem_dc = gdi32.CreateCompatibleDC(hdc)
        mem_bmp = gdi32.CreateCompatibleBitmap(hdc, w, h)
        old_bmp = gdi32.SelectObject(mem_dc, mem_bmp)

        # 1. 画面全体の背景
        gdi32.BitBlt(mem_dc, 0, 0, w, h, self._screen_dc, 0, 0, 0x00CC0020)

        # 2. GDI+ によるオーバーレイ
        graphics = ctypes.c_void_p()
        if gdiplus.GdipCreateFromHDC(mem_dc, ctypes.byref(graphics)) == 0:
            gdiplus.GdipSetSmoothingMode(graphics, 2)  # HighQuality

            dim_brush = ctypes.c_void_p()
            # 半透明ダークブルー暗転 (0x990A0B16)
            gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0x990A0B16),
                                        ctypes.byref(dim_brush))

            if self._phase == "selecting":
                if not self._dragging:
                    gdiplus.GdipFillRectangle(
                        graphics, dim_brush,
                        c_float(0), c_float(0),
                        c_float(w), c_float(h)
                    )
                    self._draw_initial_gemini_bar(graphics, mem_dc, w, h)
                else:
                    self._draw_cutout_and_selection(graphics, dim_brush, w, h)
            else:
                # 選択完了フェーズ（Galaxy S25 かこって検索モード）
                self._draw_cutout_and_selection(graphics, dim_brush, w, h)
                self._draw_floating_action_bar(graphics, mem_dc, w, h)
                self._draw_galaxy_panel(graphics, mem_dc, w, h)

            gdiplus.GdipDeleteBrush(dim_brush)
            gdiplus.GdipDeleteGraphics(graphics)

        gdi32.BitBlt(hdc, 0, 0, w, h, mem_dc, 0, 0, 0x00CC0020)
        gdi32.SelectObject(mem_dc, old_bmp)
        gdi32.DeleteObject(mem_bmp)
        gdi32.DeleteDC(mem_dc)
        user32.EndPaint(hwnd, ctypes.byref(ps))

    def _draw_initial_gemini_bar(self, graphics: ctypes.c_void_p, hdc: int,
                                 width: int, height: int) -> None:
        """初期状態：画面下部にSpeakPulse Gemini専用バーを表示。"""
        self._hit_rects.clear()

        s = self._s
        bar_w, bar_h = s(560.0), s(56.0)
        bx = (float(width) - bar_w) / 2.0
        by = float(height) - s(88.0)

        # ピル背景 (#181A22, alpha=0.96)
        p_brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xF5181A22),
                                    ctypes.byref(p_brush))
        path = self._round_rect_path(bx, by, bar_w, bar_h, s(28.0))
        gdiplus.GdipFillPath(graphics, p_brush, path)
        gdiplus.GdipDeleteBrush(p_brush)

        # ピル境界線（Galaxy Blue / Cyan グロー）
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0x88388BFD),
                               c_float(s(1.6)), 0, ctypes.byref(pen))
        gdiplus.GdipDrawPath(graphics, pen, path)
        gdiplus.GdipDeletePen(pen)
        gdiplus.GdipDeletePath(path)

        # Google "G" アイコン
        self._draw_google_g_icon(graphics, bx + s(18.0), by + s(18.0),
                                 s(20.0))

        # SpeakPulse 録音中ボタン（右端）
        mic_x = bx + bar_w - s(46.0)
        mic_y = by + s(8.0)
        mic_sz = s(40.0)
        self._hit_rects["btn_mic"] = (mic_x, mic_y, mic_sz, mic_sz)
        self._draw_pulse_mic_button(graphics, mic_x, mic_y, mic_sz)

        # テキスト描画 (GDI)
        gdiplus.GdipFlush(graphics, 1)
        clipgfx.start()
        if self._fonts is None:
            self._fonts = clipgfx.Fonts()

        font_label = self._font(13)
        old_font = gdi32.SelectObject(hdc, font_label)
        gdi32.SetBkMode(hdc, 1)  # TRANSPARENT

        if self._ai_status == "listening":
            gdi32.SetTextColor(hdc, 0x00FFFFFF)
            lbl = "🎙️ SpeakPulse AI 音声指示受付中…（話しかけるか画面を囲んでください）"
        elif self._ai_status == "recognizing":
            gdi32.SetTextColor(hdc, 0x00FD8B38)
            lbl = "⏳ 音声を文字に変換しています…"
        else:
            gdi32.SetTextColor(hdc, 0x00C0C4D0)
            lbl = "画面をくるっと囲むか、マイクで話しかけてください"

        rect_t = clipgfx.RECT(int(bx + s(48.0)), int(by + s(16.0)),
                              int(mic_x - s(12.0)), int(by + s(40.0)))
        user32.DrawTextW(hdc, lbl, _u16len(lbl), ctypes.byref(rect_t), 0x0024)
        gdi32.SelectObject(hdc, old_font)

    def _draw_cutout_and_selection(self, graphics: ctypes.c_void_p,
                                   dim_brush: ctypes.c_void_p,
                                   w: int, h: int) -> None:
        """選択範囲以外を暗転させ、選択範囲に四隅ホワイトブラケットを描画。"""
        if self._phase == "selecting":
            rx = float(min(self._start_x, self._cur_x))
            ry = float(min(self._start_y, self._cur_y))
            rw = float(abs(self._cur_x - self._start_x))
            rh = float(abs(self._cur_y - self._start_y))
        else:
            rx, ry, rw, rh = (float(v) for v in self._selected_rect)

        # 暗転
        gdiplus.GdipFillRectangle(graphics, dim_brush, c_float(0), c_float(0),
                                  c_float(w), c_float(ry))
        gdiplus.GdipFillRectangle(graphics, dim_brush, c_float(0), c_float(ry + rh),
                                  c_float(w), c_float(max(0.0, h - (ry + rh))))
        gdiplus.GdipFillRectangle(graphics, dim_brush, c_float(0), c_float(ry),
                                  c_float(rx), c_float(rh))
        gdiplus.GdipFillRectangle(graphics, dim_brush, c_float(rx + rw), c_float(ry),
                                  c_float(max(0.0, w - (rx + rw))), c_float(rh))

        # 選択枠（Galaxy Blue #388BFD）
        pen_blue = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0x99388BFD), c_float(1.8), 0,
                               ctypes.byref(pen_blue))
        gdiplus.GdipDrawRectangle(graphics, pen_blue, c_float(rx), c_float(ry),
                                  c_float(rw), c_float(rh))
        gdiplus.GdipDeletePen(pen_blue)

        # 四隅のホワイトブラケット（┏ ┓ ┗ ┛）
        pen_white = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0xFFFFFFFF), c_float(3.2), 0,
                               ctypes.byref(pen_white))
        gdiplus.GdipSetPenStartCap(pen_white, 2)  # RoundCap
        gdiplus.GdipSetPenEndCap(pen_white, 2)

        blen = min(22.0, rw / 3.0, rh / 3.0)
        # 左上
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx), c_float(ry + blen),
                             c_float(rx), c_float(ry))
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx), c_float(ry),
                             c_float(rx + blen), c_float(ry))
        # 右上
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx + rw - blen), c_float(ry),
                             c_float(rx + rw), c_float(ry))
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx + rw), c_float(ry),
                             c_float(rx + rw), c_float(ry + blen))
        # 左下
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx), c_float(ry + rh - blen),
                             c_float(rx), c_float(ry + rh))
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx), c_float(ry + rh),
                             c_float(rx + blen), c_float(ry + rh))
        # 右下
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx + rw - blen), c_float(ry + rh),
                             c_float(rx + rw), c_float(ry + rh))
        gdiplus.GdipDrawLine(graphics, pen_white, c_float(rx + rw), c_float(ry + rh),
                             c_float(rx + rw), c_float(ry + rh - blen))

        gdiplus.GdipDeletePen(pen_white)

    def _draw_floating_action_bar(self, graphics: ctypes.c_void_p, hdc: int,
                                  w: int, h: int) -> None:
        """囲み枠直下の3連フローティングボタン（画像検索・文字コピー・翻訳）。"""
        rx, ry, rw, rh = (float(v) for v in self._selected_rect)
        if rw < 10 or rh < 10:
            return

        s = self._s
        bar_w = s(144.0)
        bar_h = s(40.0)
        # 枠の直下左側、画面下にはみ出るなら枠上部に配置
        bx = rx
        by = ry + rh + s(10.0)
        if by + bar_h > float(h) - s(10.0):
            by = max(s(10.0), ry - bar_h - s(10.0))
        if bx + bar_w > float(w) - s(10.0):
            bx = max(s(10.0), float(w) - bar_w - s(10.0))

        # カプセル背景 (#1F2129, alpha=0.96)
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xF61F2129),
                                    ctypes.byref(brush))
        path = self._round_rect_path(bx, by, bar_w, bar_h, s(20.0))
        gdiplus.GdipFillPath(graphics, brush, path)
        gdiplus.GdipDeleteBrush(brush)

        # 境界線
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0x55FFFFFF), c_float(s(1.2)),
                               0, ctypes.byref(pen))
        gdiplus.GdipDrawPath(graphics, pen, path)
        gdiplus.GdipDeletePen(pen)
        gdiplus.GdipDeletePath(path)

        # 3つのボタン: float_lens, float_ocr, float_translate
        btn_defs = [
            ("float_lens", "lens"),
            ("float_ocr", "ocr"),
            ("float_translate", "translate"),
        ]
        btn_w = s(40.0)
        btn_h = s(32.0)
        btn_y = by + s(4.0)

        for i, (bid, kind) in enumerate(btn_defs):
            btn_x = bx + s(6.0) + float(i) * s(44.0)
            self._hit_rects[bid] = (btn_x, btn_y, btn_w, btn_h)
            is_hover = (self._hover_btn == bid)
            if is_hover:
                h_brush = ctypes.c_void_p()
                gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xFF383C4C),
                                            ctypes.byref(h_brush))
                h_path = self._round_rect_path(btn_x, btn_y, btn_w, btn_h,
                                               s(16.0))
                gdiplus.GdipFillPath(graphics, h_brush, h_path)
                gdiplus.GdipDeleteBrush(h_brush)
                gdiplus.GdipDeletePath(h_path)

            if kind == "lens":
                self._draw_lens_glyph(graphics, btn_x + s(10.0),
                                      btn_y + s(6.0), s(20.0))
            elif kind == "ocr":
                self._draw_copy_glyph(graphics, btn_x + s(10.0),
                                      btn_y + s(6.0), s(20.0))
            elif kind == "translate":
                self._draw_translate_glyph(graphics, hdc, btn_x + s(8.0),
                                           btn_y + s(6.0), s(24.0))

    def _draw_galaxy_panel(self, graphics: ctypes.c_void_p, hdc: int,
                           width: int, height: int) -> None:
        """Galaxy S25風の対話オーバーレイシート（Google アプリ風）。"""
        rx, ry, rw, rh = (float(v) for v in self._selected_rect)

        # ★寸法はすべて _s() で拡大率を掛ける。配置のしきい値（380）も
        # パネル幅と同じ単位で比べないと、拡大時に判定だけ等倍のまま
        # になってレイアウトが崩れる。
        s = self._s
        # 囲み枠の右側に十分なスペースがあれば右側に縦長シートを配置
        right_space = float(width) - (rx + rw)
        left_space = rx
        if right_space >= s(380.0):
            panel_w = min(s(420.0), right_space - s(24.0))
            panel_h = min(float(height) - s(40.0), s(540.0))
            px = rx + rw + s(14.0)
            py = max(s(16.0), min(ry, float(height) - panel_h - s(16.0)))
        elif left_space >= s(380.0):
            panel_w = min(s(420.0), left_space - s(24.0))
            panel_h = min(float(height) - s(40.0), s(540.0))
            px = rx - panel_w - s(14.0)
            py = max(s(16.0), min(ry, float(height) - panel_h - s(16.0)))
        else:
            # 左右に余白がない場合は下部に横長配置
            panel_w = min(s(680.0), float(width) - s(32.0))
            panel_h = (s(340.0) if (self._ai_answer
                                    or self._ai_status == "busy")
                       else s(220.0))
            px = (float(width) - panel_w) / 2.0
            py = float(height) - panel_h - s(20.0)

        self._hit_rects["sheet"] = (px, py, panel_w, panel_h)

        # パネル背景（#1E2028, alpha=0.96）
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xF61E2028),
                                    ctypes.byref(brush))
        path = self._round_rect_path(px, py, panel_w, panel_h, s(18.0))
        gdiplus.GdipFillPath(graphics, brush, path)
        gdiplus.GdipDeleteBrush(brush)

        # 境界線
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0x55388BFD), c_float(s(1.5)),
                               0, ctypes.byref(pen))
        gdiplus.GdipDrawPath(graphics, pen, path)
        gdiplus.GdipDeletePen(pen)
        gdiplus.GdipDeletePath(path)

        # ドラッグハンドル
        hx = px + (panel_w - s(38.0)) / 2.0
        hy = py + s(8.0)
        hbrush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xFF5A5E6B),
                                    ctypes.byref(hbrush))
        hpath = self._round_rect_path(hx, hy, s(38.0), s(4.0), s(2.0))
        gdiplus.GdipFillPath(graphics, hbrush, hpath)
        gdiplus.GdipDeleteBrush(hbrush)
        gdiplus.GdipDeletePath(hpath)

        # 閉じるボタン (✕)
        cx, cy = px + panel_w - s(30.0), py + s(8.0)
        self._hit_rects["close"] = (cx, cy, s(22.0), s(22.0))
        pen_close = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0xFF8A8E9B),
                               c_float(s(1.6)), 0, ctypes.byref(pen_close))
        gdiplus.GdipDrawLine(graphics, pen_close, c_float(cx + s(4.0)),
                             c_float(cy + s(4.0)), c_float(cx + s(18.0)),
                             c_float(cy + s(18.0)))
        gdiplus.GdipDrawLine(graphics, pen_close, c_float(cx + s(18.0)),
                             c_float(cy + s(4.0)), c_float(cx + s(4.0)),
                             c_float(cy + s(18.0)))
        gdiplus.GdipDeletePen(pen_close)

        # ヘッダーアイコン（Google "G" アイコン）
        self._draw_google_g_icon(graphics, px + s(18.0), py + s(12.0),
                                 s(18.0))

        # 質問入力バー
        bar_x = px + s(16.0)
        bar_y = py + s(38.0)
        bar_w = panel_w - s(32.0)
        bar_h = s(44.0)

        bar_brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xFF2A2D37),
                                    ctypes.byref(bar_brush))
        bar_path = self._round_rect_path(bar_x, bar_y, bar_w, bar_h,
                                         s(22.0))
        gdiplus.GdipFillPath(graphics, bar_brush, bar_path)
        gdiplus.GdipDeleteBrush(bar_brush)

        bar_pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0x55FFFFFF),
                               c_float(s(1.2)), 0, ctypes.byref(bar_pen))
        gdiplus.GdipDrawPath(graphics, bar_pen, bar_path)
        gdiplus.GdipDeletePen(bar_pen)
        gdiplus.GdipDeletePath(bar_path)

        # サムネイル表示枠（左側）
        thumb_x, thumb_y = bar_x + s(8.0), bar_y + s(6.0)
        thumb_sz = s(32.0)
        if rw > 0 and rh > 0 and self._screen_dc:
            gdi32.StretchBlt(
                hdc, int(thumb_x), int(thumb_y), int(thumb_sz), int(thumb_sz),
                self._screen_dc, int(rx), int(ry), int(rw), int(rh), 0x00CC0020
            )
            tpen = ctypes.c_void_p()
            gdiplus.GdipCreatePen1(ctypes.c_uint32(0x88FFFFFF),
                                   c_float(s(1.0)), 0, ctypes.byref(tpen))
            gdiplus.GdipDrawRectangle(graphics, tpen, c_float(thumb_x),
                                      c_float(thumb_y), c_float(thumb_sz),
                                      c_float(thumb_sz))
            gdiplus.GdipDeletePen(tpen)

        # 送信ボタン（右端、↑ アイコン）
        sub_x = bar_x + bar_w - s(36.0)
        sub_y = bar_y + s(6.0)
        sub_sz = s(32.0)
        self._hit_rects["btn_submit"] = (sub_x, sub_y, sub_sz, sub_sz)
        self._draw_submit_arrow_glyph(graphics, sub_x, sub_y, sub_sz)

        # 録音マイクボタン（送信ボタンの左隣）
        mic_x = sub_x - s(36.0)
        mic_y = bar_y + s(6.0)
        mic_sz = s(32.0)
        self._hit_rects["btn_mic"] = (mic_x, mic_y, mic_sz, mic_sz)
        self._draw_pulse_mic_button(graphics, mic_x, mic_y, mic_sz)

        # クイックアクションチップ (ボタン4つ)
        chips = [
            ("btn_ocr", "📋 コピー"),
            ("btn_search", "🔍 検索"),
            ("btn_translate", "🌐 翻訳"),
            ("btn_ask", "✨ 質問"),
        ]
        chip_y = bar_y + s(52.0)
        chip_w = (panel_w - s(48.0)) / 4.0
        chip_h = s(28.0)

        for i, (cid, label) in enumerate(chips):
            cx = bar_x + float(i) * (chip_w + s(4.0))
            self._hit_rects[cid] = (cx, chip_y, chip_w, chip_h)
            is_hover = (self._hover_btn == cid)

            cbg = 0xFF353946 if is_hover else 0xFF242630
            c_brush = ctypes.c_void_p()
            gdiplus.GdipCreateSolidFill(ctypes.c_uint32(cbg),
                                        ctypes.byref(c_brush))
            c_path = self._round_rect_path(cx, chip_y, chip_w, chip_h,
                                           s(14.0))
            gdiplus.GdipFillPath(graphics, c_brush, c_path)
            gdiplus.GdipDeleteBrush(c_brush)

            c_pen = ctypes.c_void_p()
            gdiplus.GdipCreatePen1(
                ctypes.c_uint32(0x55FFFFFF if is_hover else 0x33FFFFFF),
                c_float(s(1.0)), 0, ctypes.byref(c_pen)
            )
            gdiplus.GdipDrawPath(graphics, c_pen, c_path)
            gdiplus.GdipDeletePen(c_pen)
            gdiplus.GdipDeletePath(c_path)

        # GDI によるテキスト描画
        gdiplus.GdipFlush(graphics, 1)
        clipgfx.start()
        if self._fonts is None:
            self._fonts = clipgfx.Fonts()

        # ヘッダータイトルテキスト
        font_hdr_t = self._font(11, weight=700)
        old_font = gdi32.SelectObject(hdc, font_hdr_t)
        gdi32.SetBkMode(hdc, 1)
        gdi32.SetTextColor(hdc, 0x00E0E2E8)
        rect_ht = clipgfx.RECT(int(px + s(44.0)), int(py + s(12.0)),
                               int(px + panel_w - s(40.0)),
                               int(py + s(32.0)))
        hdr_label = "何でも質問 / 画面検索"
        user32.DrawTextW(hdc, hdr_label, _u16len(hdr_label),
                         ctypes.byref(rect_ht), 0x0020)

        # 質問欄テキスト
        font_bar = self._font(12)
        gdi32.SelectObject(hdc, font_bar)
        gdi32.SetTextColor(hdc,
                           0x00FFFFFF if self._question_text else 0x009094A0)
        q_label = self._question_text or "画像について質問（音声または文字）"
        rect_q = clipgfx.RECT(int(thumb_x + thumb_sz + s(8.0)),
                              int(bar_y + s(12.0)), int(mic_x - s(6.0)),
                              int(bar_y + s(36.0)))
        user32.DrawTextW(hdc, q_label, _u16len(q_label), ctypes.byref(rect_q),
                         0x0024)

        # チップテキスト
        font_chip = self._font(10)
        gdi32.SelectObject(hdc, font_chip)
        gdi32.SetTextColor(hdc, 0x00E0E2E8)
        for i, (cid, label) in enumerate(chips):
            cx = bar_x + float(i) * (chip_w + s(4.0))
            rect_c = clipgfx.RECT(int(cx), int(chip_y),
                                  int(cx + chip_w), int(chip_y + chip_h))
            user32.DrawTextW(hdc, label, _u16len(label), ctypes.byref(rect_c),
                             0x0025 | 0x0001)

        # 回答・概要表示エリア
        ans_y = int(chip_y + chip_h + s(12.0))
        ans_w = int(panel_w - s(32.0))
        ans_h = int(py + panel_h - float(ans_y) - s(12.0))

        if ans_h > s(40.0):
            font_hdr = self._font(12, weight=700)
            gdi32.SelectObject(hdc, font_hdr)
            gdi32.SetTextColor(hdc, 0x00FD8B38)  # Cyan
            hdr_text = "✨ AI による概要"
            rect_h = clipgfx.RECT(int(bar_x), ans_y,
                                  int(bar_x + s(160.0)),
                                  ans_y + int(s(20.0)))
            user32.DrawTextW(hdc, hdr_text, _u16len(hdr_text),
                             ctypes.byref(rect_h), 0x0020)

            # ボタン類（コピー、Googleで開く、設定）
            btn_area_x = bar_x + bar_w
            if self._ai_answer:
                # 📋 コピーボタン
                copy_w = s(56.0)
                copy_x = btn_area_x - copy_w
                self._hit_rects["btn_copy"] = (
                    copy_x, float(ans_y) - s(2.0), copy_w, s(22.0))
                font_cp = self._font(10)
                gdi32.SelectObject(hdc, font_cp)
                gdi32.SetTextColor(hdc, 0x00C0C4D0)
                rect_cp = clipgfx.RECT(int(copy_x),
                                       ans_y - int(s(2.0)),
                                       int(copy_x + copy_w),
                                       ans_y + int(s(20.0)))
                user32.DrawTextW(hdc, "📋 コピー", _u16len("📋 コピー"), ctypes.byref(rect_cp),
                                 0x0025)

                # 🔍 Googleで開くボタン
                g_open_w = s(64.0)
                g_open_x = copy_x - g_open_w - s(4.0)
                self._hit_rects["btn_open_google"] = (
                    g_open_x, float(ans_y) - s(2.0), g_open_w, s(22.0)
                )
                rect_go = clipgfx.RECT(int(g_open_x),
                                       ans_y - int(s(2.0)),
                                       int(g_open_x + g_open_w),
                                       ans_y + int(s(20.0)))
                user32.DrawTextW(hdc, "🔍 検索", _u16len("🔍 検索"), ctypes.byref(rect_go),
                                 0x0025)

            # 本文表示
            font_body = self._font(11)
            gdi32.SelectObject(hdc, font_body)
            gdi32.SetTextColor(hdc, 0x00E0E2E8)
            rect_body = clipgfx.RECT(int(bar_x), ans_y + int(s(24.0)),
                                     int(bar_x + ans_w), ans_y + ans_h)
            ans_disp = self._ai_answer or "✨ AIが画像を解析中です..."
            user32.DrawTextW(hdc, ans_disp, _u16len(ans_disp),
                             ctypes.byref(rect_body),
                             0x0010 | 0x0004)  # DT_WORDBREAK | DT_TOP

            # APIキー未設定案内と設定ボタン
            api_key = self.cfg.str_("ai_api_key", "") if self.cfg else ""
            if not api_key:
                set_w = s(120.0)
                set_h = s(24.0)
                set_x = bar_x
                set_y = float(ans_y + ans_h) - s(26.0)
                self._hit_rects["btn_settings"] = (set_x, set_y, set_w, set_h)
                font_set = self._font(10, weight=700)
                gdi32.SelectObject(hdc, font_set)
                gdi32.SetTextColor(hdc, 0x0088CCFF)
                rect_set = clipgfx.RECT(int(set_x), int(set_y),
                                        int(set_x + set_w), int(set_y + set_h))
                user32.DrawTextW(hdc, "⚙️ APIキーを設定", 11,
                                 ctypes.byref(rect_set), 0x0020)

        gdi32.SelectObject(hdc, old_font)

    def _draw_lens_glyph(self, graphics: ctypes.c_void_p,
                         x: float, y: float, size: float) -> None:
        """画像検索（写真フレーム）アイコンを描画。"""
        # 内部の余白・線幅は基準寸法 20px からの比率で合わせる
        # （呼び出し側で拡大した size にそのまま追随させるため）
        u = size / 20.0
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0xFFFFFFFF),
                               c_float(1.5 * u), 0, ctypes.byref(pen))
        # 外枠
        rect_path = self._round_rect_path(x, y, size, size * 0.85, 3.0 * u)
        gdiplus.GdipDrawPath(graphics, pen, rect_path)
        gdiplus.GdipDeletePath(rect_path)
        # 山形
        gdiplus.GdipDrawLine(graphics, pen, c_float(x + 3.0 * u),
                             c_float(y + size * 0.65), c_float(x + size * 0.4),
                             c_float(y + size * 0.35))
        gdiplus.GdipDrawLine(graphics, pen, c_float(x + size * 0.4),
                             c_float(y + size * 0.35), c_float(x + size * 0.7),
                             c_float(y + size * 0.55))
        gdiplus.GdipDrawLine(graphics, pen, c_float(x + size * 0.7),
                             c_float(y + size * 0.55),
                             c_float(x + size - 3.0 * u),
                             c_float(y + size * 0.4))
        gdiplus.GdipDeletePen(pen)

    def _draw_copy_glyph(self, graphics: ctypes.c_void_p,
                         x: float, y: float, size: float) -> None:
        """テキストコピーアイコンを描画。"""
        u = size / 20.0  # 基準寸法 20px からの比率（_draw_lens_glyph 参照）
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0xFFFFFFFF),
                               c_float(1.4 * u), 0, ctypes.byref(pen))
        # 背面シート
        p1 = self._round_rect_path(x + 4.0 * u, y, size * 0.7,
                                   size * 0.75, 2.0 * u)
        gdiplus.GdipDrawPath(graphics, pen, p1)
        gdiplus.GdipDeletePath(p1)
        # 前面シート
        p2 = self._round_rect_path(x, y + 4.0 * u, size * 0.7,
                                   size * 0.75, 2.0 * u)
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xFF242630),
                                    ctypes.byref(brush))
        gdiplus.GdipFillPath(graphics, brush, p2)
        gdiplus.GdipDeleteBrush(brush)
        gdiplus.GdipDrawPath(graphics, pen, p2)
        gdiplus.GdipDeletePath(p2)
        gdiplus.GdipDeletePen(pen)

    def _draw_translate_glyph(self, graphics: ctypes.c_void_p, hdc: int,
                              x: float, y: float, size: float) -> None:
        """翻訳（文A）アイコンを描画。"""
        font = self._font(10, weight=700)
        if font:
            old_font = gdi32.SelectObject(hdc, font)
            gdi32.SetBkMode(hdc, 1)
            gdi32.SetTextColor(hdc, 0x00FFFFFF)
            rect = clipgfx.RECT(int(x), int(y), int(x + size), int(y + size))
            user32.DrawTextW(hdc, "文A", 2, ctypes.byref(rect),
                             0x0025 | 0x0001)
            gdi32.SelectObject(hdc, old_font)

    def _draw_submit_arrow_glyph(self, graphics: ctypes.c_void_p,
                                 x: float, y: float, size: float) -> None:
        """上向き矢印（↑ 送信）ボタンを描画。"""
        # 内部のずらし量・線幅は基準寸法 32px からの比率で合わせる
        u = size / 32.0
        # 丸背景
        brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(0xFF1A73E8),
                                    ctypes.byref(brush))
        gdiplus.GdipFillEllipse(graphics, brush, c_float(x), c_float(y),
                                c_float(size), c_float(size))
        gdiplus.GdipDeleteBrush(brush)

        # 白い上向き矢印
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0xFFFFFFFF),
                               c_float(1.8 * u), 0, ctypes.byref(pen))
        cx = x + size / 2.0
        cy = y + size / 2.0
        # 縦軸
        gdiplus.GdipDrawLine(graphics, pen, c_float(cx),
                             c_float(cy + 6.0 * u),
                             c_float(cx), c_float(cy - 6.0 * u))
        # 矢じり
        gdiplus.GdipDrawLine(graphics, pen, c_float(cx - 4.5 * u),
                             c_float(cy - 1.5 * u),
                             c_float(cx), c_float(cy - 6.0 * u))
        gdiplus.GdipDrawLine(graphics, pen, c_float(cx + 4.5 * u),
                             c_float(cy - 1.5 * u),
                             c_float(cx), c_float(cy - 6.0 * u))
        gdiplus.GdipDeletePen(pen)

    def _draw_pulse_mic_button(self, graphics: ctypes.c_void_p,
                               x: float, y: float, size: float) -> None:
        """SpeakPulse 専用録音中ボタン（パルスリング＋イコライザー波形）。"""
        cx = x + size / 2.0
        cy = y + size / 2.0

        if self._ai_status == "listening":
            # 録音中：赤＋シアンの脈動パルスリング
            pulse = math.sin(self._anim_tick * 0.25) * self._s(3.5)
            ring_r = size / 2.0 + self._s(3.0) + pulse
            pen_pulse = ctypes.c_void_p()
            gdiplus.GdipCreatePen1(ctypes.c_uint32(0x55E0483A),
                                   c_float(self._s(2.0)), 0,
                                   ctypes.byref(pen_pulse))
            gdiplus.GdipDrawEllipse(graphics, pen_pulse,
                                    c_float(cx - ring_r), c_float(cy - ring_r),
                                    c_float(ring_r * 2.0), c_float(ring_r * 2.0))
            gdiplus.GdipDeletePen(pen_pulse)
            bg_color = 0xFFE0483A  # SpeakPulse Crimson Red
        elif self._ai_status == "recognizing":
            bg_color = 0xFF1A73E8  # Google Blue
        else:
            bg_color = 0xFF353946  # Slate

        b_brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(bg_color),
                                    ctypes.byref(b_brush))
        gdiplus.GdipFillEllipse(graphics, b_brush, c_float(x), c_float(y),
                                c_float(size), c_float(size))
        gdiplus.GdipDeleteBrush(b_brush)

        # マイクピクトグラム
        gsz = self._s(14.0)
        self._draw_mic_glyph(graphics, x + (size - gsz) / 2.0,
                             y + (size - gsz) / 2.0, gsz, 0xFFFFFFFF)

        # イコライザーバー（録音中）
        if self._ai_status == "listening" and self._mic_level > 0.05:
            pen_eq = ctypes.c_void_p()
            gdiplus.GdipCreatePen1(ctypes.c_uint32(0xEEFFFFFF),
                                   c_float(self._s(1.5)), 0,
                                   ctypes.byref(pen_eq))
            for i in range(3):
                h_bar = self._s(2.0) + self._mic_level * self._s(8.0) * (
                    0.8 + 0.4 * math.sin(self._anim_tick * 0.4 + i)
                )
                bx = x - self._s(10.0) - float(i) * self._s(3.5)
                gdiplus.GdipDrawLine(graphics, pen_eq, c_float(bx),
                                     c_float(cy - h_bar / 2),
                                     c_float(bx), c_float(cy + h_bar / 2))
            gdiplus.GdipDeletePen(pen_eq)

    def _draw_google_g_icon(self, graphics: ctypes.c_void_p,
                            x: float, y: float, size: float) -> None:
        """Google の "G" アイコンを描画する。"""
        pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(0xFF4285F4),
                               c_float(self._s(2.4)), 0, ctypes.byref(pen))
        gdiplus.GdipDrawArc(graphics, pen, c_float(x), c_float(y),
                            c_float(size), c_float(size),
                            c_float(45), c_float(270))
        gdiplus.GdipDrawLine(graphics, pen, c_float(x + size / 2),
                             c_float(y + size / 2),
                             c_float(x + size), c_float(y + size / 2))
        gdiplus.GdipDeletePen(pen)

    def _draw_mic_glyph(self, graphics: ctypes.c_void_p,
                        x: float, y: float, size: float, argb: int) -> None:
        """マイクピクトグラムを描画する。"""
        s = size / 16.0
        cx = x + size / 2.0
        p_brush = ctypes.c_void_p()
        gdiplus.GdipCreateSolidFill(ctypes.c_uint32(argb),
                                    ctypes.byref(p_brush))

        # カプセル
        cw, ch = 5.0 * s, 8.0 * s
        p_cap = self._round_rect_path(cx - cw / 2.0, y, cw, ch, cw / 2.0)
        gdiplus.GdipFillPath(graphics, p_brush, p_cap)
        gdiplus.GdipDeletePath(p_cap)

        # U字アーム
        p_pen = ctypes.c_void_p()
        gdiplus.GdipCreatePen1(ctypes.c_uint32(argb), c_float(1.6 * s), 0,
                               ctypes.byref(p_pen))
        aw = 9.0 * s
        gdiplus.GdipDrawArc(graphics, p_pen, c_float(cx - aw / 2.0),
                            c_float(y + 2.0 * s), c_float(aw), c_float(8.0 * s),
                            c_float(0), c_float(180))
        # 支柱 & 台座
        gdiplus.GdipDrawLine(graphics, p_pen, c_float(cx),
                             c_float(y + 10.0 * s),
                             c_float(cx), c_float(y + 13.0 * s))
        gdiplus.GdipDrawLine(graphics, p_pen, c_float(cx - 3.5 * s),
                             c_float(y + 13.0 * s),
                             c_float(cx + 3.5 * s), c_float(y + 13.0 * s))

        gdiplus.GdipDeletePen(p_pen)
        gdiplus.GdipDeleteBrush(p_brush)

    def _round_rect_path(self, x: float, y: float, w: float, h: float,
                         r: float) -> ctypes.c_void_p:
        path = ctypes.c_void_p()
        gdiplus.GdipCreatePath(0, ctypes.byref(path))
        d = r * 2.0
        gdiplus.GdipAddPathArc(path, c_float(x), c_float(y), c_float(d), c_float(d), c_float(180), c_float(90))
        gdiplus.GdipAddPathArc(path, c_float(x + w - d), c_float(y), c_float(d), c_float(d), c_float(270), c_float(90))
        gdiplus.GdipAddPathArc(path, c_float(x + w - d), c_float(y + h - d), c_float(d), c_float(d), c_float(0), c_float(90))
        gdiplus.GdipAddPathArc(path, c_float(x), c_float(y + h - d), c_float(d), c_float(d), c_float(90), c_float(90))
        gdiplus.GdipClosePathFigure(path)
        return path

    def select(self) -> tuple[int, int, int, int] | None:
        """選択オーバーレイを表示し、完了までループを実行する。"""
        if dryrun.enabled():
            return (100, 100, 400, 300)

        global _active_snipper
        _active_snipper = self
        clipgfx.start()
        try:
            self._capture_screen_to_bitmap()
            if not self._ensure_class():
                return None

            self._hwnd = user32.CreateWindowExW(
                WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
                _CLASS_NAME, "koe-type snipping",
                WS_POPUP | WS_VISIBLE,
                self._screen_x, self._screen_y,
                self._screen_w, self._screen_h,
                0, 0, 0, None
            )
            if not self._hwnd:
                log.warning("スニッピングウィンドウの作成に失敗しました: %s",
                            ctypes.get_last_error())
                return None

            # ★パネル等の寸法に掛ける拡大率を、窓ができたここで決める
            # （最初の描画より前に決まっていないと意味がない）
            self._ui_scale = self._resolve_ui_scale()

            # アニメーション用タイマー開始（100ms 間隔に適正化。
            # 以前は 30ms ごとに全画面を再描画していて重かった）
            user32.SetTimer(self._hwnd, ANIM_TIMER_ID, 100, None)

            # ★マイクは自動で始めない（2026-10-24 改修）。開いただけで
            # 録音が始まると「勝手に文字起こしが始まった」ように見え、
            # 音声の自動送信（無音 1.8 秒で AI へ送信）まで連鎖していた。
            # 音声指示は、利用者がマイクボタンを押したときだけ始める。
            self._ai_status = "idle"

            user32.SetForegroundWindow(self._hwnd)
            user32.ShowWindow(self._hwnd, SW_SHOW)
            user32.UpdateWindow(self._hwnd)

            msg = wintypes.MSG()
            while user32.GetMessageW(ctypes.byref(msg), 0, 0, 0) > 0:
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
        finally:
            if self._recorder is not None:
                try:
                    self._recorder.stop()
                except Exception:
                    pass
                self._recorder = None

            if self._screen_dc:
                gdi32.DeleteDC(self._screen_dc)
                self._screen_dc = 0
            if self._screen_hbm:
                gdi32.DeleteObject(self._screen_hbm)
                self._screen_hbm = 0
            _active_snipper = None

        return self.result


def select_region() -> tuple[int, int, int, int] | None:
    """Galaxy S25風の選択オーバーレイを表示し、選択矩形を返す（互換用）。"""
    snipper = ScreenSnipper(interactive=False)
    return snipper.select()


def open_screen_assistant(cfg=None, engine=None, on_notify=None) -> None:
    """Galaxy S25風のかこって検索・画面AI対話オーバーレイを開く。

    ★開くのは「利用者が明示的にホットキー／ボタンを押したとき」だけ。
    すでに開いている場合と、前回から 2 秒以内の再起動は誤爆として捨てる。
    """
    global _last_open_at
    now = time.monotonic()
    with _open_lock:
        if _active_snipper is not None:
            log.info("画面AIアシスタントはすでに開いているので何もしません")
            return
        if now - _last_open_at < MIN_REOPEN_GAP_SEC:
            log.info("画面AIアシスタントの再起動が速すぎるので捨てます")
            return
        _last_open_at = now
    snipper = ScreenSnipper(cfg=cfg, engine=engine, on_notify=on_notify,
                            interactive=True)
    snipper.select()
