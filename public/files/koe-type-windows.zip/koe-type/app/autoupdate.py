"""バックグラウンドで最新モデルカタログと本体更新を確認する。

通信は設定で許可されている場合のみ行い、オフライン時は何もしない。
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Callable

from . import catalog, downloads, updates
from .configstore import Config

log = logging.getLogger(__name__)

CHECK_INTERVAL_SEC = 86400  # 24時間


class AutoUpdater:
    """最新モデルカタログの取得と本体の自動更新を確認する見張り役。"""

    def __init__(self, cfg: Config,
                 notify_fn: Callable[[str], None] | None = None,
                 is_idle_fn: Callable[[], bool] | None = None) -> None:
        self.cfg = cfg
        self.notify_fn = notify_fn
        self.is_idle_fn = is_idle_fn or (lambda: True)
        self._thread: threading.Thread | None = None
        self._stopping = threading.Event()
        self.last_checked = 0.0

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._stopping.clear()
        self._thread = threading.Thread(target=self._loop,
                                        name="auto-updater",
                                        daemon=True)
        self._thread.start()
        log.info("自動更新・モデル確認の監視を開始しました")

    def stop(self) -> None:
        self._stopping.set()

    def _loop(self) -> None:
        # 起動直後の負荷を避けるため、10秒待ってから初回確認
        if self._stopping.wait(10):
            return

        while not self._stopping.is_set():
            try:
                self.check_now()
            except Exception:
                log.debug("自動更新チェック中にエラー", exc_info=True)

            # 次回確認まで待機
            if self._stopping.wait(CHECK_INTERVAL_SEC):
                break

    def check_now(self) -> None:
        """今すぐ最新カタログと本体更新を確認する。"""
        if downloads.is_offline():
            return

        # 利用者がアプリを使っている間は、通信も含めて後回しにする
        # （PRODUCT_SPEC H7: 重い作業は使っている間は止める）。
        # 昔は is_idle_fn を受け取るだけで一度も見ていなかった。
        try:
            if not self.is_idle_fn():
                log.debug("使用中なので更新確認を次回に回します")
                return
        except Exception:
            log.debug("使用中かの確認で例外", exc_info=True)

        mode = self.cfg.str_("auto_update_mode", "notify")
        if mode == "off":
            return

        repo = self.cfg.str_("update_repo", updates.DEFAULT_REPO)

        # 1. リモートモデルカタログの更新
        # 設定 auto_update_catalog がオフのときは取得しない。
        # 昔は設定項目だけあって、ここでは見ていなかった。
        try:
            added = (catalog.update_remote_catalog(repo)
                     if self.cfg.bool_("auto_update_catalog", True)
                     else 0)
            if added > 0 and self.notify_fn:
                self.notify_fn(f"新しいモデルが {added} 件追加されました")
        except Exception:
            log.debug("モデルカタログの取得をスキップしました")

        # 2. アプリ本体の更新確認
        try:
            info = updates.check(repo)
            if info.get("ok") and info.get("newer"):
                latest = info.get("latest", "")
                if mode == "auto":
                    # ★自動では適用しない（2026-10-24 改修）。
                    # perform_update は「呼んだらすぐアプリを終わらせる」
                    # 前提の作り（updates.py の apply の注意書き）だが、
                    # ここでは本体を終わらせる手段がなく、動いている
                    # アプリの下でファイルが入れ替わり、--restarted の
                    # 新しい実体が多重起動よけに弾かれて消えるだけだった。
                    # 入れ替え中のファイル変更は再起動の引き金にもなる。
                    # いまは知らせるだけにし、適用は設定画面の手動更新
                    # （本体を終わらせてから入れ替える経路）に任せる。
                    log.info("最新版 %s があります（自動適用はしません）",
                             latest)
                    if self.notify_fn:
                        self.notify_fn(
                            f"新しい版（{latest}）が利用可能です。"
                            "設定画面から更新してください")
                elif mode == "notify":
                    log.info("新しい版 %s が利用可能です", latest)
                    if self.notify_fn:
                        self.notify_fn(f"新しい版（{latest}）が利用可能です")
        except Exception:
            log.debug("本体更新の確認をスキップしました")

        self.last_checked = time.monotonic()
