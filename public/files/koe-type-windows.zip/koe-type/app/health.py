"""軽さの見張りと記録。**記録のせいで重くならないこと**を最優先にする。

PC 全体を重くしたことがあるので、ここは「測るために重くなる」ことが
あってはいけない。そのための決まり。

  ・測るのは **1 秒に 1 回だけ**。それも OS に数字を聞くだけ。
  ・書き出すのは **変化があったときか、印をつけられたとき**だけ。
  ・持っておくのは**直近 5 分ぶん**（それより古いものは捨てる）。
  ・ファイルは 2MB を超えたら古いほうから捨てる。

見ているもの
  ・このアプリの CPU・メモリ
  ・PC 全体の CPU
  ・文字起こし 1 回の時間
  ・やり残しの件数（処理待ち）
  ・ショートカットの登録が生きているか
  ・心拍（見張り役のプロセスが生死を知るため）
"""

from __future__ import annotations

import ctypes
import json
import logging
import threading
import time
from collections import deque
from ctypes import wintypes
from pathlib import Path

log = logging.getLogger(__name__)

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

HISTORY_SECONDS = 300          # 持っておく長さ
MAX_LOG_BYTES = 2 * 1024 * 1024


class FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", wintypes.DWORD),
                ("dwHighDateTime", wintypes.DWORD)]


class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


# ctypes は argtypes を書かないと 64bit のハンドルを切り詰めてしまう
kernel32.GetCurrentProcess.restype = wintypes.HANDLE
kernel32.GetProcessTimes.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME)]
kernel32.GetProcessTimes.restype = wintypes.BOOL
kernel32.GetSystemTimes.argtypes = [ctypes.POINTER(FILETIME),
                                    ctypes.POINTER(FILETIME),
                                    ctypes.POINTER(FILETIME)]
kernel32.GetSystemTimes.restype = wintypes.BOOL
psapi.GetProcessMemoryInfo.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(PROCESS_MEMORY_COUNTERS), wintypes.DWORD]
psapi.GetProcessMemoryInfo.restype = wintypes.BOOL


def _ft(ft: FILETIME) -> float:
    return ((ft.dwHighDateTime << 32) | ft.dwLowDateTime) / 1e7


class Health:
    """1 秒ごとに軽く測り、重くなったら知らせる。"""

    def __init__(self, path: Path, *, heartbeat: Path | None = None) -> None:
        self.path = path
        self.heartbeat = heartbeat
        self.samples: deque[dict] = deque(maxlen=HISTORY_SECONDS)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

        self._cpu_mark = (0.0, 0.0)        # (このアプリの CPU 秒, 実時間)
        self._sys_mark = (0.0, 0.0)        # (PC 全体の仕事, 全体の時間)

        # 本体が入れてくれる数字
        self.last_transcribe = 0.0
        self.pending = 0
        self.recording = False
        # 「止める途中」。ここで居残ると帯が消えず、Ctrl+Space も
        # 効かなくなる。見張り役プロセスにも伝える。
        self.stopping_since = 0.0
        # 画面の繰り返しが回った回数。止まっていないことの証拠にする。
        self.ticks = 0
        self.hotkeys_ok = True
        self.degraded = ""                 # 軽い動きに切り替えた理由

        self.slow_events = 0               # 重いと判断した回数

    # ------------------------------------------------------------ 測る

    def _process_cpu(self) -> float:
        creation, exit_, kernel, user = (FILETIME(), FILETIME(),
                                         FILETIME(), FILETIME())
        if not kernel32.GetProcessTimes(
                kernel32.GetCurrentProcess(), ctypes.byref(creation),
                ctypes.byref(exit_), ctypes.byref(kernel),
                ctypes.byref(user)):
            return 0.0
        return _ft(kernel) + _ft(user)

    def _system_busy(self) -> tuple[float, float]:
        idle, kernel, user = FILETIME(), FILETIME(), FILETIME()
        if not kernel32.GetSystemTimes(ctypes.byref(idle),
                                       ctypes.byref(kernel),
                                       ctypes.byref(user)):
            return (0.0, 0.0)
        total = _ft(kernel) + _ft(user)
        return (total - _ft(idle), total)

    def _memory_mb(self) -> float:
        counters = PROCESS_MEMORY_COUNTERS()
        counters.cb = ctypes.sizeof(counters)
        if not psapi.GetProcessMemoryInfo(kernel32.GetCurrentProcess(),
                                          ctypes.byref(counters),
                                          counters.cb):
            return 0.0
        return counters.WorkingSetSize / (1024 * 1024)

    def sample(self) -> dict:
        now = time.monotonic()
        cpu = self._process_cpu()
        busy, total = self._system_busy()

        prev_cpu, prev_at = self._cpu_mark
        span = max(1e-6, now - prev_at) if prev_at else 0.0
        mine = ((cpu - prev_cpu) / span * 100) if span else 0.0
        self._cpu_mark = (cpu, now)

        prev_busy, prev_total = self._sys_mark
        gap = total - prev_total
        whole = ((busy - prev_busy) / gap * 100) if gap > 0 else 0.0
        self._sys_mark = (busy, total)

        row = {
            "t": round(time.time(), 1),
            "cpu": round(max(0.0, min(100.0, mine)), 1),
            "sys": round(max(0.0, min(100.0, whole)), 1),
            "mem": round(self._memory_mb(), 1),
            "rec": 1 if self.recording else 0,
            "wait": self.pending,
            "asr": round(self.last_transcribe, 3),
        }
        if not self.hotkeys_ok:
            row["keys"] = "lost"
        if self.degraded:
            row["slow"] = self.degraded
        with self._lock:
            self.samples.append(row)
        return row

    # ------------------------------------------------------------ 回す

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(target=self._loop, name="health",
                                        daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def _loop(self) -> None:
        while not self._stop.wait(1.0):
            try:
                row = self.sample()
                self._beat()
                self._judge(row)
            except Exception:
                log.exception("軽さの見張りで例外")

    def _beat(self) -> None:
        """生きている印を残す（見張り役のプロセスが見る）。"""
        if self.heartbeat is None:
            return
        try:
            # 時刻だけでなく「いまの状態」も書く。見張り役が、
            # 固まりだけでなく**中途半端なまま居残っている**ことにも
            # 気づけるようにするため。古い版は 1 行目だけ読む。
            stuck = 0.0
            if self.stopping_since:
                stuck = max(0.0, time.monotonic() - self.stopping_since)
            self.heartbeat.write_text(
                f"{int(time.time())}\n"
                f"state={'recording' if self.recording else 'idle'}\n"
                f"stopping={stuck:.1f}\n"
                f"ticks={self.ticks}\n", "utf-8")
        except OSError:
            pass

    def _judge(self, row: dict) -> None:
        """重いかどうかを見分ける。"""
        heavy = (row["cpu"] > 60 and row["rec"] == 0) or row["wait"] > 6
        if heavy:
            self.slow_events += 1
            if self.slow_events in (1, 5, 20):
                log.warning("重い状態です: CPU %.0f%% / PC全体 %.0f%% / "
                            "待ち %d 件 / 1回 %.2fs",
                            row["cpu"], row["sys"], row["wait"], row["asr"])
                self.mark("自動で見つけた重い状態")
        else:
            self.slow_events = max(0, self.slow_events - 1)

    # ------------------------------------------------------------ 書き出す

    def mark(self, why: str) -> None:
        """いまの前後の記録を書き出して、印をつける。

        トレイの「いま重かった」からも呼ぶ。
        """
        with self._lock:
            rows = list(self.samples)[-60:]
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            if self.path.exists() and self.path.stat().st_size > MAX_LOG_BYTES:
                # 大きくなりすぎたら、後ろ半分だけ残す
                data = self.path.read_bytes()[-MAX_LOG_BYTES // 2:]
                self.path.write_bytes(data[data.find(b"\n") + 1:])
            with self.path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps({"mark": why,
                                     "at": round(time.time(), 1)},
                                    ensure_ascii=False) + "\n")
                for row in rows:
                    fh.write(json.dumps(row, ensure_ascii=False) + "\n")
            log.info("そのときの記録を残しました（%s / %d 秒ぶん）",
                     why, len(rows))
        except OSError:
            log.exception("記録を書けませんでした")

    def summary(self) -> dict:
        """いまの様子を短くまとめる（診断情報のコピー用）。"""
        with self._lock:
            rows = list(self.samples)
        if not rows:
            return {}
        recent = rows[-60:]
        asr = [r["asr"] for r in recent if r["asr"]]
        return {
            "samples": len(rows),
            "cpu_now": recent[-1]["cpu"],
            "cpu_max": max(r["cpu"] for r in recent),
            "sys_max": max(r["sys"] for r in recent),
            "mem_mb": recent[-1]["mem"],
            "mem_max": max(r["mem"] for r in recent),
            "wait_max": max(r["wait"] for r in recent),
            "asr_avg": round(sum(asr) / len(asr), 3) if asr else 0,
            "asr_max": round(max(asr), 3) if asr else 0,
            "slow_events": self.slow_events,
            "hotkeys_ok": self.hotkeys_ok,
            "degraded": self.degraded,
        }
