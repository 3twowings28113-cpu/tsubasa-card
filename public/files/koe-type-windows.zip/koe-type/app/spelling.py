"""アルファベット読み（「エフディーイー」など）の英語変換。

音声認識エンジン（SenseVoice や Whisper など）は、アルファベットの頭字語や
スペルアウト（一文字ずつの発音）を「エフディーイー」「エーピーアイ」のような
カタカナ・ひらがなで出力してしまうことが多い。

ここでは、2文字以上の連続したアルファベット読み（または数字が混ざるもの）を
検出し、大文字アルファベット（例: 「FDE」「API」「URL」）に自動変換する。

決め事：
  ・基本は、2文字以上のアルファベット読みトークンが連続している
    （または数字が隣接する）場合に変換する。
  ・単独1文字の読み（「エム」など）は、区間全体がその読みだけ・
    助詞に挟まれた位置・サイズ/型/級/判 の直前、のいずれかの境界
    条件を満たすときだけ変換する（_SINGLE_POLICY の文字別ポリシー
    付き。「えー」フィラーや「あい」愛、「ワイ」関西弁の一人称を
    誤変換しないため。詳細は _convert_single_letters 側のコメント）。
  ・「エスカレーター」「ビール」など、一般名詞の一部を誤爆しないよう、
    代表的な頭字語テーブルと音節パーサーを組み合わせて安全に行う。
"""

from __future__ import annotations

import re
from typing import Callable, Final

# ------------------------------------------------ アルファベット単音の定義

# 各アルファベットに対応する代表的なカタカナ・ひらがな読み（長音の有無含む）。
# 長いパターンを先に試すため、文字数の多い順に並べる。
_LETTER_READINGS: Final[list[tuple[str, str]]] = [
    # W (ダブリュー、だぶりゅー、ダブル、だぶる)
    ("W", "ダブリュー"), ("W", "だぶりゅー"),
    ("W", "ダブリュ"), ("W", "だぶりゅ"),
    ("W", "ダブル"), ("W", "だぶる"),
    # M (エム、えむ)
    ("M", "エム"), ("M", "えむ"),
    # N (エヌ、えぬ)
    ("N", "エヌ"), ("N", "えぬ"),
    # L (エル、える)
    ("L", "エル"), ("L", "える"),
    # F (エフ、えふ)
    ("F", "エフ"), ("F", "えふ"),
    # S (エス、えす)
    ("S", "エス"), ("S", "えす"),
    # X (エックス、えっくす)
    ("X", "エックス"), ("X", "えっくす"),
    # H (エイチ、えいち)
    ("H", "エイチ"), ("H", "えいち"),
    # J (ジェー、じぇー、ジェイ、じぇい)
    ("J", "ジェー"), ("J", "じぇー"),
    ("J", "ジェイ"), ("J", "じぇい"),
    # K (ケー、けー、ケイ、けい)
    ("K", "ケー"), ("K", "けー"),
    ("K", "ケイ"), ("K", "けい"),
    # Q (キュー、きゅー)
    ("Q", "キュー"), ("Q", "きゅー"),
    # R (アール、あーる)
    ("R", "アール"), ("R", "あーる"),
    # Y (ワイ、わい)
    ("Y", "ワイ"), ("Y", "わい"),
    # Z (ゼット、ぜっと、ズィー、ずぃー)
    ("Z", "ゼット"), ("Z", "ぜっと"),
    ("Z", "ズィー"), ("Z", "ずぃー"),
    # B (ビー、びー)
    ("B", "ビー"), ("B", "びー"),
    # C (シー、しー)
    ("C", "シー"), ("C", "しー"),
    # D (ディー、でぃー、デー、でー)
    ("D", "ディー"), ("D", "でぃー"),
    ("D", "デー"), ("D", "でー"),
    # T (ティー、てぃー、テー、てー)
    ("T", "ティー"), ("T", "てぃー"),
    ("T", "テー"), ("T", "てー"),
    # P (ピー、ぴー)
    ("P", "ピー"), ("P", "ぴー"),
    # V (ブイ、ぶい、ヴィー、ヴイ)
    ("V", "ヴィー"), ("V", "ヴイ"),
    ("V", "ブイ"), ("V", "ぶい"),
    # G (ジー、じー)
    ("G", "ジー"), ("G", "じー"),
    # U (ユー、ゆー)
    ("U", "ユー"), ("U", "ゆー"),
    # I (アイ、あい)
    ("I", "アイ"), ("I", "あい"),
    # E (イー、いー)
    ("E", "イー"), ("E", "いー"),
    # O (オー、おー)
    ("O", "オー"), ("O", "おー"),
    # A (エー、えー、エイ、えい)
    ("A", "エー"), ("A", "えー"),
    ("A", "エイ"), ("A", "えい"),
]

# --------------------------------------------- 代表的頭字語の優先テーブル
# 日常会話や IT・ビジネスで頻出する頭字語。
# これらは中黒や空白、読点が挟まっても確実にマッチさせ、最優先で変換する。
_ACRONYMS: Final[dict[str, tuple[str, ...]]] = {
    "USJ": ("ユーエスジェイ", "ユー・エス・ジェイ", "ゆーえすじぇー",
            "ユーエスジェー", "ユー・エス・ジェー"),
    "TDL": ("ティーディーエル", "ティー・ディー・エル"),
    "HDMI": ("エイチディーエムアイ", "エイチ・ディー・エム・アイ",
             "えいちでぃーえむあい", "エイチ ディー エム アイ"),
    "Wi-Fi": ("ワイファイ", "わいふぁい", "ワイ・ファイ"),
    "SaaS": ("サース", "サーズ"),
    "PaaS": ("パース",),
    "IaaS": ("イアース", "アイアース"),
    "ATM": ("エーティーエム", "エー・ティー・エム", "えーてぃーえむ"),
    "ETC": ("イーティーシー", "イー・ティー・シー", "いーてぃーしー"),
    "GPS": ("ジーピーエス", "ジー・ピー・エス", "じーぴーえす"),
    "QR": ("キューアール", "キュー・アール", "きゅーあーる"),
    "JR": ("ジェイアール", "ジェーアール", "ジェイ・アール", "ジェー・アール"),
    "NHK": ("エヌエイチケー", "エヌ・エイチ・ケー", "えぬえいちけー"),
    "FAQ": ("エフエーキュー", "エフ・エー・キュー", "えふえーきゅー"),
    "Q&A": ("キューアンドエー", "キュー・アンド・エー", "きゅーあんどえー"),
    "KPI": ("ケーピーアイ", "ケイピーアイ", "ケー・ピー・アイ"),
    "KGI": ("ケージーアイ", "ケイジーアイ"),
    "OKR": ("オーケーアール", "オー・ケー・アール"),
    "BtoB": ("ビートゥービー", "ビー・トゥー・ビー"),
    "BtoC": ("ビートゥーシー", "ビー・トゥー・シー"),
    "CtoC": ("シートゥーシー", "シー・トゥー・シー"),
    "D2C": ("ディートゥーシー", "ディー・トゥー・シー"),
    "CSV": ("シーエスブイ", "シー・エス・ブイ", "しーえすぶい"),
    "XML": ("エックスエムエル", "エックス・エム・エル"),
    "YAML": ("ヤムル", "ワイエーエムエル"),
    "OK": ("オーケー", "オー・ケー", "おーけー"),
    "NG": ("エヌジー", "エヌ・ジー", "えぬじー"),
    "DM": ("ディーエム", "ディー・エム", "でぃーえむ"),
    "CM": ("シーエム", "シー・エム", "しーえむ"),
    "PV": ("ピーブイ", "ピー・ブイ", "ぴーぶい"),
    "MV": ("エムブイ", "エム・ブイ", "えむぶい"),
    "BGM": ("ビージーエム", "ビー・ジー・エム", "びーじーえむ"),
    "DJ": ("ディージェイ", "ディージェー", "でぃーじぇー"),
    "MC": ("エムシー", "エム・シー", "えむしー"),
    "VIP": ("ブイアイピー", "ブイ・アイ・ピー", "ぶいあいぴー"),
    "SOS": ("エスオーエス", "エス・オー・エス", "えすおーえす"),
    "UFO": ("ユーフォー", "ユーエフオー", "ユー・エフ・オー"),
    "DNA": ("ディーエヌエー", "ディー・エヌ・エー", "でぃーえぬえー"),
    "GDP": ("ジーディーピー", "ジー・ディー・ピー", "じーでぃーぴー"),
    "GNP": ("ジーエヌピー", "ジー・エヌ・ピー"),
    "IPO": ("アイピーオー", "アイ・ピー・オー"),
    "TOB": ("ティーオービー", "ティー・オー・ビー"),
    "CLI": ("シーエルアイ", "シー・エル・アイ"),
    "GUI": ("ジーユーアイ", "ジー・ユー・アイ"),
    "TS": ("ティーエス", "ティー・エス", "てぃーえす"),
    "DP": ("ディーピー", "ディー・ピー"),
    "DVI": ("ディーブイアイ", "ディー・ブイ・アイ"),
    "VGA": ("ブイジーエー", "ブイ・ジー・エー"),
    "LTE": ("エルティーイー", "エル・ティー・イー"),
    "5G": ("ファイブジー", "ファイブ・ジー"),
    "4G": ("フォージー", "フォー・ジー"),
    "OJT": ("オージェーティー", "オージェイティー"),
    "PoC": ("ポック", "ピーオーシー"),
    "MVP": ("エムブイピー", "エム・ブイ・ピー"),
    "CEO": ("シーイーオー", "シー・イー・オー"),
    "COO": ("シーオーオー", "シー・オー・オー"),
    "CTO": ("シーティーオー", "シー・ティー・オー"),
    "CFO": ("シーエフオー", "シー・エフ・オー"),
    "CMO": ("シーエムオー", "シー・エム・オー"),
    "CIO": ("シーアイオー", "シー・アイ・オー"),
    "NPO": ("エヌピーオー", "エヌ・ピー・オー"),
    "NGO": ("エヌジーオー", "エヌ・ジー・オー"),
    "WHO": ("ダブリューエイチオー", "ダブリュー・エイチ・オー"),
    "JAL": ("ジェイエーエル", "ジェーエーエル"),
    "ANA": ("エーエヌエー", "エイエヌエー"),
    "FDE": ("エフディーイー", "エフ・ディー・イー", "エフ、ディー、イー",
            "エフ ディー イー", "えふでぃーいー"),
    "API": ("エーピーアイ", "エー・ピー・アイ", "エイピーアイ", "えーぴーあい"),
    "URL": ("ユーアールエル", "ユー・アール・エル", "ゆーあーるえる"),
    "SDK": ("エスディーケー", "エス・ディー・ケー", "えすでぃーけー"),
    "CPU": ("シーピーユー", "シー・ピー・ユー", "しーぴーゆー"),
    "GPU": ("ジーピーユー", "ジー・ピー・ユー", "じーぴーゆー"),
    "DB": ("ディービー", "ディー・ビー", "でぃーびー"),
    "IDE": ("アイディーイー", "アイ・ディー・イー", "アイ、ディー、イー",
            "アイ ディー イー", "あいでぃーいー", "あい・でぃー・いー",
            "アイディーいー", "あいでぃーイー", "あいでぃいー", "アイディイー",
            "アイデーイー", "あいでーいー", "アイ・ディ・イー", "アイディ・イー"),
    "ID": ("アイディー", "アイ・ディー", "あい・でぃー", "あいディー"),
    "IP": ("アイピー", "アイ・ピー", "あいぴー"),
    "AI": ("エーアイ", "エー・アイ", "エイアイ", "えーあい"),
    "UI": ("ユーアイ", "ユー・アイ", "ゆーあい"),
    "UX": ("ユーエックス", "ユー・エックス", "ゆーえっくす"),
    "OS": ("オーエス", "オー・エス", "おーえす"),
    "PC": ("ピーシー", "ピー・シー", "ぴーしー"),
    "PR": ("ピーアール", "ピー・アール", "ぴーあーる"),
    "SNS": ("エスエヌエス", "エス・エヌ・エス", "えすえぬえす"),
    "DNS": ("ディーエヌエス", "ディー・エヌ・エス", "でぃーえぬえす"),
    "SSL": ("エスエスエル", "エス・エス・エル", "えすえすえる"),
    "SSH": ("エスエスエイチ", "エス・エス・エイチ", "えすえすえいち"),
    "HTTP": ("エイチティーティーピー", "エイチ・ティー・ティー・ピー"),
    "HTTPS": ("エイチティーティーピーエス",
              "エイチ・ティー・ティー・ピー・エス"),
    "HTML": ("エイチティーエムエル", "エイチ・ティー・エム・エル"),
    "CSS": ("シーエスエス", "シー・エス・エス", "しーえすえす"),
    "JS": ("ジェーエス", "ジェー・エス", "じぇーえす"),
    "JSON": ("ジェイソン", "ジェーソン"),  # 単語として読まれる場合もある
    "SQL": ("エスキューエル", "エス・キュー・エル", "えすきゅーえる"),
    "SSD": ("エスエスディー", "エス・エス・ディー", "えすえすでぃー"),
    "HDD": ("エイチディーディー", "エイチ・ディー・ディー"),
    "USB": ("ユーエスビー", "ユー・エス・ビー", "ゆーえすびー"),
    "LAN": ("エルエーエヌ", "エル・エー・エヌ"),
    "VPN": ("ブイピーエヌ", "ブイ・ピー・エヌ", "ぶいぴーえぬ"),
    "VM": ("ブイエム", "ブイ・エム", "ぶいえむ"),
    "VR": ("ブイアール", "ブイ・アール", "ぶいあーる"),
    "AR": ("エーアール", "エー・アール", "えーあーる"),
    "MR": ("エムアール", "エム・アール", "えむあーる"),
    "DX": ("ディーエックス", "ディー・エックス", "でぃーえっくす"),
    "IoT": ("アイオーティー", "アイ・オー・ティー", "あいおーてぃー"),
    "FPS": ("エフピーエス", "エフ・ピー・エス", "えふぴーえす"),
    "RPG": ("アールピージー", "アール・ピー・ジー", "あーるぴーじー"),
    "PDF": ("ピーディーエフ", "ピー・ディー・エフ", "ぴーでぃーえふ"),
    "LED": ("エルイーディー", "エル・イー・ディー", "えるいーでぃー"),
    "CD": ("シーディー", "シー・ディー", "しーでぃー"),
    "DVD": ("ディーブイディー", "ディー・ブイ・ディー", "でぃーぶいでぃー"),
    "SD": ("エスディー", "エス・ディー", "えすでぃー"),
    "FHD": ("エフエイチディー", "エフ・エイチ・ディー"),
    "AWS": ("エーダブリューエス", "エー・ダブリュー・エス"),
    "GCP": ("ジーシーピー", "ジー・シー・ピー"),
    "LLM": ("エルエルエム", "エル・エル・エム"),
    "CER": ("シーイーアール", "シー・イー・アール"),
    "WER": ("ダブリューイーアール", "ダブリュー・イー・アール"),
    "VAD": ("ブイエーディー", "ブイ・エー・ディー"),
    # 2026-10-25 追加分（mapping_draft (b) の「追」）。
    # 単語読み・記号含み・部分一致で壊れる形だけを表に入れる。
    # 素の読みチェーンで足りるものはチェーン解析に任せ、表を
    # 小さく保つ（表が大きいほど部分一致の誤爆面が広がるため）。
    "CI/CD": ("シーアイシーディー", "シー・アイ・シー・ディー",
              "しーあいしーでぃー"),
    "E2E": ("イートゥーイー", "イートゥイー", "いーとぅーいー"),
    "GraphQL": ("グラフキューエル", "ぐらふきゅーえる"),
    "IPS": ("アイピーエス", "アイ・ピー・エス", "あいぴーえす"),
    "NoSQL": ("ノーエスキューエル", "のーえすきゅーえる"),
    "USB-C": ("ユーエスビーシー", "ユー・エス・ビー・シー",
              "ゆーえすびーしー"),
    "ARPU": ("アープ", "あーぷ"),
    "M&A": ("エムアンドエー", "エム・アンド・エー", "えむあんどえー"),
    "ROAS": ("ロアス", "ろあす"),
    "SDGs": ("エスディージーズ", "えすでぃーじーず"),
    "TOEIC": ("トーイック", "トイック", "とーいっく", "といっく"),
    # SIM はひらがな形（しむ）を入れない。「楽しむ」等の動詞の
    # 一部を誤変換するため。カタカナ形だけなら衝突はほぼ無い。
    "SIM": ("シム",),
}

# 代表的頭字語の正規表現コンパイル（長い読みパターンから優先して適用）
_COMPILED_ACRONYMS: list[tuple[re.Pattern[str], str]] = []
_all_acronym_pairs: list[tuple[str, str]] = []
for _target, _patterns in _ACRONYMS.items():
    for _pat in _patterns:
        _all_acronym_pairs.append((_pat, _target))

# 「アイディーイー」が「アイディー（ID）」に取られないよう長い順にソート
_all_acronym_pairs.sort(key=lambda pair: len(pair[0]), reverse=True)

for _pat, _target in _all_acronym_pairs:
    _escaped = re.escape(_pat)
    _COMPILED_ACRONYMS.append((
        re.compile(_escaped),
        _target,
    ))

# アルファベット読みトークンのリスト（参照用）
_READING_DICT: dict[str, str] = {reading: letter
                                 for letter, reading in _LETTER_READINGS}

# 2文字以上の連続したアルファベット読みの変換は、_convert_letter_chains
# のスキャナで行う（_parse_letter_chain の後ろに定義）。
# 正規表現の最長一致では「直後が除外語の頭かどうか」を見られず、
# 「エイチディーエムアイケーブル」の末尾の「ケー」を K と誤認する
# ため、1トークンずつ境界を確認しながら読む方式に変えた。

# 数字の読み（アルファベット＋数字、例: エムワン→M1, エスディーケーツー→SDK2）
_DIGIT_READINGS: Final[dict[str, str]] = {
    "ゼロ": "0", "ぜろ": "0",
    "ワン": "1", "わん": "1", "イチ": "1", "いち": "1",
    "ツー": "2", "つー": "2", "ニ": "2",
    "スリー": "3", "すりー": "3", "サン": "3", "さん": "3",
    "フォー": "4", "ふぉー": "4", "ヨン": "4", "よん": "4",
    "ファイブ": "5", "ふぁいぶ": "5",
    "シックス": "6", "しっくす": "6", "ロク": "6", "ろく": "6",
    "セブン": "7", "せぶん": "7", "ナナ": "7", "なな": "7",
    "エイト": "8", "えいと": "8", "ハチ": "8", "はち": "8",
    "ナイン": "9", "ないん": "9", "キュウ": "9", "きゅう": "9",
}

# 英字に直接後続・先行して安全に数字とみなせる読み
# 助詞や日常語と衝突しやすい単独文字（「に」「し」「ご」など）は除外する
_SAFE_SUFFIX_DIGIT_READINGS: Final[dict[str, str]] = {
    "ワン": "1", "わん": "1", "イチ": "1",
    "ツー": "2", "つー": "2",
    "スリー": "3", "すりー": "3", "サン": "3",
    "フォー": "4", "ふぉー": "4", "ヨン": "4",
    "ファイブ": "5", "ふぁいぶ": "5",
    "シックス": "6", "しっくす": "6",
    "セブン": "7", "せぶん": "7", "ナナ": "7",
    "エイト": "8", "えいと": "8", "ハチ": "8",
    "ナイン": "9", "ないん": "9", "キュウ": "9",
    "ゼロ": "0", "ぜろ": "0",
}

# 一般単語を保護するための除外語（これらで始まる・終わる場合はアルファベット連続とみなさない）
_EXCLUSIONS: Final[tuple[str, ...]] = (
    "エスカレーター", "エメラルド", "ビール", "ピータン", "チーズ",
    "コーヒー", "ジェイソン", "アイディア", "アイデア", "アンパン",
    "エスカルゴ", "エステ", "エルボー", "オーケストラ", "ケーブル",
)


# --------------------------------------------- 文脈による固有表現・IDE補正
# 音声認識モデルが「アンチグラビティ」「Antigravity」の文脈で
# 「IDE」を「FDE」「USJ」「アイディーいー」等と聞き間違えたものを確実に救済する。
_ANTIGRAVITY_IDE_RE: Final[re.Pattern[str]] = re.compile(
    r"(?i)(アンチグラビティ[ー]?|Antigravity|あんちぐらびてぃ[ー]?)"
    r"[\s・,、]*"
    r"(?:FDE|USJ|アイディー[いイ]ー?|あいでぃー[いイ]ー?|アイディ[いイ]ー?|"
    r"あいでぃ[いイ]ー?|ＩＤＥ|アイ・ディー・イー|あい・でぃー・いー|IDE)"
)

# 開発環境・エディタ文脈での FDE / USJ 誤認識の救済
_DEV_CONTEXT_IDE_RE: Final[re.Pattern[str]] = re.compile(
    r"(?i)(開発環境|エディタ[ー]?|統合開発環境|次世代)"
    r"[\s・,、]*"
    r"(?:FDE|USJ)"
)

# 1文字読み＋数字読み（例: エムワン -> M1, フォーケー -> 4K）の事前コンパイル
# 毎回の呼び出しで 60×20=1200 回の re.sub を動的コンパイルしていたのを
# 結合正規表現にして一括処理し、CPU 負荷をゼロにする。
_L_READINGS_SORTED = sorted(_LETTER_READINGS, key=lambda x: len(x[1]),
                            reverse=True)
_D_READINGS_SORTED = sorted(_DIGIT_READINGS.items(), key=lambda x: len(x[0]),
                            reverse=True)
_L_MAP: Final[dict[str, str]] = {r: l for l, r in _L_READINGS_SORTED}
_D_MAP: Final[dict[str, str]] = dict(_D_READINGS_SORTED)

_L_ALT = "|".join(re.escape(r) for r in _L_MAP)
_D_ALT = "|".join(re.escape(r) for r in _D_MAP)

_LETTER_THEN_DIGIT_RE: Final[re.Pattern[str]] = re.compile(
    rf"({_L_ALT})[・\s]*({_D_ALT})"
)
_DIGIT_THEN_LETTER_RE: Final[re.Pattern[str]] = re.compile(
    rf"({_D_ALT})[・\s]*({_L_ALT})"
)

_SUFFIX_DIGIT_ALT = "|".join(re.escape(w) for w in _SAFE_SUFFIX_DIGIT_READINGS)
_ALPHA_THEN_DIGIT_RE: Final[re.Pattern[str]] = re.compile(
    rf"([A-Za-z]+)[・\s]*({_SUFFIX_DIGIT_ALT})"
)
_DIGIT_THEN_ALPHA_RE: Final[re.Pattern[str]] = re.compile(
    rf"({_SUFFIX_DIGIT_ALT})[・\s]*([A-Za-z]+)"
)


def _repl_letter_then_digit(m: re.Match[str]) -> str:
    l_part = _L_MAP.get(m.group(1), "")
    d_part = _D_MAP.get(m.group(2), "")
    return f"{l_part}{d_part}"


def _repl_digit_then_letter(m: re.Match[str]) -> str:
    d_part = _D_MAP.get(m.group(1), "")
    l_part = _L_MAP.get(m.group(2), "")
    return f"{d_part}{l_part}"


def _repl_alpha_then_digit(m: re.Match[str]) -> str:
    return f"{m.group(1)}{_SAFE_SUFFIX_DIGIT_READINGS.get(m.group(2), '')}"


def _repl_digit_then_alpha(m: re.Match[str]) -> str:
    return f"{_SAFE_SUFFIX_DIGIT_READINGS.get(m.group(1), '')}{m.group(2)}"


def _consume_forward_tokens(text: str) -> tuple[str, str]:
    """文字列の先頭からアルファベット読みトークンを消費し (英字列, 残り) を返す。"""
    letters: list[str] = []
    idx = 0
    wlen = len(text)
    while idx < wlen:
        # 区切り記号（中黒・空白・読点）をスキップ
        sep_m = re.match(r"^[・\s,、]+", text[idx:])
        if sep_m:
            idx += len(sep_m.group(0))
            if idx >= wlen:
                break
        matched = False
        for letter, reading in _LETTER_READINGS:
            if text.startswith(reading, idx):
                next_idx = idx + len(reading)
                # 伸ばして発音したときの長音の重なり（ピーー）は
                # 同じトークンの一部として吸収する
                while next_idx < wlen and text[next_idx] == "ー":
                    next_idx += 1
                # 直後にカタカナが続く場合、次のカタカナが別の読みトークンでなければ
                # 一般単語の一部（例: 「ケーブル」の「ケー」）とみなして中断する
                if next_idx < wlen and re.match(r"[ァ-ヴー]", text[next_idx]):
                    has_next = any(
                        text.startswith(r2, next_idx)
                        for _, r2 in _LETTER_READINGS
                    )
                    if not has_next:
                        break
                letters.append(letter)
                idx = next_idx
                matched = True
                break
        if not matched:
            break
    if letters:
        return "".join(letters), text[idx:]
    return "", text


def _parse_letter_chain(chain_text: str) -> str:
    """アルファベット読みの連続テキストを英字列（例: 'エフディーイー' -> 'FDE'）にする。"""
    # 中黒や空白、読点を除去しながらトークン分割
    cleaned = re.sub(r"[・\s,、]+", " ", chain_text).strip()
    words = cleaned.split() if " " in cleaned else [cleaned]
    letters: list[str] = []

    for word in words:
        idx = 0
        wlen = len(word)
        while idx < wlen:
            matched = False
            # 長い読みから順に先頭一致を試す
            for letter, reading in _LETTER_READINGS:
                if word.startswith(reading, idx):
                    letters.append(letter)
                    idx += len(reading)
                    matched = True
                    break
            if not matched:
                # 解析不能な文字が混ざっていたら失敗
                return ""

    if len(letters) >= 2:
        return "".join(letters)
    return ""


# --------------------------------- 頭字語テーブルの境界ガード付き適用
# テーブルの部分文字列置換が長い読みチェーンの先頭だけを先に取り、
# 残りを壊す事故（エーアイピーシー → エーIPシー）の対策。
# 置換位置の前後が「読みトークンの続き」なら、その一致はチェーンの
# 一部とみなして置換しない（チェーン側でまとめて処理させる）。

def _ends_with_reading(text: str, pos: int) -> bool:
    """text[:pos] の末尾がアルファベット読みトークンで終わるか。"""
    prefix = text[:pos].rstrip("・,、 \t\n　")
    # 長音の重なり（ピーー）は畳んでから末尾を見る
    prefix = re.sub(r"ー{2,}", "ー", prefix)
    return any(prefix.endswith(r) for _, r in _LETTER_READINGS)


def _starts_with_reading(text: str, pos: int) -> bool:
    """text[pos:] の先頭がアルファベット読みトークンで始まるか。"""
    suffix = text[pos:].lstrip("・,、 \t\n　")
    suffix = re.sub(r"ー{2,}", "ー", suffix)
    return any(suffix.startswith(r) for _, r in _LETTER_READINGS)


def _plain_chain_result(pattern: str) -> str:
    """読みパターンが素のチェーン解析だけで得られる英字列。

    得られなければ空文字。テーブル側の表記（USB-C 等）と一致する
    パターンはチェーンに任せてよく、一致しないもの（単語読み・
    記号含み・チェーンでは作れない形）だけを先行確定の対象にする
    ための振り分けに使う。
    """
    cleaned = re.sub(r"[・\s,、]+", "", pattern)
    return _parse_letter_chain(cleaned)


# テーブル全件（境界ガード付き適用に使う、生パターン付き）
_COMPILED_ACRONYMS_ALL: list[tuple[re.Pattern[str], str, str]] = [
    (pat, target, raw)
    for (raw, target), (pat, _t) in zip(_all_acronym_pairs,
                                        _COMPILED_ACRONYMS)
]

# 先行確定の対象: チェーン解析ではそのまま得られないパターンだけ。
# 素の読みチェーン形まで先に置換すると、長いチェーンの部分一致で
# 壊れる（従来の事故そのもの）ので、ここには絶対に入れない。
_COMPILED_ACRONYMS_SPECIAL: list[tuple[re.Pattern[str], str, str]] = [
    entry for entry in _COMPILED_ACRONYMS_ALL
    if _plain_chain_result(entry[2]) != entry[1]
]


def _apply_acronyms_guarded(
    text: str,
    entries: list[tuple[re.Pattern[str], str, str]],
) -> str:
    """境界ガード付きで頭字語テーブルを適用する。"""
    for pat, target, raw in entries:
        def _repl(m: re.Match[str], _raw: str = raw,
                  _target: str = target, _src: str = text) -> str:
            s, e = m.span()
            # 前後が読みの続きならチェーンの一部なので触らない
            if _ends_with_reading(_src, s) or _starts_with_reading(
                    _src, e):
                return m.group(0)
            # 短い単語読み（アープ、シム等）は、カタカナ語の途中に
            # 現れたら一般語の一部（ハープ、マキシム）とみなす
            if len(_raw) <= 3:
                if s > 0 and "ァ" <= _src[s - 1] <= "ヶ":
                    return m.group(0)
                if e < len(_src) and "ァ" <= _src[e] <= "ヶ":
                    return m.group(0)
            return _target

        text = pat.sub(_repl, text)
    return text


# ------------------------------------------------ チェーン解析（走査式）

def _match_reading_at(text: str, pos: int) -> tuple[str, int] | None:
    """pos から始まる読みトークンを1つ読み、(英字, 終端) を返す。

    長音の重なり（ピーー の余分な ー）は、伸ばして発音したときに
    SenseVoice が重ねて出すノイズなので、同じトークンの一部として
    吸収する。ー で始まる日本語の単語は文中に無いため、読みの直後の
    ー は常に「伸ばし」とみなしてよい。
    """
    for letter, reading in _LETTER_READINGS:
        if text.startswith(reading, pos):
            end = pos + len(reading)
            while end < len(text) and text[end] == "ー":
                end += 1
            return letter, end
    return None


_CHAIN_SEPS: Final[str] = "・,、"


def _skip_chain_seps(text: str, pos: int) -> int:
    """チェーンの区切り（中黒・読点・空白）を読み飛ばす。"""
    while pos < len(text) and (text[pos] in _CHAIN_SEPS
                               or text[pos].isspace()):
        pos += 1
    return pos


def _convert_letter_chains(text: str) -> str:
    """読みトークンが2個以上連続する範囲を英字列に変換する。

    テーブルより先に最長一致で処理するのが、テーブルの部分一致で
    チェーンが壊れる事故への対策（エーアイピーシー → AIPC）。
    除外語（ケーブル等）で始まる位置ではチェーンを始めず・伸ばさ
    ない: 「エイチディーエムアイケーブル」の末尾の「ケー」を K と
    誤認しないため（従来はテーブル先行で守られていた境界）。
    """
    out: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        if any(text.startswith(excl, i) for excl in _EXCLUSIONS):
            out.append(text[i])
            i += 1
            continue
        first = _match_reading_at(text, i)
        if first is None:
            out.append(text[i])
            i += 1
            continue
        letters = [first[0]]
        last_end = first[1]
        pos = first[1]
        while pos < n:
            nxt = _skip_chain_seps(text, pos)
            if nxt >= n:
                break
            if any(text.startswith(excl, nxt) for excl in _EXCLUSIONS):
                break
            m = _match_reading_at(text, nxt)
            if m is None:
                break
            letters.append(m[0])
            pos = m[1]
            last_end = pos
        span = text[i:last_end]
        if len(letters) >= 2 and not any(
                excl in span for excl in _EXCLUSIONS):
            out.append("".join(letters))
            i = last_end
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


# チェーン解析の結果が一般表記とずれる数件だけの固定表。
# 読み側テーブル（ユーエスビーシー → USB-C）で拾えなかった残り
# （境界ガードで先行確定を外れ、チェーンが USBC にした形）を直す。
_CHAIN_FIXUPS: Final[tuple[tuple[re.Pattern[str], str], ...]] = (
    (re.compile(r"(?<![A-Za-z])USBC(?![A-Za-z])"), "USB-C"),
    (re.compile(r"(?<![A-Za-z])CICD(?![A-Za-z])"), "CI/CD"),
)


# ------------------------------------------------ 単独1文字の境界判定

# 単独変換の Tier B（助詞境界）で数える助詞。
# 直前は「は/が/も/の/と」だけ（「をエム」のような形は言わない）。
# 直後は助詞全般に「で」を含める（「エムでお願いします」が
# 典型形のため）。「です/だ/ます/って」と句読点・文末も区切り。
_SINGLE_PREV_OK: Final[str] = "はがもとの"
_SINGLE_NEXT_OK: Final[str] = "はがをにへともので"
_SINGLE_PUNCT: Final[str] = "。、！？!?"


def _is_boundary_after(text: str, pos: int) -> bool:
    """pos の直後が文末・助詞・句読点などの「区切り」かどうか。"""
    if pos >= len(text):
        return True
    rest = text[pos:]
    if not rest.strip(" " + _SINGLE_PUNCT + "　"):
        return True
    ch = text[pos]
    if ch in _SINGLE_PUNCT or ch in _SINGLE_NEXT_OK:
        return True
    return rest.startswith(("です", "ます", "って", "だ"))


def _is_boundary_before(text: str, pos: int) -> bool:
    """pos の直前が文頭・読点・助詞（は/が/も/の/と）かどうか。"""
    if pos <= 0:
        return True
    prefix = text[:pos]
    if not prefix.strip(" " + _SINGLE_PUNCT + "　"):
        return True
    ch = text[pos - 1]
    return ch in "、,，" or ch in _SINGLE_PREV_OK


def _join_leftover_token(text: str) -> str:
    """英字列の直後に残った単独トークン1個を結合する最終受け皿。

    チェーンやテーブルで拾い切れず「IPエス」のように残った場合に、
    後方が文末・助詞・句読点のときだけ結合する。I（アイ）と
    Y（ワイ）は単独変換と同じ理由で結合しない。
    """
    out: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        m_alpha = re.match(r"[A-Za-z]+", text[i:])
        if m_alpha is None:
            out.append(text[i])
            i += 1
            continue
        j = i + len(m_alpha.group(0))
        nxt = _skip_chain_seps(text, j)
        m = _match_reading_at(text, nxt) if nxt < n else None
        if (m is not None and m[0] not in ("I", "Y")
                and not any(text.startswith(excl, nxt)
                            for excl in _EXCLUSIONS)
                and _is_boundary_after(text, m[1])):
            out.append(text[i:j] + m[0])
            i = m[1]
        else:
            out.append(text[i:j])
            i = j
    return "".join(out)


# ------------------------------------------------ 単独1文字変換（Tier）

# 文字別の許可 Tier（W=区間全体、B=助詞境界、S=サフィックス直前）。
# ・I（アイ）は愛・相・会いと、Y（ワイ）は関西弁の一人称と判別
#   できないので、単独では一切変換しない（表に載せない）。
# ・A（エー）と O（オー）は感嘆・フィラーと同音なので全体単独
#   （W）だけ禁止する。Q は合図の「キュー」と同音だが、単独発話
#   では Q のことが多いので W・B を許可し、S は許可しない。
# ・T（ティー）は紅茶、U（ユー）は英語 you のカナ表記と同音
#   なので、サフィックス直前（T型、U型）のときだけ許可する。
_SINGLE_POLICY: Final[dict[str, frozenset[str]]] = {
    "A": frozenset("BS"),
    "O": frozenset("BS"),
    "Q": frozenset("WB"),
    "T": frozenset("S"),
    "U": frozenset("S"),
}
_SINGLE_DEFAULT: Final[frozenset[str]] = frozenset("WBS")
_SINGLE_SUFFIXES: Final[tuple[str, ...]] = ("サイズ", "型", "級", "判")

# 単独変換はカタカナ読みだけを対象にする。ひらがなの単独読みは
# 「えー」（フィラー）や「あい」のような日本語そのものが多く、
# エンジンの基本形もカタカナなので、安全側に倒す。
_SINGLE_READINGS: Final[list[tuple[str, str]]] = sorted(
    [(letter, r) for letter, r in _LETTER_READINGS
     if "ァ" <= r[0] <= "ヶ"],
    key=lambda pair: len(pair[1]), reverse=True)


def _should_convert_single(text: str, s: int, e: int, letter: str) -> bool:
    """単独トークン (text[s:e] = letter の読み) を変換してよいか。"""
    policy = _SINGLE_POLICY.get(letter, _SINGLE_DEFAULT)
    if not policy:
        return False
    # 除外語の一部なら触らない（エステのエス等）
    if any(text.startswith(excl, s) for excl in _EXCLUSIONS):
        return False
    # 前後が読みトークンの続きならチェーンの一部（チェーン側の領分）
    if _ends_with_reading(text, s):
        return False
    nxt = _skip_chain_seps(text, e)
    if nxt < len(text) and _match_reading_at(text, nxt) is not None:
        return False
    # 区間全体がこの読みだけなら、W の可否だけで決める。
    # （全体単独の A・O を、B の「直後が文末」で誤変換しないため）
    whole = (not text[:s].strip(" " + _SINGLE_PUNCT + "　")
             and not text[e:].strip(" " + _SINGLE_PUNCT + "　"))
    if whole:
        return "W" in policy
    # 直後がカタカナなら複合語の一部として保護する（エムダッシュ等）。
    # ただしサフィックス（サイズ/型/級/判）だけは S の判定に回す。
    if e < len(text) and "ァ" <= text[e] <= "ヶ":
        if "S" in policy:
            for suffix in _SINGLE_SUFFIXES:
                if text.startswith(suffix, e) and _is_boundary_after(
                        text, e + len(suffix)):
                    return True
        return False
    # G（ジー）の擬態語「ジーっと見る」「ジーと見る」は変換しない
    if letter == "G" and (text[e:].startswith("っと")
                          or text[e:].startswith("と見")):
        return False
    if ("B" in policy and _is_boundary_before(text, s)
            and _is_boundary_after(text, e)):
        return True
    if "S" in policy:
        for suffix in _SINGLE_SUFFIXES:
            if text.startswith(suffix, e) and _is_boundary_after(
                    text, e + len(suffix)):
                return True
    return False


def _convert_single_letters(text: str) -> str:
    """単独で現れた1文字読みを Tier 条件のもとで英字にする。

    例: 「エム」→「M」、「サイズはエムです」→「サイズはMです」、
    「エムサイズ」→「Mサイズ」、「ビーとシーの間」→「BとCの間」。
    境界条件を満たさないもの（「ティーを飲む」のティー等）は
    そのまま残す。
    """
    out: list[str] = []
    i = 0
    n = len(text)
    while i < n:
        matched: tuple[str, int] | None = None
        for letter, reading in _SINGLE_READINGS:
            if letter in ("I", "Y"):
                continue
            if text.startswith(reading, i):
                end = i + len(reading)
                while end < n and text[end] == "ー":
                    end += 1
                matched = (letter, end)
                break
        if matched is None:
            out.append(text[i])
            i += 1
            continue
        letter, end = matched
        if _should_convert_single(text, i, end, letter):
            out.append(letter)
            i = end
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def convert_spelled_alphabet(text: str) -> str:
    """テキスト中のアルファベット読みを大文字英語に変換する。

    例:
      「エフディーイー」 -> 「FDE」
      「エーピーアイの仕様」 -> 「APIの仕様」
      「ユーアールエルはこちら」 -> 「URLはこちら」
      「エムワンチップ」 -> 「M1チップ」
      「エム」 -> 「M」（単独1文字は境界条件を満たすときだけ）
      「エーアイピーシー」 -> 「AIPC」（チェーン先行で部分一致を回避）
    """
    if not text:
        return text

    # 0. アンチグラビティ / 開発環境文脈での IDE 誤認識の救済
    text = _ANTIGRAVITY_IDE_RE.sub(r"\1 IDE", text)
    text = _DEV_CONTEXT_IDE_RE.sub(r"\1 IDE", text)

    # 除外語の保護
    for excl in _EXCLUSIONS:
        if excl in text:
            # 除外語がある場合は後で復元できるようプレースホルダー化
            pass

    # 1. 英字と隣接するカタカナ読み混在の解決
    # 英字アンカーがある場合は、途中の短い頭字語に誤分解される前に直接消費する
    # 例: Hディーエムアイ -> HDMI, H・ディー・エム・アイ -> HDMI, UエスJ -> USJ, Pシー -> PC
    def _repl_after(m: re.Match[str]) -> str:
        prefix = m.group(1)
        rest = m.group(2)
        consumed, remainder = _consume_forward_tokens(rest)
        if consumed:
            return prefix + consumed + remainder
        return m.group(0)

    for _ in range(5):
        prev = text
        text = re.sub(
            r"([A-Za-z]+)[・\s,、]*([ァ-ヴーぁ-ん].*)",
            _repl_after,
            text,
        )
        if text == prev:
            break

    # 先行するカタカナ読みの消費（例: エフディーE -> FDE）
    for letter, reading in _LETTER_READINGS:
        pat_before = (
            rf"(^|[^ァ-ヴーぁ-ん]){re.escape(reading)}[・\s,、]*([A-Za-z]+)"
        )
        text = re.sub(pat_before, rf"\g<1>{letter}\g<2>", text)

    # 中黒や空白で区切られた英字同士を結合（例: H・DMI -> HDMI, U・S・J -> USJ）
    text = re.sub(r"(?<=[A-Za-z])[・\s]+(?=[A-Za-z])", "", text)

    # 2. 単語読み・記号含みの頭字語だけを先に確定させる。
    #    グラフキューエル→GraphQL のようにチェーン解析では作れない
    #    形が対象で、境界ガード付きで適用する。素の読みチェーン形
    #    （エスエヌエス等）まで先に置換すると、長いチェーンの部分
    #    一致で壊れる（従来の事故）ので、ここでは絶対に扱わない。
    text = _apply_acronyms_guarded(text, _COMPILED_ACRONYMS_SPECIAL)

    # 3. 任意の2文字以上のアルファベット読み連続を置換（最長一致）。
    #    テーブルより先に処理するのが、部分一致でチェーンが壊れる
    #    事故（エーアイピーシー → エーIPシー）への対策。
    text = _convert_letter_chains(text)
    for _fix_pat, _fix_to in _CHAIN_FIXUPS:
        text = _fix_pat.sub(_fix_to, text)

    # 4. 残った頭字語テーブルを境界ガード付きで適用する。
    #    チェーンで拾えなかった形（IDE の表記揺れ等）の最終受け皿。
    text = _apply_acronyms_guarded(text, _COMPILED_ACRONYMS_ALL)

    # 置換後に生じた英字同士の結合
    text = re.sub(r"(?<=[A-Za-z])[・\s]+(?=[A-Za-z])", "", text)

    # 5. アルファベット（1文字または連続）＋数字の読み（例: エムワン→M1, フォーケー→4K）
    text = _LETTER_THEN_DIGIT_RE.sub(_repl_letter_then_digit, text)
    text = _DIGIT_THEN_LETTER_RE.sub(_repl_digit_then_letter, text)

    # 6. すでに英字になったものに後続・先行する数字読み（例: SDKツー -> SDK2）
    text = _ALPHA_THEN_DIGIT_RE.sub(_repl_alpha_then_digit, text)
    text = _DIGIT_THEN_ALPHA_RE.sub(_repl_digit_then_alpha, text)

    # 7. 英字列の直後に残った単独トークン1個を結合する（IPエス型）
    text = _join_leftover_token(text)

    # 8. 単独1文字の読みを、Tier の境界条件を満たすものだけ変換する
    text = _convert_single_letters(text)

    # 9. 後処理での文脈再補正（アルファベット変換後の FDE 等を最終救済）
    text = _ANTIGRAVITY_IDE_RE.sub(r"\1 IDE", text)
    text = _DEV_CONTEXT_IDE_RE.sub(r"\1 IDE", text)

    return text


# ------------------------------------------------ 外来語の混在崩れ修復
# 音声認識エンジンが外来語を「カタカナの頭＋実在する英単語」という
# 形で出す崩れ（「アニメーション」→「アニnotion」、2026-10-25 に
# 利用者が実際に踏んだ）を元に戻す。エンジンは音の似た英単語を
# 当てに来るので、外来語の末尾が英単語そのものに化けやすい。
#
# 安全策（誤爆は未変換より害が大きいので条件は厳しくする）:
#   ・カタカナ列と英字が空白なしで直接くっついた形だけが対象。
#     単独の英単語（アプリ名「Notion」等）や、空白を挟んで並んだ
#     だけのものは、意図的な表記の可能性があるので絶対に触らない。
#   ・カタカナ部分は、直前のカタカナ列「全体」が表のキーと完全
#     一致したときだけ。長いカタカナ語の途中には一致させない。
#   ・英字の直後が英数字、または URL・識別子らしい記号＋英数字
#     なら触らない（「version2」「notion.so」等の一部かもしれ
#     ないため）。
# 表は (カタカナの頭, 英単語の小文字形) -> 外来語全体。
_LOANWORD_REPAIRS: Final[dict[tuple[str, str], str]] = {
    # 実例: 「メーション」をエンジンが英単語 notion に化かした形
    ("アニ", "notion"): "アニメーション",
    # モーションは英単語 motion が語源で音もほぼそのまま
    ("プロ", "motion"): "プロモーション",
    ("エ", "motion"): "エモーション",
    # テレビジョンの「ビジョン」は vision の音写でほぼ同音
    ("テレ", "vision"): "テレビジョン",
    # バージョンは英単語 version の音写そのもの
    ("バー", "version"): "バージョン",
    # ワークは work の音写。「〜ワーク」型でも同じ崩れが出る
    ("ネット", "work"): "ネットワーク",
    ("ホーム", "work"): "ホームワーク",
    ("フレーム", "work"): "フレームワーク",
}

_MIXED_LOANWORD_RE: Final[re.Pattern[str]] = re.compile(
    r"([ァ-ヶー]+)([A-Za-z]+)")


def repair_mixed_loanwords(text: str) -> str:
    """外来語の「カタカナ＋英単語」混在崩れを元に戻す。

    例: 「アニnotion」 -> 「アニメーション」、
        「アニnotionが好き」 -> 「アニメーションが好き」
    英単語の大小文字は区別しない。表に無い組み合わせ、空白で
    区切られた並び、単独の英単語は一切変えない。
    """
    if not text:
        return text

    def _repl(m: re.Match[str]) -> str:
        fixed = _LOANWORD_REPAIRS.get(
            (m.group(1), m.group(2).lower()))
        if fixed is None:
            return m.group(0)
        # 英字の直後を見る。英数字が続けば、より長い英単語や
        # 識別子の一部（「version2」等）なので触らない。
        # 「. / - _ の後に英数字」も URL やパス、複合識別子の
        # 一部（「notion.so」「version-control」）とみて触らない。
        rest = text[m.end():]
        if rest:
            nxt = rest[0]
            if nxt.isascii() and nxt.isalnum():
                return m.group(0)
            if (nxt in "._/-" and len(rest) > 1
                    and rest[1].isascii() and rest[1].isalnum()):
                return m.group(0)
        return fixed

    return _MIXED_LOANWORD_RE.sub(_repl, text)


# ------------------------------------------------ 同音異義語・同訓異義語の文脈自動補正

# 音声認識モデル（SenseVoice / Whisper 等）は音響特徴のみから漢字を決定するため、
# 「機会」と「機械」、「暑い」と「熱い」、「収める」と「納める」などの
# 同訓異義語・同音異義語の判定を文脈と逆に誤変換することが極めて多い。
# 前後の共起表現（直前・直後の助詞や名詞・動詞）から確定可能なパターンを
# ルールベースで安全・超高速に補正する。
# 誤爆防止のため、前後文脈が明確なもののみを事前コンパイルして厳選する。

_HOMOPHONE_RULES: Final[list[tuple[re.Pattern[str],
                                   str | Callable[[re.Match[str]], str]]]] = [
    # ------------------ 同訓異義語 ------------------
    # 【あつい】
    # 暑い（気候・気温）: 今日は暑い、夏は暑い、暑い日、気温が暑い
    (re.compile(
        r"(今日|明日|昨日|夏|外|室内|部屋|日|夜|季節|時期|気温|天候|気候)[\s]*"
        r"(?:は|が|も|で)?[\s]*(?:とても|すごく|かなり|実に)?[\s]*[熱厚]い"),
     lambda m: m.group(0).replace("熱い", "暑い").replace("厚い", "暑い")),
    (re.compile(r"[熱厚]い[\s]*(夏|日|夜|季節|時期)"), r"暑い\1"),
    # 熱い（温度・熱量・情熱）: お茶が熱い、熱いお茶、熱い思い、熱い視線
    (re.compile(
        r"(お茶|お湯|風呂|スープ|コーヒー|ラーメン|鍋|鉄|視線|思い|情熱|戦い|闘志|血|胸)[\s]*"
        r"(?:は|が|も|の|を)?[\s]*(?:とても|すごく|かなり)?[\s]*[暑厚]い"),
     lambda m: m.group(0).replace("暑い", "熱い").replace("厚い", "熱い")),
    (re.compile(
        r"[暑厚]い[\s]*(お茶|お湯|風呂|スープ|コーヒー|ラーメン|鍋|視線|思い|情熱|戦い|闘志)"),
     r"熱い\1"),
    # 厚い（厚み・人情）: 本が厚い、壁が厚い、手厚い、情に厚い
    (re.compile(
        r"(本|壁|紙|板|氷|雲|層|手当て|手当|情|志|信頼|恩義|友情)[\s]*"
        r"(?:は|が|も|の|に)?[\s]*(?:とても|すごく|かなり)?[\s]*[暑熱]い"),
     lambda m: m.group(0).replace("暑い", "厚い").replace("熱い", "厚い")),
    (re.compile(r"[暑熱]い[\s]*(本|壁|紙|板|氷|雲|層|コート|ジャケット)"), r"厚い\1"),

    # 【おさめる】
    # 納める（納入・税金）: 税金を納める、会費を納める、納期に納める
    (re.compile(
        r"(税金|税|会費|年金|保険料|代金|授業料|学費|注文|結納|納期)[\s]*"
        r"(?:を|に|で)?[\s]*(?:収め|治め|修め)"),
     lambda m: re.sub(r"(?:収め|治め|修め)", "納め", m.group(0))),
    # 治める（統治・鎮静）: 国を治める、争いを治める、怒りを治める
    (re.compile(
        r"(国|天下|領地|争い|暴動|怒り|混乱|騒動)[\s]*"
        r"(?:を)?[\s]*(?:収め|納め|修め)"),
     lambda m: re.sub(r"(?:収め|納め|修め)", "治め", m.group(0))),
    # 修める（学問・修行）: 学問を修める、身を修める
    (re.compile(
        r"(学問|学業|身|修行)[\s]*(?:を)?[\s]*(?:収め|納め|治め)"),
     lambda m: re.sub(r"(?:収め|納め|治め)", "修め", m.group(0))),
    # 収める（収納・成果・記録）: 箱に収める、成功を収める、写真に収める
    (re.compile(
        r"(箱|枠|手元|写真|カメラ|成功|勝利|好成績|成果)[\s]*"
        r"(?:を|に|内)?[\s]*(?:納め|治め|修め)"),
     lambda m: re.sub(r"(?:納め|治め|修め)", "収め", m.group(0))),
    (re.compile(
        r"(?:納め|治め|修め)る[\s]*(?:べき)?[\s]*(成果|好成績|勝利|成功)"),
     r"収めるべき\1"),

    # 【つく】
    # 着く（到着）: 駅に着く、席に着く、現地に着く
    (re.compile(
        r"(駅|空港|家|現地|目的地|席|現場|ホテル|港|ホーム)[\s]*"
        r"(?:に|へ)[\s]*(?:付い|就い|付く|就く)"),
     lambda m: m.group(0).replace("付い", "着い").replace("就い", "着い")
                         .replace("付く", "着く").replace("就く", "着く")),
    # 就く（就任）: 職に就く、教壇に就く、座に就く
    (re.compile(
        r"(職|教壇|役職|座|ポスト|教鞭|任務)[\s]*(?:に)[\s]*"
        r"(?:着い|付い|着く|付く)"),
     lambda m: m.group(0).replace("着い", "就い").replace("付い", "就い")
                         .replace("着く", "就く").replace("付く", "就く")),
    # 付く（付着・点火）: 傷が付く、火が付く、気が付く
    (re.compile(
        r"(傷|火|明かり|電気|身|気|目処|折り合い|決着|自信|差)[\s]*"
        r"(?:が|に)[\s]*(?:着い|就い|着く|就く)"),
     lambda m: m.group(0).replace("着い", "付い").replace("就い", "付い")
                         .replace("着く", "付く").replace("就く", "付く")),

    # 【とめる】
    # 止める（停止）: 車を止める、息を止める、録音を止める
    (re.compile(
        r"(車|息|足|作業|録音|音楽|手|再生|呼吸)[\s]*(?:を)?[\s]*"
        r"(?:泊め|留め)"),
     lambda m: re.sub(r"(?:泊め|留め)", "止め", m.group(0))),
    # 泊める（宿泊）: ホテルに泊める、友人を泊める
    (re.compile(
        r"(宿|ホテル|友達|友人|親戚|客)[\s]*(?:に|を)?[\s]*"
        r"(?:止め|留め)"),
     lambda m: re.sub(r"(?:止め|留め)", "泊め", m.group(0))),
    # 留める（固定・記憶）: 心に留める、ピンで留める
    (re.compile(
        r"(心|記憶|ピン|ボタン|胸)[\s]*(?:に|で|を)?[\s]*"
        r"(?:止め|泊め)"),
     lambda m: re.sub(r"(?:止め|泊め)", "留め", m.group(0))),

    # 【はかる】
    # 計る（時間）: 時間を計る、タイミングを計る
    (re.compile(
        r"(時間|タイミング|タイム|時計)[\s]*(?:を|で)?[\s]*"
        r"(?:測る|量る|図る|謀る)"),
     lambda m: re.sub(r"(?:測る|量る|図る|謀る)", "計る", m.group(0))),
    # 量る（重さ・分量）: 重さを量る、体重を量る
    (re.compile(
        r"(重さ|体重|容積|目方|重量)[\s]*(?:を)?[\s]*"
        r"(?:測る|計る|図る|謀る)"),
     lambda m: re.sub(r"(?:測る|計る|図る|謀る)", "量る", m.group(0))),
    # 測る（長さ・温度）: 長さを測る、体温を測る
    (re.compile(
        r"(長さ|距離|深さ|面積|体温|熱)[\s]*(?:を)?[\s]*"
        r"(?:量る|計る|図る|謀る)"),
     lambda m: re.sub(r"(?:量る|計る|図る|謀る)", "測る", m.group(0))),
    # 図る（企図・解決）: 解決を図る、便宜を図る、向上を図る
    (re.compile(
        r"(便宜|解決|自立|向上|改善|効率化|連携|再起)[\s]*(?:を)?[\s]*"
        r"(?:測る|量る|計る|謀る)"),
     lambda m: re.sub(r"(?:測る|量る|計る|謀る)", "図る", m.group(0))),

    # 【うつす】
    # 写す（写真・原本）: 写真に写す、カメラで写す
    (re.compile(
        r"(写真|カメラ|ノート|原本)[\s]*(?:を|に|で)?[\s]*(?:映す|移す)"),
     lambda m: re.sub(r"(?:映す|移す)", "写す", m.group(0))),
    # 映す（投影・鏡）: 鏡に映す、映画を映す、スクリーンに映す
    (re.compile(
        r"(鏡|スクリーン|画面|映画|プロジェクター|水面)[\s]*(?:に|を)?[\s]*"
        r"(?:写す|移す)"),
     lambda m: re.sub(r"(?:写す|移す)", "映す", m.group(0))),
    # 移す（場所・行動・感染）: 場所を移す、住所を移す、行動に移す
    (re.compile(
        r"(場所|席|データ|ファイル|重心|話題|行動|感染|病気|住所|拠点|住まい)[\s]*"
        r"(?:を|に)?[\s]*(?:写す|映す)"),
     lambda m: re.sub(r"(?:写す|映す)", "移す", m.group(0))),

    # 【こえる】
    # 越える（境界・障害）: 山を越える、峠を越える、国境を越える
    (re.compile(
        r"(山|峠|国境|川|壁|冬|年|ハードル)[\s]*(?:を)?[\s]*超え"),
     lambda m: m.group(0).replace("超え", "越え")),
    # 超える（数量・限度・基準）: 基準を超える、定員を超える、予想を超える
    (re.compile(
        r"(制限|基準|予想|定員|限度|限界|100|一万|想像)[\s]*(?:を)?[\s]*越え"),
     lambda m: m.group(0).replace("越え", "超え")),

    # ------------------ 同音異義語 ------------------
    # 【きかい】
    # 機械（マシン・装置）: 精密機械、券売機、機械学習、機械の故障、機械を操作
    (re.compile(
        r"(精密|工作|農業|電子|券売|自動|重|建設|産業|印刷)[\s]*機会"),
     r"\1機械"),
    (re.compile(
        r"機会([\s]*(?:を|の|が|で)?[\s]*)"
        r"(学習|工学|油|室|警備|器具|操作|故障|修理|設計|部品|トラブル|"
        r"点検|導入|停止|運転|メンテナンス)"),
     r"機械\1\2"),
    (re.compile(
        r"機会([\s]*(?:を|が)?[\s]*)(動かす|操る|動く|壊れる|止まる|直す)"),
     r"機械\1\2"),
    # 機会（チャンス）: この機会に、機会があれば、機会を逃す
    (re.compile(
        r"(この|その|良い|いい|絶好の|貴重な|次の|またの|千載一遇の|利用の)[\s]*機械"),
     r"\1機会"),
    (re.compile(
        r"機械[\s]*(があれば|があり|に恵まれ|を逃す|をうかが|を伺|を活か|"
        r"を捉え|を設け|をいただき|をいただく)"),
     r"機会\1"),

    # 【たいしょう】
    # 対象（ターゲット）: 調査の対象、対象者、対象外
    (re.compile(
        r"(調査|支援|研究|評価|適用|課税|捜査|攻撃|比較|除外|監視|観測)"
        r"([\s]*(?:の)?[\s]*)(?:対照|対称)"),
     r"\1\2対象"),
    (re.compile(
        r"(?:対照|対称)[\s]*(者|外|内|地域|商品|年齢|範囲|となる|とする|にする)"),
     r"対象\1"),
    # 対照（コントラスト）: 好対照、対照的、対照実験
    (re.compile(r"(好|明暗|鮮やかな)[\s]*(?:対象|対称)"), r"\1対照"),
    (re.compile(r"(?:対象|対称)([\s]*(?:的|表|実験|をなす|を成す))"), r"対照\1"),
    # 対称（シンメトリー）: 左右対称、線対称
    (re.compile(r"(左右|線|点|非)[\s]*(?:対象|対照)"), r"\1対称"),
    (re.compile(r"(?:対象|対照)[\s]*(軸|図形|性)"), r"対称\1"),

    # 【かいとう】
    # 回答（返事・アンケート）: アンケートの回答、質問に回答する
    (re.compile(
        r"(アンケート|質問|問い合わせ|問合せ|ご意見|メール)"
        r"([\s]*(?:の|に|へ)?[\s]*)(?:解答|解凍)"),
     r"\1\2回答"),
    (re.compile(r"(?:解答|解凍)[\s]*(期限|いただく|願います|待ち|お願い|欄)"),
     r"回答\1"),
    # 解答（試験・問題の答え）: 試験の解答、模範解答
    (re.compile(
        r"(テスト|試験|問題|クイズ|設問)([\s]*(?:の|に|へ)?[\s]*)(?:回答|解凍)"),
     r"\1\2解答"),
    (re.compile(r"(?:回答|解凍)[\s]*(用紙|速報|解説)"), r"解答\1"),
    # 解凍（冷凍・zip）: ファイルを解凍、自然解凍
    (re.compile(
        r"(冷凍|zip|ZIP|ファイル|圧縮)([\s]*(?:を|の)?[\s]*)(?:回答|解答)"),
     r"\1\2解凍"),

    # 【いがい】
    # 意外（思いがけない）: 意外と、意外にも、意外な結果
    (re.compile(r"以外(?:と|にも|な|だった|に思|な一面|な結果)"),
     lambda m: m.group(0).replace("以外", "意外")),
    # 以外（除外）: それ以外、自分以外、業務以外
    (re.compile(
        r"(それ|これ|あれ|私|自分|本人|日本人|日本語|業務|仕事|平日|例外|"
        r"[0-9]+(?:日|時|分|人|件|個|台|本))([\s]*)意外"),
     r"\1\2以外"),

    # 【いどう】
    # 移動（場所の移動）: 車で移動、画面を移動
    (re.compile(
        r"(車|徒歩|新幹線|電車|バス|席|画面|データ|ファイル|場所)"
        r"([\s]*(?:で|を|へ)?[\s]*)異動"),
     r"\1\2移動"),
    (re.compile(r"異動[\s]*(中|時間|手段|経路)"), r"移動\1"),
    # 異動（人事）: 人事異動、部署の異動
    (re.compile(
        r"(人事|部署|転勤|役職|組織)([\s]*(?:の)?[\s]*)移動"),
     r"\1\2異動"),
    (re.compile(r"移動[\s]*(願い|届|辞令)"), r"異動\1"),

    # 【せいさく】
    # 制作（創作・映像・Web）: 映画を制作、Webサイト制作
    (re.compile(
        r"(番組|映画|アニメ|楽曲|Webサイト|ウェブサイト|ホームページ|デザイン|"
        r"ポスター|動画|映像|CM|コンテンツ)[\s]*(?:の|を)?[\s]*(?:製作|政策)"),
     r"\1制作"),
    # 製作（製造・機械）: 部品を製作、機械製作
    (re.compile(
        r"(機械|部品|試作|模型|器具|金型|工作|道具)[\s]*(?:の|を)?[\s]*"
        r"(?:制作|政策)"),
     r"\1製作"),
    # 政策（政治・方針）: 経済政策、政策提言
    (re.compile(
        r"(経済|金融|外交|環境|医療|政府|減税)[\s]*(?:の)?[\s]*(?:制作|製作)"),
     r"\1政策"),

    # 【そうぞう】
    # 想像（イマジネーション）: 想像がつく、想像を絶する
    (re.compile(r"創造(?:がつく|を絶する|以上に|どおり|通り|できない)"),
     lambda m: m.group(0).replace("創造", "想像")),
    (re.compile(r"ご創造"), "ご想像"),
    # 創造（クリエイション）: 天地創造、価値の創造
    (re.compile(r"(天地|新たな価値|新時代|神の)[\s]*(?:の|を)?[\s]*想像"),
     r"\1創造"),

    # 【かてい】
    # 過程（プロセス）: 製造の過程、進化の過程
    (re.compile(
        r"(製造|進化|成長|開発|思考|歴史)[\s]*(?:の)?[\s]*(?:仮定|家庭)"),
     r"\1の過程"),
    # 仮定（イフ）: 仮定の話、と仮定する
    (re.compile(r"(?:過程|家庭)の話"), "仮定の話"),
    (re.compile(r"と(?:過程|家庭)する"), "と仮定する"),
    # 家庭（ファミリー）: 温かい家庭、家庭料理
    (re.compile(r"(温かい|一般|明るい)[\s]*(?:過程|仮定)"), r"\1家庭"),
    (re.compile(r"(?:過程|仮定)(?:環境|料理)"),
     lambda m: "家庭" + m.group(0)[2:]),

    # 【いし】
    # 意志（決意）: 強い意志、意志を貫く
    (re.compile(r"(強い|固い|本人の|確固たる)[\s]*意思"), r"\1意志"),
    (re.compile(r"意思を貫く"), "意志を貫く"),
    # 意思（意向）: 意思疎通、意思決定、意思表示、意思を疎通
    (re.compile(r"意志([\s]*(?:の|を)?[\s]*)(表示|疎通|決定|確認)"), r"意思\1\2"),

    # 【かくてい】
    # 確定申告、確定拠出年金（誤って「画定」となるのを補正）
    (re.compile(r"画定(申告|拠出年金|判決|申告書)"), r"確定\1"),
    (re.compile(r"画定する"), "確定する"),
]


def correct_homophones(text: str) -> str:
    """前後の文脈に基づいて同音異義語・同訓異義語の誤変換を補正する。

    音声認識モデル（SenseVoice / Whisper 等）が前後の意味を取り違えて
    「機械」を「機会」、「暑い」を「熱い」、「納める」を「収める」と
    出力したものを、助詞や共起語の文脈から特定して正しい漢字に直す。
    """
    if not text:
        return text

    for pat, repl in _HOMOPHONE_RULES:
        text = pat.sub(repl, text)

    return text

