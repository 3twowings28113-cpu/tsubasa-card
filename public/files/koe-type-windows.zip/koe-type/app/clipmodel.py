"""クリップボードの窓の「中身」と「操作の決まり」。

描くことも Win32 も知らない。キーやクリックを受けて、
「何をするか」（Command）を返すだけにしてある。
本物のキーを送らずに、操作の決まりを全部試験できるようにするため。
"""

from __future__ import annotations

import re
import time
import unicodedata
from dataclasses import dataclass, field
from typing import Callable

from .clipstore import DOWNLOADS, HISTORY, Clip

# 仮想キー
VK_BACK, VK_TAB, VK_RETURN, VK_ESCAPE = 0x08, 0x09, 0x0D, 0x1B
VK_PRIOR, VK_NEXT, VK_END, VK_HOME = 0x21, 0x22, 0x23, 0x24
VK_LEFT, VK_UP, VK_RIGHT, VK_DOWN = 0x25, 0x26, 0x27, 0x28
VK_DELETE, VK_APPS, VK_F2, VK_F10 = 0x2E, 0x5D, 0x71, 0x79

KIND_FILTERS = ("all", "text", "image", "link", "files")
# 絞り込みの切り替えには出さないが、選べる種類
_EXTRA_KINDS = ("colour", "mail", "secret")

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff")
_URL = re.compile(r"^(https?://|www\.)\S+$", re.I)
_COLOUR = re.compile(r"^#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$", re.I)
_MAIL = re.compile(r"^[\w.+-]+@[\w-]+(\.[\w-]+)+$")


def norm(text: str) -> str:
    """探すための形。全角半角・大文字小文字・カタカナひらがなをそろえる。"""
    text = unicodedata.normalize("NFKC", text).casefold()
    return "".join(chr(ord(c) - 0x60) if "ァ" <= c <= "ヶ" else c
                   for c in text)


def look(clip: Clip) -> str:
    """一覧での見え方の種類。text / link / colour / mail / image / files /
    download（実ファイル）。"""
    if clip.group_id == DOWNLOADS:
        return "download"
    if clip.kind != "text":
        return clip.kind
    if clip.secret:
        return "secret"
    body = clip.snippet.strip()
    if "\n" not in body and len(body) < 2048:
        if _URL.match(body):
            return "link"
        if _COLOUR.match(body):
            return "colour"
        if _MAIL.match(body):
            return "mail"
    return "text"


def matches_kind(clip: Clip, kind: str) -> bool:
    if kind == "all":
        return True
    seen = look(clip)
    if seen == "download":
        if kind == "image":
            return clip.path.lower().endswith(IMAGE_EXT)
        return kind == "files"
    if kind == "text":
        return clip.kind == "text"
    if kind == "link":
        return seen == "link"
    return seen == kind


# ---------------------------------------------------------------- 入力欄


@dataclass
class SearchBox:
    """1 行の入力欄。caret と選択（anchor〜caret）を持つ。"""

    text: str = ""
    caret: int = 0
    anchor: int | None = None

    def selection(self) -> tuple[int, int] | None:
        if self.anchor is None or self.anchor == self.caret:
            return None
        return (min(self.anchor, self.caret), max(self.anchor, self.caret))

    def _drop_selection(self) -> bool:
        sel = self.selection()
        if sel is None:
            self.anchor = None
            return False
        a, b = sel
        self.text = self.text[:a] + self.text[b:]
        self.caret = a
        self.anchor = None
        return True

    def insert(self, s: str) -> None:
        s = s.replace("\r", " ").replace("\n", " ").replace("\t", " ")
        self._drop_selection()
        self.text = self.text[:self.caret] + s + self.text[self.caret:]
        self.caret += len(s)

    def _word_left(self, i: int) -> int:
        while i > 0 and self.text[i - 1].isspace():
            i -= 1
        while i > 0 and not self.text[i - 1].isspace():
            i -= 1
        return i

    def _word_right(self, i: int) -> int:
        n = len(self.text)
        while i < n and not self.text[i].isspace():
            i += 1
        while i < n and self.text[i].isspace():
            i += 1
        return i

    def backspace(self, word: bool = False) -> None:
        if self._drop_selection() or self.caret == 0:
            return
        start = self._word_left(self.caret) if word else self.caret - 1
        self.text = self.text[:start] + self.text[self.caret:]
        self.caret = start

    def delete(self, word: bool = False) -> None:
        if self._drop_selection() or self.caret >= len(self.text):
            return
        end = self._word_right(self.caret) if word else self.caret + 1
        self.text = self.text[:self.caret] + self.text[end:]

    def move(self, to: int, shift: bool) -> None:
        to = max(0, min(len(self.text), to))
        if shift:
            if self.anchor is None:
                self.anchor = self.caret
        else:
            self.anchor = None
        self.caret = to

    def left(self, shift: bool = False, word: bool = False) -> None:
        sel = self.selection()
        if sel and not shift:
            self.move(sel[0], False)
            return
        to = self._word_left(self.caret) if word else self.caret - 1
        self.move(to, shift)

    def right(self, shift: bool = False, word: bool = False) -> None:
        sel = self.selection()
        if sel and not shift:
            self.move(sel[1], False)
            return
        to = self._word_right(self.caret) if word else self.caret + 1
        self.move(to, shift)

    def select_all(self) -> None:
        self.anchor = 0
        self.caret = len(self.text)

    def clear(self) -> None:
        self.text = ""
        self.caret = 0
        self.anchor = None


# ---------------------------------------------------------------- 窓の中身


@dataclass
class Tab:
    gid: int
    name: str
    count: int = 0
    hotkey: str = ""


@dataclass
class Command:
    """窓が行うこと。kind で分ける。

    paste / copy / close / delete / undo / pin / group_menu / move /
    edit / open / menu / reorder / settings / new_group
    """

    kind: str
    ids: list[int] = field(default_factory=list)
    plain: bool = False
    transform: str = ""
    group_id: int = 0
    delta: int = 0
    index: int = -1


REPAINT = Command("repaint")


class PopupModel:
    """タブ・一覧・選択・検索・取り消しを持つ。"""

    def __init__(self, load_tabs: Callable[[], list[Tab]],
                 load_items: Callable[[int], list[Clip]]) -> None:
        self._load_tabs = load_tabs
        self._load_items = load_items
        self.tabs: list[Tab] = []
        self.tab = 0
        self.items: list[Clip] = []
        self.view: list[Clip] = []
        self.sel = 0
        self.multi: list[int] = []        # 選んだ順（まとめて貼る順）
        self._range_from: int | None = None
        self.top = 0                      # 一番上に見えている行
        self.page = 8                     # 一度に見える行数（描く側が決める）
        self.search = SearchBox()
        self.kind = "all"
        self.undo: list[list[dict]] = []
        self.note = ""
        self.note_until = 0.0
        self.click_to_paste = True
        self._hay: dict[int, str] = {}

    # ------------------------------------------------------------ 読み込み

    @property
    def gid(self) -> int:
        return self.tabs[self.tab].gid if self.tabs else HISTORY

    def reload(self, *, keep: bool = True) -> None:
        """タブと一覧を読み直す。選んでいた項目はなるべくそのまま。"""
        current = self.current()
        keep_id = current.id if (keep and current) else None
        gid = self.gid
        self.tabs = self._load_tabs() or [Tab(HISTORY, "")]
        ids = [t.gid for t in self.tabs]
        self.tab = ids.index(gid) if gid in ids else min(
            self.tab, len(self.tabs) - 1)
        self.items = self._load_items(self.gid)
        self._hay = {}
        alive = {c.id for c in self.items}
        self.multi = [i for i in self.multi if i in alive]
        self._filter(keep_id)

    def _haystack(self, clip: Clip) -> str:
        hay = self._hay.get(clip.id)
        if hay is None:
            body = "" if clip.secret else clip.snippet
            hay = norm("\n".join([clip.title, body, clip.app,
                                  " ".join(clip.files)]))
            self._hay[clip.id] = hay
        return hay

    def _filter(self, keep_id: int | None = None) -> None:
        words = norm(self.search.text).split()
        out = []
        for clip in self.items:
            if not matches_kind(clip, self.kind):
                continue
            if words:
                hay = self._haystack(clip)
                if not all(w in hay for w in words):
                    continue
            out.append(clip)
        self.view = out
        if keep_id is not None:
            for i, clip in enumerate(out):
                if clip.id == keep_id:
                    self.sel = i
                    break
            else:
                self.sel = min(self.sel, max(0, len(out) - 1))
        else:
            self.sel = 0
        self._scroll_to_sel()

    def open(self, tab_gid: int | None = None) -> None:
        """窓を開くときに呼ぶ。検索と選択は新しくする。"""
        self.search.clear()
        self.kind = "all"
        self.multi = []
        self._range_from = None
        self.sel = 0
        self.top = 0
        self.note = ""
        self.tabs = self._load_tabs() or [Tab(HISTORY, "")]
        self.tab = 0
        if tab_gid is not None:
            for i, t in enumerate(self.tabs):
                if t.gid == tab_gid:
                    self.tab = i
        self.items = self._load_items(self.gid)
        self._hay = {}
        self._filter()

    def current(self) -> Clip | None:
        if 0 <= self.sel < len(self.view):
            return self.view[self.sel]
        return None

    def chosen(self) -> list[int]:
        """貼る・消すなどの相手。まとめて選んでいればそれ、なければ今の行。"""
        if self.multi:
            return list(self.multi)
        clip = self.current()
        return [clip.id] if clip else []

    def say(self, text: str, seconds: float = 2.5) -> None:
        self.note = text
        self.note_until = time.monotonic() + seconds

    def note_now(self) -> str:
        if self.note and time.monotonic() < self.note_until:
            return self.note
        return ""

    # ------------------------------------------------------------ 動かす

    def _scroll_to_sel(self) -> None:
        page = max(1, self.page)
        if self.sel < self.top:
            self.top = self.sel
        elif self.sel >= self.top + page:
            self.top = self.sel - page + 1
        self.top = max(0, min(self.top, max(0, len(self.view) - page)))

    def select(self, index: int, *, shift: bool = False) -> None:
        if not self.view:
            self.sel = 0
            return
        index = max(0, min(len(self.view) - 1, index))
        if shift:
            if self._range_from is None:
                self._range_from = self.sel
                first = self.view[self.sel].id
                if first not in self.multi:
                    self.multi.append(first)
            a, b = sorted((self._range_from, index))
            for clip in self.view[a:b + 1]:
                if clip.id not in self.multi:
                    self.multi.append(clip.id)
        else:
            self._range_from = None
        self.sel = index
        self._scroll_to_sel()

    def scroll(self, rows: int) -> None:
        page = max(1, self.page)
        self.top = max(0, min(self.top + rows,
                              max(0, len(self.view) - page)))

    def set_tab(self, index: int) -> None:
        if not self.tabs:
            return
        self.tab = index % len(self.tabs)
        self.items = self._load_items(self.gid)
        self._hay = {}
        self.multi = []
        self._range_from = None
        self.top = 0
        self._filter()

    def next_tab(self, step: int = 1) -> None:
        self.set_tab(self.tab + step)

    def cycle_kind(self) -> str:
        i = KIND_FILTERS.index(self.kind) if self.kind in KIND_FILTERS else 0
        self.kind = KIND_FILTERS[(i + 1) % len(KIND_FILTERS)]
        self._filter()
        return self.kind

    def set_kind(self, kind: str) -> None:
        self.kind = kind if kind in KIND_FILTERS + _EXTRA_KINDS else "all"
        self._filter()

    def toggle_multi(self, index: int) -> None:
        if not 0 <= index < len(self.view):
            return
        clip_id = self.view[index].id
        # まとめて貼る順は、Ctrl を押して選んだ順にする（貼る列）
        if clip_id in self.multi:
            self.multi.remove(clip_id)
        else:
            self.multi.append(clip_id)
        self.sel = index
        self._range_from = None

    # ------------------------------------------------------------ キー

    def key(self, vk: int, *, ctrl: bool = False, shift: bool = False,
            alt: bool = False) -> Command | None:
        """キーが押された。何もしないときは None。"""
        s = self.search
        if vk == VK_ESCAPE:
            if s.text:
                s.clear()
                self._filter()
                return REPAINT
            if self.multi:
                self.multi = []
                return REPAINT
            return Command("close")
        if vk == VK_RETURN:
            ids = self.chosen()
            if not ids:
                return None
            if ctrl:
                return Command("copy", ids, plain=shift)
            return Command("paste", ids, plain=shift)
        if vk == VK_UP:
            if ctrl and shift:
                return self._reorder(-1)
            self.select(self.sel - 1, shift=shift)
            return REPAINT
        if vk == VK_DOWN:
            if ctrl and shift:
                return self._reorder(+1)
            self.select(self.sel + 1, shift=shift)
            return REPAINT
        if vk == VK_PRIOR:
            self.select(self.sel - max(1, self.page - 1), shift=shift)
            return REPAINT
        if vk == VK_NEXT:
            self.select(self.sel + max(1, self.page - 1), shift=shift)
            return REPAINT
        if vk in (VK_HOME, VK_END):
            if ctrl or not s.text:
                self.select(0 if vk == VK_HOME else len(self.view) - 1,
                            shift=shift)
            else:
                s.move(0 if vk == VK_HOME else len(s.text), shift)
            return REPAINT
        if vk == VK_TAB:
            self.next_tab(-1 if shift else 1)
            return REPAINT
        if vk in (VK_LEFT, VK_RIGHT):
            if not s.text and not shift and not ctrl:
                self.next_tab(-1 if vk == VK_LEFT else 1)
            elif vk == VK_LEFT:
                s.left(shift, ctrl)
            else:
                s.right(shift, ctrl)
            return REPAINT
        if vk == VK_BACK:
            if s.text:
                s.backspace(word=ctrl)
                self._filter()
            return REPAINT
        if vk == VK_DELETE:
            if s.text and (s.selection() or s.caret < len(s.text)):
                s.delete(word=ctrl)
                self._filter()
                return REPAINT
            ids = self.chosen()
            return Command("delete", ids) if ids else None
        if vk == VK_APPS or (vk == VK_F10 and shift):
            return Command("menu", self.chosen(), index=self.sel)
        if vk == VK_F2:
            return Command("edit", self.chosen()[:1])
        if ctrl and not alt:
            letter = chr(vk) if 0x30 <= vk <= 0x5A else ""
            if letter in "123456789" and letter:
                index = int(letter) - 1
                if index < len(self.view):
                    return Command("paste", [self.view[index].id],
                                   plain=shift)
                return None
            if letter == "A":
                if s.text:
                    s.select_all()
                else:
                    self.multi = [c.id for c in self.view]
                return REPAINT
            if letter == "Z":
                return Command("undo")
            if letter == "P":
                return Command("pin", self.chosen())
            if letter == "G" or letter == "M":
                return Command("group_menu", self.chosen(), index=self.sel)
            if letter == "E":
                return Command("edit", self.chosen()[:1])
            if letter == "C":
                ids = self.chosen()
                return Command("copy", ids, plain=shift) if ids else None
            if letter == "O":
                return Command("open", self.chosen()[:1])
            if letter == "T":
                self.cycle_kind()
                return REPAINT
            if letter == "F":
                s.select_all()
                return REPAINT
            if letter == "V":
                return Command("search_paste")
        return None

    def _reorder(self, delta: int) -> Command | None:
        clip = self.current()
        if clip is None or self.gid <= HISTORY:      # 履歴・ダウンロード
            return None
        return Command("reorder", [clip.id], delta=delta)

    def char(self, ch: str) -> bool:
        """文字が打たれた（IME の確定も含む）。検索欄に入れる。"""
        if not ch or ord(ch[0]) < 0x20 or ch == "\x7f":
            return False
        self.search.insert(ch)
        self.multi = []
        self._filter()
        return True

    def paste_into_search(self, text: str) -> None:
        self.search.insert(text.splitlines()[0] if text else "")
        self._filter()

    # ------------------------------------------------------------ マウス

    def click(self, index: int, *, ctrl: bool = False,
              shift: bool = False) -> Command | None:
        if not 0 <= index < len(self.view):
            return None
        if ctrl:
            self.toggle_multi(index)
            return REPAINT
        if shift:
            self.select(index, shift=True)
            return REPAINT
        self.select(index)
        clicked = self.view[index].id
        if self.multi and clicked not in self.multi:
            # まとめて選んだ仲間でない行を押した＝その行を使いたい。
            # 前は、選んであった別の項目がまとめて貼られていた
            self.multi = []
        if self.click_to_paste and not self.multi:
            return Command("paste", [clicked])
        if self.click_to_paste and self.multi:
            return Command("paste", list(self.multi))
        return REPAINT

    def double_click(self, index: int) -> Command | None:
        if not 0 <= index < len(self.view):
            return None
        self.select(index)
        if self.click_to_paste:
            return None          # 1 回目のクリックで貼ってある
        return Command("paste", self.chosen())

    # ------------------------------------------------------------ 取り消し

    def remember_deleted(self, rows: list[dict]) -> None:
        if rows:
            self.undo.append(rows)
            del self.undo[:-20]

    def pop_undo(self) -> list[dict]:
        return self.undo.pop() if self.undo else []


# ---------------------------------------------------------------- 貼る前の加工


def _is_wide(ch: str) -> bool:
    return unicodedata.east_asian_width(ch) in ("W", "F")


def transform(text: str, how: str) -> str:
    """「変換して貼る」の中身。how が知らない名前なら、そのまま返す。"""
    if how == "trim":
        lines = [line.rstrip() for line in text.splitlines()]
        return "\n".join(lines).strip()
    if how == "oneline":
        # 和文どうしの改行はつなぐだけ、英文の改行は空白にする
        parts = [p.strip() for p in text.splitlines() if p.strip()]
        out = ""
        for p in parts:
            if out and not (_is_wide(out[-1]) and _is_wide(p[0])):
                out += " "
            out += p
        return out
    if how == "half":
        out = []
        for ch in text:
            code = ord(ch)
            if 0xFF01 <= code <= 0xFF5E:
                out.append(chr(code - 0xFEE0))
            elif code == 0x3000:
                out.append(" ")
            else:
                out.append(ch)
        return "".join(out)
    if how == "full":
        out = []
        for ch in text:
            code = ord(ch)
            if 0x21 <= code <= 0x7E:
                out.append(chr(code + 0xFEE0))
            elif ch == " ":
                out.append("　")
            else:
                out.append(ch)
        return "".join(out)
    if how == "upper":
        return text.upper()
    if how == "lower":
        return text.lower()
    if how == "quote":
        return "\n".join("> " + line for line in text.splitlines())
    return text


TRANSFORMS = ("trim", "oneline", "half", "full", "upper", "lower", "quote")


_VAR = re.compile(r"\{(date|time|datetime|weekday|clipboard)"
                  r"(?::([^{}]*))?\}")


def expand(text: str, *, clipboard: str = "",
           now: float | None = None) -> str:
    """グループの言葉の中の {date} などを、貼るときの値に置き換える。

    {date} 2026/10/11 ・ {time} 14:05 ・ {datetime} 2026/10/11 14:05 ・
    {weekday} 日 ・ {clipboard} いまのクリップボードの文字 ・
    {date:%Y-%m-%d} のように書き方も選べる。{{ と }} は { と } のまま。
    """
    stamp = time.localtime(now if now is not None else time.time())
    days = "月火水木金土日"

    def one(m: re.Match[str]) -> str:
        name, spec = m.group(1), m.group(2)
        if name == "clipboard":
            return clipboard
        if spec:
            try:
                return time.strftime(spec, stamp)
            except ValueError:
                return m.group(0)
        if name == "date":
            return time.strftime("%Y/%m/%d", stamp)
        if name == "time":
            return time.strftime("%H:%M", stamp)
        if name == "datetime":
            return time.strftime("%Y/%m/%d %H:%M", stamp)
        return days[stamp.tm_wday]

    marker_l, marker_r = "\x00L", "\x00R"
    text = text.replace("{{", marker_l).replace("}}", marker_r)
    text = _VAR.sub(one, text)
    return text.replace(marker_l, "{").replace(marker_r, "}")
