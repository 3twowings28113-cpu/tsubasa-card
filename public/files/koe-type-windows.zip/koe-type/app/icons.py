"""トレイやウィンドウで使うアイコン。

2026-10-26 に全面リデザインした。旧アイコン（マイク＋万年筆＋発光
プラス＋星）は細部が多く、トレイの 16〜20px では潰れて判別でき
なかった。新デザインは「濃色の角丸スクエア＋白抜きの太いシルエット」
で、小さいサイズでも読めることを最優先にした。
`python tools\\make_icons.py` で再現・再生成できる。

  ふだん（待機中） … オレンジの地に白マイク
  録音中           … 赤の地に白マイク（地の色で区別）
  文字起こし中     … オレンジの地に白の音波バー（輪郭で区別）

  待機・文字起こし中の地は当初 紺 #242460 だったが、暗いトレイ
  背景に同化して見分けづらいという本人の指摘で、鮮やかな
  オレンジ #FF8A00 に変えた（2026-10-26）。
"""

from __future__ import annotations

import logging
from pathlib import Path

from .util import ROOT

log = logging.getLogger(__name__)

ICON_DIR = ROOT / "assets" / "icon"
PNG_DIR = ICON_DIR / "png"

ORANGE = "#FF8A00"
RED = "#E0483A"

# トレイの状態 -> .ico
STATE_FILES = {
    "idle": "koe-type-idle.ico",
    "recording": "koe-type-recording.ico",
    "transcribing": "koe-type-transcribing.ico",
}


def ico_path(state: str = "idle") -> Path:
    return ICON_DIR / STATE_FILES.get(state, STATE_FILES["idle"])


def png_path(state: str = "idle", size: int = 32) -> Path:
    name = state if state in ("recording", "transcribing") else "idle"
    return PNG_DIR / f"{name}-{size}.png"


def ensure_icons(_unused_dir: Path | None = None) -> dict[str, Path]:
    """トレイが使う .ico の場所を返す。足りなければ警告を出す。"""
    found: dict[str, Path] = {}
    for state in ("idle", "recording", "transcribing"):
        path = ico_path(state)
        if path.exists():
            found[state] = path
        else:
            log.error("アイコンが見つかりません: %s "
                      "（python tools\\make_icons.py で作れます）", path)
    return found
