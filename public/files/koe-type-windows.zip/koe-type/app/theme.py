"""配色。Windows のライト／ダーク設定に合わせる。

紫系グラデーションや光るボタンのような「AIアプリらしい」記号は使わない。
地の色・文字・細い罫線・1色のアクセント（くすんだ青）だけで構成する。
"""

from __future__ import annotations

import ctypes
import logging
import winreg
from ctypes import wintypes

log = logging.getLogger(__name__)

DARK = {
    "bg": "#17191d",          # 本体の地
    "bg_alt": "#1e2126",      # 行の地（交互・ホバー）
    "side": "#101216",        # 左のカテゴリ列
    "card": "#1b1e23",
    "line": "#2b2f36",        # 罫線
    "fg": "#e3e5e9",          # 本文
    "dim": "#8b9199",         # 補足
    "faint": "#5d646d",       # さらに薄い
    "accent": "#5b8cc8",      # 選択・オン
    "accent_fg": "#ffffff",
    "field": "#222630",       # 入力欄
    "field_line": "#39404a",
    "warn": "#c89a3a",
    "danger": "#c4635d",
    "ok": "#6a9a70",
    "sel": "#28303c",
}

LIGHT = {
    "bg": "#ffffff",
    "bg_alt": "#f6f7f9",
    "side": "#f1f2f5",
    "card": "#fbfbfc",
    "line": "#dfe2e7",
    "fg": "#1b1e23",
    "dim": "#5f666f",
    "faint": "#8b919a",
    "accent": "#2f6cc0",
    "accent_fg": "#ffffff",
    "field": "#ffffff",
    "field_line": "#c6cbd3",
    "warn": "#8a6410",
    "danger": "#a83c35",
    "ok": "#2f6b3a",
    "sel": "#e3ecf9",
}

UI_FONT = "Yu Gothic UI"
MONO_FONT = "Consolas"


def windows_prefers_dark() -> bool:
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize")
        with key:
            return not bool(winreg.QueryValueEx(key, "AppsUseLightTheme")[0])
    except OSError:
        return False


def accent_color() -> str:
    """Windows のアクセント色（#RRGGBB）。白文字が読める明るさに収めて返す。"""
    raw = None
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Software\Microsoft\Windows\DWM") as key:
            # ColorizationColor は AARRGGBB
            raw = int(winreg.QueryValueEx(key, "ColorizationColor")[0]) & 0xFFFFFF
    except OSError:
        pass
    if raw is None:
        return "#0f6cbd"
    r, g, b = (raw >> 16) & 0xFF, (raw >> 8) & 0xFF, raw & 0xFF
    # 白文字が乗るので、明るすぎる色は少し暗くする
    lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255
    if lum > 0.55:
        factor = 0.55 / lum
        r, g, b = (int(c * factor) for c in (r, g, b))
    return f"#{r:02x}{g:02x}{b:02x}"


def resolve(setting: str) -> str:
    """"system" / "light" / "dark" -> "light" or "dark"."""
    setting = str(setting or "system").lower()
    if setting in ("light", "dark"):
        return setting
    return "dark" if windows_prefers_dark() else "light"


def palette(setting: str) -> dict[str, str]:
    return DARK if resolve(setting) == "dark" else LIGHT


# ---------------------------------------------------------------- 窓枠の色

DWMWA_USE_IMMERSIVE_DARK_MODE = 20
DWMWA_WINDOW_CORNER_PREFERENCE = 33
DWMWA_CORNER_ROUND = 2

_dwm = ctypes.WinDLL("dwmapi")


def apply_window_chrome(hwnd: int, dark: bool, *, rounded: bool = True) -> None:
    """タイトルバーをダーク／ライトに合わせ、角を丸める（Windows 11）。"""
    try:
        flag = ctypes.c_int(1 if dark else 0)
        _dwm.DwmSetWindowAttribute(wintypes.HWND(hwnd),
                                   DWMWA_USE_IMMERSIVE_DARK_MODE,
                                   ctypes.byref(flag), ctypes.sizeof(flag))
    except Exception:
        log.debug("タイトルバーの色を変えられませんでした", exc_info=True)
    if rounded:
        try:
            pref = ctypes.c_int(DWMWA_CORNER_ROUND)
            _dwm.DwmSetWindowAttribute(wintypes.HWND(hwnd),
                                       DWMWA_WINDOW_CORNER_PREFERENCE,
                                       ctypes.byref(pref), ctypes.sizeof(pref))
        except Exception:
            pass
