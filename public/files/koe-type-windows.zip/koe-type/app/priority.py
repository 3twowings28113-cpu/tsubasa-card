"""他のアプリの邪魔をしないための、処理の優先度の調整。

きっかけ：利用者の PC で、別の音声入力（Handy）が急に重くなった。
原因のひとつは、こちらの重い処理が内蔵 GPU と CPU を取り合っていたこと。

決め事
  ・**待機中は控えめ**（優先度を下げる）。使っていない時に居ても
    気づかれないのが、常駐アプリのあるべき姿。
  ・**録音中だけ普通に戻す**（話す速さについていく必要がある）。
  ・優先度を「上げる」ことはしない。他のアプリを押しのけてまで
    速くするのは、道具としてやりすぎ。
  ・OS 標準の kernel32 だけを使う（新しい依存は増やさない）。
"""

from __future__ import annotations

import ctypes
import logging
from ctypes import wintypes

log = logging.getLogger(__name__)

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

# プロセスの優先度
NORMAL_PRIORITY_CLASS = 0x00000020
BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
# 「バックグラウンド」モード。CPU だけでなく I/O も控えめになる。
PROCESS_MODE_BACKGROUND_BEGIN = 0x00100000
PROCESS_MODE_BACKGROUND_END = 0x00200000

kernel32.SetPriorityClass.argtypes = [wintypes.HANDLE, wintypes.DWORD]
kernel32.SetPriorityClass.restype = wintypes.BOOL
kernel32.GetPriorityClass.argtypes = [wintypes.HANDLE]
kernel32.GetPriorityClass.restype = wintypes.DWORD
kernel32.GetCurrentProcess.restype = wintypes.HANDLE

_state = ""          # "" / "idle" / "busy"


def _set(value: int, label: str) -> bool:
    handle = kernel32.GetCurrentProcess()
    if kernel32.SetPriorityClass(handle, value):
        return True
    log.debug("優先度を %s にできませんでした err=%s", label,
              ctypes.get_last_error())
    return False


def idle() -> None:
    """待機中。控えめにする。"""
    global _state
    if _state == "idle":
        return
    # バックグラウンドモードを抜けてから下げる（入れ替えの順番が要る）
    _set(PROCESS_MODE_BACKGROUND_END, "通常")
    if _set(BELOW_NORMAL_PRIORITY_CLASS, "控えめ"):
        _state = "idle"
        log.debug("待機中なので優先度を下げました")


def busy() -> None:
    """録音・文字起こし中。普通の優先度に戻す。"""
    global _state
    if _state == "busy":
        return
    _set(PROCESS_MODE_BACKGROUND_END, "通常")
    if _set(NORMAL_PRIORITY_CLASS, "通常"):
        _state = "busy"
        log.debug("録音中なので優先度を通常に戻しました")


def current() -> str:
    return _state


def describe() -> str:
    value = kernel32.GetPriorityClass(kernel32.GetCurrentProcess())
    return {NORMAL_PRIORITY_CLASS: "通常",
            BELOW_NORMAL_PRIORITY_CLASS: "控えめ"}.get(value, f"0x{value:x}")
