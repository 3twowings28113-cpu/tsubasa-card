"""音声認識エンジンの呼び出し。

2 つの方式がある。

**常駐（既定）** `transcribe.dll` を ctypes で読み、モデルをメモリに
置いたまま何度でも使う。1 回あたり 0.6 秒かかっていたプロセス起動と
モデル読み込みの固定費がなくなるので、この PC では SenseVoice Small が
0.62 秒 → 0.12 秒になった。PCM をそのまま渡せるので、
一時 WAV を書く手間もない。

**外部プロセス** catalog.py の argv をそのまま起動する。
認識結果は必ず標準出力に出る（診断ログは標準エラー）ので stdout だけを読む。
常駐方式が使えない PC（DLL が読めない等）の受け皿。

`build()` は常駐方式を先に試し、だめなら外部プロセスへ自動で落ちる。
"""

from __future__ import annotations

import logging
import re
import subprocess
import tempfile
import time
import wave
from pathlib import Path

from . import catalog, resident, speechworker
from .resident import SAMPLE_RATE
from .catalog import Model
from .util import BIN_DIR, MODEL_DIR, ROOT

log = logging.getLogger(__name__)

CREATE_NO_WINDOW = 0x08000000
_TAG = re.compile(r"<\|[^|]{0,40}\|>")


class EngineError(RuntimeError):
    pass


class Engine:
    def __init__(self, spec: Model, *, language: str = "ja",
                 backend: str = "") -> None:
        self.spec = spec
        self.name = spec.key
        self.language = language
        self.backend = backend or str(spec.extra.get("backend", "cpu"))
        missing = catalog.missing_assets(spec.key)
        if missing:
            names = ", ".join(a.name for a in missing)
            raise EngineError(f"ファイルが足りません: {names}")

    def _expand(self, token: str, wav: str, hints: str) -> str:
        return (token
                .replace("{bin}", str(BIN_DIR))
                .replace("{models}", str(MODEL_DIR))
                .replace("{root}", str(ROOT))
                .replace("{backend}", self.backend)
                .replace("{language}", self.language)
                .replace("{hints}", hints)
                .replace("{wav}", wav))

    def transcribe(self, wav_path: Path, hints: str = "") -> str:
        args = [self._expand(a, str(wav_path), hints) for a in self.spec.argv]
        t0 = time.perf_counter()
        try:
            proc = subprocess.run(
                args, capture_output=True, cwd=str(ROOT), timeout=180,
                creationflags=CREATE_NO_WINDOW,
            )
        except FileNotFoundError as exc:
            raise EngineError(f"実行ファイルが見つかりません: {args[0]}") from exc
        except subprocess.TimeoutExpired:
            raise EngineError("文字起こしが時間内に終わりませんでした") from None
        except OSError as exc:
            raise EngineError(f"実行できませんでした: {exc}") from exc
        dt = time.perf_counter() - t0
        text = proc.stdout.decode("utf-8", "replace").strip()
        if not text:
            tail = proc.stderr.decode("utf-8", "replace").strip()[-400:]
            if proc.returncode != 0:
                raise EngineError(
                    f"エンジンが異常終了しました (rc={proc.returncode}): {tail}")
            log.info("認識結果が空でした (%.2fs)", dt)
            return ""
        log.info("認識 %.2fs (%s): %s", dt, self.name,
                 text.replace("\n", " ")[:200])
        return text

    # ---------------------------------------------------------- 共通の入口

    @property
    def resident(self) -> bool:
        return False

    @property
    def ready(self) -> bool:
        return True

    def transcribe_pcm(self, pcm: bytes, hints: str = "") -> str:
        """PCM を文字にする。外部プロセス方式は一時 WAV を経由する。"""
        wav = temp_wav()
        try:
            write_wav(wav, pcm)
            return self.transcribe(wav, hints)
        finally:
            wav.unlink(missing_ok=True)

    def warmup(self) -> None:
        wav = temp_wav()
        try:
            write_wav(wav, b"\x00" * 16000)
            t0 = time.perf_counter()
            self.transcribe(wav)
            log.info("ウォームアップ完了 %.2fs", time.perf_counter() - t0)
        except Exception as exc:
            log.warning("ウォームアップに失敗: %s", exc)
        finally:
            wav.unlink(missing_ok=True)

    def close(self) -> None:
        pass


class ResidentEngine:
    """モデルをメモリに置いたまま使うエンジン。

    Engine と同じ呼び方ができるようにしてある。
    """

    def __init__(self, spec: Model, *, language: str = "ja",
                 n_threads: int = 0) -> None:
        self.spec = spec
        self.name = spec.key
        self.language = language
        path = catalog.resident_file(spec.key)
        if path is None or not path.is_file():
            raise EngineError(
                f"モデルのファイルがありません: {spec.extra.get('file', '?')}")
        backend = str(spec.extra.get("backend", "vulkan"))
        self._core = resident.Resident(path, backend=backend,
                                       language=language,
                                       n_threads=n_threads)

    @property
    def resident(self) -> bool:
        return True

    @property
    def session(self):  # noqa: ANN201
        """常駐セッション。Whisper で直接翻訳するときに使う。"""
        return getattr(self._core, "session", None)

    @property
    def ready(self) -> bool:
        return self._core.ready

    @property
    def average_seconds(self) -> float:
        return self._core.average_seconds

    @property
    def last_seconds(self) -> float:
        return self._core.last_seconds

    def load_async(self) -> None:
        self._core.load_async()

    @property
    def best_seconds(self) -> float:
        """このモデルが安心して扱える音の長さ。"""
        return float(self.spec.extra.get("best_seconds", 30))

    def transcribe_pcm(self, pcm: bytes, hints: str = "",
                       _depth: int = 0) -> str:
        """PCM を文字にする。中身が取れなかったら半分に割ってやり直す。

        SenseVoice は長い音が苦手で、11 秒を超えたあたりから
        記号しか返さなくなることがある（FLEURS 日本語 200 本のうち 22 本）。
        そのまま捨てると**話した内容がまるごと消える**ので、
        半分に割って聞き直し、つなぎ直す。
        """
        vocab = _hint_list(hints) if self.spec.supports_hints else None
        try:
            text = self._core.transcribe_pcm(pcm, vocabulary=vocab)
        except resident.ResidentError as exc:
            raise EngineError(str(exc)) from exc

        seconds = len(pcm) / (SAMPLE_RATE * 2)

        # 空が返ってきたら、長さをほんの少し変えてもう一度聞く。
        # 同じ音でも長さが少し違うだけで結果が出ることがある
        # （実際の利用で 47 回、聞こえていたのに空が返っていた）。
        # 1 回 0.07 秒なので、やり直しても遅くならない。
        # 下限は 0.3 秒: 「ピーシー」のような短い単独発話（約 0.5 秒）が
        # 空で返ると、以前は聞き直しが無く丸ごと消えていた（2026-10-26
        # 監査）。0.3 秒未満は物音の可能性が高いので従来どおり対象外。
        if not text.strip() and _depth == 0 and seconds >= 0.3:
            pad = bytes(SAMPLE_RATE * 2 // 5)      # 0.2 秒の無音
            for extra in (pad, pad + pad):
                try:
                    again = self._core.transcribe_pcm(pcm + extra,
                                                      vocabulary=vocab)
                except resident.ResidentError:
                    break
                if again.strip():
                    if _has_substance(again):
                        log.info("空だったので聞き直したら取れました: %s",
                                 again[:60])
                        return again
                    # 記号だけ取れた。それを成功扱いで打ち切らず、
                    # 下の分割救済へ回す（短い音ならそのまま返る）。
                    text = again
                    break
        if (_has_substance(text) or _depth >= 2 or seconds < 4.0
                or seconds <= self.best_seconds * 0.8):
            return text

        # 長い音で中身が返ってこなかった（空、または記号だけ）。
        # ★以前は「空かどうか」だけで判定していたため、記号列は
        # 非空として成功扱いになり、想定した故障そのものを救済が
        # 素通りしていた（2026-10-31 監査 H3）。真ん中で割って
        # 聞き直す。
        log.warning("%.1f 秒の音で中身が取れなかったので、半分に割って"
                    "聞き直します（%d 回目）: %r",
                    seconds, _depth + 1, text[:40])
        half = (len(pcm) // 2) & ~1              # 偶数バイトに丸める
        # 真ん中で言葉が切れないよう、少しだけ重ねる
        overlap = min(SAMPLE_RATE * 2 // 2, half // 4)
        first = self.transcribe_pcm(pcm[:half + overlap], hints, _depth + 1)
        second = self.transcribe_pcm(pcm[half:], hints, _depth + 1)
        joined = _join(first, second)
        if joined:
            log.info("割って聞き直したら取れました: %s", joined[:80])
        return joined

    def transcribe(self, wav_path: Path, hints: str = "") -> str:
        """WAV から。評価用の道具がこちらを呼ぶので残してある。"""
        with wave.open(str(wav_path)) as w:
            pcm = w.readframes(w.getnframes())
        return self.transcribe_pcm(pcm, hints)

    def warmup(self) -> None:
        # 区切りの最長（モデルが得意な長さ。上限 10 秒）ぶんを先に用意する
        self._core.warmup(long_seconds=min(self.best_seconds, 10.0))

    def close(self) -> None:
        self._core.unload()


class SpeechWorkerEngine(ResidentEngine):
    """speech.cpp の worker 常駐で動かすエンジン。

    transcribe.dll では読めないモデル（Haas など）のための常駐方式。
    聞き直し・分割救済の判断は ResidentEngine のものをそのまま使う。
    """

    def __init__(self, spec: Model, *, language: str = "ja",
                 n_threads: int = 0) -> None:
        # super().__init__ は transcribe.dll 前提なので呼ばない。
        # ResidentEngine のメソッドが触る属性だけを用意する。
        # n_threads は worker 側の既定に任せる（フラグを足さない）。
        self.spec = spec
        self.name = spec.key
        self.language = language
        path = catalog.resident_file(spec.key)
        if path is None or not path.is_file():
            raise EngineError(
                f"モデルのファイルがありません: "
                f"{spec.extra.get('file', '?')}")
        try:
            command = speechworker.default_command(path)
        except speechworker.SpeechWorkerError as exc:
            raise EngineError(str(exc)) from exc
        self._core = speechworker.SpeechWorker(command)

def _has_substance(text: str) -> bool:
    """意味のある文字が 1 つでもあるか。

    SenseVoice の故障モードは「記号しか返らない」こと。記号列は
    strip しても空にならないので、空かどうかでは救済が発動しない。
    タグ（<|ja|> のような制御トークン）は文字として数えない。
    相槌のような正当な短い出力は仮名を含むので、ここでは弾かれず、
    分割救済の誤爆にならない。
    """
    return any(ch.isalnum() for ch in strip_tags(text))


def _join(first: str, second: str) -> str:
    """割って聞き直した 2 つを、重なりを取り除いてつなぐ。"""
    first, second = first.strip(), second.strip()
    if not first:
        return second
    if not second:
        return first
    # 後ろの頭が、前の尻と重なっていたら落とす
    for size in range(min(24, len(first), len(second)), 2, -1):
        if first.endswith(second[:size]):
            return first + second[size:]
    return first + second


def _hint_list(hints: str) -> list[str]:
    return [h.strip() for h in hints.replace("、", ",").split(",")
            if h.strip()][:48]


def build(model_key: str, language: str = "ja"):  # noqa: ANN201
    """モデルを用意する。常駐方式を先に試す。

    常駐が使えない時は、同じ中身の外部プロセス方式へ静かに落ちる。
    利用者には「使えています」という状態を保つのが大事なので、
    ここで止めない。
    """
    spec = catalog.MODELS.get(model_key)
    if spec is None:
        raise EngineError(f"モデル '{model_key}' は一覧にありません")
    if spec.extra.get("worker") == "speech":
        # speech.cpp の worker 常駐（transcribe.dll では読めない
        # モデル用）。使えなければ、従来どおり外部プロセスへ落とす。
        try:
            return SpeechWorkerEngine(spec, language=language)
        except EngineError as exc:
            log.warning("speech worker 方式が使えないので外部プロセス"
                        "に切り替えます: %s", exc)
            fallback = catalog.MODELS.get(catalog.FALLBACK_MODEL)
            if fallback is None:
                raise
            return Engine(fallback, language=language)
    if spec.extra.get("resident"):
        ok, why = resident.available()
        if ok:
            try:
                return ResidentEngine(spec, language=language)
            except EngineError as exc:
                why = str(exc)
        log.warning("常駐方式が使えないので外部プロセスに切り替えます: %s", why)
        fallback = catalog.MODELS.get(catalog.FALLBACK_MODEL)
        if fallback is None:
            raise EngineError(why)
        return Engine(fallback, language=language)
    return Engine(spec, language=language)


def write_wav(path: Path, pcm: bytes, rate: int = 16000) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm)


def temp_wav() -> Path:
    fd = tempfile.NamedTemporaryFile(prefix="koe-type-", suffix=".wav",
                                     delete=False)
    fd.close()
    return Path(fd.name)


def strip_tags(text: str) -> str:
    return _TAG.sub("", text)
