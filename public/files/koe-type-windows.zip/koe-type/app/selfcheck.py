"""動作チェック。「使える状態か」を一覧で見せ、だめな所の直し方を出す。

ほかの人に渡したとき、うまく動かない理由が自分で分かるようにするための
しくみ。設定画面の「アプリ」から開ける。コマンドからも動かせる。

    python tools/doctor.py

決め事
  ・**直し方まで書く。** 「マイクがありません」で終わらせない。
  ・調べるだけ。設定も Windows も書き換えない。
  ・キーは1回も送らない。音も鳴らさない。
  ・調べるのに時間がかかるもの（モデルの読み込み）は、そう書いておく。
"""

from __future__ import annotations

import ctypes
import logging
import os
import platform
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path

from . import catalog, resident
from .util import DATA_DIR, HOME, LOG_DIR, MODEL_DIR, ROOT, VERSION

log = logging.getLogger(__name__)

OK = "ok"             # 問題なし
WARN = "warn"         # 動くが、よくない
BAD = "bad"           # 動かない
INFO = "info"         # 参考（良し悪しではない）


@dataclass
class Result:
    key: str
    title_ja: str
    title_en: str
    status: str
    detail_ja: str = ""
    detail_en: str = ""
    fix_ja: str = ""           # 直し方
    fix_en: str = ""
    extra: dict = field(default_factory=dict)

    def as_dict(self) -> dict:
        return {
            "key": self.key, "status": self.status,
            "title": {"ja": self.title_ja, "en": self.title_en},
            "detail": {"ja": self.detail_ja, "en": self.detail_en},
            "fix": {"ja": self.fix_ja, "en": self.fix_en},
            "extra": self.extra,
        }


# ---------------------------------------------------------------- 各項目


def check_windows() -> Result:
    build = 0
    try:
        build = int(platform.version().split(".")[-1])
    except Exception:
        pass
    name = f"{platform.system()} {platform.release()} (build {build})"
    if build and build < 19041:
        return Result("windows", "Windows のバージョン", "Windows version",
                      WARN,
                      name, name,
                      "Windows 10 の 2004（build 19041）より新しいバージョンを"
                      "おすすめします。古いバージョンでは、録音中の表示が崩れることがあります。",
                      "Windows 10 2004 (build 19041) or newer is "
                      "recommended; the indicator may not draw correctly on "
                      "older builds.")
    return Result("windows", "Windows のバージョン", "Windows version",
                  OK, name, name)


def check_python() -> Result:
    """Python の版。問題がない限り画面には出さない（内部の話なので）。"""
    v = sys.version_info
    name = f"Python {v.major}.{v.minor}.{v.micro}"
    if (v.major, v.minor) < (3, 11):
        return Result("python", "Python のバージョン", "Python version", BAD,
                      name, name,
                      "Python 3.11 以上が必要です。"
                      "python.org から新しい版を入れてください。",
                      "Python 3.11 or newer is required. Install a newer "
                      "version from python.org.")
    return Result("python", "Python のバージョン", "Python version",
                  OK, name, name, extra={"advanced": True})


def check_console() -> Result:
    """黒いウィンドウが一緒に開く起動の仕方になっていないか。"""
    exe = Path(sys.executable).name.lower()
    if exe.startswith("pythonw"):
        return Result("console", "起動のしかた", "How it was started", OK,
                      "ふつうに起動しています", "Started normally",
                      extra={"advanced": True})
    return Result("console", "起動のしかた", "How it was started", INFO,
                  "黒いウィンドウが一緒に開いています",
                  "A console window is open alongside it",
                  "koe-type.pyw（または作られたショートカット）から起動すると、"
                  "黒いウィンドウは出ません。",
                  "Start it from koe-type.pyw or the created shortcut and "
                  "the console window will not appear.")


def check_microphone() -> Result:
    from .audio import devices  # noqa: PLC0415
    found = devices()
    if not found:
        return Result("mic", "マイク", "Microphone", BAD,
                      "見つかりません", "None found",
                      "マイクをつないでから、この画面を開き直してください。"
                      "つないであるのに出ない場合は、Windows の "
                      "「設定 → プライバシーとセキュリティ → マイク」で"
                      "「アプリにマイクへのアクセスを許可する」と"
                      "「デスクトップ アプリにマイクへのアクセスを許可する」"
                      "の両方をオンにしてください。",
                      "Connect a microphone and reopen this window. If one "
                      "is connected but not listed, turn on both “Let apps "
                      "access your microphone” and “Let desktop apps access "
                      "your microphone” under Settings → Privacy & security "
                      "→ Microphone.")
    def _clean_mic(name: str) -> str:
        for noise in ("(R)", "(TM)", "(C)", "®", "™"):
            name = name.replace(noise, "")
        name = " ".join(name.split()).strip()
        return name + "…" if len(name) >= 31 else name

    labels = [_clean_mic(n) for _i, n in found]
    names = "、".join(labels)
    return Result("mic", "マイク", "Microphone", OK,
                  f"{len(found)} 台: {names}",
                  f"{len(found)} found: {', '.join(labels)}",
                  extra={"devices": labels})


def check_mic_permission() -> Result:
    """マイクを実際に開けるか。許可がオフだとここで分かる。"""
    from .audio import Recorder  # noqa: PLC0415
    rec = Recorder(lambda _data: None)
    try:
        rec.preroll_ms = 200
        rec._open()
        rec._close()
    except Exception as exc:
        return Result("mic_open", "マイクの使用許可",
                      "Microphone permission", BAD,
                      f"開けません: {exc}", f"Cannot open: {exc}",
                      "Windows の「設定 → プライバシーとセキュリティ → マイク」で"
                      "「デスクトップ アプリにマイクへのアクセスを許可する」を"
                      "オンにしてください。ほかのアプリがマイクを独占している"
                      "場合も開けないことがあります。",
                      "Turn on “Let desktop apps access your microphone” "
                      "under Settings → Privacy & security → Microphone. "
                      "Another app holding the microphone exclusively can "
                      "also cause this.")
    return Result("mic_open", "マイクの使用許可", "Microphone permission", OK,
                  "開けました", "Opened successfully")


def check_resident() -> Result:
    ok, why = resident.available()
    if ok:
        folder = resident.native_dir()
        return Result("resident", "文字起こしの準備",
                      "Speech engine", OK,
                      "すぐ使える状態です", "Ready to use",
                      extra={"dir": str(folder), "advanced": True})
    return Result("resident", "文字起こしの準備", "Speech engine", WARN,
                  why, why,
                  "設定画面の「文字起こし」から、常駐エンジンを"
                  "ダウンロードしてください。なくても動きますが、"
                  "1 回ごとに 0.5 秒ほど余分にかかります"
                  "（毎回モデルを読み直すため）。",
                  "Download the always-loaded engine from the "
                  "Transcription page. koe-type still works without it, but "
                  "each phrase costs about half a second more because the "
                  "model is reloaded every time.")


def _device_name(device) -> str:  # noqa: ANN001
    """GPU の名前だけを短く取り出す。

    "Intel(R) Arc(TM) 140V GPU (16GB)" のような商標つきの長い名前を、
    画面に出せる短さにする。
    """
    text = str(getattr(device, "description", "")
               or getattr(device, "name", ""))
    for noise in ("(R)", "(TM)", "(C)", "®", "™"):
        text = text.replace(noise, "")
    return " ".join(text.split()).strip()


def check_gpu() -> Result:
    """Vulkan が使える GPU があるか。"""
    try:
        tcpp = resident.load_binding()
    except Exception:
        return Result("gpu", "GPU", "GPU", INFO,
                      "文字起こしの準備ができていないので調べられません",
                      "Cannot check until the speech engine is ready",
                      "設定画面の「文字起こし」から用意すると調べられます。",
                      "Set it up on the Transcription page to check.")
    try:
        devices = [_device_name(d) for d in tcpp.backends()]
    except Exception as exc:
        return Result("gpu", "GPU", "GPU", INFO,
                      f"調べられません: {exc}", f"Cannot check: {exc}")
    gpus = [d for d in devices if "cpu" not in d.lower()]
    if gpus:
        return Result("gpu", "GPU", "GPU", OK,
                      f"{gpus[0]} を使っています",
                      f"Using {gpus[0]}",
                      extra={"devices": devices})
    return Result("gpu", "GPU", "GPU", WARN,
                  "見つかりません（CPU で動きます）",
                  "None found — it will run on the CPU",
                  "GPU がなくても動きますが遅くなります。"
                  "「文字起こし」のページで、小さいモデル"
                  "（Moonshine Base 日本語・77MB）を選ぶと軽くなります。",
                  "It still works on the CPU, just slower. Pick the small "
                  "model (Moonshine Base Japanese, 77 MB) on the "
                  "Transcription page to lighten the load.")


def check_model(model_key: str = "") -> Result:
    key = model_key or catalog.DEFAULT_MODEL
    spec = catalog.MODELS.get(key)
    if spec is None:
        return Result("model", "モデル", "Model", BAD,
                      f"'{key}' は一覧にありません",
                      f"'{key}' is not in the catalog",
                      "「文字起こし」のページでモデルを選び直してください。",
                      "Pick a model again on the Transcription page.")
    missing = catalog.missing_assets(key)
    if missing:
        names = ", ".join(a.name for a in missing)
        return Result("model", "モデル", "Model", BAD,
                      f"{spec.name}: ファイルが足りません（{names}）",
                      f"{spec.name}: missing files ({names})",
                      "設定画面の「文字起こし」から"
                      "「ダウンロード」を押してください。"
                      "途中で止まったファイルがある場合は、"
                      "もう一度押すと取り直します。",
                      "Press Download on the Transcription page. If a "
                      "previous download stopped halfway, pressing it again "
                      "re-fetches the file.")
    # 大きさが途中で切れていないか（壊れたダウンロードの検出）
    for asset in spec.assets:
        path = catalog.asset_path(asset)
        if path.is_file() and asset.size and path.stat().st_size < asset.size * 0.9:
            return Result("model", "モデル", "Model", BAD,
                          f"{path.name} が途中までしかありません"
                          f"（{path.stat().st_size / 1e6:.0f}MB / "
                          f"{asset.size / 1e6:.0f}MB）",
                          f"{path.name} is incomplete",
                          "「文字起こし」のページで取り直してください。"
                          "途中で止まったファイルは自動で上書きされます。",
                          "Re-download it from the Transcription page; the "
                          "partial file is overwritten.")
    return Result("model", "モデル", "Model", OK,
                  f"{spec.name}（{catalog.human_size(spec.size)}）",
                  f"{spec.name} ({catalog.human_size(spec.size)})")


def check_hotkey(hotkey: str = "ctrl+space",
                 excluded: tuple[str, ...] = ()) -> Result:
    """ショートカットが、ほかのものとぶつかっていないか。

    すでに「koe-type を使わないアプリ」へ入れてあるなら、
    それは解決済みなので「参考」に下げる。直したのに警告が残り続けると、
    警告そのものを見なくなってしまうため。
    """
    from .hotkeys import conflicts, label  # noqa: PLC0415
    issues = conflicts(hotkey)
    nice = label(hotkey)
    if not issues:
        return Result("hotkey", "ショートカット", "Shortcut", OK,
                      f"{nice}（ぶつかりなし）", f"{nice} — no conflicts")
    handled = {e.lower() for e in excluded}
    if "code.exe" in handled:
        # VS Code の入力補完とのぶつかりは、除外アプリで解決済み
        issues = [i for i in issues if "VS Code" not in i[1]]
    if not issues:
        return Result("hotkey", "ショートカット", "Shortcut", OK,
                      f"{nice}（ぶつかるアプリは除外済み）",
                      f"{nice} — conflicting apps are already excluded")
    worst = max(issues, key=lambda i: i[0] == "bad")
    status = BAD if any(i[0] == "bad" for i in issues) else WARN
    return Result("hotkey", "ショートカット", "Shortcut", status,
                  f"{nice}: " + " / ".join(i[1] for i in issues),
                  f"{nice}: " + " / ".join(i[2] for i in issues),
                  worst[3], worst[4])


def check_paste() -> Result:
    """クリップボードを開けるか（貼り付けの準備）。"""
    from . import inject  # noqa: PLC0415
    snapshot = inject.snapshot_clipboard()
    if snapshot is None:
        return Result("paste", "文字の貼り付け", "Typing text", WARN,
                      "クリップボードを開けません",
                      "Cannot open the clipboard",
                      "ほかのアプリがクリップボードを握っています。"
                      "クリップボード管理アプリ（Ditto など）を使っている"
                      "場合は、一度閉じて試してください。",
                      "Another app is holding the clipboard. If you use a "
                      "clipboard manager such as Ditto, close it and retry.")
    inject.restore_clipboard(snapshot)
    return Result("paste", "文字の貼り付け", "Typing text", OK,
                  "問題ありません", "Working",
                  extra={"advanced": True})


def check_disk() -> Result:
    try:
        usage = shutil.disk_usage(str(HOME))
    except OSError as exc:
        return Result("disk", "ディスクの空き", "Free disk space", WARN,
                      str(exc), str(exc))
    free_gb = usage.free / (1024 ** 3)
    detail = f"{free_gb:.1f} GB 空いています"
    if free_gb < 1.0:
        return Result("disk", "ディスクの空き", "Free disk space", BAD,
                      detail, f"{free_gb:.1f} GB free",
                      "空きが 1GB を切っています。"
                      "履歴の音声の保存をオフにするか、"
                      "「履歴」のページで古いものを消してください。",
                      "Less than 1 GB free. Turn off keeping audio in the "
                      "history, or delete old entries on the History page.")
    if free_gb < 5.0:
        return Result("disk", "ディスクの空き", "Free disk space", WARN,
                      detail, f"{free_gb:.1f} GB free",
                      "モデルを増やすと足りなくなるかもしれません。",
                      "Adding more models may not fit.")
    return Result("disk", "ディスクの空き", "Free disk space", OK,
                  detail, f"{free_gb:.1f} GB free")


def check_folders() -> Result:
    """設定の置き場所に書けるか。OneDrive の中かどうかも見る。"""
    problems = []
    for folder in (HOME, LOG_DIR, DATA_DIR, MODEL_DIR):
        try:
            folder.mkdir(parents=True, exist_ok=True)
            probe = folder / ".koe-type-write-test"
            probe.write_text("ok", "utf-8")
            probe.unlink()
        except OSError as exc:
            problems.append(f"{folder.name}: {exc}")
    if problems:
        return Result("folders", "フォルダへの書き込み",
                      "Writing to the app folders", BAD,
                      " / ".join(problems), " / ".join(problems),
                      "フォルダが読み取り専用か、別のアプリが握っています。"
                      "`Program Files` の中に置くと書けないことがあるので、"
                      "ユーザーのフォルダ（ドキュメントなど）へ移してください。",
                      "The folder is read-only or locked by another app. "
                      "Installing under Program Files can cause this; move "
                      "koe-type somewhere under your user folder.")
    onedrive = os.environ.get("OneDrive", "")
    if onedrive and str(ROOT).lower().startswith(onedrive.lower()):
        return Result("folders", "フォルダへの書き込み",
                      "Writing to the app folders", WARN,
                      "OneDrive の中にあります", "Located inside OneDrive",
                      "OneDrive の中だと、履歴やモデルが同期されて"
                      "通信量と容量を使います。また同期の最中に"
                      "ファイルが掴まれて、保存に失敗することがあります。"
                      "OneDrive の外へ移すことをおすすめします。",
                      "Inside OneDrive the history and models get synced, "
                      "using bandwidth and space, and syncing can lock "
                      "files mid-save. Moving it outside OneDrive is "
                      "recommended.")
    return Result("folders", "設定の保存先", "Where settings are saved",
                  "ok", "書き込めます", "Writable",
                  extra={"path": str(HOME), "advanced": True})


def check_sac() -> Result:
    """Smart App Control が有効かどうか（参考）。"""
    try:
        import winreg  # noqa: PLC0415
        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Control\CI\Policy") as key:
            value, _ = winreg.QueryValueEx(
                key, "VerifiedAndReputablePolicyState")
    except Exception:
        return Result("sac", "Smart App Control", "Smart App Control", INFO,
                      "調べられません（無効と思われます）",
                      "Cannot read the setting (likely off)")
    states = {0: "無効", 1: "有効", 2: "評価中"}
    name = states.get(value, str(value))
    if value == 1:
        return Result("sac", "Smart App Control", "Smart App Control", INFO,
                      f"{name}。未署名のファイルが止められることがあります",
                      "On — unsigned files can be blocked",
                      "koe-type 自体は OS 標準の DLL しか使わないので"
                      "止まりません。文字起こしのエンジンが止められた場合は、"
                      "この画面の「常駐エンジン」に出ます。",
                      "koe-type itself only calls DLLs that ship with "
                      "Windows, so it is unaffected. If the speech engine "
                      "gets blocked, the “Always-loaded engine” row above "
                      "will say so.")
    return Result("sac", "Smart App Control", "Smart App Control", INFO,
                  name, name)


def check_other_voice_input() -> Result:
    """ほかの音声入力が動いていないか（ショートカットの取り合い）。"""
    from .winthread import running_exes  # noqa: PLC0415
    known = {"handy.exe": "Handy", "voiceaccess.exe": "音声アクセス",
             "wisprflow.exe": "Wispr Flow", "superwhisper.exe": "superwhisper",
             "talon.exe": "Talon", "dragon.exe": "Dragon"}
    try:
        running = running_exes()
    except Exception:
        return Result("others", "ほかの音声入力", "Other dictation apps",
                      INFO, "調べられません", "Cannot check")
    found = [label for exe, label in known.items() if exe in running]
    if not found:
        return Result("others", "ほかの音声入力", "Other dictation apps", OK,
                      "見つかりません", "None running")
    names = "、".join(found)
    return Result("others", "ほかの音声入力", "Other dictation apps", INFO,
                  f"{names} が動いています",
                  f"{', '.join(found)} running",
                  "同時に使えますが、ショートカットが同じだと"
                  "両方が反応します。「一般」のページで"
                  "ショートカットを変えるか、"
                  "相手側のショートカットを変えてください。",
                  "They can run together, but a shared shortcut triggers "
                  "both. Change the shortcut on the General page, or change "
                  "the other app's.")


CHECKS = (
    check_windows, check_python, check_console,
    check_microphone, check_mic_permission,
    check_resident, check_gpu,
    check_paste, check_folders, check_disk,
    check_sac, check_other_voice_input,
)


def run_all(*, model_key: str = "", hotkey: str = "",
            excluded: tuple[str, ...] = (),
            quick: bool = False) -> list[Result]:
    """全部調べる。quick=True なら時間のかかるものを飛ばす。"""
    out: list[Result] = []
    for fn in CHECKS:
        if quick and fn in (check_resident, check_gpu, check_mic_permission):
            continue
        try:
            out.append(fn())
        except Exception as exc:  # noqa: BLE001
            log.exception("動作チェック %s で例外", fn.__name__)
            out.append(Result(fn.__name__, fn.__name__, fn.__name__, WARN,
                              f"調べられません: {exc}",
                              f"Could not check: {exc}"))
    try:
        out.append(check_model(model_key))
    except Exception as exc:  # noqa: BLE001
        out.append(Result("model", "モデル", "Model", WARN,
                          str(exc), str(exc)))
    if hotkey:
        try:
            out.append(check_hotkey(hotkey, tuple(excluded or ())))
        except Exception as exc:  # noqa: BLE001
            out.append(Result("hotkey", "ショートカット", "Shortcut", WARN,
                              str(exc), str(exc)))
    return out


def summary(results: list[Result]) -> dict:
    """まとめ。参考（info）は件数に数えない。

    何も問題がないのに「注意 1 件」と出ると、初めて使う人を
    不必要に心配させるため。
    """
    counts = {OK: 0, WARN: 0, BAD: 0, INFO: 0}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1
    overall = BAD if counts[BAD] else (WARN if counts[WARN] else OK)
    return {"overall": overall, "counts": counts,
            "checked": len(results), "version": VERSION}
