"""モデルと実行ファイルのダウンロード。

urllib だけで行う（外部ライブラリを足さないため）。
zip / tar.gz の中の 1 ファイルだけ欲しい場合は、一時ファイルに落として取り出す。

★tar.gz も開ける。文字起こしのエンジン（transcribe.cpp）は tar.gz で
配られているのに zip しか開けず、**新しい PC の初回の案内で必ず
失敗していた**（2026-10-05、空のフォルダで初回の流れを再現して発覚）。
開発した PC には別の方法でエンジンを入れていたので気づかなかった。
"""

from __future__ import annotations

import fnmatch
import logging
import shutil
import tarfile
import tempfile
import threading
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

from .catalog import Asset, asset_path

log = logging.getLogger(__name__)

UA = "koe-type/1.1 (+https://github.com/)"
Progress = Callable[[str, float], None]      # (ファイル名, 0.0〜1.0)

# 通信が途中で切れても、受け取り済みの分から再開して粘る回数。
# 昔は 1 回の失敗で .part ごと捨てていたので、900MB 級のモデルが
# 99% で落ちると最初からやり直しになり、「結局うまくいかない」で
# 終わっていた（初回導線の監査 2026-10-28）。
RETRIES = 3
RETRY_WAIT = 1.0                # 秒。テストでは 0 に差し替えられる
# 空き容量の確認で、ダウンロード本体とは別に残しておく余裕。
# 圧縮ファイルは取り出し先にも同じくらいの場所が要るため。
SPACE_MARGIN = 32 * 1024 * 1024

_offline: bool = False


def set_offline(offline: bool) -> None:
    """通信遮断（オフラインモード）の有効・無効を設定する。"""
    global _offline
    _offline = bool(offline)


def is_offline() -> bool:
    """オフラインモードか調べる（環境変数 KOE_TYPE_OFFLINE も見る）。"""
    import os
    if os.environ.get("KOE_TYPE_OFFLINE") in ("1", "true", "TRUE"):
        return True
    return _offline


class DownloadError(RuntimeError):
    pass


def free_bytes(path: Path) -> int:
    """path のあるドライブの空き容量。分からなければ -1。

    親フォルダがまだ無いことがあるので、実在する親まで遡る。
    """
    try:
        target = path
        while not target.exists() and target.parent != target:
            target = target.parent
        return shutil.disk_usage(target).free
    except OSError:
        return -1


def check_space(dest: Path, expected: int) -> None:
    """空き容量が足りなければ、始める前に分かる言葉で止める。

    途中でディスクがいっぱいになると、受け取り済みの分まで
    巻き込んで壊れる。最初に確かめるのが確実で、利用者にも
    次に何をすればよいか（消す／小さいモデルを選ぶ）が伝わる。
    分からない環境（-1）では止めない（動くものを止めない）。
    """
    if expected <= 0:
        return
    free = free_bytes(dest.parent)
    if free < 0:
        return
    need = expected + SPACE_MARGIN
    if free < need:
        raise DownloadError(
            "空き容量が足りません。"
            f"あと約 {(need - free) / 1e6:.0f} MB 必要です"
            f"（空き {free / 1e6:.0f} MB / 必要 {need / 1e6:.0f} MB）。"
            "不要なファイルを消すか、小さいモデルを選んでください")


_TLS_CONTEXT = None


def tls_context():  # noqa: ANN202
    """取得に使う TLS の設定（使い回す）。

    一部の配布元（Hugging Face 等）は、ルート証明書に届く前の
    途中の証明書までしか送ってこない。Windows 標準の検証は
    それでも通すが OpenSSL の既定は完全なチェーンを求めるため、
    まっさらな PC で証明書エラーになり、モデルだけ落ちて
    こない事故があった（VM 実証で確認）。ブラウザと同じく、
    信頼できる証明書までの部分チェーンを許可する。
    検証そのものを弱めるものではない。
    """
    global _TLS_CONTEXT
    if _TLS_CONTEXT is None:
        import ssl  # noqa: PLC0415
        ctx = ssl.create_default_context()
        partial = getattr(ssl, "VERIFY_X509_PARTIAL_CHAIN", 0)
        if partial:
            ctx.verify_flags |= partial
        _TLS_CONTEXT = ctx
    return _TLS_CONTEXT

class _Incomplete(Exception):
    """届くはずの長さまで届かなかった。再開すれば続きが取れる。"""

    def __init__(self, done: int, total: int) -> None:
        super().__init__(f"{done}/{total} バイトまで届きました")
        self.total = total


def _fetch_once(url: str, dest: Path, expected: int, name: str,
                progress: Progress | None,
                cancel: threading.Event | None, part: Path,
                floor: int = 0) -> int:
    """1 回ぶんの取得。.part へ足していき、そろったら dest へ替える。

    失敗しても .part は消さない。次は Range で続きから受け取る
    （相手が Range に応じなければ、最初から取り直す）。
    長さの確認は、相手が名乗った Content-Length に対してだけ行う。
    カタログの size は「おおよそ」なので、照合には使わない。
    """
    have = part.stat().st_size if part.exists() else 0
    headers = {"User-Agent": UA}
    if have > 0:
        headers["Range"] = f"bytes={have}-"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=60,
                                context=tls_context()) as response:
        status = getattr(response, "status", 200) or 200
        if have > 0 and status != 206:
            # Range を無視された。混ざると壊れるので最初から。
            have = 0
        length = response.headers.get("Content-Length")
        total = 0
        if length:
            try:
                total = int(length) + have if status == 206 else int(length)
            except ValueError:
                total = 0
        if not total:
            total = expected or 0
        # 同じ取得の中で一度でも申告された長さは下限として保つ。
        # 再開の応答が短い長さを言い直しても、切り捨てを受け
        # 入れない（壊れた相手・中継が長さを落とすことがある）。
        total = max(total, floor)
        done = have
        with part.open("ab" if have > 0 else "wb") as fh:
            while True:
                if cancel is not None and cancel.is_set():
                    raise DownloadError("中止しました")
                chunk = response.read(262_144)
                if not chunk:
                    break
                fh.write(chunk)
                done += len(chunk)
                if progress and total:
                    progress(name, min(1.0, done / total))
    if total and done < total:
        raise _Incomplete(done, total)
    if total and done > total:
        # 長さが合わない＝中身が壊れている。.part ごと捨てて取り直す
        part.unlink(missing_ok=True)
        raise DownloadError("届いたファイルの大きさが合いませんでした。"
                            "もう一度ためしてください")
    part.replace(dest)
    return total


def _fetch(url: str, dest: Path, expected: int, name: str,
           progress: Progress | None, cancel: threading.Event | None) -> None:
    if is_offline():
        raise DownloadError("通信が遮断されています（オフラインモード）。"
                            "設定の「通信を止める」をオフにしてから、"
                            "もう一度ためしてください")
    dest.parent.mkdir(parents=True, exist_ok=True)
    check_space(dest, expected)
    part = dest.with_suffix(dest.suffix + ".part")
    last: Exception | None = None
    want = 0
    for attempt in range(RETRIES):
        if cancel is not None and cancel.is_set():
            raise DownloadError("中止しました")
        if attempt and RETRY_WAIT:
            time.sleep(RETRY_WAIT * attempt)
        try:
            _fetch_once(url, dest, expected, name, progress, cancel,
                        part, want)
            return
        except DownloadError:
            raise
        except _Incomplete as exc:
            want = max(want, exc.total)
            last = exc
            log.warning("取得が途中で終わりました（%d 回目）: %s",
                        attempt + 1, exc)
        except urllib.error.HTTPError as exc:
            last = exc
            if exc.code == 416 and part.exists():
                # 続きの位置が相手の長さを超えている＝.part が
                # 壊れている。捨てて最初から取り直す。
                part.unlink(missing_ok=True)
                continue
            log.warning("取得に失敗（%d 回目）: %s", attempt + 1, exc)
        except Exception as exc:  # noqa: BLE001
            # URLError・切断・途中までしか届かなかった、など。
            # .part は残るので、次の試行は続きから再開する。
            last = exc
            log.warning("取得に失敗（%d 回目）: %s", attempt + 1, exc)
    have = part.stat().st_size if part.exists() else 0
    detail = f"{last}" if last is not None else ""
    raise DownloadError(
        "うまく受け取れませんでした。"
        + (f"途中まで {have / 1e6:.0f} MB 受け取っています。"
           if have else "")
        + "通信を確認して、もう一度ためしてください。"
          "続きから再開します。"
        + (f"（{detail[:120]}）" if detail else ""))


def fetch_asset(asset: Asset, progress: Progress | None = None,
                cancel: threading.Event | None = None) -> None:
    dest = asset_path(asset)
    if dest.exists():
        if dest.stat().st_size > 0:
            return
        # 0 バイトのファイルは「ある」ことにしない。前の失敗の
        # 残骸を本物と間違えると、エンジンが読めずに詰まる。
        dest.unlink(missing_ok=True)
    if not asset.unzip_from:
        _fetch(asset.url, dest, asset.size, asset.name, progress, cancel)
        if not dest.exists() or dest.stat().st_size == 0:
            raise DownloadError(f"{asset.name} が空でした")
        log.info("取得しました: %s", dest)
        return

    with tempfile.TemporaryDirectory(prefix="koe-type-dl-") as tmpdir:
        archive = Path(tmpdir) / "download.bin"
        _fetch(asset.url, archive, asset.size, asset.name, progress, cancel)
        with _Archive(archive) as box:
            _extract(box, asset, dest)
    if not dest.exists() or dest.stat().st_size == 0:
        raise DownloadError("取り出したファイルがそろいませんでした。"
                            "もう一度ためしてください")
    log.info("取り出しました: %s", dest)


class _Archive:
    """zip と tar.gz を同じ形で読む小さな包み。"""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._zip: zipfile.ZipFile | None = None
        self._tar: tarfile.TarFile | None = None

    def __enter__(self) -> "_Archive":
        if zipfile.is_zipfile(self.path):
            self._zip = zipfile.ZipFile(self.path)
        elif tarfile.is_tarfile(self.path):
            self._tar = tarfile.open(self.path)
        else:
            raise DownloadError("zip でも tar.gz でもないファイルが届きました")
        return self

    def __exit__(self, *exc: object) -> None:
        if self._zip is not None:
            self._zip.close()
        if self._tar is not None:
            self._tar.close()

    def names(self) -> list[str]:
        """ファイルの名前（フォルダは除く）。区切りは / にそろえる。"""
        if self._zip is not None:
            return [n for n in self._zip.namelist() if not n.endswith("/")]
        assert self._tar is not None
        return [m.name for m in self._tar.getmembers() if m.isfile()]

    def read(self, name: str) -> bytes:
        if self._zip is not None:
            return self._zip.read(name)
        assert self._tar is not None
        handle = self._tar.extractfile(name)
        if handle is None:
            raise DownloadError(f"{name} を取り出せません")
        with handle:
            return handle.read()


def _safe_join(root: Path, rel: str) -> Path:
    """圧縮ファイルの中の名前を、root の下の場所にする。

    「../」や絶対パスで root の外へ書かせない（壊れた・悪意のある
    圧縮ファイルで、ほかの場所のファイルを上書きしないため）。
    """
    out = (root / rel).resolve()
    if root.resolve() not in out.parents:
        raise DownloadError(f"圧縮ファイルの中の名前が不正です: {rel}")
    return out


def _write_atomic(out: Path, data: bytes) -> None:
    """途中で落ちても、半端な中身を本物として残さない。

    いったん .part に書いてから替える。取り出しの途中で電源が
    切れても、目印のファイルが「そろった」ことにならない。
    """
    part = out.with_suffix(out.suffix + ".part")
    part.write_bytes(data)
    part.replace(out)


def _extract(box: _Archive, asset: Asset, dest: Path) -> None:
    names = box.names()
    pattern = asset.unzip_from
    if pattern == "*":
        # まるごと取り出す（フォルダの並びは保つ）。dest は「そろった」の
        # 目印になるファイル。圧縮ファイルの中での場所から、取り出す
        # 根元を決める。目印は**最後に**書く（途中で失敗したときに、
        # そろったと誤解しないため）。
        mark = next((n for n in names
                     if dest.as_posix().endswith("/" + n)), None)
        if mark is None:
            raise DownloadError(f"圧縮ファイルに {dest.name} がありません")
        root = Path(dest.as_posix()[:-len(mark)].rstrip("/"))
        root.mkdir(parents=True, exist_ok=True)
        for n in sorted(names, key=lambda n: n == mark):
            out = _safe_join(root, n)
            out.parent.mkdir(parents=True, exist_ok=True)
            _write_atomic(out, box.read(n))
        return
    if pattern.endswith("/*"):
        # フォルダまるごと（whisper.cpp の Release/ など）を dest の横へ
        prefix = pattern[:-1]
        targets = [n for n in names if n.startswith(prefix)]
        if not targets:
            raise DownloadError(f"圧縮ファイルに {pattern} がありません")
        dest.parent.mkdir(parents=True, exist_ok=True)
        # 目印（dest）になるファイルは最後に書く。途中で失敗した
        # ときに、ほかの DLL が無いのに「そろった」と間違えない。
        for n in sorted(targets,
                        key=lambda n: Path(n).name == dest.name):
            _write_atomic(dest.parent / Path(n).name, box.read(n))
        return
    match = next((n for n in names
                  if n == pattern or fnmatch.fnmatch(Path(n).name, pattern)),
                 None)
    if match is None:
        raise DownloadError(f"圧縮ファイルに {pattern} がありません")
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_suffix(dest.suffix + ".part")
    part.write_bytes(box.read(match))
    part.replace(dest)


def fetch_all(assets: list[Asset], progress: Progress | None = None,
              cancel: threading.Event | None = None) -> None:
    for asset in assets:
        fetch_asset(asset, progress, cancel)


def remove_assets(assets: list[Asset]) -> int:
    removed = 0
    for asset in assets:
        path = asset_path(asset)
        try:
            if path.exists():
                path.unlink()
                removed += 1
                log.info("削除しました: %s", path)
        except OSError:
            log.exception("削除できませんでした: %s", path)
    return removed
