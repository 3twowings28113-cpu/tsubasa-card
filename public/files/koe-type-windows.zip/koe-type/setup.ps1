# koe-type installer.
#
#   Checks for a usable Python (3.10+ with tkinter), installs the official
#   python.org build through winget if there is none, then starts koe-type and
#   registers it to launch at sign-in.
#
#   Everything it runs is signed by Microsoft or the Python Software Foundation,
#   so it works on PCs with Smart App Control turned on.
#
#   Run:  powershell -ExecutionPolicy Bypass -File setup.ps1

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$minMajor = 3
$minMinor = 10

function Write-Step($text) { Write-Host "`n==> $text" -ForegroundColor Cyan }
function Write-Ok($text)   { Write-Host "    $text" -ForegroundColor Green }
function Write-Warn($text) { Write-Host "    $text" -ForegroundColor Yellow }

function Test-Python($exe) {
    if (-not $exe) { return $false }
    try {
        $script = "import sys,tkinter;" +
                  "print(sys.version_info[0],sys.version_info[1])"
        $out = & $exe -c $script 2>$null
        if ($LASTEXITCODE -ne 0 -or -not $out) { return $false }
        $parts = $out.Trim() -split '\s+'
        $maj = [int]$parts[0]; $min = [int]$parts[1]
        return ($maj -gt $minMajor) -or ($maj -eq $minMajor -and $min -ge $minMinor)
    } catch { return $false }
}

function Find-Python {
    # 同梱の署名済み Python があれば、それを使う。
    # 受け取った人の PC に Python が無くても動くようにするため。
    $bundled = Join-Path $root "runtime\python.exe"
    if ((Test-Path $bundled) -and (Test-Python $bundled)) {
        return $bundled
    }
    $candidates = @()
    foreach ($name in @("python", "python3")) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) { $candidates += $cmd.Source }
    }
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        try {
            foreach ($line in (& py -0p 2>$null)) {
                $m = [regex]::Match($line, '([A-Za-z]:\\[^\s].*python\.exe)')
                if ($m.Success) { $candidates += $m.Groups[1].Value }
            }
        } catch { }
    }
    $candidates += @(
        "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe",
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "C:\Python313\python.exe", "C:\Python312\python.exe"
    )
    foreach ($c in ($candidates | Select-Object -Unique)) {
        if ((Test-Path $c) -and (Test-Python $c)) { return $c }
    }
    return $null
}

Write-Host "koe-type setup" -ForegroundColor White

Write-Step "Looking for Python $minMajor.$minMinor or newer"
$python = Find-Python
if ($python) {
    Write-Ok "Found: $python"
} else {
    Write-Warn "No suitable Python found."
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if (-not $winget) {
        Write-Host @"
    winget is not available on this PC.
    Please install Python 3.12 from https://www.python.org/downloads/windows/
    (keep the default options, which include tkinter), then run setup again.
"@ -ForegroundColor Red
        exit 1
    }
    Write-Step "Installing Python 3.12 with winget (signed by python.org)"
    winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements --scope user
    $env:Path = [Environment]::GetEnvironmentVariable("Path", "User") + ";" +
                [Environment]::GetEnvironmentVariable("Path", "Machine")
    $python = Find-Python
    if (-not $python) {
        Write-Host "    Python was installed but could not be found. Open a new terminal and run setup again." -ForegroundColor Red
        exit 1
    }
    Write-Ok "Installed: $python"
}

$pythonw = Join-Path (Split-Path $python) "pythonw.exe"
if (-not (Test-Path $pythonw)) { $pythonw = $python }

Write-Step "Writing start.cmd"
$cmd = "@echo off`r`n" +
       "rem Launch koe-type (no console window)`r`n" +
       "start """" ""$pythonw"" ""$root\koe-type.pyw""`r`n"
Set-Content -Path (Join-Path $root "start.cmd") -Value $cmd -Encoding Ascii
Write-Ok "start.cmd"

Write-Step "Creating a Start menu shortcut"
try {
    $startMenu = [Environment]::GetFolderPath("Programs")
    $link = Join-Path $startMenu "koe-type.lnk"
    $shell = New-Object -ComObject WScript.Shell
    $sc = $shell.CreateShortcut($link)
    $sc.TargetPath = $pythonw
    $sc.Arguments = """$root\koe-type.pyw"""
    $sc.WorkingDirectory = $root
    $sc.Description = "koe-type - offline Japanese voice typing"
    $iconFile = Join-Path $root "assets\icon\koe-type-idle.ico"
    if (Test-Path $iconFile) { $sc.IconLocation = "$iconFile,0" }
    $sc.Save()
    Write-Ok $link
} catch {
    Write-Warn "Could not create the shortcut: $_"
}

Write-Step "Starting koe-type"
Start-Process -FilePath $pythonw -ArgumentList "`"$root\koe-type.pyw`"" -WorkingDirectory $root
Start-Sleep -Seconds 3
Write-Ok "Running. Look for the microphone icon in the system tray."

Write-Host @"

Done.

  * The first time it runs, the settings window opens so you can download a
    speech model (about 250 MB for the default one).
  * Press Ctrl+Space to start dictating, Ctrl+Space again to stop.
  * Right-click the tray icon for Settings.
  * koe-type now starts automatically when you sign in. You can turn that off
    under Settings > Application.

"@ -ForegroundColor White
