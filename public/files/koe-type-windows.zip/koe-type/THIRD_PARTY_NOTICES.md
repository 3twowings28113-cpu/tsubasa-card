# サードパーティのライセンス / Third-party notices

koe-type 本体（`app/`, `tools/`, `koe-type.pyw`）は MIT ライセンスです。
本体は **Python 標準ライブラリと Windows 標準 DLL しか使いません**。
pip パッケージへの依存はありません。

`vendor/` には、他者のコードを**そのままの形で同梱**しています。
どれも純 Python（ctypes）で、インストールするものはありません。

実行ファイルとモデルはリポジトリに含まれず、初回起動時か設定画面から
下記の公式配布元を取得します。**それぞれのライセンスは配布元のものに従います。**

---

## 同梱しているコード（`vendor/`）

### transcribe_cpp 0.3.0（Python バインディング）
- 置き場所: `vendor/transcribe_cpp/`（`__init__.py` `_abi.py`
  `_generated.py` `_library.py` `errors.py` の 5 ファイル）
- 出どころ: PyPI の `transcribe-cpp` 0.3.0（`py3-none-any`、純 Python）
- 上流: https://github.com/handy-computer/transcribe.cpp
- ライセンス: **MIT** — 全文を `vendor/transcribe_cpp/LICENSE` に置いています
- 役目: 文字起こしの実体（`transcribe.dll`）を ctypes で呼ぶための層。
  **変更せずにそのまま**置いています。
- なぜ pip ではなく同梱なのか: インストールするものが何もないため、
  ファイルを置くだけで動きます。ネットがなくても動き、配布 zip にそのまま
  入ります。「pip パッケージを足さない」という方針を保てます。

---

## 持ち運べる版に同梱するもの（`runtime/`）

### Python（Python Software Foundation）
- `pythonw.exe` `python.exe` `python3*.dll` と標準ライブラリ。
  python.org の配布物を**変更せずに**置いています（PSF の署名つき）。
- ライセンス: Python Software Foundation License

### Microsoft Visual C++ ランタイム
- `vcruntime140.dll` `vcruntime140_1.dll`（Python に付いているもの）と
  `msvcp140.dll`（文字起こしのエンジンが使う）。
- マイクロソフトの署名つきで、アプリと一緒に置く形の再配布が
  認められているファイルです。**変更していません。**
- なぜ同梱するのか: エンジンの DLL がすべて `msvcp140.dll` に頼っており、
  Visual C++ 再頒布可能パッケージが入っていない PC では、同梱しないと
  文字起こしが動きません（入れるには管理者権限が要ります）。

---

## 実行ファイル（エンジン）

### transcribe.cpp ランタイム（既定）
- 使うもの: `transcribe.dll` と、同梱の `ggml*.dll`（13 ファイル）
- 配布元: https://github.com/handy-computer/transcribe.cpp/releases
  （タグ `v0.3.0`、`transcribe-native-0.3.0-windows-x86_64-cpu-vulkan.tar.gz`）
- ライセンス: **MIT** — 配布物の `licenses/LICENSE` に全文が入っています
- 内部で [ggml](https://github.com/ggml-org/ggml)（MIT）を使っています。
- koe-type はこのバイナリを**変更せずに**ダウンロードし、
  ctypes で読み込んで呼び出すだけです。ソースコードは取り込んでいません。
- モデルをメモリに置いたまま使えるので、1 回ごとのモデル読み込みが
  なくなります（この PC の実測で 0.62 秒 → 0.122 秒）。

### speech.cpp ランタイム（worker 常駐）
- 使うもの: `speech.exe` と、相棒の `speech.dll`
- 配布元: https://github.com/nyosegawa/speech.cpp/releases
  （タグ `v0.10.1`、`speech-0.10.1-windows-x64-vulkan.zip`）
- ライセンス: **MIT** — https://github.com/nyosegawa/speech.cpp/blob/main/LICENSE
- 内部で [ggml](https://github.com/ggml-org/ggml)（MIT）を使っています。
- koe-type はこのバイナリを**変更せずに**ダウンロードし、
  `speech worker` という常駐プロセスとして呼び出すだけです
  （JSON Lines で PCM を渡す。transcribe.dll では読めない
  FastConformer 系モデルのための担い手）。

### FunASR llama.cpp runtime
- 使うもの: `llama-funasr-sensevoice.exe`（Vulkan 版）, `llama-funasr-cli.exe`
- 配布元: https://github.com/modelscope/FunASR/releases （タグ `v1.4.16`）
- ライセンス: **MIT** — https://github.com/modelscope/FunASR/blob/main/LICENSE
- 内部で [llama.cpp / ggml](https://github.com/ggml-org/llama.cpp)（MIT）を使っています。
- koe-type はこのバイナリを**変更せずに**ダウンロードし、サブプロセスとして
  呼び出すだけです。ソースコードは取り込んでいません。

### whisper.cpp
- 使うもの: `whisper-cli.exe` と同梱の ggml / OpenBLAS DLL
- 配布元: https://github.com/ggml-org/whisper.cpp/releases （タグ `v1.9.2`）
- ライセンス: **MIT** — https://github.com/ggml-org/whisper.cpp/blob/master/LICENSE
- 同梱される OpenBLAS は **BSD 3-Clause** — https://github.com/OpenMathLib/OpenBLAS/blob/develop/LICENSE

---

## モデル

ライセンスは 2026-10-03 に各配布元で確認しました。

| モデル | 配布元 | ライセンス |
|---|---|---|
| SenseVoice Small (GGUF) | https://huggingface.co/FunAudioLLM/SenseVoiceSmall-GGUF | **FunASR Model Open Source License Agreement v1.1**（下記） |
| Fun-ASR-Nano (GGUF: encoder + Qwen3-0.6B decoder) | https://huggingface.co/FunAudioLLM/Fun-ASR-Nano-GGUF | **Apache-2.0** |
| Whisper large-v3-turbo (ggml) | https://huggingface.co/ggerganov/whisper.cpp | **MIT** |
| Haas-ja-v1.0 (GGUF) | https://huggingface.co/sakasegawa/Haas-ja-v1.0-GGUF | **Apache-2.0** |

### SenseVoice Small について（注意）

元モデル [FunAudioLLM/SenseVoiceSmall](https://huggingface.co/FunAudioLLM/SenseVoiceSmall)
のモデルカードは `license: other` / `license_name: model-license` で、
実体は
**[FunASR Model Open Source License Agreement v1.1](https://github.com/modelscope/FunASR/blob/main/MODEL_LICENSE)**
（Alibaba Group）です。**Apache-2.0 ではありません。**

GGUF への変換を配布している
[SenseVoiceSmall-GGUF](https://huggingface.co/FunAudioLLM/SenseVoiceSmall-GGUF)
のカードには `license: apache-2.0` と書かれていますが、派生物が元より緩い
ライセンスになることはないため、koe-type では**厳しいほう（FunASR モデル
ライセンス）に従って表示**しています。

この契約の要点（原文を要約したものです。正確な条件は原文を見てください）
- 使用・複製・改変・共有は自由
- ただし**出典と著作者の表示を残し、モデル名を保持する**こと
- 無保証。利用による損害の責任は負わない
- モデルに対する不当な中傷などを行った場合、ライセンスは自動的に失効する

→ koe-type はモデルを**改変せずダウンロードして使うだけ**で、
モデル名（SenseVoice Small）と配布元を設定画面と本書に明記しています。

### Fun-ASR-Nano について

[Fun-ASR-Nano-2512](https://huggingface.co/FunAudioLLM/Fun-ASR-Nano-2512) の
モデルカードは `license: apache-2.0`、
[Fun-ASR のリポジトリ](https://github.com/QwenAudio/Fun-ASR/blob/main/LICENSE)
も Apache-2.0 です。

### Whisper について

ggml 形式の配布元 [ggerganov/whisper.cpp](https://huggingface.co/ggerganov/whisper.cpp)
は MIT、元の [openai/whisper](https://github.com/openai/whisper/blob/main/LICENSE)
も MIT です。

### Haas-ja-v1.0 について

元モデル [third-intelligence/Haas-ja-v1.0](https://huggingface.co/third-intelligence/Haas-ja-v1.0)
（Third Intelligence、日本語特化の FastConformer 系）は **Apache-2.0**、
GGUF への変換を配布している
[sakasegawa/Haas-ja-v1.0-GGUF](https://huggingface.co/sakasegawa/Haas-ja-v1.0-GGUF)
も Apache-2.0 です。実行には speech.cpp ランタイム（上記）を使います。

いずれも商用利用が許されていますが、**最新の条件は配布元で確認してください**。
モデルの重みは koe-type の配布物には含まれません。

---

## 参考にしたもの / Acknowledgements

- [Handy](https://github.com/cjpais/Handy)（MIT）… 同じ領域の先行アプリ。
  **コードもファイルも取り込んでいません。** 日本語ベンチマークの公開値を
  モデル選定の出発点として参考にし、設定画面を「左にカテゴリ、右に項目」という
  一般的な構成にする点で発想を得ました。配色・ロゴ・文言は共有していません。
- [FunASR](https://github.com/modelscope/FunASR)（MIT）… エンジンと GGUF 変換。
- [whisper.cpp](https://github.com/ggml-org/whisper.cpp) / [llama.cpp](https://github.com/ggml-org/llama.cpp)（MIT）。

---

## 評価に使ったデータ

### FLEURS（Google）
- 使い方: 日本語の test 分割から 200 本を、**精度の計測にだけ**使いました。
- 出どころ: https://huggingface.co/datasets/google/fleurs
- ライセンス: **CC-BY-4.0**
- **リポジトリにも配布物にも含めていません**（`bench/fleurs/` は
  `.gitignore` 済み）。計測し直したい場合は、上記から取得してください。

---

## 同梱している素材

- トレイのアイコンと効果音は、**実行時にコードで生成**しています
  （`app/icons.py`, `app/sysaudio.py`）。外部の画像・音源は同梱していません。
- 使用フォントは Windows 標準の Yu Gothic UI / Segoe UI / Consolas を
  名前で指定しているだけで、フォントファイルは含みません。
