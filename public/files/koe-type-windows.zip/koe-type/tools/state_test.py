"""どんな状態からでも待機へ戻れるかを、組み合わせで確かめる。

**本物のキーもクリックも 1 回も送らない。** 台本（`app/testdrive.py`）で
内側から操作する。スピーカーも使わない（WAV を流し込む）。

## なぜ作ったか

静かになって自動停止したあと、**帯が消えず、Ctrl+Space が何回押しても
効かなくなった。** 原因は 2 つ。

  1. 画面の繰り返し（`_tick`）が、自動停止のときに `try` の中で
     `return` していて、**繰り返しそのものが終わっていた**。
  2. ショートカットの確認が「いま持っている分を付け直す」だけで、
     除外アプリが前面だった拍子に登録が外れると戻らなかった。

どちらも「ある状態からある状態へ移るとき」の抜けだった。だから
**状態の移り方をひとつずつ**確かめる。

## 確かめること

どの終わり方（静かで自動停止／送信／別の窓へ移動／クリック／Esc）の
あとでも、

  ・次の Ctrl+Space で**必ず録音が始まる**
  ・画面の繰り返しが**止まっていない**
  ・「待機へ戻します」の強制復帰に頼っていない（ふつうに戻れている）
  ・落ちていない

    python tools/state_test.py
    python tools/state_test.py --only silence
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tools.mock_e2e import AUDIO, make_home, run_app  # noqa: E402

TMP = ROOT / "bench" / "eval" / "_state"

# 1 回の録音の長さ（秒）。短いほど速いが、文字起こしが追いつく長さにする。
TALK = 3.0


def plan(steps: list[tuple[float, str]], **common) -> list[dict]:
    """(秒, 操作) の並びを台本にする。"""
    out = []
    for at, event in steps:
        row = {"at": round(at, 2), "event": event}
        row.update(common.get(event, {}))
        out.append(row)
    return out


# ---------------------------------------------------------------- 台本たち


def case_silence() -> tuple[list[dict], int]:
    """静かで自動停止 → そのあと Ctrl+Space で録音できるか（例の不具合）。"""
    return plan([
        (1.0, "hotkey_down"),       # 1 回目の録音
        (1.0 + TALK, "silence"),    # 静かな時間を進める → 自動停止
        (1.0 + TALK + 3.0, "hotkey_down"),   # ★ここが始まらなかった
        (1.0 + TALK * 2 + 3.0, "stop"),
        (1.0 + TALK * 2 + 6.0, "quit"),
    ]), 2


def case_silence_twice() -> tuple[list[dict], int]:
    """自動停止を 2 回続けても戻れるか。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "silence"),
        (1.0 + TALK + 2.5, "hotkey_down"),
        (1.0 + TALK * 2 + 2.5, "silence"),
        (1.0 + TALK * 2 + 5.0, "hotkey_down"),
        (1.0 + TALK * 3 + 5.0, "stop"),
        (1.0 + TALK * 3 + 8.0, "quit"),
    ]), 3


def case_send() -> tuple[list[dict], int]:
    """Enter で送信して止めたあと、また録音できるか。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "send"),
        (1.0 + TALK + 3.0, "hotkey_down"),
        (1.0 + TALK * 2 + 3.0, "stop"),
        (1.0 + TALK * 2 + 6.0, "quit"),
    ]), 2


def case_focus() -> tuple[list[dict], int]:
    """別の窓へ移って止まったあと、また録音できるか。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "focus_changed"),
        (1.0 + TALK + 3.0, "hotkey_down"),
        (1.0 + TALK * 2 + 3.0, "stop"),
        (1.0 + TALK * 2 + 6.0, "quit"),
    ], focus_changed={"hwnd": 999999}), 2


def case_focus_blip() -> tuple[list[dict], int]:
    """一瞬だけ別の窓が前に出ても、録音を止めない。

    メニューや通知が一瞬だけ前に出て、録音を始めて 0.1〜1.9 秒で
    止まることが 10 回続いた（2026-10-05 の診断情報）。
    """
    return plan([
        (1.0, "hotkey_down"),
        (2.0, "focus_changed"),
        (2.1, "focus_back"),
        (1.0 + TALK, "stop"),
        (1.0 + TALK + 4.0, "quit"),
    ], focus_changed={"hwnd": 999999}), 1


def case_hold() -> tuple[list[dict], int]:
    """長押し：押して話し、離したら止まる。

    ★前は離したことを知る手段がなく、ショートカットで止められなかった。
    """
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "hotkey_up"),
        (1.0 + TALK + 4.0, "quit"),
    ], hotkey_up={"held": TALK}), 1


def case_auto_tap() -> tuple[list[dict], int]:
    """おまかせ：短く押したら、離しても止まらない。もう一度押すと止まる。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.2, "hotkey_up"),
        (1.0 + TALK, "hotkey_down"),
        (1.0 + TALK + 0.2, "hotkey_up"),
        (1.0 + TALK + 4.0, "quit"),
    ], hotkey_up={"held": 0.2}), 1


def case_auto_hold() -> tuple[list[dict], int]:
    """おまかせ：長く押したら、離したところで止まる。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "hotkey_up"),
        (1.0 + TALK + 4.0, "quit"),
    ], hotkey_up={"held": TALK}), 1


# 回ごとに変える設定（ほかは共通）
CASE_CONFIG = {
    "hold": {"shortcut_mode": "hold"},
    "auto_tap": {"shortcut_mode": "auto"},
    "auto_hold": {"shortcut_mode": "auto"},
}


def case_pause() -> tuple[list[dict], int]:
    """トレイで一時停止 → 再開したあと、ふつうに録音できるか。"""
    return plan([
        (1.0, "menu:pause"),
        (2.0, "menu:pause"),
        (3.0, "hotkey_down"),
        (3.0 + TALK, "stop"),
        (3.0 + TALK + 4.0, "quit"),
    ]), 1


def case_click() -> tuple[list[dict], int]:
    """クリックで止まったあと、また録音できるか。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "click_stop"),
        (1.0 + TALK + 3.0, "hotkey_down"),
        (1.0 + TALK * 2 + 3.0, "stop"),
        (1.0 + TALK * 2 + 6.0, "quit"),
    ]), 2


def case_cancel() -> tuple[list[dict], int]:
    """Esc で中止したあと、また録音できるか。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "cancel"),
        (1.0 + TALK + 2.0, "hotkey_down"),
        (1.0 + TALK * 2 + 2.0, "stop"),
        (1.0 + TALK * 2 + 5.0, "quit"),
    ]), 2


def case_idle_cancel() -> tuple[list[dict], int]:
    """待機中に Esc を押しても壊れず、そのあと録音できるか。"""
    return plan([
        (1.0, "cancel"),
        (1.6, "cancel"),
        (2.2, "hotkey_down"),
        (2.2 + TALK, "stop"),
        (2.2 + TALK + 3.0, "quit"),
    ]), 1


def case_stop_then_start() -> tuple[list[dict], int]:
    """止めた直後（止める途中）に Ctrl+Space を押しても始まるか。"""
    return plan([
        (1.0, "hotkey_down"),
        (1.0 + TALK, "stop"),
        (1.0 + TALK + 0.1, "hotkey_down"),   # ほぼ同時
        (1.0 + TALK * 2 + 0.1, "stop"),
        (1.0 + TALK * 2 + 4.0, "quit"),
    ]), 2


def case_toggle_fast() -> tuple[list[dict], int]:
    """Ctrl+Space を続けて押しても、開始と停止が食い違わないか。"""
    steps = [(1.0, "hotkey_down")]
    at = 1.0 + TALK
    for _ in range(3):
        steps.append((at, "hotkey_down"))        # 停止
        at += 0.6
        steps.append((at, "hotkey_down"))        # 開始
        at += TALK
    steps.append((at, "stop"))
    steps.append((at + 4.0, "quit"))
    return plan(steps), 4


def case_mixed() -> tuple[list[dict], int]:
    """全部の終わり方を一本で通し、最後にちゃんと録音できるか。"""
    steps = []
    at = 1.0
    for ending in ("silence", "send", "focus_changed", "click_stop",
                   "cancel"):
        steps.append((at, "hotkey_down"))
        at += TALK
        steps.append((at, ending))
        at += 2.5
    steps.append((at, "hotkey_down"))      # ★最後に必ず始まること
    at += TALK
    steps.append((at, "stop"))
    steps.append((at + 5.0, "quit"))
    return plan(steps, focus_changed={"hwnd": 999999}), 6


CASES = {
    "silence": ("静かで自動停止 → 次の録音", case_silence),
    "silence2": ("自動停止を 2 回続ける", case_silence_twice),
    "send": ("送信で停止 → 次の録音", case_send),
    "focus": ("別の窓へ移動 → 次の録音", case_focus),
    "focus_blip": ("一瞬だけ別の窓 → 止めない", case_focus_blip),
    "pause": ("一時停止 → 再開 → 次の録音", case_pause),
    "hold": ("長押し：離したら止まる", case_hold),
    "auto_tap": ("おまかせ：短く押すと切り替え", case_auto_tap),
    "auto_hold": ("おまかせ：長く押すと離して止まる", case_auto_hold),
    "click": ("クリックで停止 → 次の録音", case_click),
    "cancel": ("Esc で中止 → 次の録音", case_cancel),
    "idle_esc": ("待機中の Esc → 次の録音", case_idle_cancel),
    "stop_start": ("止める途中で開始", case_stop_then_start),
    "toggle": ("続けて押す", case_toggle_fast),
    "mixed": ("全部の終わり方を通す", case_mixed),
}


# ---------------------------------------------------------------- 検証


def judge(name: str, result: dict, want_sessions: int):  # noqa: ANN201
    """ログを読んで、(おかしな点の一覧, 数) を返す。"""
    bad: list[str] = []
    text = ""
    log_path: Path = result["app_log"]
    for path in sorted(log_path.parent.glob(log_path.name + "*")):
        text += path.read_text("utf-8", "replace")

    starts = re.findall(r"録音開始 session=(\d+)", text)
    stops = re.findall(r"録音停止 session=(\d+)", text)
    cancels = re.findall(r"中止 session=(\d+)", text)
    ends = len(stops) + len(cancels)

    if len(starts) < want_sessions:
        bad.append(f"録音が {len(starts)} 回しか始まっていない"
                   f"（{want_sessions} 回のはず）")
    if ends < want_sessions:
        bad.append(f"終わりが {ends} 回しかない（{want_sessions} 回のはず）")

    if "未捕捉の例外" in text:
        bad.append("未捕捉の例外が出ている")
    if result["rc"] != 0:
        bad.append(f"終了コードが {result['rc']}")

    # 停止にかける時間の内訳が、見張りの締め切りに収まっているか。
    # ここが逆転していると、ふつうの停止で「終わらない」と誤判定する
    # （長時間テストで実際に 2 回出た）。
    import app.main as _m  # noqa: PLC0415
    budget = 0.4 + _m.Controller.JOIN_STREAM        # 録り残し + 合流
    if budget >= 3.0:
        bad.append(f"停止の内訳 {budget:.1f} 秒が締め切り 3.0 秒に収まらない")

    # 強制復帰に頼っていないか（頼らず戻れているのが正しい）
    forced = text.count("待機の状態へ戻します")
    stuck = len(re.findall(r"停止が [0-9.]+ 秒終わらない", text))
    if stuck:
        bad.append(f"停止が終わらず強制復帰した（{stuck} 回）")

    # 画面の繰り返しが止まっていないか
    m = re.search(r"画面の繰り返し (\d+) 回", text)
    if not m:
        bad.append("画面の繰り返しの回数が残っていない")
    else:
        ticks = int(m.group(1))
        # 80ms ごとなので、動いた秒数 × 5 回は最低限ある
        # ★動いた秒数は、プロセスの寿命ではなく**ログの最初の行から
        # 「画面の繰り返し」の行まで**で測る。PC が混んでいると終了に
        # 30 秒以上かかる回があり、その時間まで数えて「止まった」と
        # 誤判定していた（2026-10-05、今朝のコードでも同じだった）。
        stamps = re.findall(
            r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d,\d+)", text, re.M)
        alive = result["elapsed"]
        tick_line = re.search(
            r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d,\d+).*画面の繰り返し",
            text, re.M)
        if stamps and tick_line:
            from datetime import datetime  # noqa: PLC0415
            fmt = "%Y-%m-%d %H:%M:%S,%f"
            alive = (datetime.strptime(tick_line.group(1), fmt)
                     - datetime.strptime(stamps[0], fmt)).total_seconds()
        least = int(alive * 5)
        if ticks < least:
            bad.append(f"画面の繰り返しが {ticks} 回しかない"
                       f"（{least} 回以上のはず＝途中で止まった）")

    # 入力先の切り替わり：一瞬だけなら続け、移ったままなら止める
    moved = "入力先が変わったので録音を止めます" in text
    if name == "focus_blip":
        if moved:
            bad.append("一瞬だけ出た窓で録音を止めた")
        if "一瞬だけ前に出た窓" not in text:
            bad.append("一瞬だけ出た窓を見分けていない")
    elif name == "focus" and not moved:
        bad.append("別の窓へ移ったのに録音を止めていない")
    released = "キーを離したので止めます" in text
    if name in ("hold", "auto_hold") and not released:
        bad.append("キーを離しても止まっていない")
    if name == "auto_tap" and released:
        bad.append("短く押しただけなのに、離したところで止めた")
    if name == "pause" and not ("一時停止: した" in text
                                and "一時停止: やめた" in text):
        bad.append("一時停止と再開が記録されていない")

    # ショートカットの登録が外れたままになっていないか
    if "ショートカットの登録が外れました" in text:
        bad.append("ショートカットの登録が外れた")

    return bad, {"starts": len(starts), "ends": ends, "forced": forced,
                 "ticks": int(m.group(1)) if m else 0}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--only", action="append", default=[],
                    help="この名前の場合だけ動かす")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    if args.list:
        for key, (title, _) in CASES.items():
            print(f"  {key:12} {title}")
        return 0

    names = args.only or list(CASES)
    print("=" * 70)
    print(" 状態の移り方の検証（本物のキーもクリックも送りません）")
    print("=" * 70)

    wav = AUDIO / "j01.wav"
    if not wav.is_file():
        print(f"  音声が見つかりません: {wav}")
        return 1

    ok = 0
    for name in names:
        title, build = CASES[name]
        script, want = build()
        print(f"\n■ {name}  {title}")
        # 前の回のログが混ざらないよう、毎回まっさらにする
        shutil.rmtree(TMP / name, ignore_errors=True)
        home = make_home(TMP / name, {
            "input_mode": "stream",
            "guardian": False,
            "stop_on_silence_ms": 10000,
            "stop_on_window_change": "stop",
            "stop_on_click": "any",
            "shutdown_wait_ms": 3000,
            **CASE_CONFIG.get(name, {}),
        })
        last = max(r["at"] for r in script)
        result = run_app(home, wav, script, timeout=last + 90)
        bad, nums = judge(name, result, want)
        print(f"    開始 {nums['starts']} 回 / 終わり {nums['ends']} 回 / "
              f"画面の繰り返し {nums['ticks']} 回 / "
              f"強制復帰 {nums['forced']} 回 / {result['elapsed']:.1f}s")
        if bad:
            for line in bad:
                print(f"    NG  {line}")
            tail = result["stderr"][-400:] if result["stderr"] else ""
            if tail.strip():
                print(f"    （標準エラー）{tail}")
        else:
            print("    合格")
            ok += 1

    print("\n" + "=" * 70)
    print(f" {ok}/{len(names)} 合格")
    print("=" * 70)
    return 0 if ok == len(names) else 1


if __name__ == "__main__":
    raise SystemExit(main())
