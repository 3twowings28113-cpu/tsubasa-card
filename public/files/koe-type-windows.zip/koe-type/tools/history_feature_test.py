r"""履歴の前後比較・貼り直し（入力）・コピー機能のテスト。

本物のキー送信やウィンドウ操作は一切行わず、
から打ちモード（KOE_TYPE_DRY_RUN=1）で検証する。

  python tools\history_feature_test.py
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_sandbox = Path(tempfile.mkdtemp(prefix="koe-type-hist-test-"))
(_sandbox / "logs").mkdir()
(_sandbox / "data").mkdir()
os.environ["KOE_TYPE_HOME"] = str(_sandbox)
os.environ["KOE_TYPE_DRY_RUN"] = "1"
os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

from app import configstore, dryrun, history, textproc, websettings
from app.main import Controller

passed = 0
failed = 0


def check(name: str, got: object, want: object) -> None:
    global passed, failed
    if got == want:
        print(f"  OK   {name}")
        passed += 1
    else:
        print(f"  NG   {name}")
        print(f"       期待: {want!r}")
        print(f"       実際: {got!r}")
        failed += 1


def main() -> None:
    print("=" * 60)
    print(" 履歴の前後比較・貼り直し・コピー機能テスト")
    print("=" * 60)

    db_path = _sandbox / "data" / "history.db"
    hist = history.History(db_path)

    # 1. raw_text の保存と取得
    print("\n[1] 履歴の生テキスト（raw_text）の保存と取得")
    hist.add("サイバーエージェントに行きます",
             raw_text="さいばーえーじぇんとにいきます",
             model="sensevoice-resident")
    rows = hist.recent(10)
    check("1件取得できる", len(rows), 1)
    check("整形後テキストが正しい", rows[0]["text"], "サイバーエージェントに行きます")
    check("生テキストが正しい", rows[0]["raw_text"], "さいばーえーじぇんとにいきます")

    # raw_text 省略時の互換性
    hist.add("ふつうの文です")
    rows2 = hist.recent(10)
    check("raw_text省略時はtextと同じ", rows2[0]["raw_text"], "ふつうの文です")

    # 2. WebSettings Bridge._history() の出力
    print("\n[2] WebSettings の履歴状態（Bridge._history）")
    cfg = configstore.Config(_sandbox / "config.json")
    dict_obj = textproc.Dictionary(_sandbox / "dictionary.txt")
    bridge = websettings.Bridge(cfg, dict_obj, hist, lambda name, **kw: None)
    h_state = bridge._history()
    check("Bridge から履歴が返る", len(h_state), 2)
    check("Bridge に raw_text が含まれる", h_state[1]["raw_text"], "さいばーえーじぇんとにいきます")

    # 3. Controller との連携（paste_text / copy）
    print("\n[3] WebUI からの貼り直し（再入力）とコピーのアクション")
    ctl = Controller()
    bridge_live = websettings.Bridge(ctl.cfg, ctl.dictionary, ctl.history,
                                     ctl._settings_action)

    dryrun.reset()
    res_paste = bridge_live.run_action("paste_text", {"text": "もう一度入れるテキスト"})
    check("paste_text が成功を返す", res_paste.get("ok"), True)
    paste_entries = [e for e in dryrun.entries() if e.get("kind") in ("paste", "type")]
    check("dryrun に入力の記録がある", len(paste_entries) > 0, True)
    check("入力された文字が正しい", paste_entries[-1].get("text"), "もう一度入れるテキスト")

    res_copy = bridge_live.run_action("copy", {"text": "コピーするテキスト"})
    check("copy が成功を返す", res_copy.get("ok"), True)
    clip_entries = [e for e in dryrun.entries() if e.get("kind") == "clipboard"]
    check("dryrun にクリップボードの記録がある", len(clip_entries) > 0, True)
    check("コピーされた文字が正しい", clip_entries[-1].get("text"), "コピーするテキスト")

    # 4. セッション追記（append）と結合（merge）
    print("\n[4] セッションまとめ（append）と手動結合（merge）")
    # append
    eid1 = hist.add("最初の文です", raw_text="さいしょのぶんです", session_id=101)
    check("add が ID を返す", isinstance(eid1, int) and eid1 > 0, True)
    ok_app = hist.append(eid1, "次の文です", raw_text="つぎのぶんです", seconds=1.5)
    check("append が成功する", ok_app, True)
    row_merged = hist.recent(1)[0]
    check("追記後のテキストが結合されている", row_merged["text"], "最初の文です 次の文です")
    check("追記後の生テキストが結合されている", row_merged["raw_text"], "さいしょのぶんです つぎのぶんです")

    # merge
    eid_a = hist.add("プレゼンのやつ私しとくね")
    eid_b = hist.add("なんかね思ったんだけど")
    merged_id = hist.merge([eid_a, eid_b])
    check("merge が成功する", merged_id is not None, True)
    row_m = [r for r in hist.recent(10) if r["id"] == merged_id][0]
    check("時系列順（古い順）に結合される", row_m["text"], "プレゼンのやつ私しとくね なんかね思ったんだけど")

    # Bridge run_action history_merge
    eid_c = hist.add("Aパート")
    eid_d = hist.add("Bパート")
    res_m = bridge.run_action("history_merge", {"ids": [eid_c, eid_d]})
    check("Bridge history_merge が成功する", res_m.get("ok"), True)

    # 5. Controller の同一セッションまとめ
    print("\n[5] Controller の _remember で同一セッションが自動でまとまること")
    ctl._session_entry_ids.clear()
    s_id = 999
    c_eid1 = ctl._remember("パート1", b"\x00" * 3200, raw_text="ぱーと1", session=s_id)
    c_eid2 = ctl._remember("パート2", b"\x00" * 3200, raw_text="ぱーと2", session=s_id)
    check("同じセッションでは同じ entry_id に追記される", c_eid1 == c_eid2, True)
    ctl_recent = ctl.history.recent(1)[0]
    check("Controller 経由の履歴が1行にまとまっている", ctl_recent["text"], "パート1 パート2")

    print(f"\n==== 成功 {passed} / 失敗 {failed} ====")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
