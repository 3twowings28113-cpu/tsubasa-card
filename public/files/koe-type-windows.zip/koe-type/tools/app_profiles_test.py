"""アプリ連動スマートプロファイルの単体・結合テスト。

前面ウィンドウのアプリ（Slack/Discord/Word等）に応じて
性格・変換アクションが安全に自動切り替えされることを検証する。
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))



def test_app_profiles_logic() -> None:
    # 模擬の設定
    defaults = {
        "app_profiles_enabled": False,
        "app_profiles": {
            "slack.exe": "custom_instruction_polite",
            "discord.exe": "custom_instruction_polite",
            "code.exe": "custom_instruction_proofread",
            "winword.exe": "custom_instruction_polite",
        },
    }

    # 1. 無効時（既定）はどんなアプリでも切り替わらない
    def resolve_action(exe: str, user_action: str, enabled: bool,
                       profiles: dict[str, str]) -> str:
        action = user_action
        if not action and enabled:
            for pat, act in profiles.items():
                if pat.lower() in exe.lower():
                    action = act
                    break
        return action

    # 無効時
    assert resolve_action("slack.exe", "", False, defaults["app_profiles"]) == ""
    assert resolve_action("code.exe", "", False, defaults["app_profiles"]) == ""

    # 有効時
    assert resolve_action("slack.exe", "", True,
                          defaults["app_profiles"]) == "custom_instruction_polite"
    assert resolve_action("code.exe", "", True,
                          defaults["app_profiles"]) == "custom_instruction_proofread"
    assert resolve_action("notepad.exe", "", True,
                          defaults["app_profiles"]) == ""  # 未登録は通常入力

    # ユーザーが明示的に選択している場合は上書きしない
    assert resolve_action("slack.exe", "custom_instruction_summary", True,
                          defaults["app_profiles"]) == "custom_instruction_summary"

    print("[OK] アプリ連動プロファイルの全判定ロジック検証合格")


def main() -> None:
    print("=== アプリ連動プロファイルテスト開始 ===")
    test_app_profiles_logic()
    print("=== 全テスト成功 ===")


if __name__ == "__main__":
    main()
