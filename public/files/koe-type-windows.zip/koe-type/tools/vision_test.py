"""画面AIアシスタント（ジャービス）およびカレンダー連携のテスト。

- ctypes GDI+ によるスクリーンキャプチャ（pip一切不要）
- Googleカレンダー予定作成URL生成
- 画面マルチモーダル解析の安全なフォールバック
を検証する。
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.transform import build_google_calendar_url, process_screen_assistant  # noqa: E402
from app.vision import capture_window_or_screen  # noqa: E402


def test_calendar_url_builder() -> None:
    # 2026年10月25日 14:00〜15:00 の打ち合わせ
    url = build_google_calendar_url(
        title="新規事業ミーティング",
        start_dt="20261025T140000",
        end_dt="20261025T150000",
        details="Facebookメッセンジャーでの約束",
        location="オンライン",
    )
    assert url.startswith("https://calendar.google.com/calendar/render?action=TEMPLATE")
    assert "20261025T140000" in url
    assert "20261025T150000" in url
    assert "action=TEMPLATE" in url
    print("[OK] GoogleカレンダーURL生成テスト合格")


def test_screen_capture_dryrun() -> None:
    os.environ["KOE_TYPE_DRY_RUN"] = "1"
    jpeg_bytes = capture_window_or_screen(0)
    assert len(jpeg_bytes) > 0
    # JPEG マジックバイト確認
    assert jpeg_bytes[:2] == b"\xff\xd8"
    assert jpeg_bytes[-2:] == b"\xff\xd9"
    print(f"[OK] ドライラン画面キャプチャ検証合格: {len(jpeg_bytes)} bytes")


def test_process_screen_assistant_offline() -> None:
    dummy_jpeg = b"\xff\xd8\xff\xd9"
    # オフラインモードでの呼び出し
    mode, text, url = process_screen_assistant(
        "画面を見てこれ要約して",
        dummy_jpeg,
        api_key="",
        is_offline=True,
    )
    assert mode == "answer"
    assert "API キー" in text
    assert url == ""
    print("[OK] オフライン時安全フォールバック検証合格")


def main() -> None:
    print("=== 画面AIアシスタント・カレンダー連携テスト開始 ===")
    test_calendar_url_builder()
    test_screen_capture_dryrun()
    test_process_screen_assistant_offline()
    print("=== 全テスト成功 ===")


if __name__ == "__main__":
    main()
