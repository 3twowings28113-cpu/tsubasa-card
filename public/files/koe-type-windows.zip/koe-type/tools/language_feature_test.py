"""言語切り替え機能（トレイメニュー・ショートカット・音声コマンド）の自動テスト。

本物のキー送信やマイク録音は一切行わない（KOE_TYPE_DRY_RUN=1）。
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TMPDIR = tempfile.TemporaryDirectory(prefix="koe-type-lang-test-")
os.environ["KOE_TYPE_HOME"] = TMPDIR.name
os.environ["KOE_TYPE_DRY_RUN"] = "1"
sys.path.insert(0, str(ROOT))

from app import configstore, jatext, main, schema, winthread  # noqa: E402


def test_schema_item() -> None:
    print("=== 1. スキーマ定義の検証 ===")
    item = schema.find("hotkey_language")
    assert item is not None, "hotkey_language should exist in schema"
    assert item.kind == "hotkey"
    assert item.default == ""
    print("OK: hotkey_language defined in schema")


def test_quick_settings_and_tray() -> None:
    print("\n=== 2. クイック設定とトレイディスパッチの検証 ===")
    cfg = configstore.Config()
    cfg.set("language", "en")

    ctl = main.Controller()
    qs = ctl._quick_settings()
    assert qs.get("language") == "en", f"Expected language 'en', got {qs.get('language')}"

    # トレイメニューからの言語変更
    ctl._menu("lang:ja")
    assert ctl.cfg.str_("language") == "ja", "Language should be updated to 'ja'"

    ctl._menu("lang:auto")
    assert ctl.cfg.str_("language") == "auto", "Language should be updated to 'auto'"
    print("OK: Tray menu changes language in controller")


def test_toggle_language() -> None:
    print("\n=== 3. 言語トグル（巡回）の検証 ===")
    ctl = main.Controller()
    ctl.cfg.set("language", "ja")

    # ja -> en
    ctl._toggle_language()
    assert ctl.cfg.str_("language") == "en"

    # en -> auto
    ctl._toggle_language()
    assert ctl.cfg.str_("language") == "auto"

    # auto -> ja
    ctl._toggle_language()
    assert ctl.cfg.str_("language") == "ja"
    print("OK: Language toggles ja -> en -> auto -> ja")


def test_voice_commands_language() -> None:
    print("\n=== 4. 音声コマンドによる言語切り替えの検証 ===")
    ctl = main.Controller()
    ctl.cfg.set("language", "ja")

    # 「英語モード」
    handled = ctl._run_command("英語モード", "", 1)
    assert handled is True
    assert ctl.cfg.str_("language") == "en"

    # 「日本語モード」
    handled = ctl._run_command("日本語モード", "", 2)
    assert handled is True
    assert ctl.cfg.str_("language") == "ja"

    # 「言語切り替え」
    handled = ctl._run_command("言語切り替え", "", 3)
    assert handled is True
    assert ctl.cfg.str_("language") == "en"
    print("OK: Voice commands switch language accurately")


def test_winthread_hotkey_config() -> None:
    print("\n=== 5. WinThread へのホットキー設定の検証 ===")
    events = []
    wt = winthread.WinThread(
        on_hotkey_down=lambda: None,
        on_hotkey_up=lambda: None,
        on_send=lambda: None,
        on_cancel=lambda: None,
        on_menu=lambda name: events.append(name),
        is_recording=lambda: False,
        on_toggle_lang=lambda: events.append("toggle_lang"),
    )

    # configure with lang_hotkey
    wt.configure(
        hotkey="ctrl+space",
        cancel_hotkey="esc",
        hold_mode=False,
        enter_sends=True,
        excluded=[],
        show_tray=True,
        lang_hotkey="ctrl+shift+l",
    )
    assert wt.lang_vk != 0, "lang_vk should be configured"
    assert "ctrl" in wt.lang_mods and "shift" in wt.lang_mods

    # hotkey_fired
    wt._hotkey_fired(winthread.inputwatch.ID_TOGGLE_LANG)
    assert "toggle_lang" in events, "on_toggle_lang callback should have fired"
    print("OK: WinThread configures and fires lang hotkey correctly")


if __name__ == "__main__":
    try:
        test_schema_item()
        test_quick_settings_and_tray()
        test_toggle_language()
        test_voice_commands_language()
        test_winthread_hotkey_config()
        print("\nAll language feature tests passed successfully!")
    finally:
        try:
            TMPDIR.cleanup()
        except OSError:
            pass
