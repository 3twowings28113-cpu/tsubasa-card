"""koe-type のアイコンを生成する（全面リデザイン版）。

旧アイコンは写真から切り出した「マイク＋万年筆＋発光プラス＋星」で、
細部が多く、トレイの 16〜20px では潰れて何のアプリか分からなかった
（2026-10-26 本人の指摘）。新デザインは「小さいサイズでも判読できる」
ことだけを条件にした:

  ・派手な色の角丸スクエア（待機=オレンジ #FF8A00／録音中=赤
    #E0483A）の上に
  ・白抜きの太いマイクのシルエット（文字起こし中は音波バー）
  ・細線・グラデーション・発光は使わない

  待機の地は当初 紺 #242460 だったが、暗いトレイ背景に同化して
  見分けづらいと本人から指摘があり（2026-10-26）、鮮やかな
  オレンジに変更した。録音中の赤とは色相で見分けがつく。

描画は符号付き距離関数（SDF）をスーパーサンプリングする純粋な
Python 実装で、標準ライブラリだけで動く（gdiplus も元画像も不要）。
このスクリプトを実行するだけで、全サイズの .ico と PNG を
assets/icon/ へ再生成できる。

  python tools\\make_icons.py
"""
from __future__ import annotations

import math
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ASSETS_ICON = ROOT / "assets" / "icon"
OUT_PNG = ASSETS_ICON / "png"

SIZES = (16, 20, 24, 32, 48, 64, 128, 256)

ORANGE = (0xFF, 0x8A, 0x00)   # 待機・文字起こし中の地（暗背景でも沈まない橙）
RED = (0xE0, 0x48, 0x3A)      # 録音中の地
WHITE = (0xFF, 0xFF, 0xFF)


# ---------------------------------------------------------------- 形（SDF）
# 座標は 0..1 のキャンバス（y は下向き）。戻り値が負なら形の内側。

def _seg_dist(px: float, py: float, ax: float, ay: float,
              bx: float, by: float) -> float:
    """点と線分の距離。"""
    dx, dy = bx - ax, by - ay
    t = ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)
    t = 0.0 if t < 0.0 else (1.0 if t > 1.0 else t)
    cx, cy = ax + t * dx, ay + t * dy
    return math.hypot(px - cx, py - cy)


def _box_sdf(px: float, py: float, cx: float, cy: float,
             hx: float, hy: float, r: float) -> float:
    """角丸矩形の SDF（中心 cx,cy／半幅 hx,hy／角 r）。"""
    qx = abs(px - cx) - (hx - r)
    qy = abs(py - cy) - (hy - r)
    ox = qx if qx > 0.0 else 0.0
    oy = qy if qy > 0.0 else 0.0
    return math.hypot(ox, oy) + min(max(qx, qy), 0.0) - r


def bg_sdf(px: float, py: float) -> float:
    """地の角丸スクエア。枠いっぱいに置く（余白 0.025）。"""
    return _box_sdf(px, py, 0.5, 0.5, 0.475, 0.475, 0.23)


def mic_sdf(px: float, py: float) -> float:
    """太いマイク: カプセル本体＋受け皿の弧＋脚＋台座。"""
    d = _seg_dist(px, py, 0.5, 0.27, 0.5, 0.40) - 0.125
    # 受け皿: 中心 (0.5, 0.42)・半径 0.245 の輪の下半分（太さ 0.05）
    ring = abs(math.hypot(px - 0.5, py - 0.42) - 0.245) - 0.05
    cradle = max(ring, 0.40 - py)
    ex = math.sqrt(max(0.0, 0.245 * 0.245 - 0.02 * 0.02))
    cap_l = math.hypot(px - (0.5 - ex), py - 0.40) - 0.05
    cap_r = math.hypot(px - (0.5 + ex), py - 0.40) - 0.05
    d = min(d, cradle, cap_l, cap_r)
    d = min(d, _box_sdf(px, py, 0.5, 0.685, 0.034, 0.075, 0.03))   # 脚
    d = min(d, _box_sdf(px, py, 0.5, 0.775, 0.155, 0.033, 0.03))   # 台座
    return d


def bars_sdf(px: float, py: float) -> float:
    """音波バー 3 本（文字起こし中用）。マイクとは輪郭で区別する。"""
    d = _seg_dist(px, py, 0.295, 0.40, 0.295, 0.60) - 0.078
    d = min(d, _seg_dist(px, py, 0.5, 0.27, 0.5, 0.73) - 0.078)
    d = min(d, _seg_dist(px, py, 0.705, 0.40, 0.705, 0.60) - 0.078)
    return d


# ---------------------------------------------------------------- 描画

def _supersample(size: int) -> int:
    if size <= 24:
        return 8
    if size <= 32:
        return 6
    if size <= 64:
        return 4
    if size <= 128:
        return 3
    return 2


def render(size: int, bg_rgb: tuple[int, int, int], glyph) -> bytearray:
    """1 サイズぶんの RGBA を描く（プリマルチプライドで平均）。"""
    ss = _supersample(size)
    sub = 1.0 / (size * ss)          # サブピクセルの一辺（単位座標）
    out = bytearray(size * size * 4)
    for y in range(size):
        for x in range(size):
            acc_r = acc_g = acc_b = acc_a = 0.0
            for sy in range(ss):
                py = (y * ss + sy + 0.5) * sub
                for sx in range(ss):
                    px = (x * ss + sx + 0.5) * sub
                    a_bg = 0.5 - bg_sdf(px, py) / sub
                    a_bg = 0.0 if a_bg < 0.0 else (1.0 if a_bg > 1.0
                                                  else a_bg)
                    if a_bg <= 0.0:
                        continue
                    a_fg = 0.5 - glyph(px, py) / sub
                    a_fg = 0.0 if a_fg < 0.0 else (1.0 if a_fg > 1.0
                                                   else a_fg)
                    rest = a_bg * (1.0 - a_fg)
                    acc_r += WHITE[0] * a_fg + bg_rgb[0] * rest
                    acc_g += WHITE[1] * a_fg + bg_rgb[1] * rest
                    acc_b += WHITE[2] * a_fg + bg_rgb[2] * rest
                    acc_a += a_fg + rest
            n = float(ss * ss)
            alpha = acc_a / n
            idx = (y * size + x) * 4
            if alpha > 0.0:
                out[idx] = int(round(acc_r / n / alpha))
                out[idx + 1] = int(round(acc_g / n / alpha))
                out[idx + 2] = int(round(acc_b / n / alpha))
                out[idx + 3] = int(round(alpha * 255.0))
    return out


def build_layers(bg_rgb: tuple[int, int, int],
                 glyph) -> dict[int, bytearray]:
    return {sz: render(sz, bg_rgb, glyph) for sz in SIZES}


# ---------------------------------------------------------------- ICO/PNG

def _bmp_entry(size: int, rgba: bytearray) -> bytes:
    """ICO 内の 256px 未満のエントリ用ビットマップデータを生成。"""
    header = struct.pack("<IiiHHIIiiII", 40, size, size * 2, 1, 32, 0,
                         size * size * 4, 0, 0, 0, 0)
    body = bytearray()
    for y in range(size - 1, -1, -1):
        row = rgba[y * size * 4:(y + 1) * size * 4]
        for x in range(size):
            r, g, b, a = row[x * 4:x * 4 + 4]
            body += bytes((b, g, r, a))
    mask_row = (size + 31) // 32 * 4
    return header + bytes(body) + bytes(mask_row * size)


def _write_png_bytes(size: int, rgba: bytearray) -> bytes:
    """PNG 形式のバイナリバイト列を生成（zlib 圧縮）。"""
    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    raw = bytearray()
    for y in range(size):
        raw.append(0)
        raw += rgba[y * size * 4:(y + 1) * size * 4]

    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR",
                    struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
            + chunk(b"IEND", b""))


def write_ico_file(out_ico: Path, layers: dict[int, bytearray]) -> None:
    """全サイズを含むマルチサイズ .ico をファイルに書き出す。"""
    sorted_sizes = sorted(layers.keys())
    entries, blobs = [], []
    offset = 6 + 16 * len(sorted_sizes)
    for sz in sorted_sizes:
        rgba = layers[sz]
        if sz >= 256:
            data = _write_png_bytes(sz, rgba)
        else:
            data = _bmp_entry(sz, rgba)
        entries.append(struct.pack("<BBBBHHII",
                                   sz & 0xFF, sz & 0xFF,
                                   0, 0, 1, 32, len(data), offset))
        blobs.append(data)
        offset += len(data)

    out_ico.parent.mkdir(parents=True, exist_ok=True)
    out_ico.write_bytes(
        struct.pack("<HHH", 0, 1, len(sorted_sizes))
        + b"".join(entries) + b"".join(blobs)
    )
    print(f"ICO OK: {out_ico.name} ({out_ico.stat().st_size} bytes)")


# ---------------------------------------------------------------- 配置

STATES = (
    # (状態名, 地の色, 図形)
    ("idle", ORANGE, mic_sdf),
    ("recording", RED, mic_sdf),
    ("transcribing", ORANGE, bars_sdf),
)


def deploy_all() -> None:
    """状態別アイコン（ICO・PNG）を生成して assets/icon/ へ置く。"""
    OUT_PNG.mkdir(parents=True, exist_ok=True)
    for name, bg_rgb, glyph in STATES:
        print(f"Building {name} icons...")
        layers = build_layers(bg_rgb, glyph)
        write_ico_file(ASSETS_ICON / f"koe-type-{name}.ico", layers)
        write_ico_file(ASSETS_ICON / f"speakpulse-{name}.ico", layers)
        for sz, rgba in layers.items():
            png_bytes = _write_png_bytes(sz, rgba)
            (OUT_PNG / f"{name}-{sz}.png").write_bytes(png_bytes)
            (OUT_PNG / f"speakpulse-{name}-{sz}.png").write_bytes(png_bytes)
    print("All icons successfully generated and deployed!")


if __name__ == "__main__":
    deploy_all()
