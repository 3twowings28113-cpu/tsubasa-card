r"""設定の案内（困りごとから探す）の自動テスト。

なぜこのテストが必要か
  「困りごとから探す」の案内項目が schema.py に存在しない設定キーを
  指していると、利用者が「この設定へ移動する」を押したときに
  何も起きない・画面が固まるなどの致命的な不具合になる。
  また、i18n の多言語文字列が欠けていると、英語環境などで
  「guide.xxx」のような生のキー名が画面に露出してしまう。
  このテストでキーの存在と日英の翻訳がそろっているかを厳格に確かめる。
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# 利用者の設定・辞書・履歴には触らない（使い捨ての環境を使う）
if not os.environ.get("KOE_TYPE_SELFTEST_HOME"):
    _sandbox = Path(tempfile.mkdtemp(prefix="koe-type-guide-test-"))
    (_sandbox / "logs").mkdir()
    (_sandbox / "data").mkdir()
    os.environ["KOE_TYPE_HOME"] = str(_sandbox)
    os.environ["KOE_TYPE_SELFTEST_HOME"] = str(_sandbox)
    os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

from app import guide, i18n, schema  # noqa: E402


def test_guide_topics_validity() -> None:
    """全トピックの設定キーとカテゴリが実在するか検証する。"""
    defaults = schema.defaults()
    categories = {cat.key for cat in schema.CATEGORIES}
    categories.update({"models", "dictionary", "history"})

    known_keys = set(defaults.keys())
    known_keys.update({"model", "dictionary", "history"})

    assert len(guide.GUIDE_TOPICS) >= 10, "トピック数が少なすぎます"

    for topic in guide.GUIDE_TOPICS:
        # トピック自体のキー検証
        if topic.target_key:
            assert topic.target_key in known_keys, (
                f"トピック {topic.id} の target_key '{topic.target_key}' が "
                f"schema に存在しません"
            )
            cat = schema.find_category(topic.target_key)
            assert cat in categories, (
                f"トピック {topic.id} の target_key '{topic.target_key}' の "
                f"カテゴリ '{cat}' が存在しません"
            )

        # 選択肢がある場合のキー検証
        for ch in topic.choices:
            assert ch.target_key in known_keys, (
                f"トピック {topic.id} の選択肢 {ch.id} の target_key "
                f"'{ch.target_key}' が schema に存在しません"
            )
            cat = schema.find_category(ch.target_key)
            assert cat in categories, (
                f"トピック {topic.id} の選択肢 {ch.id} の target_key "
                f"'{ch.target_key}' のカテゴリ '{cat}' が存在しません"
            )


def test_guide_i18n_strings() -> None:
    """案内で使われている全文字列キーが日英両方で登録されているか検証する。"""
    for topic in guide.GUIDE_TOPICS:
        assert topic.title_key in i18n.STRINGS, (
            f"トピック {topic.id} の title_key '{topic.title_key}' が未定義"
        )
        assert topic.summary_key in i18n.STRINGS, (
            f"トピック {topic.id} の summary_key '{topic.summary_key}' が未定義"
        )
        ja_title, en_title = i18n.STRINGS[topic.title_key]
        assert ja_title and en_title, (
            f"title_key '{topic.title_key}' の日英が不完全"
        )

        ja_desc, en_desc = i18n.STRINGS[topic.summary_key]
        assert ja_desc and en_desc, (
            f"summary_key '{topic.summary_key}' の日英が不完全"
        )

        if topic.reason_key:
            assert topic.reason_key in i18n.STRINGS, (
                f"トピック {topic.id} の reason_key '{topic.reason_key}' が未定義"
            )
            ja_r, en_r = i18n.STRINGS[topic.reason_key]
            assert ja_r and en_r, (
                f"reason_key '{topic.reason_key}' の日英が不完全"
            )

        if topic.question_key:
            assert topic.question_key in i18n.STRINGS, (
                f"トピック {topic.id} の question_key '{topic.question_key}' が未定義"
            )
            ja_q, en_q = i18n.STRINGS[topic.question_key]
            assert ja_q and en_q, (
                f"question_key '{topic.question_key}' の日英が不完全"
            )

        for ch in topic.choices:
            assert ch.label_key in i18n.STRINGS, (
                f"選択肢 {ch.id} の label_key '{ch.label_key}' が未定義"
            )
            assert ch.reason_key in i18n.STRINGS, (
                f"選択肢 {ch.id} の reason_key '{ch.reason_key}' が未定義"
            )
            ja_ct, en_ct = i18n.STRINGS[ch.label_key]
            assert ja_ct and en_ct, f"label_key '{ch.label_key}' の日英が不完全"
            ja_cr, en_cr = i18n.STRINGS[ch.reason_key]
            assert ja_cr and en_cr, f"reason_key '{ch.reason_key}' の日英が不完全"


def test_serialize_guides() -> None:
    """Web 画面送信用データのシリアライズが正しく動くか検証する。"""
    data = guide.serialize_guides()
    assert isinstance(data, list)
    assert len(data) == len(guide.GUIDE_TOPICS)
    for item in data:
        assert "id" in item
        assert "category_tag" in item
        assert "title" in item
        assert "summary" in item
        assert "choices" in item


def main() -> int:
    print("設定の案内の検査を開始します...")
    test_guide_topics_validity()
    print("  OK   全トピックの設定キーとカテゴリの存在検証")
    test_guide_i18n_strings()
    print("  OK   全案内の日英翻訳キーの存在検証")
    test_serialize_guides()
    print("  OK   Web画面向けシリアライズ検証")
    print("すべての検査に合格しました。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
