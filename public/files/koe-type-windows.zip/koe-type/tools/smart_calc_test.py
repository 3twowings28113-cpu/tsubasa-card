"""スマート計算・日付音声入力機能の単体テスト。

完全オフラインで四則演算、税込/税抜、割引、相対日付が正確に
計算・変換されることを検証する。
"""

import sys
from pathlib import Path

# プロジェクトルートをパスに追加
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.transform import to_smart_calc_offline  # noqa: E402


def test_calculations() -> None:
    cases = [
        # 税込・税抜
        ("1000円の税込", "1,100円（税込）"),
        ("5000円の消費税込み", "5,500円（税込）"),
        ("1100円の税抜", "1,000円（税抜）"),
        # 割引
        ("10000円の20%オフ", "8,000円（20%オフ）"),
        ("5000円の3割引", "3,500円（3割引）"),
        ("3000円の半額", "1,500円（半額）"),
        # 四則演算
        ("1200かける3", "3,600"),
        ("10000わる4", "2,500"),
        ("500足す300", "800"),
        ("1000引く250", "750"),
    ]

    for speech, expected in cases:
        got = to_smart_calc_offline(speech)
        assert got == expected, f"Speech: {speech} -> Expected: {expected}, Got: {got}"
        print(f"[OK] {speech} -> {got}")


def test_dates() -> None:
    speech_list = ["今日", "明日", "明後日", "来週月曜日", "現在の時刻"]
    for sp in speech_list:
        res = to_smart_calc_offline(sp)
        assert res != sp, f"Date conversion failed for: {sp}"
        print(f"[OK] 日付・時刻: {sp} -> {res}")


def main() -> None:
    print("=== スマート計算・日付テスト開始 ===")
    test_calculations()
    test_dates()
    print("=== 全テスト成功 ===")


if __name__ == "__main__":
    main()
