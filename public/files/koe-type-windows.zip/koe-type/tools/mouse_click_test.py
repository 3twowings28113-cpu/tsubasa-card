"""stop_on_click（文字選択・上書きと入力欄外クリック停止）の単体テスト。

本物のキーやマウス入力は一切送信せず、ロジックと状態遷移を完全に検証する。
"""

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

# リポジトリ直下をパスに追加
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.mousewatch import MouseWatch


class DummyCfg:
    def __init__(self, settings: dict):
        self.d = settings

    def str_(self, key: str, default: str = "") -> str:
        return str(self.d.get(key, default))

    def int_(self, key: str, default: int = 0) -> int:
        return int(self.d.get(key, default))

    def bool_(self, key: str, default: bool = False) -> bool:
        return bool(self.d.get(key, default))


class TestMouseClickLogic(unittest.TestCase):
    def test_is_same_app_window(self):
        """同一ウィンドウ・入力領域の判定テスト。"""
        from app.main import Controller

        ctrl = Controller.__new__(Controller)

        # 1. 無効値
        self.assertFalse(ctrl._is_same_app_window(0, 100))
        self.assertFalse(ctrl._is_same_app_window(100, 0))

        # 2. 完全一致
        self.assertTrue(ctrl._is_same_app_window(100, 100))

        # 3. GetAncestor による親子・祖先判定のモックテスト
        with patch("ctypes.windll.user32.GetAncestor") as mock_ga:
            # clicked_hwnd(101) の親(GA_PARENT=1)が target_hwnd(100)
            def mock_ancestor(hwnd, ga_type):
                if hwnd == 101 and ga_type == 1:
                    return 100
                if hwnd == 101 and ga_type in (2, 3):
                    return 100
                if hwnd == 100 and ga_type in (2, 3):
                    return 100
                # 別ウィンドウ 200
                if hwnd == 200 and ga_type in (2, 3):
                    return 200
                return 0

            mock_ga.side_effect = mock_ancestor

            # 子ウィンドウのクリック -> 同一と判定
            self.assertTrue(ctrl._is_same_app_window(101, 100))

            # 別ウィンドウ(200)のクリック -> 外と判定
            self.assertFalse(ctrl._is_same_app_window(200, 100))

    def test_on_click_outside_mode(self):
        """mode == outside 時の挙動テスト。"""
        from app.main import Controller

        ctrl = Controller.__new__(Controller)
        ctrl.recording = True
        ctrl.target_hwnd = 1000
        ctrl._last_insert_hwnd = 1000
        ctrl._last_insert_tail = "あいう"
        ctrl.win = MagicMock()
        ctrl.win.is_own_window.return_value = False
        ctrl._post = MagicMock()
        ctrl.cfg = DummyCfg({"stop_on_click": "outside"})

        # 同一ウィンドウの判定をモック
        with patch.object(ctrl, "_is_same_app_window") as mock_same:
            # 1. 入力欄内をクリック（同一ウィンドウ）
            mock_same.return_value = True
            stopped = ctrl._on_click(1001, False)
            self.assertFalse(stopped)
            self.assertEqual(ctrl._last_insert_hwnd, 0)
            self.assertEqual(ctrl._last_insert_tail, "")
            ctrl._post.assert_not_called()

            # 2. 入力欄外をクリック（別ウィンドウ）
            mock_same.return_value = False
            stopped = ctrl._on_click(2000, False)
            self.assertTrue(stopped)
            ctrl._post.assert_called_once_with("click_stop", outside=True)

    def test_on_click_off_mode(self):
        """mode == off 時の挙動テスト（止めない）。"""
        from app.main import Controller

        ctrl = Controller.__new__(Controller)
        ctrl.recording = True
        ctrl.target_hwnd = 1000
        ctrl._last_insert_hwnd = 1000
        ctrl._last_insert_tail = "テスト"
        ctrl.win = MagicMock()
        ctrl.win.is_own_window.return_value = False
        ctrl._post = MagicMock()
        ctrl.cfg = DummyCfg({"stop_on_click": "off"})

        # 外をクリックしても止めない
        stopped = ctrl._on_click(2000, False)
        self.assertFalse(stopped)
        self.assertEqual(ctrl._last_insert_hwnd, 0)
        ctrl._post.assert_not_called()

    def test_mousewatch_hit_lifecycle(self):
        """MouseWatch._hit の _fired ライフサイクルテスト。"""
        # 1回目は同一ウィンドウクリックで stopped=False
        # 2回目は別ウィンドウクリックで stopped=True
        # 3回目はすでに停止済みなので呼ばれない
        call_count = 0

        def fake_on_click(hwnd, held):
            nonlocal call_count
            call_count += 1
            if hwnd == 1000:
                return False  # 入力欄内（文字選択）: 継続
            return True  # 入力欄外: 停止

        watch = MouseWatch(fake_on_click)

        # 1回目: 入力欄内（文字選択）
        with patch("app.mousewatch._window_under_cursor", return_value=1000):
            watch._hit("左")
            self.assertEqual(call_count, 1)
            self.assertFalse(watch._fired, "入力欄内選択時はまだ _fired にならないこと")

        # 2回目: 再度文字選択（複数回クリックやドラッグ）
        with patch("app.mousewatch._window_under_cursor", return_value=1000):
            watch._hit("左")
            self.assertEqual(call_count, 2)
            self.assertFalse(watch._fired, "2回目の選択でも _fired にならないこと")

        # 3回目: 外をクリック
        with patch("app.mousewatch._window_under_cursor", return_value=2000):
            watch._hit("左")
            self.assertEqual(call_count, 3)
            self.assertTrue(watch._fired, "外クリックで停止した時に _fired になること")

        # 4回目: すでに _fired のため呼ばれない
        with patch("app.mousewatch._window_under_cursor", return_value=2000):
            watch._hit("左")
            self.assertEqual(call_count, 3, "停止後は無視されること")

    def test_focus_restoration_logic(self):
        """音声入力終了時および貼り付け時のフォーカス復帰テスト。"""
        from app import inject
        from app.main import Controller

        # 1. dryrun 下での activate_window
        with patch("app.dryrun.enabled", return_value=True):
            res = inject.activate_window(1000, 2000)
            self.assertTrue(res)

        # 2. paste_text でのフォーカス自動復帰
        with patch("app.dryrun.enabled", return_value=True), \
             patch("app.inject.foreground", side_effect=[9999, 1000, 1000]), \
             patch("app.inject.activate_window", return_value=True) as mock_act:
            res = inject.paste_text("テスト入力", target_hwnd=1000,
                                    target_focus=2000, restore_target=True)
            self.assertEqual(res, inject.PASTED)
            mock_act.assert_called_once_with(1000, 2000)

        # 3. Controller の _stop_recording 時のフォーカス復帰
        ctrl = Controller.__new__(Controller)
        ctrl.recording = True
        ctrl.target_hwnd = 1000
        ctrl.target_focus_hwnd = 2000
        ctrl.cfg = DummyCfg({"restore_focus_on_finish": True})
        ctrl.mouse = MagicMock()
        ctrl.win = MagicMock()
        ctrl.recorder = MagicMock()
        ctrl.overlay = MagicMock()
        ctrl.cutter = MagicMock()
        ctrl.cutter.flush.return_value = []
        ctrl._work = MagicMock()
        ctrl._lock = MagicMock()
        ctrl._agree_lock = MagicMock()
        ctrl.session = 1
        ctrl.utterance = 0
        ctrl._current_action = ""
        ctrl._action_pcm = bytearray()
        ctrl.agreement = MagicMock()
        ctrl.agreement.pending.return_value = ""
        ctrl._types_while_speaking = MagicMock(return_value=False)
        ctrl._tray_state = MagicMock()
        ctrl._restore_audio = MagicMock()
        ctrl._play_sound = MagicMock()
        ctrl._join_stream = MagicMock()

        with patch("app.inject.activate_window") as mock_act:
            ctrl._stop_recording(submit=False)
            mock_act.assert_called_once_with(1000, 2000)


if __name__ == "__main__":
    unittest.main()

