r"""新しい PC で初めて入れる流れを確かめる。

★なぜ作ったか
  文字起こしのエンジン（transcribe.cpp）は tar.gz で配られているのに、
  ダウンロードの処理が zip しか開けず、**新しい PC の初回の案内で必ず
  失敗していた**（2026-10-05 発覚）。開発した PC には別の方法で
  エンジンを入れていたので、ずっと気づかなかった。
  「この PC ではもう入っているから確かめられない」を、空のフォルダで
  作り直して確かめる。

    python tools\fresh_install_test.py             # 取り出し方だけ（通信なし）
    python tools\fresh_install_test.py --network   # 本物を落として文字起こしまで

キーは送らない。音はスピーカーで鳴らさず、WAV を直接読ませる。
利用者のフォルダ（engines / models / 設定）には一切触らない。
"""

from __future__ import annotations

import argparse
import io
import os
import subprocess
import sys
import tarfile
import tempfile
import time
import wave
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

ok = 0
ng: list[str] = []


def check(label: str, cond: bool, note: str = "") -> None:
    global ok
    if cond:
        ok += 1
        print(f"  OK   {label}{('  ' + note) if note else ''}")
    else:
        ng.append(label)
        print(f"  NG   {label}{('  ' + note) if note else ''}")


def make_tar(path: Path, files: dict[str, bytes]) -> None:
    with tarfile.open(path, "w:gz") as tar:
        for name, data in files.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))


def make_zip(path: Path, files: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "w") as zf:
        for name, data in files.items():
            zf.writestr(name, data)


def offline(tmp: Path) -> None:
    """手元で作った圧縮ファイルで、取り出し方を確かめる。"""
    from app import downloads  # noqa: PLC0415
    from app.catalog import Asset  # noqa: PLC0415

    print("\n[1] tar.gz をまるごと取り出す（エンジンと同じ形）")
    arc = tmp / "engine.tar.gz"
    make_tar(arc, {"pkg/a.dll": b"A", "pkg/sub/b.txt": b"B",
                   "pkg/mark.dll": b"M"})
    dest = tmp / "engines" / "tcpp" / "pkg" / "mark.dll"
    asset = Asset("tcpp/pkg/mark.dll", "file:///unused", 1, into="engines",
                  unzip_from="*")
    with downloads._Archive(arc) as box:
        downloads._extract(box, asset, dest)
    check("目印のファイルがある", dest.read_bytes() == b"M")
    check("ほかのファイルも並びを保って出る",
          (dest.parent / "sub" / "b.txt").read_bytes() == b"B")

    print("\n[2] zip から 1 つだけ取り出す")
    arc = tmp / "one.zip"
    make_zip(arc, {"x/tool.exe": b"T", "x/readme.txt": b"R"})
    dest = tmp / "engines" / "tool-renamed.exe"
    asset = Asset("tool-renamed.exe", "file:///unused", 1, into="engines",
                  unzip_from="tool.exe")
    with downloads._Archive(arc) as box:
        downloads._extract(box, asset, dest)
    check("名前を変えて取り出せる", dest.read_bytes() == b"T")

    print("\n[3] 外へ書かせない")
    arc = tmp / "evil.tar.gz"
    make_tar(arc, {"../../evil.dll": b"X", "pkg/mark.dll": b"M"})
    dest = tmp / "safe" / "pkg" / "mark.dll"
    asset = Asset("pkg/mark.dll", "file:///unused", 1, into="engines",
                  unzip_from="*")
    refused = False
    try:
        with downloads._Archive(arc) as box:
            downloads._extract(box, asset, dest)
    except downloads.DownloadError:
        refused = True
    check("「../」を含む圧縮ファイルは断る", refused)
    check("外にファイルができていない", not (tmp / "evil.dll").exists())

    print("\n[4] 圧縮ファイルでないものは断る")
    bad = tmp / "notarchive.bin"
    bad.write_bytes(b"<html>404</html>")
    refused = False
    try:
        with downloads._Archive(bad):
            pass
    except downloads.DownloadError:
        refused = True
    check("HTML などが届いたら断る", refused)


def network(tmp: Path) -> None:
    """空のフォルダへ本物を落として、文字起こしまで通す。"""
    from app import catalog, downloads, engines  # noqa: PLC0415

    print("\n[5] 本物を落として文字起こしまで（新しい PC と同じ）")
    key = catalog.DEFAULT_MODEL
    missing = catalog.missing_assets(key)
    total = sum(a.size for a in missing)
    check("空のフォルダでは、エンジンとモデルが足りない",
          len(missing) >= 2, f"{len(missing)} 個 / {total / 1e6:.0f} MB")
    started = time.monotonic()
    downloads.fetch_all(list(missing))
    took = time.monotonic() - started
    check("ダウンロードしてそろう",
          catalog.model_ready(key) and catalog.runtime_ready("tcpp"),
          f"{took:.1f} 秒")
    wav_path = ROOT / "bench" / "audio" / "j01.wav"
    if not wav_path.is_file():
        print("  （bench/audio/j01.wav が無いので、文字起こしは飛ばします）")
        return
    eng = engines.build(key, "ja")
    with wave.open(str(wav_path)) as w:
        pcm = w.readframes(w.getnframes())
    text = eng.transcribe_pcm(pcm, "")
    check("落としたエンジンとモデルで文字にできる", bool(text.strip()),
          text[:30])


def point_home(tmp: Path) -> None:
    """★app を読み込む前に、置き場所を全部使い捨てのフォルダへ向ける。

    利用者の engines / models / 設定には触らない。
    """
    os.environ["KOE_TYPE_HOME"] = str(tmp / "home")
    os.environ["KOE_TYPE_ENGINE_DIR"] = str(tmp / "engines")
    os.environ["KOE_TYPE_MODEL_DIR"] = str(tmp / "models")
    sys.path.insert(0, str(ROOT))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--network", action="store_true",
                    help="本物を落として文字起こしまで確かめる")
    ap.add_argument("--child", default="", help=argparse.SUPPRESS)
    args = ap.parse_args()

    if args.child:
        # 本物のダウンロードは別プロセスで。読み込んだ DLL はプロセスが
        # 終わるまで消せないので、親が後片付けできるようにする。
        point_home(Path(args.child))
        network(Path(args.child))
        return 1 if ng else 0

    print("=" * 70)
    print(" 新しい PC で初めて入れる流れ（利用者のフォルダには触りません）")
    print("=" * 70)
    child_failed = False
    with tempfile.TemporaryDirectory(prefix="koe-type-fresh-") as name:
        tmp = Path(name)
        point_home(tmp)
        offline(tmp)
        if args.network:
            net = tmp / "net"
            net.mkdir()
            child = subprocess.run(
                [sys.executable, __file__, "--child", str(net)],
                capture_output=True, text=True, encoding="utf-8",
                errors="replace", check=False)
            lines = [line for line in child.stdout.splitlines()
                     if not line.startswith(("ggml", "load_backend"))]
            print("\n".join(lines))
            child_failed = child.returncode != 0
            if child_failed:
                ng.append("本物のダウンロード（別プロセス）")
                print(child.stderr[-800:])
        else:
            print("\n（本物のダウンロードは --network を付けたときだけ）")

    print(f"\n==== 成功 {ok} / 失敗 {len(ng)} ====")
    for label in ng:
        print(f"  - {label}")
    return 1 if ng else 0


if __name__ == "__main__":
    raise SystemExit(main())
