"""モデルの精度と速さを測る。スピーカーもマイクも使わない。

測るもの
  ・文字誤り率（CER）：句読点・空白・全半角の差は無視する
  ・雑音を混ぜたときの崩れ方（SN比 20 / 10 / 5 dB）
  ・固有名詞の正解率（辞書のヒントあり／なし）
  ・1 件あたりの時間と、5 秒換算の時間
  ・無音・雑音だけで**1文字も出さないか**（幻覚の除外が効いているか）

    python tools/evaluate.py --set tts              # 合成音声 16 本
    python tools/evaluate.py --set fleurs --limit 50
    python tools/evaluate.py --set noise
    python tools/evaluate.py --set quiet
    python tools/evaluate.py --set all --model sensevoice-small
    python tools/evaluate.py --set tts --models sensevoice-small,funasr-nano

結果は bench/eval/results-<モデル>.json に書く（.gitignore 済み）。
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import unicodedata
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import catalog, engines  # noqa: E402
from app.textproc import Dictionary, is_hallucination, is_noise, tidy  # noqa: E402

EVAL = ROOT / "bench" / "eval"
FLEURS = ROOT / "bench" / "fleurs"
AUDIO = ROOT / "bench" / "audio"
PRIVATE = ROOT / "bench" / "private"

# 比べるときに無視するもの（句読点・空白・括弧）
_IGNORE = re.compile(r"[\s、。，．,.！？!?「」『』（）()\[\]・…ー~～\-〜　]+")


def normalise(text: str) -> str:
    """比較用にそろえる。全半角とかなの揺れは意味の差ではないので潰す。"""
    text = unicodedata.normalize("NFKC", text)
    return _IGNORE.sub("", text).lower()


def cer(reference: str, hypothesis: str) -> float:
    """文字誤り率。編集距離 / 正解の文字数。"""
    a, b = normalise(reference), normalise(hypothesis)
    if not a:
        return 0.0 if not b else 1.0
    # 編集距離（行を 1 本だけ持つ省メモリ版）
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1,
                         prev[j - 1] + (ca != cb))
        prev = cur
    return prev[-1] / len(a)


def seconds_of(path: Path) -> float:
    with wave.open(str(path)) as w:
        return w.getnframes() / w.getframerate()


# ---------------------------------------------------------------- 検査の集合


def load_truth(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    return json.loads(path.read_text("utf-8"))


def set_tts() -> list[tuple[Path, str]]:
    """Windows の読み上げ声で作った 16 本（ふつうの文＋固有名詞）。"""
    truth = load_truth(PRIVATE / "audio_truth.json")
    out = []
    for key, text in sorted(truth.items()):
        wav = AUDIO / f"{key}.wav"
        if wav.exists():
            out.append((wav, text))
    return out


def set_it() -> list[tuple[Path, str]]:
    """IT 用語の文。"""
    truth = load_truth(EVAL / "truth.json")
    out = []
    for key, text in sorted(truth.items()):
        if not key.startswith("t"):
            continue
        wav = EVAL / f"{key}.wav"
        if wav.exists():
            out.append((wav, text))
    return out


def set_noise() -> list[tuple[Path, str]]:
    """雑音を混ぜた版。"""
    truth = load_truth(EVAL / "truth.json")
    out = []
    for key, text in sorted(truth.items()):
        if "_" not in key or key.startswith("quiet"):
            continue
        wav = EVAL / f"{key}.wav"
        if wav.exists():
            out.append((wav, text))
    return out


def set_fleurs() -> list[tuple[Path, str]]:
    """FLEURS 日本語（公開データ）。"""
    truth = load_truth(FLEURS / "truth.json")
    out = []
    for key, text in sorted(truth.items()):
        wav = FLEURS / f"{key}.wav"
        if wav.exists():
            out.append((wav, text))
    return out


def set_real() -> list[tuple[Path, str]]:
    """利用者が自分のマイクで録った実音声（リポジトリには入れない）。"""
    truth = load_truth(PRIVATE / "real_truth.json")
    out = []
    for key, text in sorted(truth.items()):
        for folder in (AUDIO, ROOT / "bench" / "real"):
            wav = folder / f"{key}.wav"
            if wav.exists():
                out.append((wav, text))
                break
    return out


def set_quiet() -> list[tuple[Path, str]]:
    """無音と雑音だけ。正解は「空」。"""
    return [(p, "") for p in sorted(EVAL.glob("quiet_*.wav"))]


SETS = {"tts": set_tts, "it": set_it, "noise": set_noise,
        "fleurs": set_fleurs, "real": set_real, "quiet": set_quiet}


# ---------------------------------------------------------------- 測る


def run_set(engine, name: str, items: list[tuple[Path, str]], *,  # noqa: ANN001
            hints: str = "", clean: bool = True,
            dictionary: Dictionary | None = None) -> dict:
    if not items:
        print(f"  {name}: 音声がありません")
        return {}
    rows = []
    print(f"\n■ {name}（{len(items)} 本）")
    for index, (wav, truth) in enumerate(items, 1):
        secs = seconds_of(wav)
        t0 = time.perf_counter()
        try:
            raw = engine.transcribe(wav, hints)
        except Exception as exc:  # noqa: BLE001
            print(f"  {wav.stem}: 失敗 {exc}")
            continue
        took = time.perf_counter() - t0
        text = tidy(raw, punctuation=True, fillers=False, halfwidth=True)
        if dictionary is not None:
            text = dictionary.apply(text)
        dropped = ""
        if clean:
            if is_noise(text):
                dropped, text = "記号だけ", ""
            else:
                junk, why = is_hallucination(text, secs)
                if junk:
                    dropped, text = why, ""
        rows.append({
            "id": wav.stem, "seconds": round(secs, 2),
            "took": round(took, 3),
            "per5s": round(took / secs * 5, 3) if secs else 0,
            "truth": truth, "text": text, "dropped": dropped,
            "cer": round(cer(truth, text), 4) if truth else None,
        })
        if index <= 3 or index % 25 == 0 or len(items) <= 20:
            mark = f" ※捨てた（{dropped}）" if dropped else ""
            print(f"  {wav.stem:24s} {secs:5.1f}s {took:5.2f}s "
                  f"CER {rows[-1]['cer'] if truth else '-'}{mark}")
            if truth and rows[-1]["cer"] and rows[-1]["cer"] > 0.25:
                print(f"       正解: {truth[:70]}")
                print(f"       結果: {text[:70]}")

    scored = [r for r in rows if r["cer"] is not None]
    took_all = [r["took"] for r in rows]
    per5 = [r["per5s"] for r in rows if r["per5s"]]
    summary = {
        "count": len(rows),
        "cer": round(sum(r["cer"] for r in scored) / len(scored), 4)
        if scored else None,
        "took_avg": round(sum(took_all) / len(took_all), 3) if took_all else 0,
        "took_max": round(max(took_all), 3) if took_all else 0,
        "per5s_avg": round(sum(per5) / len(per5), 3) if per5 else 0,
        "empty": sum(1 for r in rows if not r["text"]),
        "dropped": sum(1 for r in rows if r["dropped"]),
    }
    if name == "quiet":
        leaked = [r for r in rows if r["text"]]
        summary["leaked"] = len(leaked)
        for r in leaked:
            print(f"  ★漏れた: {r['id']} -> {r['text']!r}")
        print(f"  → 1文字も出さなかった: "
              f"{len(rows) - len(leaked)}/{len(rows)} 本")
    else:
        print(f"  → CER {summary['cer']} / 1件 {summary['took_avg']}s "
              f"(最大 {summary['took_max']}s) / 5秒換算 "
              f"{summary['per5s_avg']}s / 空になった {summary['empty']} 本")
    return {"summary": summary, "rows": rows}


def noise_breakdown(result: dict) -> None:
    """雑音の種類と SN比ごとに分けて見せる。"""
    rows = result.get("rows") or []
    groups: dict[str, list[float]] = {}
    for r in rows:
        m = re.match(r".*_([a-z]+)(\d+)$", r["id"])
        if not m or r["cer"] is None:
            continue
        groups.setdefault(f"{m.group(1)} {m.group(2)}dB", []).append(r["cer"])
    if not groups:
        return
    print("\n  雑音の種類と SN比ごとの CER")
    label = {"pink": "ピンク", "babble": "ざわめき", "keys": "打鍵"}
    for key in sorted(groups, key=lambda k: (k.split()[0],
                                             -int(k.split()[1][:-2]))):
        kind, snr = key.split()
        values = groups[key]
        print(f"    {label.get(kind, kind):8s} {snr:>6s}  "
              f"CER {sum(values) / len(values):.4f}  ({len(values)} 本)")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--set", default="tts",
                    help="tts / it / noise / fleurs / real / quiet / all")
    ap.add_argument("--model", default="")
    ap.add_argument("--models", default="", help="カンマ区切りで複数")
    ap.add_argument("--limit", type=int, default=0, help="先頭 N 本だけ")
    ap.add_argument("--hints", action="store_true",
                    help="辞書を認識ヒントとして渡す")
    ap.add_argument("--raw", action="store_true",
                    help="幻覚の除外をせず、生の結果で測る")
    args = ap.parse_args()

    names = ([m.strip() for m in args.models.split(",") if m.strip()]
             or [args.model or catalog.DEFAULT_MODEL])
    wanted = (list(SETS) if args.set == "all" else
              [s.strip() for s in args.set.split(",") if s.strip()])

    dictionary = Dictionary(ROOT / "dictionary.sample.txt")
    hints = dictionary.hint_string() if args.hints else ""
    if hints:
        print(f"認識ヒント: {hints[:80]}")

    overall: dict[str, dict] = {}
    for model_key in names:
        print("\n" + "=" * 70)
        print(f" モデル: {model_key}")
        print("=" * 70)
        try:
            engine = engines.build(model_key, "ja")
        except Exception as exc:  # noqa: BLE001
            print(f" 使えません: {exc}")
            continue
        per_model: dict[str, dict] = {}
        for set_name in wanted:
            maker = SETS.get(set_name)
            if maker is None:
                print(f" そんな集合はありません: {set_name}")
                continue
            items = maker()
            if args.limit:
                items = items[:args.limit]
            result = run_set(engine, set_name, items, hints=hints,
                             clean=not args.raw, dictionary=dictionary)
            if result:
                per_model[set_name] = result
                if set_name == "noise":
                    noise_breakdown(result)
        overall[model_key] = per_model
        out = EVAL / f"results-{model_key}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(per_model, ensure_ascii=False, indent=1),
                       "utf-8")
        print(f"\n  書き出し: {out.relative_to(ROOT)}")

    print("\n" + "=" * 70)
    print(" まとめ")
    print("=" * 70)
    print(f" {'モデル':24s} {'集合':10s} {'CER':>8s} {'1件':>8s} {'5秒換算':>9s}")
    for model_key, sets in overall.items():
        for set_name, result in sets.items():
            s = result["summary"]
            cer_text = "-" if s["cer"] is None else f"{s['cer']:.4f}"
            extra = (f"  漏れ {s['leaked']}/{s['count']}"
                     if "leaked" in s else "")
            print(f" {model_key:24s} {set_name:10s} {cer_text:>8s} "
                  f"{s['took_avg']:7.2f}s {s['per5s_avg']:8.2f}s{extra}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
