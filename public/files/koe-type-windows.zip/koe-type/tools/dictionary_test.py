r"""ユーザー辞書（新機能：類似読み自動補正、および既存互換）の検証テスト。

マイクやスピーカーは使わない。キーも送らない。
  python tools\dictionary_test.py
"""

from __future__ import annotations

import sys
import tempfile
import time
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.textproc import Dictionary, to_hiragana, levenshtein_distance

ok = 0
ng = []

def check(label: str, got: object, expected: object) -> None:
    global ok
    if got == expected:
        ok += 1
        print(f"  OK   {label}")
    else:
        ng.append(label)
        print(f"  NG   {label}\n       期待: {expected!r}\n       実際: {got!r}")

def main() -> int:
    print("=" * 60)
    print(" ユーザー辞書のテスト（自動補正・既存互換・速度）")
    print("=" * 60)

    print("\n[1] 基本関数（ひらがな変換・編集距離）")
    check("カタカナがひらがなになる",
          to_hiragana("サイバーエージェント"), "さいばーえーじぇんと")
    check("全角英数がローマ字ひらがな化される",
          to_hiragana("Ｌａｂｏ１２３"), "らぼ123")
    check("完全一致の距離は0",
          levenshtein_distance("さいばー", "さいばー"), 0)
    check("1文字違いの距離は1",
          levenshtein_distance("さいばー", "さいば"), 1)
    check("max_dist超えで足切り",
          levenshtein_distance("さいばーえーじぇんと", "まったくちがう", 2) > 2, True)

    with tempfile.TemporaryDirectory(prefix="koe-type-dict-test-") as tmp:
        p = Path(tmp) / "dictionary.txt"

        print("\n[2] 新形式：表記のみ登録で類似読みを自動修正")
        p.write_text(
            "# ユーザー辞書テスト\n"
            "サイバーエージェント\n"
            "オープンLabo:おーぷんらぼ\n"
            "メモ\n"
            "裁判エージェント=サイバーエージェント\n"
            "re:^うん$=はい\n",
            encoding="utf-8"
        )
        d = Dictionary(p)

        # カタカナ語の自動補正（長音抜けなど）
        check("長音抜けの「サイバエージェント」が「サイバーエージェント」になる",
              d.apply("昨日はサイバエージェントへ行きました"),
              "昨日はサイバーエージェントへ行きました")
        check("ひらがな「さいばーえーじぇんと」が「サイバーエージェント」になる",
              d.apply("さいばーえーじぇんとの会議"),
              "サイバーエージェントの会議")

        # 漢字混じりの指定読み自動補正
        check("「おーぷんラボ」が「オープンLabo」になる",
              d.apply("おーぷんラボで打ち合わせ"),
              "オープンLaboで打ち合わせ")

        # 既存ルールの完全互換
        check("明示的な誤認識「裁判エージェント」も直る",
              d.apply("裁判エージェントです"),
              "サイバーエージェントです")
        check("正規表現「re:^うん$=はい」も効く",
              d.apply("うん"), "はい")

        # 短語の誤爆防止
        check("単独の「めも」は「メモ」に直る",
              d.apply("めもを取ります"), "メモを取ります")
        check("「ためらい」の中の「め」で誤爆しない",
              d.apply("ためらいながら話す"), "ためらいながら話す")

        # ヒント一覧
        hints = d.hints
        check("「サイバーエージェント」がヒントに入る", "サイバーエージェント" in hints, True)
        check("「オープンLabo」がヒントに入る", "オープンLabo" in hints, True)
        check("「メモ」がヒントに入る", "メモ" in hints, True)

        print("\n[3] 編集と保存・エクスポート")
        # detailed_entries の取得
        details = d.detailed_entries()
        check("詳細エントリが取得できる", len(details), 5)
        
        # 新しい表記を追加して保存
        details.append({"surface": "生成AI", "reading": "せいせいえーあい", "mishearing": ""})
        d.save(details)
        check("追加した語がすぐ反映される",
              d.apply("せいせいえーあいの活用"), "生成AIの活用")

        # エクスポート
        exp_text = d.export_text()
        check("エクスポートに新形式が含まれる", "生成AI:せいせいえーあい" in exp_text, True)

        print("\n[4] 処理速度の検証（10ms 以内）")
        # 100語のダミー語彙を追加して負荷測定
        heavy_entries = details + [
            {"surface": f"専門用語{i}", "reading": f"せんもんようご{i}ばん", "mishearing": ""}
            for i in range(100)
        ]
        d.save(heavy_entries)

        sentence = "昨日はサイバエージェントのオープンラボでせいせいえーあいのめもを取りました。"
        # ウォームアップ
        d.apply(sentence)

        t0 = time.perf_counter()
        N = 100
        for _ in range(N):
            res = d.apply(sentence)
        t1 = time.perf_counter()
        elapsed_per_call_ms = (t1 - t0) / N * 1000
        print(f"       100語辞書での1回あたり処理時間: {elapsed_per_call_ms:.2f} ms")
        check("1回の文変換が 10ms 以内に終わる", elapsed_per_call_ms < 10.0, True)
        check("複合文でも正しく置換される",
              res, "昨日はサイバーエージェントのオープンLaboで生成AIのメモを取りました。")

    print(f"\n==== 成功 {ok} / 失敗 {len(ng)} ====")
    if ng:
        print("失敗した項目:")
        for n in ng:
            print(f"  - {n}")
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
