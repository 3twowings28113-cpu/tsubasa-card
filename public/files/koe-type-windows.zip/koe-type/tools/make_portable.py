r"""署名済みの Python を同梱した「持ち運べる koe-type」を組み立てる。

受け取る人の PC に Python が入っていなくても動くようにする。
**新しい未署名の exe を 1 つも作らない**のが肝。

## なぜこの形か

- PyInstaller などで 1 つの exe にまとめると、**署名がないと
  Smart App Control にブロックされる**。署名しても SmartScreen の
  警告は評判が貯まるまで消えない。ウイルス対策の誤検知も増える。
- python.org が配る Python は `pythonw.exe` も `python3xx.dll` も
  **Python Software Foundation の署名つき**。これをそのまま持ってきて、
  koe-type は **.py のソースのまま**置けば、新しい exe は増えない。
- ソースが読めることは、「本当に外へ送っていない」ことの証明にもなる。

## できあがり

    dist/koe-type-portable/
      koe-type.cmd          これを実行すると起動する
      install.cmd           スタートメニューと自動起動に登録（管理者権限なし）
      uninstall.cmd         きれいに消す（データを残すか選べる）
      app/ tools/ docs/ …   koe-type 本体（ソース）
      runtime/              署名済みの Python
        pythonw.exe  python.exe  python3.dll  python3xx.dll
        vcruntime140.dll  vcruntime140_1.dll
        python3xx.zip     標準ライブラリ
        DLLs/             .pyd
        python3xx._pth    探す場所の指定

## 使い方

    python tools/make_portable.py
    python tools/make_portable.py --from C:\Python314
    python tools/make_portable.py --embeddable python-3.14.4-embed-amd64.zip
    python tools/make_portable.py --no-test     # 起動の確認をしない

**最後に必ず 1 回起動して、ブロックされないか確かめる**（`--no-test`
を付けない限り）。このプロジェクトの決まり。
"""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# koe-type が使う標準ライブラリのうち、入れないと動かないもの以外は
# 削って軽くする。削りすぎると「たまに落ちる」ので、迷ったら残す。
DROP_DIRS = {
    "test", "tests", "idlelib", "lib2to3", "turtledemo", "pydoc_data",
    "ensurepip", "distutils", "__pycache__", "site-packages",
    # tkinter は使わない（6.14）。入れると tcl/tk の dll まで要る
    "tkinter",
}
# 同梱しない拡張モジュール。tkinter とその土台の tcl/tk
DROP_DLLS = {"_tkinter.pyd", "tcl86t.dll", "tk86t.dll"}
DROP_FILES = {"turtle.py"}

# 同梱するもの（アプリ側）
APP_FILES = ("koe-type.pyw", "LICENSE", "README.md", "README.en.md",
             "CHANGELOG.md", "THIRD_PARTY_NOTICES.md",
             "dictionary.sample.txt")
APP_DIRS = ("app", "vendor", "tools", "docs", "assets/icon")
SKIP_PARTS = ("__pycache__", ".pyc", ".pyo")


def log(text: str) -> None:
    print(text, flush=True)


# ---------------------------------------------------------------- Python


def tag_of(prefix: Path) -> str:
    """python314 のような名前を、そのフォルダから見つける。"""
    for dll in prefix.glob("python3*.dll"):
        if dll.stem != "python3":
            return dll.stem
    raise SystemExit(f"python3xx.dll が見つかりません: {prefix}")


def copy_msvcp(out: Path) -> None:
    """Visual C++ ランタイムの msvcp140.dll を runtime\\ に置く。

    ★文字起こしのエンジン（transcribe.dll と ggml*.dll の 13 個すべて）が
    MSVCP140.dll に頼っている。Python は vcruntime140 しか同梱しない
    ので、Visual C++ 再頒布可能パッケージが入っていない、まっさらな
    PC では**エンジンを読めず、文字起こしが一切動かない**。
    pythonw.exe と同じフォルダに置けば、DLL を探す順番で最初に見つかる
    （管理者権限も、再頒布可能パッケージのインストールも要らない）。
    マイクロソフトの署名つきで、アプリと一緒に置く形の再配布が
    認められているファイル（Python の vcruntime140.dll と同じ扱い）。
    """
    system = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32"
    for name in ("msvcp140.dll",):
        src = system / name
        if src.is_file():
            shutil.copy2(src, out / name)
            log(f"  {name}（Visual C++ ランタイム。エンジンが使う）")
        else:
            log(f"  ⚠ {name} が見つかりません。Visual C++ 再頒布可能"
                "パッケージが無い PC ではエンジンが動きません")


def copy_runtime_from_install(prefix: Path, out: Path) -> str:
    """ふつうに入っている Python から、持ち運べる形を組み立てる。"""
    tag = tag_of(prefix)
    out.mkdir(parents=True, exist_ok=True)

    log(f"  もとの Python: {prefix}（{tag}）")
    for name in ("pythonw.exe", "python.exe", "python3.dll", f"{tag}.dll",
                 "vcruntime140.dll", "vcruntime140_1.dll"):
        src = prefix / name
        if src.is_file():
            shutil.copy2(src, out / name)
        elif name in ("pythonw.exe", f"{tag}.dll"):
            raise SystemExit(f"必要なファイルがありません: {src}")
    copy_msvcp(out)

    # 標準ライブラリを zip に固める（埋め込み用 Python と同じ形）
    lib = prefix / "Lib"
    if not lib.is_dir():
        raise SystemExit(f"Lib がありません: {lib}")
    zip_path = out / f"{tag}.zip"
    count = 0
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, 9) as zf:
        for path in sorted(lib.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(lib)
            parts = set(rel.parts)
            if parts & DROP_DIRS or rel.name in DROP_FILES:
                continue
            if path.suffix in (".pyc", ".pyo"):
                continue
            zf.write(path, str(rel).replace(os.sep, "/"))
            count += 1
    log(f"  標準ライブラリ {count} ファイル → {zip_path.name} "
        f"（{zip_path.stat().st_size / 1e6:.1f} MB）")

    # 拡張モジュール（.pyd）
    dlls_src = prefix / "DLLs"
    dlls_out = out / "DLLs"
    dlls_out.mkdir(exist_ok=True)
    n = 0
    for path in dlls_src.iterdir():
        if path.name in DROP_DLLS:
            continue
        if path.suffix.lower() in (".pyd", ".dll") and "test" not in path.name:
            shutil.copy2(path, dlls_out / path.name)
            n += 1
    log(f"  拡張モジュールと dll {n} ファイル")

    # 探す場所の指定。これがないと、入っている Python を見に行ってしまう
    (out / f"{tag}._pth").write_text(
        f"{tag}.zip\nDLLs\n.\n..\n\n# import site は切る（site-packages を"
        f"見に行かせない）\n", "utf-8")
    return tag


def unpack_embeddable(zip_path: Path, out: Path, prefix: Path) -> str:
    """公式の「埋め込み用 Python」の zip を使う（いちばん素直）。"""
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(out)
    tag = tag_of(out)
    log(f"  埋め込み用 Python を展開しました（{tag}）")

    # ★tkinter はもう使わない（6.14）。前は埋め込み用に入っていない
    # tkinter と tcl/tk を同じ版から足していた。今はそのまま使える。
    dlls_out = out / "DLLs"
    dlls_out.mkdir(exist_ok=True)
    copy_msvcp(out)
    pth = out / f"{tag}._pth"
    if pth.is_file():
        text = pth.read_text("utf-8")
        if "DLLs" not in text:
            pth.write_text(text.replace(f"{tag}.zip",
                                        f"{tag}.zip\nDLLs"), "utf-8")
        text = pth.read_text("utf-8")
        if "\n..\n" not in text:
            pth.write_text(text.rstrip() + "\n..\n", "utf-8")
    return tag


# ---------------------------------------------------------------- アプリ


def copy_app(out: Path) -> int:
    n = 0
    for name in APP_FILES:
        src = ROOT / name
        if src.is_file():
            shutil.copy2(src, out / name)
            n += 1
    for folder in APP_DIRS:
        src = ROOT / folder
        if not src.is_dir():
            continue
        for path in src.rglob("*"):
            if not path.is_file():
                continue
            rel = path.relative_to(ROOT).as_posix()
            if any(part in rel for part in SKIP_PARTS):
                continue
            dst = out / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dst)
            n += 1
    return n


LAUNCHER = """@echo off
rem koe-type を起動します。同梱の署名済み Python を使うので、
rem この PC に Python が入っていなくても動きます。
setlocal
set "HERE=%~dp0"
start "" "%HERE%runtime\\pythonw.exe" "%HERE%koe-type.pyw"
endlocal
"""

INSTALL = """@echo off
rem koe-type をこの PC に登録します。**管理者権限は要りません。**
rem 置き場所はこのフォルダのまま。スタートメニューと自動起動に登録します。
setlocal
set "HERE=%~dp0"
"%HERE%runtime\\python.exe" "%HERE%tools\\install.py" %*
pause
"""

UNINSTALL = """@echo off
rem koe-type の登録を消します。設定・辞書・履歴を残すか選べます。
setlocal
set "HERE=%~dp0"
"%HERE%runtime\\python.exe" "%HERE%tools\\uninstall.py" %*
pause
"""


def write_launchers(out: Path) -> None:
    (out / "koe-type.cmd").write_text(LAUNCHER, "utf-8")
    (out / "install.cmd").write_text(INSTALL, "utf-8")
    (out / "uninstall.cmd").write_text(UNINSTALL, "utf-8")
    log("  koe-type.cmd / install.cmd / uninstall.cmd")


# ---------------------------------------------------------------- 確かめる


def smoke_test(out: Path, tag: str) -> bool:
    """**1 回起動して、ブロックされないか確かめる。**

    Smart App Control は署名のない exe をファイル単位で止める。
    新しい実行ファイルを使う前に必ず確かめる、という決まり。
    """
    exe = out / "runtime" / "python.exe"
    if not exe.is_file():
        log("  ⚠ python.exe がないので確かめられません")
        return False
    checks = [
        ("起動できる", "import sys; print(sys.version)"),
        ("標準ライブラリが読める",
         "import json, sqlite3, ctypes, wave, zlib; print('ok')"),
        ("同梱の Visual C++ ランタイムを読める",
         "import ctypes, sys, os; "
         "ctypes.WinDLL(os.path.join(os.path.dirname(sys.executable), "
         "'msvcp140.dll')); print('ok')"),
        ("koe-type が読める（tkinter なしで）",
         "import sys; sys.path.insert(0, r'" + str(out) + "'); "
         "import app.main, app.overlay, app.schema; "
         "assert 'tkinter' not in sys.modules, 'tkinter'; print('ok')"),
    ]
    good = True
    for label, code in checks:
        try:
            proc = subprocess.run(  # noqa: S603
                [str(exe), "-c", code], capture_output=True, text=True,
                timeout=90, cwd=str(out))
        except Exception as exc:  # noqa: BLE001
            log(f"  NG   {label}: {exc}")
            good = False
            continue
        if proc.returncode == 0:
            log(f"  OK   {label}  {proc.stdout.strip()[:60]}")
        else:
            log(f"  NG   {label}: {proc.stderr.strip()[-200:]}")
            good = False
    return good


def folder_size(path: Path) -> float:
    return sum(f.stat().st_size for f in path.rglob("*") if f.is_file()) / 1e6


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


# ---------------------------------------------------------------- 本体


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--from", dest="src", default="",
                    help="もとにする Python のフォルダ（既定：いま動いているもの）")
    ap.add_argument("--embeddable", default="",
                    help="公式の埋め込み用 Python の zip")
    ap.add_argument("--out", default="")
    ap.add_argument("--no-test", action="store_true")
    ap.add_argument("--zip", action="store_true", help="zip も作る")
    args = ap.parse_args()

    prefix = Path(args.src) if args.src else Path(sys.base_prefix)
    out = Path(args.out) if args.out else ROOT / "dist" / "koe-type-portable"

    print("=" * 70)
    print(" 持ち運べる koe-type を組み立てる")
    print(" 新しい未署名の exe は 1 つも作りません")
    print("=" * 70)

    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    log("\n[1] 署名済みの Python を入れる")
    runtime = out / "runtime"
    if args.embeddable:
        tag = unpack_embeddable(Path(args.embeddable), runtime, prefix)
    else:
        tag = copy_runtime_from_install(prefix, runtime)

    log("\n[2] koe-type を入れる")
    n = copy_app(out)
    log(f"  {n} ファイル")
    write_launchers(out)

    log("\n[3] 署名を確かめる")
    try:
        ps = ("Get-ChildItem -Path '" + str(runtime) +
              "' -Include *.exe,*.dll,*.pyd -Recurse | "
              "ForEach-Object { (Get-AuthenticodeSignature $_).Status } | "
              "Group-Object | ForEach-Object { \"$($_.Name) $($_.Count)\" }")
        proc = subprocess.run(  # noqa: S603
            ["powershell", "-NoProfile", "-Command", ps],
            capture_output=True, text=True, timeout=180)
        for line in (proc.stdout or "").splitlines():
            if line.strip():
                log(f"  {line.strip()}")
        if "NotSigned" in (proc.stdout or ""):
            log("  ⚠ 署名のないファイルが混ざっています")
    except Exception as exc:  # noqa: BLE001
        log(f"  署名を確かめられませんでした: {exc}")

    if not args.no_test:
        log("\n[4] 1 回起動して確かめる")
        if not smoke_test(out, tag):
            log("\n  ✗ 起動の確認に失敗しました。中身を見直してください。")
            return 1

    size = folder_size(out)
    log(f"\n  できあがり: {out}")
    log(f"  大きさ: {size:.1f} MB")

    if args.zip:
        log("\n[5] zip にする")
        from app.util import VERSION  # noqa: PLC0415
        name = f"koe-type-{VERSION}-windows-x64-portable.zip"
        zip_path = out.parent / name
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, 9) as zf:
            for path in sorted(out.rglob("*")):
                if path.is_file():
                    zf.write(path, f"koe-type/{path.relative_to(out)}")
        digest = sha256(zip_path)
        (out.parent / (name + ".sha256")).write_text(
            f"{digest}  {name}\n", "utf-8")
        log(f"  {zip_path.name}  {zip_path.stat().st_size / 1e6:.1f} MB")
        log(f"  SHA256 {digest}")

    print("\n" + "=" * 70)
    print(" 受け取った人の手順")
    print("=" * 70)
    print("  1. zip を好きな場所に展開する")
    print("  2. install.cmd をダブルクリック（管理者権限は要りません）")
    print("  3. 初回の案内が出るので、順に進める")
    print("  消すとき: uninstall.cmd（設定を残すか選べます）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
