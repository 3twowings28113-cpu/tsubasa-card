r"""設定画面のスクリーンショットを撮る（Edge のヘッドレス）。

ライト／ダーク × 狭い窓／広い窓 の 4 通りを、全カテゴリぶん撮る。
画面にも音にも触らないので、ふだんの作業の邪魔をしない。

  python tools\settings_shots.py [出力フォルダ]
"""

from __future__ import annotations

import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# ★app を読み込む前に、使い捨てのフォルダを置き場所にする。
# 前は本物の設定と辞書を読んでいた（画像に利用者の辞書が写り、
# 「テストでは必ずコピーを使う」決まりにも反していた）。
# 辞書は見本（dictionary.sample.txt）を使う。
_HOME = Path(tempfile.mkdtemp(prefix="koe-type-shots-"))
os.environ["KOE_TYPE_HOME"] = str(_HOME)
# クリップボード履歴の見本を動かすため。から打ちにしておけば、
# ショートカットの登録もクリップボードの見張りも一切しない。
os.environ["KOE_TYPE_DRY_RUN"] = "1"
_SAMPLE = ROOT / "dictionary.sample.txt"
if _SAMPLE.is_file():
    shutil.copy2(_SAMPLE, _HOME / "dictionary.txt")

from app import i18n                                    # noqa: E402
from app.configstore import Config                      # noqa: E402
from app.history import History                         # noqa: E402
from app.textproc import Dictionary                     # noqa: E402
from app.util import ensure_dictionary, ensure_dirs, setup_logging  # noqa: E402
from app.websettings import Bridge, SettingsServer, find_edge       # noqa: E402
from tools.edgeshot import shoot                                    # noqa: E402

PAGES = ("guide", "general", "audio", "transcription", "ai", "dictionary",
         "clipboard", "display", "history", "app")
# 高さは「ページ全体が入る」ように大きく取る。
# 窓の高さではなく「全部を一枚に写すための紙の大きさ」なので、
# 左の目次（画面に固定）が下のほうにもう一度描かれることがある。
# 中身の確認が目的なので、そこは気にしない。
# 前は 760px しかなく、各ページの下半分が一度も画像になっていなかった
# （別エージェントのレビューで指摘された）。実際の窓の高さではなく、
# 「全部を一枚に写すための紙の大きさ」として使う。
SIZES = {"wide": (1180, 3600), "narrow": (820, 4200)}
THEMES = ("light", "dark")


def _sample_clip(cfg: Config):  # noqa: ANN202
    """見本の入ったクリップボード履歴（から打ち。画面にもキーにも触れない）。"""
    from app import clipstore                       # noqa: PLC0415
    from app.clipwin import ClipService              # noqa: PLC0415
    clip = ClipService(cfg)
    clip.start()
    store = clip.store
    if store.history_count() == 0:
        for text, app in (("明日の打ち合わせは 10 時からに変更になりました。",
                           "slack.exe"),
                          ("https://www.example.co.jp/news", "chrome.exe"),
                          ("お世話になっております。山田です。",
                           "OUTLOOK.EXE")):
            store.add(kind="text", hash_=clipstore.text_hash(text),
                      text=text, app=app)
        gid = store.groups()[0].id
        for title, text, secret in (("会社のメール",
                                     "yamada" + "@" + "example.co.jp",
                                     False),
                                    ("社内システム", "Pa55word!", True),
                                    ("今日の日付", "{date}", False)):
            store.add(kind="text", hash_=clipstore.text_hash(text),
                      text=text, group_id=gid, title=title, secret=secret)
    return clip


def main() -> int:
    global PAGES
    args = list(sys.argv[1:])
    if "--only" in args:
        # python tools\settings_shots.py --only clipboard  （1 ページだけ撮る）
        i = args.index("--only")
        PAGES = tuple(args[i + 1].split(",")) if i + 1 < len(args) else PAGES
        del args[i:i + 2]
    out_dir = Path(args[0]) if args else ROOT / "logs" / "shots"
    out_dir.mkdir(parents=True, exist_ok=True)

    edge = find_edge()
    if edge is None:
        print("Edge が見つかりませんでした。")
        return 2

    ensure_dirs()
    ensure_dictionary()
    setup_logging("WARNING")
    cfg = Config()
    # 履歴のページが空だと、並んだときの見た目を確かめられない。
    # 見本の文だけを入れる（利用者の履歴は使わない）。
    from app.history import store_audio  # noqa: PLC0415
    sample = History()
    if not sample.recent(1):
        for text in ("あしたの打ち合わせは午前10時から会議室でやります",
                     "資料は前の日までに共有しておいてください",
                     "句読点が多すぎるので少なめにしたい"):
            sample.add(text, model="sensevoice-resident", seconds=2.0,
                       audio=store_audio(b"\x00\x00" * 3200), limit=50)
    i18n.set_language(cfg.str_("ui_language", "ja"))
    clip = _sample_clip(cfg)

    def action(name: str, **kw: object) -> object:
        if name == "clip_api":
            return clip.api(str(kw.get("api", "")),
                            dict(kw.get("payload") or {}))
        if name == "clip_image":
            return clip.image_bytes(int(kw.get("id", 0) or 0))
        return None

    server = SettingsServer(Bridge(cfg, Dictionary(), History(), action))
    server.keep_open = True          # 窓が閉じてもサーバーを残す
    server.start()
    print(f"サーバー: 127.0.0.1:{server.port}")

    made = []
    try:
        for theme in THEMES:
            for size_name, (w, h) in SIZES.items():
                for page in PAGES:
                    name = f"{page}-{theme}-{size_name}.png"
                    url = f"{server.url(page)}&theme={theme}"
                    path = out_dir / name
                    # 古い画像を消す・専用のプロフィール・書き終わりを
                    # 待つ、は edgeshot に任せる（理由はそちらに書いた）
                    if shoot(edge, url, path, w, h):
                        made.append(path)
                        print(f"  撮れました {name}"
                              f"  ({path.stat().st_size // 1024} KB)")
                    else:
                        print(f"  失敗 {name}")
                    server.beat()
                    time.sleep(0.1)
    finally:
        server.stop()
        shutil.rmtree(_HOME, ignore_errors=True)
    print(f"\n{len(made)} 枚を {out_dir} に保存しました")
    return 0 if made else 1


if __name__ == "__main__":
    raise SystemExit(main())
