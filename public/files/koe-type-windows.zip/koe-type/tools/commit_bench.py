"""文字を「いつ確定するか」を、利用者の実際の録音で比べる。

**音は鳴らさない**（WAV を直接モデルへ渡す）。**キーもクリックも送らない**
（入力欄の代わりに文字列へ足していく）。

## 比べるもの

| 名前 | やり方 |
|---|---|
| `stream` | 話しながら入力欄へ入れる（くり返し聞き直し、一致した先頭だけ確定） |
| `preview` | 帯には先出しするが、**入力欄へはひと区切りごと**にまとめて入れる |
| `phrase` | ひと区切りごと（先出しもしない。入る文字は preview と同じ） |

`preview` と `phrase` は入力欄に入る文字が同じなので、まとめて測る。

## 測るもの

- **文字誤り率**：録音ぜんぶを一度に聞かせた結果を「お手本」として比べる。
  いちばん文脈がそろった状態の結果なので、**途中で確定したせいで
  どれだけ崩れたか**が分かる。
- **二重入力の回数**：入れた文字の終わりと、次に入れる文字の頭が
  重なっている回数。「隣りの」＋「隣の客は…」のような壊れ方を数える。
- **最初の文字までの時間**：話し始めてから 1 文字目が入るまで。

## 録音の作り直し

履歴の録音は**区切りごと**に保存されている。そのままでは区切りの
判定を測れないので、保存した時刻が近いものをつなぎ直し、
そのあいだの無音も入れて「1 回の録音」に戻してから流す。

    python tools/commit_bench.py
    python tools/commit_bench.py --limit 5        # 5 本だけ
    python tools/commit_bench.py --mode stream    # 片方だけ
"""

from __future__ import annotations

import argparse
import array
import json
import logging
import statistics
import sys
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import jatext  # noqa: E402
from app.streaming import Agreement, remainder  # noqa: E402
from app.vad import SegmentCutter  # noqa: E402

SAMPLE_RATE = 16000
CHUNK_MS = 50          # 本体がマイクから受け取る 1 回の長さ


# ---------------------------------------------------------------- 録音を戻す


def load_wav(path: Path) -> bytes:
    with wave.open(str(path)) as w:
        assert w.getnchannels() == 1, f"モノラルではありません: {path}"
        assert w.getsampwidth() == 2, f"16bit ではありません: {path}"
        return w.readframes(w.getnframes())


def silence(seconds: float) -> bytes:
    return bytes(int(SAMPLE_RATE * seconds) * 2)


def rebuild(folder: Path, *, split_gap: float = 20.0) -> list[dict]:
    """区切りごとの録音を、1 回の録音につなぎ直す。"""
    files = []
    for path in sorted(folder.glob("*.wav")):
        try:
            stamp = int(path.stem)
        except ValueError:
            continue
        pcm = load_wav(path)
        files.append({"at": stamp / 1000.0, "pcm": pcm,
                      "secs": len(pcm) / (SAMPLE_RATE * 2),
                      "name": path.name})
    if not files:
        return []

    takes: list[dict] = []
    current: list[dict] = []
    for i, row in enumerate(files):
        if current:
            prev = current[-1]
            gap = row["at"] - prev["at"] - row["secs"]
            if gap > split_gap:
                takes.append({"parts": current})
                current = []
            else:
                row = dict(row)
                # 保存の時刻には文字起こしの時間も入っているので、
                # 無音は控えめに見積もる（0.3〜2.0 秒）
                row["gap"] = max(0.3, min(2.0, gap))
        current.append(row)
    if current:
        takes.append({"parts": current})

    out = []
    for take in takes:
        buf = bytearray()
        for part in take["parts"]:
            if buf:
                buf.extend(silence(part.get("gap", 0.5)))
            buf.extend(part["pcm"])
        out.append({"pcm": bytes(buf),
                    "secs": len(buf) / (SAMPLE_RATE * 2),
                    "parts": len(take["parts"]),
                    "first": take["parts"][0]["name"]})
    return out


# ---------------------------------------------------------------- 物差し


def cer(reference: str, got: str) -> float:
    """文字誤り率。お手本に対する編集距離 ÷ お手本の長さ。"""
    if not reference:
        return 0.0 if not got else 1.0
    prev = list(range(len(got) + 1))
    for i, rc in enumerate(reference, 1):
        row = [i]
        for j, gc in enumerate(got, 1):
            row.append(min(prev[j] + 1, row[j - 1] + 1,
                           prev[j - 1] + (rc != gc)))
        prev = row
    return prev[-1] / len(reference)


_IGNORE = set("、。，．！？!?,. 　\t\n")


def _plain(text: str) -> str:
    return "".join(ch for ch in text if ch not in _IGNORE)


def count_doubles(pieces: list[str], reference: str = "") -> int:
    """二重入力の回数。入れた文字の終わりと次の頭が重なっている数。

    ★お手本（reference）にも同じ並びが続けてあれば、本物の繰り返し
    （「なかなか」「どんどん」）なので数えない。数えていたころは、
    文字がお手本とまったく同じでも「二重あり」と出ていた（2026-10-05）。
    """
    ref = _plain(reference)
    doubles = 0
    acc = ""
    for piece in pieces:
        a, b = _plain(acc), _plain(piece)
        if a and b:
            for size in range(min(8, len(a), len(b)), 1, -1):
                if a.endswith(b[:size]):
                    if not (ref and b[:size] * 2 in ref):
                        doubles += 1
                    break
        acc += piece
    return doubles


# ---------------------------------------------------------------- 流す


class Clean:
    """本体と同じ整えかたをする（設定は既定のまま）。"""

    def __init__(self) -> None:
        self.opt = jatext.Options()

    def __call__(self, raw: str, *, final: bool = False) -> str:
        from app.textproc import tidy
        text = tidy(raw, punctuation=True, fillers=False,
                    halfwidth=self.opt.halfwidth_alnum)
        return jatext.format_text(text, self.opt, final=final)


def make_cutter(cfg: dict) -> SegmentCutter:
    return SegmentCutter(
        SAMPLE_RATE,
        pause_ms=cfg.get("pause_ms", 700),
        min_speech_ms=cfg.get("min_speech_ms", 300),
        max_segment_ms=cfg.get("max_segment_ms", 15000),
        preroll_ms=cfg.get("preroll_ms", 200),
        tail_ms=cfg.get("tail_ms", 250),
        sensitivity=cfg.get("vad_sensitivity", 30) / 10.0,
        floor=float(cfg.get("vad_floor", 180)),
        merge_short_ms=cfg.get("merge_short_ms", 1000),
        hold_release_ms=cfg.get("hold_release_ms", 1500),
    )


def run_segments(engine, clean: Clean, pcm: bytes,  # noqa: ANN001
                 cfg: dict) -> dict:
    """ひと区切りごとに入れるやり方（preview / phrase）。"""
    cutter = make_cutter(cfg)
    pieces: list[str] = []
    first_at = None
    audio_t = 0.0
    spent = 0.0
    step = SAMPLE_RATE * 2 * CHUNK_MS // 1000
    for i in range(0, len(pcm), step):
        chunk = pcm[i:i + step]
        audio_t += len(chunk) / (SAMPLE_RATE * 2)
        for seg in cutter.feed(chunk):
            t0 = time.perf_counter()
            text = clean(engine(seg), final=False)
            spent += time.perf_counter() - t0
            if text:
                if first_at is None:
                    first_at = audio_t + spent
                pieces.append(text)
    for seg in cutter.flush():
        t0 = time.perf_counter()
        text = clean(engine(seg), final=True)
        spent += time.perf_counter() - t0
        if text:
            if first_at is None:
                first_at = audio_t + spent
            pieces.append(text)
    return {"pieces": pieces, "first": first_at}


def run_stream(engine, clean: Clean, pcm: bytes, cfg: dict) -> dict:  # noqa: ANN001
    """話しながら入力欄へ入れるやり方（stream）。"""
    cutter = make_cutter(cfg)
    agree = Agreement(rounds=cfg.get("stream_agree_rounds", 3),
                      min_span=cfg.get("stream_agree_span_ms", 400) / 1000.0)
    # 本体と同じ間隔にする。本体は何本か重ねて走らせるので、
    # 聞き直しの間隔は interval / workers（既定 350/2 = 175ms）。
    # ここを本体より広く取ると、stream を実際より控えめに見積もって
    # しまい、比べる意味がなくなる。
    workers = max(1, cfg.get("stream_workers", 2))
    interval = cfg.get("stream_interval_ms", 350) / 1000.0 / workers
    pieces: list[str] = []
    first_at = None
    audio_t = 0.0
    spent = 0.0
    next_round = interval
    step = SAMPLE_RATE * 2 * CHUNK_MS // 1000
    for i in range(0, len(pcm), step):
        chunk = pcm[i:i + step]
        audio_t += len(chunk) / (SAMPLE_RATE * 2)
        segments = cutter.feed(chunk)

        if audio_t >= next_round and not segments:
            next_round = audio_t + interval
            buffered = cutter.buffered()
            if len(buffered) > SAMPLE_RATE * 2 * 35 // 100:
                t0 = time.perf_counter()
                text = clean(engine(buffered))
                spent += time.perf_counter() - t0
                fresh = agree.update(text, len(buffered) / (SAMPLE_RATE * 2))
                if fresh:
                    if first_at is None:
                        first_at = audio_t + spent
                    pieces.append(fresh)

        for seg in segments:
            typed = agree.take()
            agree.reset()
            t0 = time.perf_counter()
            text = clean(engine(seg))
            spent += time.perf_counter() - t0
            rest = remainder(typed, text) if typed else text
            if rest:
                if first_at is None:
                    first_at = audio_t + spent
                pieces.append(rest)
            next_round = audio_t + interval

    for seg in cutter.flush():
        typed = agree.take()
        agree.reset()
        t0 = time.perf_counter()
        text = clean(engine(seg), final=True)
        spent += time.perf_counter() - t0
        rest = remainder(typed, text) if typed else text
        if rest:
            if first_at is None:
                first_at = audio_t + spent
            pieces.append(rest)
    return {"pieces": pieces, "first": first_at}


# ---------------------------------------------------------------- 本体


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--audio", default=str(ROOT / "data" / "audio"),
                    help="録音の入ったフォルダ")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--mode", action="append", default=[],
                    choices=["stream", "segments"])
    ap.add_argument("--old", action="store_true",
                    help="短い区切りをつなげない昔の設定も比べる")
    ap.add_argument("--json", default="")
    args = ap.parse_args()

    logging.basicConfig(level=logging.ERROR)

    folder = Path(args.audio)
    if not folder.is_dir():
        print(f"録音のフォルダがありません: {folder}")
        return 1
    takes = rebuild(folder)
    if args.limit:
        takes = takes[:args.limit]
    if not takes:
        print("つなぎ直せる録音がありません")
        return 1

    print("=" * 74)
    print(" 確定のしかたを、実際の録音で比べる")
    print(" 音は鳴らしません／キーもクリックも送りません")
    print("=" * 74)
    total = sum(t["secs"] for t in takes)
    print(f"  録音 {len(takes)} 本 / 合計 {total:.1f} 秒"
          f"（もとの区切り {sum(t['parts'] for t in takes)} 個をつなぎ直し）")

    from app import catalog, engines
    engine = engines.build(catalog.DEFAULT_MODEL, "ja")
    if engine is None:
        print("  エンジンを用意できません")
        return 1
    print(f"  モデル: {engine.spec.name}")
    clean = Clean()

    def listen(pcm: bytes) -> str:
        return engine.transcribe_pcm(pcm, "")

    base = {"merge_short_ms": 1000, "hold_release_ms": 1500}
    plans = []
    want = args.mode or ["stream", "segments"]
    if "segments" in want:
        plans.append(("preview / phrase", run_segments, base))
    if "stream" in want:
        plans.append(("stream（話しながら）", run_stream, base))
    if args.old:
        old = dict(base, merge_short_ms=0)
        if "segments" in want:
            plans.append(("preview（昔：つなげない）", run_segments, old))
        if "stream" in want:
            plans.append(("stream（昔：つなげない）", run_stream, old))

    results: dict = {name: {"cer": [], "doubles": 0, "first": [],
                            "texts": []} for name, _, _ in plans}

    for i, take in enumerate(takes, 1):
        t0 = time.perf_counter()
        ref = clean(listen(take["pcm"]), final=True)
        ref_took = time.perf_counter() - t0
        print(f"\n■ {i}/{len(takes)}  {take['secs']:.1f} 秒 "
              f"（区切り {take['parts']} 個）")
        print(f"    お手本（まとめて 1 回・{ref_took:.2f}s）: {ref[:110]}")
        for name, fn, cfg in plans:
            got = fn(listen, clean, take["pcm"], cfg)
            text = "".join(got["pieces"])
            score = cer(_plain(ref), _plain(text))
            doubles = count_doubles(got["pieces"], ref)
            results[name]["cer"].append(score)
            results[name]["doubles"] += doubles
            if got["first"] is not None:
                results[name]["first"].append(got["first"])
            results[name]["texts"].append(text)
            flag = "  ★二重あり" if doubles else ""
            print(f"    {name:26} 誤り {score * 100:5.1f}% / "
                  f"二重 {doubles} / 1文字目 "
                  f"{got['first'] if got['first'] else float('nan'):.2f}s"
                  f"{flag}")
            if score > 0.12 or doubles:
                print(f"       → {text[:110]}")

    print("\n" + "=" * 74)
    print(" まとめ")
    print("=" * 74)
    print(f"  {'やり方':28} {'誤り率':>8} {'二重':>6} {'1文字目':>9}")
    for name in results:
        r = results[name]
        med = statistics.mean(r["cer"]) * 100
        first = (statistics.median(r["first"]) if r["first"] else float("nan"))
        print(f"  {name:28} {med:7.1f}% {r['doubles']:6} {first:8.2f}s")
    print("\n  ※ 誤り率は「録音ぜんぶを一度に聞かせた結果」に対する差です。")
    print("     小さいほど、途中で確定したことによる崩れが少ない。")

    if args.json:
        Path(args.json).write_text(json.dumps(
            {k: {"cer": v["cer"], "doubles": v["doubles"],
                 "first": v["first"]} for k, v in results.items()},
            ensure_ascii=False, indent=2), "utf-8")
        print(f"\n  数字を書き出しました: {args.json}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
