"""重い処理と同時に、録音の開始・停止をくり返しても大丈夫かを確かめる。

**本物のキーもクリックも 1 回も送らない。** 台本で操作する。
スピーカーも使わない（WAV を流し込む）。

いちばん見たいのは「**ほかのアプリの邪魔をしていないか**」。
以前、低レベルのフックのせいで PC 全体のカーソルがカクついた。
それが直っているかを、数字で確かめる。

測るもの
  ・**入力の応答の遅れ**（別プロセスから入力の流れを調べる）
  ・ショートカットの登録が外れないか
  ・落ちない・固まらない
  ・CPU とメモリ

    python tools/stress_test.py                  # 5 分ぶん
    python tools/stress_test.py --minutes 60     # 1 時間
    python tools/stress_test.py --load           # CPU を埋めた状態で
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import statistics
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tools.mock_e2e import AUDIO, make_home  # noqa: E402

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

PYTHON = sys.executable


class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wintypes.UINT), ("dwTime", wintypes.DWORD)]


user32.GetLastInputInfo.argtypes = [ctypes.POINTER(LASTINPUTINFO)]
user32.GetLastInputInfo.restype = wintypes.BOOL
user32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
kernel32.GetTickCount.restype = wintypes.DWORD


def probe_input_latency(samples: int = 40) -> list[float]:
    """入力の流れがどれだけ待たされているかを測る。

    `GetLastInputInfo` と `GetCursorPos` は、入力まわりのロックを
    通るので、**入力の流れが詰まっていると返りが遅くなる**。
    低レベルのフックが詰まっていた時は、ここが目に見えて遅くなる。
    """
    out = []
    info = LASTINPUTINFO()
    info.cbSize = ctypes.sizeof(info)
    point = wintypes.POINT()
    for _ in range(samples):
        t0 = time.perf_counter()
        user32.GetLastInputInfo(ctypes.byref(info))
        user32.GetCursorPos(ctypes.byref(point))
        out.append((time.perf_counter() - t0) * 1000.0)
        time.sleep(0.02)
    return out


def burn(stop_at: float) -> None:
    x = 0.0
    while time.time() < stop_at:
        for i in range(200000):
            x += i * 0.5


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--minutes", type=float, default=5.0)
    ap.add_argument("--load", action="store_true", help="CPU を埋める")
    ap.add_argument("--cycle", type=float, default=6.0,
                    help="録音 1 回ぶんの長さ（秒）")
    args = ap.parse_args()

    print("=" * 70)
    print(f" 負荷のなかで録音をくり返す（{args.minutes:.0f} 分）")
    print(" 本物のキーもクリックも 1 回も送りません")
    print("=" * 70)

    # --- 比べるための、何もしていない状態の遅れ
    print("\n[1] まず、何もしていないときの入力の遅れを測る")
    base = probe_input_latency(60)
    print(f"    中央値 {statistics.median(base):.3f} ms / "
          f"最大 {max(base):.3f} ms")

    burners = []
    if args.load:
        import multiprocessing
        n = max(1, (multiprocessing.cpu_count() or 4) // 2)
        stop_at = time.time() + args.minutes * 60 + 120
        for _ in range(n):
            p = multiprocessing.Process(target=burn, args=(stop_at,),
                                        daemon=True)
            p.start()
            burners.append(p)
        print(f"    CPU を {n} 本の処理で埋めました")

    # --- アプリを起動して、台本で録音をくり返す
    cycles = max(1, int(args.minutes * 60 / args.cycle))
    print(f"\n[2] 録音の開始・停止を {cycles} 回くり返す")

    home = make_home(ROOT / "bench" / "eval" / "_stress",
                     {"input_mode": "stream", "guardian": False})
    script = []
    at = 1.0
    for _ in range(cycles):
        script.append({"at": round(at, 2), "event": "hotkey_down"})
        script.append({"at": round(at + args.cycle * 0.6, 2),
                       "event": "stop"})
        at += args.cycle
    script.append({"at": round(at + 3, 2), "event": "quit"})
    (home / "script.json").write_text(json.dumps(script), "utf-8")

    env = dict(os.environ)
    env.update({
        "PYTHONUTF8": "1", "KOE_TYPE_HOME": str(home),
        "KOE_TYPE_DRY_RUN": "1",
        "KOE_TYPE_DRY_RUN_LOG": str(home / "logs" / "dryrun.jsonl"),
        "KOE_TYPE_TEST_SCRIPT": str(home / "script.json"),
        "KOE_TYPE_FAKE_MIC": str(AUDIO / "p01.wav"),
    })
    t0 = time.perf_counter()
    proc = subprocess.Popen(  # noqa: S603
        [PYTHON, "-m", "app.main"], cwd=str(ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    # --- 動いているあいだ、入力の遅れを測り続ける
    during: list[float] = []
    checks = 0
    while proc.poll() is None:
        during.extend(probe_input_latency(20))
        checks += 1
        elapsed = time.perf_counter() - t0
        if checks % 10 == 0:
            print(f"    {elapsed / 60:.1f} 分  入力の遅れ 中央値 "
                  f"{statistics.median(during[-400:]):.3f} ms / "
                  f"最大 {max(during[-400:]):.3f} ms")
        if elapsed > args.minutes * 60 + 180:
            proc.kill()
            break
    rc = proc.returncode
    took = time.perf_counter() - t0
    for p in burners:
        p.terminate()

    # --- まとめ
    # ログは 1MB で回るので、回った分も合わせて数える
    # （数え落として「半分しか動いていない」と誤解した）
    text = ""
    for log in sorted((home / "logs").glob("koe-type.log*")):
        text += log.read_text("utf-8", "replace")
    starts = text.count("録音開始")
    stops = text.count("録音停止")
    lost = text.count("ショートカットの登録が外れました")
    crashed = text.count("未捕捉の例外")

    metrics = home / "logs" / "metrics.jsonl"
    cpu_max = mem_max = wait_max = 0.0
    if metrics.exists():
        for line in metrics.read_text("utf-8", "replace").splitlines():
            try:
                row = json.loads(line)
            except ValueError:
                continue
            cpu_max = max(cpu_max, row.get("cpu", 0))
            mem_max = max(mem_max, row.get("mem", 0))
            wait_max = max(wait_max, row.get("wait", 0))

    print("\n" + "=" * 70)
    print(" 結果")
    print("=" * 70)
    print(f"  動かした時間          {took / 60:.1f} 分")
    print(f"  録音の開始／停止      {starts} 回 / {stops} 回")
    print(f"  終了コード            {rc}")
    print(f"  落ちた・固まった      {crashed} 回")
    print(f"  ショートカットが外れた {lost} 回")
    if during:
        print(f"\n  入力の遅れ（何もしていないとき）"
              f"  中央値 {statistics.median(base):.3f} ms / "
              f"最大 {max(base):.3f} ms")
        print(f"  入力の遅れ（録音をくり返す間）  "
              f"  中央値 {statistics.median(during):.3f} ms / "
              f"最大 {max(during):.3f} ms")
        over = sum(1 for v in during if v > 20.0)
        print(f"  20 ms を超えた回数              {over} / {len(during)}")
    if cpu_max:
        print(f"\n  このアプリの CPU（最大）        {cpu_max:.0f} %")
        print(f"  メモリ（最大）                  {mem_max:.0f} MB")
        print(f"  処理待ちの最大                  {wait_max:.0f} 件")

    ok = (rc == 0 and crashed == 0 and lost == 0 and starts >= cycles * 0.9)
    if during:
        # ふだんより大きく遅くなっていないか（カーソルのカクつきの指標）
        ok = ok and statistics.median(during) < max(2.0,
                                                    statistics.median(base) * 5)
    print("\n  " + ("合格" if ok else "不合格"))
    print("=" * 70)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
