"""録音中の帯を確かめる。**画面を撮らない**ので、ロック中でも通る。

帯が描いた中身をそのまま読み、思ったとおりに組み立てられているかを見る。
キーもクリックも音も使わない。

確かめること

  ・3 案とも、4 つの状態で絵が作れる（ライト・ダーク両方）
  ・状態ごとに**形が違う**（色が見分けにくい人にも分かる）
  ・録音中は枠が状態の色になる
  ・大きさ 小 < 中 < 大
  ・「アニメーションを減らす」設定のときは、出入りの動きをしない
  ・お知らせだけのときは小さくなる（目障りにしない）
  ・入力先のウィンドウと同じモニターに出す
  ・フォーカスを奪わない・クリックを通す窓の作りになっている

    python tools/overlay_test.py
"""

from __future__ import annotations

import ctypes
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import overlay as ov  # noqa: E402

ok = 0
ng: list[str] = []


def check(label: str, got: object, want: object = True) -> None:
    global ok
    if got == want:
        ok += 1
        print(f"  OK   {label}")
    else:
        ng.append(label)
        print(f"  NG   {label}: {got!r} ではなく {want!r} のはず")


def make(design: str, theme_name: str = "light",
         size: str = "medium") -> ov.Overlay:
    bar = ov.Overlay()
    bar.configure(theme_name=theme_name, position="bottom", size=size,
                  margin_px=16, enabled=True, design=design,
                  hint_text="Ctrl + Space で止める", show_hint=True)
    bar._animate = False
    for name in ov.FONTS:
        family = ctypes.c_void_p()
        if ov.gdiplus.GdipCreateFontFamilyFromName(
                name, None, ctypes.byref(family)) == 0:
            bar._font_family = family
            break
    return bar


def pixels(bar: ov.Overlay) -> tuple[int, int, bytes] | None:
    for _ in range(3):
        shot = bar.snapshot()
    return shot


def colours_in(rgba: bytes) -> set[tuple[int, int, int]]:
    out = set()
    for i in range(0, len(rgba), 4):
        r, g, b, a = rgba[i:i + 4]
        if a > 200:
            out.add((r // 16, g // 16, b // 16))
    return out


if not ov._start_gdiplus():
    print("GDI+ を始められませんでした")
    raise SystemExit(1)

print("\n[1] 3 案とも、4 つの状態で絵が作れる")
STATES = [("recording", 4.0, 0.6, "あしたの打ち合わせは", ""),
          ("recording", 73.0, 0.4, "あ" * 90, ""),
          ("transcribing", 0.0, 0.0, "", ""),
          ("done", 0.0, 0.0, "", "静かなので止めました")]
sizes: dict[tuple[str, str], tuple[int, int]] = {}
for design in ov.DESIGNS:
    for mode in ("light", "dark"):
        bar = make(design, mode)
        try:
            good = True
            for state, elapsed, level, pending, message in STATES:
                bar.set_state(state, elapsed=elapsed, level=level,
                              pending=pending, message=message)
                shot = pixels(bar)
                if shot is None or shot[0] < 40 or shot[1] < 20:
                    good = False
                    break
                sizes[(design, state)] = (shot[0], shot[1])
            check(f"{design} / {mode}", good)
        finally:
            if bar._font_family:
                ov.gdiplus.GdipDeleteFontFamily(bar._font_family)

print("\n[2] 状態ごとに形が違う")
shapes = {ov.STATE_SHAPE[s] for s in ("recording", "transcribing", "done")}
check("聞いている・文字にしている・止まった で形が 3 通り", len(shapes), 3)
check("聞いている は丸", ov.STATE_SHAPE["recording"], "dot")
check("文字にしている は四角", ov.STATE_SHAPE["transcribing"], "square")
check("止まった はチェック", ov.STATE_SHAPE["done"], "check")

print("\n[3] 色は設定画面とそろっている")
check("録音中は指定の赤", ov.STATE_COLOUR["recording"]["dark"].lower(),
      "#e0483a")
check("ライトの土台は指定の紺", ov.PALETTE["light"]["brand"].lower(),
      "#242460")
source = (ROOT / "app" / "overlay.py").read_text("utf-8")
for word in ("GdipCreateLineBrush", "LinearGradient", "GdipCreatePathGradient"):
    check(f"グラデーションを使っていない（{word}）", word not in source)

print("\n[4] 大きさ 小 < 中 < 大")
widths = []
for size in ("small", "medium", "large"):
    bar = make(ov.DESIGN_DEFAULT, "light", size)
    try:
        bar.set_state("recording", elapsed=4.0, level=0.6,
                      pending="あしたの打ち合わせは")
        shot = pixels(bar)
        widths.append((shot[0], shot[1]) if shot else (0, 0))
    finally:
        if bar._font_family:
            ov.gdiplus.GdipDeleteFontFamily(bar._font_family)
check("幅が順に大きい", widths[0][0] < widths[1][0] < widths[2][0])
check("高さが順に大きい", widths[0][1] < widths[1][1] < widths[2][1])
print(f"       小 {widths[0]} / 中 {widths[1]} / 大 {widths[2]}")

print("\n[5] 以前の帯よりはっきり大きい")
# 以前は高さ 36px（影を除く）だった
bar = make("pill", "light", "medium")
try:
    bar.set_state("recording", elapsed=4.0, level=0.6, pending="")
    shot = pixels(bar)
finally:
    if bar._font_family:
        ov.gdiplus.GdipDeleteFontFamily(bar._font_family)
inner_h = shot[1] - ov.SHADOW * 2 if shot else 0
# 既定（ピル）は縦に短くする。高すぎると入力欄の上に重なり、
# 文字が入ったか見えなくなった（2026-10-05）。低すぎても読めない。
check(f"中くらいの高さが 32〜44px（いま {inner_h}px）",
      32 <= inner_h <= 44)

print("\n[6] お知らせだけのときは小さくなる")
rec = sizes.get((ov.DESIGN_DEFAULT, "recording"), (0, 0))
done = sizes.get((ov.DESIGN_DEFAULT, "done"), (0, 0))
check(f"録音中 {rec} より小さい {done}",
      done[0] < rec[0] and done[1] < rec[1])

print("\n[6a] 話している言葉を帯に出さない設定")
# 利用者の頼み（2026-10-06）：チェックひとつで、言葉を出す／出さないを
# 切り替えたい。出さないときは、ピルの幅が言葉のぶん狭くなるはず。
widths = {}
for show in (True, False):
    bar = make("pill")
    bar.configure(theme_name="light", position="bottom", size="medium",
                  margin_px=16, enabled=True, design="pill",
                  hint_text="", show_hint=False, show_text=show)
    try:
        bar.set_state("recording", elapsed=3.0, level=0.5,
                      pending="あしたの打ち合わせは午前10時から")
        shot = pixels(bar)
        widths[show] = shot[0] if shot else 0
    finally:
        if bar._font_family:
            ov.gdiplus.GdipDeleteFontFamily(bar._font_family)
check(f"出さないと幅が狭くなる（{widths[True]} → {widths[False]}）",
      0 < widths[False] < widths[True] - 100)

print("\n[6b] 画面の拡大率（150%・200% でぼやけない）")
# ★アプリは DPI を自分で扱うと宣言する（main._dpi_aware）。宣言した
# プロセスでは、帯の高さが 38px × 拡大率になるはず。宣言は後から
# 変えられないので、別のプロセスで確かめる。100% の PC では 38px。
import subprocess as _sp  # noqa: E402
probe = _sp.run(
    [sys.executable, "-c",
     "import ctypes, sys; sys.path.insert(0, r'" + str(ROOT) + "'); "
     "ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)); "
     "sys.argv = ['x']; "
     "import tools.overlay_test_dpi as p; p.main()"],
    capture_output=True, text=True, timeout=60)
parts = probe.stdout.split()
if len(parts) == 2:
    factor, height = float(parts[0]), int(parts[1])
    want = round(38 * factor)
    check(f"拡大率 {factor:.2f} で帯の高さ {height}px（{want}px のはず）",
          abs(height - want) <= 1)
else:
    check("拡大率の確かめが動いた", False, probe.stderr[-300:])

print("\n[7] 動きの決まり")
bar = ov.Overlay()
bar._animate = False
check("動きを切ってあれば、出るときは最初から濃い",
      bar._fade_now("recording"), 1.0)
check("動きを切ってあれば、消えるときは一気に消える",
      bar._fade_now("hidden"), 0.0)
bar._animate = True
bar._fade_at = 0.0           # ずっと前に始めたことにする
check("動きがあっても、終われば濃さは 1.0", bar._fade_now("recording"), 1.0)
check("出入りの時間は 0.2 秒より短い",
      ov.Overlay.FADE_IN < 0.2 and ov.Overlay.FADE_OUT < 0.2)
check("Windows の設定を見る仕掛けがある",
      callable(ov.animations_on) and isinstance(ov.animations_on(), bool))

print("\n[8] 窓の作り（フォーカスを奪わない・クリックを通す）")
for flag in ("WS_EX_NOACTIVATE", "WS_EX_TRANSPARENT", "WS_EX_TOOLWINDOW"):
    check(f"{flag} を付けている", f"| {flag}" in source or f"{flag} |" in source)
check("モニターを選ぶ仕掛けがある", "MonitorFromWindow" in source)
check("入力先を受け取れる", hasattr(ov.Overlay, "set_target"))

print(f"\n==== 成功 {ok} / 失敗 {len(ng)} ====")
if ng:
    for label in ng:
        print(f"  - {label}")
raise SystemExit(1 if ng else 0)
