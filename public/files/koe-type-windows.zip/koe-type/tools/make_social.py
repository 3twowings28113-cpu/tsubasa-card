r"""GitHub のソーシャルプレビュー（1280x640）と、アイコンの確認用画像を作る。

文字を並べるだけなので、HTML を書いて Edge のヘッドレスで撮る。
新しい依存は増やさない。

  python tools\make_social.py
"""

from __future__ import annotations

import base64
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.websettings import find_edge  # noqa: E402

ICON_DIR = ROOT / "assets" / "icon"
PNG_DIR = ICON_DIR / "png"
DOCS = ROOT / "docs"
SHOTS = ROOT / "logs" / "shots"

NAVY = "#242460"
RED = "#E0483A"


def data_uri(path: Path) -> str:
    return "data:image/png;base64," + base64.b64encode(path.read_bytes()).decode()


def shoot(html: str, out: Path, width: int, height: int,
          transparent: bool = False) -> bool:
    edge = find_edge()
    if edge is None:
        print("Edge が見つかりませんでした。")
        return False
    out.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="koe-type-img-") as tmp:
        page = Path(tmp) / "page.html"
        page.write_text(html, "utf-8")
        from tools.edgeshot import shoot  # noqa: PLC0415
        extra = (["--default-background-color=00000000"] if transparent
                 else [])
        made = shoot(edge, page.as_uri(), out, width, height, extra)
    if made:
        print(f"  {out.relative_to(ROOT)}  ({out.stat().st_size // 1024} KB)")
        return True
    print(f"  失敗: {out.name}")
    return False


# ---------------------------------------------------------------- 紹介用画像


def social_html() -> str:
    icon = data_uri(PNG_DIR / "idle-256.png")
    return f"""<!doctype html><html lang="ja"><head><meta charset="utf-8">
<style>
  * {{ box-sizing: border-box; margin: 0; }}
  html, body {{ width: 1280px; height: 640px; }}
  body {{
    display: grid;
    grid-template-columns: 300px 1fr;
    align-items: center;
    gap: 56px;
    padding: 0 84px;
    background: #fbfbfd;
    color: #1a1a1a;
    font-family: "Segoe UI Variable Text", "Segoe UI", "Yu Gothic UI",
                 "Meiryo UI", sans-serif;
    border-top: 10px solid {NAVY};
  }}
  .icon {{ width: 228px; height: 228px; justify-self: center; }}
  h1 {{
    font-family: "Segoe UI Variable Display", "Segoe UI", sans-serif;
    font-size: 78px; font-weight: 600; letter-spacing: -0.02em;
    line-height: 1; color: {NAVY};
  }}
  .ja {{ margin-top: 20px; font-size: 29px; font-weight: 600; color: #22252b; }}
  .en {{ margin-top: 9px; font-size: 21px; color: #5d6470; }}
  .tags {{ display: flex; gap: 10px; margin-top: 34px; flex-wrap: wrap; }}
  .tags span {{
    font-size: 17px; padding: 7px 16px; border-radius: 999px;
    border: 1px solid #d3d7df; color: #3b4150; background: #fff;
  }}
  .tags span.on {{ background: {NAVY}; border-color: {NAVY}; color: #fff; }}
</style></head><body>
  <img class="icon" src="{icon}" alt="">
  <div>
    <h1>koe-type</h1>
    <p class="ja">Windows 用の日本語音声入力。完全オフライン、完全無料。</p>
    <p class="en">Offline Japanese voice typing for Windows. Free, and free forever.</p>
    <div class="tags">
      <span class="on">音声はPCの外に出ない</span>
      <span>Ctrl+Space で話すだけ</span>
      <span>どのアプリの入力欄でも</span>
      <span>MIT</span>
    </div>
  </div>
</body></html>"""


# ---------------------------------------------------------------- 確認用画像


def preview_html() -> str:
    rows = []
    for name, label, colour in (("idle", "ふだん", NAVY),
                                ("recording", "録音中", RED)):
        cells = []
        for size in (16, 20, 24, 32, 40, 48, 64):
            png = PNG_DIR / f"{name}-{size}.png"
            if not png.exists():
                continue
            zoom = 8 if size <= 32 else 4
            cells.append(f"""
              <figure>
                <div class="box"><img src="{data_uri(png)}"
                     style="width:{size * zoom}px;height:{size * zoom}px"></div>
                <figcaption>{size}px &times;{zoom}</figcaption>
              </figure>""")
        actual = "".join(
            f'<img src="{data_uri(PNG_DIR / f"{name}-{s}.png")}" '
            f'style="width:{s}px;height:{s}px">'
            for s in (16, 20, 24, 32, 40, 48, 64)
            if (PNG_DIR / f"{name}-{s}.png").exists())
        rows.append(f"""
          <section>
            <h2><i style="background:{colour}"></i>{label}</h2>
            <div class="grid">{"".join(cells)}</div>
            <div class="actual">原寸: {actual}</div>
          </section>""")
    return f"""<!doctype html><html lang="ja"><head><meta charset="utf-8">
<style>
  * {{ box-sizing: border-box; margin: 0; }}
  body {{
    background: #f3f3f3; color: #1a1a1a; padding: 28px 32px;
    font-family: "Segoe UI Variable Text", "Segoe UI", "Yu Gothic UI", sans-serif;
  }}
  h1 {{ font-size: 22px; font-weight: 600; margin-bottom: 4px; }}
  .lead {{ font-size: 13px; color: #5d5d5d; margin-bottom: 22px; }}
  section {{ margin-bottom: 26px; }}
  h2 {{ font-size: 15px; font-weight: 600; margin-bottom: 12px;
        display: flex; align-items: center; gap: 8px; }}
  h2 i {{ width: 11px; height: 11px; border-radius: 3px; display: block; }}
  .grid {{ display: flex; align-items: flex-end; gap: 18px; flex-wrap: wrap; }}
  figure {{ text-align: center; }}
  .box {{
    background: #fff; border: 1px solid #e1e1e4; border-radius: 8px;
    padding: 10px; display: grid; place-items: center;
  }}
  img {{ image-rendering: pixelated; display: block; }}
  figcaption {{ font-size: 11px; color: #6b6b6b; margin-top: 6px;
                font-variant-numeric: tabular-nums; }}
  .actual {{
    margin-top: 14px; padding: 10px 14px; background: #fff;
    border: 1px solid #e1e1e4; border-radius: 8px;
    display: flex; align-items: center; gap: 14px;
    font-size: 12px; color: #6b6b6b;
  }}
  .actual img {{ image-rendering: auto; }}
</style></head><body>
  <h1>koe-type のアイコン</h1>
  <p class="lead">小さいサイズ（16/20/24/32）は専用の SVG から、
     40px 以上は icon.svg から作っています。拡大表示は最近傍。</p>
  {"".join(rows)}
</body></html>"""


def main() -> int:
    if not (PNG_DIR / "idle-256.png").exists():
        print("先に python tools\\make_icons.py を実行してください。")
        return 2
    print("紹介用画像:")
    ok1 = shoot(social_html(), DOCS / "social-preview.png", 1280, 640)
    print("確認用画像:")
    ok2 = shoot(preview_html(), SHOTS / "icon-preview.png", 1120, 1290)
    return 0 if (ok1 and ok2) else 1


if __name__ == "__main__":
    raise SystemExit(main())
