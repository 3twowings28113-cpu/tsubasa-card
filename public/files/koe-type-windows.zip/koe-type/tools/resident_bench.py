"""常駐モデルの速さと精度を、このPCで実測する。

スピーカーもマイクも使わない。キーも送らない。

    python tools/resident_bench.py                     # 既定の候補
    python tools/resident_bench.py --files 16          # 本数を増やす
    python tools/resident_bench.py --model <ファイル名>
"""

from __future__ import annotations

import argparse
import array
import json
import sys
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import resident  # noqa: E402
from app.textproc import tidy  # noqa: E402
from tools.evaluate import cer  # noqa: E402

AUDIO = ROOT / "bench" / "audio"
PRIVATE = ROOT / "bench" / "private"
MODELS = ROOT / "models"

# この PC で試す候補。(ファイル名, 表示名, 公開されている日本語の誤り率)
CANDIDATES = [
    ("SenseVoiceSmall-Q8_0.gguf", "SenseVoice Small", 7.63),
    ("moonshine-base-ja-Q8_0.gguf", "Moonshine Base 日本語", 10.81),
    ("ggml-large-v3-turbo-q8_0.bin", "Whisper large-v3-turbo", 4.82),
    ("Fun-ASR-MLT-Nano-2512-Q8_0.gguf", "Fun-ASR-MLT-Nano", 2.32),
]

def load_vocab() -> list[str]:
    """固有名詞のヒントは、辞書の「正しい表記」から取る。

    ここに直接書くと、利用者の固有名詞がリポジトリに入ってしまう。
    （privacy_check がそれを見つけてくれた）
    """
    from app.textproc import Dictionary  # noqa: PLC0415
    for path in (ROOT / "dictionary.txt", ROOT / "dictionary.sample.txt"):
        if path.is_file():
            return Dictionary(path).hints[:48]
    return []


def read_pcm(path: Path) -> tuple[bytes, float]:
    with wave.open(str(path)) as w:
        data = w.readframes(w.getnframes())
        return data, w.getnframes() / w.getframerate()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--files", type=int, default=8)
    ap.add_argument("--model", default="")
    ap.add_argument("--backend", default="vulkan,cpu")
    ap.add_argument("--vocab", action="store_true", help="語彙ヒントも試す")
    args = ap.parse_args()

    ok, why = resident.available()
    print(f"常駐方式: {'使える' if ok else '使えない'} {why}")
    if not ok:
        return 2

    truth = json.loads((PRIVATE / "audio_truth.json").read_text("utf-8"))
    files = [AUDIO / f"{k}.wav" for k in sorted(truth)][:args.files]
    files = [f for f in files if f.is_file()]
    total_audio = sum(read_pcm(f)[1] for f in files)
    print(f"音声 {len(files)} 本 / 合計 {total_audio:.1f} 秒\n")

    candidates = ([(args.model, args.model, 0.0)] if args.model
                  else CANDIDATES)
    backends = [b.strip() for b in args.backend.split(",") if b.strip()]
    vocab = load_vocab()
    summary = []

    for filename, label, published in candidates:
        path = MODELS / filename
        if not path.is_file():
            print(f"── {label}: ファイルがありません（{filename}）")
            continue
        for backend in backends:
            print(f"── {label} / {backend}")
            eng = resident.Resident(path, backend=backend, language="ja")
            try:
                eng.load()
            except Exception as exc:
                print(f"   読み込めません: {str(exc)[:140]}\n")
                continue
            print(f"   読み込み {eng.load_seconds:.2f}s")
            # 1 回目は捨てる（最初だけ余計にかかる）
            try:
                eng.transcribe_pcm(bytes(16000))
            except Exception:
                pass

            rows, broken = [], 0
            for f in files:
                pcm, secs = read_pcm(f)
                t0 = time.perf_counter()
                try:
                    raw = eng.transcribe_pcm(pcm, vocabulary=(vocab if args.vocab
                                                              else None))
                except Exception as exc:
                    print(f"   {f.stem}: 失敗 {type(exc).__name__}")
                    broken += 1
                    continue
                took = time.perf_counter() - t0
                text = tidy(raw, punctuation=True, fillers=False,
                            halfwidth=True)
                if not text:
                    broken += 1
                rows.append({"id": f.stem, "secs": secs, "took": took,
                             "cer": cer(truth[f.stem], text), "text": text})
            if not rows:
                print("   1 本も測れませんでした\n")
                eng.unload()
                continue
            avg = sum(r["took"] for r in rows) / len(rows)
            per5 = sum(r["took"] / r["secs"] * 5 for r in rows) / len(rows)
            mean_cer = sum(r["cer"] for r in rows) / len(rows)
            worst = max(rows, key=lambda r: r["cer"])
            print(f"   1件 {avg:.3f}s / 5秒換算 {per5:.3f}s / "
                  f"最大 {max(r['took'] for r in rows):.3f}s")
            print(f"   CER {mean_cer:.4f}（公開値 {published}%）"
                  f"  空・失敗 {broken} 本")
            print(f"   いちばん悪かったもの {worst['id']} CER {worst['cer']:.3f}")
            print(f"     正解: {truth[worst['id']][:60]}")
            print(f"     結果: {worst['text'][:60]}")
            print()
            summary.append({
                "model": label, "file": filename, "backend": backend,
                "load_s": round(eng.load_seconds, 3),
                "avg_s": round(avg, 3), "per5s": round(per5, 3),
                "cer": round(mean_cer, 4), "broken": broken,
                "published_cer": published,
                "rows": rows,
            })
            eng.unload()

    print("=" * 78)
    print(f" {'モデル':26s} {'backend':8s} {'読込':>6s} {'1件':>7s} "
          f"{'5秒換算':>8s} {'CER':>7s} {'失敗':>5s}")
    for s in sorted(summary, key=lambda s: s["per5s"]):
        print(f" {s['model']:26s} {s['backend']:8s} {s['load_s']:5.2f}s "
              f"{s['avg_s']:6.3f}s {s['per5s']:7.3f}s {s['cer']:7.4f} "
              f"{s['broken']:5d}")
    print("=" * 78)
    print(" 速さの予算: 最初の文字 1.5 秒以内 / 話し終わって 0.5 秒以内")
    print(" 「話しながら」は 2 回一致で確定するので、1 件が 0.5 秒を切ると"
          "予算に入る")

    out = ROOT / "bench" / "eval" / "resident.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(summary, ensure_ascii=False, indent=1), "utf-8")
    print(f"\n 書き出し: {out.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
