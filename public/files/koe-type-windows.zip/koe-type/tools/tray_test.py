r"""トレイメニューの「よく使う切り替え」のテスト。

句読点設定、音声コマンドトグル、直前の結果コピー、モデル切り替えの
トレイ連動を、本物のキー送信やウィンドウ操作なしで検証する。

  python tools\tray_test.py
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_sandbox = Path(tempfile.mkdtemp(prefix="koe-type-tray-test-"))
(_sandbox / "logs").mkdir()
(_sandbox / "data").mkdir()
os.environ["KOE_TYPE_HOME"] = str(_sandbox)
os.environ["KOE_TYPE_DRY_RUN"] = "1"
os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

from app import configstore, dryrun, inject, winthread
from app.main import Controller

passed = 0
failed = 0


def check(name: str, got: object, want: object) -> None:
    global passed, failed
    if got == want:
        print(f"  OK   {name}")
        passed += 1
    else:
        print(f"  NG   {name}")
        print(f"       期待: {want!r}")
        print(f"       実際: {got!r}")
        failed += 1


def main() -> None:
    print("=" * 60)
    print(" トレイメニューのクイック切り替えテスト")
    print("=" * 60)

    ctl = Controller()
    cfg = ctl.cfg

    # 1. クイック設定プロバイダ
    print("\n[1] クイック設定プロバイダの動作")
    qs = ctl._quick_settings()
    check("句読点設定が取得できる", qs.get("punct_density"), "few")
    check("音声コマンド設定が取得できる", qs.get("voice_commands"), True)
    check("現在のモデルが取得できる", isinstance(qs.get("current_model"), str), True)
    check("利用可能なモデル一覧がリスト", isinstance(qs.get("ready_models"), list), True)

    # 2. メニューからの句読点切り替え
    print("\n[2] 句読点の切り替え")
    ctl._menu("punct:normal")
    check("句読点が標準に変わる", cfg.str_("punctuation_density"), "normal")
    ctl._menu("punct:many")
    check("句読点が多めに変わる", cfg.str_("punctuation_density"), "many")
    ctl._menu("punct:few")
    check("句読点が少なめに戻る", cfg.str_("punctuation_density"), "few")

    # 3. 音声コマンドのトグル
    print("\n[3] 音声コマンドの切り替え")
    check("初期は音声コマンド有効", cfg.bool_("voice_commands", True), True)
    ctl._menu("voice_commands")
    check("トレイから無効化できる", cfg.bool_("voice_commands", True), False)
    ctl._menu("voice_commands")
    check("トレイから再有効化できる", cfg.bool_("voice_commands", True), True)

    # 4. 直前の結果をクリップボードにコピー
    print("\n[4] 直前の結果をクリップボードにコピー")
    ctl.last_text = "テスト用の文字起こし結果です"
    ctl._menu("copy_last")
    clip_entries = [e for e in dryrun.entries() if e.get("kind") == "clipboard"]
    check("クリップボードへの記録がある", len(clip_entries) > 0, True)
    check("文字が正しくコピーされる", clip_entries[-1].get("text"), "テスト用の文字起こし結果です")

    # 5. winthread のメニューコマンドマッピング
    print("\n[5] メニューコマンドIDのマッピング")
    commands_sent: list[str] = []
    wt = winthread.WinThread(
        on_hotkey_down=lambda: None,
        on_hotkey_up=lambda: None,
        on_send=lambda: None,
        on_cancel=lambda: None,
        on_menu=lambda name: commands_sent.append(name),
        is_recording=lambda: False,
    )
    wt._menu_command(winthread.ID_PUNCT_FEW)
    check("ID_PUNCT_FEW が punct:few にマップされる", commands_sent[-1], "punct:few")
    wt._menu_command(winthread.ID_PUNCT_NORMAL)
    check("ID_PUNCT_NORMAL が punct:normal にマップされる", commands_sent[-1], "punct:normal")
    wt._menu_command(winthread.ID_PUNCT_MANY)
    check("ID_PUNCT_MANY が punct:many にマップされる", commands_sent[-1], "punct:many")
    wt._menu_command(winthread.ID_VOICE_COMMANDS)
    check("ID_VOICE_COMMANDS が voice_commands にマップされる", commands_sent[-1], "voice_commands")
    wt._menu_command(winthread.ID_COPY_LAST)
    check("ID_COPY_LAST が copy_last にマップされる", commands_sent[-1], "copy_last")
    wt._menu_command(winthread.ID_LANG_JA)
    check("ID_LANG_JA が lang:ja にマップされる", commands_sent[-1], "lang:ja")
    wt._menu_command(winthread.ID_LANG_EN)
    check("ID_LANG_EN が lang:en にマップされる", commands_sent[-1], "lang:en")
    wt._menu_command(winthread.ID_LANG_AUTO)
    check("ID_LANG_AUTO が lang:auto にマップされる", commands_sent[-1], "lang:auto")

    # モデルIDの動的マッピング
    wt._menu_model_keys = ["model-a", "model-b"]
    wt._menu_command(winthread.ID_MODEL_BASE + 1)
    check("モデルIDが model:model-b にマップされる", commands_sent[-1], "model:model-b")

    print(f"\n==== 成功 {passed} / 失敗 {failed} ====")
    if failed:
        sys.exit(1)


if __name__ == "__main__":
    main()
