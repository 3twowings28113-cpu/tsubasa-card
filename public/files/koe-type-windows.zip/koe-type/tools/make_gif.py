r"""「使っている様子」の GIF を作る。**本物のキーを 1 回も送らない。**

画面も撮らない。録音中の帯が描いた中身をそのまま並べて、
GIF にする。だから**画面がロックされていても作れる**。

GIF の書き出しは標準ライブラリだけで行う（LZW も自前）。
pip パッケージを足さない決まりのため。

    python tools\make_gif.py
    python tools\make_gif.py --design wave --theme dark
    python tools\make_gif.py --out docs\demo.gif
"""

from __future__ import annotations

import argparse
import ctypes
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import overlay as ov  # noqa: E402

# 話していく様子。(経過秒, 声の大きさ, いま聞こえている文字)
SCRIPT_TEXT = "きょうの打ち合わせは午前10時から会議室でやります"
HINT = "Ctrl + Space で止める　・　Esc で取り消し"


def frames_plan(fps: int = 12) -> list:
    """1 コマずつの中身を作る。"""
    plan = []
    # 1) 出てくる（まだ何も聞こえていない）
    for i in range(int(fps * 0.5)):
        plan.append(("recording", i / fps, 0.12, "", ""))
    # 2) 話す（文字が増えていく）
    chars = len(SCRIPT_TEXT)
    speak = int(fps * 3.2)
    for i in range(speak):
        at = i / speak
        shown = SCRIPT_TEXT[:max(1, int(chars * at))]
        # 声の大きさは、ことばの切れ目で少し落ちる
        level = 0.30 + 0.45 * abs(((i * 7) % 23) / 23 - 0.5) * 2
        if i % 11 in (0, 1):
            level *= 0.35
        plan.append(("recording", 0.5 + at * 3.2, level, shown, ""))
    # 3) 文字にしている
    for i in range(int(fps * 0.7)):
        plan.append(("transcribing", 0.0, 0.0, "", ""))
    # 4) 止まった
    for i in range(int(fps * 0.9)):
        plan.append(("done", 0.0, 0.0, "", "入力しました"))
    return plan


# ---------------------------------------------------------------- 色を減らす


def quantize(frames: list, size: tuple) -> tuple:
    """全コマをまとめて 255 色に落とす（GIF は 256 色まで）。

    やり方は「よく出る色から順に取る」。帯は色数が少ないので、
    これで十分きれいに出る。残り 1 色は透明に使う。
    """
    counts: dict = {}
    for rgba in frames:
        for i in range(0, len(rgba), 4):
            r, g, b, a = rgba[i:i + 4]
            if a < 24:
                continue
            key = (r >> 2 << 2, g >> 2 << 2, b >> 2 << 2)
            counts[key] = counts.get(key, 0) + 1
    palette = [c for c, _ in sorted(counts.items(), key=lambda kv: -kv[1])]
    palette = palette[:255]
    if not palette:
        palette = [(0, 0, 0)]

    # 近い色を引くための箱
    cache: dict = {}

    def nearest(r: int, g: int, b: int) -> int:
        key = (r >> 2, g >> 2, b >> 2)
        hit = cache.get(key)
        if hit is not None:
            return hit
        best, best_d = 0, 1 << 30
        for idx, (pr, pg, pb) in enumerate(palette):
            d = (pr - r) ** 2 + (pg - g) ** 2 + (pb - b) ** 2
            if d < best_d:
                best, best_d = idx, d
                if d == 0:
                    break
        cache[key] = best
        return best

    transparent = len(palette)
    indexed = []
    for rgba in frames:
        buf = bytearray(len(rgba) // 4)
        for i in range(0, len(rgba), 4):
            r, g, b, a = rgba[i:i + 4]
            buf[i // 4] = transparent if a < 24 else nearest(r, g, b)
        indexed.append(bytes(buf))
    return indexed, palette, transparent


# ---------------------------------------------------------------- LZW


def lzw(data: bytes, bits: int) -> bytes:
    """GIF の LZW。標準ライブラリだけで書く。"""
    clear = 1 << bits
    end = clear + 1
    size = bits + 1
    table = {bytes([i]): i for i in range(clear)}
    nxt = end + 1

    out = bytearray()
    buffer = 0
    nbits = 0

    def emit(code: int) -> None:
        nonlocal buffer, nbits
        buffer |= code << nbits
        nbits += size
        while nbits >= 8:
            out.append(buffer & 0xFF)
            buffer >>= 8
            nbits -= 8

    emit(clear)
    current = b""
    for byte in data:
        probe = current + bytes([byte])
        if probe in table:
            current = probe
            continue
        emit(table[current])
        if nxt < 4096:
            table[probe] = nxt
            nxt += 1
            if nxt > (1 << size) and size < 12:
                size += 1
        else:
            emit(clear)
            table = {bytes([i]): i for i in range(clear)}
            nxt = end + 1
            size = bits + 1
        current = bytes([byte])
    if current:
        emit(table[current])
    emit(end)
    if nbits:
        out.append(buffer & 0xFF)
    return bytes(out)


def blocks(data: bytes) -> bytes:
    out = bytearray()
    for i in range(0, len(data), 255):
        piece = data[i:i + 255]
        out.append(len(piece))
        out += piece
    out.append(0)
    return bytes(out)


def write_gif(path: Path, frames: list, palette: list, transparent: int,
              w: int, h: int, delay_cs: int) -> None:
    bits = max(2, (len(palette) + 1 - 1).bit_length())
    table_size = 1 << bits
    table = bytearray()
    for i in range(table_size):
        if i < len(palette):
            table += bytes(palette[i])
        else:
            table += b"\x00\x00\x00"

    out = bytearray()
    out += b"GIF89a"
    out += w.to_bytes(2, "little") + h.to_bytes(2, "little")
    out += bytes([0xF0 | (bits - 1), 0, 0])
    out += table
    # くり返し
    out += b"\x21\xFF\x0BNETSCAPE2.0\x03\x01\x00\x00\x00"

    for frame in frames:
        out += b"\x21\xF9\x04"
        out += bytes([0x09])           # 前のコマを消してから描く＋透明あり
        out += delay_cs.to_bytes(2, "little")
        out += bytes([transparent, 0])
        out += b"\x2C"
        out += (0).to_bytes(2, "little") + (0).to_bytes(2, "little")
        out += w.to_bytes(2, "little") + h.to_bytes(2, "little")
        out += bytes([0])
        out += bytes([bits])
        out += blocks(lzw(frame, bits))
    out += b"\x3B"
    path.write_bytes(bytes(out))


# ---------------------------------------------------------------- 本体


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--design", default=ov.DESIGN_DEFAULT, choices=list(ov.DESIGNS))
    ap.add_argument("--theme", default="light", choices=["light", "dark"])
    ap.add_argument("--size", default="medium")
    ap.add_argument("--fps", type=int, default=12)
    ap.add_argument("--out", default="")
    ap.add_argument("--bg", default="",
                    help="背景の色（既定：テーマに合わせた紙の色）。"
                         "none にすると透明のまま")
    args = ap.parse_args()

    out = (Path(args.out) if args.out
           else ROOT / "docs" / f"demo-{args.design}-{args.theme}.gif")
    out.parent.mkdir(parents=True, exist_ok=True)

    if not ov._start_gdiplus():
        print("GDI+ を始められませんでした")
        return 1

    bar = ov.Overlay()
    bar.configure(theme_name=args.theme, position="bottom", size=args.size,
                  margin_px=16, enabled=True, design=args.design,
                  hint_text=HINT, show_hint=True)
    bar._animate = False
    for name in ov.FONTS:
        family = ctypes.c_void_p()
        if ov.gdiplus.GdipCreateFontFamilyFromName(
                name, None, ctypes.byref(family)) == 0:
            bar._font_family = family
            break

    print(f"  案 {args.design} / {args.theme} / {args.fps} コマ毎秒")
    plan = frames_plan(args.fps)
    raw = []
    width = height = 0
    try:
        for state, elapsed, level, pending, message in plan:
            bar.set_state(state, elapsed=elapsed, level=level,
                          pending=pending, message=message)
            bar._pump_wave(len(bar._wave) or 30, level, state == "recording")
            shot = bar.snapshot()
            if shot is None:
                continue
            w, h, rgba = shot
            width, height = max(width, w), max(height, h)
            raw.append((w, h, rgba))
    finally:
        if bar._font_family:
            ov.gdiplus.GdipDeleteFontFamily(bar._font_family)

    if not raw:
        print("  コマを作れませんでした")
        return 1

    # 大きさがコマごとに変わるので、いちばん大きいものに合わせて中央へ置く
    fixed = []
    for w, h, rgba in raw:
        if (w, h) == (width, height):
            fixed.append(rgba)
            continue
        canvas = bytearray(width * height * 4)
        ox, oy = (width - w) // 2, (height - h) // 2
        for y in range(h):
            src = y * w * 4
            dst = ((y + oy) * width + ox) * 4
            canvas[dst:dst + w * 4] = rgba[src:src + w * 4]
        fixed.append(bytes(canvas))

    # 透明のままだと、影が黒く見えることがある。
    # README に貼ったときに自然になるよう、紙の色を敷く。
    if args.bg != "none":
        hex_bg = args.bg or ("#f3f3f3" if args.theme == "light" else "#202020")
        br, bg_, bb = (int(hex_bg.lstrip("#")[i:i + 2], 16)
                       for i in (0, 2, 4))
        flat = []
        for rgba in fixed:
            buf = bytearray(len(rgba))
            for i in range(0, len(rgba), 4):
                r, g, b, a = rgba[i:i + 4]
                if a == 255:
                    buf[i:i + 4] = bytes((r, g, b, 255))
                else:
                    f = a / 255
                    buf[i:i + 4] = bytes((
                        int(r * f + br * (1 - f)),
                        int(g * f + bg_ * (1 - f)),
                        int(b * f + bb * (1 - f)), 255))
            flat.append(bytes(buf))
        fixed = flat

    print(f"  {len(fixed)} コマ / {width}x{height}")
    indexed, palette, transparent = quantize(fixed, (width, height))
    print(f"  色 {len(palette)} 色")
    write_gif(out, indexed, palette, transparent, width, height,
              max(2, round(100 / args.fps)))
    print(f"\n  できました: {out}  "
          f"（{out.stat().st_size / 1024:.0f} KB）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
