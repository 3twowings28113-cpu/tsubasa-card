"""Enter送信の未確定文字フラッシュと使用感プリセットの自動テスト。

本物のキー送信や音声出力は一切行わない（から打ちモード KOE_TYPE_DRY_RUN=1）。
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ["KOE_TYPE_DRY_RUN"] = "1"

from app import dryrun, schema  # noqa: E402
from app.configstore import Config  # noqa: E402
from app.websettings import Bridge  # noqa: E402

_SANDBOX = ROOT / "logs" / "test_preset_submit"


def check(name: str, actual: object, expected: object) -> None:
    if actual == expected:
        print(f"  OK   {name}")
    else:
        print(f"  NG   {name}: got={actual!r} want={expected!r}")
        sys.exit(1)


def test_presets_data() -> None:
    print("\n[1 使用感プリセットの定義と網羅性]")
    pids = [p["id"] for p in schema.PRESETS]
    check("4つのプリセットが定義されている", len(pids), 4)
    check("チャットプリセットがある", "chat" in pids, True)
    check("執筆プリセットがある", "writing" in pids, True)
    check("コーディングプリセットがある", "coding" in pids, True)
    check("初心者プリセットがある", "beginner" in pids, True)

    chat = next(p for p in schema.PRESETS if p["id"] == "chat")
    check("チャットプリセットは Enter 送信オン",
          chat["settings"]["enter_sends"], True)
    check("チャットプリセットの遅延は 200ms 以上",
          chat["settings"]["enter_delay_ms"] >= 200, True)


def test_apply_preset_action() -> None:
    print("\n[2 プリセット適用の動作検証]")
    _SANDBOX.mkdir(parents=True, exist_ok=True)
    cfg_file = _SANDBOX / "config.json"
    if cfg_file.exists():
        cfg_file.unlink()

    cfg = Config(cfg_file)
    notified: list[tuple[str, dict]] = []

    def mock_action(name: str, **kw: object) -> object:
        notified.append((name, kw))
        return None

    class Dummy:
        def detailed_entries(self) -> list:
            return []

        def recent(self, n: int = 400) -> list:
            return []

    d = Dummy()
    bridge = Bridge(cfg, d, d, mock_action)

    # 1. state() に presets が含まれるか
    st = bridge.state()
    check("state() に presets が返る", len(st.get("presets", [])), 4)

    # 2. チャットプリセットを適用
    res = bridge.run_action("apply_preset", {"preset": "chat"})
    check("プリセット適用アクションが成功する", res.get("ok"), True)
    check("enter_sends が True になる", cfg.bool_("enter_sends"), True)
    check("send_key が enter になる", cfg.str_("send_key"), "enter")
    check("enter_delay_ms が 220 になる", cfg.int_("enter_delay_ms"), 220)
    check("stop_on_click が outside になる",
          cfg.str_("stop_on_click"), "outside")
    check("full_stops が off になる", cfg.str_("full_stops"), "off")

    # 3. 執筆プリセットを適用
    res2 = bridge.run_action("apply_preset", {"preset": "writing"})
    check("執筆プリセット適用が成功する", res2.get("ok"), True)
    check("enter_sends が False になる", cfg.bool_("enter_sends"), False)
    check("stop_on_click が off になる", cfg.str_("stop_on_click"), "off")
    check("full_stops が all になる", cfg.str_("full_stops"), "all")

    # 4. 不明なプリセットはエラーを返す
    res_err = bridge.run_action("apply_preset", {"preset": "unknown_xxx"})
    check("不正なプリセットは拒否される", res_err.get("ok"), False)


def test_pending_flush_logic() -> None:
    print("\n[3 録音停止時の未確定文字（pending）フラッシュ機構]")
    from app.streaming import Agreement  # noqa: PLC0415
    agree = Agreement(rounds=3, min_span=0.8)

    # まだ3回一致していない発話途中の状態をシミュレート
    agree.update("お世話になっております。よろしくお願", 1.0)
    agree.update("お世話になっております。よろしくお願いし", 1.5)
    # committed（確定入力済み）が "お世話になっております。" だけだったとする
    agree.committed = "お世話になっております。"

    # pending() が残りの文字を返せるか確認
    leftover = agree.pending()
    check("未確定の残り文字が取り出せる",
          leftover, "よろしくお願いし")


def main() -> None:
    print("==================================================================")
    print(" Enter送信の未確定文字フラッシュ＆使用感プリセット機能テスト")
    print("==================================================================")
    test_presets_data()
    test_apply_preset_action()
    test_pending_flush_logic()
    print("\n==================================================================")
    print(" すべてのテストに合格しました！")
    print("==================================================================")


if __name__ == "__main__":
    main()
