"""配布用の zip を作る。

入れるもの：アプリのコード、設定画面、見本の辞書、アイコン、文書。
**入れないもの**：モデル、エンジン、利用者の設定・辞書・履歴・ログ、
評価用の音声、個人の固有名詞の一覧。

モデルとエンジンはリポジトリにも zip にも入れません。
受け取った人が初回起動時か設定画面からダウンロードします
（ライセンスの都合と、合わせて 1GB を超える大きさのため）。

    python tools/make_dist.py
    python tools/make_dist.py --out C:\\somewhere
    python tools/make_dist.py --check    # 中身を確かめるだけ（zip は作らない）
"""

from __future__ import annotations

import argparse
import hashlib
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.util import VERSION  # noqa: E402

# 入れるもの（フォルダは中身ごと）
INCLUDE_FILES = (
    "koe-type.pyw", "setup.cmd", "setup.ps1",
    "dictionary.sample.txt", "LICENSE", "README.md", "README.en.md",
    "CHANGELOG.md", "THIRD_PARTY_NOTICES.md", ".gitignore",
)
INCLUDE_DIRS = ("app", "vendor", "assets/icon", "docs", "tools")

# 入れないもの（上のフォルダの中にあっても除く）
EXCLUDE_PARTS = (
    "__pycache__", ".pyc", ".pyo",
    "private_words.txt",          # 個人の固有名詞
    "manual_e2e.py",              # 本物のキーを送るテスト（配布しない）
)
EXCLUDE_DIRS = ("logs", "data", "models", "engines", "bench",
                ".git", "node_modules")

# zip に入ってはいけないもの（入っていたら作るのをやめる）
FORBIDDEN_SUFFIX = (".wav", ".mp3", ".db", ".sqlite", ".log",
                    ".gguf", ".bin", ".exe", ".dll")
FORBIDDEN_NAMES = ("config.json", "dictionary.txt", "dictionary.user.txt")


def wanted(path: Path) -> bool:
    rel = path.relative_to(ROOT).as_posix()
    if any(part in rel for part in EXCLUDE_PARTS):
        return False
    return not any(rel.startswith(d + "/") or rel == d for d in EXCLUDE_DIRS)


def collect() -> list[Path]:
    out: list[Path] = []
    for name in INCLUDE_FILES:
        path = ROOT / name
        if path.is_file():
            out.append(path)
        else:
            print(f"  ※ ありません（飛ばします）: {name}")
    for folder in INCLUDE_DIRS:
        base = ROOT / folder
        if not base.is_dir():
            print(f"  ※ ありません（飛ばします）: {folder}/")
            continue
        for path in sorted(base.rglob("*")):
            if path.is_file() and wanted(path):
                out.append(path)
    return sorted(set(out))


def check(files: list[Path]) -> list[str]:
    """入ってはいけないものが混ざっていないか。"""
    problems = []
    for path in files:
        rel = path.relative_to(ROOT).as_posix()
        if path.name in FORBIDDEN_NAMES:
            problems.append(f"{rel}: 利用者のファイルです")
        if path.suffix.lower() in FORBIDDEN_SUFFIX:
            problems.append(f"{rel}: この拡張子は配布物に入れません")
        if path.stat().st_size > 8 * 1024 * 1024:
            problems.append(f"{rel}: 大きすぎます "
                            f"（{path.stat().st_size / 1e6:.1f}MB）")
    return problems


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default="")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    print("=" * 68)
    print(f" 配布用 zip を作ります（koe-type {VERSION}）")
    print("=" * 68)

    files = collect()
    total = sum(f.stat().st_size for f in files)
    print(f"\n 入れるファイル {len(files)} 個 / 合計 {total / 1e6:.2f} MB")

    kinds: dict[str, int] = {}
    for f in files:
        top = f.relative_to(ROOT).parts[0]
        kinds[top] = kinds.get(top, 0) + 1
    for name, count in sorted(kinds.items(), key=lambda x: -x[1]):
        print(f"   {name:24s} {count:4d} 個")

    problems = check(files)
    if problems:
        print("\n■ 入ってはいけないものがあります")
        for line in problems:
            print("  -", line)
        print("\n zip は作りませんでした。")
        return 1
    print("\n 入ってはいけないものはありません。")

    if args.check:
        return 0

    out_dir = Path(args.out) if args.out else ROOT / "dist"
    out_dir.mkdir(parents=True, exist_ok=True)
    target = out_dir / f"koe-type-{VERSION}.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED,
                         compresslevel=9) as zf:
        for path in files:
            zf.write(path, f"koe-type/{path.relative_to(ROOT).as_posix()}")
        # ファイル名は ASCII にする。日本語の名前は、展開に使う道具に
        # よって文字化けすることがある（Git Bash の unzip で確認した）。
        zf.writestr("koe-type/START-HERE.txt", FIRST_RUN)

    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    print(f"\n できました: {target.relative_to(ROOT)}"
          f"（{target.stat().st_size / 1e6:.2f} MB）")
    print(f" SHA-256: {digest}")
    print("\n 受け取った人がすること")
    print("   1. zip を好きな場所に展開する（Program Files の中は避ける）")
    print("   2. setup.cmd をダブルクリック（Python がなければ案内が出ます）")
    print("   3. 設定画面が開くので、モデルをダウンロードする（253MB）")
    return 0


FIRST_RUN = """koe-type — Windows 用の日本語音声入力

はじめかた
  1. このフォルダを好きな場所に置いてください。
     （Program Files の中は避けてください。書き込めないことがあります）
  2. setup.cmd をダブルクリックしてください。
     Python が入っていなければ、入れ方の案内が出ます。
  3. 設定画面が開いたら、「文字起こし」で
     モデル（253MB）をダウンロードしてください。
     一度取得すれば、以降はネットなしで動きます。

使い方
  Ctrl+Space      録音の開始／停止
  Enter           録音中なら、入力してから送信
  Esc             録音中なら中止

  タスクトレイのアイコンを右クリックで、設定・辞書・履歴を開けます。

うまく動かないとき
  設定画面の「アプリ」→「動作チェック」を押してください。
  何が足りないかと、その直し方が出ます。

  docs\\TROUBLESHOOTING.md にも、よくある詰まりどころを書いています。

プライバシー
  音声はこの PC の外に出ません。
  通信するのは、モデルを最初にダウンロードするときだけです。
  詳しくは docs\\PRIVACY.md をご覧ください。

ライセンス
  このソフトは MIT ライセンスです（LICENSE をご覧ください）。
  文字起こしのモデルは、それぞれ別のライセンスです。
  設定画面のモデル一覧に表示されます。
"""


if __name__ == "__main__":
    raise SystemExit(main())
