r"""koe-type をこの PC に登録する。**管理者権限は要らない。**

やること（どれもユーザー単位。Windows の設定は変えない）

  1. スタートメニューにショートカットを作る
  2. サインイン時に自動で始まるように登録する（`HKCU\...\Run` だけ）
  3. koe-type を起動する（初めてなら案内が開く）

ショートカットは **PowerShell の WScript.Shell** で作る。PowerShell は
Microsoft の署名つきで、Smart App Control でも動く。新しい exe を
増やさないための選択。

    python tools/install.py
    python tools/install.py --no-autostart
    python tools/install.py --no-start      # 登録だけして起動しない
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

APP_NAME = "koe-type"


def start_menu_dir() -> Path:
    base = os.environ.get("APPDATA", "")
    return Path(base) / "Microsoft" / "Windows" / "Start Menu" / "Programs"


def runtime_pythonw() -> Path:
    """同梱の署名済み Python。無ければ、いま動いている Python。"""
    bundled = ROOT / "runtime" / "pythonw.exe"
    if bundled.is_file():
        return bundled
    exe = Path(sys.executable)
    if exe.name.lower() == "python.exe":
        alt = exe.with_name("pythonw.exe")
        if alt.is_file():
            return alt
    return exe


def ps_quote(value: object) -> str:
    """PowerShell の '…' の中に入れる文字列にする。

    ' は '' と書く決まり。フォルダ名に ' があるとショートカット作りが
    壊れていた（O'Brien さんのユーザーフォルダなど）。
    """
    return "'" + str(value).replace("'", "''") + "'"


def unpacked_in_temp(root: Path) -> bool:
    """zip を展開せずに中から実行した（＝一時フォルダにいる）か。

    エクスプローラーで zip を開いたまま install.cmd を押すと、Windows は
    一時フォルダに取り出して実行する。その場所を登録すると、あとで
    消えて起動しなくなる。初めての人がいちばんやりがちな操作。
    """
    temp = os.environ.get("TEMP") or os.environ.get("TMP") or ""
    if not temp:
        return False
    try:
        root.resolve().relative_to(Path(temp).resolve())
        return True
    except ValueError:
        return False


def make_shortcut(path: Path, target: Path, args: str,
                  workdir: Path, icon: Path | None) -> bool:
    """ショートカット（.lnk）を作る。PowerShell に任せる。"""
    icon_line = ""
    if icon and icon.is_file():
        icon_line = f"$s.IconLocation = {ps_quote(icon)}\n"
    script = (
        "$w = New-Object -ComObject WScript.Shell\n"
        f"$s = $w.CreateShortcut({ps_quote(path)})\n"
        f"$s.TargetPath = {ps_quote(target)}\n"
        f"$s.Arguments = {ps_quote(args)}\n"
        f"$s.WorkingDirectory = {ps_quote(workdir)}\n"
        f"$s.Description = 'koe-type 日本語音声入力'\n"
        + icon_line +
        "$s.Save()\n")
    try:
        proc = subprocess.run(  # noqa: S603
            ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
             "-Command", script],
            capture_output=True, text=True, timeout=60)
    except Exception as exc:  # noqa: BLE001
        print(f"  ショートカットを作れませんでした: {exc}")
        return False
    if proc.returncode != 0:
        print(f"  ショートカットを作れませんでした: "
              f"{(proc.stderr or '').strip()[:200]}")
        return False
    return path.is_file()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--no-autostart", action="store_true")
    ap.add_argument("--no-shortcut", action="store_true")
    ap.add_argument("--no-start", action="store_true")
    args = ap.parse_args()

    print("=" * 66)
    print(" koe-type をこの PC に登録します")
    print(" 管理者権限は要りません。Windows の設定は変えません。")
    print("=" * 66)

    pythonw = runtime_pythonw()
    target = ROOT / "koe-type.pyw"
    if not target.is_file():
        print(f"\n  本体が見つかりません: {target}")
        return 1
    if unpacked_in_temp(ROOT):
        print("\n  zip を開いたまま実行しているようです。")
        print("  このままだと、すぐ消える一時フォルダを登録してしまいます。")
        print("\n  1. zip を右クリック →「すべて展開」")
        print("  2. 展開してできたフォルダの install.cmd を実行")
        print("\n  （登録はしていません）")
        return 1
    bundled = (ROOT / "runtime" / "pythonw.exe").is_file()
    print(f"\n  置き場所  {ROOT}")
    print(f"  Python    {pythonw}"
          f"{'（同梱の署名済み）' if bundled else '（この PC のもの）'}")

    ok = True

    if not args.no_shortcut:
        print("\n[1] スタートメニューに登録")
        folder = start_menu_dir()
        if not folder.is_dir():
            print(f"  スタートメニューのフォルダがありません: {folder}")
            ok = False
        else:
            icon = ROOT / "assets" / "icon" / "koe-type.ico"
            link = folder / f"{APP_NAME}.lnk"
            if make_shortcut(link, pythonw, f'"{target}"', ROOT,
                             icon if icon.is_file() else None):
                print(f"  作りました: {link}")
            else:
                ok = False
    else:
        print("\n[1] スタートメニューへの登録は飛ばします")

    if not args.no_autostart:
        print("\n[2] サインイン時に自動で始まるように登録")
        from app import autostart  # noqa: PLC0415
        if autostart.enable():
            print(f"  登録しました: {autostart.command()}")
        else:
            print("  登録できませんでした")
            ok = False
    else:
        print("\n[2] 自動起動の登録は飛ばします")

    if not args.no_start:
        print("\n[3] 起動します")
        try:
            subprocess.Popen(  # noqa: S603
                [str(pythonw), str(target)], cwd=str(ROOT),
                creationflags=0x08000000)
            print("  起動しました。タスクトレイに絵が出ます。")
            print("  初めてのときは、案内の画面が開きます。")
        except Exception as exc:  # noqa: BLE001
            print(f"  起動できませんでした: {exc}")
            ok = False

    print("\n" + "=" * 66)
    if ok:
        print(" 準備ができました。Ctrl + Space で録音を始められます。")
    else:
        print(" いくつか登録できませんでした。上の行を見てください。")
    print(" 消すときは uninstall.cmd（設定を残すか選べます）")
    print("=" * 66)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
