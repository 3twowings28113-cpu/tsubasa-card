r"""マイクもスピーカーも使わない自己診断。

設定・文字整形・辞書・区間切り・クリップボードを、その場で作った一時データで試す。
利用者の設定や辞書は書き換えない。

  python tools\selftest.py
"""

from __future__ import annotations

import array
import math
import sys
import tempfile
import time
import wave
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# ★利用者の設定・辞書・履歴には触らない。
# 使い捨てのフォルダを KOE_TYPE_HOME にしてから app を読み込む
# （app.util は読み込んだ時点で置き場所を決めるので、import より前）。
# 以前ここが無く、設定画面の検査が**本物の config.json** を
# 書き換えていた（戻してはいたが、決まりに反する）。
import os  # noqa: E402

if not os.environ.get("KOE_TYPE_SELFTEST_HOME"):
    _sandbox = Path(tempfile.mkdtemp(prefix="koe-type-selftest-"))
    (_sandbox / "logs").mkdir()
    (_sandbox / "data").mkdir()
    os.environ["KOE_TYPE_HOME"] = str(_sandbox)
    os.environ["KOE_TYPE_SELFTEST_HOME"] = str(_sandbox)
    os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

from app import catalog, inject, schema                # noqa: E402
from app.audio import SAMPLE_RATE, devices             # noqa: E402
from app.configstore import Config                     # noqa: E402
from app.textproc import Dictionary, is_noise, tidy    # noqa: E402
from app.util import ensure_dirs, setup_logging        # noqa: E402
from app.vad import SegmentCutter                      # noqa: E402
from app.winthread import parse_hotkey                 # noqa: E402

ok_count = 0
fail_count = 0


def _clipboard_roundtrip() -> None:
    """本物のクリップボードで、預かって返せるかを試す。

    利用者がコピーしていた中身を先に預かり、最後に必ず返す。
    キーは1つも送らない（貼り付けはしない）。
    """
    original = inject.snapshot_clipboard()
    try:
        inject.set_clipboard_text("もとの中身")
        saved = inject.snapshot_clipboard()
        check("スナップショットが取れた",
              saved is not None and len(saved) > 0, True)
        inject.set_clipboard_text("入れ替えた中身")
        inject.restore_clipboard(saved)
        time.sleep(0.1)
        text_now = ""
        for fmt, data in (inject.snapshot_clipboard() or []):
            if fmt == inject.CF_UNICODETEXT:
                text_now = data.decode("utf-16-le").rstrip("\x00")
        check("元に戻っている", text_now, "もとの中身")
    finally:
        inject.restore_clipboard(original)
        print("       （利用者のクリップボードは元に戻しました）")


def check(label: str, got, want=None, *, truthy: bool = False) -> None:
    global ok_count, fail_count
    good = bool(got) if truthy else got == want
    if good:
        ok_count += 1
        print(f"  OK   {label}")
    else:
        fail_count += 1
        print(f"  NG   {label}\n        got : {got!r}\n        want: {want!r}")


def tone(seconds: float, freq: float = 220.0, amp: int = 6000) -> bytes:
    """発話の代わりに使う音。無音と区別できればよい。"""
    import math
    import struct
    n = int(SAMPLE_RATE * seconds)
    return b"".join(
        struct.pack("<h", int(math.sin(2 * math.pi * freq * i / SAMPLE_RATE) * amp))
        for i in range(n))


def main() -> int:
    ensure_dirs()
    setup_logging("INFO")

    print("\n[1] 設定")
    cfg = Config()
    check("既定値がそろっている", len(schema.defaults()) >= 30, True)
    check("モデルが選ばれている", cfg.str_("model"), truthy=True)
    check("ホットキーを読める", parse_hotkey("ctrl+space"), (0x20, frozenset({"ctrl"})))
    check("別のホットキーも読める", parse_hotkey("alt+shift+f5"),
          (0x74, frozenset({"alt", "shift"})))
    check("壊れたホットキーは既定に落ちる", parse_hotkey("???")[0], 0x20)
    print(f"       モデル={cfg.str_('model')} / "
          f"録音={cfg.str_('hotkey')} / 中止={cfg.str_('cancel_hotkey')}")

    print("\n[2] 文字の整形")
    check("日本語の間の空白を取る",
          tidy("今日 の 日付 と 見出 しの 部分"), "今日の日付と見出しの部分")
    check("英単語の間の空白は残す",
          tidy("Claude  Code and Git"), "Claude Code and Git")
    check("英字と日本語の間の空白は落とす",
          tidy("Claude Code で作る"), "Claude Codeで作る")
    check("前後の空白と改行を落とす", tidy("  あいうえお \n "), "あいうえお")
    check("先頭の句読点を落とす", tidy("、はい"), "はい")
    check("タグを落とす", tidy("<|ja|><|NEUTRAL|>こんにちは"), "こんにちは")
    check("フィラー語を消す",
          tidy("えーと、明日の予定です", fillers=True), "明日の予定です")
    check("句読点を外せる",
          tidy("はい、そうです。", punctuation=False), "はいそうです")
    check("全角英数字を半角にする",
          tidy("ＡＢＣ１０時", halfwidth=True), "ABC10時")
    check("記号だけは入力しない", is_noise("。") and is_noise("?"), True)
    check("ふつうの語は入力する", is_noise("はい"), False)

    print("\n[3] 置き換え辞書（一時ファイルで試す）")
    with tempfile.TemporaryDirectory(prefix="koe-type-test-") as tmp:
        path = Path(tmp) / "dictionary.txt"
        path.write_text("# 見本\nあいう=ABC\nかきく=XYZ\nre:[0-9]+ばん=\\g<0>目\n",
                        "utf-8")
        d = Dictionary(path)
        check("置き換えが効く", d.apply("あいうとかきく"), "ABCとXYZ")
        check("正規表現が効く", d.apply("3ばん"), "3ばん目")
        check("件数が取れる", len(d.entries()), 3)
        check("ヒント語が取れる", sorted(d.hints), ["ABC", "XYZ"])

        d.save(d.entries() + [("さしす", "QQQ")])
        check("画面から追加できる", d.apply("さしす"), "QQQ")
        d.save([r for r in d.entries() if r[0] != "あいう"])
        check("画面から削除できる", d.apply("あいう"), "あいう")

        out = Path(tmp) / "export.txt"
        check("書き出せる", d.export_file(out), True)
        check("書き出したものを読み込める",
              Dictionary(out).apply("かきく"), "XYZ")

        # 保存のたびに読み直されること（再起動なしの反映）
        path.write_text("ななな=777\n", "utf-8")
        time.sleep(0.02)
        check("保存したらすぐ反映される", d.apply("ななな"), "777")

    print("\n[4] 無音の切れ目で区間を切る")
    cutter = SegmentCutter(SAMPLE_RATE, pause_ms=700, min_speech_ms=300,
                           max_segment_ms=15000, preroll_ms=200, tail_ms=250,
                           sensitivity=3.0, floor=180.0)
    silence = bytes(SAMPLE_RATE * 2)                     # 1 秒の無音
    stream = silence[:SAMPLE_RATE] + tone(1.2) + silence + tone(0.9) + silence
    got: list[bytes] = []
    step = SAMPLE_RATE * 2 * 50 // 1000
    for i in range(0, len(stream), step):
        got.extend(cutter.feed(stream[i:i + step]))
    got.extend(cutter.flush())
    check("2 区間に分かれる", len(got), 2)
    if len(got) == 2:
        check("1区間目の長さが妥当（1.0〜2.0秒）",
              1.0 <= len(got[0]) / (SAMPLE_RATE * 2) <= 2.0, True)
    check("無音だけなら区間にならない",
          SegmentCutter(SAMPLE_RATE, pause_ms=700, min_speech_ms=300,
                        max_segment_ms=15000, preroll_ms=200, tail_ms=250,
                        sensitivity=3.0, floor=180.0).feed(silence * 3), [])

    # ★話している最中に区切られ、残りの声が捨てられていた（2026-10-06）。
    # 雑音の上でしゃべり続け、ところどころ声が小さくなる音。前は 6 秒の
    # 音が 4 秒で切られ、2 秒ぶんがどこにも出なかった。
    import random as _random
    _random.seed(1)

    def voiced(seconds: float, amp: float) -> bytes:
        n = int(SAMPLE_RATE * seconds)
        return array.array("h", [
            int(max(-32000, min(32000, amp * math.sin(i * 0.07) * 1.414
                                + _random.gauss(0, 300))))
            for i in range(n)]).tobytes()

    def hiss(seconds: float) -> bytes:
        return array.array("h", [int(_random.gauss(0, 300))
                                 for _ in range(int(SAMPLE_RATE * seconds))]
                           ).tobytes()

    talk = b"".join(voiced(0.15, 7000) + voiced(0.05, 2200)
                    for _ in range(30))                 # 6 秒
    cutter = SegmentCutter(SAMPLE_RATE, pause_ms=700, min_speech_ms=300,
                           max_segment_ms=15000, preroll_ms=200, tail_ms=250,
                           sensitivity=3.0, floor=180.0, merge_short_ms=0)
    got = []
    stream = hiss(1.0) + talk + hiss(1.5)
    for i in range(0, len(stream), step):
        got.extend(cutter.feed(stream[i:i + step]))
    got.extend(cutter.flush())
    total = sum(len(g) for g in got) / (SAMPLE_RATE * 2)
    check(f"しゃべり続けた 6 秒が途中で捨てられない（{total:.2f} 秒ぶん）",
          total >= 6.0, True)

    print("\n[5] モデルと実行ファイル")
    for key, spec in catalog.MODELS.items():
        missing = catalog.missing_assets(key)
        state = "そろっている" if not missing else f"{len(missing)} ファイル不足"
        print(f"       {key:24} {state}")
    check("カタログが 3 つ以上ある", len(catalog.MODELS) >= 3, True)
    check("既定のモデルが定義されている",
          catalog.DEFAULT_MODEL in catalog.MODELS, True)

    print("\n[6] マイク")
    found = devices()
    print(f"       {len(found)} 台: " +
          (", ".join(name for _i, name in found) or "（なし）"))
    check("マイクの一覧を取れる", isinstance(found, list), True)

    print("\n[7] クリップボードの保存と復元")
    # ★本物のクリップボードを書き換えるので、`--clipboard` を付けた
    # ときだけ試す。利用者が PC を使っているあいだに流すと、預かって
    # から返すまでの間にコピーした物を古い中身で上書きしてしまう。
    # から打ちモードでは書き込みが記録だけになり、確かめられない。
    check("履歴よけの形式が登録できる",
          len(inject._no_history_marks()) >= 2, True)
    if "--clipboard" in sys.argv[1:] and not inject.dryrun.enabled():
        _clipboard_roundtrip()
    else:
        print("       （本物での保存と復元は省略。試すときは --clipboard）")

    print("\n[8] 設定画面のサーバー")
    import json as _json
    import urllib.error
    import urllib.request
    from app.history import History
    from app.websettings import Bridge, SettingsServer, find_edge

    def on_action(name, **kw):  # noqa: ANN001, ANN202
        return [] if name == "running_apps" else None

    server = SettingsServer(Bridge(cfg, Dictionary(), History(), on_action))
    server.keep_open = True
    server.start()

    def fetch(path, token=None, body=None):  # noqa: ANN001, ANN202
        url = (f"http://127.0.0.1:{server.port}{path}?t="
               + (server.token if token is None else token))
        data = _json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            url, data=data,
            headers={"Content-Type": "application/json"} if data else {})
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, r.read()
        except urllib.error.HTTPError as exc:
            return exc.code, exc.read()

    try:
        code, body = fetch("/")
        check("トップページが返る",
              code == 200 and (b"SpeakPulse" in body or b"koe-type" in body),
              True)
        check("合言葉が本文に残っていない", b"__TOKEN__" not in body, True)
        check("CSS が返る", fetch("/assets/app.css")[0], 200)
        check("JS が返る", fetch("/assets/app.js")[0], 200)

        code, body = fetch("/api/state")
        state = _json.loads(body)
        check("状態が返る", code, 200)
        # 9 つめはクリップボード（2026-10-11 に足した）
        check("カテゴリが 9 つ", len(state["categories"]), 9)
        check("モデルの一覧がある", len(state["models"]) >= 3, True)
        check("表示文字列がある", len(state["text"]) > 40, True)

        check("合言葉が違えば断る", fetch("/", token="wrong")[0], 403)
        check("フォルダを抜けられない",
              fetch("/assets/../../config.json")[0] in (403, 404), True)

        before = cfg.int_("pause_ms")
        code, body = fetch("/api/set", body={"key": "pause_ms", "value": 900})
        check("設定を変えられる", _json.loads(body).get("ok"), True)
        check("値が反映される", cfg.int_("pause_ms"), 900)
        fetch("/api/set", body={"key": "pause_ms", "value": 99999})
        check("範囲外は丸められる", cfg.int_("pause_ms"), 2000)
        cfg.set("pause_ms", before)
        code, body = fetch("/api/set", body={"key": "nope", "value": 1})
        check("知らないキーは断る", _json.loads(body).get("ok"), False)
        check("Edge が見つかる", find_edge() is not None, True)
    finally:
        server.stop()

    # 履歴：録音をその場で聞き直す口と、聞き違いを辞書に足す操作
    from app import history as _hist
    hist = History()
    rec = _hist.store_audio(b"\x00\x00" * 1600)
    hist.add("テストの記録", model="t", seconds=0.1, audio=rec, limit=50)
    row_id = hist.recent(1)[0]["id"]
    dictionary = Dictionary()
    server = SettingsServer(Bridge(cfg, dictionary, hist, on_action))
    server.keep_open = True
    server.start()
    try:
        def get_raw(path):  # noqa: ANN001, ANN202
            url = f"http://127.0.0.1:{server.port}{path}&t={server.token}"
            try:
                with urllib.request.urlopen(url, timeout=5) as r:
                    return r.status, r.headers.get("Content-Type"), r.read()
            except urllib.error.HTTPError as exc:
                return exc.code, "", b""
        code, ctype, body = get_raw(f"/api/history_audio?id={row_id}")
        check("履歴の録音を返す", (code, ctype, body[:4]),
              (200, "audio/wav", b"RIFF"))
        check("無い番号は断る", get_raw("/api/history_audio?id=999999")[0], 404)
        check("番号でない指定は断る",
              get_raw("/api/history_audio?id=..%2Fconfig")[0], 404)
        state = _json.loads(fetch("/api/state")[1])
        check("画面に「録音あり」が渡る",
              any(h["audio"] for h in state["history"]), True)
        ok1 = _json.loads(fetch("/api/action", body={
            "name": "dict_add", "from": "パテナ", "to": "はてな"})[1])
        ok2 = _json.loads(fetch("/api/action", body={
            "name": "dict_add", "from": "パテナ", "to": "別"})[1])
        check("聞き違いを辞書に足せる", ok1.get("ok"), True)
        check("同じ「元」は二重に足さない", ok2.get("ok"), False)
        check("辞書に入っている", ("パテナ", "はてな") in dictionary.entries(),
              True)
    finally:
        server.stop()

    # ★Edge の更新から、起動した msedge.exe はすぐ終わる（本当の窓は別の
    # プロセス）。それを「閉じた」と見てサーバーを止め、設定の窓が
    # 「接続が拒否されました」になっていた（2026-10-06）。すぐ終わる
    # プロセスを起動したことにして、心拍が届くあいだは止めないかを見る。
    import subprocess as _sp2
    server = SettingsServer(Bridge(cfg, Dictionary(), History(), on_action))
    server.start()
    try:
        server._browser = _sp2.Popen([sys.executable, "-c", "pass"])
        server._browser.wait(timeout=10)
        for _ in range(3):
            fetch("/api/beat", body={})
            time.sleep(1.2)
        check("起動したプロセスが終わっても、心拍があれば止めない",
              server.running, True)
        check("心拍があれば「開いている」とみなす", server.page_alive(), True)
    finally:
        server.stop()

    # ★ページを移るときにも「閉じます」が届く。すぐ閉じると
    # 「初回の案内をもう一度」で窓ごと消えた（2026-10-05）。
    import time as _time
    from app import websettings as _ws
    server = SettingsServer(Bridge(cfg, Dictionary(), History(), on_action))
    server.start()
    try:
        fetch("/api/close", body={})
        _time.sleep(0.3)
        fetch("/onboarding")            # 次のページが開いた
        _time.sleep(_ws.CLOSE_GRACE + 0.6)
        check("ページを移っただけなら閉じない", server.running, True)
        fetch("/api/close", body={})
        _time.sleep(_ws.CLOSE_GRACE + 0.6)
        check("本当に閉じたら閉じる", server.running, False)
    finally:
        server.stop()

    print("\n[8b] 一時停止（トレイから）でショートカットを手放す")
    # 本物の RegisterHotKey は使わず、登録を覚えるだけの偽物で確かめる
    from app import inputwatch as _iw
    from app.winthread import WinThread

    class FakeKeys:
        def __init__(self) -> None:
            self.held: set[int] = set()

        def register(self, key_id, mods, vk):  # noqa: ANN001, ANN201
            self.held.add(key_id)
            return True

        def unregister(self, key_id):  # noqa: ANN001, ANN201
            self.held.discard(key_id)

    win = WinThread.__new__(WinThread)
    win.keys = FakeKeys()
    win.hotkey_mods, win.hotkey_vk = {"ctrl"}, 0x20
    win.cancel_mods, win.cancel_vk = set(), 0x1B
    win.enter_sends = True
    win._excluded_now_flag = False
    win.paused = False
    recording = {"now": False}
    win._is_recording = lambda: recording["now"]
    win._apply_hotkeys_now()
    check("ふだんは録音のショートカットを持つ",
          _iw.ID_RECORD in win.keys.held, True)
    win.paused = True
    win._apply_hotkeys_now()
    check("一時停止中は手放す", _iw.ID_RECORD in win.keys.held, False)
    recording["now"] = True
    win._apply_hotkeys_now()
    check("録音中なら一時停止でも止められる（手放さない）",
          _iw.ID_RECORD in win.keys.held, True)
    recording["now"] = False
    win.paused = False
    win._apply_hotkeys_now()
    check("再開すると持ち直す", _iw.ID_RECORD in win.keys.held, True)

    print("\n[8c] 長押し：キーを離したことに気づく")
    # ★RegisterHotKey は離したことを知らせない。前は何もしておらず、
    # 「長押しの間だけ」で録音を止められなかった。キーの状態を偽物にして、
    # 押している間は待ち、離したら知らせるかを見る。
    from app import winthread as _wt

    class FakeUser32:
        def __init__(self) -> None:
            self.down = True
            self.timers: set[int] = set()

        def GetAsyncKeyState(self, vk):  # noqa: ANN001, ANN201, N802
            return -32768 if self.down else 0

        def SetTimer(self, hwnd, tid, ms, fn):  # noqa: ANN001, ANN201, N802
            self.timers.add(tid)
            return tid

        def KillTimer(self, hwnd, tid):  # noqa: ANN001, ANN201, N802
            self.timers.discard(tid)
            return 1

    fake = FakeUser32()
    real = _wt.user32
    _wt.user32 = fake
    try:
        ups: list[float] = []
        win2 = WinThread.__new__(WinThread)
        win2._hwnd = 1
        win2.hold_mode = True
        win2.hotkey_vk = 0x20
        win2._hotkey_held = False
        win2._down_at = 0.0
        win2._on_hotkey_down = lambda: None
        win2._on_hotkey_up = lambda held: ups.append(held)
        win2._hotkey_fired(_iw.ID_RECORD)
        check("押したら見張りのタイマーが動く",
              _wt.RELEASE_TIMER in fake.timers, True)
        win2._poll_release()
        check("押している間は知らせない", ups, [])
        fake.down = False
        win2._poll_release()
        check("離したら 1 回だけ知らせる", len(ups), 1)
        check("離したらタイマーを止める",
              _wt.RELEASE_TIMER in fake.timers, False)
        win2._poll_release()
        check("二度は知らせない", len(ups), 1)
    finally:
        _wt.user32 = real

    print("\n[8d] 再起動：古いほうが終わるのを待って鍵を取る")
    # ★トレイの「再起動」は新しいほうを先に起こす。古いほうの終了が
    # 遅れると、新しいほうが「すでに起動している」で終わり、何も
    # 動いていない状態になりえた。本物の鍵とは別の名前で試す。
    import subprocess as _sp
    import uuid as _uuid
    from app.main import single_instance
    lock = f"Local\\koe-type-selftest-{_uuid.uuid4().hex[:8]}"
    holder = _sp.Popen([sys.executable, "-c",
                        "import ctypes, time; k = ctypes.WinDLL('kernel32'); "
                        "k.CreateMutexW.restype = ctypes.c_void_p; "
                        f"h = k.CreateMutexW(None, True, {lock!r}); "
                        "time.sleep(1.5)"])
    try:
        time.sleep(0.6)
        check("待たなければ取れない（ふつうの二重起動）",
              single_instance(wait=0.0, name=lock), False)
        started = time.monotonic()
        got = single_instance(wait=8.0, name=lock)
        check("待てば取れる（古いほうが終わったら）", got, True)
        check("古いほうが終わるまで待った",
              time.monotonic() - started > 0.3, True)
    finally:
        holder.wait(timeout=10)

    print("\n[8e] ログ：ほかのプロセスが開いていても書き続ける")
    # ★見張り役が同じログを開いていて、1MB を超えた瞬間から回せなくなり、
    # それ以降のログが 1 行も残らなかった（2026-10-06）。
    import logging as _logging
    import tempfile as _tempfile
    from app.util import _SafeRotatingHandler
    with _tempfile.TemporaryDirectory() as _tmp:
        path = Path(_tmp) / "t.log"
        handler = _SafeRotatingHandler(path, maxBytes=2000, backupCount=2,
                                       encoding="utf-8")
        logger = _logging.getLogger("selftest-rotate")
        logger.propagate = False
        logger.addHandler(handler)
        holder = None
        try:
            logger.warning("はじめ")
            holder = open(path, encoding="utf-8")   # 別の誰かが開いている
            for i in range(200):
                logger.warning("行 %d %s", i, "x" * 40)
            handler.flush()
            text = path.read_text("utf-8", "replace")
            check("回せなくても最後の行まで書けている", "行 199" in text, True)
        finally:
            if holder:
                holder.close()
            logger.removeHandler(handler)
            handler.close()

    print("\n[9] 音声ファイルの書き出し")
    from app import engines
    wav = engines.temp_wav()
    try:
        engines.write_wav(wav, tone(0.3))
        with wave.open(str(wav)) as w:
            check("16kHz モノラル 16bit で書ける",
                  (w.getframerate(), w.getnchannels(), w.getsampwidth()),
                  (16000, 1, 2))
    finally:
        wav.unlink(missing_ok=True)

    print("\n[10] 設定の案内（困りごとから探す）")
    from app import guide as _guide
    check("案内トピックが10件以上ある", len(_guide.GUIDE_TOPICS) >= 10, True)
    _all_keys = (set(schema.defaults().keys())
                 | {"model", "dictionary", "history"})
    _all_cats = ({c.key for c in schema.CATEGORIES}
                 | {"models", "dictionary", "history"})
    _keys_valid = True
    for _tp in _guide.GUIDE_TOPICS:
        if _tp.target_key and _tp.target_key not in _all_keys:
            _keys_valid = False
        if (_tp.target_key
                and schema.find_category(_tp.target_key) not in _all_cats):
            _keys_valid = False
        for _ch in _tp.choices:
            if _ch.target_key not in _all_keys:
                _keys_valid = False
            if schema.find_category(_ch.target_key) not in _all_cats:
                _keys_valid = False
    check("全案内の設定キーとカテゴリが実在する", _keys_valid, True)
    _serialized = _guide.serialize_guides()
    check("Web 画面用のシリアライズができる",
          len(_serialized) == len(_guide.GUIDE_TOPICS), True)

    print(f"\n==== 成功 {ok_count} / 失敗 {fail_count} ====")
    return 1 if fail_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
