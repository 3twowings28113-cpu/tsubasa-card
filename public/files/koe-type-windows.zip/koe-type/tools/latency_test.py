"""速さの予算を守れているかを測る。キーは1回も送らない。

測るもの（PRODUCT_SPEC の H1 / H2）
  H1 話し始めてから最初の文字が入るまで **1.5 秒以内**
  H2 話し終わってから全部入るまで **0.5 秒以内**

アプリ本体をそのまま動かし、から打ちの記録（logs/dryrun.jsonl）の
時刻から逆算する。音は WAV を実時間で流し込む。

    python tools/latency_test.py                 # 既定（話しながら）
    python tools/latency_test.py --mode phrase
    python tools/latency_test.py --load cpu      # CPU を埋めた状態で測る
    python tools/latency_test.py --files 6
"""

from __future__ import annotations

import argparse
import json
import multiprocessing
import sys
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tools.evaluate import cer  # noqa: E402
from tools.mock_e2e import AUDIO, make_home, run_app  # noqa: E402

TRUTH = json.loads((ROOT / "bench" / "private" / "audio_truth.json")
                   .read_text("utf-8")) if (
    ROOT / "bench" / "private" / "audio_truth.json").exists() else {}

BUDGET_FIRST = 1.5
BUDGET_TAIL = 0.5


def wav_seconds(path: Path) -> float:
    with wave.open(str(path)) as w:
        return w.getnframes() / w.getframerate()


def burn(stop_at: float) -> None:
    """CPU を埋める（混んでいる状態を作る）。"""
    x = 0.0
    while time.time() < stop_at:
        for i in range(200000):
            x += i * 0.5
    return


def measure(home: Path, wav: Path, mode: str) -> dict:
    """1 本ぶん測る。戻り値は最初の文字と、話し終わりからの遅れ。"""
    secs = wav_seconds(wav)
    start = 0.5
    stop = start + secs + 0.3          # 話し終わって 0.3 秒で停止操作
    script = [
        {"at": start, "event": "hotkey_down"},
        {"at": stop, "event": "stop"},
        {"at": stop + 8.0, "event": "quit"},
    ]
    r = run_app(home, wav, script, timeout=90)
    entries = r["entries"]
    begin = next((float(e["t"]) for e in entries
                  if e.get("kind") == "event"
                  and e.get("event") == "hotkey_down"), None)
    texts = [e for e in entries if e.get("kind") in ("paste", "copy")
             and e.get("text")]
    if begin is None:
        return {"id": wav.stem, "error": "録音開始の記録がない",
                "rc": r["rc"], "stderr": r["stderr"][:200]}
    speech_end = begin + secs
    first = (float(texts[0]["t"]) - begin) if texts else None
    last = (float(texts[-1]["t"]) - speech_end) if texts else None
    return {
        "id": wav.stem, "seconds": round(secs, 2), "mode": mode,
        "first": round(first, 3) if first is not None else None,
        "tail": round(last, 3) if last is not None else None,
        "chars": sum(len(e["text"]) for e in texts),
        "pastes": len(texts),
        "text": "".join(e["text"] for e in texts),
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--mode", default="stream", help="stream / phrase")
    ap.add_argument("--files", type=int, default=4)
    ap.add_argument("--model", default="")
    ap.add_argument("--load", default="", help="cpu を指定すると CPU を埋める")
    ap.add_argument("--load-cores", type=int, default=0,
                    help="埋めるコア数（0 なら全コア-1）")
    ap.add_argument("--rounds", type=int, default=0,
                    help="確定までの一致回数（0 で設定どおり）")
    ap.add_argument("--interval", type=int, default=0,
                    help="聞き直す間隔ミリ秒（0 で設定どおり）")
    ap.add_argument("--workers", type=int, default=0)
    ap.add_argument("--span", type=int, default=-1,
                    help="一致に必要な音の増え方ミリ秒（-1 で設定どおり）")
    args = ap.parse_args()

    config = {"input_mode": args.mode}
    if args.model:
        config["model"] = args.model
    if args.rounds:
        config["stream_agree_rounds"] = args.rounds
    if args.interval:
        config["stream_interval_ms"] = args.interval
    if args.workers:
        config["stream_workers"] = args.workers
    if args.span >= 0:
        config["stream_agree_span_ms"] = args.span

    files = sorted(AUDIO.glob("p0*.wav"))[:args.files]
    print("=" * 72)
    print(f" 速さの予算を測る（{args.mode}"
          + (f" / CPU を埋めた状態" if args.load == "cpu" else "") + "）")
    print(f" 目標: 最初の文字 {BUDGET_FIRST}s 以内 / "
          f"話し終わってから {BUDGET_TAIL}s 以内")
    print("=" * 72)

    burners = []
    if args.load == "cpu":
        n = args.load_cores or max(1, (multiprocessing.cpu_count() or 4) - 1)
        stop_at = time.time() + 60 * len(files) + 60
        for _ in range(n):
            p = multiprocessing.Process(target=burn, args=(stop_at,),
                                        daemon=True)
            p.start()
            burners.append(p)
        print(f" CPU を {n} 本の処理で埋めました\n")

    rows = []
    try:
        for index, wav in enumerate(files, 1):
            home = make_home(ROOT / "bench" / "eval" /
                             f"_lat{args.span if args.span >= 0 else 'x'}_{index}",
                             config)
            row = measure(home, wav, args.mode)
            rows.append(row)
            if row.get("error"):
                print(f"  {row['id']}: {row['error']} rc={row.get('rc')}")
                continue
            ok_first = row["first"] is not None and row["first"] <= BUDGET_FIRST
            ok_tail = row["tail"] is not None and row["tail"] <= BUDGET_TAIL
            print(f"  {row['id']}  音 {row['seconds']:4.1f}s  "
                  f"最初 {row['first']} s {'OK' if ok_first else 'NG'}  "
                  f"語尾 {row['tail']} s {'OK' if ok_tail else 'NG'}  "
                  f"{row['pastes']} 回 / {row['chars']} 字")
            row["cer"] = round(cer(TRUTH.get(row["id"], ""), row["text"]), 4)
            print(f"      CER {row['cer']}  {row['text'][:60]}")
    finally:
        for p in burners:
            p.terminate()

    good = [r for r in rows if not r.get("error") and r["first"] is not None]
    if good:
        firsts = [r["first"] for r in good]
        tails = [r["tail"] for r in good if r["tail"] is not None]
        print("\n" + "=" * 72)
        print(f" 最初の文字: 平均 {sum(firsts)/len(firsts):.2f}s / "
              f"最大 {max(firsts):.2f}s / 予算内 "
              f"{sum(1 for f in firsts if f <= BUDGET_FIRST)}/{len(firsts)}")
        if tails:
            print(f" 語尾まで　: 平均 {sum(tails)/len(tails):.2f}s / "
                  f"最大 {max(tails):.2f}s / 予算内 "
                  f"{sum(1 for t in tails if t <= BUDGET_TAIL)}/{len(tails)}")
        cers = [r["cer"] for r in good if r.get("cer") is not None]
        if cers:
            print(f" 入った文字の誤り率: 平均 {sum(cers)/len(cers):.4f} / "
                  f"最大 {max(cers):.4f}")
        print("=" * 72)

    tag = f"{args.load}{args.load_cores or ''}" if args.load else ""
    if args.span >= 0:
        tag += f"-span{args.span}"
    out = ROOT / "bench" / "eval" / f"latency-{args.mode}{tag}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, ensure_ascii=False, indent=1), "utf-8")
    print(f" 書き出し: {out.relative_to(ROOT)}")
    bad = [r for r in good
           if r["first"] > BUDGET_FIRST
           or (r["tail"] is not None and r["tail"] > BUDGET_TAIL)]
    return 1 if (bad or not good) else 0


if __name__ == "__main__":
    raise SystemExit(main())
