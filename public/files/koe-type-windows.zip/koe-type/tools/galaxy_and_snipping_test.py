"""Galaxy S25風かこって検索・画面オーバーラップ・オーバーレイ文字表示設定の検証テスト。

自動テストの決まり：
  ・本物のキー入力（SendInput）を行わない（KOE_TYPE_DRY_RUN=1）
  ・スピーカーから音を流さない
  ・pip パッケージを追加しない
"""

import os
import sys
from pathlib import Path

# テスト環境の設定
os.environ["KOE_TYPE_DRY_RUN"] = "1"
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import recipes, schema, snipping, transform, vision

passed = 0
failed = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  OK   {name}")
    else:
        failed += 1
        print(f"  NG   {name} ({detail})")


print("\n[1] overlay_text 設定（基本設定への昇格）")
item_text = schema.find("overlay_text")
check("overlay_text が存在する", item_text is not None)
check("overlay_text が基本設定 (advanced=False)",
      item_text is not None and not item_text.advanced)

print("\n[2] snipping モジュール（Galaxy S25風画面選択）")
rect = snipping.select_region()
check("dryrun で select_region が矩形を返す", rect == (100, 100, 400, 300))

print("\n[3] vision モジュール（矩形キャプチャ）")
img = vision.capture_window_or_screen(rect=(10, 10, 200, 150))
check("rect 指定で JPEG バイト列が返る", bool(img and len(img) > 10))

print("\n[4] recipes モジュール（かこって検索の標準ラインナップ）")
all_recipes = recipes.from_config([])
screen_r = next((r for r in all_recipes if r.id == "screen_assistant"), None)
check("レシピ一覧に screen_assistant が存在する", screen_r is not None)
check("screen_assistant のカテゴリが tools",
      screen_r is not None and screen_r.category == "tools")
check("screen_assistant のショートカットが ctrl+alt+j",
      screen_r is not None and screen_r.hotkey == "ctrl+alt+j")

print("\n[5] transform モジュール（Google検索・質問・カレンダー解析）")
# ネットワーク通信を行わないよう call_gemini_multimodal をモック
def mock_gemini(prompt: str, image_bytes: bytes, **kw: object) -> str:
    if "Google で検索するための" in prompt:
        return "Python エラー解決"
    elif "カレンダー" in prompt or "予定" in prompt:
        return '{"title": "打ち合わせ", "start": "20261025T140000", "end": "20261025T150000", "details": "メモ", "location": "オンライン"}'
    return "これは画面の解説です。"

transform.call_gemini_multimodal = mock_gemini

# 検索
mode, ans, url = transform.process_screen_assistant(
    "このエラーについてGoogleで検索して", b"dummy",
    api_key="test-key", is_offline=False
)
check("検索指示で mode='search' になる", mode == "search")
check("Google 検索 URL が生成される", "google.com/search?q=" in url)
check("検索クエリが含まれる", "Python" in url or "Python" in ans)

# カレンダー
mode_cal, ans_cal, url_cal = transform.process_screen_assistant(
    "明日のミーティングをカレンダーに入れて", b"dummy",
    api_key="test-key", is_offline=False
)
check("カレンダー指示で mode='calendar' になる", mode_cal == "calendar")

# 質問（要約）
mode_ans, ans_txt, url_ans = transform.process_screen_assistant(
    "これ何？説明して", b"dummy",
    api_key="test-key", is_offline=False
)
check("質問指示で mode='answer' になる", mode_ans == "answer")

print("\n[6] open_screen_assistant（dryrun での起動と通知）")
notified = []
snipping.open_screen_assistant(
    cfg=None, engine=None,
    on_notify=lambda m: notified.append(m)
)
check("open_screen_assistant が dryrun 下で例外なく完了する", True)

print("\n[7] ScreenSnipper インスタンスと音声指示・ボタンハンドラ")
snipper = snipping.ScreenSnipper(interactive=True)
check("ScreenSnipper の初期状態が listening（音声指示受付）である", snipper._ai_status == "listening")

# 音声チャンクの受信とレベル計算
fake_chunk = (b"\x00\x00" * 100) + (b"\x00\x10" * 100)
snipper._on_audio_chunk(fake_chunk)
check("音声チャンクを受信してバッファされる", len(snipper._audio_chunks) > 0)

# capture_dc_rect のテスト
dc_jpeg = vision.capture_dc_rect(0, 0, 0, 100, 100)
check("capture_dc_rect が dryrun 下でダミーJPEGを返す", len(dc_jpeg) > 0)

snipper._selected_rect = (10, 10, 200, 150)
snipper._ai_answer = "テスト回答テキスト"
snipper._on_button_click("btn_search")
check("btn_search クリックで _ai_status が busy になる", snipper._ai_status == "busy")

print("\n[8] clipwin レシピショートカット長押し判定")
from app import clipwin
check("RECIPE_HOLD_TIMER 定数が存在する", hasattr(clipwin, "RECIPE_HOLD_TIMER"))

print(f"\n==== 成功 {passed} / 失敗 {failed} ====")
if failed > 0:
    sys.exit(1)
