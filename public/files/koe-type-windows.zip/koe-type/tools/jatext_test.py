"""日本語の整形の検査。音も使わず、キーも送らない。

ここが koe-type の一番の売りなので、細かく確かめる。
特に「やりすぎて意味を変えていないか」を見る。

    python tools/jatext_test.py
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import jatext  # noqa: E402

ok = 0
ng: list[str] = []


def eq(label: str, got: object, want: object) -> None:
    global ok
    if got == want:
        ok += 1
        print(f"  OK   {label}")
    else:
        ng.append(label)
        print(f"  NG   {label}\n         得た: {got!r}\n         欲しい: {want!r}")


print("\n[1] 句読点の形をそろえる")
eq("半角カンマを読点にする",
   jatext.unify_punct("明日は晴れ, 明後日は雨."), "明日は晴れ、明後日は雨。")
eq("全角カンマも読点にする",
   jatext.unify_punct("これは，そうです．"), "これは、そうです。")
eq("数字の中のカンマは壊さない",
   jatext.unify_punct("売上は1,200万円でした."), "売上は1,200万円でした。")
eq("小数点は壊さない",
   jatext.unify_punct("円周率は3.14です."), "円周率は3.14です。")
eq("ドメイン名は壊さない",
   jatext.unify_punct("example.com を見てください."),
   "example.com を見てください。")
eq("感嘆符と疑問符を全角にする",
   jatext.unify_punct("本当ですか? すごい!"), "本当ですか？すごい！")

print("\n[2] 句読点の量")
many = jatext.punctuation(
    "明日の打ち合わせは午前十時から会議室で行いますので関係する方は"
    "資料を持って集まってください", "many")
print(f"       多め: {many}")
eq("多めでも文字そのものは変わらない",
   many.replace("、", ""),
   "明日の打ち合わせは午前十時から会議室で行いますので関係する方は"
   "資料を持って集まってください")
eq("多めで読点が増える", many.count("、") >= 1, True)
few = jatext.punctuation("これは、とても、長い、文章、です、ね。", "few")
print(f"       少なめ: {few}")
eq("少なめで読点が減る", few.count("、") < 5, True)
eq("少なめでも句点は残る", "。" in few, True)
eq("なしで全部取る",
   jatext.punctuation("これは、そうです。", "none"), "これはそうです")
eq("標準は手を加えない",
   jatext.punctuation("これは、そうです。", "normal"), "これは、そうです。")

print("\n[3] 読点を増やす判断")
eq("短い文には足さない",
   jatext.punctuation("今日は晴れです。", "many"), "今日は晴れです。")
eq("文末の直前には足さない",
   jatext.punctuation("明日の会議は中止です。", "many").endswith("中止です。"),
   True)
eq("既にある読点のすぐ後ろには足さない",
   "、、" not in jatext.punctuation(
       "明日は、打ち合わせがありますので資料を用意してください", "many"), True)

print("\n[4] 日本語と英単語のあいだの空白")
eq("既定では入れない",
   jatext.space_between("ClaudeとChatGPTを比べる", "none"),
   "ClaudeとChatGPTを比べる")
eq("設定すれば入れる",
   jatext.space_between("ClaudeとChatGPTを比べる", "space"),
   "Claude と ChatGPT を比べる")
eq("もともと空白があれば増やさない",
   jatext.space_between("Claude と ChatGPT", "space"), "Claude と ChatGPT")

print("\n[5] 漢数字")
eq("既定では変えない",
   jatext.arabic_numbers("午前十時から", False), "午前十時から")
eq("三十二を32にする", jatext.arabic_numbers("三十二人", True), "32人")
eq("十時を10時にする", jatext.arabic_numbers("午前十時から", True), "午前10時から")
eq("二千二十六を2026にする",
   jatext.arabic_numbers("二千二十六年", True), "2026年")
eq("一つは変えない", jatext.arabic_numbers("一つください", True), "一つください")
eq("一番は変えない", jatext.arabic_numbers("一番いいのは", True), "一番いいのは")
eq("十分（じゅうぶん）は変えない",
   jatext.arabic_numbers("十分な準備", True), "十分な準備")
eq("単位だけなら変えない", jatext.arabic_numbers("千葉県", True), "千葉県")

print("\n[6] つなぎ言葉")
pat = jatext.compile_fillers(jatext.DEFAULT_FILLERS)
eq("文頭のえーとを消す",
   jatext.remove_fillers("えーと、明日の予定です。", pat), "明日の予定です。")
eq("途中のあのーを消す",
   jatext.remove_fillers("明日は、あのー、会議です。", pat), "明日は、会議です。")
eq("語の一部は消さない",
   jatext.remove_fillers("なんかしらの理由で。", pat), "なんかしらの理由で。")
eq("あーという語の中は消さない",
   jatext.remove_fillers("あーけーびー。", pat), "あーけーびー。")
eq("単独のなんかは消す",
   jatext.remove_fillers("なんか、よさそうです。", pat), "よさそうです。")
eq("一覧を差し替えられる",
   jatext.remove_fillers("ですね、そうです。",
                         jatext.compile_fillers(["ですね"])), "そうです。")
eq("読点なしの文頭えーを消す",
   jatext.remove_fillers("えー今日は晴れです。", pat), "今日は晴れです。")
eq("読点なしのあーそうですねを消す",
   jatext.remove_fillers("あーそうですね。", pat), "そうですね。")
eq("読点なしのあのー田中さんを消す",
   jatext.remove_fillers("あのー田中さん。", pat), "田中さん。")
eq("文中の読点なしえーとを消す",
   jatext.remove_fillers("明日は、えーと来週の月曜日です。", pat),
   "明日は、来週の月曜日です。")
eq("直後にカタカナ語が続くあーを消す",
   jatext.remove_fillers("あーラーメン食べたい。", pat), "ラーメン食べたい。")
eq("後続文に長音（キーボード）があってもえーを消す",
   jatext.remove_fillers("えー今日はキーボードです。", pat),
   "今日はキーボードです。")
eq("カタカナのエーを消す",
   jatext.remove_fillers("エー明日は晴れです。", pat), "明日は晴れです。")
eq("アーチェリー等のカタカナ一般語は壊さない",
   jatext.remove_fillers("アーチェリー大会。", pat), "アーチェリー大会。")
eq("エース等のカタカナ一般語は壊さない",
   jatext.remove_fillers("エースをねらえ。", pat), "エースをねらえ。")
eq("波ダッシュのあの〜を消す",
   jatext.remove_fillers("あの〜田中さん。", pat), "田中さん。")
eq("助詞のあとの文中のあーを消す",
   jatext.remove_fillers("今日はあー雨です。", pat), "今日は雨です。")
eq("助詞のあとの文中のえーを消す",
   jatext.remove_fillers("それでえー次はこれです。", pat), "それで次はこれです。")
eq("助詞のあとの文中のえっとを消す",
   jatext.remove_fillers("明日はえっと会議です。", pat), "明日は会議です。")
eq("文末に残ったえーとを消す",
   jatext.remove_fillers("それでええと", pat), "それで")
eq("ああいうの意味のあーいうは残す",
   jatext.remove_fillers("会議であーいう話をした。", pat),
   "会議であーいう話をした。")
eq("文頭のため息はあーは残す",
   jatext.remove_fillers("はあー疲れた。", pat), "はあー疲れた。")
eq("ねえーは壊さない",
   jatext.remove_fillers("ねえー聞いて。", pat), "ねえー聞いて。")
eq("通しの整形でも既定でつなぎ言葉が消える",
   jatext.format_text("えー今日はあー雨です", jatext.Options(), final=True),
   "今日は雨です")

print("\n[7] 言い直し")
eq("既定では残す",
   jatext.fix_restatement("明日じゃなくて明後日です。", False),
   "明日じゃなくて明後日です。")
eq("有効なら後ろを残す",
   jatext.fix_restatement("明日じゃなくて明後日です。", True), "明後日です。")
eq("読点のあとからでも効く",
   jatext.fix_restatement("会議は、十時ではなく十一時から。", True),
   "会議は、十一時から。")

print("\n[8] 音声コマンド")
eq("改行", getattr(jatext.match_command("改行"), "value", None), "\n")
eq("かいぎょう（ひらがな）",
   getattr(jatext.match_command("かいぎょう。"), "value", None), "\n")
eq("まる", getattr(jatext.match_command("まる"), "value", None), "。")
eq("はてな", getattr(jatext.match_command("はてな"), "value", None), "？")
eq("疑問符", getattr(jatext.match_command("疑問符"), "value", None), "？")
eq("はてなブログには反応しない",
   jatext.match_command("はてなブログは便利です"), None)
eq("送って", getattr(jatext.match_command("送って"), "kind", None), "submit")
eq("取り消し", getattr(jatext.match_command("取り消し"), "kind", None), "undo")
eq("まるいテーブルには反応しない",
   jatext.match_command("まるいテーブルを買いました。"), None)
eq("改行を含む文には反応しない",
   jatext.match_command("改行コードの話をします。"), None)
eq("長い文には反応しない",
   jatext.match_command("これはとても長い文章なのでコマンドではありません。"),
   None)
eq("空には反応しない", jatext.match_command("。"), None)

print("\n[9] 付けすぎの「？」")
# 既定は「付けない」。ルールで疑問を当てると、「隣りの？」のような
# 途中で切れた言葉まで疑問とみなしてしまった（実際に利用者を困らせた）。
eq("既定では全部落とす",
   jatext.question_marks("どこですか？"), "どこですか。")
eq("既定では言い切りも落とす",
   jatext.question_marks("テスト？"), "テスト。")
eq("途中で切れた言葉も落とす",
   jatext.question_marks("隣りの？"), "隣りの。")
eq("モデルにまかせると触らない",
   jatext.question_marks("テスト？", "model"), "テスト？")

# 「質問のときだけ」を選んだときの動き
eq("推測：質問でないものは句点に",
   jatext.question_marks("テスト？", "smart"), "テスト。")
eq("推測：「隣りの？」は疑問としない",
   jatext.question_marks("隣りの？", "smart"), "隣りの。")
eq("推測：ですか は残す",
   jatext.question_marks("今日の天気はどうですか？", "smart"),
   "今日の天気はどうですか？")
eq("推測：かな は残す",
   jatext.question_marks("これでいいかな？", "smart"), "これでいいかな？")
eq("推測：疑問詞があれば残す",
   jatext.question_marks("どこにありますか？", "smart"), "どこにありますか？")
eq("推測：なぜ〜の も残す",
   jatext.question_marks("なぜそうなるの？", "smart"), "なぜそうなるの？")
eq("推測：ませんか は残す",
   jatext.question_marks("行きませんか？", "smart"), "行きませんか？")

eq("「？」がなければ何もしない",
   jatext.question_marks("明日は晴れです。"), "明日は晴れです。")
eq("整形でも効く（既定は句点も付けない）",
   jatext.format_text("テスト？", jatext.Options()).strip(), "テスト")
eq("句点をモデルのままにすれば句点になる",
   jatext.format_text("テスト？",
                      jatext.Options(full_stops="model")).strip(), "テスト。")
eq("はてな と言えば「？」が入る",
   getattr(jatext.match_command("はてな"), "value", None), "？")

print("\n[10] まとめて整形")
o = jatext.Options()
eq("既定の組み合わせ（句点は付けない）",
   jatext.format_text("えーと, 明日は晴れです.", o), "明日は晴れです")
eq("句点を最後だけなら、最後の区間で付く",
   jatext.format_text("えーと, 明日は晴れです.",
                      jatext.Options(full_stops="end"), final=True),
   "明日は晴れです。")
eq("句点を最後だけなら、途中では付かない",
   jatext.format_text("えーと, 明日は晴れです.",
                      jatext.Options(full_stops="end"), final=False),
   "明日は晴れです")
eq("文の途中の句点は取る",
   jatext.format_text("導入した後に。うまくいかなかったんだよ", o),
   "導入した後にうまくいかなかったんだよ")
eq("読点はそのまま残る",
   "、" in jatext.format_text("これは、そういうことです。", o), True)
o2 = jatext.Options(punctuation="many", arabic_numbers=True, spacing="space")
got = jatext.format_text(
    "えーと、明日の打ち合わせは午前十時からClaudeの話をします", o2)
print(f"       全部入り: {got}")
eq("全部入りでも文字は消えない", "打ち合わせ" in got and "Claude" in got, True)
eq("数字になっている", "10時" in got, True)

print("\n[11] 言葉の途中の句読点（2026-10-05 の立ち会いテストの実例）")
eq("読点で割れた「ございます」をつなぐ",
   jatext.join_split_words("おはようござ、います、今日の天気は晴れです"),
   "おはようございます、今日の天気は晴れです")
eq("句点で割れた「ございます」をつなぐ",
   jatext.join_split_words("おはようござ。います。"), "おはようございます。")
eq("「ました」「ません」の前も取る",
   jatext.join_split_words("行き、ました。分かり、ません"),
   "行きました。分かりません")
eq("文の頭の「ですから」は残す",
   jatext.join_split_words("はい、ですから"), "はい、ですから")
eq("文の頭の「ですが」は残す",
   jatext.join_split_words("了解、ですが"), "了解、ですが")
eq("「ます」で始まらない語の前は触らない",
   jatext.join_split_words("明日、まで"), "明日、まで")
eq("整形の全体でも割れが直る",
   jatext.format_text("おはようござ、います、今日の天気は晴れです。",
                      jatext.Options()),
   "おはようございます、今日の天気は晴れです")

print("\n[13] 読点を文章の決まりで減らす（2026-10-06 利用者の文）")
nc = jatext.natural_commas
eq("口ぐせ（あと、）のあとは落とす",
   nc("あと、句読点の点がめちゃめちゃ多い、これ音声入力で入れている文字だからね"),
   "あと句読点の点がめちゃめちゃ多い、これ音声入力で入れている文字だからね")
eq("言葉を割る読点（〜てる、のも）は落とし、「けど、」は残す",
   nc("で、止まっちゃってる、のもそうなんだけど、言葉の最後のところが"
      "聞こえないのはどうにかしてほしい"),
   "で止まっちゃってるのもそうなんだけど、言葉の最後のところが"
   "聞こえないのはどうにかしてほしい")
eq("「とか」を割る読点は落とす",
   nc("見ることができるファイルと、かってもう作られて"),
   "見ることができるファイルとかってもう作られて")
eq("書き言葉の接続詞（ただ、）のあとは残す",
   nc("ただ、あまりにも今のやつだと変に多すぎる気がする"),
   "ただ、あまりにも今のやつだと変に多すぎる気がする")
eq("長い主題（〜においては、）のあとは残す",
   nc("最終的な発表においては、普通に僕のパソコンで見せる"),
   "最終的な発表においては、普通に僕のパソコンで見せる")
eq("読点がなければそのまま", nc("今日は晴れです"), "今日は晴れです")
eq("少なめの設定で新しい決まりが使われる",
   jatext.punctuation("あと、句読点の点がめちゃめちゃ多い、これを直したい", "few"),
   "あと句読点の点がめちゃめちゃ多い、これを直したい")

print("\n[12] 文の終わりの「はてな」（2026-10-05 の立ち会いテストの実例）")
o = jatext.Options()
eq("続けて言った「はてな」が「？」になる",
   jatext.format_text("ご機嫌どうかなはてな", o), "ご機嫌どうかな？")
eq("読点・句点をはさんでも「？」になる",
   jatext.format_text("ご機嫌どうかな、はてな。", o), "ご機嫌どうかな？")
eq("「はてなマーク」も「？」になる",
   jatext.format_text("ご機嫌どうかなはてなマーク", o), "ご機嫌どうかな？")
eq("「クエスチョン」も「？」になる",
   jatext.format_text("元気ですかクエスチョン", o), "元気ですか？")
eq("文の途中の「はてなブログ」は触らない",
   jatext.format_text("はてなブログは便利です", o), "はてなブログは便利です")
eq("「はてな」だけの区間は音声コマンドに任せる",
   jatext.format_text("はてな", o), "はてな")
eq("音声コマンドを切っていれば替えない",
   jatext.format_text("ご機嫌どうかなはてな",
                      jatext.Options(tail_question=False)),
   "ご機嫌どうかなはてな")
eq("「はてなマーク」だけでも音声コマンドになる",
   getattr(jatext.match_command("はてなマーク"), "value", None), "？")

from app.streaming import Agreement  # noqa: E402
eq("話しながら：末尾の「は」は確定を待つ",
   Agreement._hold_command_start("ご機嫌どうかなは", 8), 7)
eq("話しながら：末尾の「はて」も確定を待つ",
   Agreement._hold_command_start("ご機嫌どうかなはて", 9), 7)
eq("話しながら：関係ない末尾はそのまま",
   Agreement._hold_command_start("今日はいい天気", 7), 7)
ag = Agreement(rounds=3, min_span=0.0)
fresh = ""
for i, t in enumerate(["ご機嫌どうかなはて", "ご機嫌どうかなはてな",
                       "ご機嫌どうかなはてな", "ご機嫌どうかなはてな"]):
    fresh += ag.update(t, 0.5 + i * 0.4)
eq("話しながら：「はて」まで先に入れない",
   "は" in fresh, False)

print("\n[14] 記号の呼び方（symbol_commands）")
custom_syms = [
    {"word": "はてな", "symbol": "？", "enabled": True},
    {"word": "びっくり", "symbol": "！", "enabled": True},
    {"word": "改行", "symbol": "\n", "enabled": True},
    {"word": "ほし", "symbol": "★", "enabled": True},
]
o_custom = jatext.Options(symbol_commands=custom_syms)
eq("びっくりを有効にすると「！」になる",
   jatext.format_text("すごいびっくり", o_custom), "すごい！")
eq("改行を有効にすると「\\n」になる",
   jatext.format_text("明日の予定改行", o_custom), "明日の予定\n")
eq("自分で追加した言葉（ほし→★）も効く",
   jatext.format_text("大好きほし", o_custom), "大好き★")

# 初期値（びっくりは無効）では置換されない
o_default = jatext.Options(symbol_commands=jatext.DEFAULT_SYMBOL_COMMANDS)
eq("初期値ではびっくりは無効なので置換されない",
   jatext.format_text("すごいびっくり", o_default), "すごいびっくり")

print(f"\n==== 成功 {ok} / 失敗 {len(ng)} ====")
if ng:
    for name in ng:
        print("  -", name)
raise SystemExit(1 if ng else 0)
