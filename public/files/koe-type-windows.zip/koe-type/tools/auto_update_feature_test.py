"""自動アップデート・動的モデルカタログ機能の単体テスト。

から打ちモードで安全に検証する。
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

# プロジェクトルートを検索パスに追加
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# テスト用の安全な環境設定
os.environ["KOE_TYPE_DRY_RUN"] = "1"
tmp_dir = tempfile.TemporaryDirectory()
os.environ["KOE_TYPE_HOME"] = tmp_dir.name

from app import autoupdate, catalog, configstore, schema, updates  # noqa: E402


def test_schema_items() -> None:
    """自動更新とモデルカタログ設定がスキーマに正しく存在すること。"""
    mode_item = schema.find("auto_update_mode")
    assert mode_item is not None, "auto_update_mode が見つかりません"
    assert mode_item.default == "notify"

    cat_item = schema.find("auto_update_catalog")
    assert cat_item is not None, "auto_update_catalog が見つかりません"
    assert cat_item.default is True
    print("OK: スキーマ項目の確認")


def test_scan_local_models() -> None:
    """models/ に未知の .gguf が置かれたら自動検出されてカタログに載ること。"""
    # 一時フォルダにダミーの gguf を作成
    dummy_gguf = catalog.MODEL_DIR / "test-future-model.gguf"
    dummy_gguf.parent.mkdir(parents=True, exist_ok=True)
    dummy_gguf.write_bytes(b"GGUF_TEST_HEADER")

    try:
        added = catalog.scan_local_models()
        assert added >= 1
        key = "local-test-future-model"
        assert key in catalog.MODELS
        spec = catalog.MODELS[key]
        assert "カスタム" in spec.name or "ローカル" in spec.name
        assert spec.runtime == "tcpp"
        print("OK: ローカルモデルの自動検出とカタログ登録")
    finally:
        dummy_gguf.unlink(missing_ok=True)


def test_load_catalog_json() -> None:
    """JSON 形式の外部モデルカタログを動的にマージできること。"""
    dummy_data = {
        "models": [
            {
                "key": "test-remote-model-v2",
                "name": "Test Remote Model v2",
                "ja": "最新のリモートモデル",
                "runtime": "tcpp",
                "assets": [
                    {
                        "name": "remote-v2.gguf",
                        "url": "https://example.com/v2.gguf",
                        "size": 500000,
                    }
                ],
                "accuracy": 5,
                "speed": 5,
                "cer": 1.5,
                "extra": {"resident": True, "file": "remote-v2.gguf"},
            }
        ]
    }
    added = catalog.load_catalog_json(dummy_data)
    assert added == 1
    assert "test-remote-model-v2" in catalog.MODELS
    spec = catalog.MODELS["test-remote-model-v2"]
    assert spec.name == "Test Remote Model v2"
    assert spec.cer == 1.5
    print("OK: リモートモデルカタログの動的マージ")


def test_newer_version_detection() -> None:
    """バージョン比較が正しく動くこと。"""
    assert updates.newer("1.5.0", "1.4.0") is True
    assert updates.newer("1.4.0", "1.4.0") is False
    assert updates.newer("1.3.9", "1.4.0") is False
    assert updates.newer("2.0.0", "1.9.9") is True
    print("OK: バージョン比較判定")


if __name__ == "__main__":
    test_schema_items()
    test_scan_local_models()
    test_load_catalog_json()
    test_newer_version_detection()
    print("==== すべての自動更新・モデル対応テストに合格 ====")
