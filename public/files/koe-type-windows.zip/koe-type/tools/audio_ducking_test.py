"""録音中のPC音声ダッキング機能（ROADMAP 4.7）の検証テスト。

ルール遵守:
  - スピーカーから音を流さない。
  - システム音量を変更しない（KOE_TYPE_DRY_RUN=1 で実音量変更を安全にモック/ガード）。
"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ["KOE_TYPE_DRY_RUN"] = "1"

from app import schema, sysaudio
from app.configstore import Config


class AudioDuckingTest(unittest.TestCase):

    def test_schema_items(self) -> None:
        """schema に audio_ducking と duck_ratio_pct が正しく定義されていること。"""
        duck_item = schema.find("audio_ducking")
        self.assertIsNotNone(duck_item)
        self.assertEqual(duck_item.default, "off")
        vals = [opt.value for opt in duck_item.options]
        self.assertIn("off", vals)
        self.assertIn("duck", vals)
        self.assertIn("mute", vals)

        ratio_item = schema.find("duck_ratio_pct")
        self.assertIsNotNone(ratio_item)
        self.assertEqual(ratio_item.default, 25)
        self.assertEqual(ratio_item.minimum, 5)
        self.assertEqual(ratio_item.maximum, 50)

    def test_volume_duck_and_unduck(self) -> None:
        """_Volume の duck と unduck が状態を正しく制御すること。"""
        vol = sysaudio._Volume()
        self.assertFalse(vol._ducked_by_us)

        # テストモードでは実際の音量変更なしにフラグが更新される
        vol.duck(0.25)
        self.assertTrue(vol._ducked_by_us)
        self.assertIsNotNone(vol._prev_volume)

        # 二重 duck の防止
        vol.duck(0.50)
        self.assertTrue(vol._ducked_by_us)

        vol.unduck()
        self.assertFalse(vol._ducked_by_us)
        self.assertIsNone(vol._prev_volume)

    def test_volume_restore_clears_both(self) -> None:
        """restore() が mute と duck の両方を安全に解除すること。"""
        vol = sysaudio._Volume()
        vol.mute()
        self.assertTrue(vol._muted_by_us)
        vol.restore()
        self.assertFalse(vol._muted_by_us)

        vol.duck(0.2)
        self.assertTrue(vol._ducked_by_us)
        vol.restore()
        self.assertFalse(vol._ducked_by_us)

    def test_main_ducking_logic(self) -> None:
        """main.Controller の _apply_audio_ducking と _restore_audio の挙動。"""
        from app.main import Controller

        ctrl_mock = MagicMock(spec=Controller)
        ctrl_mock.cfg = Config()

        # 1. off (既定)
        ctrl_mock.cfg.set("audio_ducking", "off")
        ctrl_mock.cfg.set("mute_while_recording", False)
        with patch.object(sysaudio.speaker, "mute") as mock_m, \
             patch.object(sysaudio.speaker, "duck") as mock_d:
            Controller._apply_audio_ducking(ctrl_mock)
            mock_m.assert_not_called()
            mock_d.assert_not_called()

        # 2. mute
        ctrl_mock.cfg.set("audio_ducking", "mute")
        with patch.object(sysaudio.speaker, "mute") as mock_m, \
             patch.object(sysaudio.speaker, "duck") as mock_d:
            Controller._apply_audio_ducking(ctrl_mock)
            mock_m.assert_called_once()
            mock_d.assert_not_called()

        # 3. duck
        ctrl_mock.cfg.set("audio_ducking", "duck")
        ctrl_mock.cfg.set("duck_ratio_pct", 30)
        with patch.object(sysaudio.speaker, "mute") as mock_m, \
             patch.object(sysaudio.speaker, "duck") as mock_d:
            Controller._apply_audio_ducking(ctrl_mock)
            mock_m.assert_not_called()
            mock_d.assert_called_once_with(0.30)

        # 4. 安全設計：audio_ducking="off" のときは mute_while_recording が True でもミュートしない（音楽停止事故の防止）
        ctrl_mock.cfg.set("audio_ducking", "off")
        ctrl_mock.cfg.set("mute_while_recording", True)
        with patch.object(sysaudio.speaker, "mute") as mock_m, \
             patch.object(sysaudio.speaker, "duck") as mock_d:
            Controller._apply_audio_ducking(ctrl_mock)
            mock_m.assert_not_called()
            mock_d.assert_not_called()

        # 5. restore
        with patch.object(sysaudio.speaker, "restore") as mock_r:
            Controller._restore_audio(ctrl_mock)
            mock_r.assert_called_once()


if __name__ == "__main__":
    unittest.main()
