"""動作チェック。使える状態かを一覧で出し、だめな所の直し方を見せる。

調べるだけ。設定も Windows も書き換えない。キーも送らない。音も鳴らさない。

    python tools/doctor.py
    python tools/doctor.py --quick     # 時間のかかる項目を飛ばす
    python tools/doctor.py --json      # 機械に読ませる形で出す
    python tools/doctor.py --en        # 英語で出す
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import selfcheck  # noqa: E402
from app.configstore import Config  # noqa: E402

MARK = {selfcheck.OK: "OK  ", selfcheck.WARN: "注意",
        selfcheck.BAD: "エラー", selfcheck.INFO: "参考"}
MARK_EN = {selfcheck.OK: "OK  ", selfcheck.WARN: "warn", selfcheck.BAD: "FAIL",
           selfcheck.INFO: "info"}


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(errors="replace")
        except Exception:
            pass
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--en", action="store_true")
    args = ap.parse_args()

    cfg = Config()
    results = selfcheck.run_all(model_key=cfg.str_("model"),
                                hotkey=cfg.str_("hotkey", "ctrl+space"),
                                excluded=tuple(cfg.list_("excluded_apps")),
                                quick=args.quick)
    info = selfcheck.summary(results)

    if args.json:
        print(json.dumps({"summary": info,
                          "results": [r.as_dict() for r in results]},
                         ensure_ascii=False, indent=1))
        return 0 if info["overall"] != selfcheck.BAD else 1

    ja = not args.en
    marks = MARK if ja else MARK_EN
    print("=" * 74)
    print(" koe-type 動作チェック" if ja else " koe-type self-check")
    print("=" * 74)
    for r in results:
        title = r.title_ja if ja else r.title_en
        detail = r.detail_ja if ja else r.detail_en
        print(f" {marks[r.status]}  {title:22s} {detail}")
        fix = r.fix_ja if ja else r.fix_en
        if fix and r.status in (selfcheck.WARN, selfcheck.BAD):
            for line in _wrap(fix, 64):
                print(f"            → {line}")
    counts = info["counts"]
    print("=" * 74)
    if ja:
        print(f" 問題なし {counts['ok']} / 注意 {counts['warn']} / "
              f"エラー {counts['bad']} / 参考 {counts['info']}")
        print(" 全体: " + {"ok": "使える状態です",
                           "warn": "使えますが、気になる点があります",
                           "bad": "このままでは使えません"}[info["overall"]])
    else:
        print(f" ok {counts['ok']} / warn {counts['warn']} / "
              f"fail {counts['bad']} / info {counts['info']}")
    print("=" * 74)
    return 0 if info["overall"] != selfcheck.BAD else 1


def _wrap(text: str, width: int) -> list[str]:
    """日本語を含む文を、だいたいの幅で折り返す。"""
    out, line = [], ""
    for ch in text:
        line += ch
        wide = sum(2 if ord(c) > 0x2000 else 1 for c in line)
        if wide >= width and ch in "。、 ）」":
            out.append(line)
            line = ""
    if line:
        out.append(line)
    return out


if __name__ == "__main__":
    raise SystemExit(main())
