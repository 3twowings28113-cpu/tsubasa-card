"""アルファベット読み自動変換のテスト。

「エフディーイー」->「FDE」
「エーピーアイ」->「API」
「ユーアールエル」->「URL」
「エムワン」->「M1」
などの変換が正しく機能し、誤爆（エスカレーター、ビール等）がないことを確認する。
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.spelling import (convert_spelled_alphabet, correct_homophones,
                          repair_mixed_loanwords)


def test_basic_acronyms() -> None:
    cases = [
        ("エフディーイー", "FDE"),
        ("エフ・ディー・イー", "FDE"),
        ("えふでぃーいー", "FDE"),
        ("エーピーアイ", "API"),
        ("ユーアールエル", "URL"),
        ("エスディーケー", "SDK"),
        ("シーピーユー", "CPU"),
        ("ジーピーユー", "GPU"),
        ("ディービー", "DB"),
        ("アイディー", "ID"),
        ("オーエス", "OS"),
        ("ピーシー", "PC"),
        ("エーアイ", "AI"),
        ("ユーアイ", "UI"),
        ("ユーエックス", "UX"),
        ("エスエヌエス", "SNS"),
        ("ディーエヌエス", "DNS"),
        ("エスエスエル", "SSL"),
        ("エイチティーティーピー", "HTTP"),
        ("ブイアール", "VR"),
        ("エルイーディー", "LED"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: basic acronyms")


def test_in_sentence() -> None:
    cases = [
        ("エフディーイーの機能を確認します", "FDEの機能を確認します"),
        ("このエーピーアイの仕様書を見てください", "このAPIの仕様書を見てください"),
        ("ユーアールエルはこちらです", "URLはこちらです"),
        ("新しいシーピーユーとジーピーユーを搭載しています",
         "新しいCPUとGPUを搭載しています"),
        ("ディービーの接続設定を変更した", "DBの接続設定を変更した"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: in sentence")


def test_with_numbers() -> None:
    cases = [
        ("エムワン", "M1"),
        ("エスディーケーツー", "SDK2"),
        ("フォーケー", "4K"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: with numbers")


def test_arbitrary_letter_chains() -> None:
    # 辞書に明示登録していない任意の2文字以上の組み合わせ
    cases = [
        ("エフエム", "FM"),
        ("エービーシー", "ABC"),
        ("エックスワイゼット", "XYZ"),
        ("ジェーケー", "JK"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: arbitrary letter chains")


def test_no_false_positives() -> None:
    # 一般単語を誤変換しないこと
    cases = [
        ("エスカレーターに乗る", "エスカレーターに乗る"),
        ("冷たいビールを飲む", "冷たいビールを飲む"),
        ("美味しいチーズを食べる", "美味しいチーズを食べる"),
        ("喫茶店でコーヒーを頼む", "喫茶店でコーヒーを頼む"),
        ("えー、本日の天気は晴れです", "えー、本日の天気は晴れです"),
        ("あいまいな表現を避ける", "あいまいな表現を避ける"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: no false positives")


def test_ide_and_antigravity() -> None:
    cases = [
        # 単体での IDE 変換
        ("アイディーイー", "IDE"),
        ("あいでぃーいー", "IDE"),
        ("アイ・ディー・イー", "IDE"),
        ("アイディーいー", "IDE"),
        # アンチグラビティ文脈での FDE / USJ / アイディーいー の救済
        ("アンチグラビティFDE", "アンチグラビティ IDE"),
        ("アンチグラビティーFDE", "アンチグラビティー IDE"),
        ("アンチグラビティUSJ", "アンチグラビティ IDE"),
        ("アンチグラビティーUSJ", "アンチグラビティー IDE"),
        ("アンチグラビティアイディーいー", "アンチグラビティ IDE"),
        ("アンチグラビティーあいでぃーいー", "アンチグラビティー IDE"),
        ("Antigravity FDE", "Antigravity IDE"),
        ("Antigravity USJ", "Antigravity IDE"),
        ("Antigravityアイディーイー", "Antigravity IDE"),
        # 開発環境・エディタ文脈
        ("開発環境FDE", "開発環境 IDE"),
        ("次世代エディタUSJ", "次世代エディタ IDE"),
        # 文章中での変換
        ("アンチグラビティーFDEでコードを書く",
         "アンチグラビティー IDEでコードを書く"),
        ("アンチグラビティUSJのプラグイン",
         "アンチグラビティ IDEのプラグイン"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: ide and antigravity context correction")


def test_expanded_acronyms_and_hybrids() -> None:
    cases = [
        # ユーザー指定の代表例
        ("ユーエスジェイに行きたい", "USJに行きたい"),
        ("ゆーえすじぇー", "USJ"),
        ("ユー・エス・ジェイ", "USJ"),
        ("エイチディーエムアイケーブルを挿す", "HDMIケーブルを挿す"),
        ("エイチ・ディー・エム・アイ", "HDMI"),
        ("えいちでぃーえむあい", "HDMI"),
        ("ピーシーを買い替えた", "PCを買い替えた"),
        ("エフディーイーを使う", "FDEを使う"),
        # 英字＋カタカナ読み混在パターン
        ("Hディーエムアイ出力", "HDMI出力"),
        ("H・ディー・エム・アイ端子", "HDMI端子"),
        ("Hディーエムアイケーブルに接続", "HDMIケーブルに接続"),
        ("UエスJのアトラクション", "USJのアトラクション"),
        ("Pシーで起動する", "PCで起動する"),
        ("FディーEの設定", "FDEの設定"),
        ("IディーEのプラグイン", "IDEのプラグイン"),
        ("SエヌSでシェア", "SNSでシェア"),
        ("CピーUの使用率", "CPUの使用率"),
        ("GピーUの温度", "GPUの温度"),
        # 一般的な頭字語・略語
        ("ワイファイに繋ぐ", "Wi-Fiに繋ぐ"),
        ("サースを導入する", "SaaSを導入する"),
        ("ビートゥービーの取引", "BtoBの取引"),
        ("キューアンドエーを見る", "Q&Aを見る"),
        ("エフエーキューを確認する", "FAQを確認する"),
        ("エーティーエムでお金を下ろす", "ATMでお金を下ろす"),
        ("イーティーシーレーンを通る", "ETCレーンを通る"),
        ("ジーピーエスで位置を確認", "GPSで位置を確認"),
        ("キューアールコードを読み取る", "QRコードを読み取る"),
        ("ジェイアールに乗る", "JRに乗る"),
        ("エヌエイチケーを見る", "NHKを見る"),
        ("シーエスブイファイルを出力", "CSVファイルを出力"),
        ("エックスエムエル形式", "XML形式"),
        ("オーケーです", "OKです"),
        ("エヌジーです", "NGです"),
        ("ディーエムを送る", "DMを送る"),
        ("シーエムが流れる", "CMが流れる"),
        ("ブイアイピー待遇", "VIP待遇"),
        ("エスオーエスを出す", "SOSを出す"),
        ("ディーエヌエー鑑定", "DNA鑑定"),
        ("ジーディーピーが成長", "GDPが成長"),
    ]
    for src, expected in cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: expanded acronyms and hybrids")




def test_abbrev_singles_chains_and_guards() -> None:
    # 2026-10-25 追加: 単独1文字（Tier W/B/S）・長音重なり・
    # チェーン先行による部分一致事故の修正・追加した頭字語。
    # 設計は abbrev/DESIGN.md、変換表は abbrev/mapping_draft.md。
    convert_cases = [
        # 単独 Tier W（区間全体）
        ("エム", "M"),
        ("エックス", "X"),
        # 単独 Tier B（助詞境界）
        ("サイズはエムです", "サイズはMです"),
        ("ビーとシーの間", "BとCの間"),
        ("エムって何", "Mって何"),
        ("エムでお願いします", "Mでお願いします"),
        # 単独 Tier S（サフィックス直前）
        ("エムサイズ", "Mサイズ"),
        ("エルサイズ", "Lサイズ"),
        ("エムサイズの服", "Mサイズの服"),
        ("ビー型", "B型"),
        ("エー判", "A判"),
        ("ビー級", "B級"),
        ("ティー型", "T型"),
        ("ユー型", "U型"),
        ("オー型", "O型"),
        # 長音の重なり
        ("ピーーシー", "PC"),
        ("エスーエヌエス", "SNS"),
        # 部分一致で壊れていた長いチェーン
        ("エーアイピーシー", "AIPC"),
        ("ユーエスビーシー", "USB-C"),
        ("アイピーエス", "IPS"),
        ("エスディージーズ", "SDGs"),
        # 追加した頭字語
        ("ノーエスキューエル", "NoSQL"),
        ("エムアンドエー", "M&A"),
        ("シーアイシーディー", "CI/CD"),
        ("イートゥーイー", "E2E"),
        ("グラフキューエル", "GraphQL"),
        ("アープ", "ARPU"),
        ("ロアス", "ROAS"),
        ("トーイック", "TOEIC"),
        ("シム", "SIM"),
    ]
    for src, expected in convert_cases:
        out = convert_spelled_alphabet(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    # 変換してはいけないケース（誤爆防止の回帰固定）
    keep_cases = [
        "エー", "オー", "ワイ", "アイ", "ティー", "ユー",
        "ティーを飲まずに作業する", "ティーシャツを買う",
        "ユーターン禁止", "エステに行く", "エムダッシュを使う",
        "あいまいな表現を避ける", "エスカレーターに乗る",
        "冷たいビールを飲む", "ジーっと見る", "ジーと見る",
        "ビー玉を買う", "ケータイを買う", "ハープを弾く", "マキシム",
    ]
    for src in keep_cases:
        out = convert_spelled_alphabet(src)
        assert out == src, f"Must not convert {src}, got {out}"
    print("OK: abbrev singles / chains / guards")


def test_mixed_loanword_repairs() -> None:
    # 2026-10-25 追加: 外来語の混在崩れ（「アニnotion」型）。
    # 融合形（カタカナ＋英単語、空白なし）だけを元に戻し、
    # 単独の英単語や空白で並んだ形には触らない。
    convert_cases = [
        ("アニnotion", "アニメーション"),  # 利用者の実例
        ("アニNotion", "アニメーション"),  # 大小文字は区別しない
        ("アニnotionが好き", "アニメーションが好き"),
        ("プロmotion", "プロモーション"),
        ("エmotion", "エモーション"),
        ("テレvision", "テレビジョン"),
        ("バーversion", "バージョン"),
        ("ネットwork", "ネットワーク"),
        ("ホームwork", "ホームワーク"),
        ("フレームwork", "フレームワーク"),
    ]
    for src, expected in convert_cases:
        out = repair_mixed_loanwords(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    keep_cases = [
        "Notion", "Notionでタスクを管理する", "animation",
        "I have a notion that this works",
        "アニメーション", "アニ notion", "ネット work",
        "https://www.notion.so/abc123", "animation_duration = 3",
        "バーversion2", "バーversion-control", "スーパーversion",
    ]
    for src in keep_cases:
        out = repair_mixed_loanwords(src)
        assert out == src, f"Must not convert {src}, got {out}"
    print("OK: mixed loanword repairs")


def test_correct_homophones() -> None:
    cases = [
        # きかい: 機械 / 機会
        ("機械があれば伺います", "機会があれば伺います"),
        ("機会を操作する", "機械を操作する"),
        ("機械学習のモデル", "機械学習のモデル"),
        ("またの機械にお願いします", "またの機会にお願いします"),
        # あつい: 暑い / 熱い / 厚い
        ("熱いお茶を飲む", "熱いお茶を飲む"),
        ("暑いお茶を飲む", "熱いお茶を飲む"),
        ("熱い夏が来る", "暑い夏が来る"),
        ("気温が熱いですね", "気温が暑いですね"),
        ("本が熱い", "本が厚い"),
        # おさめる: 収める / 納める / 治める / 修める
        ("税金を収める", "税金を納める"),
        ("写真に納める", "写真に収める"),
        ("国を収める", "国を治める"),
        ("学問を収める", "学問を修める"),
        ("納めるべき成果", "収めるべき成果"),
        # つく: 着く / 就く / 付く
        ("駅に付く", "駅に着く"),
        ("職に着く", "職に就く"),
        ("気が着く", "気が付く"),
        # とめる: 止める / 泊める / 留める
        ("ホテルに止める", "ホテルに泊める"),
        ("車を泊める", "車を止める"),
        ("心に止める", "心に留める"),
        # はかる: 測る / 量る / 計る / 図る / 謀る
        ("時間を測る", "時間を計る"),
        ("体重を計る", "体重を量る"),
        ("長さを計る", "長さを測る"),
        ("便宜を量る", "便宜を図る"),
        # うつす: 写す / 映す / 移す
        ("写真を映す", "写真を写す"),
        ("映画を写す", "映画を映す"),
        ("住所を写す", "住所を移す"),
        # こえる: 越える / 超える
        ("山を越える", "山を越える"),
        ("基準を越える", "基準を超える"),
        ("締め切りを越える", "締め切りを過ぎる" if False else "締め切りを越える"),
        ("定員を越える", "定員を超える"),
        # その他同音異義語
        ("アンケートに解答する", "アンケートに回答する"),
        ("質問に解答する", "質問に回答する"),
        ("テストの回答", "テストの解答"),
        ("実験の対照実験", "実験の対照実験"),
        ("左右対象", "左右対称"),
        ("意外と簡単だった", "意外と簡単だった"),
        ("部署の移動が決まった", "部署の異動が決まった"),
        ("意志を疎通する", "意思を疎通する"),
    ]
    for src, expected in cases:
        out = correct_homophones(src)
        assert out == expected, f"Expected {expected}, got {out} (from {src})"
    print("OK: correct homophones")


def main() -> None:
    test_basic_acronyms()
    test_in_sentence()
    test_with_numbers()
    test_arbitrary_letter_chains()
    test_no_false_positives()
    test_ide_and_antigravity()
    test_expanded_acronyms_and_hybrids()
    test_abbrev_singles_chains_and_guards()
    test_mixed_loanword_repairs()
    test_correct_homophones()
    print("\nALL SPELLING TESTS PASSED!")


if __name__ == "__main__":
    main()

