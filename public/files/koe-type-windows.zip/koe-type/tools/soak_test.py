"""何千回もランダムにくり返して、壊れないことを数字で確かめる。

**本物のキーもクリックも 1 回も送らない。** 台本（`app/testdrive.py`）で
内側から操作する。**スピーカーも使わない**（WAV を直接読み込ませる）。

## 何を見るか

| 見るもの | 合格の線 |
|---|---|
| 落ちる・固まる | 0 回 |
| 帯が残る（画面の繰り返しが止まる） | 0 回。1 秒あたり 5 回以上回っていること |
| Ctrl+Space が効かなくなる | 0 回 |
| 「止める途中」で居残る | 0 回 |
| メモリが増え続ける | 1 時間あたり 20MB 未満 |
| ほかのアプリの入力が遅くなる | 中央値が何もしていない時の 5 倍未満 |

## 使い方

    python tools/soak_test.py                  # 1 時間
    python tools/soak_test.py --hours 3        # 3 時間
    python tools/soak_test.py --minutes 10     # 短く試す
    python tools/soak_test.py --seed 7         # 同じ並びをもう一度

1 回のアプリ起動につき 20 分ぶんの台本を流し、終わったら次の起動へ。
起動と終了もくり返すので、「起動したら壊れていた」も見つけられる。
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import random
import shutil
import statistics
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tools.mock_e2e import AUDIO, make_home  # noqa: E402
from tools.stress_test import probe_input_latency  # noqa: E402

PYTHON = sys.executable
TMP = ROOT / "bench" / "eval" / "_soak"

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)

PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ = 0x0010


class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                ("PeakWorkingSetSize", ctypes.c_size_t),
                ("WorkingSetSize", ctypes.c_size_t),
                ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPagedPoolUsage", ctypes.c_size_t),
                ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                ("PagefileUsage", ctypes.c_size_t),
                ("PeakPagefileUsage", ctypes.c_size_t)]


kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL,
                                 wintypes.DWORD]
kernel32.OpenProcess.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
psapi.GetProcessMemoryInfo.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(PROCESS_MEMORY_COUNTERS), wintypes.DWORD]
psapi.GetProcessMemoryInfo.restype = wintypes.BOOL


def _quarter(settled, head: bool) -> float:  # noqa: ANN001
    """最初（または最後）の 1/4 の中央値。上下のゆれをならす。"""
    if not settled:
        return 0.0
    n = max(1, len(settled) // 4)
    part = settled[:n] if head else settled[-n:]
    return round(statistics.median(v for _, v in part), 1)


def memory_mb(pid: int) -> float:
    """そのプロセスがいま使っているメモリ（MB）。取れなければ 0。"""
    handle = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ,
                                  False, pid)
    if not handle:
        return 0.0
    try:
        counters = PROCESS_MEMORY_COUNTERS()
        counters.cb = ctypes.sizeof(counters)
        if psapi.GetProcessMemoryInfo(handle, ctypes.byref(counters),
                                      counters.cb):
            return counters.WorkingSetSize / (1024 * 1024)
        return 0.0
    finally:
        kernel32.CloseHandle(handle)


# ---------------------------------------------------------------- 台本


# どの操作を、どれくらいの割合で混ぜるか。
# 実際の使い方に近づけつつ、めったに通らない道も必ず通す。
ENDINGS = (
    ("stop", 34),             # Ctrl+Space で止める
    ("send", 16),             # Enter で送信して止める
    ("silence", 14),          # 静かになって自動で止まる
    ("focus_changed", 14),    # 別のウィンドウへ移って止まる
    ("click_stop", 12),       # クリックして止まる
    ("cancel", 10),           # Esc で中止
)
# ときどき混ぜる「意地悪」
MISCHIEF = (
    ("double_start", 6),      # 録音中にもう一度 Ctrl+Space
    ("idle_cancel", 5),       # 待機中に Esc
    ("instant_stop", 5),      # 始めた直後に止める
    ("stop_then_start", 5),   # 止めた直後に始める
    ("idle_send", 3),         # 待機中に Enter
)


def pick(table) -> str:  # noqa: ANN001
    total = sum(w for _, w in table)
    roll = random.random() * total
    for name, weight in table:
        roll -= weight
        if roll <= 0:
            return name
    return table[-1][0]


def build_script(minutes: float) -> tuple[list[dict], dict]:
    """でたらめな並びの台本を作る。戻り値は (台本, 数えたもの)。"""
    rows: list[dict] = []
    counts = {"start": 0}
    at = 2.0
    end = minutes * 60
    while at < end:
        kind = pick(MISCHIEF) if random.random() < 0.22 else ""
        if kind == "idle_cancel":
            rows.append({"at": round(at, 2), "event": "cancel"})
            counts["idle_cancel"] = counts.get("idle_cancel", 0) + 1
            at += random.uniform(0.3, 1.2)
            continue
        if kind == "idle_send":
            rows.append({"at": round(at, 2), "event": "send"})
            counts["idle_send"] = counts.get("idle_send", 0) + 1
            at += random.uniform(0.3, 1.2)
            continue

        # ここから 1 回の録音
        rows.append({"at": round(at, 2), "event": "hotkey_down"})
        counts["start"] += 1
        talk = random.uniform(0.6, 6.0)

        if kind == "double_start":
            # 録音中にもう一度押す（＝止まる）。そのあと続けて始める
            rows.append({"at": round(at + talk, 2), "event": "hotkey_down"})
            counts["double_start"] = counts.get("double_start", 0) + 1
            at += talk + random.uniform(0.2, 1.5)
            continue
        if kind == "instant_stop":
            rows.append({"at": round(at + 0.12, 2), "event": "stop"})
            counts["instant_stop"] = counts.get("instant_stop", 0) + 1
            at += random.uniform(0.6, 2.0)
            continue
        if kind == "stop_then_start":
            rows.append({"at": round(at + talk, 2), "event": "stop"})
            rows.append({"at": round(at + talk + 0.08, 2),
                         "event": "hotkey_down"})
            rows.append({"at": round(at + talk * 2 + 0.08, 2),
                         "event": "stop"})
            counts["stop_then_start"] = counts.get("stop_then_start", 0) + 1
            counts["start"] += 1
            at += talk * 2 + random.uniform(0.5, 2.5)
            continue

        ending = pick(ENDINGS)
        row: dict = {"at": round(at + talk, 2), "event": ending}
        if ending == "focus_changed":
            row["hwnd"] = random.randint(100000, 999999)
        rows.append(row)
        counts[ending] = counts.get(ending, 0) + 1
        at += talk + random.uniform(0.4, 3.0)

    rows.append({"at": round(at + 4.0, 2), "event": "quit"})
    return rows, counts


# ---------------------------------------------------------------- 1 回ぶん


def run_round(index: int, minutes: float, wav: Path) -> dict:
    """アプリを 1 回起動し、台本を流し、様子を測って返す。"""
    # 前の回のログが混ざらないよう、毎回まっさらにする
    shutil.rmtree(TMP / f"r{index}", ignore_errors=True)
    home = make_home(TMP / f"r{index}", {
        "input_mode": random.choice(["stream", "preview", "phrase"]),
        "guardian": False,              # 見張り役は別に確かめる
        "overlay": True,                # ★帯も本物で動かす（残らないか）
        "overlay_design": random.choice(["card", "wave", "pill"]),
        "overlay_position": "bottom-right",
        "tray_icon": False,
        "stop_on_silence_ms": 10000,
        "stop_on_window_change": "stop",
        "stop_on_click": "any",
        "shutdown_wait_ms": 4000,
        "log_level": "INFO",            # DEBUG だとログが巨大になる
    })
    script, counts = build_script(minutes)
    (home / "script.json").write_text(json.dumps(script, ensure_ascii=False),
                                      "utf-8")

    env = dict(os.environ)
    env.update({
        "PYTHONUTF8": "1",
        "KOE_TYPE_HOME": str(home),
        "KOE_TYPE_DRY_RUN": "1",
        "KOE_TYPE_DRY_RUN_LOG": str(home / "logs" / "dryrun.jsonl"),
        "KOE_TYPE_TEST_SCRIPT": str(home / "script.json"),
        "KOE_TYPE_FAKE_MIC": str(wav),
        "KOE_TYPE_NO_AUTOSTART": "1",
    })

    began = time.perf_counter()
    proc = subprocess.Popen(  # noqa: S603
        [PYTHON, "-m", "app.main"], cwd=str(ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    mem: list[float] = []
    lat: list[float] = []
    limit = minutes * 60 + 180
    next_mem = 0.0
    while proc.poll() is None:
        now = time.perf_counter() - began
        if now > limit:
            proc.kill()
            break
        if now >= next_mem:
            next_mem = now + 5.0
            value = memory_mb(proc.pid)
            if value:
                # 起動直後はモデルを読む途中なので、増え方の計算からは外す
                mem.append((now, value))
            lat.extend(probe_input_latency(12))
        else:
            time.sleep(0.4)
    took = time.perf_counter() - began
    try:
        out, err = proc.communicate(timeout=20)
    except subprocess.TimeoutExpired:
        proc.kill()
        out, err = b"", b""

    text = ""
    for path in sorted((home / "logs").glob("koe-type.log*")):
        text += path.read_text("utf-8", "replace")

    import re
    ticks = [int(m) for m in re.findall(r"画面の繰り返し (\d+) 回", text)]
    # モデルの読み込みが終わってからの分だけで、増え方を見る
    WARMUP = 90.0
    settled = [(at, v) for at, v in mem if at >= WARMUP]
    result = {
        "round": index, "took": took, "rc": proc.returncode,
        "planned": counts,
        "starts": text.count("録音開始"),
        "stops": text.count("録音停止"),
        "cancels": text.count("中止 session="),
        "crashes": text.count("未捕捉の例外") + text.count("Traceback"),
        "keys_lost": text.count("ショートカットの登録が外れました"),
        "forced": text.count("待機の状態へ戻します"),
        "stuck": len(re.findall(r"停止が [0-9.]+ 秒終わらない", text)),
        "draw_errors": text.count("帯の描画で例外"),
        "ticks": ticks[0] if ticks else 0,
        # 増え方は「最初の 1/4 の中央値」と「最後の 1/4 の中央値」で見る。
        # 1 点ずつで比べると、たまたま高いところを拾って
        # 増えたように見える（実際そうなり、増えていないのに
        # 不合格と出た）。
        "mem_first": _quarter(settled, True),
        "mem_last": _quarter(settled, False),
        "mem_min": min((v for _, v in settled), default=0.0),
        "mem_max": max((v for _, v in mem), default=0.0),
        "mem_span": (settled[-1][0] - settled[0][0]) if settled else 0.0,
        "mem_samples": [round(v, 1) for _, v in settled],
        "lat_median": statistics.median(lat) if lat else 0.0,
        "lat_max": max(lat) if lat else 0.0,
        "stderr_tail": (err.decode("utf-8", "replace")[-300:]
                        if err else ""),
        "home": str(home),
    }
    result["tick_rate"] = (result["ticks"] / took) if took else 0.0
    return result


# ---------------------------------------------------------------- 本体


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--hours", type=float, default=0.0)
    ap.add_argument("--minutes", type=float, default=60.0)
    ap.add_argument("--round-minutes", type=float, default=20.0,
                    help="1 回の起動で流す長さ")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--json", default="")
    args = ap.parse_args()

    total_minutes = args.hours * 60 if args.hours else args.minutes
    seed = args.seed or int(time.time()) % 100000
    random.seed(seed)

    wav = AUDIO / "j05.wav"
    if not wav.is_file():
        print(f"音声が見つかりません: {wav}")
        return 1

    print("=" * 74)
    print(f" 長時間テスト（{total_minutes:.0f} 分 / たね {seed}）")
    print(" 本物のキーもクリックも送りません／スピーカーも使いません")
    print("=" * 74)

    print("\n[0] 何もしていないときの入力の遅れを測る")
    base = probe_input_latency(90)
    base_med = statistics.median(base)
    print(f"    中央値 {base_med:.4f} ms / 最大 {max(base):.4f} ms")

    rounds: list[dict] = []
    began = time.perf_counter()
    index = 0
    while (time.perf_counter() - began) / 60.0 < total_minutes:
        index += 1
        left = total_minutes - (time.perf_counter() - began) / 60.0
        minutes = max(2.0, min(args.round_minutes, left))
        print(f"\n■ {index} 回目（{minutes:.0f} 分ぶん）")
        try:
            row = run_round(index, minutes, wav)
        except Exception as exc:  # noqa: BLE001
            print(f"    この回で例外: {exc}")
            rounds.append({"round": index, "crashes": 1, "rc": -99,
                           "took": 0.0, "error": str(exc)})
            continue
        rounds.append(row)
        print(f"    録音 {row['starts']} 回 / 停止 {row['stops']} 回 / "
              f"中止 {row['cancels']} 回")
        print(f"    画面の繰り返し {row['ticks']} 回"
              f"（1 秒あたり {row['tick_rate']:.1f}）")
        print(f"    メモリ {row['mem_first']:.0f} → {row['mem_last']:.0f} MB"
              f"（{row.get('mem_min', 0):.0f}〜{row['mem_max']:.0f} のあいだで上下）")
        print(f"    入力の遅れ 中央値 {row['lat_median']:.4f} ms / "
              f"最大 {row['lat_max']:.4f} ms")
        bad = []
        if row["rc"] != 0:
            bad.append(f"終了コード {row['rc']}")
        for key, label in (("crashes", "落ちた"), ("keys_lost", "キーが外れた"),
                           ("stuck", "停止が終わらない"),
                           ("draw_errors", "帯の描画で例外")):
            if row.get(key):
                bad.append(f"{label} {row[key]} 回")
        if row["tick_rate"] < 5.0:
            bad.append(f"画面の繰り返しが遅い（{row['tick_rate']:.1f}/秒）")
        if bad:
            print("    NG  " + " / ".join(bad))
            if row.get("stderr_tail"):
                print(f"    （標準エラー）{row['stderr_tail']}")
        else:
            print("    合格")

    # ------------------------------------------------------------ まとめ
    took_h = (time.perf_counter() - began) / 3600.0
    starts = sum(r.get("starts", 0) for r in rounds)
    stops = sum(r.get("stops", 0) for r in rounds)
    cancels = sum(r.get("cancels", 0) for r in rounds)
    crashes = sum(r.get("crashes", 0) for r in rounds)
    keys_lost = sum(r.get("keys_lost", 0) for r in rounds)
    stuck = sum(r.get("stuck", 0) for r in rounds)
    forced = sum(r.get("forced", 0) for r in rounds)
    draw = sum(r.get("draw_errors", 0) for r in rounds)
    bad_rc = sum(1 for r in rounds if r.get("rc", 0) != 0)
    rates = [r["tick_rate"] for r in rounds if r.get("tick_rate")]
    lats = [r["lat_median"] for r in rounds if r.get("lat_median")]
    lat_max = max((r.get("lat_max", 0.0) for r in rounds), default=0.0)

    # メモリの増え方（1 時間あたり）
    growth = []
    for r in rounds:
        # 落ち着いてからの区間が 5 分以上あるときだけ、増え方を見る
        if r.get("mem_first") and r.get("mem_span", 0) >= 300:
            per_hour = ((r["mem_last"] - r["mem_first"])
                        / (r["mem_span"] / 3600.0))
            growth.append(per_hour)

    print("\n" + "=" * 74)
    print(" まとめ")
    print("=" * 74)
    print(f"  動かした時間            {took_h:.2f} 時間（{len(rounds)} 回起動）")
    print(f"  録音の開始／停止／中止   {starts} / {stops} / {cancels} 回")
    print(f"  落ちた・固まった        {crashes} 回")
    print(f"  終了コードが 0 でない    {bad_rc} 回")
    print(f"  ショートカットが外れた   {keys_lost} 回")
    print(f"  停止が終わらなかった     {stuck} 回（強制復帰 {forced} 回）")
    print(f"  帯の描画で例外          {draw} 回")
    if rates:
        print(f"  画面の繰り返し          1 秒あたり "
              f"{statistics.median(rates):.1f} 回（最低 {min(rates):.1f}）")
    if growth:
        print(f"  メモリの増え方          1 時間あたり "
              f"{statistics.median(growth):+.1f} MB"
              f"（最大 {max(growth):+.1f}）")
    if lats:
        print(f"  入力の遅れ（何もしていない時）中央値 {base_med:.4f} ms")
        print(f"  入力の遅れ（動かしている間）  中央値 "
              f"{statistics.median(lats):.4f} ms / 最大 {lat_max:.4f} ms")

    ok = (crashes == 0 and bad_rc == 0 and keys_lost == 0 and stuck == 0
          and draw == 0 and starts > 0
          and (not rates or min(rates) >= 5.0)
          and (not growth or max(growth) < 20.0)
          and (not lats or statistics.median(lats)
               < max(1.0, base_med * 5)))
    print("\n  " + ("合格" if ok else "不合格"))
    print("=" * 74)

    # ★細かい数字はいつも残す。前は --json を付けたときだけで、
    # 不合格になった回の原因（メモリの動き）を追えなかった（2026-10-05）。
    out = (Path(args.json) if args.json
           else ROOT / "logs" / "soak" /
           f"soak-{time.strftime('%Y%m%d-%H%M%S')}.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(
        {"seed": seed, "hours": took_h, "rounds": rounds,
         "base_latency": base_med, "ok": ok},
        ensure_ascii=False, indent=2), "utf-8")
    print(f"  数字を書き出しました: {out}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
