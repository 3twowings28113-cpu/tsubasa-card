"""クリップボード保存設定と直接入力方式の単体テスト。

KOE_TYPE_DRY_RUN=1 で本物のキーは一切送らず、dryrun ログとモックで検証する。
"""

from __future__ import annotations

import os
import tempfile
import sys
from pathlib import Path

# プロジェクトルートを検索パスに追加
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# テスト用の安全な環境設定
os.environ["KOE_TYPE_DRY_RUN"] = "1"
tmp_dir = tempfile.TemporaryDirectory()
os.environ["KOE_TYPE_HOME"] = tmp_dir.name

from app import configstore, dryrun, inject, schema  # noqa: E402


def test_schema_items() -> None:
    """スキーマに設定項目が存在し、既定値が正しいこと。"""
    paste_method_item = schema.find("paste_method")
    assert paste_method_item is not None, "paste_method が見つかりません"
    assert paste_method_item.default == "auto"

    save_cb_item = schema.find("save_to_clipboard")
    assert save_cb_item is not None, "save_to_clipboard が見つかりません"
    assert save_cb_item.default == "fallback"
    print("OK: スキーマ項目の確認")


def test_direct_typing_dryrun() -> None:
    """direct 方式で paste_text を呼んだとき、type が記録されること。"""
    dryrun.reset()
    res = inject.paste_text("こんにちはテスト", method="direct")
    assert res == inject.PASTED
    entries = dryrun.entries()
    type_entries = [e for e in entries if e.get("kind") == "type"]
    assert len(type_entries) == 1
    assert type_entries[0].get("text") == "こんにちはテスト"
    # クリップボード操作が一切記録されていないこと
    clip_entries = [e for e in entries if e.get("kind") == "clipboard"]
    assert len(clip_entries) == 0
    print("OK: 直接入力（direct）でクリップボードを触らない")


def test_save_to_clipboard_fallback_off() -> None:
    """copy_on_fallback=False のとき、窓変更でクリップボードに保存されないこと。"""
    dryrun.reset()
    inject.foreground = lambda: 12345
    # target_hwnd=99999 で前面と異なる窓を指定
    res = inject.paste_text("テスト文字", target_hwnd=99999,
                            copy_on_fallback=False)
    assert res == inject.FAILED
    entries = dryrun.entries()
    clip_entries = [e for e in entries if e.get("kind") == "clipboard"]
    assert len(clip_entries) == 0
    copy_entries = [e for e in entries if e.get("kind") == "copy"]
    assert len(copy_entries) == 1
    assert copy_entries[0].get("skipped") is True
    print("OK: copy_on_fallback=False でクリップボード保存をスキップ")


def test_save_to_clipboard_fallback_on() -> None:
    """copy_on_fallback=True のとき、窓変更でクリップボードに保存されること。"""
    dryrun.reset()
    inject.foreground = lambda: 12345
    res = inject.paste_text("テスト文字", target_hwnd=99999,
                            copy_on_fallback=True)
    assert res == inject.COPIED
    entries = dryrun.entries()
    copy_entries = [e for e in entries if e.get("kind") == "copy"]
    assert len(copy_entries) == 1
    assert copy_entries[0].get("skipped") is not True
    print("OK: copy_on_fallback=True でクリップボードへ退避")


if __name__ == "__main__":
    test_schema_items()
    test_direct_typing_dryrun()
    test_save_to_clipboard_fallback_off()
    test_save_to_clipboard_fallback_on()
    print("==== すべてのクリップボード設定テストに合格 ====")
