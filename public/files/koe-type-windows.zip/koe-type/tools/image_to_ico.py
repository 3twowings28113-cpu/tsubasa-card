"""任意の画像（JPG/PNG）から Windows 用の高品質マルチサイズ .ico を生成するツール。
Smart App Control 適合（Python 標準ライブラリ + OS 標準 gdiplus.dll のみ）。
"""
from __future__ import annotations

import ctypes
from ctypes import Structure, byref, c_int, c_uint, c_void_p, wintypes
from pathlib import Path
import struct
import zlib

gdiplus = ctypes.windll.gdiplus


class GdiplusStartupInput(Structure):
    _fields_ = [
        ("GdiplusVersion", wintypes.UINT),
        ("DebugEventCallback", c_void_p),
        ("SuppressBackgroundThread", wintypes.BOOL),
        ("SuppressExternalCodecs", wintypes.BOOL),
    ]


class BitmapData(Structure):
    _fields_ = [
        ("Width", wintypes.UINT),
        ("Height", wintypes.UINT),
        ("Stride", c_int),
        ("PixelFormat", c_int),
        ("Scan0", c_void_p),
        ("Reserved", c_void_p),
    ]


class Rect(Structure):
    _fields_ = [
        ("X", c_int),
        ("Y", c_int),
        ("Width", c_int),
        ("Height", c_int),
    ]


PixelFormat32bppARGB = 0x26200A
ImageLockModeRead = 0x0001
InterpolationModeHighQualityBicubic = 7


def _bmp_entry(size: int, rgba: bytearray) -> bytes:
    header = struct.pack("<IiiHHIIiiII", 40, size, size * 2, 1, 32, 0,
                         size * size * 4, 0, 0, 0, 0)
    body = bytearray()
    for y in range(size - 1, -1, -1):
        row = rgba[y * size * 4:(y + 1) * size * 4]
        for x in range(size):
            r, g, b, a = row[x * 4:x * 4 + 4]
            body += bytes((b, g, r, a))
    mask_row = (size + 31) // 32 * 4
    return header + bytes(body) + bytes(mask_row * size)


def _write_png_bytes(size: int, rgba: bytearray) -> bytes:
    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))
    raw = bytearray()
    for y in range(size):
        raw.append(0)
        raw += rgba[y * size * 4:(y + 1) * size * 4]
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
            + chunk(b"IEND", b""))


def convert_to_ico(src_image: Path, out_ico: Path,
                   sizes=(16, 20, 24, 32, 40, 48, 64, 128, 256)) -> None:
    token = c_void_p()
    si = GdiplusStartupInput(1, None, False, False)
    if gdiplus.GdiplusStartup(byref(token), byref(si), None) != 0:
        raise RuntimeError("GdiplusStartup 失敗")

    try:
        p_image = c_void_p()
        w_path = str(src_image.resolve())
        if gdiplus.GdipLoadImageFromFile(w_path, byref(p_image)) != 0:
            raise FileNotFoundError(f"画像を開けません: {w_path}")

        w_in, h_in = c_uint(), c_uint()
        gdiplus.GdipGetImageWidth(p_image, byref(w_in))
        gdiplus.GdipGetImageHeight(p_image, byref(h_in))

        images_rgba = {}
        for sz in sizes:
            p_bmp = c_void_p()
            gdiplus.GdipCreateBitmapFromScan0(sz, sz, 0, PixelFormat32bppARGB,
                                             None, byref(p_bmp))
            p_gfx = c_void_p()
            gdiplus.GdipGetImageGraphicsContext(p_bmp, byref(p_gfx))
            gdiplus.GdipSetInterpolationMode(p_gfx,
                                            InterpolationModeHighQualityBicubic)

            gdiplus.GdipDrawImageRectRectI(p_gfx, p_image,
                                          0, 0, sz, sz,
                                          0, 0, w_in.value, h_in.value,
                                          2, None, None, None)

            bd = BitmapData()
            rc = Rect(0, 0, sz, sz)
            gdiplus.GdipBitmapLockBits(p_bmp, byref(rc), ImageLockModeRead,
                                      PixelFormat32bppARGB, byref(bd))

            buf = (ctypes.c_ubyte * (sz * sz * 4)).from_address(bd.Scan0)
            rgba = bytearray(sz * sz * 4)
            for i in range(sz * sz):
                b = buf[i * 4]
                g = buf[i * 4 + 1]
                r = buf[i * 4 + 2]
                a = buf[i * 4 + 3]
                rgba[i * 4] = r
                rgba[i * 4 + 1] = g
                rgba[i * 4 + 2] = b
                rgba[i * 4 + 3] = a

            gdiplus.GdipBitmapUnlockBits(p_bmp, byref(bd))
            gdiplus.GdipDeleteGraphics(p_gfx)
            gdiplus.GdipDisposeImage(p_bmp)

            images_rgba[sz] = rgba

        gdiplus.GdipDisposeImage(p_image)

        sorted_sizes = sorted(images_rgba.keys())
        entries, blobs = [], []
        offset = 6 + 16 * len(sorted_sizes)
        for sz in sorted_sizes:
            rgba = images_rgba[sz]
            if sz >= 256:
                data = _write_png_bytes(sz, rgba)
            else:
                data = _bmp_entry(sz, rgba)
            entries.append(struct.pack("<BBBBHHII",
                                       sz & 0xFF, sz & 0xFF,
                                       0, 0, 1, 32, len(data), offset))
            blobs.append(data)
            offset += len(data)

        out_ico.parent.mkdir(parents=True, exist_ok=True)
        out_ico.write_bytes(struct.pack("<HHH", 0, 1, len(sorted_sizes))
                            + b"".join(entries) + b"".join(blobs))
        print(f"OK: {out_ico.name} ({out_ico.stat().st_size} bytes)")

    finally:
        gdiplus.GdiplusShutdown(token)


def deploy_app_icons() -> None:
    root = Path(__file__).resolve().parent.parent
    src_dir = root / "docs" / "icons"
    idle_jpg = src_dir / "speakpulse_plus_single_icon_1792678880530.jpg"
    rec_jpg = src_dir / "speakpulse_plus_recording.jpg"

    assets_icon = root / "assets" / "icon"
    png_dir = assets_icon / "png"
    png_dir.mkdir(parents=True, exist_ok=True)

    # 1. idle アイコン
    print("Converting Idle icon...")
    convert_to_ico(idle_jpg, assets_icon / "koe-type-idle.ico")
    convert_to_ico(idle_jpg, assets_icon / "speakpulse-idle.ico")

    # 2. recording アイコン
    print("Converting Recording icon...")
    convert_to_ico(rec_jpg, assets_icon / "koe-type-recording.ico")
    convert_to_ico(rec_jpg, assets_icon / "speakpulse-recording.ico")

    print("Deploy completed successfully!")


if __name__ == "__main__":
    deploy_app_icons()
