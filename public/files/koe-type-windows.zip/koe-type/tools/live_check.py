"""本物として動いているアプリが、ちゃんと生きているかを確かめる。

自動テストは**から打ちモード**で動くので、「本物で起動したら
壊れていた」を見つけられない。実際にあった例

  ・ショートカットの確認を別のスレッドから呼んでいて、登録が外れた
    （から打ちモードでは登録しないので、テストでは出なかった）
  ・設定に古いモデル名が残っていて、新しい人だけ遅いモデルになった

ここでは**キーもクリックも 1 回も送らず**、外から様子を見るだけで
確かめる。

| 見るもの | やり方 |
|---|---|
| 動いているか | 多重起動よけの鍵（ミューテックス）を開いてみる |
| 固まっていないか | かくれ窓に WM_NULL を 2 秒待って投げる |
| 心拍 | `logs/heartbeat` の時刻と中身 |
| ショートカット | **自分で登録してみて、取られていれば OK** |
| マイク・モデル・見張り役 | 起動後のログを読む |
| 画面の帯 | 窓があるか |

    python tools/live_check.py
    python tools/live_check.py --start   # 動いていなければ起動してから見る
"""

from __future__ import annotations

import argparse
import ctypes
import re
import subprocess
import sys
import time
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

user32 = ctypes.WinDLL("user32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
user32.FindWindowW.restype = wintypes.HWND
user32.IsHungAppWindow.argtypes = [wintypes.HWND]
user32.IsHungAppWindow.restype = wintypes.BOOL
user32.SendMessageTimeoutW.argtypes = [
    wintypes.HWND, wintypes.UINT, ctypes.c_void_p, ctypes.c_void_p,
    wintypes.UINT, wintypes.UINT, ctypes.POINTER(ctypes.c_void_p)]
user32.SendMessageTimeoutW.restype = wintypes.LONG
user32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int,
                                  wintypes.UINT, wintypes.UINT]
user32.RegisterHotKey.restype = wintypes.BOOL
user32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
user32.OpenDesktopW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.BOOL,
                                wintypes.DWORD]
user32.OpenDesktopW.restype = wintypes.HANDLE
user32.SetThreadDesktop.argtypes = [wintypes.HANDLE]
user32.SetThreadDesktop.restype = wintypes.BOOL
kernel32.OpenMutexW.argtypes = [wintypes.DWORD, wintypes.BOOL,
                                wintypes.LPCWSTR]
kernel32.OpenMutexW.restype = wintypes.HANDLE
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

SYNCHRONIZE = 0x00100000
MUTEX_NAME = "Global\\koe-type-single"
HIDDEN_CLASS = "KoeTypeHiddenWindow"
ERROR_HOTKEY_ALREADY_REGISTERED = 1409

ok = 0
ng: list[str] = []
warn: list[str] = []


def check(label: str, good: bool, detail: str = "") -> bool:
    global ok
    if good:
        ok += 1
        print(f"  OK   {label}" + (f"  （{detail}）" if detail else ""))
    else:
        ng.append(label)
        print(f"  NG   {label}" + (f"  （{detail}）" if detail else ""))
    return good


def note(label: str, detail: str = "") -> None:
    warn.append(label)
    print(f"  ・   {label}" + (f"  （{detail}）" if detail else ""))


# ---------------------------------------------------------------- 見る係


def app_running() -> bool:
    handle = kernel32.OpenMutexW(SYNCHRONIZE, False, MUTEX_NAME)
    if handle:
        kernel32.CloseHandle(handle)
        return True
    return False


def hotkey_taken(mods: int, vk: int) -> bool:
    """そのショートカットが**誰かに取られている**か。

    自分で登録してみて、失敗すれば取られている。
    成功してしまったら、**すぐ外す**（横取りしたままにしない）。
    """
    ctypes.set_last_error(0)
    if user32.RegisterHotKey(None, 0xB001, mods, vk):
        user32.UnregisterHotKey(None, 0xB001)
        return False
    return ctypes.get_last_error() == ERROR_HOTKEY_ALREADY_REGISTERED


def last_startup(text: str) -> str:
    """いちばん新しい起動から後ろのログだけを返す。

    ログは道具（画像を撮る等）も書き込むので、**今の起動の分だけ**を
    切り出さないと、昔の失敗を今の失敗と勘違いする（実際にやった）。
    """
    lines = text.splitlines()
    last = None
    for i, line in enumerate(lines):
        if "待機中です" in line:
            last = i
    if last is None:
        return text[-20000:]
    floor = max(0, last - 250)
    begin = floor
    # 起動のいちばん最初に出る行まで さかのぼる
    for i in range(last, floor, -1):
        # 起動のたびに 1 回だけ出る行（これより上は前の起動）
        if "を起動します (python" in lines[i]:
            begin = i
            break
    return chr(10).join(lines[begin:])


def guardian_running() -> bool:
    """見張り役が動いているか。

    コマンドを呼ばずに、ログで見る。見張り役は起動時に 1 行書く。
    いまは自分のログ（guardian.log）に書く（本体と同じファイルだと
    Windows でログを回せなくなったため）。昔の版は本体のログに出る。
    """
    if "見張りを始めます" in last_startup(read_log()):
        return True
    path = ROOT / "logs" / "guardian.log"
    try:
        tail = path.read_text("utf-8", "replace")[-4000:]
    except OSError:
        return False
    return "見張りを始めます" in tail


def read_log() -> str:
    path = ROOT / "logs" / "koe-type.log"
    if not path.is_file():
        return ""
    return path.read_text("utf-8", "replace")


def heartbeat() -> tuple[float, dict]:
    path = ROOT / "logs" / "heartbeat"
    try:
        age = max(0.0, time.time() - path.stat().st_mtime)
        text = path.read_text("utf-8", "replace")
    except OSError:
        return 1e9, {}
    fields = {}
    for line in text.splitlines()[1:]:
        if "=" in line:
            key, _, value = line.partition("=")
            fields[key.strip()] = value.strip()
    return age, fields


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--start", action="store_true",
                    help="動いていなければ起動してから見る")
    args = ap.parse_args()

    print("=" * 70)
    print(" 本物として動いているアプリを確かめる")
    print(" キーもクリックも 1 回も送りません")
    print("=" * 70)

    if not app_running() and args.start:
        print("\n  動いていないので起動します")
        script_path = str(ROOT / "koe-type.pyw")
        cmd = ('schtasks /create /tn "KoeTypeRun" '
               f'/tr "\\"C:\\Python314\\pythonw.exe\\" \\"{script_path}\\"" '
               '/sc ONCE /st 23:59 /it /f && schtasks /run /tn "KoeTypeRun"')
        res = subprocess.run(["cmd.exe", "/c", cmd],
                             capture_output=True, check=False)
        if res.returncode != 0:
            exe = Path(sys.executable)
            if exe.name.lower() == "python.exe":
                alt = exe.with_name("pythonw.exe")
                if alt.is_file():
                    exe = alt
            subprocess.Popen(  # noqa: S603
                [str(exe), str(ROOT / "koe-type.pyw")], cwd=str(ROOT),
                creationflags=0x08000000)
        for _ in range(40):
            if app_running():
                break
            time.sleep(0.5)
        time.sleep(6.0)

    print("\n[1] 動いているか")
    running = check("多重起動よけの鍵がある（＝動いている）", app_running())
    if not running:
        print("\n  動いていないので、ここで終わります。")
        print("  `python tools/live_check.py --start` で起動してから見られます。")
        return 1

    print("\n[2] 固まっていないか")
    # 別デスクトップ（エージェント等）から実行されても利用者の窓を探せるようにする
    try:
        hdesk = user32.OpenDesktopW("Default", 0, False, 0x01FF)
        if hdesk:
            user32.SetThreadDesktop(hdesk)
    except Exception:
        pass
    hwnd = user32.FindWindowW(HIDDEN_CLASS, None)
    check("かくれ窓がある", bool(hwnd), f"hwnd={hwnd}")
    if hwnd:
        check("Windows から「応答なし」と見られていない",
              not user32.IsHungAppWindow(hwnd))
        result = ctypes.c_void_p()
        answered = user32.SendMessageTimeoutW(hwnd, 0x0000, None, None,
                                              0x0002, 2000,
                                              ctypes.byref(result))
        check("メッセージループが 2 秒以内に返事をする", bool(answered))

    print("\n[3] 心拍")
    age, fields = heartbeat()
    check("心拍が 15 秒以内に打たれている", age < 15.0, f"{age:.1f} 秒前")
    if fields:
        check("心拍に状態が書かれている", "state" in fields, str(fields))
        stuck = float(fields.get("stopping", 0) or 0)
        check("「止める途中」で居残っていない", stuck < 5.0,
              f"{stuck:.1f} 秒")
        check("画面の繰り返しが回っている",
              int(fields.get("ticks", 0) or 0) > 0,
              f"{fields.get('ticks')} 回")
    else:
        note("心拍に状態が書かれていない（古い版が動いている可能性）")

    print("\n[4] ショートカット（登録されているか）")
    sys.path.insert(0, str(ROOT))
    from app import hotkeys  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    cfg = Config()
    spec = cfg.str_("hotkey", "ctrl+space")
    vk, mods = hotkeys.parse(spec)
    flags = 0
    for name, bit in (("alt", 1), ("ctrl", 2), ("shift", 4), ("win", 8)):
        if name in mods:
            flags |= bit
    check(f"{hotkeys.label(spec)} が誰かに取られている（＝登録できている）",
          hotkey_taken(flags, vk))

    print("\n[5] 起動したときのログ")
    text = read_log()
    tail = last_startup(text)
    wants = [
        ("ショートカットの用意", "ショートカットとトレイを用意しました"),
        ("帯の用意", "録音中の帯を用意しました"),
        ("画面の見張り", "画面の見張りを付けました"),
        ("マイク", "マイクを開きました"),
        ("モデルの読み込み", "常駐モデルを読みました"),
        ("ウォームアップ", "ウォームアップ完了"),
        ("見張り役", "見張り役を起こしました"),
        ("待機に入った", "待機中です"),
    ]
    for label, needle in wants:
        check(label, needle in tail)

    m = re.search(r"ウォームアップ完了 (\S+)（読み込み ([0-9.]+)s / "
                  r"1回 ([0-9.]+)s）", tail)
    if m:
        print(f"       モデル {m.group(1)} / 読み込み {m.group(2)}s / "
              f"1 回 {m.group(3)}s")
        check("1 回の認識が 0.4 秒以内", float(m.group(3)) <= 0.4,
              f"{m.group(3)}s")

    print("\n[6] 起動後に困りごとが出ていないか")
    bad = [line for line in tail.splitlines()
           if ("ERROR" in line or "Traceback" in line)
           and "空だった" not in line]
    check("ERROR の行がない", not bad,
          bad[0][:90] if bad else "")
    check("マウスの古い見張りが動いていない",
          "マウスの見張りは、作り直すまで" not in tail)

    print("\n[7] 見張り役")
    check("見張り役が動いている", guardian_running())

    print("\n[8] 設定とモデル")
    from app import catalog  # noqa: PLC0415
    model = cfg.str_("model", catalog.DEFAULT_MODEL)
    check("モデルが一覧にある", model in catalog.MODELS, model)
    spec_model = catalog.MODELS.get(model)
    if spec_model is not None:
        path = getattr(spec_model, "model_path", None)
        if path:
            check("モデルのファイルがある", Path(path).is_file(), str(path))
    for key, want in (("question_marks", "never"),
                      ("full_stops", "off"),
                      ("stop_on_click", "any"),
                      ("join_separator", "space")):
        got = cfg.str_(key, "")
        if got != want:
            note(f"設定 {key} が {got!r}（おすすめは {want!r}）")
        else:
            check(f"設定 {key} = {want}", True)

    print("\n" + "=" * 70)
    print(f" 成功 {ok} / 失敗 {len(ng)}" +
          (f" / 気になる点 {len(warn)}" if warn else ""))
    print("=" * 70)
    if ng:
        for label in ng:
            print(f"  - {label}")
    return 1 if ng else 0


if __name__ == "__main__":
    raise SystemExit(main())
