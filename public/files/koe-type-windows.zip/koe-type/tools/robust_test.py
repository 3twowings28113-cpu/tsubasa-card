"""「どんな環境・状況でも壊れない」を確かめる。

実機で作れない状況は**差し替え**で作り出す。
どの場合も次の 4 つを満たすことを見る。

  ・落ちない（終了コードが 0）
  ・固まらない（時間内に終わる）
  ・文字を失わない（入るはずだった文字が記録に残る）
  ・分かりやすい日本語で、状況と次にすることを知らせる

本物のキーは 1 回も送らない。スピーカーも鳴らさない。
利用者の設定・辞書・履歴には触らない（一時フォルダを使う）。

    python tools/robust_test.py
    python tools/robust_test.py -k model
    python tools/robust_test.py --list
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tools.mock_e2e import AUDIO, Check, kinds, make_home, run_app, typed  # noqa: E402

PYTHON = sys.executable
TESTS: dict[str, object] = {}


def test(name: str):  # noqa: ANN201
    def deco(fn):  # noqa: ANN001
        TESTS[name] = fn
        return fn
    return deco


def log_text(home: Path) -> str:
    try:
        return (home / "logs" / "koe-type.log").read_text("utf-8", "replace")
    except OSError:
        return ""


def survives(c: Check, r: dict, home: Path) -> None:
    """どの状況でも共通に見ること。"""
    c.ok(r["rc"] == 0,
         f"落ちました（終了コード {r['rc']}）: {r['stderr'][:200]}")
    text = log_text(home)
    c.ok("Traceback" not in (r["stderr"] or ""), "stderr に例外が出ました")
    c.ok("未捕捉の例外" not in text, "ログに未捕捉の例外があります")


# ------------------------------------------------------------ 設定まわり


@test("config_broken")
def t_config_broken(tmp: Path) -> Check:
    """設定ファイルが壊れていても、初期値で起動して退避する。"""
    c = Check("config_broken")
    home = make_home(tmp / "cfgbad")
    (home / "config.json").write_text('{"hotkey": "ctrl+space", "bro',
                                      "utf-8")
    r = run_app(home, AUDIO / "silence.wav",
                [{"at": 0.5, "event": "quit"}], timeout=60)
    survives(c, r, home)
    broken = list(home.glob("config.broken-*.json"))
    c.ok(bool(broken), "壊れた設定ファイルが退避されていません")
    c.ok((home / "config.json").is_file(), "設定ファイルが作り直されていません")
    if broken:
        kept = broken[0].read_text("utf-8")
        c.ok("bro" in kept, "退避したファイルの中身が元のままではありません")
        c.note(f"退避先 {broken[0].name}（中身はそのまま）")
    c.ok("壊れていたので" in log_text(home),
         "日本語で状況を知らせていません")
    return c


@test("config_empty")
def t_config_empty(tmp: Path) -> Check:
    """設定ファイルが空（0 バイト）でも起動する。"""
    c = Check("config_empty")
    home = make_home(tmp / "cfgempty")
    (home / "config.json").write_text("", "utf-8")
    r = run_app(home, AUDIO / "silence.wav",
                [{"at": 0.5, "event": "quit"}], timeout=60)
    survives(c, r, home)
    c.ok((home / "config.json").stat().st_size > 10,
         "設定ファイルが作り直されていません")
    return c


@test("dictionary_broken")
def t_dict_broken(tmp: Path) -> Check:
    """辞書の文字コードが違っても、起動して退避する。"""
    c = Check("dictionary_broken")
    home = make_home(tmp / "dictbad")
    (home / "dictionary.txt").write_bytes(b"\xff\xfe\x00\x81\x40bad")
    r = run_app(home, AUDIO / "silence.wav",
                [{"at": 0.5, "event": "quit"}], timeout=60)
    survives(c, r, home)
    c.ok(bool(list(home.glob("dictionary.broken-*.txt"))),
         "壊れた辞書が退避されていません")
    return c


@test("history_broken")
def t_history_broken(tmp: Path) -> Check:
    """履歴のデータベースが壊れていても、文字起こしは続く。"""
    c = Check("history_broken")
    home = make_home(tmp / "histbad", {"input_mode": "phrase"})
    (home / "data").mkdir(parents=True, exist_ok=True)
    (home / "data" / "history.db").write_bytes(b"this is not a database" * 40)
    wav = AUDIO / "p01.wav"
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 6.0, "event": "stop"},
        {"at": 12.0, "event": "quit"},
    ])
    survives(c, r, home)
    c.ok(bool(typed(r["entries"])),
         "履歴が壊れていると文字が入らなくなりました（文字を失っています）")
    c.note(f"入った文字: {typed(r['entries'])[:40]}")
    return c


# ------------------------------------------------------------ モデルまわり


@test("model_missing")
def t_model_missing(tmp: Path) -> Check:
    """モデルのファイルがないとき、分かる言葉で知らせる。"""
    c = Check("model_missing")
    home = make_home(tmp / "nomodel", {"model": "whisper-turbo-resident"})
    # ★本物の models\ を見ると、利用者がそのモデルを落とした時点で
    # 「ない」状態が作れなくなる（2026-10-05 に実際に落ちた）。
    # 空の使い捨てフォルダを見せて、確実に「ない」状態にする。
    empty = tmp / "nomodel_models"
    empty.mkdir(parents=True, exist_ok=True)
    r = run_app(home, AUDIO / "silence.wav",
                [{"at": 0.5, "event": "quit"}], timeout=60,
                env_extra={"KOE_TYPE_MODEL_DIR": str(empty)})
    survives(c, r, home)
    text = log_text(home)
    c.ok("ファイルがありません" in text or "モデルを使えません" in text
         or "切り替えます" in text,
         "モデルがないことを知らせていません")
    c.note("ログの知らせ方を確認")
    return c


@test("model_corrupt")
def t_model_corrupt(tmp: Path) -> Check:
    """モデルのファイルが壊れていても落ちない。"""
    c = Check("model_corrupt")
    fake_models = tmp / "badmodels"
    fake_models.mkdir(parents=True, exist_ok=True)
    (fake_models / "SenseVoiceSmall-Q8_0.gguf").write_bytes(
        b"GGUF" + b"\x00" * 4096)
    home = make_home(tmp / "badmodel")
    env_extra = {"KOE_TYPE_MODEL_DIR": str(fake_models)}
    r = run_app(home, AUDIO / "p01.wav", [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 5.0, "event": "stop"},
        {"at": 11.0, "event": "quit"},
    ], env_extra=env_extra)
    survives(c, r, home)
    text = log_text(home)
    c.ok("読めません" in text or "切り替えます" in text
         or "使えません" in text,
         "モデルが壊れていることを知らせていません")
    return c


@test("no_resident")
def t_no_resident(tmp: Path) -> Check:
    """常駐エンジンがない PC でも、外部プロセス方式で動く。"""
    c = Check("no_resident")
    home = make_home(tmp / "nodll", {"input_mode": "phrase"})
    r = run_app(home, AUDIO / "p02.wav", [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 5.5, "event": "stop"},
        {"at": 13.0, "event": "quit"},
    ], env_extra={"KOE_TYPE_NO_RESIDENT": "1"})
    survives(c, r, home)
    c.ok(bool(typed(r["entries"])),
         "常駐エンジンなしだと文字が入りません")
    text = log_text(home)
    c.ok("外部プロセス" in text, "外部プロセス方式へ落ちた記録がありません")
    c.note(f"入った文字: {typed(r['entries'])[:40]}")
    return c


# ------------------------------------------------------------ マイクまわり


@test("no_microphone")
def t_no_mic(tmp: Path) -> Check:
    """マイクがなくても落ちない。知らせて待つ。"""
    c = Check("no_microphone")
    home = make_home(tmp / "nomic", {"mic_preroll_ms": 0})
    # 偽マイクを外し、本物のマイクも開けない状況にする
    r = run_app(home, AUDIO / "silence.wav",
                [{"at": 0.5, "event": "quit"}], timeout=60,
                env_extra={"KOE_TYPE_NO_MIC": "1"}, fake_mic=False)
    survives(c, r, home)
    return c


# ------------------------------------------------------------ 多重起動など


@test("two_instances")
def t_two(tmp: Path) -> Check:
    """2 つ同時に起動しても、2 つ目は静かに終わる。"""
    c = Check("two_instances")
    home = make_home(tmp / "two")
    script = home / "script.json"
    script.write_text(json.dumps(
        [{"at": 6.0, "event": "quit"}]), "utf-8")
    env = dict(os.environ)
    env.update({"PYTHONUTF8": "1", "KOE_TYPE_HOME": str(home),
                "KOE_TYPE_DRY_RUN": "1",
                "KOE_TYPE_TEST_SCRIPT": str(script),
                "KOE_TYPE_FAKE_MIC": str(AUDIO / "silence.wav")})
    first = subprocess.Popen(  # noqa: S603
        [PYTHON, "-m", "app.main"], cwd=str(ROOT), env=env,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(2.5)
    second = subprocess.run(  # noqa: S603
        [PYTHON, "-m", "app.main"], cwd=str(ROOT), env=env,
        capture_output=True, text=True, encoding="utf-8",
        errors="replace", timeout=40)
    try:
        first.wait(timeout=30)
    except subprocess.TimeoutExpired:
        first.kill()
        c.fails.append("1 つ目が終わりませんでした")
    c.ok(second.returncode == 0,
         f"2 つ目の終了コードが {second.returncode}")
    c.ok("すでに起動している" in log_text(home),
         "2 つ目が静かに終わった記録がありません")
    return c


@test("long_recording")
def t_long(tmp: Path) -> Check:
    """長めの録音でも、遅れが積み上がらず最後まで入る。"""
    c = Check("long_recording")
    home = make_home(tmp / "long")
    wav = AUDIO / "p08.wav"          # いちばん長いもの
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 40.0, "event": "stop"},      # 音を何度も繰り返す長さ
        {"at": 48.0, "event": "quit"},
    ], timeout=120)
    survives(c, r, home)
    entries = [e for e in r["entries"] if e.get("kind") == "paste"]
    c.ok(bool(entries), "40 秒の録音で 1 文字も入りませんでした")
    if len(entries) >= 2:
        gaps = [float(b["t"]) - float(a["t"])
                for a, b in zip(entries, entries[1:])]
        worst = max(gaps)
        c.ok(worst < 12.0, f"入力の間隔が開きすぎました（最大 {worst:.1f}s）")
        c.note(f"{len(entries)} 回入力 / 間隔の最大 {worst:.1f}s")
    return c


# ------------------------------------------------------------ 本体


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("-k", "--filter", default="")
    ap.add_argument("--keep", action="store_true")
    ap.add_argument("--list", action="store_true")
    args = ap.parse_args()

    if args.list:
        for name in TESTS:
            print(name)
        return 0

    names = [n for n in TESTS if args.filter in n]
    print("=" * 70)
    print(" 壊れない確認（本物のキーは1回も送りません）")
    print("=" * 70)
    tmp = Path(tempfile.mkdtemp(prefix="koe-type-robust-"))
    results = []
    try:
        for name in names:
            print(f"\n■ {name}")
            t0 = time.perf_counter()
            try:
                check = TESTS[name](tmp)  # type: ignore[operator]
            except Exception as exc:  # noqa: BLE001
                import traceback
                check = Check(name)
                check.fails.append(f"テスト自体で例外: {exc}")
                traceback.print_exc()
            for note in check.notes:
                print(f"    {note}")
            for fail in check.fails:
                print(f"    × {fail}")
            print(f"    {'合格' if check.passed else '不合格'}"
                  f"  ({time.perf_counter() - t0:.1f}s)")
            results.append(check)
    finally:
        if args.keep:
            print(f"\n一時フォルダ: {tmp}")
        else:
            shutil.rmtree(tmp, ignore_errors=True)

    bad = [r for r in results if not r.passed]
    print("\n" + "=" * 70)
    print(f" {len(results) - len(bad)}/{len(results)} 合格")
    if bad:
        print(" 不合格: " + ", ".join(r.name for r in bad))
    print("=" * 70)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
