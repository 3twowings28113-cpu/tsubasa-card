"""効果音のプリセット、音量調整、テスト再生、およびテスト時の安全弁の検証。

ルール遵守:
  - スピーカーから音を流さない（KOE_TYPE_DRY_RUN=1 で winsound を呼ばない）。
  - 合成キー入力を行わない。
  - テスト用の一時フォルダで完結する。
"""

from __future__ import annotations

import os
import struct
import sys
import tempfile
import unittest
import wave
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# テスト実行時は常に音を鳴らさない（スピーカー保護ルール）
os.environ["KOE_TYPE_DRY_RUN"] = "1"
os.environ["KOE_TYPE_HOME"] = tempfile.mkdtemp(prefix="koe_sound_test_")

from app import schema, sysaudio
from app.configstore import Config
from app.websettings import Bridge


class SoundFeaturesTest(unittest.TestCase):

    def test_themes_definition(self) -> None:
        """4種類のテーマが定義され、必要な音がそろっていること。"""
        expected_themes = {"default", "soft", "chime", "mechanical"}
        self.assertTrue(expected_themes.issubset(set(sysaudio.THEMES.keys())))
        for theme_name, sounds in sysaudio.THEMES.items():
            for sound_key in ("start", "stop", "cancel"):
                self.assertIn(sound_key, sounds,
                              f"{theme_name} に {sound_key} がありません")
                specs = sounds[sound_key]
                self.assertGreater(len(specs), 0)
                for freq, sec in specs:
                    self.assertGreater(freq, 0)
                    self.assertGreater(sec, 0)

    def test_ensure_sounds_generates_valid_wav(self) -> None:
        """各テーマの WAV ファイルが正しく生成され、wave モジュールで読めること。"""
        for theme in ("default", "soft", "chime", "mechanical"):
            sounds = sysaudio.ensure_sounds(theme=theme, volume=80)
            for sound_name in ("start", "stop", "cancel"):
                path = sounds.get(sound_name)
                self.assertIsNotNone(path)
                self.assertTrue(path.exists(), f"{path} が存在しません")
                with wave.open(str(path), "rb") as w:
                    self.assertEqual(w.getnchannels(), 1)
                    self.assertEqual(w.getsampwidth(), 2)
                    self.assertEqual(w.getframerate(), 22050)
                    frames = w.readframes(w.getnframes())
                    self.assertGreater(len(frames), 0)

    def test_volume_scaling(self) -> None:
        """音量設定によって WAV の振幅が変わること。"""
        sounds_low = sysaudio.ensure_sounds(theme="default", volume=20)
        sounds_high = sysaudio.ensure_sounds(theme="default", volume=100)

        def max_amp(path: Path) -> int:
            with wave.open(str(path), "rb") as w:
                frames = w.readframes(w.getnframes())
            count = len(frames) // 2
            samples = struct.unpack(f"<{count}h", frames)
            return max(abs(s) for s in samples)

        amp_low = max_amp(sounds_low["start"])
        amp_high = max_amp(sounds_high["start"])
        self.assertGreater(amp_high, amp_low)
        self.assertGreater(amp_low, 0)

    def test_dry_run_suppresses_sound(self) -> None:
        """KOE_TYPE_DRY_RUN=1 のときは winsound.PlaySound を呼ばないこと。"""
        with patch("winsound.PlaySound") as mock_play:
            sysaudio.play("start", theme="default", volume=80)
            mock_play.assert_not_called()

    def test_schema_items(self) -> None:
        """schema に効果音関連の項目が正しく定義されていること。"""
        theme_item = schema.find("sound_theme")
        self.assertIsNotNone(theme_item)
        self.assertEqual(theme_item.default, "default")
        theme_vals = [opt.value for opt in theme_item.options]
        self.assertIn("default", theme_vals)
        self.assertIn("soft", theme_vals)
        self.assertIn("chime", theme_vals)
        self.assertIn("mechanical", theme_vals)

        vol_item = schema.find("sound_volume")
        self.assertIsNotNone(vol_item)
        self.assertEqual(vol_item.default, 80)
        self.assertEqual(vol_item.minimum, 0)
        self.assertEqual(vol_item.maximum, 100)

        test_item = schema.find("test_sound")
        self.assertIsNotNone(test_item)
        self.assertEqual(test_item.kind, "action")
        self.assertEqual(test_item.panel, "test_sound")

    def test_bridge_test_sound_action(self) -> None:
        """Bridge.run_action('test_sound') が正常に動作すること。"""
        cfg = Config()
        mock_action = MagicMock()
        mock_dict = MagicMock()
        mock_dict.detailed_entries.return_value = []
        mock_hist = MagicMock()
        mock_hist.recent.return_value = []

        bridge = Bridge(cfg, mock_dict, mock_hist, mock_action)
        with patch("app.sysaudio.play") as mock_play:
            res = bridge.run_action("test_sound", {})
            self.assertTrue(res.get("ok"))
            mock_play.assert_called_once_with("start", theme="default", volume=80)


if __name__ == "__main__":
    unittest.main()
