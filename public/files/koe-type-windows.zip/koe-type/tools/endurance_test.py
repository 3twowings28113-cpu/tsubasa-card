"""長く使っても重くならないことを確かめる。

測るもの
  ・待機中の CPU がほぼ 0% か（基準 C5）
  ・100 回くり返してもメモリが増え続けないか（基準 C6 / 8.10）

キーは 1 回も送らない。スピーカーも使わない。
利用者の設定・辞書・履歴には触らない。

    python tools/endurance_test.py              # 100 回
    python tools/endurance_test.py --runs 300
    python tools/endurance_test.py --idle 120   # 待機中の CPU を 120 秒見る
"""

from __future__ import annotations

import argparse
import ctypes
import gc
import json
import sys
import time
import wave
from ctypes import wintypes
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import catalog, engines  # noqa: E402

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
psapi = ctypes.WinDLL("psapi", use_last_error=True)


class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
    _fields_ = [
        ("cb", wintypes.DWORD),
        ("PageFaultCount", wintypes.DWORD),
        ("PeakWorkingSetSize", ctypes.c_size_t),
        ("WorkingSetSize", ctypes.c_size_t),
        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPagedPoolUsage", ctypes.c_size_t),
        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
        ("PagefileUsage", ctypes.c_size_t),
        ("PeakPagefileUsage", ctypes.c_size_t),
    ]


class FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", wintypes.DWORD),
                ("dwHighDateTime", wintypes.DWORD)]


# ctypes は argtypes / restype を書かないと、64bit のハンドルを
# 32bit に切り詰めてしまい、呼び出しが黙って失敗する（0 が返る）。
kernel32.GetCurrentProcess.restype = wintypes.HANDLE
kernel32.GetProcessTimes.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME),
    ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME)]
kernel32.GetProcessTimes.restype = wintypes.BOOL
psapi.GetProcessMemoryInfo.argtypes = [
    wintypes.HANDLE, ctypes.POINTER(PROCESS_MEMORY_COUNTERS), wintypes.DWORD]
psapi.GetProcessMemoryInfo.restype = wintypes.BOOL


def memory_mb() -> float:
    counters = PROCESS_MEMORY_COUNTERS()
    counters.cb = ctypes.sizeof(counters)
    if not psapi.GetProcessMemoryInfo(kernel32.GetCurrentProcess(),
                                      ctypes.byref(counters), counters.cb):
        raise OSError(f"メモリを測れません err={ctypes.get_last_error()}")
    return counters.WorkingSetSize / (1024 * 1024)


def cpu_seconds() -> float:
    creation, exit_, kernel, user = (FILETIME(), FILETIME(),
                                     FILETIME(), FILETIME())
    if not kernel32.GetProcessTimes(
            kernel32.GetCurrentProcess(), ctypes.byref(creation),
            ctypes.byref(exit_), ctypes.byref(kernel), ctypes.byref(user)):
        raise OSError(f"CPU 時間を測れません err={ctypes.get_last_error()}")

    def to_s(ft: FILETIME) -> float:
        return ((ft.dwHighDateTime << 32) | ft.dwLowDateTime) / 1e7

    return to_s(kernel) + to_s(user)


def read_pcm(path: Path) -> bytes:
    with wave.open(str(path)) as w:
        return w.readframes(w.getnframes())


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--runs", type=int, default=100)
    ap.add_argument("--idle", type=int, default=60,
                    help="待機中の CPU を見る秒数")
    ap.add_argument("--model", default=catalog.DEFAULT_MODEL)
    args = ap.parse_args()

    print("=" * 70)
    print(" 長く使っても重くならないかを確かめる")
    print("=" * 70)

    # ---------------------------------------------------------- 待機中
    print(f"\n[1] 待機中の CPU（{args.idle} 秒）")
    print("     アプリを待機状態のまま置いて、使った CPU 時間を測ります")
    from app.audio import Recorder  # noqa: PLC0415
    got = []
    rec = Recorder(lambda data: got.append(len(data)))
    rec.preroll_ms = 1000
    try:
        rec.listen()
    except Exception as exc:  # noqa: BLE001
        print(f"     マイクを開けませんでした: {exc}")
    t0, c0 = time.perf_counter(), cpu_seconds()
    time.sleep(args.idle)
    wall = time.perf_counter() - t0
    used = cpu_seconds() - c0
    rec.shutdown()
    percent = used / wall * 100
    print(f"     CPU 時間 {used:.2f} 秒 / 実時間 {wall:.1f} 秒 "
          f"= **{percent:.2f}%**")
    print(f"     {'OK' if percent < 2.0 else 'NG'}  基準：ほぼ 0%（2% 未満）")
    idle_ok = percent < 2.0

    # ---------------------------------------------------------- くり返し
    print(f"\n[2] {args.runs} 回くり返したときのメモリ")
    try:
        engine = engines.build(args.model, "ja")
    except Exception as exc:  # noqa: BLE001
        print(f"     モデルを使えません: {exc}")
        return 2
    engine.warmup()

    files = sorted((ROOT / "bench" / "audio").glob("p0*.wav"))
    pcms = [read_pcm(f) for f in files] or [bytes(16000 * 2 * 3)]
    gc.collect()
    base = memory_mb()
    print(f"     はじめ {base:.1f} MB")

    marks = []
    t0 = time.perf_counter()
    for i in range(1, args.runs + 1):
        engine.transcribe_pcm(pcms[i % len(pcms)])
        if i % max(1, args.runs // 10) == 0:
            gc.collect()
            now = memory_mb()
            marks.append((i, now))
            print(f"     {i:4d} 回目  {now:7.1f} MB  "
                  f"（はじめから {now - base:+.1f} MB）")
    took = time.perf_counter() - t0
    engine.close()
    gc.collect()
    after = memory_mb()

    print(f"\n     {args.runs} 回で {took:.1f} 秒"
          f"（1 回あたり {took / args.runs:.3f} 秒）")
    print(f"     終わり {after:.1f} MB（はじめから {after - base:+.1f} MB）")

    # 後半だけの増え方を見る（前半はキャッシュが温まるので増えて当然）
    half = marks[len(marks) // 2:]
    grown = (half[-1][1] - half[0][1]) if len(half) >= 2 else 0.0
    runs_in_half = (half[-1][0] - half[0][0]) if len(half) >= 2 else 1
    per_run = grown / max(1, runs_in_half)
    print(f"     後半 {runs_in_half} 回での増え方 {grown:+.1f} MB "
          f"（1 回あたり {per_run * 1024:+.1f} KB）")
    leak_ok = per_run < 0.05        # 1 回あたり 50KB 未満なら増え続けていない
    print(f"     {'OK' if leak_ok else 'NG'}  "
          f"基準：くり返しても増え続けない")

    out = ROOT / "bench" / "eval" / "endurance.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps({
        "idle_percent": round(percent, 3), "idle_seconds": args.idle,
        "runs": args.runs, "base_mb": round(base, 1),
        "after_mb": round(after, 1), "marks": marks,
        "per_run_kb": round(per_run * 1024, 1),
        "seconds_per_run": round(took / args.runs, 4),
    }, ensure_ascii=False, indent=1), "utf-8")

    print("\n" + "=" * 70)
    print(f" 待機中の CPU {'合格' if idle_ok else '不合格'} / "
          f"メモリ {'合格' if leak_ok else '不合格'}")
    print("=" * 70)
    return 0 if (idle_ok and leak_ok) else 1


if __name__ == "__main__":
    raise SystemExit(main())
