r"""音声ファイルを通して、録音以外のすべてを検証する。

スピーカーもマイクも使わない。WAV を「マイクから来たことにして」
無音検出 → 区間切り出し → 文字起こし → 整形 → 辞書 の順に通す。

  python tools\pipeline_test.py
"""

from __future__ import annotations

import sys
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import catalog, engines                      # noqa: E402
from app.audio import SAMPLE_RATE                      # noqa: E402
from app.configstore import Config                     # noqa: E402
from app.textproc import Dictionary, is_noise, tidy    # noqa: E402
from app.util import ensure_dirs, setup_logging        # noqa: E402
from app.vad import SegmentCutter                      # noqa: E402

AUDIO = ROOT / "bench" / "audio"

ok = fail = 0


def check(label: str, good: bool, extra: str = "") -> None:
    global ok, fail
    if good:
        ok += 1
        print(f"  OK   {label} {extra}")
    else:
        fail += 1
        print(f"  NG   {label} {extra}")


def read_pcm(path: Path) -> bytes:
    with wave.open(str(path)) as w:
        assert w.getframerate() == SAMPLE_RATE, f"{path} は 16kHz ではありません"
        return w.readframes(w.getnframes())


def main() -> int:
    ensure_dirs()
    setup_logging("INFO")
    cfg = Config()
    d = Dictionary()

    clips = sorted(AUDIO.glob("p0*.wav"))[:3]
    if not clips:
        print("bench/audio に検証用の音声がありません。")
        print("  powershell -ExecutionPolicy Bypass -File bench\\make_tts.ps1")
        print("で作ってから、もう一度実行してください。")
        return 2

    print(f"\n[1] 無音 1.2 秒をはさんだ {len(clips)} 文を区切る")
    sil = lambda ms: b"\x00" * (SAMPLE_RATE * 2 * ms // 1000)  # noqa: E731
    stream = sil(400)
    for clip in clips:
        stream += read_pcm(clip) + sil(1200)

    cutter = SegmentCutter(
        SAMPLE_RATE, pause_ms=cfg.int_("pause_ms"),
        min_speech_ms=cfg.int_("min_speech_ms"),
        max_segment_ms=cfg.int_("max_segment_ms"),
        preroll_ms=cfg.int_("preroll_ms"), tail_ms=cfg.int_("tail_ms"),
        sensitivity=cfg.int_("vad_sensitivity") / 10.0,
        floor=float(cfg.int_("vad_floor")))

    segments: list[bytes] = []
    step = SAMPLE_RATE * 2 * 50 // 1000
    for i in range(0, len(stream), step):
        segments.extend(cutter.feed(stream[i:i + step]))
    segments.extend(cutter.flush())
    check(f"{len(clips)} 区間に分かれる", len(segments) == len(clips),
          f"-> {len(segments)} 区間")

    print("\n[2] 現在のモデルで文字起こし")
    model_key = cfg.str_("model", catalog.DEFAULT_MODEL)
    missing = catalog.missing_assets(model_key)
    if missing:
        print(f"  モデル '{model_key}' のファイルが足りません: "
              + ", ".join(a.name for a in missing))
        print(f"  python -m app.fetch {model_key}  で取得できます。")
        return 2
    engine = engines.build(model_key, cfg.str_("language", "ja"))
    # 1 回目はモデル読み込みとシェーダ準備で遅いので、計測の前に空回しする
    warm = engines.temp_wav()
    try:
        engines.write_wav(warm, bytes(SAMPLE_RATE))   # 0.5 秒ぶんの無音
        engine.transcribe(warm)
    finally:
        warm.unlink(missing_ok=True)
    options = dict(punctuation=cfg.str_("punctuation_density", "normal") != "none",
                   fillers=cfg.bool_("remove_fillers"),
                   halfwidth=cfg.bool_("halfwidth_numbers"))
    for i, seg in enumerate(segments, 1):
        wav = engines.temp_wav()
        try:
            engines.write_wav(wav, seg)
            t0 = time.perf_counter()
            raw = engine.transcribe(wav)
        finally:
            wav.unlink(missing_ok=True)
        dt = time.perf_counter() - t0
        text = tidy(d.apply(tidy(raw, **options)), **options)
        secs = len(seg) / (SAMPLE_RATE * 2)
        print(f"       区間{i} {secs:.2f}s -> {dt:.2f}s  {text}")
        check(f"区間{i} の結果が空でない", bool(text) and not is_noise(text))
        check(f"区間{i} が 5 秒換算 1.5 秒以内", dt / secs * 5 <= 1.5,
              f"-> {dt / secs * 5:.2f}s")

    print("\n[3] 整形の規則")
    check("日本語の間の空白を取る",
          tidy("今日 の 予定") == "今日の予定")
    check("英単語の間の空白は残す",
          tidy("Claude  Code and Git") == "Claude Code and Git")
    check("フィラー語を消す",
          tidy("えーと、明日の予定です", fillers=True) == "明日の予定です",
          f"-> {tidy('えーと、明日の予定です', fillers=True)!r}")
    check("句読点を外せる",
          tidy("はい、そうです。", punctuation=False) == "はいそうです")
    check("全角数字を半角にする",
          tidy("１０時です", halfwidth=True) == "10時です")
    check("記号だけは入力しない", is_noise("。") and is_noise("?"))
    check("ふつうの語は入力する", not is_noise("はい"))

    print(f"\n==== 成功 {ok} / 失敗 {fail} ====")
    return 1 if fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
