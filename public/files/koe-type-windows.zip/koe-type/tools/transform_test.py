"""特定動作（敬語変換、ビジネス丁寧語、要約、翻訳）のテスト。"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.transform import (
    ApiRequiredError,
    clean_ai_output,
    detect_provider,
    fill_prompt,
    to_brainstorm_offline,
    to_business,
    to_english_offline,
    to_meeting_minutes_offline,
    to_polite,
    to_proofread_offline,
    to_reply_generator_offline,
    to_standardize_offline,
    to_summary,
    transform_text,
)


def test_polite() -> None:
    cases = [
        ("明日は雨だ", "明日は雨です"),
        ("昨日打ち合わせをした", "昨日打ち合わせをしました"),
        ("それはできない", " colonial" if False else "それはできません"),
        ("僕も行く", "私もいきます"),
        ("すいません、ちょっと待って", "すみません、少々待ってください"),
        ("確認してくれ", "確認してください"),
        ("これでいい", "これでいいです"),
        ("明日ご飯行こう", "明日ご飯行きましょう"),
        ("めちゃめちゃ長すいたぜ、明日ご飯行こう",
         "めちゃめちゃ長すぎました、明日ご飯行きましょう"),
    ]
    for src, expected in cases:
        out = to_polite(src)
        assert out == expected, f"Expected '{expected}', got '{out}' (src='{src}')"
    print("OK: polite conversion")


def test_business() -> None:
    cases = [
        ("ありがとうございます", "誠にありがとうございます"),
        ("よろしくお願いします", "何卒よろしくお願い申し上げます"),
        ("資料を確認してください", "資料をご確認いただけますと幸いです"),
        ("ファイルを送ってください", "ファイルをご送付いただけますと幸甚に存じます"),
        ("私が言いました", "私が申し上げました"),
    ]
    for src, expected in cases:
        out = to_business(src)
        assert out == expected, f"Expected '{expected}', got '{out}' (src='{src}')"
    print("OK: business conversion")


def test_summary() -> None:
    src = "第一の議題は予算です。第二の議題はスケジュールです。"
    out = to_summary(src)
    assert "・第一の議題は予算です" in out
    assert "・第二の議題はスケジュールです" in out
    print("OK: summary conversion")


def test_offline_english() -> None:
    cases = [
        ("こんにちは", "Hello."),
        ("ありがとうございます", "Thank you very much."),
        ("テストです", "This is a test."),
        ("おはようございます明日は晴れです",
         "Good morning. It will be sunny tomorrow."),
        ("こんにちは、ありがとうございます",
         "Hello. Thank you very much."),
    ]
    for src, expected in cases:
        out = to_english_offline(src)
        assert out == expected, f"Expected '{expected}', got '{out}'"
    print("OK: offline english")


def test_transform_fallback() -> None:
    # offline_mode = True の時やキー未設定時にローカルへ落ちること
    res = transform_text("明日は休みだ", "polite", is_offline=True)
    assert res == "明日は休みです"

    res_none = transform_text("テスト", "none")
    assert res_none == "テスト"

    # slack_report のローカルフォールバック
    res_slack = transform_text("進捗です。機能が完成しました。", "slack_report", is_offline=True)
    assert "【進捗・共有事項】" in res_slack
    assert "機能が完成しました" in res_slack

    # custom は API 必須のため、オフライン・キーなしでは ApiRequiredError
    raised_custom = False
    try:
        transform_text(
            "明日は雨だ", "custom", custom_prompt="敬語に直して", is_offline=True)
    except ApiRequiredError:
        raised_custom = True
    assert raised_custom, "custom action should require API key"

    # レシピ選択メニューから渡される custom_instruction_ 形式のテスト
    res_recipe_polite = transform_text(
        "明日ご飯行こう", "custom_instruction_polite", is_offline=True)
    assert res_recipe_polite == "明日ご飯行きましょう"

    res_recipe_terminal = transform_text(
        "Git のステータス", "custom_instruction_terminal_helper", is_offline=True)
    assert res_recipe_terminal == "git status"

    res_recipe_translate = transform_text(
        "こんにちは", "custom_instruction_translate_en", is_offline=True)
    assert res_recipe_translate == "Hello."

    print("OK: transform fallback")


def test_providers() -> None:
    assert detect_provider("gemini", "", "") == "gemini"
    assert detect_provider("claude", "", "") == "claude"
    assert detect_provider("openrouter", "", "") == "openrouter"
    assert detect_provider("auto", "AIzaSyTestKey", "") == "gemini"
    assert detect_provider("auto", "sk-ant-api-key", "") == "claude"
    assert detect_provider("auto", "sk-or-v1-key", "") == "openrouter"
    # デフォルトフォールバック
    assert detect_provider("auto", "other-key", "claude-3-opus") == "claude"
    assert detect_provider("auto", "other-key", "openai/gpt-4o") == "openrouter"
    assert detect_provider("auto", "other-key", "") == "gemini"
    print("OK: provider detection")


def test_api_required() -> None:
    # prompt_creator は API キーが必須（ローカル変換せずエラーを起こす）
    raised = False
    try:
        transform_text("バグ修正の依頼文", "prompt_creator", is_offline=True)
    except ApiRequiredError:
        raised = True
    assert raised, "prompt_creator should raise ApiRequiredError without API"

    # レシピからの custom_instruction_prompt_creator も同様
    raised = False
    try:
        transform_text("要件定義書", "custom_instruction_prompt_creator",
                       is_offline=True)
    except ApiRequiredError:
        raised = True
    assert raised, "custom prompt_creator should raise ApiRequiredError"

    # instruct も API キーが必須（ローカル変換せずエラーを起こす）
    raised = False
    try:
        transform_text("体調不良の欠勤連絡を作って", "instruct",
                       is_offline=True)
    except ApiRequiredError:
        raised = True
    assert raised, "instruct should raise ApiRequiredError without API"

    # レシピからの custom_instruction_instruct も同様
    raised = False
    try:
        transform_text("お詫びのメール", "custom_instruction_instruct",
                       is_offline=True)
    except ApiRequiredError:
        raised = True
    assert raised, "custom instruct should raise ApiRequiredError"

    # ユーザー自作のカスタムプロンプト (API未設定) もエラーになること
    raised = False
    try:
        transform_text("テスト入力", "custom_instruction_my_custom",
                       custom_prompt="語尾にニャンをつけて", is_offline=True)
    except ApiRequiredError:
        raised = True
    assert raised, "User custom instruction should raise ApiRequiredError"

    print("OK: api required error enforcement")


def test_call_llm_mocks() -> None:
    from unittest.mock import MagicMock, patch
    from app.transform import call_claude, call_gemini, call_openrouter

    # Gemini mock
    gemini_resp = {
        "candidates": [{
            "content": {"parts": [{"text": "Hello from Gemini"}]}
        }]
    }
    with patch("urllib.request.urlopen") as mock_url:
        mock_cm = MagicMock()
        mock_cm.read.return_value = json.dumps(gemini_resp).encode("utf-8")
        mock_cm.__enter__.return_value = mock_cm
        mock_url.return_value = mock_cm

        res = call_gemini("hi", api_key="test-key", model="model")
        assert res == "Hello from Gemini"

    # Claude mock
    claude_resp = {
        "content": [{
            "type": "text",
            "text": "Hello from Claude"
        }]
    }
    with patch("urllib.request.urlopen") as mock_url:
        mock_cm = MagicMock()
        mock_cm.read.return_value = json.dumps(claude_resp).encode("utf-8")
        mock_cm.__enter__.return_value = mock_cm
        mock_url.return_value = mock_cm

        res = call_claude("hi", api_key="sk-ant-test", model="claude-3-opus")
        assert res == "Hello from Claude"

    # OpenRouter mock
    openrouter_resp = {
        "choices": [{
            "message": {"content": "Hello from OpenRouter"}
        }]
    }
    with patch("urllib.request.urlopen") as mock_url:
        mock_cm = MagicMock()
        mock_cm.read.return_value = json.dumps(openrouter_resp).encode("utf-8")
        mock_cm.__enter__.return_value = mock_cm
        mock_url.return_value = mock_cm

        res = call_openrouter("hi", api_key="sk-or-test",
                              model="openai/gpt-4o")
        assert res == "Hello from OpenRouter"

    print("OK: llm mock calls")


def test_speaker_focus() -> None:
    import array
    from unittest.mock import patch
    from app.vad import SegmentCutter

    # 1. SegmentCutter の話者フォーカス（音響エネルギー判定）テスト
    # 小さな音（RMS約150）を作成
    low_audio = array.array("h", [150] * 320).tobytes()

    cutter_off = SegmentCutter(
        16000, pause_ms=400, min_speech_ms=100, max_segment_ms=5000,
        preroll_ms=100, tail_ms=100, sensitivity=3.0, floor=100.0,
        speaker_focus="off",
    )
    cutter_strong = SegmentCutter(
        16000, pause_ms=400, min_speech_ms=100, max_segment_ms=5000,
        preroll_ms=100, tail_ms=100, sensitivity=3.0, floor=100.0,
        speaker_focus="strong",
    )

    # off では床が100なので RMS 150 は音声とみなされうる
    cutter_off.feed(low_audio)
    # strong では床が 420 以上に引き上げられるため RMS 150 は完全に無音
    cutter_strong.feed(low_audio)
    assert not cutter_strong.in_speech, "strong focus should suppress low volume"

    # 2. transform_text の話者分離プロンプト付加テスト
    captured_prompts: list[str] = []

    def fake_call_gemini(prompt: str, **kwargs):  # noqa: ANN001, ANN003
        captured_prompts.append(prompt)
        return "Fake Result"

    with patch("app.transform.call_gemini", side_effect=fake_call_gemini):
        # speaker_focus="normal" の場合
        transform_text("テスト発言", "polite", api_key="AIzaSyTest",
                       speaker_focus="normal")
        assert len(captured_prompts) == 1
        assert "話者分離" in captured_prompts[0]

        # speaker_focus="off" の場合
        captured_prompts.clear()
        transform_text("テスト発言", "polite", api_key="AIzaSyTest",
                       speaker_focus="off")
        assert len(captured_prompts) == 1
        assert "話者分離" not in captured_prompts[0]

    print("OK: speaker focus tests")


def test_clean_ai_output() -> None:
    # 1. コードブロックの除去
    assert clean_ai_output("```markdown\nHello World\n```") == "Hello World"
    assert clean_ai_output("```bash\ngit status\n```") == "git status"
    assert clean_ai_output("```\nclear\n```") == "clear"

    # 2. 前置きフレーズの除去
    intro1 = "承知いたしました。\n明日は14時にお伺いします。"
    assert clean_ai_output(intro1) == "明日は14時にお伺いします。"

    intro2 = "はい、作成した文章です：\n明日は晴れの予定です。"
    assert clean_ai_output(intro2) == "明日は晴れの予定です。"

    intro3 = "Here is the translated text:\nGood morning."
    assert clean_ai_output(intro3) == "Good morning."

    # 3. 外側の余計な引用符のストリップ
    assert clean_ai_output('"Hello Koe-type"') == "Hello Koe-type"
    assert clean_ai_output("「了解いたしました。」") == "了解いたしました。"
    assert clean_ai_output("『会議を始めます。』") == "会議を始めます。"

    print("OK: clean_ai_output tests")


def test_clipboard_prompt_macro() -> None:
    tmpl = "返信文を作って:\n【相手】\n{clipboard}\n\n【要望】\n{text}"
    out1 = fill_prompt(tmpl, "了解と返信して",
                       clipboard_text="明日の10時は空いていますか？")
    assert "明日の10時は空いていますか？" in out1
    assert "了解と返信して" in out1

    out2 = fill_prompt(tmpl, "よろしく", clipboard_text="")
    assert "（なし）" in out2
    assert "よろしく" in out2

    print("OK: clipboard prompt macro")


def test_new_recipes_offline() -> None:
    # 1. reply_generator
    rep = to_reply_generator_offline("明日の14時なら大丈夫",
                                     clipboard_text="面談の日程はいかがでしょうか？")
    assert "ご連絡ありがとうございます" in rep
    assert "明日の14時なら大丈夫です" in rep
    assert "よろしくお願い申し上げます" in rep

    # 2. meeting_minutes
    minutes = to_meeting_minutes_offline(
        "次期バージョンの公開日を11月1日に決定しました。"
        "田中さんがリリースノートの作成を担当します。"
    )
    assert "【決定事項】" in minutes
    assert "公開日を11月1日に決定しました" in minutes
    assert "【ネクストアクション】" in minutes
    assert "リリースノートの作成を担当します" in minutes

    # 3. proofread
    proof = to_proofread_offline(
        "こんにちわ。明日は雨が見れるかも。全然大丈夫です。"
    )
    assert "こんにちは" in proof
    assert "見られる" in proof
    assert "全く問題ありません" in proof

    # 4. standardize
    std = to_standardize_offline("これマジでヤバいじゃん。早く行かなきゃ。")
    assert "本当に" in std
    assert "行かなければなりません" in std

    # 5. brainstorm
    idea = to_brainstorm_offline(
        "音声入力でスマートホームを操作する機能。"
        "照明やエアコンを声だけでオンオフできるようにする。"
    )
    assert "【コアコンセプト】" in idea
    assert "音声入力でスマートホームを操作する機能" in idea
    assert "【具体的な施策・アイデア骨子】" in idea
    assert "照明やエアコンを声だけでオンオフできるようにする" in idea
    assert "【期待される効果・提供価値】" in idea

    # 6. transform_text 経由のフォールバック動作
    res_reply = transform_text(
        "承知しました", "reply_generator", is_offline=True,
        clipboard_text="ご確認をお願いします")
    assert "ご連絡ありがとうございます" in res_reply

    res_minutes = transform_text(
        "来週の会議を火曜日に決定しました", "meeting_minutes", is_offline=True)
    assert "【決定事項】" in res_minutes

    res_proof = transform_text(
        "こんにちわ", "proofread", is_offline=True)
    assert res_proof == "こんにちは"

    res_std = transform_text(
        "これマジでいいじゃん", "standardize", is_offline=True)
    assert "本当に" in res_std

    res_idea = transform_text(
        "新しいAIメモアプリの企画", "brainstorm", is_offline=True)
    assert "【コアコンセプト】" in res_idea

    print("OK: new recipes offline tests")


def test_expanded_polite_and_business() -> None:
    # 敬語の追加ルール検証
    assert to_polite("早く行かなきゃ") == "早く行かなければなりません"
    assert to_polite("明日は休みかも") == "明日は休みかもしれません"
    assert to_polite("明日行きたいな") == "明日行きたいです"
    assert to_polite("マジでやばい") == "本当に大変です"

    # ビジネス敬語の追加ルール検証
    b1 = to_business("明日の件、わかりました")
    assert "承知いたしました" in b1
    b2 = to_business("質問があります")
    assert "ご質問させていただきたく存じます" in b2
    b3 = to_business("日程はどうですか")
    assert "いかがでしょうか" in b3

    print("OK: expanded polite and business tests")


def main() -> None:
    test_polite()
    test_business()
    test_summary()
    test_offline_english()
    test_transform_fallback()
    test_providers()
    test_api_required()
    test_call_llm_mocks()
    test_speaker_focus()
    test_clean_ai_output()
    test_clipboard_prompt_macro()
    test_new_recipes_offline()
    test_expanded_polite_and_business()
    print("\nALL TRANSFORM TESTS PASSED!")


if __name__ == "__main__":
    main()
