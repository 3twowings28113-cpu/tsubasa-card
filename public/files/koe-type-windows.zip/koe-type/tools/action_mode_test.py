"""特定動作（アクションモード：長押し／専用キー）の動作検証テスト。

最優先ルール厳守：
  ・KOE_TYPE_DRY_RUN=1 で実行し、実際のキーストローク・クリックを行わない。
  ・スピーカーから音声を流さない。
  ・使い捨ての一時ディレクトリを KOE_TYPE_HOME に指定する。
"""

import os
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# テスト用の環境変数を先にセット
TEST_DIR = Path(tempfile.mkdtemp(prefix="koe_type_action_test_"))
os.environ["KOE_TYPE_HOME"] = str(TEST_DIR)
os.environ["KOE_TYPE_DRY_RUN"] = "1"

from app.audio import SAMPLE_RATE
from app.configstore import Config
from app.main import ACTION, Controller
from app import dryrun


class ActionModeTest(unittest.TestCase):
    def setUp(self) -> None:
        self.ctrl = Controller.__new__(Controller)
        self.ctrl.cfg = Config()
        self.ctrl.cfg.set("long_press_action", "polite")
        self.ctrl.cfg.set("action_mode", "translate_en")
        self.ctrl.session = 0
        self.ctrl.utterance = 0
        self.ctrl.agreement = MagicMock()
        self.ctrl._stop = MagicMock()
        self.ctrl._stop.is_set.return_value = True
        self.ctrl.recording = False
        self.ctrl.stopping = False
        self.ctrl.pending = 0
        self.ctrl.cancelled = set()
        self.ctrl._current_action = ""
        self.ctrl._action_pcm = bytearray()
        self.ctrl._action_sessions = set()
        self.ctrl._long_press_promoted = False
        self.ctrl._lock = MagicMock()
        self.ctrl._lock.__enter__.return_value = None
        self.ctrl._lock.__exit__.return_value = None
        self.ctrl._agree_lock = MagicMock()
        self.ctrl.win = MagicMock()
        self.ctrl.mouse = MagicMock()
        self.ctrl.overlay = MagicMock()
        self.ctrl.recorder = MagicMock()
        self.ctrl.cutter = MagicMock()
        self.ctrl.engine = MagicMock()
        self.ctrl._work = MagicMock()
        self.ctrl._notify = MagicMock()
        self.ctrl._play_sound = MagicMock()
        self.ctrl._tray_state = MagicMock()
        self.ctrl._apply_audio_ducking = MagicMock()
        self.ctrl._restore_audio = MagicMock()
        self.ctrl._join_stream = MagicMock()
        self.ctrl._force_idle = MagicMock()

    def tearDown(self) -> None:
        pass

    def test_long_press_promotion_and_release(self) -> None:
        """起動キー長押しでアクションモードに昇格し、離して停止する。"""
        # 1. 録音開始（通常モード）
        self.ctrl._start_recording()
        self.assertTrue(self.ctrl.recording)
        self.assertEqual(self.ctrl._current_action, "")
        self.assertFalse(self.ctrl._long_press_promoted)

        # 2. 0.6 秒経過し長押し検知が届く
        self.ctrl._on_long_press(0.6)
        self.assertEqual(self.ctrl._current_action, "polite")
        self.assertTrue(self.ctrl._long_press_promoted)
        self.assertIn(self.ctrl.session, self.ctrl._action_sessions)

        # 3. アクション中は同時文字起こし（入力欄への途中入力）が無効化
        self.assertFalse(self.ctrl._types_while_speaking())

        # 4. 音声データが届く
        fake_pcm = b"\x00\x00" * int(SAMPLE_RATE * 0.5)
        self.ctrl._on_audio(fake_pcm)
        self.assertEqual(len(self.ctrl._action_pcm), len(fake_pcm))

        # 5. キーを離す（_hotkey_up）
        with patch.object(self.ctrl, "_stop_recording") as mock_stop:
            self.ctrl._hotkey_up(0.6)
            mock_stop.assert_called_once_with(submit=False)

    def test_dedicated_action_hotkey(self) -> None:
        """専用アクションキーで直接アクションモードで起動する。"""
        self.ctrl._action_down()
        self.assertTrue(self.ctrl.recording)
        self.assertEqual(self.ctrl._current_action, "translate_en")
        self.assertIn(self.ctrl.session, self.ctrl._action_sessions)

        # 再度押すと停止する
        with patch.object(self.ctrl, "_stop_recording") as mock_stop:
            self.ctrl._action_down()
            mock_stop.assert_called_once_with(submit=False)

    def test_stop_recording_enqueues_action(self) -> None:
        """アクションモード終了時に ACTION ジョブがエンキューされる。"""
        self.ctrl._start_recording(action="summary")
        fake_pcm = b"\x01\x00" * int(SAMPLE_RATE * 1.0)
        self.ctrl._on_audio(fake_pcm)

        self.ctrl._stop_recording(submit=False)
        self.assertFalse(self.ctrl.recording)

        # _work に ACTION が積まれたことを確認
        found_action = False
        for call_args in self.ctrl._work.put.call_args_list:
            item = call_args[0][0]
            if item[0] is ACTION:
                found_action = True
                self.assertEqual(item[1][0], "summary")
                self.assertEqual(item[1][1], bytes(fake_pcm))
                break
        self.assertTrue(found_action, "ACTION ジョブが積まれていません")

    def test_handle_action_execution(self) -> None:
        """_handle_action で変換が適用されて一括入力される。"""
        fake_pcm = b"\x00\x00" * int(SAMPLE_RATE * 1.0)
        self.ctrl._transcribe = MagicMock(return_value="今日はいい天気だ")
        self.ctrl._type = MagicMock()
        self.ctrl._spill = MagicMock(return_value=False)
        self.ctrl._remember = MagicMock()

        self.ctrl._handle_action("polite", fake_pcm, session=1)

        # "今日はいい天気だ" が敬語 "今日はいい天気です" に変換されて入力
        self.ctrl._type.assert_called_once()
        typed_text = self.ctrl._type.call_args[0][0]
        self.assertEqual(typed_text, "今日はいい天気です")


if __name__ == "__main__":
    try:
        unittest.main(verbosity=2)
    finally:
        shutil.rmtree(TEST_DIR, ignore_errors=True)
