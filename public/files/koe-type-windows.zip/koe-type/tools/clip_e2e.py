r"""クリップボード履歴を、アプリ本体ごと端から端まで動かす。

本物のキーもクリップボードも使わない（から打ちモード・台本で内側から操作）。
画面にも何も出さない（帯・トレイを切り、一覧の窓は から打ちでは出ない）。

  python tools\clip_e2e.py

確かめること
  ・本体（main.Controller）からクリップボード履歴が動き出す
  ・コピーした扱いのもの → 一覧 → ↓ → Enter で、貼るはずの中身が記録される
  ・同じショートカットをもう一度押すと、次のグループに替わる
  ・ログに例外が出ていない
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from tools.mock_e2e import make_home, run_app  # noqa: E402

ok_count = 0
fail_count = 0


def check(label: str, good: bool, detail: str = "") -> None:
    global ok_count, fail_count
    if good:
        ok_count += 1
        print(f"  OK   {label}")
    else:
        fail_count += 1
        print(f"  NG   {label} {detail}")


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="koe-type-clip-e2e-"))
    home = make_home(tmp, {"guardian": False})
    shot = home / "logs" / "clip.png"
    script = [
        {"at": 1.5, "event": "clip_capture", "text": "最初のコピー",
         "app": "notepad.exe"},
        {"at": 1.8, "event": "clip_capture", "text": "二番目のコピー",
         "app": "chrome.exe"},
        {"at": 2.6, "event": "clip_open", "target": 777},
        {"at": 2.9, "event": "clip_key", "vk": 0x28},          # ↓
        {"at": 3.2, "event": "clip_key", "vk": 0x0D},          # Enter
        {"at": 4.0, "event": "clip_open", "target": 777},
        {"at": 4.3, "event": "clip_hotkey"},                   # 次のグループ
        {"at": 4.6, "event": "clip_type", "text": "zzz"},
        {"at": 4.9, "event": "clip_snapshot", "path": str(shot)},
        {"at": 5.6, "event": "clip_key", "vk": 0x1B},          # 検索を消す
        {"at": 5.8, "event": "clip_key", "vk": 0x1B},          # 閉じる
        {"at": 7.0, "event": "quit"},
    ]
    print("[本体ごと動かす（から打ち）]")
    result = run_app(home, Path("unused.wav"), script, timeout=120.0,
                     fake_mic=False)
    entries = result["entries"]
    kinds = [e.get("kind") for e in entries]
    check("アプリが終わった", result["rc"] == 0, f"rc={result['rc']}")
    shows = [e for e in entries if e.get("kind") == "clip_show"]
    check("一覧が開いた（2 回）", len(shows) == 2, str(shows))
    check("開いたときに 2 件ある", bool(shows) and shows[0].get("items") == 2,
          str(shows[:1]))
    pastes = [e for e in entries if e.get("kind") == "clip_paste"]
    check("↓ → Enter で 2 番目（古いほう）を貼る",
          [p.get("text") for p in pastes] == ["最初のコピー"], str(pastes))
    check("貼るキーは記録だけ（から打ち）", "paste_keys" in kinds, str(kinds))
    check("窓の絵を画像にできた", shot.exists())
    log_text = result["app_log"].read_text("utf-8", "replace") \
        if result["app_log"].exists() else ""
    check("クリップボード履歴が動き出した", "クリップボード履歴を用意しました"
          in log_text)
    clip_errors = [line for line in log_text.splitlines()
                   if "例外" in line and ("clip" in line or "クリップ" in line)]
    check("クリップボードまわりで例外が出ていない", not clip_errors,
          "\n".join(clip_errors[:5]))
    print(f"\n==== 成功 {ok_count} / 失敗 {fail_count} ====")
    if fail_count:
        print(json.dumps(entries[-20:], ensure_ascii=False, indent=1))
    return 1 if fail_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
