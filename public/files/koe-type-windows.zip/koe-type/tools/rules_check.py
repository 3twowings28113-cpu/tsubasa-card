"""`AGENTS.md` と `CLAUDE.md` がそろっているか確かめる。

同じ作業ルールを 2 つのファイルに置いている。

| ファイル | 読むもの |
|---|---|
| `AGENTS.md` | Antigravity（Gemini） |
| `CLAUDE.md` | Claude Code |

**片方だけ直すと、もう片方の AI が古いルールで動く。**
それがいちばん危ない（「本物のキーを送らない」が消えた版を読む、など）。
だからコミット前にここで確かめる。

違うのは**冒頭の案内 5 行だけ**。それより下は 1 文字も違ってはいけない。

    python tools/rules_check.py          # 確かめる
    python tools/rules_check.py --fix    # AGENTS.md に合わせて CLAUDE.md を直す
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

AGENTS = ROOT / "AGENTS.md"
CLAUDE = ROOT / "CLAUDE.md"

# 冒頭の案内。ここだけは、相手のファイル名が入れ替わる。
HEAD_AGENTS = """# koe-type の作業ルール

> **このファイルと `CLAUDE.md` は同じ内容です。**
> Antigravity（Gemini）は `AGENTS.md` を、Claude Code は `CLAUDE.md` を読みます。
> **どちらかを直したら、必ずもう片方もそろえてください。**
> ずれていないかは `python tools/rules_check.py` で確かめられます。
"""

HEAD_CLAUDE = """# koe-type の作業ルール

> **このファイルと `AGENTS.md` は同じ内容です。**
> Claude Code は `CLAUDE.md` を、Antigravity（Gemini）は `AGENTS.md` を読みます。
> **どちらかを直したら、必ずもう片方もそろえてください。**
> ずれていないかは `python tools/rules_check.py` で確かめられます。
"""


def body_of(path: Path, head: str) -> str | None:
    """冒頭の案内を取り除いた本文。案内が違っていれば None。"""
    text = path.read_text("utf-8").replace("\r\n", "\n")
    if not text.startswith(head):
        return None
    return text[len(head):]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--fix", action="store_true",
                    help="AGENTS.md に合わせて CLAUDE.md を書き直す")
    args = ap.parse_args()

    print("=" * 66)
    print(" 作業ルールの 2 つのファイルがそろっているか")
    print("=" * 66)

    problems = []
    for path in (AGENTS, CLAUDE):
        if not path.is_file():
            problems.append(f"{path.name} がありません")
    if problems:
        for text in problems:
            print(f"  NG   {text}")
        return 1

    agents_body = body_of(AGENTS, HEAD_AGENTS)
    claude_body = body_of(CLAUDE, HEAD_CLAUDE)

    if agents_body is None:
        print("  NG   AGENTS.md の冒頭の案内が、決めた形と違います")
        print("       （tools/rules_check.py の HEAD_AGENTS を見てください）")
        return 1

    if args.fix:
        CLAUDE.write_text(HEAD_CLAUDE + agents_body, "utf-8")
        print("  AGENTS.md に合わせて CLAUDE.md を書き直しました")
        claude_body = agents_body

    if claude_body is None:
        print("  NG   CLAUDE.md の冒頭の案内が、決めた形と違います")
        print("       `python tools/rules_check.py --fix` で直せます")
        return 1

    if agents_body != claude_body:
        print("  NG   本文が違います")
        a = agents_body.splitlines()
        c = claude_body.splitlines()
        for i in range(max(len(a), len(c))):
            left = a[i] if i < len(a) else "（無し）"
            right = c[i] if i < len(c) else "（無し）"
            if left != right:
                print(f"       {i + 1} 行目")
                print(f"         AGENTS.md: {left[:70]}")
                print(f"         CLAUDE.md: {right[:70]}")
                break
        print("\n  `python tools/rules_check.py --fix` で、"
              "AGENTS.md に合わせられます。")
        return 1

    lines = len(agents_body.splitlines())
    print(f"  OK   本文 {lines} 行が完全に同じです")

    # 中身の最低限（消えていたら困るもの）
    must = [
        ("本物のキーを送らない", "実際のキー送信・貼り付け・クリックを一切しない"),
        ("スピーカーを使わない", "スピーカーから音声を流さない"),
        ("常駐を壊さない", "常駐しているアプリを壊さない"),
        ("GitHubへpushする", "コミット時は GitHub へ常に push して最新状態を維持する"),
        ("管理者権限を使わない", "管理者権限（UAC）が必要な操作はしない"),
        ("pip を足さない", "pip パッケージを足さない"),
        ("低レベルのフックを使わない", "低レベルのフック"),
        ("そろえる決まり", "必ずもう片方もそろえて"),
    ]
    ng = 0
    for label, needle in must:
        both = needle in AGENTS.read_text("utf-8") and \
            needle in CLAUDE.read_text("utf-8")
        print(f"  {'OK  ' if both else 'NG  '} {label}")
        if not both:
            ng += 1

    print("=" * 66)
    return 1 if ng else 0


if __name__ == "__main__":
    raise SystemExit(main())
