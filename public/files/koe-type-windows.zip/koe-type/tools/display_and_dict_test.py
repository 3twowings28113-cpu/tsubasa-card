"""表示（オーバーレイ新デザイン・プレビュー・サイズ位置）および辞書機能の自動テスト。"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_sandbox = Path(tempfile.mkdtemp(prefix="koe-type-test-disp-"))
(_sandbox / "logs").mkdir()
(_sandbox / "data").mkdir()
os.environ["KOE_TYPE_HOME"] = str(_sandbox)
os.environ["KOE_TYPE_DRY_RUN"] = "1"
os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

from app import overlay as ov
from app import schema
from app.configstore import Config
from app.textproc import Dictionary
from app.websettings import Bridge

ok_count = 0


def check(desc: str, cond: bool) -> None:
    global ok_count
    if not cond:
        print(f"  FAIL: {desc}")
        sys.exit(1)
    print(f"  OK   {desc}")
    ok_count += 1


def main() -> int:
    print("=" * 66)
    print(" 表示（オーバーレイ）＆辞書機能 総合テスト")
    print("=" * 66)

    # 1. オーバーレイデザインの定義
    print("\n[1 オーバーレイデザインと設定項目]")
    check("DESIGNSに5種類ある", len(ov.DESIGNS) == 5)
    for d in ("pill", "wave", "card", "dot", "caption"):
        check(f"デザイン '{d}' が存在する", d in ov.DESIGNS)

    design_item = schema.find("overlay_design")
    check("overlay_design が存在する", design_item is not None)
    opts = [o.value for o in design_item.options]
    check("overlay_design の選択肢に dot がある", "dot" in opts)
    check("overlay_design の選択肢に caption がある", "caption" in opts)

    size_item = schema.find("overlay_size")
    check("overlay_size が基本設定（advanced=False）である",
          not size_item.advanced)

    pos_item = schema.find("overlay_position")
    check("overlay_position が基本設定（advanced=False）である",
          not pos_item.advanced)

    # 2. レンダリングの健全性（GDI+ でエラーなく生成されるか）
    print("\n[2 新デザイン（dot, caption）の描画検証]")
    check("GDI+ 起動", ov._start_gdiplus())
    bar = ov.Overlay()
    bar._animate = False

    for d in ("dot", "caption"):
        bar.configure(theme_name="dark", position="bottom", size="medium",
                      margin_px=16, enabled=True, design=d)
        bar.set_state("recording", elapsed=4.2, level=0.6,
                      pending="テストテキストです")
        rendered = bar._render()
        check(f"{d} の _render が None でない", rendered is not None)
        w, h = rendered[0], rendered[1]
        check(f"{d} の width が整数である ({w})", isinstance(w, int))
        check(f"{d} の height が整数である ({h})", isinstance(h, int))
        check(f"{d} の width が正である", w > 50)
        check(f"{d} の height が正である", h > 20)

    # 3. 辞書の初期化とスターター単語パック
    print("\n[3 ユーザー辞書・定番AI単語パック]")
    dict_file = _sandbox / "dictionary.txt"
    dictionary = Dictionary(dict_file)

    sample_path = ROOT / "dictionary.sample.txt"
    check("dictionary.sample.txt が存在する", sample_path.exists())
    sample_text = sample_path.read_text("utf-8")
    for keyword in ("ChatGPT", "Claude", "Gemini", "Gmail", "Slack",
                    "Discord", "よろしくお願いいたします"):
        check(f"sample に '{keyword}' が含まれる", keyword in sample_text)

    cfg = Config(_sandbox / "config.json")
    actions_called = []
    bridge = Bridge(cfg, dictionary, None,
                    lambda name, **kw: actions_called.append(name))

    # add_starter_words アクション
    res = bridge.run_action("add_starter_words", {})
    check("add_starter_words アクション成功", res.get("ok") is True)
    added = res.get("added", 0)
    check("単語が追加された (>0)", added > 0)
    check("dictionary_changed アクションが呼ばれた",
          "dictionary_changed" in actions_called)

    # もう一度実行したら重複が追加されないこと
    res2 = bridge.run_action("add_starter_words", {})
    check("二重追加されない（added=0）", res2.get("added") == 0)

    # test_overlay アクション
    actions_called.clear()
    res_ov = bridge.run_action("test_overlay", {})
    check("test_overlay アクション成功", res_ov.get("ok") is True)
    check("本体の test_overlay が呼ばれた", "test_overlay" in actions_called)

    # 4. 辞書置換の動作検証
    print("\n[4 辞書適用の検証]")
    check("ジーメールが Gmail に置換される",
          dictionary.apply("ジーメールを確認") == "Gmailを確認")
    check("チャットGPTが ChatGPT に置換される",
          dictionary.apply("チャットGPTに聞く") == "ChatGPTに聞く")
    check("スラックが Slack に置換される",
          dictionary.apply("スラックで送る") == "Slackで送る")

    print("\n" + "=" * 66)
    print(f" 全テスト成功！ ({ok_count} 項目合格)")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
