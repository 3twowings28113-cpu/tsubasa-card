r"""ユーザー辞書適用による CER（文字誤り率）の改善効果を検証するスクリプト。"""
import json
from pathlib import Path
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app.textproc import Dictionary, to_hiragana

def cer(ref: str, got: str) -> float:
    # 記号を除去した文字誤り率
    ignore = set("、。，．！？!?,. 　\t\n")
    r = [c for c in ref if c not in ignore]
    g = [c for c in got if c not in ignore]
    if not r:
        return 0.0 if not g else 1.0
    prev = list(range(len(g) + 1))
    for i, rc in enumerate(r, 1):
        curr = [i] * (len(g) + 1)
        for j, gc in enumerate(g, 1):
            cost = 0 if rc == gc else 1
            curr[j] = min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost)
        prev = curr
    return prev[-1] / len(r)

def main():
    truth_path = ROOT / "bench" / "private" / "audio_truth.json"
    results_path = ROOT / "bench" / "private" / "results.json"
    if not truth_path.exists() or not results_path.exists():
        print("ベンチマークデータが見つかりません。")
        return

    truth = json.loads(truth_path.read_text("utf-8"))
    results = json.loads(results_path.read_text("utf-8"))

    # テスト用辞書の作成（表記と読みを登録）
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        dp = Path(tmp) / "dict.txt"
        dp.write_text(
            "# 専門用語辞書\n"
            "オープンLabo:おーぷんらぼ\n"
            "BizStyle:みらいすたいる\n"
            "オープンEXPO:きょうそうえきすぽ\n"
            "TechVation:すちゅべーしょん\n"
            "Claude Code:くろーどこーど\n"
            "ChatGPT:ちゃっとじーぴーてぃー\n"
            "Gemini:じぇみに\n"
            "MeetingNotes:かいぎのーつ\n"
            "LinkedIn:りんくどいん\n"
            "GitHub:ぎっとはぶ\n",
            encoding="utf-8"
        )
        d = Dictionary(dp)

        print("=" * 60)
        print(" 専門用語（j01〜j08）における辞書適用前後の CER 比較")
        print("=" * 60)

        # モデルごとの結果を比較
        for model_name, data in results.items():
            if not model_name.startswith("sensevoice"):
                continue
            rows = data.get("rows", [])
            j_rows = [r for r in rows if r["id"].startswith("j")]
            if not j_rows:
                continue

            print(f"\nモデル: {model_name}")
            cer_before_list = []
            cer_after_list = []

            for r in j_rows:
                qid = r["id"]
                ref = truth.get(qid, "")
                orig_got = r["text"]
                dict_got = d.apply(orig_got)

                c_before = cer(ref, orig_got)
                c_after = cer(ref, dict_got)
                cer_before_list.append(c_before)
                cer_after_list.append(c_after)

                if c_before != c_after:
                    print(f"  [{qid}]")
                    print(f"    正解: {ref}")
                    print(f"    元  : {orig_got} (CER {c_before*100:.1f}%)")
                    print(f"    辞書: {dict_got} (CER {c_after*100:.1f}%)")

            avg_before = sum(cer_before_list) / len(cer_before_list) * 100
            avg_after = sum(cer_after_list) / len(cer_after_list) * 100
            print(f"\n  >> 平均 CER: {avg_before:.2f}%  ->  {avg_after:.2f}%  (改善: {avg_before - avg_after:+.2f}%)")

if __name__ == "__main__":
    main()
