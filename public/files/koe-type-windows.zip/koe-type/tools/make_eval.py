"""評価用の音声をそろえる。スピーカーは使わない（ファイルだけ）。

作るもの
  1. 雑音を混ぜた版（SN比 20 / 10 / 5 dB）。雑音はその場で作る。
     ・ピンクノイズ（空調・ざわめきに近い）
     ・カフェのような話し声（複数の帯域の変調ノイズ）
     ・キーボードの打鍵（短い衝撃音の連打）
  2. IT 用語の文（Windows の読み上げ声で作る。**ファイルへ書き出す**）
  3. 無音と、雑音だけの音（1文字も出さないことの確認用）

    python tools/make_eval.py            # 全部
    python tools/make_eval.py --noise    # 雑音混ぜだけ
    python tools/make_eval.py --list     # できているものを数える

できたものは bench/eval/ に置く（個人データ扱いで .gitignore する）。
"""

from __future__ import annotations

import argparse
import array
import json
import math
import random
import subprocess
import sys
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

AUDIO = ROOT / "bench" / "audio"
PRIVATE = ROOT / "bench" / "private"
OUT = ROOT / "bench" / "eval"
RATE = 16000

# IT の仕事でよく出る言い方。固有名詞と、数字・否定・時刻を混ぜてある。
IT_SENTENCES = {
    "t01": "プルリクエストのレビューをお願いします。",
    "t02": "本番環境へのデプロイは十五時からです。",
    "t03": "このエラーはnullポインタ参照が原因でした。",
    "t04": "ブランチをマージする前にテストを通してください。",
    "t05": "APIのレスポンスが五百ミリ秒を超えています。",
    "t06": "ログにスタックトレースが出ていませんでした。",
    "t07": "依存ライブラリのバージョンを上げる必要はありません。",
    "t08": "データベースのマイグレーションは済んでいます。",
    "t09": "キャッシュを消してから再度ビルドしてください。",
    "t10": "この変更はリリースノートに書かなくていいです。",
    "t11": "認証トークンの有効期限は二十四時間です。",
    "t12": "コンテナのメモリ上限を二ギガバイトに増やしました。",
    "t13": "サーバーの再起動は行っていません。",
    "t14": "設定ファイルの文字コードはUTF-8にしてください。",
    "t15": "クエリの実行計画を見たらインデックスが効いていませんでした。",
    "t16": "この機能は次のスプリントに回します。",
}


# ---------------------------------------------------------------- 音の道具


def read_wav(path: Path) -> array.array:
    with wave.open(str(path)) as w:
        if (w.getframerate(), w.getnchannels(), w.getsampwidth()) != (RATE, 1, 2):
            raise ValueError(f"16kHz/モノラル/16bit ではありません: {path.name}")
        a = array.array("h")
        a.frombytes(w.readframes(w.getnframes()))
        return a


def write_wav(path: Path, samples: array.array) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(samples.tobytes())


def rms(samples) -> float:  # noqa: ANN001
    if not len(samples):
        return 0.0
    total = 0
    for s in samples:
        total += s * s
    return math.sqrt(total / len(samples))


def speech_rms(samples: array.array, frame: int = 320) -> float:
    """話している所だけの大きさ。無音を混ぜて測ると SN比がずれるため。"""
    levels = []
    for i in range(0, len(samples) - frame, frame):
        levels.append(rms(samples[i:i + frame]))
    if not levels:
        return rms(samples)
    levels.sort()
    # 上位 3 割の平均を「声の大きさ」とみなす
    top = levels[int(len(levels) * 0.7):]
    return sum(top) / len(top) if top else rms(samples)


# ---------------------------------------------------------------- 雑音


def pink_noise(n: int, seed: int = 1) -> array.array:
    """ピンクノイズ。空調やざわめきに近い、低い方が強い雑音。"""
    rng = random.Random(seed)
    out = array.array("h", bytes(2 * n))
    # Voss-McCartney の簡易版
    rows = 8
    values = [rng.uniform(-1, 1) for _ in range(rows)]
    total = sum(values)
    for i in range(n):
        counter = i
        for row in range(rows):
            if counter & 1:
                total -= values[row]
                values[row] = rng.uniform(-1, 1)
                total += values[row]
                break
            counter >>= 1
        out[i] = max(-32768, min(32767, int(total / rows * 12000)))
    return out


def babble_noise(n: int, seed: int = 2) -> array.array:
    """カフェのような話し声。いくつかの帯域を揺らして重ねる。"""
    rng = random.Random(seed)
    out = array.array("h", bytes(2 * n))
    voices = [(rng.uniform(180, 320), rng.uniform(2.0, 5.5), rng.uniform(0, 6))
              for _ in range(6)]
    for i in range(n):
        t = i / RATE
        value = 0.0
        for base, mod, phase in voices:
            env = 0.5 + 0.5 * math.sin(2 * math.pi * mod * t + phase)
            value += env * math.sin(2 * math.pi * base * t + phase) \
                * (0.6 + 0.4 * rng.random())
        out[i] = max(-32768, min(32767, int(value / len(voices) * 9000)))
    return out


def keyboard_noise(n: int, seed: int = 3) -> array.array:
    """キーボードの打鍵。短い衝撃音を不規則に並べる。"""
    rng = random.Random(seed)
    out = array.array("h", bytes(2 * n))
    i = 0
    while i < n:
        gap = int(rng.uniform(0.06, 0.22) * RATE)
        i += gap
        length = int(rng.uniform(0.004, 0.012) * RATE)
        amp = rng.uniform(0.4, 1.0)
        for k in range(length):
            if i + k >= n:
                break
            decay = math.exp(-k / (length * 0.35))
            out[i + k] = max(-32768, min(32767,
                                         int(rng.uniform(-1, 1) * decay
                                             * amp * 16000)))
        i += length
    return out


NOISES = {"pink": pink_noise, "babble": babble_noise, "keys": keyboard_noise}


def mix(speech: array.array, noise: array.array, snr_db: float) -> array.array:
    """SN比を指定して混ぜる。声の大きさは変えない（雑音側を合わせる）。"""
    s = speech_rms(speech) or 1.0
    want = s / (10 ** (snr_db / 20.0))
    have = rms(noise) or 1.0
    gain = want / have
    out = array.array("h", bytes(2 * len(speech)))
    for i, value in enumerate(speech):
        mixed = value + noise[i % len(noise)] * gain
        out[i] = max(-32768, min(32767, int(mixed)))
    return out


# ---------------------------------------------------------------- 作る


def make_noise_set() -> dict:
    truth_path = PRIVATE / "audio_truth.json"
    truth = json.loads(truth_path.read_text("utf-8")) if truth_path.exists() else {}
    made: dict[str, str] = {}
    sources = sorted(AUDIO.glob("[pj]*.wav"))
    if not sources:
        print("  bench/audio に元の音声がありません")
        return made
    print(f"  元の音声 {len(sources)} 本 × 雑音 3 種 × SN比 3 段")
    cache: dict[tuple[str, int], array.array] = {}
    for src in sources:
        speech = read_wav(src)
        for kind, fn in NOISES.items():
            key = (kind, len(speech))
            if key not in cache:
                cache[key] = fn(max(len(speech), RATE * 3))
            for snr in (20, 10, 5):
                name = f"{src.stem}_{kind}{snr}"
                write_wav(OUT / f"{name}.wav", mix(speech, cache[key], snr))
                if src.stem in truth:
                    made[name] = truth[src.stem]
    print(f"  雑音入り {len(list(OUT.glob('*_*.wav')))} 本")
    return made


def make_silence_set() -> None:
    """無音と、雑音だけの音。1文字も出さないことの確認用。"""
    write_wav(OUT / "quiet_silence.wav", array.array("h", bytes(2 * RATE * 5)))
    for kind, fn in NOISES.items():
        noise = fn(RATE * 5)
        # 人の声と同じくらいの大きさにする（これでも何も出ないのが正しい）
        loud = array.array("h", (max(-32768, min(32767, int(v * 1.8)))
                                 for v in noise))
        write_wav(OUT / f"quiet_{kind}.wav", loud)
    print(f"  無音・雑音だけ {len(list(OUT.glob('quiet_*.wav')))} 本")


def make_it_set() -> dict:
    """IT 用語の文を Windows の読み上げ声で作る（ファイルへ書き出す）。"""
    OUT.mkdir(parents=True, exist_ok=True)
    payload = OUT / "_it.json"
    payload.write_text(json.dumps(IT_SENTENCES, ensure_ascii=False), "utf-8")
    script = r'''
$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Speech
$outDir = $args[0]
$truth = ConvertFrom-Json (Get-Content -Raw -Encoding UTF8 $args[1])
$fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(16000, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
foreach ($p in $truth.PSObject.Properties) {
  $path = Join-Path $outDir ($p.Name + ".wav")
  $s = New-Object System.Speech.Synthesis.SpeechSynthesizer
  try { $s.SelectVoice("Microsoft Haruka Desktop") } catch { }
  $s.SetOutputToWaveFile($path, $fmt)
  $s.Speak($p.Value)
  $s.Dispose()
}
Write-Output "ok"
'''
    ps1 = OUT / "_make_it.ps1"
    ps1.write_text(script, "utf-8")
    proc = subprocess.run(  # noqa: S603
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
         "-File", str(ps1), str(OUT), str(payload)],
        capture_output=True, text=True, encoding="utf-8", errors="replace")
    ps1.unlink(missing_ok=True)
    payload.unlink(missing_ok=True)
    if "ok" not in (proc.stdout or ""):
        print("  読み上げ声で作れませんでした:", (proc.stderr or "")[:200])
        return {}
    print(f"  IT 用語の文 {len(IT_SENTENCES)} 本")
    return dict(IT_SENTENCES)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--noise", action="store_true", help="雑音混ぜだけ")
    ap.add_argument("--it", action="store_true", help="IT 用語の文だけ")
    ap.add_argument("--list", action="store_true", help="数えるだけ")
    args = ap.parse_args()

    if args.list:
        files = sorted(OUT.glob("*.wav"))
        print(f"bench/eval: {len(files)} 本")
        groups: dict[str, int] = {}
        for f in files:
            key = ("雑音入り" if "_" in f.stem and not f.stem.startswith("quiet")
                   else "無音・雑音" if f.stem.startswith("quiet") else "その他")
            groups[key] = groups.get(key, 0) + 1
        for k, v in groups.items():
            print(f"  {k}: {v}")
        truth = OUT / "truth.json"
        if truth.exists():
            print(f"  正解テキスト: {len(json.loads(truth.read_text('utf-8')))} 件")
        return 0

    OUT.mkdir(parents=True, exist_ok=True)
    all_truth: dict[str, str] = {}
    existing = OUT / "truth.json"
    if existing.exists():
        all_truth.update(json.loads(existing.read_text("utf-8")))

    do_all = not (args.noise or args.it)
    print("評価用の音声を作ります（スピーカーは使いません）")
    if do_all or args.noise:
        all_truth.update(make_noise_set())
        make_silence_set()
    if do_all or args.it:
        all_truth.update(make_it_set())

    existing.write_text(json.dumps(all_truth, ensure_ascii=False, indent=1),
                        "utf-8")
    print(f"\n正解テキスト {len(all_truth)} 件を bench/eval/truth.json に書きました")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
