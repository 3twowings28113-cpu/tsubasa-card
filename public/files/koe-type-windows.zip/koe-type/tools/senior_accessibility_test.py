"""シニア・アクセシビリティと特殊キー対応、画面柔軟性のテスト。

・文字サイズ設定（標準・大きめ・特大）と帯の特大表示（xlarge）
・ゆっくり話すプリセット（pause_ms 1800ms）
・日本語キーボード専用「無変換」「変換」キーの解釈と表示
・解像度やDPIが異なる環境でのオーバーレイ位置・スケーリングの安定性
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import hotkeys, schema
from app.overlay import SCALES, Overlay


def test_schema_accessibility() -> None:
    # ui_font_size の存在と選択肢
    found_font = False
    for cat in schema.CATEGORIES:
        for grp in cat.groups:
            for item in grp.items:
                if item.key == "ui_font_size":
                    found_font = True
                    opts = [o.value for o in item.options]
                    assert opts == ["normal", "large", "xlarge"], f"bad options: {opts}"
                    assert item.default == "normal", f"bad default: {item.default}"
    assert found_font, "ui_font_size not found in schema"

    # overlay_size に xlarge があること
    found_overlay_size = False
    for cat in schema.CATEGORIES:
        for grp in cat.groups:
            for item in grp.items:
                if item.key == "overlay_size":
                    found_overlay_size = True
                    opts = [o.value for o in item.options]
                    assert "xlarge" in opts, f"xlarge missing from overlay_size: {opts}"
    assert found_overlay_size, "overlay_size not found in schema"

    # pause_ms のプリセットに 1800ms があること
    found_pause = False
    for cat in schema.CATEGORIES:
        for grp in cat.groups:
            for item in grp.items:
                if item.key == "pause_ms":
                    found_pause = True
                    vals = [p.value for p in item.presets]
                    assert 1800 in vals, f"1800ms preset missing in pause_ms: {vals}"
    assert found_pause, "pause_ms not found in schema"
    print("OK: schema accessibility and pause presets")


def test_overlay_scaling() -> None:
    assert "xlarge" in SCALES, "xlarge missing in SCALES"
    assert SCALES["xlarge"] > SCALES["large"], "xlarge should be bigger than large"
    assert SCALES["xlarge"] == 1.48, f"unexpected scale: {SCALES['xlarge']}"

    ov = Overlay()
    ov.configure(
        theme_name="system",
        position="bottom",
        size="xlarge",
        margin_px=20,
        enabled=True,
    )
    assert ov.size_name == "xlarge", f"size_name not xlarge: {ov.size_name}"

    # 不正なサイズが渡されたときにフォールバックすること
    ov.configure(
        theme_name="system",
        position="bottom",
        size="invalid_size_xxx",
        margin_px=20,
        enabled=True,
    )
    assert ov.size_name == "medium", f"fallback failed: {ov.size_name}"
    print("OK: overlay scaling and safe fallback")


def test_japanese_special_hotkeys() -> None:
    # 無変換キー
    vk, mods = hotkeys.parse("muhenkan")
    assert vk == 0x1D, f"bad vk for muhenkan: {vk:#x}"
    assert mods == frozenset(), f"mods should be empty: {mods}"
    assert hotkeys.label("muhenkan", "ja") == "無変換"
    assert hotkeys.label("muhenkan", "en") == "Muhenkan (non-conversion)"

    # 変換キー
    vk, mods = hotkeys.parse("henkan")
    assert vk == 0x1C, f"bad vk for henkan: {vk:#x}"
    assert mods == frozenset()
    assert hotkeys.label("henkan", "ja") == "変換"

    # かなキー
    vk, mods = hotkeys.parse("kana")
    assert vk == 0x15, f"bad vk for kana: {vk:#x}"
    assert hotkeys.label("kana", "ja") == "かな"

    # ぶつかり警告判定（muhenkan は予約キーと衝突しないこと）
    c = hotkeys.conflicts("muhenkan")
    assert not any(sev == "bad" for sev, *rest in c), f"muhenkan should not be bad: {c}"
    print("OK: japanese special hotkeys (muhenkan, henkan, kana)")


def test_dpi_and_resolutions() -> None:
    # Overlayの描画・サイズ測定が落ちないこと
    ov = Overlay()
    ov.configure(
        theme_name="system",
        position="bottom",
        size="xlarge",
        margin_px=16,
        enabled=True,
        design="pill",
    )
    ov.set_state("recording", elapsed=2.5, level=0.5, pending="おじいさんおばあさん向けテスト")
    # 状態の更新と文字列測定がエラーなく動作すること
    assert ov._pending == "おじいさんおばあさん向けテスト"
    assert ov._state == "recording"
    print("OK: high-resolution & DPI overlay state handling")


if __name__ == "__main__":
    test_schema_accessibility()
    test_overlay_scaling()
    test_japanese_special_hotkeys()
    test_dpi_and_resolutions()
    print("\nALL SENIOR ACCESSIBILITY & FLEXIBILITY TESTS PASSED!")
