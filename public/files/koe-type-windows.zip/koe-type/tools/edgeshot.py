"""Edge のヘッドレスでページを画像にする（設定画面・初回の案内・画像づくり）。

画面を撮らないので、画面がロックされていても撮れる。

★2026-10-05 に Edge が裏で更新されてから、`msedge.exe` が**すぐ戻り、
実際の撮影は別のプロセスで続ける**ようになった。戻った直後に画像を
探すと「無い」になり、どの道具も 1 枚も撮れなくなった（画像は少し
遅れてできていた）。そこで

  ・撮る前に古い画像を消す（残っていると「撮れた」と誤解する）
  ・撮影ごとに専用のプロフィールを使う（止まったまま残った
    ヘッドレス Edge に、後の撮影が吸い込まれないように）
  ・戻ったあと、画像ができて大きさが落ち着くまで待つ
"""

from __future__ import annotations

import shutil
import subprocess
import tempfile
import time
from pathlib import Path

WAIT_SECONDS = 40.0


def shoot(edge: Path, url: str, out: Path, width: int, height: int,
          extra: list[str] | None = None) -> bool:
    """url を out（PNG）に撮る。撮れたら True。"""
    out.parent.mkdir(parents=True, exist_ok=True)
    out.unlink(missing_ok=True)
    profile = Path(tempfile.mkdtemp(prefix="koe-type-edge-shot-"))
    args = [str(edge), "--headless=new", f"--screenshot={out}",
            f"--window-size={width},{height}", "--hide-scrollbars",
            "--force-device-scale-factor=1", "--virtual-time-budget=2500",
            "--disable-gpu", "--no-first-run", "--disable-extensions",
            "--disable-sync", f"--user-data-dir={profile}"]
    args += list(extra or [])
    args.append(url)
    try:
        subprocess.run(args, capture_output=True, timeout=90, check=False)
        deadline = time.monotonic() + WAIT_SECONDS
        last = -1
        while time.monotonic() < deadline:
            if out.is_file():
                size = out.stat().st_size
                if size > 0 and size == last:
                    return True       # 書き終わった（大きさが落ち着いた）
                last = size
            time.sleep(0.4)
        return out.is_file() and out.stat().st_size > 0
    except subprocess.TimeoutExpired:
        return False
    finally:
        # 撮影のプロセスが終わるまで、プロフィールは消せないことがある
        shutil.rmtree(profile, ignore_errors=True)
