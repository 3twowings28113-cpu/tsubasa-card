"""AI 自動編集およびカスタム指示機能の検証テスト

Speakly 風の「AI自動編集」および「カスタム指示（プリセット・独自ショートカット）」が
正しく設定スキーマ・変換ロジック・ホットキー管理に組み込まれているかを検証する。
"""

from __future__ import annotations

import sys
from pathlib import Path

# koe-type のルートをパスに追加
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import unittest
from app import schema, transform, inputwatch, winthread


class TestAiEditorAndCustomInstructions(unittest.TestCase):
    """AI 自動編集とカスタム指示の単体テスト。"""

    def test_schema_defaults(self) -> None:
        """スキーマに AI 自動編集およびカスタム指示が定義されていること。"""
        defaults = schema.defaults()
        self.assertIn("ai_auto_edit", defaults)
        self.assertIs(defaults["ai_auto_edit"], False)

        self.assertIn("ai_auto_edit_prompt", defaults)
        self.assertIn("フィラー", defaults["ai_auto_edit_prompt"])

        self.assertIn("ai_custom_instructions", defaults)
        presets = defaults["ai_custom_instructions"]
        self.assertIsInstance(presets, list)
        self.assertGreaterEqual(len(presets), 6)

        # プリセット ID の確認
        preset_ids = [p.get("id") for p in presets]
        self.assertIn("translate_en", preset_ids)
        self.assertIn("terminal_helper", preset_ids)
        self.assertIn("professional", preset_ids)
        self.assertIn("task_list", preset_ids)
        self.assertIn("chaos_mode", preset_ids)
        self.assertIn("buzzword_mode", preset_ids)

    def test_schema_find_keys(self) -> None:
        """変換の一覧は画面から更新でき、「AI自動編集」のスイッチは出さないこと。

        2026-10-11 利用者の頼み：つなぎ言葉の削除はふだんの文字起こしで
        いつも効かせ、変換は AI 編集とは別の単体の機能にする。
        スイッチをオンにすると、ふだんの録音まで変換に取られていたため、
        画面から外した（値は古い設定ファイルのために defaults に残す）。
        """
        self.assertIsNotNone(schema.find("ai_custom_instructions"))
        self.assertIsNone(schema.find("ai_auto_edit"))
        self.assertIsNone(schema.find("ai_auto_edit_prompt"))
        self.assertIs(schema.defaults()["ai_auto_edit"], False)

    def test_normal_recording_is_never_converted(self) -> None:
        """ai_auto_edit が残っていても、ふだんの録音を変換に回さないこと。"""
        src = (ROOT / "app" / "main.py").read_text("utf-8")
        start = src.index("def _start_recording")
        body = src[start:src.index("    def ", start + 1)]
        self.assertNotIn('bool_("ai_auto_edit"', body)

    def test_builtin_prompts_have_real_newlines(self) -> None:
        """指示文に「\\n」という文字が混ざらないこと（改行のつもりの書き損じ）。"""
        for inst in schema.defaults()["ai_custom_instructions"]:
            self.assertNotIn("\\n", inst["prompt"], inst["id"])
            self.assertIn("{text}", inst["prompt"], inst["id"])

    def test_edited_builtin_prompt_is_used(self) -> None:
        """一覧で書きかえた指示文が、組み込みの変換でも AI に渡ること。"""
        sent: list[str] = []
        original = transform.call_gemini
        transform.call_gemini = lambda prompt, **_kw: sent.append(prompt) or "OK"
        try:
            insts = [{"id": "translate_en", "prompt": "訳して：{text}"},
                     {"id": "professional", "prompt": "硬く：{text}"},
                     {"id": "summary", "prompt": "まとめて"}]
            for action in ("translate_en", "business", "summary"):
                transform.transform_text("あした行きます", action,
                                         api_key="k",
                                         custom_instructions=insts)
            # 一覧にない組み込みは、これまでの指示文のまま
            transform.transform_text("あした行きます", "polite",
                                     api_key="k", custom_instructions=insts)
        finally:
            transform.call_gemini = original
        self.assertEqual(sent[0], "訳して：あした行きます")
        self.assertEqual(sent[1], "硬く：あした行きます")
        self.assertEqual(sent[2], "まとめて\n\nあした行きます")
        self.assertIn("です・ます調", sent[3])

    def test_new_builtins_are_added_once(self) -> None:
        """古い一覧に新しい変換を 1 回だけ足し、消したものは戻さないこと。"""
        from app.configstore import _migrate
        old = [{"id": "translate_en", "prompt": "自分の文{text}"},
               {"id": "my_rule", "prompt": "x{text}"}]
        out = _migrate({"ai_custom_instructions": old})
        ids = [x["id"] for x in out["ai_custom_instructions"]]
        self.assertEqual(ids[:2], ["translate_en", "my_rule"])
        self.assertIn("polite", ids)
        self.assertIn("summary", ids)
        # 書きかえた指示文は上書きしない
        self.assertEqual(out["ai_custom_instructions"][0]["prompt"],
                         "自分の文{text}")
        # 足したあとに利用者が消したものは、次に読んでも戻らない
        out["ai_custom_instructions"] = [
            x for x in out["ai_custom_instructions"] if x["id"] != "polite"]
        again = _migrate(out)
        self.assertNotIn("polite",
                         [x["id"] for x in again["ai_custom_instructions"]])

    def test_basic_settings_are_the_essentials(self) -> None:
        """「よく使う設定」は根幹の項目だけ。それぞれ「→」で結果を書く。"""
        basic = [i.key or i.panel for c in schema.CATEGORIES
                 for g in c.groups for i in g.items if not i.advanced]
        self.assertLessEqual(len(basic), 36)
        for key in ("hotkey", "shortcut_mode", "microphone", "input_mode",
                    "language", "remove_fillers", "ai_custom_instructions"):
            self.assertIn(key, basic)
        for key in ("hotkey", "shortcut_mode", "input_mode",
                    "remove_fillers", "overlay", "autostart"):
            self.assertIn("→", schema.find(key).help_ja, key)

    def test_category_count_and_existence(self) -> None:
        """カテゴリーに 'ai' (AI編集・指示) が存在すること。"""
        cats = schema.CATEGORIES
        self.assertEqual(len(cats), 9)
        ai_cat = next((c for c in cats if c.key == "ai"), None)
        self.assertIsNotNone(ai_cat)
        self.assertEqual(ai_cat.icon, "sparkles")

    def test_offline_ai_auto_edit_fallback(self) -> None:
        """APIキー未設定時、ai_auto_edit がフィラー除去フォールバックとして動作すること。"""
        # "えーと、本日の会議ですが、あの、よろしくお願いします"
        raw_text = "えーと、本日の会議ですが、あの、よろしくお願いします"
        # transform_text(raw_text, "ai_auto_edit") を呼び出す
        # APIキーがない場合は jatext.clean_for_typing によりフィラーが除去される
        res = transform.transform_text(raw_text, "ai_auto_edit")
        self.assertNotIn("えーと", res)
        self.assertNotIn("あの", res)
        self.assertIn("本日の会議ですが", res)

    def test_custom_instruction_prompt_lookup(self) -> None:
        """カスタム指示のプロンプト取得とフォールバック動作の確認。"""
        insts = [
            {
                "id": "my_test_rule",
                "title": "テストルール",
                "prompt": "全ての語尾に『にゃん』を付けてください。",
            }
        ]
        # APIキーがない場合は ApiRequiredError が送出されること
        with self.assertRaises(transform.ApiRequiredError):
            transform.transform_text(
                "こんにちは",
                "custom_instruction_my_test_rule",
                custom_instructions=insts,
            )
        # APIキーがある場合はプロンプトが渡されること
        sent: list[str] = []
        original = transform.call_gemini
        transform.call_gemini = lambda p, **_kw: sent.append(p) or "こんにちはにゃん"
        try:
            res = transform.transform_text(
                "こんにちは",
                "custom_instruction_my_test_rule",
                api_key="test-key",
                custom_instructions=insts,
            )
            self.assertEqual(res, "こんにちはにゃん")
            self.assertIn("にゃん", sent[0])
        finally:
            transform.call_gemini = original

    def test_custom_hotkey_parsing(self) -> None:
        """カスタム指示用のホットキー文字列が正しく解析できること。"""
        # winthread.parse_hotkey の検証
        vk, mods = winthread.parse_hotkey("ctrl+alt+t")
        self.assertNotEqual(vk, 0)
        self.assertIn("ctrl", mods)
        self.assertIn("alt", mods)

        # ID_CUSTOM_BASE が定義されていること
        self.assertTrue(hasattr(inputwatch, "ID_CUSTOM_BASE"))
        self.assertEqual(inputwatch.ID_CUSTOM_BASE, 0xA100)

    def test_offline_speakly_disfluency_and_list_structuring(self) -> None:
        """オフラインでも Speakly 風の言い直し訂正とリスト構造化が動作すること。"""
        # 言い直し訂正の検証
        repair_text = "明日は3時に、いや待って、4時に行きます。"
        repaired = transform.fix_speech_repair(repair_text)
        self.assertNotIn("3時に", repaired)
        self.assertIn("4時に行きます", repaired)

        # Speakly 典型文のオフライン AI 自動編集
        speakly_speech = (
            "えーと、今日やることは3つあって、まずはレポートを書いて、"
            "いや待って、まずはメール返信して、それからレポート書いて、"
            "でえーと、明日の会議の準備をする。"
        )
        res = transform.transform_text(speakly_speech, "ai_auto_edit")
        # フィラーが消えていること
        self.assertNotIn("えーと", res)
        # 構造化リストになっていること（1. 2. 3. またはタスク一覧）
        self.assertIn("1.", res)
        self.assertIn("2.", res)
        self.assertIn("3.", res)
        self.assertIn("メール返信", res)
        self.assertIn("レポート書", res)
        self.assertIn("明日の会議", res)

    def test_offline_terminal_helper(self) -> None:
        """オフラインでターミナルコマンド推論が動作すること。"""
        self.assertEqual(transform.to_terminal_helper_offline("デスクトップに移動して"), "cd ~/Desktop")
        self.assertEqual(transform.to_terminal_helper_offline("ファイル一覧を表示して"), "ls -la")
        self.assertEqual(transform.to_terminal_helper_offline("ステータス確認して"), "git status")
        self.assertEqual(transform.to_terminal_helper_offline("Gitでプッシュして"), "git push")
        self.assertEqual(transform.to_terminal_helper_offline("npmインストールして"), "npm install")

    def test_offline_custom_instruction_dispatch(self) -> None:
        """カスタム指示がAPIキーなしでも専用オフラインエンジンへ正しくディスパッチされること。"""
        # terminal_helper
        cmd = transform.transform_text("gitプッシュして", "custom_instruction_terminal_helper")
        self.assertEqual(cmd, "git push")

        # chaos_mode
        chaos = transform.transform_text("これは便利です", "custom_instruction_chaos_mode")
        self.assertTrue("草" in chaos or "神" in chaos or "₍₍" in chaos)

        # buzzword_mode
        buzz = transform.transform_text("この方針に賛成です", "custom_instruction_buzzword_mode")
        self.assertIn("アグリー", buzz)

    def test_hold_mode_skips_long_press_action(self) -> None:
        """shortcut_mode が 'hold' の時は長押し特定動作に昇格しないことの整合性を確認。"""
        from app.configstore import Config
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            cfg = Config(Path(tmp) / "config.json")
            cfg.set("shortcut_mode", "hold")
            cfg.set("long_press_action", "polite")

            # shortcut_mode が hold のときは起動キーは純粋な PTT（通常録音）であり、
            # 意図しない敬語変換への昇格を防止する設計
            self.assertEqual(cfg.str_("shortcut_mode"), "hold")
            self.assertEqual(cfg.str_("long_press_action"), "polite")


if __name__ == "__main__":
    unittest.main()

