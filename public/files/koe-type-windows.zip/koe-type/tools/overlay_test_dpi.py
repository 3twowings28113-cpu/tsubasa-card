"""overlay_test から呼ぶ小さな確かめ（DPI を宣言したプロセスで動かす）。

拡大率と、中くらいのピルの帯の高さ（影を除く）を 1 行で出す。
画面には何も出さない（描いた中身を数えるだけ）。
"""

from __future__ import annotations

import ctypes
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import overlay as ov  # noqa: E402


def main() -> None:
    if not ov._start_gdiplus():
        print("0 0")
        return
    bar = ov.Overlay()
    bar.configure(theme_name="light", position="bottom", size="medium",
                  margin_px=16, enabled=True, design="pill",
                  hint_text="", show_hint=False)
    bar._animate = False
    for name in ov.FONTS:
        family = ctypes.c_void_p()
        if ov.gdiplus.GdipCreateFontFamilyFromName(
                name, None, ctypes.byref(family)) == 0:
            bar._font_family = family
            break
    bar.set_state("recording", elapsed=3.0, level=0.5, pending="")
    shot = None
    for _ in range(3):
        shot = bar.snapshot()
    height = (shot[1] - ov.SHADOW * 2) if shot else 0
    print(f"{bar._dpi_factor():.4f} {height}")


if __name__ == "__main__":
    main()
