"""koe-type をきれいに取り除く。

消すもの・残すものを、こちらで勝手に決めません。**必ず確認します。**

    python tools/uninstall.py            # 何をするか見せて、確認を取る
    python tools/uninstall.py --keep-data    # 設定・辞書・履歴は残す
    python tools/uninstall.py --all          # 全部消す
    python tools/uninstall.py --dry-run      # 何も消さずに一覧だけ

管理者権限は要りません（ユーザーの持ち物しか触りません）。
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import autostart  # noqa: E402
from app.util import CONFIG_PATH, DATA_DIR, DICT_PATH, LOG_DIR, MODEL_DIR  # noqa: E402


FILE_ATTRIBUTE_REPARSE_POINT = 0x400


def is_link(path: Path) -> bool:
    """ジャンクション（別の場所への入口）かどうか。

    **これを見分けないと、入口の先にある本物のファイルまで消してしまう。**
    この作業用フォルダでは models と engines が常駐アプリへの
    ジャンクションになっているので、ここを間違えると
    動いているアプリのモデルを消すことになる。
    """
    try:
        if path.is_symlink():
            return True
        return bool(path.lstat().st_file_attributes
                    & FILE_ATTRIBUTE_REPARSE_POINT)
    except (OSError, AttributeError):
        return False


def size_of(path: Path) -> int:
    if is_link(path):
        return 0          # 中身は別の場所のもの。数えない
    if path.is_file():
        return path.stat().st_size
    if path.is_dir():
        return sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    return 0


def powershell(script: str) -> str:
    import subprocess  # noqa: PLC0415
    try:
        done = subprocess.run(  # noqa: S603
            ["powershell", "-NoProfile", "-NonInteractive", "-Command",
             script], capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=60, creationflags=0x08000000)
    except Exception:  # noqa: BLE001
        return ""
    return done.stdout


def ps_quote(value: object) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def ours(text: str | None) -> bool:
    """登録やショートカットが、**この場所の** koe-type を指しているか。

    ほかの場所にも koe-type を入れている人の登録を、
    こちらの取り除きで外してしまわないため。
    """
    return bool(text) and str(ROOT / "koe-type.pyw").lower() in text.lower()


def stop_running() -> int:
    """この場所の koe-type が動いていたら止める。止めた数を返す。

    ★動いたままだと、エンジンの DLL が使用中で消せない。
    見張り役（guardian）を先に止める。本体だけ止めると、
    見張り役がすぐ起動し直してしまう。
    """
    pattern = str(ROOT / "koe-type.pyw")
    script = (
        "$app = Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe'\""
        f" | Where-Object {{ $_.CommandLine -like ('*' + {ps_quote(pattern)}"
        " + '*') }\n"
        "$ids = @($app | ForEach-Object { $_.ProcessId })\n"
        "Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe'\" | "
        "Where-Object { $_.CommandLine -like '*app.guardian*' -and "
        "$ids -contains $_.ParentProcessId } | "
        "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }\n"
        "$app | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }\n"
        "Write-Output $ids.Count\n")
    try:
        return int((powershell(script).strip().splitlines() or ["0"])[-1])
    except ValueError:
        return 0


def start_menu_link() -> Path:
    import os  # noqa: PLC0415
    return (Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows"
            / "Start Menu" / "Programs" / "koe-type.lnk")


def link_points_here(link: Path) -> bool:
    if not link.is_file():
        return False
    script = ("$s = (New-Object -ComObject WScript.Shell)."
              f"CreateShortcut({ps_quote(link)}); $s.Arguments")
    return ours(powershell(script))


def human(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


# (パス, 説明, 「あなたのもの」か)
def targets() -> list[tuple[Path, str, bool]]:
    return [
        (CONFIG_PATH, "設定", True),
        (DICT_PATH, "辞書（登録した言葉）", True),
        (DATA_DIR, "履歴（文字起こしの記録と音声）", True),
        (LOG_DIR, "ログ", False),
        (MODEL_DIR, "モデル（ダウンロードしたもの）", False),
        (ROOT / "engines", "文字起こしのエンジン", False),
        (ROOT / "dist", "作った配布用 zip", False),
    ]


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--keep-data", action="store_true",
                    help="設定・辞書・履歴は残す")
    ap.add_argument("--all", action="store_true", help="全部消す")
    ap.add_argument("--dry-run", action="store_true", help="消さずに一覧だけ")
    args = ap.parse_args()

    print("=" * 68)
    print(" koe-type を取り除きます")
    print("=" * 68)

    rows = [(p, label, mine) for p, label, mine in targets() if p.exists()]
    if not rows:
        print("\n 消すものはありませんでした。")
    else:
        print("\n このフォルダにあるもの\n")
        for path, label, mine in rows:
            mark = "★あなたのもの" if mine else "            "
            note = "（別の場所への入口）" if is_link(path) else ""
            print(f"  {mark} {label:28s} {human(size_of(path)):>9s}"
                  f"  {path.name}{note}")

    registered = autostart.current()
    if registered is None:
        state = "登録されていません"
    elif ours(registered):
        state = "この場所の koe-type が登録されています"
    else:
        state = "別の場所の koe-type が登録されています（そのままにします）"
    print(f"\n PC 起動時の自動起動: {state}")
    link = start_menu_link()
    link_here = link_points_here(link)
    if link_here:
        print(f" スタートメニュー: {link.name}（消します）")

    if args.dry_run:
        print("\n --dry-run なので何も消しませんでした。")
        return 0

    keep = args.keep_data
    if not args.keep_data and not args.all:
        print("\n どうしますか。")
        print("   1) 設定・辞書・履歴は残して、それ以外を消す（おすすめ）")
        print("   2) 全部消す")
        print("   3) やめる")
        try:
            answer = input("\n 番号を入れてください [1/2/3]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n やめました。")
            return 1
        if answer == "2":
            keep = False
        elif answer == "1":
            keep = True
        else:
            print(" やめました。")
            return 1

    stopped = stop_running()
    if stopped:
        print(f"\n 動いていた koe-type を止めました（{stopped} 個）。")

    # 自動起動の登録を外す（Windows のほかの設定には触りません）。
    # ★この場所を指しているときだけ。別の場所の koe-type の登録は残す。
    if ours(registered):
        try:
            autostart.disable()
            print("\n 自動起動の登録を外しました。")
        except Exception as exc:  # noqa: BLE001
            print(f"\n 自動起動の登録を外せませんでした: {exc}")
    if link_here:
        try:
            link.unlink()
            print(" スタートメニューから外しました。")
        except OSError as exc:
            print(f" スタートメニューから外せませんでした: {exc}")

    removed = 0
    for path, label, mine in rows:
        if keep and mine:
            print(f"  残す: {label}")
            continue
        try:
            if is_link(path):
                # 入口だけを外す。先にある本物のファイルには触らない
                path.rmdir() if path.is_dir() else path.unlink()
                print(f"  入口だけ外した: {label}（中身は別の場所なので残す）")
            elif path.is_dir():
                shutil.rmtree(path, ignore_errors=False)
                print(f"  消した: {label}")
            else:
                path.unlink()
                print(f"  消した: {label}")
            removed += 1
        except OSError as exc:
            print(f"  消せません: {label} — {exc}")

    print(f"\n {removed} 件を消しました。")
    print("\n 最後に、このフォルダごと削除してください。")
    print(f"   {ROOT}")
    if keep:
        print("\n 設定・辞書・履歴は残してあります。"
              "フォルダごと消すと、それらも消えます。")
        print(" 取っておきたい場合は、先に config.json と dictionary.txt を"
              "どこかへコピーしてください。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
