"""トレイアイコンのシミュレーション比較画像を作成する。
Windowsのダークタスクバー（#202020）およびライトタスクバー（#F3F3F3）上に
16px, 24px, 32px のサイズで並べた比較プレビューを生成する。
"""
from __future__ import annotations

import ctypes
from ctypes import Structure, byref, c_int, c_uint, c_void_p, wintypes
import sys
from pathlib import Path

root = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(root))

gdiplus = ctypes.windll.gdiplus


class GdiplusStartupInput(Structure):
    _fields_ = [
        ("GdiplusVersion", wintypes.UINT),
        ("DebugEventCallback", c_void_p),
        ("SuppressBackgroundThread", wintypes.BOOL),
        ("SuppressExternalCodecs", wintypes.BOOL),
    ]


class Rect(Structure):
    _fields_ = [
        ("X", c_int),
        ("Y", c_int),
        ("Width", c_int),
        ("Height", c_int),
    ]


PixelFormat32bppARGB = 0x26200A
InterpolationModeHighQualityBicubic = 7


def make_preview() -> None:
    token = c_void_p()
    si = GdiplusStartupInput(1, None, False, False)
    if gdiplus.GdiplusStartup(byref(token), byref(si), None) != 0:
        return

    try:
        root = Path(__file__).resolve().parent.parent
        idle_png_path = root / "assets" / "icon" / "png" / "speakpulse-idle-256.png"
        rec_png_path = root / "assets" / "icon" / "png" / "speakpulse-recording-256.png"

        p_idle = c_void_p()
        p_rec = c_void_p()
        gdiplus.GdipLoadImageFromFile(str(idle_png_path), byref(p_idle))
        gdiplus.GdipLoadImageFromFile(str(rec_png_path), byref(p_rec))

        # プレビューキャンバス（幅 720, 高さ 260）
        canvas_w, canvas_h = 720, 260
        p_bmp = c_void_p()
        gdiplus.GdipCreateBitmapFromScan0(canvas_w, canvas_h, 0, PixelFormat32bppARGB, None, byref(p_bmp))
        p_gfx = c_void_p()
        gdiplus.GdipGetImageGraphicsContext(p_bmp, byref(p_gfx))
        gdiplus.GdipSetInterpolationMode(p_gfx, InterpolationModeHighQualityBicubic)

        # 背景1: ダークモードタスクバー（#202020）
        p_brush_dark = c_void_p()
        gdiplus.GdipCreateSolidFill(0xFF202020, byref(p_brush_dark))
        gdiplus.GdipFillRectangleI(p_gfx, p_brush_dark, 0, 0, canvas_w, 130)
        gdiplus.GdipDeleteBrush(p_brush_dark)

        # 背景2: ライトモードタスクバー（#E8E8E8）
        p_brush_light = c_void_p()
        gdiplus.GdipCreateSolidFill(0xFFE8E8E8, byref(p_brush_light))
        gdiplus.GdipFillRectangleI(p_gfx, p_brush_light, 0, 130, canvas_w, 130)
        gdiplus.GdipDeleteBrush(p_brush_light)

        # 各サイズで描画 (16, 20, 24, 32, 48)
        sizes = [16, 20, 24, 32, 48]
        x_positions_idle = [30, 80, 140, 210, 280]
        x_positions_rec = [380, 430, 490, 560, 630]

        png_dir = root / "assets" / "icon" / "png"

        for sz, xi, xr in zip(sizes, x_positions_idle, x_positions_rec):
            p_sz_idle = c_void_p()
            p_sz_rec = c_void_p()
            gdiplus.GdipLoadImageFromFile(str(png_dir / f"idle-{sz}.png"), byref(p_sz_idle))
            gdiplus.GdipLoadImageFromFile(str(png_dir / f"recording-{sz}.png"), byref(p_sz_rec))

            # ダーク側
            cy_dark = 65 - sz // 2
            gdiplus.GdipDrawImageRectI(p_gfx, p_sz_idle, xi, cy_dark, sz, sz)
            gdiplus.GdipDrawImageRectI(p_gfx, p_sz_rec, xr, cy_dark, sz, sz)

            # ライト側
            cy_light = 195 - sz // 2
            gdiplus.GdipDrawImageRectI(p_gfx, p_sz_idle, xi, cy_light, sz, sz)
            gdiplus.GdipDrawImageRectI(p_gfx, p_sz_rec, xr, cy_light, sz, sz)

            gdiplus.GdipDisposeImage(p_sz_idle)
            gdiplus.GdipDisposeImage(p_sz_rec)

        # 保存
        out_path = root / "scratch" / "tray_simulation_preview.png"
        out_path.parent.mkdir(parents=True, exist_ok=True)

        # GdipSaveImageToFile (PNG clsid)
        # 簡易的に raw RGBA を抽出して _write_png_bytes で保存
        from tools.make_icons import BitmapData, _write_png_bytes, Rect, ImageLockModeRead
        bd = BitmapData()
        rc = Rect(0, 0, canvas_w, canvas_h)
        gdiplus.GdipBitmapLockBits(p_bmp, byref(rc), ImageLockModeRead, PixelFormat32bppARGB, byref(bd))
        buf = (ctypes.c_ubyte * (canvas_w * canvas_h * 4)).from_address(bd.Scan0)

        # 独自PNGエンコーダ
        import zlib
        import struct
        def chunk(tag, data):
            return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

        raw = bytearray()
        for y in range(canvas_h):
            raw.append(0)
            for x in range(canvas_w):
                idx = (y * canvas_w + x) * 4
                raw.append(buf[idx + 2])  # R
                raw.append(buf[idx + 1])  # G
                raw.append(buf[idx])      # B
                raw.append(buf[idx + 3])  # A

        png_data = (b"\x89PNG\r\n\x1a\n"
                    + chunk(b"IHDR", struct.pack(">IIBBBBB", canvas_w, canvas_h, 8, 6, 0, 0, 0))
                    + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
                    + chunk(b"IEND", b""))

        out_path.write_bytes(png_data)
        print(f"Preview saved: {out_path}")

        gdiplus.GdipBitmapUnlockBits(p_bmp, byref(bd))
        gdiplus.GdipDeleteGraphics(p_gfx)
        gdiplus.GdipDisposeImage(p_bmp)
        gdiplus.GdipDisposeImage(p_idle)
        gdiplus.GdipDisposeImage(p_rec)

    finally:
        gdiplus.GdiplusShutdown(token)


if __name__ == "__main__":
    make_preview()
