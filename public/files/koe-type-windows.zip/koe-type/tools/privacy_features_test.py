"""プライバシー機能（通信完全遮断 ＆ データの全削除）の自動テスト。

本物のキー送信やマイク録音・外部通信は一切行わない。
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

# テスト用の使い捨てフォルダを KOE_TYPE_HOME に向ける
ROOT = Path(__file__).resolve().parent.parent
TMPDIR = tempfile.TemporaryDirectory(prefix="koe-type-priv-test-")
os.environ["KOE_TYPE_HOME"] = TMPDIR.name
os.environ["KOE_TYPE_DRY_RUN"] = "1"
sys.path.insert(0, str(ROOT))

from app import configstore, downloads, history, textproc, updates, websettings  # noqa: E402


def test_offline_mode() -> None:
    print("=== 1. オフラインモード（通信遮断）の検証 ===")
    cfg = configstore.Config()
    dict_obj = textproc.Dictionary()
    hist = history.History()
    bridge = websettings.Bridge(cfg, dict_obj, hist, lambda name, **kw: None)

    # オフラインモードを有効化
    bridge.set_value("offline_mode", True)
    assert downloads.is_offline() is True, "downloads.is_offline() should be True"

    # 1. _fetch が遮断されること
    try:
        downloads._fetch("https://example.com/test", Path(TMPDIR.name) / "test.bin",
                         0, "test", None, None)
        raise AssertionError("_fetch did not raise DownloadError in offline mode")
    except downloads.DownloadError as exc:
        print(f"OK: _fetch blocked -> {exc}")

    # 2. updates.check が遮断されること
    res = updates.check()
    assert res.get("ok") is False, "updates.check should fail in offline mode"
    assert "オフライン" in res.get("error", "") or "通信が遮断" in res.get("error", "")
    print(f"OK: updates.check blocked -> {res.get('error')}")

    # 3. bridge.run_action("check_update") が遮断されること
    act_res = bridge.run_action("check_update", {})
    assert act_res.get("ok") is False
    print(f"OK: bridge check_update blocked -> {act_res.get('error')}")

    # 4. bridge._download が即座にエラーイベントを push すること
    bridge.run_action("download_model", {"model": "large"})
    events = bridge.drain()
    assert any(e.get("type") == "download_done" and "遮断" in e.get("error", "")
               for e in events), f"Expected download_done error in events: {events}"
    print("OK: bridge download_model pushed offline error")

    # オフラインモードを解除
    bridge.set_value("offline_mode", False)
    assert downloads.is_offline() is False
    print("OK: offline mode toggle verified")


def test_clear_all_data() -> None:
    print("\n=== 2. 全データ消去（clear_all_data）の検証 ===")
    cfg = configstore.Config()
    dict_obj = textproc.Dictionary()
    hist = history.History()

    events_fired = []

    def mock_action(name: str, **kw) -> None:
        events_fired.append((name, kw))

    bridge = websettings.Bridge(cfg, dict_obj, hist, mock_action)

    # 1. 履歴とダミー録音 WAV を作成
    wav_path = history.AUDIO_DIR / "dummy_audio.wav"
    wav_path.parent.mkdir(parents=True, exist_ok=True)
    wav_path.write_bytes(b"RIFFdummydataWAVE")
    hist.add("テスト発言", raw_text="テスト発言生", audio=wav_path)
    assert hist.count() == 1
    assert wav_path.exists()

    # 2. ユーザー辞書に単語を追加
    dict_obj.save([{"surface": "誤認識語", "reading": "よみ", "mishearing": "正しい語"}])
    assert len(dict_obj.detailed_entries()) == 1

    # 3. ログファイルを作成
    from app.util import LOG_DIR
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_file = LOG_DIR / "koe-type.log"
    log_file.write_text("2026-10-06 confidential test log entry\n", encoding="utf-8")
    assert log_file.stat().st_size > 0

    # 4. 設定を変更
    cfg.set("hotkey", "ctrl+alt+k")
    cfg.set("theme", "dark")
    assert cfg.str_("hotkey") == "ctrl+alt+k"

    # 5. clear_all_data を実行
    res = bridge.run_action("clear_all_data", {})
    assert res.get("ok") is True

    # 6. 検証: 履歴が空
    assert hist.count() == 0, f"History should be 0, got {hist.count()}"
    assert not wav_path.exists(), "Audio WAV should be unlinked"

    # 7. 検証: 辞書が空
    assert len(dict_obj.detailed_entries()) == 0, "Dictionary should be empty"

    # 8. 検証: ログファイルが空
    assert log_file.stat().st_size == 0, "Log file should be empty"

    # 9. 検証: 設定が初期化（hotkey が既定値に戻る）
    assert cfg.str_("hotkey") != "ctrl+alt+k", "Hotkey should be reset"

    # 10. 検証: アクション通知が届いている
    action_names = [name for name, _ in events_fired]
    assert "config_reset" in action_names
    assert "dictionary_changed" in action_names
    print("OK: clear_all_data successfully wiped all user data and reset config")

    hist.close()


if __name__ == "__main__":
    try:
        test_offline_mode()
        test_clear_all_data()
        print("\nAll privacy feature tests passed successfully!")
    finally:
        try:
            TMPDIR.cleanup()
        except OSError:
            pass
