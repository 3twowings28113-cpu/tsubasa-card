r"""常駐しているアプリを、**待機中のときだけ**起動し直す。

docs/HANDOFF.md の「4. 常駐アプリの起動し直し方」を 1 本にしたもの。

★録音の最中に止めてはいけない。2026-10-05 に、利用者が話している
最中のアプリを止めてしまった（手で PowerShell を打っていたため、
状態を確かめていなかった）。ここでは `logs/heartbeat` を読み、
待機中（state=idle）が続いているときだけ入れ替える。

キーは 1 回も送らない。最後に tools/live_check.py で外から確かめる。

    python tools\restart_live.py            # 待機中なら起動し直す
    python tools\restart_live.py --wait 600 # 待機中になるまで最大 10 分待つ
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
HEARTBEAT = ROOT / "logs" / "heartbeat"
PYTHONW = Path(sys.executable).with_name("pythonw.exe")

# 待機に戻ってから、これだけ経っていれば「いまは使っていない」とみなす。
# 話し終えてすぐ（文字を入れている最中など）に止めないため。
QUIET_SECONDS = 20.0


def read_heartbeat() -> dict[str, str]:
    try:
        lines = HEARTBEAT.read_text("utf-8").splitlines()
    except OSError:
        return {}
    out = {"time": lines[0].strip()} if lines else {}
    for line in lines[1:]:
        if "=" in line:
            key, value = line.split("=", 1)
            out[key.strip()] = value.strip()
    return out


def idle_since() -> float | None:
    """待機中になってからの秒数のおおよそ。録音中なら None。"""
    beat = read_heartbeat()
    if beat.get("state") != "idle" or beat.get("stopping", "0") not in (
            "0", "0.0"):
        return None
    try:
        age = time.time() - float(beat.get("time", "0"))
    except ValueError:
        return None
    if age > 30:
        # 心拍が古い＝アプリが止まっている。入れ替えて構わない
        return QUIET_SECONDS
    return 0.0


def wait_quiet(limit: float) -> bool:
    """待機中が QUIET_SECONDS 続くまで待つ。"""
    deadline = time.monotonic() + limit
    quiet_from: float | None = None
    while time.monotonic() < deadline:
        since = idle_since()
        now = time.monotonic()
        if since is None:
            quiet_from = None
        else:
            if quiet_from is None:
                quiet_from = now - since
            if now - quiet_from >= QUIET_SECONDS:
                return True
        time.sleep(1.0)
    return False


def powershell(script: str) -> str:
    done = subprocess.run(
        ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        creationflags=0x08000000, check=False)
    return done.stdout


def stop_running() -> None:
    # 見張り役を先に止める（本体だけ止めると、すぐ起動し直される）
    for pattern in ("*guardian*", "*koe-type.pyw*"):
        powershell(
            "Get-CimInstance Win32_Process -Filter \"Name='pythonw.exe'\" | "
            f"Where-Object {{ $_.CommandLine -like '{pattern}' }} | "
            "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }")


def start() -> None:
    # 利用者の実デスクトップ（WinSta0\default）で起動するため schtasks (/it) を使う
    script_path = str(ROOT / "koe-type.pyw")
    tr = f"C:\\Python314\\pythonw.exe {script_path}"
    subprocess.run([
        "schtasks", "/create", "/tn", "KoeTypeRun",
        "/tr", tr,
        "/sc", "ONCE", "/st", "23:59", "/it", "/f",
    ], capture_output=True, check=False)
    subprocess.run([
        "schtasks", "/run", "/tn", "KoeTypeRun",
    ], capture_output=True, check=False)


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--wait", type=float, default=60.0,
                    help="待機中になるまで待つ最大の秒数")
    args = ap.parse_args()

    print(f"待機中が {QUIET_SECONDS:.0f} 秒続くのを待ちます"
          f"（最大 {args.wait:.0f} 秒）…")
    if not wait_quiet(args.wait):
        print("使っている最中なので、入れ替えませんでした。")
        return 2
    stop_running()
    time.sleep(2.0)
    start()
    time.sleep(12.0)
    check = subprocess.run([sys.executable, str(ROOT / "tools" /
                                                 "live_check.py")],
                           capture_output=True, text=True, encoding="utf-8",
                           errors="replace", check=False)
    tail = [line for line in check.stdout.splitlines()
            if "NG" in line or "成功" in line]
    print("\n".join(tail))
    return check.returncode


if __name__ == "__main__":
    raise SystemExit(main())
