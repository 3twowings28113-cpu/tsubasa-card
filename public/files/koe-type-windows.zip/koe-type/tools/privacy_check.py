r"""コミット前に、個人データが混ざっていないか調べる。

git が追跡する（＝公開される）ファイルだけを見て、次を探す。
  ・個人の固有名詞や辞書の中身
  ・PC の利用者名を含む絶対パス
  ・メールアドレスらしき文字列
  ・音声ファイル・データベース・ログ
  ・公開してはいけないファイル名そのもの

  python tools\privacy_check.py              いまのファイルを調べる
  python tools\privacy_check.py --history    **全コミットの履歴も**調べる

履歴まで調べるのは、一度コミットしたものは消したつもりでも
`git log` から誰でも取り出せるため。公開前には必ず --history で通す。

終了コード 0 = 問題なし / 1 = 要確認
"""

from __future__ import annotations

import getpass
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# 公開してはいけないファイル（追跡されていたら失格）
FORBIDDEN_FILES = {
    "config.json", "dictionary.txt", "dictionary.user.txt",
    "bench/results.json", "bench/audio_truth.json", "bench/real_truth.json",
}
FORBIDDEN_DIRS = ("data/", "logs/", "models/", "engines/", "bench/audio/",
                  "bench/private/")
FORBIDDEN_SUFFIX = (".wav", ".mp3", ".db", ".sqlite", ".sqlite3", ".log",
                    ".gguf", ".bin", ".exe", ".dll", ".zip", ".pyc")

# 本文に出てはいけない語。自分の固有名詞は tools/private_words.txt に書く
# （このファイル自体は .gitignore しているので、語が公開されることはない）。
WORDS_FILE = Path(__file__).resolve().parent / "private_words.txt"


def personal_words() -> list[str]:
    try:
        return [w.strip() for w in WORDS_FILE.read_text("utf-8").splitlines()
                if w.strip() and not w.strip().startswith("#")]
    except OSError:
        return []


USER = getpass.getuser()
PATTERNS = [
    (re.compile(rf"[A-Za-z]:\\+Users\\+{re.escape(USER)}", re.I),
     f"PC の利用者名を含む絶対パス (Users\\{USER})"),
    (re.compile(rf"/Users/{re.escape(USER)}", re.I),
     f"PC の利用者名を含む絶対パス (/Users/{USER})"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "メールアドレスらしき文字列"),
    (re.compile(r"com\.pais\.handy"), "ほかのアプリの個人フォルダ"),
]

# 説明のために出てよい場所（README の例示など）
ALLOW_PATH_EXAMPLE = {"README.md", "README.en.md", "CLAUDE.md"}


def tracked_files() -> list[str]:
    try:
        out = subprocess.run(["git", "ls-files"], cwd=str(ROOT),
                             capture_output=True, text=True, encoding="utf-8")
        if out.returncode != 0:
            return []
        return [line.strip() for line in out.stdout.splitlines() if line.strip()]
    except FileNotFoundError:
        return []


def all_blobs() -> list[tuple[str, str]]:
    """全コミットに入っている、すべてのファイルの中身を列挙する。

    返すのは [(どこで, 中身)]。同じ中身は 1 回だけ返す。
    一度コミットしたものは、あとで消しても履歴から取り出せてしまうので、
    公開前にはここまで調べる必要がある。
    """
    try:
        listing = subprocess.run(  # noqa: S603, S607
            ["git", "rev-list", "--objects", "--all"], cwd=str(ROOT),
            capture_output=True, text=True, encoding="utf-8", errors="replace")
    except FileNotFoundError:
        return []
    if listing.returncode != 0:
        return []

    wanted: dict[str, str] = {}      # sha -> 見つかった名前
    for line in listing.stdout.splitlines():
        parts = line.split(" ", 1)
        if len(parts) != 2:
            continue
        sha, name = parts[0], parts[1].strip()
        if name:
            wanted.setdefault(sha, name)

    out: list[tuple[str, str]] = []
    shas = list(wanted)
    # cat-file --batch にまとめて渡す（1個ずつだと遅い）
    step = 400
    for i in range(0, len(shas), step):
        chunk = shas[i:i + step]
        proc = subprocess.run(  # noqa: S603, S607
            ["git", "cat-file", "--batch"], cwd=str(ROOT),
            input=("\n".join(chunk) + "\n").encode(),
            capture_output=True)
        data = proc.stdout
        pos = 0
        while pos < len(data):
            nl = data.find(b"\n", pos)
            if nl < 0:
                break
            header = data[pos:nl].decode("utf-8", "replace").split()
            pos = nl + 1
            if len(header) < 3:
                continue
            sha, kind, size = header[0], header[1], int(header[2])
            body = data[pos:pos + size]
            pos += size + 1       # 中身のあとの改行
            if kind != "blob":
                continue
            name = wanted.get(sha, sha[:8])
            lower = name.lower()
            if lower.endswith(FORBIDDEN_SUFFIX) or b"\x00" in body[:2048]:
                # 中身は読まない（画像やバイナリ）。名前だけ見る。
                out.append((f"{name} [履歴]", ""))
                continue
            try:
                out.append((f"{name} [履歴]", body.decode("utf-8")))
            except UnicodeDecodeError:
                continue
    return out


def scan_text(name: str, text: str, words: list[str]) -> list[str]:
    found = []
    for word in words:
        if word in text:
            found.append(f"{name}: 個人の固有名詞 '{word}' が含まれています")
    for pattern, label in PATTERNS:
        for hit in pattern.findall(text):
            base = name.split(" [")[0]
            if base in ALLOW_PATH_EXAMPLE and "Users" in str(hit):
                continue
            found.append(f"{name}: {label} -> {hit}")
    return found


def check_history(words: list[str]) -> list[str]:
    blobs = all_blobs()
    print(f"\n履歴の中のファイル: {len(blobs)} 件を調べます")
    problems: list[str] = []
    for name, text in blobs:
        base = name.split(" [")[0]
        lower = base.lower()
        if base in FORBIDDEN_FILES:
            problems.append(f"{name}: 公開してはいけないファイルが"
                            f"過去のコミットに入っています")
            continue
        if any(lower.startswith(d) for d in FORBIDDEN_DIRS):
            problems.append(f"{name}: 公開してはいけないフォルダの中の"
                            f"ファイルが過去のコミットに入っています")
            continue
        if lower.endswith(FORBIDDEN_SUFFIX):
            problems.append(f"{name}: この拡張子のファイルが"
                            f"過去のコミットに入っています")
            continue
        if text:
            problems.extend(scan_text(name, text, words))
    return problems


def main() -> int:
    history = "--history" in sys.argv or "-H" in sys.argv
    files = tracked_files()
    if not files:
        print("git がまだ追跡しているファイルがありません。")
        print("（git init と git add のあとで、もう一度実行してください）")
        return 0

    words = personal_words()
    problems: list[str] = []
    print(f"追跡中のファイル: {len(files)} 件")
    if words:
        print(f"個人語の一覧: {WORDS_FILE.name}（{len(words)} 語）\n")
    else:
        print(f"※ {WORDS_FILE.name} がありません。固有名詞の検査は行いません。")
        print("   private_words.sample.txt をコピーして自分の語を書いてください。\n")

    for name in files:
        lower = name.lower()
        if name in FORBIDDEN_FILES:
            problems.append(f"{name}: 公開してはいけないファイルが追跡されています")
            continue
        if any(lower.startswith(d) for d in FORBIDDEN_DIRS):
            problems.append(f"{name}: 公開してはいけないフォルダの中です")
            continue
        if lower.endswith(FORBIDDEN_SUFFIX):
            problems.append(f"{name}: この拡張子は配布物に含めません")
            continue

        path = ROOT / name
        try:
            text = path.read_text("utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        problems.extend(scan_text(name, text, words))

    if history:
        problems.extend(check_history(words))
    else:
        print("\n※ 履歴は調べていません。公開前に --history を付けて"
              "もう一度実行してください。")

    if problems:
        print("■ 要確認")
        for line in dict.fromkeys(problems):
            print("  -", line)
        print(f"\n{len(set(problems))} 件。直してからコミットしてください。")
        return 1

    print("■ 個人データは見つかりませんでした。")
    print("  ファイル名・フォルダ・本文のいずれにも問題はありません。")
    if history:
        print("  過去のすべてのコミットも調べました。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
