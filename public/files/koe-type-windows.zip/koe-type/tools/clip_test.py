r"""クリップボード履歴の試験。本物のクリップボードもキーも使わない。

  python tools\clip_test.py            # 全部
  python tools\clip_test.py --shots    # 窓の見た目の画像も作る（logs\clipshots）

使い捨てのフォルダを KOE_TYPE_HOME にしてから app を読み込むので、
利用者の履歴・グループ・設定には触らない。
から打ちモード（KOE_TYPE_DRY_RUN=1）で動かすので、クリップボードへの
書き込みと貼り付けのキーは、記録されるだけで実際には起きない。
"""

from __future__ import annotations

import json
import os
import struct
import sys
import tempfile
import time
import zlib
from pathlib import Path

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_SANDBOX = Path(tempfile.mkdtemp(prefix="koe-type-cliptest-"))
(_SANDBOX / "logs").mkdir()
(_SANDBOX / "data").mkdir()
os.environ["KOE_TYPE_HOME"] = str(_SANDBOX)
os.environ["KOE_TYPE_DRY_RUN"] = "1"
os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

from app import clipdata, clipgfx, clipmodel, clipstore, dryrun  # noqa: E402
from app.clipmodel import Command, PopupModel, Tab               # noqa: E402
from app.clipstore import HISTORY, ClipStore                      # noqa: E402

ok_count = 0
fail_count = 0

# 見本のメールアドレス。privacy_check はメールアドレスの形の文字列を
# 例外なく止めるので、ファイルの中では組み立てて作る。
MAIL_X = "x" + "@" + "example.jp"
MAIL_INFO = "info" + "@" + "example.jp"
MAIL_WORK = "yamada" + "@" + "example.co.jp"


def check(label: str, got, want=None, *, truthy: bool = False) -> None:
    global ok_count, fail_count
    good = bool(got) if truthy else got == want
    if good:
        ok_count += 1
        print(f"  OK   {label}")
    else:
        fail_count += 1
        print(f"  NG   {label}: got={got!r} want={want!r}")


def section(title: str) -> None:
    print(f"\n[{title}]")


def tiny_png(w: int, h: int, rgb: tuple[int, int, int]) -> bytes:
    """試験用の小さな PNG を自前で作る（GDI+ に頼らない見本）。"""
    raw = b"".join(b"\x00" + bytes(rgb) * w for _ in range(h))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))
    return (b"\x89PNG\r\n\x1a\n"
            + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw))
            + chunk(b"IEND", b""))


def tiny_dib(w: int, h: int, bgr: tuple[int, int, int],
             bits: int = 24) -> bytes:
    """試験用の CF_DIB（下から上）。"""
    if bits == 24:
        row = bytes(bgr) * w
        row += b"\x00" * ((4 - len(row) % 4) % 4)
    else:
        row = (bytes(bgr) + b"\xff") * w
    pixels = row * h
    header = struct.pack("<IiiHHIIiiII", 40, w, h, 1, bits, 0, len(pixels),
                         0, 0, 0, 0)
    return header + pixels


# ---------------------------------------------------------------- 保存


def test_store() -> ClipStore:
    section("1 保存（履歴・重ね・並び順・固定）")
    store = ClipStore(_SANDBOX / "data" / "t1.db", _SANDBOX / "data" / "img")
    check("データベースを開ける", store.ok, True)
    a = store.add(kind="text", hash_=clipstore.text_hash("りんご"),
                  text="りんご", app="notepad.exe")
    time.sleep(0.01)
    b = store.add(kind="text", hash_=clipstore.text_hash("みかん"),
                  text="みかん")
    time.sleep(0.01)
    again = store.add(kind="text", hash_=clipstore.text_hash("りんご"),
                      text="りんご")
    check("同じものは重ねない（同じ id）", again, a)
    rows = store.items(HISTORY, sort=clipstore.SORT_COPY)
    check("もう一度コピーしたものが一番上", [r.snippet for r in rows],
          ["りんご", "みかん"])
    time.sleep(0.01)
    store.mark_used([b])
    copy_order = [r.snippet for r in store.items(
        HISTORY, sort=clipstore.SORT_COPY)]
    use_order = [r.snippet for r in store.items(
        HISTORY, sort=clipstore.SORT_USE)]
    check("コピーした順：使っても動かない", copy_order, ["りんご", "みかん"])
    check("使った順：貼ったものが上へ", use_order, ["みかん", "りんご"])
    store.mark_used([b])
    count_order = [r.snippet for r in store.items(
        HISTORY, sort=clipstore.SORT_COUNT)]
    check("よく使う順", count_order, ["みかん", "りんご"])
    store.set_pinned([a], True)
    pinned = [r.snippet for r in store.items(HISTORY,
                                             sort=clipstore.SORT_USE)]
    check("固定したものは上に", pinned, ["りんご", "みかん"])
    unpinned_first = [r.snippet for r in store.items(
        HISTORY, sort=clipstore.SORT_USE, pinned_first=False)]
    check("固定を上にしない設定", unpinned_first, ["みかん", "りんご"])

    section("2 整理（件数・日数・固定は残す）")
    for i in range(30):
        store.add(kind="text", hash_=clipstore.text_hash(f"n{i}"),
                  text=f"n{i}")
    removed = store.trim(max_items=10, keep_days=0)
    check("件数の上限まで減る", store.history_count(), 11)   # 固定 1 件＋10
    check("消えた数", removed, 21)
    check("固定は残る", any(r.id == a for r in store.items()), True)
    store._exec("UPDATE clips SET created = ?, last_used = 0 "
                "WHERE pinned = 0", (time.time() - 40 * 86400,))
    store._changed()
    store.trim(max_items=0, keep_days=30)
    check("古いものは日数で消える（固定だけ残る）", store.history_count(), 1)

    section("3 グループ（作る・移す・並べる・名前・消す）")
    gid = store.add_group("よく使う")
    mail = store.add(kind="text", hash_=clipstore.text_hash(MAIL_X),
                     text=MAIL_X)
    moved = store.move([mail], gid)
    check("履歴からグループへ移す", moved, 1)
    check("履歴からは消える",
          any(r.id == mail for r in store.items(HISTORY)), False)
    check("グループに入る", [r.id for r in store.items(gid)], [mail])
    second = store.add(kind="text", hash_=clipstore.text_hash("住所"),
                       text="東京都", group_id=gid, title="住所")
    order = [r.id for r in store.items(gid, sort=clipstore.SORT_MANUAL)]
    check("手で並べた順（足した順）", order, [mail, second])
    store.reorder(second, -1)
    order = [r.id for r in store.items(gid, sort=clipstore.SORT_MANUAL)]
    check("上へ動かす", order, [second, mail])
    g2 = store.add_group("仕事")
    store.reorder_group(g2, -1)
    check("グループの並べ替え", [g.name for g in store.groups()],
          ["仕事", "よく使う"])
    store.rename_group(g2, "仕事用")
    check("グループの名前を変える", store.group(g2).name, "仕事用")
    check("中身の数", store.group(gid).count, 2)
    made = store.ensure_default_groups(["よく使う"])
    check("最初のグループは 1 回だけ作る", made, True)
    check("2 回目は作らない", store.ensure_default_groups(["よく使う"]),
          False)

    section("4 秘密（DPAPI で包む）")
    secret_id = store.add(kind="text", hash_=clipstore.text_hash("pw"),
                          text="P@ssw0rd!", group_id=gid, title="社内",
                          secret=True)
    check("秘密の項目を足せる", secret_id > 0, True)
    raw = store._exec("SELECT text, secret FROM clips WHERE id = ?",
                      (secret_id,)).fetchone()
    check("本文は平文で残らない", raw[0], "")
    check("包んだものは元の文字を含まない",
          b"P@ssw0rd" not in bytes(raw[1]), True)
    check("貼るときは元に戻る", store.payload(secret_id).text, "P@ssw0rd!")
    check("一覧の文字は空（伏せる）", store.get(secret_id).snippet, "")
    store.update_item(secret_id, secret=False)
    check("秘密をやめると平文に", store.full_text(secret_id), "P@ssw0rd!")
    store.update_item(secret_id, text="new-pass", secret=True)
    check("書き換えて秘密に", store.payload(secret_id).text, "new-pass")

    section("5 消す・元に戻す・書き出し")
    rows = store.delete([mail], keep_files=True)
    check("消すと行が返る", len(rows), 1)
    store.restore(rows)
    check("元に戻せる", store.get(mail) is not None, True)
    text = store.export_json()
    data = json.loads(text)
    names = [g["name"] for g in data["groups"]]
    check("グループを書き出せる", "よく使う" in names, True)
    dumped = json.dumps(data, ensure_ascii=False)
    check("秘密の中身は書き出さない（頼まれない限り）",
          "new-pass" in dumped, False)
    other = ClipStore(_SANDBOX / "data" / "t2.db",
                      _SANDBOX / "data" / "img2")
    counts = other.import_json(store.export_json(include_secrets=True))
    check("読み込める（グループ数）", counts["groups"], 2)
    inner = other.groups()[1]
    check("秘密は秘密のまま読み込む",
          any(c.secret for c in other.items(inner.id)), True)
    again = other.import_json(store.export_json(include_secrets=True))
    check("同じものを 2 回読み込んでも重ならない", again["items"], 0)
    deleted = store.delete_group(g2)
    check("空のグループを消せる", deleted, 0)
    return store


# ---------------------------------------------------------------- 画像


def test_images() -> None:
    section("6 画像（DIB → PNG・縮小・貼り付け用 DIB）")
    out = _SANDBOX / "data" / "img" / "a.png"
    w, h = clipgfx.dib_to_png(tiny_dib(40, 30, (0, 0, 255)), out)
    check("24bit の DIB を PNG にできる", (w, h), (40, 30))
    data = out.read_bytes()
    check("PNG の頭から大きさを読める", clipgfx.png_size(data), (40, 30))
    w2, h2 = clipgfx.dib_to_png(tiny_dib(17, 9, (0, 255, 0), bits=32),
                                out.with_name("b.png"))
    check("32bit の DIB も PNG にできる", (w2, h2), (17, 9))
    bitfields = bytearray(tiny_dib(8, 8, (255, 0, 0), bits=32))
    struct.pack_into("<I", bitfields, 16, 3)           # BI_BITFIELDS
    bitfields[40:40] = struct.pack("<III", 0xFF0000, 0x00FF00, 0x0000FF)
    check("BI_BITFIELDS の位置", clipgfx.dib_bits_offset(bytes(bitfields)),
          52)
    w3, _ = clipgfx.dib_to_png(bytes(bitfields), out.with_name("c.png"))
    check("BI_BITFIELDS の DIB も読める", w3, 8)
    big = out.with_name("big.png")
    big.write_bytes(tiny_png(1600, 900, (10, 120, 200)))
    made = clipgfx.save_preview(big, out.with_name("big.prev.png"), 640, 480)
    check("大きい画像は小さめの版を作る", made, True)
    check("小さめの版の大きさ",
          clipgfx.png_size(out.with_name("big.prev.png").read_bytes()),
          (640, 360))
    check("小さい画像は作らない",
          clipgfx.save_preview(out, out.with_name("x.prev.png"), 640, 480),
          False)
    dib = clipgfx.png_to_dib(big)
    check("貼り付け用の DIB を作れる", clipgfx.dib_size(dib), (1600, 900))
    check("DIB は 24bit", struct.unpack_from("<H", dib, 14)[0], 24)
    bmp, tw, th = clipgfx.load_scaled(big, 120, 120)
    check("縮めて読み込める", (tw, th), (120, 68))
    clipgfx.dispose(bmp)
    check("縦横比を保って収める", clipgfx.fit(1000, 500, 200, 200),
          (200, 100))


# ---------------------------------------------------------------- 読み書き


def test_data() -> None:
    section("7 クリップボードの形（本物には触らない）")
    raw = clipdata.hdrop(["C:\\a.txt", "C:\\b c.png"])
    check("CF_HDROP の頭は 20 バイト", struct.unpack_from("<I", raw)[0], 20)
    names = raw[20:].decode("utf-16-le").split("\x00")
    check("ファイル名が並ぶ", names[:2], ["C:\\a.txt", "C:\\b c.png"])
    one = clipdata.Captured(kind="text", text="abc")
    two = clipdata.Captured(kind="text", text="abc")
    check("同じ文字は同じ指紋", one.hash(), two.hash())
    check("文字の指紋は保存側とそろう", one.hash(),
          clipstore.text_hash("abc"))
    img = clipdata.Captured(kind="image", png=b"\x89PNGxxxx")
    check("画像の指紋", len(img.hash()), 40)
    marks = clipdata.private_marks()
    check("履歴に残さない印は 3 つ", len(marks), 3)
    dryrun.reset()
    seq = clipdata.write(0, text="こんにちは", private=True)
    rows = [e for e in dryrun.entries() if e["kind"] == "clip_put"]
    check("から打ちでは書かずに記録だけ", (seq, rows[-1]["text"]),
          (1, "こんにちは"))
    check("秘密の印も記録される", rows[-1]["private"], True)


# ---------------------------------------------------------------- 操作


def make_model() -> tuple[PopupModel, ClipStore]:
    store = ClipStore(_SANDBOX / "data" / "m.db", _SANDBOX / "data" / "mi")
    gid = store.add_group("よく使う")
    store.add_group("メール")
    for text in ("会議の議事録です", "https://example.com/page",
                 "#3366ff", "カタカナのメモ", "second line\nmore"):
        store.add(kind="text", hash_=clipstore.text_hash(text), text=text,
                  app="chrome.exe")
        time.sleep(0.005)
    store.add(kind="text", hash_=clipstore.text_hash(MAIL_INFO),
              text=MAIL_INFO, group_id=gid, title="会社のメール")

    def tabs() -> list[Tab]:
        out = [Tab(HISTORY, "履歴", store.history_count())]
        out += [Tab(g.id, g.name, g.count) for g in store.groups()]
        return out

    model = PopupModel(tabs, lambda gid: store.items(gid))
    return model, store


def test_model() -> None:
    section("8 窓の操作（キー・検索・タブ・まとめて選ぶ）")
    model, store = make_model()
    model.open()
    check("開くと履歴", model.gid, HISTORY)
    check("新しい順に並ぶ", model.view[0].snippet, "second line\nmore")
    model.key(clipmodel.VK_DOWN)
    check("下で次へ", model.sel, 1)
    cmd = model.key(clipmodel.VK_RETURN)
    check("Enter で貼る", (cmd.kind, cmd.plain), ("paste", False))
    cmd = model.key(clipmodel.VK_RETURN, shift=True)
    check("Shift+Enter で書式なし", cmd.plain, True)
    cmd = model.key(clipmodel.VK_RETURN, ctrl=True)
    check("Ctrl+Enter はコピーだけ", cmd.kind, "copy")
    for ch in "かたかな":
        model.char(ch)
    check("ひらがなでカタカナを探せる",
          [c.snippet for c in model.view], ["カタカナのメモ"])
    model.key(clipmodel.VK_ESCAPE)
    check("Esc で検索を消す", (model.search.text, len(model.view)), ("", 5))
    cmd = model.key(clipmodel.VK_ESCAPE)
    check("もう一度 Esc で閉じる", cmd.kind, "close")
    for ch in "EXAMPLE":
        model.char(ch)
    check("大文字小文字を区別しない", len(model.view), 1)
    model.key(clipmodel.VK_BACK, ctrl=True)
    check("Ctrl+Backspace で単語ごと消す", model.search.text, "")
    model.key(clipmodel.VK_TAB)
    check("Tab で次のグループ", model.tabs[model.tab].name, "よく使う")
    check("グループの中身", model.view[0].title, "会社のメール")
    for ch in "会社":
        model.char(ch)
    check("名前でも探せる", len(model.view), 1)
    model.search.clear()
    model.set_tab(0)
    model.key(clipmodel.VK_RIGHT)
    check("検索が空なら → でもグループを替える", model.tab, 1)
    model.key(clipmodel.VK_LEFT)
    check("← で戻る", model.tab, 0)
    model.next_tab(-1)
    check("最初から前へ戻ると最後へ", model.tabs[model.tab].name, "メール")
    model.set_tab(0)
    model.key(clipmodel.VK_DOWN, shift=True)
    model.key(clipmodel.VK_DOWN, shift=True)
    check("Shift+↓ でまとめて選ぶ", len(model.multi), 3)
    cmd = model.key(clipmodel.VK_RETURN)
    check("まとめて貼る", len(cmd.ids), 3)
    model.multi = []
    model.click(3, ctrl=True)
    model.click(1, ctrl=True)
    check("Ctrl+クリックで選んだ順を覚える",
          model.multi, [model.view[3].id, model.view[1].id])
    model.multi = []
    cmd = model.key(ord("3"), ctrl=True)
    check("Ctrl+3 で 3 番目を貼る", cmd.ids, [model.view[2].id])
    model.cycle_kind()
    check("種類で絞る（文字）", model.kind, "text")
    model.set_kind("link")
    check("リンクだけ", [c.snippet for c in model.view],
          ["https://example.com/page"])
    model.set_kind("colour")
    check("色だけ", [c.snippet for c in model.view], ["#3366ff"])
    model.set_kind("all")
    cmd = model.key(clipmodel.VK_DELETE)
    check("Delete で消す", cmd.kind, "delete")
    check("Ctrl+Z は元に戻す",
          model.key(ord("Z"), ctrl=True).kind, "undo")
    check("Ctrl+P で固定", model.key(ord("P"), ctrl=True).kind, "pin")
    check("Ctrl+G でグループへ",
          model.key(ord("G"), ctrl=True).kind, "group_menu")
    check("履歴では並べ替えない",
          model.key(clipmodel.VK_UP, ctrl=True, shift=True), None)
    model.click_to_paste = True
    cmd = model.click(2)
    check("クリック 1 回で貼る", cmd.kind, "paste")
    model.click_to_paste = False
    cmd = model.click(2)
    check("2 回クリックの設定では選ぶだけ", cmd.kind, "repaint")
    cmd = model.double_click(2)
    check("ダブルクリックで貼る", cmd.kind, "paste")

    section("9 検索欄の編集")
    box = clipmodel.SearchBox()
    box.insert("hello world")
    box.left(word=True)
    check("Ctrl+← で単語の頭へ", box.caret, 6)
    box.left(shift=True, word=True)
    check("Shift で選ぶ", box.selection(), (0, 6))
    box.insert("bye ")
    check("選んだところを置き換える", box.text, "bye world")
    box.select_all()
    box.backspace()
    check("全部選んで消す", box.text, "")
    box.insert("改行\nなし")
    check("改行は空白にする", box.text, "改行 なし")

    section("10 貼る前の加工と {date}")
    check("前後の空白を取る", clipmodel.transform("  a  \n b \n", "trim"),
          "a\n b")
    check("和文の改行はそのままつなぐ",
          clipmodel.transform("今日は\n晴れです", "oneline"), "今日は晴れです")
    check("英文の改行は空白に",
          clipmodel.transform("hello\nworld", "oneline"), "hello world")
    check("全角英数を半角に", clipmodel.transform("ＡＢＣ１２３　x", "half"),
          "ABC123 x")
    check("半角を全角に", clipmodel.transform("A1 ", "full"), "Ａ１\u3000")
    check("引用", clipmodel.transform("a\nb", "quote"), "> a\n> b")
    stamp = time.mktime((2026, 10, 11, 14, 5, 0, 0, 0, -1))
    check("{date}", clipmodel.expand("{date}", now=stamp), "2026/10/11")
    check("{time}", clipmodel.expand("{time}", now=stamp), "14:05")
    check("{weekday}", clipmodel.expand("{weekday}", now=stamp), "日")
    check("書き方を選ぶ", clipmodel.expand("{date:%Y-%m-%d}", now=stamp),
          "2026-10-11")
    check("{clipboard}", clipmodel.expand("「{clipboard}」", clipboard="x"),
          "「x」")
    check("{{ は { のまま", clipmodel.expand("{{date}}", now=stamp),
          "{date}")
    check("知らない名前はそのまま", clipmodel.expand("{name}"), "{name}")
    check("見え方：メール", clipmodel.look(store_clip(MAIL_INFO)), "mail")


def store_clip(text: str) -> clipstore.Clip:
    return clipstore.Clip(id=1, group_id=0, kind="text", snippet=text)


# ---------------------------------------------------------------- 見た目


def sample_store() -> tuple[ClipStore, int]:
    """見た目の画像用に、いろいろな種類を入れた履歴を作る。"""
    base = _SANDBOX / "data" / "shots"
    store = ClipStore(base / "s.db", base / "img")
    gid = store.add_group("よく使う")
    store.add_group("メール")
    store.add_group("定型文")
    now = time.time()
    rows = [
        ("text", "明日の打ち合わせは 10 時からに変更になりました。\n"
                 "資料は共有フォルダに入れてあります。", "slack.exe", 40),
        ("image", "", "SnippingTool.exe", 300),
        ("text", "https://www.example.co.jp/news/2026/10/release",
         "chrome.exe", 900),
        ("text", "#242460", "Code.exe", 3600 * 2),
        ("files", "", "explorer.exe", 3600 * 5),
        ("text", "お世話になっております。株式会社サンプルの山田です。",
         "OUTLOOK.EXE", 86400 + 60),
        ("text", "def hello():\n    print('hello')", "Code.exe", 86400 * 3),
        ("text", MAIL_INFO, "chrome.exe", 86400 * 9),
    ]
    for kind, text, app, age in rows:
        if kind == "text":
            cid = store.add(kind="text", hash_=clipstore.text_hash(text),
                            text=text, app=app)
        elif kind == "image":
            name = "shot.png"
            (base / "img").mkdir(parents=True, exist_ok=True)
            path = base / "img" / name
            # 縞の入った絵（縮めたときの見え方を確かめる）
            w, h = 1280, 720
            raw = bytearray()
            for y in range(h):
                raw.append(0)
                band = (y // 60) % 2
                for x in range(w):
                    if band:
                        raw += bytes((36, 36, 96))
                    else:
                        raw += bytes((224, 72 + x * 100 // w, 58))
            png = (b"\x89PNG\r\n\x1a\n" + _chunk(b"IHDR", struct.pack(
                ">IIBBBBB", w, h, 8, 2, 0, 0, 0))
                + _chunk(b"IDAT", zlib.compress(bytes(raw)))
                + _chunk(b"IEND", b""))
            path.write_bytes(png)
            clipgfx.save_preview(path, base / "img" / "shot.prev.png",
                                 720, 540)
            cid = store.add(kind="image", hash_="img1", image=name,
                            width=w, height=h, app=app, size=len(png))
        else:
            cid = store.add(kind="files", hash_="files1",
                            files=[r"C:\Users\me\Documents\見積書.xlsx",
                                   r"C:\Users\me\Documents\提案書.pptx"],
                            app=app)
        store._exec("UPDATE clips SET created = ? WHERE id = ?",
                    (now - age, cid))
    store._changed()
    first = store.items()[0]
    store.set_pinned([store.items()[3].id], True)
    store.mark_used([first.id])
    for title, text, secret in (("会社のメール", MAIL_WORK, False),
                                ("社内システム", "Pa55word!", True),
                                ("住所", "東京都千代田区丸の内 1-1-1", False),
                                ("", "いつもありがとうございます。", False)):
        store.add(kind="text", hash_=clipstore.text_hash(text), text=text,
                  group_id=gid, title=title, secret=secret)
    return store, gid


def _chunk(tag: bytes, data: bytes) -> bytes:
    return (struct.pack(">I", len(data)) + tag + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))


def make_shots(out_dir: Path) -> list[Path]:
    from app import clipview  # noqa: PLC0415
    store, gid = sample_store()
    thumbs: dict[tuple[int, int, int], tuple[int, int, int]] = {}

    def thumb(clip, w, h):  # noqa: ANN001, ANN202
        key = (clip.id, w, h)
        if key not in thumbs:
            prev = store.image_dir / clipstore.preview_name(clip.image)
            src = prev if prev.exists() else store.image_dir / clip.image
            thumbs[key] = clipgfx.load_scaled(src, w, h)
        return thumbs[key]

    def tabs() -> list[Tab]:
        out = [Tab(HISTORY, "", store.history_count())]
        out += [Tab(g.id, g.name, g.count) for g in store.groups()]
        return out

    made = []
    cases = [
        ("history-dark", "dark", "right", 1.5, None, ""),
        ("history-light", "light", "right", 1.5, None, ""),
        ("group-dark", "dark", "right", 1.5, gid, ""),
        ("search-light", "light", "none", 1.5, None, "example"),
        ("bottom-dark-100", "dark", "bottom", 1.0, None, ""),
        ("empty-dark", "dark", "right", 1.5, 0, "zzzz"),
    ]
    for name, theme, preview, scale, tab, query in cases:
        model = PopupModel(tabs, lambda g: store.items(g))
        model.open(tab)
        for ch in query:
            model.char(ch)
        if name == "history-dark":
            model.select(1)
            model.multi = []
        view = clipview.ClipView()
        view.configure(theme=theme, accent="#0f6cbd", font_size="medium",
                       preview=preview, two_lines=True, show_meta=True,
                       show_numbers=True, hotkey_label="Alt+V")
        w, h = (640, 440) if preview != "bottom" else (520, 560)
        canvas = clipgfx.Canvas(round(w * scale), round(h * scale))
        try:
            view.paint(canvas, model, scale, thumb=thumb,
                       full_text=lambda c: store.full_text(c.id))
            path = out_dir / f"clip-{name}.png"
            canvas.save_png(path)
            made.append(path)
        finally:
            canvas.close()
    for bmp, _w, _h in thumbs.values():
        clipgfx.dispose(bmp)
    return made


def wait_for(fn, timeout: float = 5.0) -> bool:  # noqa: ANN001
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if fn():
            return True
        time.sleep(0.05)
    return False


def entries(kind: str) -> list[dict]:
    return [e for e in dryrun.entries() if e.get("kind") == kind]


def test_service() -> None:
    section("12 本体を通しで（から打ち・本物のクリップボードとキーは使わない）")
    import ctypes  # noqa: PLC0415
    from app.clipwin import ClipService  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    user32 = ctypes.WinDLL("user32")
    seq_before = user32.GetClipboardSequenceNumber()
    cfg = Config(_SANDBOX / "svc-config.json")
    cfg.set("clip_secret_clear_s", 1)
    cfg.set("clip_show_frequent", False)
    store = ClipStore(_SANDBOX / "data" / "svc.db", _SANDBOX / "data" / "svc")
    svc = ClipService(cfg, store=store)
    check("から打ちでは画面に出さない", svc.headless, True)
    svc.start()
    check("スレッドが動く", svc.is_alive() and svc.last_error == "", True)
    check("最初のグループができる", [g.name for g in store.groups()],
          ["よく使う"])
    svc.simulate_capture(text="一つ目", app="notepad.exe")
    svc.simulate_capture(text="二つ目", app="chrome.exe")
    svc.simulate_capture(png=tiny_png(64, 48, (200, 30, 30)))
    svc.simulate_capture(files=[str(_SANDBOX / "logs")])
    ok = wait_for(lambda: store.history_count() == 4)
    check("コピーしたものが 4 件たまる", ok, True)
    image = [c for c in store.items() if c.kind == "image"]
    check("画像は PNG で保存", bool(image) and (
        store.image_dir / image[0].image).exists(), True)
    svc.simulate_capture(png=tiny_png(64, 48, (200, 30, 30)))
    time.sleep(0.4)
    check("同じ画像は重ねない", store.history_count(), 4)

    dryrun.reset()
    svc.open(target=4242)
    wait_for(lambda: entries("clip_show"))
    check("ショートカットで一覧が出る（記録だけ）",
          entries("clip_show")[-1]["items"], 4)
    svc.press_hotkey()
    wait_for(lambda: svc.model.gid != HISTORY)
    check("もう一度押すと次のグループ", svc.model.tabs[svc.model.tab].name,
          "よく使う")
    svc.press_hotkey()
    wait_for(lambda: svc.model.gid == clipstore.DOWNLOADS)
    check("その次は「ダウンロード」（いちばん後ろ）", svc.model.gid,
          clipstore.DOWNLOADS)
    svc.press_hotkey()
    wait_for(lambda: svc.model.gid == HISTORY)
    check("さらに押すと履歴に戻る", svc.model.gid, HISTORY)
    # 一番上は files（最後にコピー）。↓ を 3 回で「一つ目」
    for _ in range(3):
        svc.key(clipmodel.VK_DOWN)
    svc.key(clipmodel.VK_RETURN)
    wait_for(lambda: entries("clip_paste"))
    pasted = entries("clip_paste")
    check("Enter で貼る（中身が記録される）",
          pasted[-1]["text"] if pasted else None, "一つ目")
    check("クリップボードへは書かずに記録だけ",
          entries("clip_put")[-1]["text"], "一つ目")
    check("貼るキーも送らずに記録だけ",
          entries("paste_keys")[-1]["method"], "ctrl_v")
    check("貼ったら閉じる", svc.visible, False)
    check("使った回数が増える",
          [c.use_count for c in store.items() if c.snippet == "一つ目"],
          [1])
    check("使った順なら一番上へ", store.items()[0].snippet, "一つ目")

    section("13 本体：消す・元に戻す・固定・グループ・秘密")
    svc.open(target=4242)
    wait_for(lambda: svc.visible)
    svc.key(clipmodel.VK_DELETE)
    wait_for(lambda: store.history_count() == 3)
    check("Delete で消える", store.history_count(), 3)
    svc.key(ord("Z"), ctrl=True)
    wait_for(lambda: store.history_count() == 4)
    check("Ctrl+Z で戻る", store.history_count(), 4)
    svc.key(ord("P"), ctrl=True)
    wait_for(lambda: store.items()[0].pinned)
    check("Ctrl+P で固定", store.items()[0].pinned, True)
    svc.key(clipmodel.VK_ESCAPE)
    wait_for(lambda: not svc.visible)
    gid = store.groups()[0].id
    res = svc.api("clip_item_save", {"group_id": gid, "title": "社内",
                                     "text": "S3cret!", "secret": True})
    check("設定画面から秘密の言葉を足す", res.get("ok"), True)
    got = svc.api("clip_item_get", {"id": res["id"]})
    check("設定画面では中身を見られる", got["item"]["text"], "S3cret!")
    listed = svc.api("clip_items", {"group_id": gid})["items"]
    check("一覧には中身を出さない", listed[0]["text"], "")
    dryrun.reset()
    svc.open(gid, target=4242)
    wait_for(lambda: svc.visible)
    svc.key(clipmodel.VK_RETURN)
    wait_for(lambda: entries("clip_paste"))
    put = entries("clip_put")
    check("秘密を貼るときは履歴に残さない印", put[-1]["private"]
          if put else None, True)
    check("秘密の中身が貼られる", entries("clip_paste")[-1]["text"],
          "S3cret!")
    ok = wait_for(lambda: entries("clip_clear"), timeout=4.0)
    check("しばらくするとクリップボードから消す", ok, True)
    res = svc.api("clip_item_save", {"group_id": gid, "title": "今日",
                                     "text": "日付は{date}"})
    dryrun.reset()
    svc.open(gid, target=4242)
    wait_for(lambda: svc.visible)
    svc.key(clipmodel.VK_DOWN)
    svc.key(clipmodel.VK_RETURN)
    wait_for(lambda: entries("clip_paste"))
    text = entries("clip_paste")[-1]["text"]
    check("{date} が今日の日付になる",
          text == "日付は" + time.strftime("%Y/%m/%d"), True)
    dryrun.reset()
    svc.open(target=0)
    wait_for(lambda: svc.visible)
    svc.key(clipmodel.VK_RETURN)
    wait_for(lambda: entries("clip_copy"))
    check("貼り先がないときはコピーだけ", bool(entries("clip_copy")), True)
    check("そのときは貼るキーを送らない", entries("paste_keys"), [])

    section("14 本体：設定画面とのやり取り")
    over = svc.api("clip_overview", {})
    check("概要", (over["history"], len(over["groups"])), (4, 1))
    res = svc.api("clip_group_add", {"group_name": "メール"})
    check("グループを作る", res.get("ok"), True)
    hist = svc.api("clip_items", {"group_id": 0})["items"]
    target_id = [h["id"] for h in hist if h["text"] == "二つ目"][0]
    svc.api("clip_item_move", {"ids": [target_id], "group_id": res["id"]})
    check("履歴からグループへ移す",
          [c.id for c in store.items(res["id"])], [target_id])
    bad = svc.api("clip_group_hotkey", {"id": res["id"],
                                        "hotkey": cfg.str_("clip_hotkey")})
    check("一覧のキーと同じキーは断る", bad.get("ok"), False)
    good = svc.api("clip_group_hotkey", {"id": res["id"],
                                         "hotkey": "ctrl+alt+m"})
    check("グループ専用のキーを付けられる", good.get("ok"), True)
    exported = svc.api("clip_export", {})
    check("書き出し", "メール" in exported["text"], True)
    check("画像を設定画面へ渡せる",
          svc.image_bytes(image[0].id)[:4], b"\x89PNG")
    path = _SANDBOX / "logs" / "svc.png"
    check("窓の絵を画像にできる", svc.snapshot(path) and path.exists(),
          True)
    test_window_messages(svc)
    test_endurance(svc)
    svc.stop()
    svc.join(3.0)
    check("止められる", svc.is_alive(), False)
    seq_after = user32.GetClipboardSequenceNumber()
    if seq_after != seq_before:
        print("  （参考）試験中にクリップボードが変わりました。"
              "利用者がコピーした可能性があります")


class _Errors:
    """ログに「例外」が出たかを数える。"""

    def __init__(self) -> None:
        import logging  # noqa: PLC0415
        self.rows: list[str] = []
        outer = self

        class Handler(logging.Handler):
            def emit(self, record: logging.LogRecord) -> None:
                if record.levelno >= logging.ERROR or record.exc_info:
                    outer.rows.append(record.getMessage())
        self.handler = Handler()
        logging.getLogger().addHandler(self.handler)

    def close(self) -> None:
        import logging  # noqa: PLC0415
        logging.getLogger().removeHandler(self.handler)


def test_window_messages(svc) -> None:  # noqa: ANN001
    """隠れたままの窓に、同じプロセスの中からメッセージを送る。

    本物のキーやマウスではない（SendInput を使わず、自分の窓に
    SendMessage するだけ）。画面にも出さず、前面の窓も替えない。
    """
    section("15 窓のメッセージ処理（隠れた窓・自分のプロセスの中だけ）")
    import ctypes  # noqa: PLC0415
    from ctypes import wintypes  # noqa: PLC0415
    from app import clipwin  # noqa: PLC0415
    user32 = ctypes.WinDLL("user32")
    send = user32.SendMessageW
    send.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM,
                     wintypes.LPARAM]
    send.restype = ctypes.c_ssize_t
    errors = _Errors()
    svc.open(target=4242)
    wait_for(lambda: svc.visible)
    hwnd = svc._hwnd
    check("窓はあるが見えていない", (bool(hwnd),
                                    bool(user32.IsWindowVisible(hwnd))),
          (True, False))

    def lp(x: int, y: int) -> int:
        return (y & 0xFFFF) << 16 | (x & 0xFFFF)

    rect = clipwin.RECT()
    user32.GetWindowRect(hwnd, ctypes.byref(rect))
    corner = send(hwnd, clipwin.WM_NCHITTEST, 0,
                  lp(rect.left + 1, rect.top + 1))
    check("左上の角は大きさを変える所", corner, 13)
    send(hwnd, clipwin.WM_PAINT, 0, 0)
    lay = svc.view.layout
    check("描いたあとは配置が決まる", lay.row_h > 0, True)
    middle = send(hwnd, clipwin.WM_NCHITTEST, 0,
                  lp(rect.left + lay.search.x + 20,
                     rect.top + lay.search.y + 10))
    check("検索欄はふつうの中身", middle, 1)
    gap_x = (lay.tab_add.right + lay.kinds[0].x) // 2
    caption = send(hwnd, clipwin.WM_NCHITTEST, 0,
                   lp(rect.left + gap_x, rect.top + lay.tab_bar.y + 4))
    check("タブの横の空いた所は動かすための帯", caption, 2)
    info = clipwin.MINMAXINFO()
    send(hwnd, clipwin.WM_GETMINMAXINFO, 0, ctypes.addressof(info))
    check("小さくしすぎない", info.ptMinTrackSize.x > 300, True)
    before = svc.model.sel
    send(hwnd, clipwin.WM_KEYDOWN, clipmodel.VK_DOWN, 0)
    check("↓ のメッセージで次へ", svc.model.sel, before + 1)
    send(hwnd, clipwin.WM_CHAR, ord("x"), 0)
    check("文字のメッセージで検索欄へ", svc.model.search.text, "x")
    send(hwnd, clipwin.WM_CHAR, 0xD83D, 0)       # 絵文字の前半
    send(hwnd, clipwin.WM_CHAR, 0xDE00, 0)       # 後半
    check("2 つに分かれた文字もつなげる", svc.model.search.text,
          "x\U0001F600")
    send(hwnd, clipwin.WM_KEYDOWN, clipmodel.VK_ESCAPE, 0)
    check("Esc で検索を消す", svc.model.search.text, "")
    send(hwnd, clipwin.WM_MOUSEWHEEL, (-120 & 0xFFFF) << 16, 0)
    send(hwnd, clipwin.WM_MOUSEMOVE, 0,
         lp(lay.listing.x + 40, lay.listing.y + lay.row_h * 3 // 2))
    check("マウスを乗せた行を選ぶ", svc.model.sel, svc.model.top + 1)
    send(hwnd, clipwin.WM_SYSCOMMAND, clipwin.SC_KEYMENU, 0)
    send(hwnd, clipwin.WM_SIZE, 0, 0)
    send(hwnd, clipwin.WM_PAINT, 0, 0)
    send(hwnd, clipwin.WM_ACTIVATE, 0, 0)        # ほかの所を押した
    check("ほかの所を押すと閉じる", svc.visible, False)
    errors.close()
    check("窓の処理で例外が出ていない", errors.rows, [])


def test_recipes() -> None:
    section("17 文章変換のレシピ一覧（キー 1 つで選んで録音）")
    from app.clipwin import ClipService  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    cfg = Config(_SANDBOX / "recipe-config.json")
    started: list[str] = []
    stopped: list[int] = []
    recording = [False]
    svc = ClipService(cfg, store=ClipStore(_SANDBOX / "data" / "r.db",
                                           _SANDBOX / "data" / "r"),
                      start_recipe=started.append,
                      is_recording=lambda: recording[0],
                      stop_recording=lambda: stopped.append(1))
    svc.start()
    from app.recipes import from_config  # noqa: PLC0415
    from app.i18n import language  # noqa: PLC0415
    enabled = [r for r in cfg.get("ai_custom_instructions") or []
               if r.get("enabled", True)]
    expected_recipes = len(from_config(cfg.get("ai_custom_instructions") or [],
                                       language()))
    dryrun.reset()
    svc.press_recipe_hotkey()
    wait_for(lambda: svc.visible and svc.mode == "recipe")
    shows = entries("recipe_show")
    check("キーでレシピ一覧が出る", bool(shows) and shows[-1]["items"],
          expected_recipes)
    path = ROOT / "logs" / "clipshots" / "recipe-dark.png"
    check("レシピ一覧の絵を画像にできる", svc.snapshot(path), True)
    svc.type_text("敬語")
    wait_for(lambda: len(svc.rmodel.view) < expected_recipes)
    check("検索で絞れる", [r.id for r in svc.rmodel.view][:1], ["polite"])
    svc.key(clipmodel.VK_RETURN)
    wait_for(lambda: started)
    check("Enter で選ぶと、その変換で録音を頼む", started, ["polite"])
    check("選んだら閉じる", svc.visible, False)
    check("選んだことが記録される", entries("recipe_pick")[-1]["id"],
          "polite")
    svc.press_recipe_hotkey()
    wait_for(lambda: svc.visible)
    svc.key(ord("2"))
    wait_for(lambda: len(started) == 2)
    check("数字キーで直接選べる", started[-1], enabled[0]["id"])
    svc.press_recipe_hotkey()
    wait_for(lambda: svc.visible)
    svc.press_recipe_hotkey()
    wait_for(lambda: not svc.visible)
    check("もう一度押すと閉じる", svc.visible, False)
    recording[0] = True
    svc.press_recipe_hotkey()
    wait_for(lambda: stopped)
    check("録音中に押すと止める（変換して入力）", (len(stopped),
                                                    svc.visible), (1, False))
    recording[0] = False
    svc.press_recipe_hotkey()
    wait_for(lambda: svc.visible)
    svc.press_hotkey()
    wait_for(lambda: svc.mode == "clip")
    check("クリップボードのキーで一覧を切り替えられる", svc.mode, "clip")
    svc.press_recipe_hotkey()
    wait_for(lambda: svc.visible and svc.mode == "recipe")
    check("最初は「すべて」カテゴリ", svc.rmodel.category, "all")
    all_count = len(svc.rmodel.view)
    svc.key(clipmodel.VK_TAB)
    wait_for(lambda: svc.rmodel.category == "text")
    check("Tab で「文章作成・AI」へ", svc.rmodel.category, "text")
    check("文章作成系に絞られる", len(svc.rmodel.view) < all_count, True)
    svc.key(clipmodel.VK_TAB)
    wait_for(lambda: svc.rmodel.category == "tools")
    check("もう一度 Tab で「ツール・計算」へ", svc.rmodel.category, "tools")
    tab_box = svc.rview.layout.tabs[1]
    svc._on_up(tab_box.x + tab_box.w // 2, tab_box.y + tab_box.h // 2)
    wait_for(lambda: svc.rmodel.category == "text")
    check("タブクリックで「文章作成・AI」へ", svc.rmodel.category, "text")
    svc.key(clipmodel.VK_ESCAPE)
    wait_for(lambda: not svc.visible)
    svc.stop()
    svc.join(3.0)


def test_downloads() -> None:
    section("19 「ダウンロード」タブ（使い捨てのフォルダだけを見る）")
    from app import recentfiles  # noqa: PLC0415
    from app.clipwin import ClipService  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    base = _SANDBOX / "dl"
    (base / "sub").mkdir(parents=True)
    (base / "report.pdf").write_bytes(b"%PDF-1.4 test")
    (base / "photo.png").write_bytes(tiny_png(80, 50, (20, 140, 200)))
    (base / "sub" / "deep.txt").write_text("deep", "utf-8")
    (base / "half.crdownload").write_bytes(b"partial")
    (base / "~$temp.docx").write_bytes(b"office temp")
    # 作られた日時も見るので、ここで作るファイルは必ず「新しい」。
    # 古いものを除く確かめは、days=0 相当（1 日）でも新しいことで代える
    root = recentfiles.Root(base, "ダウンロード", 2)
    found = recentfiles.scan([root], days=7)
    names = sorted(f.name for f in found)
    check("新しいファイルだけ・書きかけと一時ファイルは除く", names,
          ["deep.txt", "photo.png", "report.pdf"])
    check("下の階層は場所の名前に出る",
          [f.where for f in found if f.name == "deep.txt"],
          ["ダウンロード\\sub"])
    cfg = Config(_SANDBOX / "dl-config.json")
    cfg.set("clip_downloads", "second")
    svc = ClipService(cfg, store=ClipStore(_SANDBOX / "data" / "d.db",
                                           _SANDBOX / "data" / "d"))
    svc.recent_roots = [root]
    svc.recent.scan_now()
    svc.start()
    dryrun.reset()
    svc.open(target=4242)
    wait_for(lambda: svc.visible)
    svc.press_hotkey()
    wait_for(lambda: svc.model.gid == clipstore.DOWNLOADS)
    check("「履歴のすぐ後」なら、もう一度押すとダウンロード",
          svc.model.gid, clipstore.DOWNLOADS)
    check("3 件ならぶ", len(svc.model.view), 3)
    path = ROOT / "logs" / "clipshots" / "downloads-dark.png"
    check("ダウンロードの絵を画像にできる", svc.snapshot(path), True)
    target = [i for i, c in enumerate(svc.model.view)
              if c.title == "photo.png"][0]
    for _ in range(target):
        svc.key(clipmodel.VK_DOWN)
    svc.key(clipmodel.VK_DELETE)
    time.sleep(0.3)
    check("Delete でもファイルは消さない", (base / "photo.png").exists(),
          True)
    svc.key(clipmodel.VK_RETURN)
    wait_for(lambda: entries("clip_put"))
    put = entries("clip_put")[-1]
    check("Enter でファイルとして貼る（場所＋絵）",
          (put["files"], put["image"]), ([str(base / "photo.png")], True))
    svc.open(clipstore.DOWNLOADS, target=4242)
    wait_for(lambda: svc.visible)
    dryrun.reset()
    target_idx = [i for i, c in enumerate(svc.model.view)
                  if c.title == "photo.png"][0]
    svc.call(lambda: svc._drag(target_idx))
    wait_for(lambda: entries("clip_drag"))
    drag_entry = entries("clip_drag")[-1]
    check("ダウンロードファイルをドラッグできる（実体ファイル）",
          drag_entry["files"], [str(base / "photo.png")])
    gid = svc.store.groups()[0].id
    svc.call(lambda: svc._move([svc.model.view[0].id], gid))
    wait_for(lambda: svc.store.group(gid).count == 1)
    check("グループには場所として入る（ファイルは動かさない）",
          (svc.store.items(gid)[0].kind, (base / "photo.png").exists()),
          ("files", True))
    svc.stop()
    svc.join(3.0)


def test_review_fixes() -> None:
    section("20 レビューで見つかった不具合が戻っていない")
    from app import clipview  # noqa: PLC0415
    from app.clipwin import ClipService  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    cfg = Config(_SANDBOX / "review.json")
    svc = ClipService(cfg, store=ClipStore(_SANDBOX / "data" / "rv.db",
                                           _SANDBOX / "data" / "rv"))
    gid = svc.store.add_group("仕事")
    check("Ctrl+V は選べない", bool(svc.key_problem("ctrl+v")), True)
    check("1 キーだけは選べない", bool(svc.key_problem("q")), True)
    check("読めないキーは選べない", bool(svc.key_problem("ctrl+@@")), True)
    check("変換の一覧のキーとぶつからない",
          bool(svc.key_problem(cfg.str_("recipe_hotkey"), group_id=gid)),
          True)
    check("無変換は 1 キーでも選べる", svc.key_problem("muhenkan"), "")
    check("空いているキーは選べる", svc.key_problem("ctrl+alt+k"), "")
    # 描いていない行（下の余り）は押せない
    model, _store = make_model()
    model.open()
    view = clipview.ClipView()
    canvas = clipgfx.Canvas(640, 300)
    try:
        view.paint(canvas, model, 1.0, thumb=lambda c, w, h: (0, 0, 0),
                   full_text=lambda c: c.snippet)
    finally:
        canvas.close()
    lay = view.layout
    below = lay.listing.y + 3 + lay.row_h * model.page + 2
    if below < lay.listing.bottom:
        check("描いていない行は押せない",
              view.hit(20, below, model)[0] != "row", True)
    else:
        check("描いていない行は押せない（余りなし）", True, True)
    # まとめて選んだあと、ほかの行を押すとその行だけ
    model.click_to_paste = True
    model.click(1, ctrl=True)
    model.click(2, ctrl=True)
    cmd = model.click(0)
    check("仲間でない行を押すと、その行だけ貼る",
          (cmd.ids, model.multi), ([model.view[0].id], []))
    # 履歴へ戻すと、名前を付けたほうが残る
    store = svc.store
    text = "戻すときの試験"
    hid = store.add(kind="text", hash_=clipstore.text_hash(text), text=text)
    tid = store.add(kind="text", hash_=clipstore.text_hash(text), text=text,
                    group_id=gid, title="名前つき")
    store.move([tid], HISTORY)
    kept = [c for c in store.items(HISTORY) if c.snippet == text]
    check("名前の付いたほうが履歴に残る",
          [(c.id, c.title) for c in kept], [(tid, "名前つき")])
    check("古いほうは消える", store.get(hid), None)


def test_api_contract() -> None:
    section("18 設定画面と本体のやり取り（JS の送り方をまねる）")
    import re  # noqa: PLC0415
    from app.clipwin import ClipService  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    js = (ROOT / "app" / "web" / "app.js").read_text("utf-8")
    m = re.search(r'const runAction = \(name, extra\) => '
                  r'api\("/api/action", (.*)\);', js)
    check("runAction の形が読める", bool(m), True)
    check("操作の名前は最後に置く（上書きされない）",
          m and m.group(1).replace(" ", "") == "{...(extra||{}),name}", True)
    svc = ClipService(Config(_SANDBOX / "contract.json"),
                      store=ClipStore(_SANDBOX / "data" / "c.db",
                                      _SANDBOX / "data" / "c"))

    def run(action: str, extra: dict) -> dict:
        body = {**extra, "name": action}          # JS と同じ並べ方
        return svc.api(body["name"], body)

    res = run("clip_group_add", {"group_name": "仕事"})
    check("グループを作れる（名前の欄がぶつからない）",
          (res.get("ok"), [g.name for g in svc.store.groups()]),
          (True, ["仕事"]))
    run("clip_group_rename", {"id": res["id"], "group_name": "仕事用"})
    check("名前を変えられる", svc.store.group(res["id"]).name, "仕事用")
    actions = set(re.findall(r'runAction\("(clip_[a-z_]+)"', js))
    source = (ROOT / "app" / "clipwin.py").read_text("utf-8")
    missing = sorted(a for a in actions if f'name == "{a}"' not in source)
    check("画面が使う clip_ 操作は、本体がすべて受け付ける", missing, [])


def _usage() -> tuple[int, int, float]:
    """(GDI の数, USER の数, 使っているメモリ MB)。"""
    import ctypes  # noqa: PLC0415
    from ctypes import wintypes  # noqa: PLC0415

    class Counters(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                    ("PrivateUsage", ctypes.c_size_t)]
    user32 = ctypes.WinDLL("user32")
    kernel32 = ctypes.WinDLL("kernel32")
    psapi = ctypes.WinDLL("psapi")
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    user32.GetGuiResources.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE,
                                           ctypes.POINTER(Counters),
                                           wintypes.DWORD]
    me = kernel32.GetCurrentProcess()
    info = Counters()
    info.cb = ctypes.sizeof(Counters)
    psapi.GetProcessMemoryInfo(me, ctypes.byref(info), info.cb)
    return (user32.GetGuiResources(me, 0), user32.GetGuiResources(me, 1),
            info.PrivateUsage / 1024 / 1024)


def test_endurance(svc) -> None:  # noqa: ANN001
    section("16 長く使っても増え続けない（描く・開く・貼るを数百回）")
    path = _SANDBOX / "logs" / "endure.png"
    for i in range(30):                       # 温める（キャッシュが埋まる）
        svc.simulate_capture(text=f"温め {i}")
    svc.open(target=4242)
    wait_for(lambda: svc.visible)
    svc.snapshot(path)
    before = _usage()
    for i in range(300):
        if i % 3 == 0:
            svc.simulate_capture(text=f"くり返し {i} " + "あ" * (i % 50))
        svc.open(target=4242)
        svc.type_text("く")
        svc.key(clipmodel.VK_DOWN)
        svc.key(clipmodel.VK_TAB)
        if i % 10 == 0:
            svc.key(clipmodel.VK_RETURN)
        else:
            svc.key(clipmodel.VK_ESCAPE)
            svc.key(clipmodel.VK_ESCAPE)
        if i % 5 == 0:
            svc.snapshot(path)               # 本物の描画も通す
    svc.snapshot(path)
    time.sleep(0.5)
    after = _usage()
    print(f"  （参考）GDI {before[0]}→{after[0]} / USER {before[1]}→"
          f"{after[1]} / メモリ {before[2]:.1f}→{after[2]:.1f} MB")
    check("GDI の数が増え続けない", after[0] - before[0] <= 20, True)
    check("USER の数が増え続けない", after[1] - before[1] <= 10, True)
    check("メモリが増え続けない（30MB 未満）", after[2] - before[2] < 30,
          True)


def test_shots() -> None:
    section("11 窓の見た目（画面には出さずに画像にする）")
    out_dir = ROOT / "logs" / "clipshots"
    made = make_shots(out_dir)
    check("画像を作れた", len(made), 6)
    for path in made:
        check(f"{path.name} が空でない", path.stat().st_size > 5000, True)
    print(f"  画像: {out_dir}")


def main() -> int:
    test_store()
    test_images()
    test_data()
    test_model()
    test_service()
    test_recipes()
    test_downloads()
    test_review_fixes()
    test_api_contract()
    if "--shots" in sys.argv[1:]:
        test_shots()
    print(f"\n==== 成功 {ok_count} / 失敗 {fail_count} ====")
    return 1 if fail_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
