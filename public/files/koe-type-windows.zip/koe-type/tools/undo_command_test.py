"""音声コマンド「取り消し」の安全性と動作テスト。

本物のキー送信は行わず、dryrun モードで検証する。
"""

from __future__ import annotations

import os
import sys
import tempfile
import time
from pathlib import Path

TEMP_DIR = Path(tempfile.mkdtemp(prefix="koe_undo_test_"))
os.environ["KOE_TYPE_HOME"] = str(TEMP_DIR)
os.environ["KOE_TYPE_DRY_RUN"] = "1"

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import dryrun, inject, jatext
from app.configstore import Config
from app.main import Controller


def test_send_backspaces_dryrun() -> None:
    """dryrun モードで send_backspaces が安全に記録されること。"""
    dryrun.reset()
    ok = inject.send_backspaces(5)
    assert ok is True
    entries = [e for e in dryrun.entries() if e.get("kind") == "backspace"]
    assert len(entries) == 1
    assert entries[0]["count"] == 5

    # 0 文字以下は送信されない
    ok = inject.send_backspaces(0)
    assert ok is False
    assert len([e for e in dryrun.entries() if e.get("kind") == "backspace"]) == 1

    # 窓が変わっている場合は安全弁で送信されない
    orig_fg = inject.foreground
    try:
        inject.foreground = lambda: 11111  # 現在の窓
        ok = inject.send_backspaces(3, target_hwnd=22222)  # 違う窓
        assert ok is False
        assert len([e for e in dryrun.entries() if e.get("kind") == "backspace"]) == 1
    finally:
        inject.foreground = orig_fg
    print("OK: send_backspaces dryrun and window guard")


def test_controller_undo_behavior() -> None:
    """Controller の undo ロジックの検証。"""
    ctl = Controller()
    ctl.target_hwnd = 12345

    # 1. 何も入力していないとき
    assert ctl._undo_last_type() is False

    # 2. テキストを入力した直後
    ctl._last_typed_text = "こんにちは"
    ctl._last_typed_hwnd = 12345
    ctl._last_typed_at = time.monotonic()
    ctl._last_typed_submitted = False

    dryrun.reset()
    # モック環境では foreground() は 0 または任意のダミー
    # target_hwnd が 0 の場合または一致する場合に通る
    ctl._last_typed_hwnd = inject.foreground()
    ok = ctl._undo_last_type()
    assert ok is True
    entries = [e for e in dryrun.entries() if e.get("kind") == "backspace"]
    assert len(entries) == 1
    assert entries[0]["count"] == 5  # "こんにちは" = 5 文字

    # 3. 直後に再度呼んだとき（二重取り消し防止）
    assert ctl._undo_last_type() is False

    # 4. 送信（Enter）済みのときは取り消せない
    ctl._last_typed_text = "送信テキスト"
    ctl._last_typed_hwnd = inject.foreground()
    ctl._last_typed_at = time.monotonic()
    ctl._last_typed_submitted = True
    assert ctl._undo_last_type() is False

    # 5. 20 秒以上経過したときは取り消せない
    ctl._last_typed_submitted = False
    ctl._last_typed_at = time.monotonic() - 25.0
    assert ctl._undo_last_type() is False

    print("OK: controller undo safety guards")


def test_run_command_undo_phrases() -> None:
    """「取り消し」「やっぱりなし」などの発話が undo コマンドとして処理されること。"""
    ctl = Controller()
    ctl._last_typed_text = "テスト文章"
    ctl._last_typed_hwnd = inject.foreground()
    ctl._last_typed_at = time.monotonic()
    ctl._last_typed_submitted = False

    dryrun.reset()
    handled = ctl._run_command("取り消し", typed="", session=1)
    assert handled is True
    entries = [e for e in dryrun.entries() if e.get("kind") == "backspace"]
    assert len(entries) == 1
    assert entries[0]["count"] == 5

    # 「やっぱりなし」
    ctl._last_typed_text = "あいう"
    ctl._last_typed_hwnd = inject.foreground()
    ctl._last_typed_at = time.monotonic()
    ctl._last_typed_submitted = False
    handled = ctl._run_command("やっぱりなし", typed="", session=2)
    assert handled is True
    entries = [e for e in dryrun.entries() if e.get("kind") == "backspace"]
    assert len(entries) == 2
    assert entries[1]["count"] == 3

    print("OK: run_command triggers undo for recognized phrases")


def main() -> None:
    test_send_backspaces_dryrun()
    test_controller_undo_behavior()
    test_run_command_undo_phrases()
    print("\nALL UNDO FEATURE TESTS PASSED!")


if __name__ == "__main__":
    main()
