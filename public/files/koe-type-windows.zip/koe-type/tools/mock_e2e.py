"""通し検証（本物のキーは1回も送らない）。

アプリ本体をそのまま別プロセスで動かし、
  ・マイクの代わりに WAV を流し込み（KOE_TYPE_FAKE_MIC）
  ・入力部分をから打ちに差し替え（KOE_TYPE_DRY_RUN=1）
  ・ショートカットの代わりに台本で操作し（KOE_TYPE_TEST_SCRIPT）
  ・設定・辞書・履歴・ログは一時フォルダへ（KOE_TYPE_HOME）
「何が入力されるはずだったか」を記録から確かめる。

**このテストは SendInput を1回も呼ばない。** 画面がロックされていても動く。
利用者の設定・辞書・履歴・録音には触らない（一時フォルダのコピーを使う）。

    python tools/mock_e2e.py              # 全部
    python tools/mock_e2e.py -k cancel    # 名前で絞る
    python tools/mock_e2e.py --keep       # 一時フォルダを残す
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


AUDIO = ROOT / "bench" / "audio"
PYTHON = sys.executable


# ---------------------------------------------------------------- 下ごしらえ


def make_home(tmp: Path, config: dict | None = None) -> Path:
    """まっさらな設定フォルダを作る。利用者の設定には触らない。"""
    home = tmp / "home"
    (home / "logs").mkdir(parents=True, exist_ok=True)
    (home / "data").mkdir(parents=True, exist_ok=True)
    base = {
        "overlay": False,           # 画面に何も出さない
        "tray_icon": False,         # トレイも出さない
        "autostart": False,         # Windows の設定を変えない
        "sound_feedback": False,    # 音を鳴らさない
        "mute_while_recording": False,
        "warmup": False,
        "mic_preroll_ms": 0,        # 偽マイクではプリロールを使わない
        "log_level": "DEBUG",
    }
    base.update(config or {})
    (home / "config.json").write_text(
        json.dumps(base, ensure_ascii=False, indent=2), "utf-8")
    shutil.copyfile(ROOT / "dictionary.sample.txt", home / "dictionary.txt")
    return home


def wav_seconds(path: Path) -> float:
    with wave.open(str(path)) as w:
        return w.getnframes() / w.getframerate()


def run_app(home: Path, wav: Path, script: list[dict],
            timeout: float = 180.0, *, env_extra: dict | None = None,
            fake_mic: bool = True) -> dict:
    """アプリを台本どおりに動かし、から打ちの記録を返す。

    env_extra で、作り出したい状況（マイクなし等）の差し替えを渡せる。
    fake_mic=False にすると、音を流し込まない（マイクなしの確認用）。
    """
    script_path = home / "script.json"
    script_path.write_text(json.dumps(script, ensure_ascii=False), "utf-8")
    log = home / "logs" / "dryrun.jsonl"
    log.unlink(missing_ok=True)

    env = dict(os.environ)
    env.update({
        "PYTHONUTF8": "1",
        "KOE_TYPE_HOME": str(home),
        "KOE_TYPE_DRY_RUN": "1",
        "KOE_TYPE_DRY_RUN_LOG": str(log),
        "KOE_TYPE_TEST_SCRIPT": str(script_path),
    })
    if fake_mic:
        env["KOE_TYPE_FAKE_MIC"] = str(wav)
    else:
        env.pop("KOE_TYPE_FAKE_MIC", None)
    env.update(env_extra or {})
    t0 = time.perf_counter()
    try:
        proc = subprocess.run(  # noqa: S603
            [PYTHON, "-m", "app.main"], cwd=str(ROOT), env=env,
            capture_output=True, text=True, encoding="utf-8",
            errors="replace", timeout=timeout)
        rc, out, err = proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired as exc:
        rc, out, err = -1, (exc.stdout or ""), "時間切れ"
    elapsed = time.perf_counter() - t0

    entries = []
    if log.exists():
        for line in log.read_text("utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except ValueError:
                    pass
    return {"rc": rc, "stdout": out, "stderr": err, "entries": entries,
            "elapsed": elapsed,
            "app_log": (home / "logs" / "koe-type.log")}


def typed(entries: list[dict]) -> str:
    return "".join(e.get("text", "") for e in entries
                   if e.get("kind") in ("paste", "copy"))


def kinds(entries: list[dict]) -> list[str]:
    return [str(e.get("kind")) for e in entries]


def first_text_at(entries: list[dict]) -> float | None:
    for e in entries:
        if e.get("kind") in ("paste", "copy") and e.get("text"):
            return float(e.get("t", 0.0))
    return None


# ---------------------------------------------------------------- 検証


class Check:
    def __init__(self, name: str) -> None:
        self.name = name
        self.fails: list[str] = []
        self.notes: list[str] = []

    def ok(self, condition: bool, message: str) -> bool:
        if not condition:
            self.fails.append(message)
        return bool(condition)

    def note(self, message: str) -> None:
        self.notes.append(message)

    @property
    def passed(self) -> bool:
        return not self.fails


TESTS: dict[str, object] = {}


def test(name: str):  # noqa: ANN201
    def deco(fn):  # noqa: ANN001
        TESTS[name] = fn
        return fn
    return deco


def no_real_input(c: Check, r: dict) -> None:
    """どのテストでも必ず確かめること：本物のキーを送っていない。"""
    c.ok("SendInput" not in (r["stderr"] or ""), "stderr に SendInput の痕跡")
    c.ok(r["rc"] == 0, f"終了コードが {r['rc']}（stderr: {r['stderr'][:300]}）")


@test("stream")
def t_stream(tmp: Path) -> Check:
    """話しながらモード：録音 → 文字が入る → 停止で残りが入る。"""
    c = Check("stream")
    wav = AUDIO / "j01.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "stream", {"input_mode": "stream"})
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 0.5 + secs + 1.2, "event": "stop"},
        {"at": 0.5 + secs + 6.0, "event": "quit"},
    ])
    no_real_input(c, r)
    text = typed(r["entries"])
    c.ok(bool(text), "文字が1つも入らなかった")
    c.ok("submit" not in kinds(r["entries"]), "頼んでいないのに Enter を送った")
    at = first_text_at(r["entries"])
    if at is not None:
        c.note(f"最初の文字 {at - 0.5:.2f}s / 入った文字 {len(text)} 字")
        c.note(f"内容: {text[:60]}")

    # ★話しながら入れた文字の「残り」の頭に、区切りの空白を入れない。
    # 区切りの番号がずれていて「おはようござい ます」と言葉の途中が
    # 割れた（2026-10-05）。ログの順で、入力済みのある区間の直後の
    # 入力が空白で始まっていないかを見る。
    log = (home / "logs" / "koe-type.log").read_text("utf-8", "replace")
    after_typed = False
    checked = 0
    for line in log.splitlines():
        if "区間を確定" in line:
            m = re.search(r"入力済み (\d+) 文字", line)
            after_typed = bool(m and int(m.group(1)) > 0)
            continue
        if after_typed and "入力しました: " in line:
            rest = line.split("入力しました: ", 1)[1]
            c.ok(not rest.startswith((" ", "、")),
                 f"同じ区切りの残りの頭に区切りが入った: {rest[:20]!r}")
            checked += 1
            after_typed = False
    c.note(f"話しながら入れたあとの残り {checked} 回を確認")
    return c


@test("click_spill")
def t_click_spill(tmp: Path) -> Check:
    """クリックで止めたら、それより後の文字は貼らずにクリップボードへ。

    送信ボタンを押したあと、空になった入力欄に「ます」だけが入り、
    本文は「宜しくお願いし」で送られた（2026-10-05 立ち会いテスト）。
    """
    c = Check("click_spill")
    wav = AUDIO / "j01.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "click_spill", {"input_mode": "stream"})
    click_at = round(0.5 + secs * 0.6, 2)
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": click_at, "event": "click_stop"},
        {"at": round(0.5 + secs + 6.0, 2), "event": "quit"},
    ])
    no_real_input(c, r)
    entries = r["entries"]
    clicked = next((float(e.get("t", 0.0)) for e in entries
                    if e.get("kind") == "event"
                    and e.get("event") == "click_stop"), None)
    c.ok(clicked is not None, "クリックの記録がない")
    if clicked is None:
        return c
    # 貼り付けの途中でクリックが来ることはあるので、少しだけ猶予を置く
    late = [e.get("text", "") for e in entries
            if e.get("kind") == "paste"
            and float(e.get("t", 0.0)) > clicked + 0.3]
    c.ok(not late, f"クリックのあとに入力欄へ貼った: {late[:3]}")
    spilled = [e.get("text", "") for e in entries
               if e.get("kind") == "clipboard"
               and float(e.get("t", 0.0)) > clicked
               and e.get("history")]
    before = [e for e in entries if float(e.get("t", 0.0)) <= clicked]
    c.note(f"クリックの前に入った文字: {typed(before)[:40]}")
    c.note(f"クリップボードへ: {spilled[-1][:40] if spilled else '（なし）'}")
    c.ok(bool(spilled), "残りがクリップボードに入っていない")
    return c


@test("click_away")
def t_click_away(tmp: Path) -> Check:
    """よその窓を押して止めたら、残りは取っておき、戻ったら元の欄に入る。

    前は残りをクリップボードへ逃がすだけで、利用者には「話したのに
    文字が入らない」ように見えていた（2026-10-11）。
    """
    c = Check("click_away")
    wav = AUDIO / "j01.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "click_away", {"input_mode": "stream"})
    click_at = round(0.5 + secs * 0.6, 2)
    back_at = round(0.5 + secs + 4.0, 2)
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": click_at, "event": "focus_changed", "hwnd": 4242},
        {"at": click_at + 0.01, "event": "click_stop", "outside": True},
        {"at": back_at, "event": "focus_back"},
        {"at": back_at + 3.0, "event": "quit"},
    ])
    no_real_input(c, r)
    entries = r["entries"]
    back = next((float(e.get("t", 0.0)) for e in entries
                 if e.get("kind") == "event"
                 and e.get("event") == "focus_back"), None)
    clicked = next((float(e.get("t", 0.0)) for e in entries
                    if e.get("kind") == "event"
                    and e.get("event") == "click_stop"), None)
    c.ok(back is not None and clicked is not None, "台本の記録がない")
    if back is None or clicked is None:
        return c
    away = [e.get("text", "") for e in entries
            if e.get("kind") == "paste"
            and clicked + 0.3 < float(e.get("t", 0.0)) < back]
    c.ok(not away, f"よそを見ているあいだに貼った: {away[:3]}")
    after = [e.get("text", "") for e in entries
             if e.get("kind") == "paste" and float(e.get("t", 0.0)) >= back]
    c.ok(bool(after), "戻っても残りが入らない")
    spilled = [e for e in entries if e.get("kind") == "clipboard"
               and e.get("history") and float(e.get("t", 0.0)) > clicked]
    c.ok(not spilled, "残りをクリップボードへ逃がしてしまった")
    c.note(f"戻ってから入った文字: {''.join(after)[:40]}")
    return c


@test("phrase")
def t_phrase(tmp: Path) -> Check:
    """文ごとモード：区切りごとに入る。"""
    c = Check("phrase")
    wav = AUDIO / "j02.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "phrase", {"input_mode": "phrase"})
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 0.5 + secs + 1.2, "event": "stop"},
        {"at": 0.5 + secs + 6.0, "event": "quit"},
    ])
    no_real_input(c, r)
    text = typed(r["entries"])
    c.ok(bool(text), "文字が1つも入らなかった")
    c.note(f"入った文字 {len(text)} 字: {text[:60]}")
    return c


@test("enter_sends")
def t_enter(tmp: Path) -> Check:
    """Enter で停止 → 文字を入れてから Enter を送る（順番が大事）。"""
    c = Check("enter_sends")
    wav = AUDIO / "j03.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "enter", {"enter_sends": True})
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 0.5 + secs + 1.0, "event": "send"},
        {"at": 0.5 + secs + 6.0, "event": "quit"},
    ])
    no_real_input(c, r)
    ks = kinds(r["entries"])
    c.ok("submit" in ks, "Enter が送られなかった")
    if "submit" in ks:
        last_text = max((i for i, k in enumerate(ks)
                         if k in ("paste", "copy")), default=-1)
        c.ok(last_text >= 0, "Enter の前に文字が入らなかった")
        c.ok(last_text < ks.index("submit"),
             "文字より先に Enter を送ってしまった")
    c.note(f"順番: {' → '.join(k for k in ks if k in ('paste', 'submit'))}")
    return c


@test("cancel")
def t_cancel(tmp: Path) -> Check:
    """話し始めてすぐ Esc → **1文字も入らない**。ただし履歴には残る。

    区切り（無音 0.7 秒）が来る前に中止するので、まだ何も入力していない。
    入力したあとに中止した場合は cancel_stream の方で見る
    （入れた文字は書き換えない決まりなので、消すことはできない）。
    """
    c = Check("cancel")
    wav = AUDIO / "j04.wav"
    home = make_home(tmp / "cancel", {"input_mode": "phrase"})
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 1.2, "event": "cancel"},
        {"at": 9.0, "event": "quit"},
    ])
    no_real_input(c, r)
    c.ok(not typed(r["entries"]),
         f"中止したのに文字が入った: {typed(r['entries'])[:60]!r}")
    c.ok("submit" not in kinds(r["entries"]), "中止したのに Enter を送った")
    rows = history_rows(home)
    c.ok(any(row.get("cancelled") for row in rows),
         "中止した録音が履歴に残っていない")
    c.note(f"履歴 {len(rows)} 件（うち中止 "
           f"{sum(1 for r2 in rows if r2.get('cancelled'))} 件）")
    return c


@test("cancel_stream")
def t_cancel_stream(tmp: Path) -> Check:
    """話しながらモードで中止：**それ以降は1文字も入らない**。

    すでに入力した文字は残る。入れた文字は書き換えない決まりなので、
    中止で消すことはできない（帯でそう伝える）。
    """
    c = Check("cancel_stream")
    wav = AUDIO / "j05.wav"
    home = make_home(tmp / "cancel_stream", {"input_mode": "stream"})
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 3.0, "event": "cancel"},
        {"at": 10.0, "event": "quit"},
    ])
    no_real_input(c, r)
    entries = r["entries"]
    cancel_at = next((float(e["t"]) for e in entries
                      if e.get("kind") == "event"
                      and e.get("event") == "cancel"), None)
    c.ok(cancel_at is not None, "中止の記録がない")
    if cancel_at is not None:
        after = [e for e in entries
                 if e.get("kind") in ("paste", "copy")
                 and float(e.get("t", 0)) > cancel_at + 0.6]
        c.ok(not after,
             f"中止したあとに文字が入った: {[e.get('text') for e in after]}")
        before = [e for e in entries if e.get("kind") == "paste"
                  and float(e.get("t", 0)) <= cancel_at]
        c.note(f"中止前に入っていた文字 {len(before)} 回 / "
               f"中止後 {len(after)} 回")
    c.ok("submit" not in kinds(entries), "中止したのに Enter を送った")
    return c


@test("silence")
def t_silence(tmp: Path) -> Check:
    """無音では1文字も出さない（勝手な文を作らない）。"""
    c = Check("silence")
    wav = AUDIO / "silence.wav"
    home = make_home(tmp / "silence")
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": 6.0, "event": "stop"},
        {"at": 12.0, "event": "quit"},
    ])
    no_real_input(c, r)
    text = typed(r["entries"])
    c.ok(not text, f"無音なのに文字が出た: {text[:80]!r}")
    return c


@test("preview")
def t_preview(tmp: Path) -> Check:
    """帯に先出しするモード：**入力欄へは、ひと区切りごとにまとめて**入れる。

    話している最中は入力欄に何も入らない。区切りが終わってから入る。
    こうすると、入力済みとの重なりを数える必要がなく、
    同じ言葉が二重に入ることが起きない。
    """
    c = Check("preview")
    wav = AUDIO / "j05.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "preview", {"input_mode": "preview"})
    r = run_app(home, wav, [
        {"at": 0.5, "event": "hotkey_down"},
        {"at": round(secs + 1.5, 2), "event": "stop"},
        {"at": round(secs + 10.0, 2), "event": "quit"},
    ])
    no_real_input(c, r)
    text = typed(r["entries"])
    c.ok(bool(text.strip()), "1 文字も入らなかった")
    c.note(f"入った文字: {text[:70]}")

    log = (home / "logs" / "koe-type.log").read_text("utf-8", "replace")
    c.ok("話しながら確定" not in log,
         "先出しモードなのに、話している最中に入力欄へ入れた")
    c.ok("区間を確定" in log, "区切りの確定が記録されていない")
    # 二重に入っていないこと（同じ 3 文字が続けて現れない）
    doubled = next((text[i:i + 3] for i in range(len(text) - 5)
                    if text[i:i + 3] and text[i:i + 3] == text[i + 3:i + 6]),
                   "")
    c.ok(not doubled, f"同じ言葉が二重に入った: {doubled!r}")
    return c


@test("join")
def t_join(tmp: Path) -> Check:
    """続けて録音したとき、前の文とのあいだに区切りが入る。

    「。」を付けない設定だと、続けて録音すると
    「ベストテスト今日の天気は」のようにつながってしまう。
    """
    c = Check("join")
    wav = AUDIO / "j01.wav"
    secs = wav_seconds(wav)
    home = make_home(tmp / "join", {"input_mode": "phrase",
                                    "join_separator": "space"})
    at = 0.5
    script = []
    for _ in range(2):
        script.append({"at": round(at, 2), "event": "hotkey_down"})
        at += secs + 1.0
        script.append({"at": round(at, 2), "event": "stop"})
        at += 4.0
    script.append({"at": round(at + 6.0, 2), "event": "quit"})
    r = run_app(home, wav, script)
    no_real_input(c, r)
    pastes = [e.get("text", "") for e in r["entries"]
              if e.get("kind") in ("paste", "copy")]
    c.note(f"入った回数 {len(pastes)}: {pastes[:4]}")
    c.ok(len(pastes) >= 2, f"2 回入るはずが {len(pastes)} 回")
    if len(pastes) >= 2:
        later = [t for t in pastes[1:] if t.strip()]
        c.ok(any(t.startswith(" ") for t in later),
             f"2 回目の頭に区切りが入っていない: {later[:2]}")
    # 「なし」にしたら入らないこと
    home2 = make_home(tmp / "join_none", {"input_mode": "phrase",
                                          "join_separator": "none"})
    r2 = run_app(home2, wav, script)
    no_real_input(c, r2)
    pastes2 = [e.get("text", "") for e in r2["entries"]
               if e.get("kind") in ("paste", "copy")]
    c.ok(not any(t.startswith(" ") for t in pastes2),
         f"「なし」なのに区切りが入った: {pastes2[:3]}")
    return c


@test("excluded")
def t_excluded(tmp: Path) -> Check:
    """除外アプリの設定が読み込まれ、ショートカットを奪わない。"""
    c = Check("excluded")
    home = make_home(tmp / "excluded",
                     {"excluded_apps": ["Code.exe", "devenv.exe"]})
    r = run_app(home, AUDIO / "silence.wav", [
        {"at": 0.5, "event": "quit"},
    ], timeout=60)
    no_real_input(c, r)
    text = (home / "logs" / "koe-type.log").read_text("utf-8", "replace")
    c.ok("Code.exe" in text or "excluded" in text.lower()
         or "除外" in text, "除外アプリの設定が記録に出てこない")
    return c


@test("dictionary")
def t_dictionary(tmp: Path) -> Check:
    """辞書の置き換えが入力に効く（書き換えてすぐ反映される）。"""
    c = Check("dictionary")
    home = make_home(tmp / "dict")
    # 1 文字でも必ず置き換わる組を仕込む
    (home / "dictionary.txt").write_text(
        "# テスト用\nテスト=試験\n", "utf-8")
    sys.path.insert(0, str(ROOT))
    from app.textproc import Dictionary  # noqa: PLC0415

    d = Dictionary(home / "dictionary.txt")
    c.ok(d.apply("これはテストです") == "これは試験です",
         f"置き換えが効かない: {d.apply('これはテストです')!r}")
    (home / "dictionary.txt").write_text(
        "# テスト用\nテスト=検査\n", "utf-8")
    time.sleep(1.1)
    got = d.apply("これはテストです")
    c.ok(got == "これは検査です", f"書き換えが反映されない: {got!r}")
    c.note("置き換えと、書き換えの即反映を確認")
    return c


def history_rows(home: Path) -> list[dict]:
    import sqlite3
    db = home / "data" / "history.db"
    if not db.exists():
        return []
    try:
        conn = sqlite3.connect(str(db))
        cols = [r[1] for r in conn.execute("PRAGMA table_info(entries)")]
        rows = [dict(zip(cols, r))
                for r in conn.execute("SELECT * FROM entries")]
        conn.close()
        return rows
    except Exception as exc:  # noqa: BLE001
        print("  履歴を読めません:", exc)
        return []


# ---------------------------------------------------------------- 本体


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("-k", "--filter", default="",
                    help="名前にこの文字を含むテストだけ動かす")
    ap.add_argument("--keep", action="store_true",
                    help="一時フォルダを残す")
    ap.add_argument("--list", action="store_true", help="一覧を出すだけ")
    args = ap.parse_args()

    if args.list:
        for name in TESTS:
            print(name)
        return 0

    names = [n for n in TESTS if args.filter in n]
    if not names:
        print("あてはまるテストがありません")
        return 2

    print("=" * 68)
    print(" 通し検証（本物のキーは1回も送りません）")
    print("=" * 68)

    tmp = Path(tempfile.mkdtemp(prefix="koe-type-mock-"))
    results: list[Check] = []
    try:
        for name in names:
            print(f"\n■ {name}")
            t0 = time.perf_counter()
            try:
                check = TESTS[name](tmp)  # type: ignore[operator]
            except Exception as exc:  # noqa: BLE001
                import traceback
                check = Check(name)
                check.fails.append(f"テスト自体で例外: {exc}")
                traceback.print_exc()
            for note in check.notes:
                print(f"    {note}")
            for fail in check.fails:
                print(f"    × {fail}")
            print(f"    {'合格' if check.passed else '不合格'}"
                  f"  ({time.perf_counter() - t0:.1f}s)")
            results.append(check)
    finally:
        if args.keep:
            print(f"\n一時フォルダを残しました: {tmp}")
        else:
            shutil.rmtree(tmp, ignore_errors=True)

    bad = [r for r in results if not r.passed]
    print("\n" + "=" * 68)
    print(f" {len(results) - len(bad)}/{len(results)} 合格")
    if bad:
        print(" 不合格: " + ", ".join(r.name for r in bad))
    print("=" * 68)
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
