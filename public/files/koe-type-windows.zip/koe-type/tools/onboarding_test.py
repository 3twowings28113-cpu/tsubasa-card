r"""初回の案内（6 画面）を確かめ、画像にも残す。

**本物のキーもクリックも送らない。** 設定画面のサーバーを立て、
HTTP で話しかけて確かめるだけ。画像は Edge のヘッドレスで撮るので、
**画面がロックされていても通る**。

確かめること

  ・6 画面ぶんの HTML と JS が配られる
  ・この PC を調べて、おすすめのモデルと理由が返る
  ・モデル・マイク・ショートカットを選ぶと、設定に入る
  ・「終わり」を押すと `onboarding_done` が立ち、二度目は開かない
  ・すでにモデルが入っている人には、最初から開かない
  ・利用者の本当の設定には触らない（使い捨てのフォルダで動かす）

    python tools/onboarding_test.py
    python tools/onboarding_test.py --shots   # 画像も撮る
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

ok = 0
ng: list[str] = []


def check(label: str, good: object, detail: str = "") -> bool:
    global ok
    if good:
        ok += 1
        print(f"  OK   {label}" + (f"  （{detail}）" if detail else ""))
    else:
        ng.append(label)
        print(f"  NG   {label}" + (f"  （{detail}）" if detail else ""))
    return bool(good)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--shots", action="store_true")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    print("=" * 70)
    print(" 初回の案内を確かめる（本物のキーは送りません）")
    print("=" * 70)

    # 使い捨ての設定フォルダ。利用者の設定には触らない。
    home = Path(tempfile.mkdtemp(prefix="koe-type-ob-"))
    (home / "logs").mkdir()
    (home / "data").mkdir()
    (home / "config.json").write_text(
        json.dumps({"overlay": False, "tray_icon": False,
                    "autostart": False, "warmup": False}), "utf-8")
    os.environ["KOE_TYPE_HOME"] = str(home)
    os.environ["KOE_TYPE_NO_AUTOSTART"] = "1"

    from app import i18n  # noqa: PLC0415
    from app.configstore import Config  # noqa: PLC0415
    from app.history import History  # noqa: PLC0415
    from app.textproc import Dictionary  # noqa: PLC0415
    from app.util import ensure_dirs, setup_logging  # noqa: PLC0415
    from app.websettings import Bridge, SettingsServer, find_edge  # noqa: PLC0415,E501

    ensure_dirs()
    setup_logging("WARNING")
    cfg = Config()
    i18n.set_language("ja")
    calls: list[tuple] = []
    bridge = Bridge(cfg, Dictionary(), History(),
                    lambda name, **kw: calls.append((name, kw)))
    server = SettingsServer(bridge)
    server.keep_open = True
    server.start()
    base = f"http://127.0.0.1:{server.port}"
    token = server.token

    def get(path: str) -> tuple[int, bytes]:
        req = urllib.request.Request(
            f"{base}{path}" + ("&" if "?" in path else "?")
            + f"t={token}", headers={"X-Koe-Token": token})
        with urllib.request.urlopen(req, timeout=20) as res:  # noqa: S310
            return res.status, res.read()

    def post(path: str, body: dict) -> dict:
        req = urllib.request.Request(
            f"{base}{path}?t={token}",
            data=json.dumps(body).encode(),
            headers={"X-Koe-Token": token,
                     "Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=120) as res:  # noqa: S310
            return json.loads(res.read())

    try:
        print("\n[1] ページが配られる")
        status, body = get("/onboarding")
        check("/onboarding が返る", status == 200, f"{status}")
        text = body.decode("utf-8", "replace")
        check("合言葉が埋め込まれている", "__TOKEN__" not in text)
        for needle in ("onboarding.css", "onboarding.js", 'id="steps"',
                       'id="next"'):
            check(f"{needle} がある", needle in text)
        for asset in ("/assets/onboarding.css", "/assets/onboarding.js",
                      "/assets/app.css"):
            status, body = get(asset)
            check(f"{asset} が返る", status == 200 and len(body) > 200,
                  f"{len(body)} バイト")

        print("\n[2] 状態が返る")
        status, body = get("/api/onboarding")
        state = json.loads(body)
        for key in ("step", "profile", "models", "ready", "download",
                    "microphones", "hotkey", "hotkey_label",
                    "hotkey_options", "hotkey_check", "practice"):
            check(f"{key} がある", key in state)
        check("モデルの候補が 3 つ", len(state["models"]) == 3,
              str([m["key"] for m in state["models"]]))
        check("ショートカットの候補がある",
              len(state["hotkey_options"]) >= 3)

        print("\n[3] この PC を調べる")
        post("/api/onboarding", {"name": "probe"})
        state = {}
        for _ in range(120):
            time.sleep(0.5)
            state = json.loads(get("/api/onboarding")[1])
            if state.get("profile") and not state.get("probing"):
                break
        prof = state.get("profile") or {}
        check("CPU の名前が取れた", bool(prof.get("cpu_name")),
              str(prof.get("cpu_name"))[:40])
        check("メモリが取れた", (prof.get("memory_gb") or 0) > 0,
              f"{prof.get('memory_gb')} GB")
        check("空き容量が取れた", (prof.get("free_gb") or 0) > 0,
              f"{prof.get('free_gb')} GB")
        advice = state.get("advice") or {}
        check("おすすめのモデルが決まった", bool(advice.get("model")),
              str(advice.get("name")))
        check("理由が日本語で付いている",
              len(str(advice.get("reason_ja") or "")) > 10)
        check("この PC の表ができた", len(state.get("rows") or []) >= 5)

        print("\n[4] 選んだものが設定に入る")
        post("/api/onboarding", {"name": "choose",
                                 "model": "moonshine-base-ja"})
        check("モデルが変わった", cfg.str_("model") == "moonshine-base-ja",
              cfg.str_("model"))
        post("/api/onboarding", {"name": "choose",
                                 "model": advice.get("model")})
        post("/api/onboarding", {"name": "hotkey", "spec": "muhenkan"})
        check("ショートカットが変わった", cfg.str_("hotkey") == "muhenkan",
              cfg.str_("hotkey"))
        post("/api/onboarding", {"name": "hotkey", "spec": "ctrl+space"})
        post("/api/onboarding", {"name": "microphone", "value": ""})
        post("/api/onboarding", {"name": "step", "step": 4})
        check("進んだところが残る",
              json.loads(get("/api/onboarding")[1])["step"] == 4)

        print("\n[5] ぶつかりの確認")
        state = json.loads(get("/api/onboarding")[1])
        hk = state.get("hotkey_check") or {}
        check("ぶつかりを調べた結果がある", bool(hk.get("state")),
              f"{hk.get('state')}: {str(hk.get('detail'))[:50]}")

        print("\n[6] 終わると二度目は開かない")
        from app import firstrun  # noqa: PLC0415
        import app.catalog as catalog0  # noqa: PLC0415
        # この PC にはもうモデルが入っているので、
        # 「まだ何も入っていない人」のふりをして確かめる
        keep = catalog0.model_ready
        try:
            catalog0.model_ready = lambda key: False
            firstrun.catalog.model_ready = catalog0.model_ready
            check("終わる前は開く", firstrun.should_open(cfg))
        finally:
            catalog0.model_ready = keep
            firstrun.catalog.model_ready = keep
        post("/api/onboarding", {"name": "finish"})
        check("onboarding_done が立つ", cfg.bool_("onboarding_done"))
        check("終わったあとは開かない", not firstrun.should_open(cfg))

        print("\n[7] すでに使えている人には出さない")
        cfg.set("onboarding_done", False)
        import app.catalog as catalog  # noqa: PLC0415
        real = catalog.model_ready
        try:
            catalog.model_ready = lambda key: True
            firstrun.catalog.model_ready = catalog.model_ready
            check("モデルが入っていれば開かない",
                  not firstrun.should_open(cfg))
            check("そのとき印も立つ", cfg.bool_("onboarding_done"))
        finally:
            catalog.model_ready = real
            firstrun.catalog.model_ready = real

        if args.shots:
            print("\n[8] 画像を撮る（Edge のヘッドレス）")
            edge = find_edge()
            if edge is None:
                print("  Edge が見つかりません。画像は飛ばします。")
            else:
                out_dir = (Path(args.out) if args.out
                           else ROOT / "logs" / "shots" / "onboarding")
                out_dir.mkdir(parents=True, exist_ok=True)
                cfg.set("onboarding_done", False)
                for i, name in enumerate(
                        ("1-welcome", "2-pc", "3-model", "4-mic",
                         "5-keys", "6-try")):
                    post("/api/onboarding", {"name": "step", "step": i})
                    for theme in ("light", "dark"):
                        path = out_dir / f"onboarding-{name}-{theme}.png"
                        from tools.edgeshot import shoot  # noqa: PLC0415
                        if shoot(edge, f"{server.url('onboarding')}"
                                 f"&theme={theme}&step={i}", path,
                                 1060, 900):
                            print(f"  撮れました {path.name}"
                                  f"  ({path.stat().st_size // 1024} KB)")
                        else:
                            print(f"  失敗 {path.name}")
                        server.beat()
    finally:
        server.stop()
        os.environ.pop("KOE_TYPE_HOME", None)
        shutil.rmtree(home, ignore_errors=True)

    print("\n" + "=" * 70)
    print(f" 成功 {ok} / 失敗 {len(ng)}")
    print("=" * 70)
    for label in ng:
        print(f"  - {label}")
    return 1 if ng else 0


if __name__ == "__main__":
    raise SystemExit(main())
