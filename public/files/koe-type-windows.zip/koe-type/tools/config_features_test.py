"""設定の書き出し・読み込み、初期値復元、基本／詳細項目の単体テスト。

合成キー送信は行わず、一時フォルダで検証する。
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

# テスト用の使い捨てフォルダを準備
TEMP_DIR = Path(tempfile.mkdtemp(prefix="koe_config_test_"))
os.environ["KOE_TYPE_HOME"] = str(TEMP_DIR)
os.environ["KOE_TYPE_DRY_RUN"] = "1"

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import schema
from app.configstore import Config
from app.history import History
from app.textproc import Dictionary
from app.websettings import Bridge


def test_schema_items_have_advanced_and_default() -> None:
    """すべての Item が advanced と default を持つことを確認する。"""
    found_advanced = 0
    found_basic = 0
    for cat in schema.CATEGORIES:
        for group in cat.groups:
            for item in group.items:
                assert hasattr(item, "advanced"), f"{item.key} has no advanced"
                if item.advanced:
                    found_advanced += 1
                else:
                    found_basic += 1
    assert found_advanced > 20, f"Expected >20 advanced items, got {found_advanced}"
    assert found_basic > 10, f"Expected >10 basic items, got {found_basic}"
    print(f"OK: schema item count (basic={found_basic}, advanced={found_advanced})")


def test_config_export() -> None:
    """設定のエクスポートが正しい JSON を返すことを確認する。"""
    cfg = Config(TEMP_DIR / "config.json")
    cfg.set("hotkey", "ctrl+shift+k")
    cfg.set("send_key", "ctrl+enter")

    dict_mgr = Dictionary(TEMP_DIR / "dictionary.txt")
    hist_mgr = History(TEMP_DIR / "history.db")
    bridge = Bridge(cfg, dict_mgr, hist_mgr, action=lambda *a, **k: None)

    res = bridge.run_action("config_export", {})
    assert res.get("ok") is True
    assert "name" in res and res["name"].endswith(".json")
    exported_text = res.get("text", "")
    data = json.loads(exported_text)
    assert data.get("hotkey") == "ctrl+shift+k"
    assert data.get("send_key") == "ctrl+enter"
    print("OK: config_export returns valid json")


def test_config_import() -> None:
    """設定のインポートで値が更新されることを確認する。"""
    cfg = Config(TEMP_DIR / "config.json")
    dict_mgr = Dictionary(TEMP_DIR / "dictionary.txt")
    hist_mgr = History(TEMP_DIR / "history.db")

    reset_called = False
    def mock_action(name: str, **_kw):
        nonlocal reset_called
        if name == "config_reset":
            reset_called = True

    bridge = Bridge(cfg, dict_mgr, hist_mgr, action=mock_action)

    new_settings = {
        "hotkey": "alt+space",
        "enter_sends": False,
        "punctuation_density": "many",
        "unknown_key_should_be_ignored": "malicious",
    }
    res = bridge.run_action("config_import", {"text": json.dumps(new_settings)})
    assert res.get("ok") is True
    assert res.get("count") >= 3
    assert reset_called is True
    assert cfg.str_("hotkey") == "alt+space"
    assert cfg.bool_("enter_sends") is False
    assert cfg.str_("punctuation_density") == "many"
    print("OK: config_import applies settings and ignores unknown keys")


def test_config_import_invalid() -> None:
    """壊れた JSON や不正な形式のインポートが安全に弾かれることを確認する。"""
    cfg = Config(TEMP_DIR / "config.json")
    dict_mgr = Dictionary(TEMP_DIR / "dictionary.txt")
    hist_mgr = History(TEMP_DIR / "history.db")
    bridge = Bridge(cfg, dict_mgr, hist_mgr, action=lambda *a, **k: None)

    # 空文字列
    res = bridge.run_action("config_import", {"text": ""})
    assert res.get("ok") is False

    # 壊れた JSON
    res = bridge.run_action("config_import", {"text": "{broken json..."})
    assert res.get("ok") is False

    # 辞書ではない JSON
    res = bridge.run_action("config_import", {"text": "[\"array\"]"})
    assert res.get("ok") is False
    print("OK: config_import safely rejects invalid payloads")


def test_reset_item() -> None:
    """個別設定キーが初期値に戻ることを確認する。"""
    cfg = Config(TEMP_DIR / "config.json")
    cfg.set("hotkey", "ctrl+alt+z")
    cfg.set("enter_sends", False)

    dict_mgr = Dictionary(TEMP_DIR / "dictionary.txt")
    hist_mgr = History(TEMP_DIR / "history.db")
    bridge = Bridge(cfg, dict_mgr, hist_mgr, action=lambda *a, **k: None)

    # hotkey のデフォルトは "ctrl+space"
    res = bridge.run_action("reset_item", {"key": "hotkey"})
    assert res.get("ok") is True
    assert res.get("value") == "ctrl+space"
    assert cfg.str_("hotkey") == "ctrl+space"

    # enter_sends のデフォルトは True
    res = bridge.run_action("reset_item", {"key": "enter_sends"})
    assert res.get("ok") is True
    assert res.get("value") is True
    assert cfg.bool_("enter_sends") is True

    # 存在しないキー
    res = bridge.run_action("reset_item", {"key": "no_such_key_xyz"})
    assert res.get("ok") is False
    print("OK: reset_item restores individual settings to defaults")


def test_bridge_item_representation() -> None:
    """Bridge._item が default と advanced を含むことを確認する。"""
    cfg = Config(TEMP_DIR / "config.json")
    dict_mgr = Dictionary(TEMP_DIR / "dictionary.txt")
    hist_mgr = History(TEMP_DIR / "history.db")
    bridge = Bridge(cfg, dict_mgr, hist_mgr, action=lambda *a, **k: None)

    hotkey_item = schema.find("hotkey")
    assert hotkey_item is not None
    data = bridge._item(hotkey_item)
    assert data["default"] == "ctrl+space"
    assert data["advanced"] is False

    stream_item = schema.find("stream_interval_ms")
    assert stream_item is not None
    data = bridge._item(stream_item)
    assert data["default"] == 450
    assert data["advanced"] is True
    print("OK: Bridge._item returns default and advanced attributes")


def test_action_choices_and_api_key() -> None:
    """変換の選択肢は一覧から作り、API キーは保存でき、診断には出ないこと。"""
    from app import diagnostics
    cfg = Config(TEMP_DIR / "config.json")
    dict_mgr = Dictionary(TEMP_DIR / "dictionary.txt")
    hist_mgr = History(TEMP_DIR / "history.db")
    bridge = Bridge(cfg, dict_mgr, hist_mgr, action=lambda *a, **k: None)

    insts = [{"id": "translate_en", "name": "英語に翻訳", "enabled": True},
             {"id": "my_rule", "name": "自分の変換", "enabled": True},
             {"id": "off_rule", "name": "止めた変換", "enabled": False}]
    cfg.set("ai_custom_instructions", insts)
    cfg.set("long_press_action", "business")   # 昔の値
    rows = bridge._item(schema.find("long_press_action"))["options"]
    values = [r["value"] for r in rows]
    assert values[0] == "none", values
    assert "my_rule" in values and "off_rule" not in values, values
    assert "business" in values, values        # 古い値も空欄にしない
    rows = bridge._item(schema.find("action_mode"))["options"]
    assert "none" not in [r["value"] for r in rows]

    # 以前は「unknown key」で弾かれ、API キーが保存されていなかった
    assert bridge.set_value("ai_api_key", " test-key-123 ")["ok"] is True
    assert cfg.str_("ai_api_key") == "test-key-123"
    assert "test-key-123" not in diagnostics._settings(cfg)
    cfg.set("ai_api_key", "")
    print("OK: action choices come from the list; API key saves and stays out "
          "of diagnostics")


def main() -> None:
    test_schema_items_have_advanced_and_default()
    test_action_choices_and_api_key()
    test_config_export()
    test_config_import()
    test_config_import_invalid()
    test_reset_item()
    test_bridge_item_representation()
    print("\nALL CONFIG FEATURE TESTS PASSED!")


if __name__ == "__main__":
    main()
