"""帯の「カーソルの近く」配置機能（ROADMAP 5.5）のテスト。

ルール遵守:
  - 自動テストで本物のキー送信・クリックを行わない。
  - スピーカーから音を流さない。
"""

from __future__ import annotations

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

os.environ["KOE_TYPE_DRY_RUN"] = "1"

from app import overlay, schema


class CursorOverlayTest(unittest.TestCase):

    def test_schema_has_cursor_option(self) -> None:
        """schema の overlay_position に cursor 選択肢があること。"""
        item = schema.find("overlay_position")
        self.assertIsNotNone(item)
        values = [opt.value for opt in item.options]
        self.assertIn("cursor", values)

    def test_overlay_configure_accepts_cursor(self) -> None:
        """Overlay.configure が position='cursor' を受け入れること。"""
        ov = overlay.Overlay()
        ov.configure(
            theme_name="system",
            position="cursor",
            size="medium",
            margin_px=16,
            enabled=True,
        )
        self.assertEqual(ov.position, "cursor")

    def test_cursor_place_normal(self) -> None:
        """カーソルが画面中央にある場合、カーソル下に配置されること。"""
        ov = overlay.Overlay()
        ov.configure(theme_name="system", position="cursor", size="medium",
                     margin_px=16, enabled=True)

        # 画面の作業領域をモック (1920x1080)
        mock_rect = overlay.RECT(0, 0, 1920, 1040)
        ov._work_area = MagicMock(return_value=mock_rect)
        ov._dpi_factor = MagicMock(return_value=1.0)
        ov._cursor_pos = MagicMock(return_value=(500, 400))

        w, h = 300, 40
        x, y = ov._place(w, h)
        # x は cx - w // 2 = 500 - 150 = 350
        # y は cy + 18 = 400 + 18 = 418
        self.assertEqual(x, 350)
        self.assertEqual(y, 418)

    def test_cursor_place_flips_near_bottom(self) -> None:
        """カーソルが画面下端近くにある場合、カーソル上へ自動反転すること。"""
        ov = overlay.Overlay()
        ov.configure(theme_name="system", position="cursor", size="medium",
                     margin_px=16, enabled=True)

        mock_rect = overlay.RECT(0, 0, 1920, 1040)
        ov._work_area = MagicMock(return_value=mock_rect)
        ov._dpi_factor = MagicMock(return_value=1.0)
        ov._cursor_pos = MagicMock(return_value=(500, 1020))  # 下端ギリギリ

        w, h = 300, 40
        x, y = ov._place(w, h)
        # 画面下端を超えるため、cy - h - 18 = 1020 - 40 - 18 = 962
        self.assertEqual(x, 350)
        self.assertEqual(y, 962)

    def test_cursor_place_fallback_on_zero(self) -> None:
        """カーソル位置が (0, 0) の場合、下中央へ安全にフォールバックすること。"""
        ov = overlay.Overlay()
        ov.configure(theme_name="system", position="cursor", size="medium",
                     margin_px=16, enabled=True)

        mock_rect = overlay.RECT(0, 0, 1920, 1040)
        ov._work_area = MagicMock(return_value=mock_rect)
        ov._dpi_factor = MagicMock(return_value=1.0)
        ov._cursor_pos = MagicMock(return_value=(0, 0))

        w, h = 300, 40
        x, y = ov._place(w, h)
        # 下中央フォールバック
        expected_x = (1920 - 300) // 2
        self.assertEqual(x, expected_x)
        self.assertGreater(y, 900)

    def test_cursor_anchor_reset_on_state_change(self) -> None:
        """状態が recording や hidden に変化した際、アンカーがリセットされること。"""
        ov = overlay.Overlay()
        ov.configure(theme_name="system", position="cursor", size="medium",
                     margin_px=16, enabled=True)
        ov._cursor_anchor = (100, 200)

        ov.set_state("recording")
        self.assertIsNone(ov._cursor_anchor)

        ov._cursor_anchor = (100, 200)
        ov.hide()
        self.assertIsNone(ov._cursor_anchor)


if __name__ == "__main__":
    unittest.main()
