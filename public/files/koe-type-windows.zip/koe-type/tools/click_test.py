"""録音中のクリックの見張りを確かめる。

**本物のクリックは 1 回も送らない。** ボタンの状態を読む部分を
差し替えて、「押した・離した」を台本で作って確かめる。

## いちばん大事なこと

**クリックを止めない・遅らせない・書き換えない。**

以前は低レベルのフック（`WH_MOUSE_LL`）でクリックを受け止め、
残りの文字を入れてから通していた。これが PC 全体をほぼ固めた
（Python ではフックのコールバックが GIL を待つあいだ、Windows が
入力全体を止める）。だからいまは**読むだけ**にしてある。

ここで確かめるのは

  ・押し下げを見つけて知らせること（同じウィンドウの中でも）
  ・1 回の録音につき 1 度だけ知らせること
  ・録音していないあいだはスレッドが回らないこと
  ・から打ちモードでは何もしないこと
  ・入力を送る関数（SendInput）を**一度も呼ばないこと**
  ・見張りの中で例外が出ても、本体を巻き込まないこと

    python tools/click_test.py
"""

from __future__ import annotations

import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import dryrun, mousewatch  # noqa: E402

ok = 0
ng: list[str] = []


def check(label: str, got: object, want: object = True) -> None:
    global ok
    if got == want:
        ok += 1
        print(f"  OK   {label}")
    else:
        ng.append(label)
        print(f"  NG   {label}: {got!r} ではなく {want!r} のはず")


def wait_for(fn, limit: float = 2.0) -> bool:  # noqa: ANN001
    end = time.monotonic() + limit
    while time.monotonic() < end:
        if fn():
            return True
        time.sleep(0.01)
    return False


class Fake:
    """ボタンの状態と、カーソルの下の窓を、こちらで決める。"""

    def __init__(self) -> None:
        self.down: set[int] = set()
        self.hwnd = 4242
        self.lock = threading.Lock()

    def install(self) -> None:
        self._real_down = mousewatch._down
        self._real_win = mousewatch._window_under_cursor
        mousewatch._down = lambda vk: vk in self.down
        mousewatch._window_under_cursor = lambda: self.hwnd

    def remove(self) -> None:
        mousewatch._down = self._real_down
        mousewatch._window_under_cursor = self._real_win

    def press(self, vk: int = mousewatch.VK_LBUTTON) -> None:
        self.down.add(vk)

    def release(self, vk: int = mousewatch.VK_LBUTTON) -> None:
        self.down.discard(vk)


class Calls:
    def __init__(self) -> None:
        self.rows: list[tuple[int, bool]] = []

    def __call__(self, hwnd: int, held: bool) -> bool:
        self.rows.append((hwnd, held))
        # 録音を止めたことにする。MouseWatch は「止めた」と返されたとき
        # だけ、その録音のあいだの知らせを打ち切る（2026-10-08 から。
        # 入力欄の中のクリックでは止めずに、続けて見張るため）
        return True


fake = Fake()
fake.install()
try:
    print("\n[1] 押し下げを見つける")
    calls = Calls()
    w = mousewatch.MouseWatch(calls, interval=0.005)
    w.arm()
    check("録音中は見張りが回っている", w.armed)
    fake.press()
    check("押したら知らせが来る", wait_for(lambda: len(calls.rows) == 1))
    check("窓の番号が渡る", calls.rows[0][0] if calls.rows else None, 4242)
    check("受け止めてはいない", calls.rows[0][1] if calls.rows else None,
          False)

    print("\n[2] 1 回の録音につき 1 度だけ")
    fake.release()
    time.sleep(0.05)
    fake.press()
    time.sleep(0.1)
    fake.release()
    time.sleep(0.05)
    fake.press()
    time.sleep(0.1)
    check("知らせは 1 回だけ", len(calls.rows), 1)
    w.disarm()
    fake.release()

    print("\n[3] 録音を止めたら、もう見ない")
    check("見張りは下りている", w.armed, False)
    before = len(calls.rows)
    fake.press()
    time.sleep(0.1)
    check("止めたあとは知らせが来ない", len(calls.rows), before)
    fake.release()

    print("\n[4] 次の録音では、また見つける")
    w.arm()
    time.sleep(0.03)
    fake.press()
    check("もう一度知らせが来る",
          wait_for(lambda: len(calls.rows) == before + 1))
    w.disarm()
    fake.release()

    print("\n[5] 始めた時に握っていたボタンは数えない")
    calls2 = Calls()
    fake.press()                       # 先に押しておく
    w2 = mousewatch.MouseWatch(calls2, interval=0.005)
    w2.arm()
    time.sleep(0.1)
    check("押しっぱなしでは知らせない", len(calls2.rows), 0)
    fake.release()
    time.sleep(0.03)
    fake.press()
    check("離してから押せば知らせる",
          wait_for(lambda: len(calls2.rows) == 1))
    w2.disarm()
    fake.release()

    print("\n[6] 右ボタン・中ボタンも見る")
    for vk, name in ((mousewatch.VK_RBUTTON, "右"),
                     (mousewatch.VK_MBUTTON, "中")):
        calls3 = Calls()
        w3 = mousewatch.MouseWatch(calls3, interval=0.005)
        w3.arm()
        time.sleep(0.03)
        fake.press(vk)
        check(f"{name}ボタンでも知らせる",
              wait_for(lambda: len(calls3.rows) == 1))
        w3.disarm()
        fake.release(vk)

    print("\n[7] 知らせる側で例外が出ても、巻き込まない")
    def boom(hwnd: int, held: bool) -> None:
        raise RuntimeError("わざと失敗させる")

    w4 = mousewatch.MouseWatch(boom, interval=0.005)
    w4.arm()
    time.sleep(0.03)
    fake.press()
    time.sleep(0.1)
    check("スレッドは生きている", w4.armed)
    w4.disarm()
    fake.release()

    print("\n[8] から打ちモードでは何もしない")
    import os
    os.environ[dryrun._ENV] = "1"
    try:
        calls5 = Calls()
        w5 = mousewatch.MouseWatch(calls5, interval=0.005)
        w5.arm()
        check("スレッドを作らない", w5.armed, False)
        fake.press()
        time.sleep(0.08)
        check("知らせも来ない", len(calls5.rows), 0)
        fake.release()
    finally:
        os.environ.pop(dryrun._ENV, None)

    print("\n[9] 入力を送る仕掛けを持っていない")
    import ast
    raw = (ROOT / "app" / "mousewatch.py").read_text("utf-8")
    # 説明の文章（なぜ使わないか）には名前が出てくるので、
    # **実際のコードの部分だけ**を見る
    tree = ast.parse(raw)
    body = tree.body[1:] if ast.get_docstring(tree) else tree.body
    source = chr(10).join(ast.unparse(node) for node in body)
    for word in ("SendInput", "SetWindowsHookEx", "WH_MOUSE_LL",
                 "mouse_event", "CallNextHookEx"):
        check(f"{word} を使っていない", word not in source)
    check("release() は何もしない（呼べる）",
          mousewatch.MouseWatch(Calls()).release(), None)
finally:
    fake.remove()

print("")
print("[10] ほかのアプリの入力を遅くしていないか（実測）")
# ここだけ差し替えをやめ、本物の GetAsyncKeyState を読ませる。
# 読むだけなので、クリックもキーも 1 回も送らない。
import statistics  # noqa: E402

from tools.stress_test import probe_input_latency  # noqa: E402

_base = probe_input_latency(120)
_real = mousewatch.MouseWatch(Calls(), interval=0.015)
_real.arm()
_during = probe_input_latency(300)
_real.disarm()
_bm, _dm = statistics.median(_base), statistics.median(_during)
print(f"       見張りなし 中央値 {_bm:.4f} ms / 最大 {max(_base):.4f} ms")
print(f"       見張りあり 中央値 {_dm:.4f} ms / 最大 {max(_during):.4f} ms")
# 入力の流れに割り込まないので、ふだんと変わらないはず。
check("入力の遅れが増えていない", _dm < max(1.0, _bm * 3))
check("飛び抜けた遅れがない", max(_during) < 5.0)

print(f"\n==== 成功 {ok} / 失敗 {len(ng)} ====")
if ng:
    for label in ng:
        print(f"  - {label}")
raise SystemExit(1 if ng else 0)
