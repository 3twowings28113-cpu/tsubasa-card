r"""録音中の帯の見た目を確かめる。

帯そのものを画面に出し、その窓だけを撮って PNG に並べる。
ほかのアプリには触らない（キーも音も使わない）。

  python tools\overlay_shots.py [出力フォルダ]
"""

from __future__ import annotations

import struct
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import overlay as ov                      # noqa: E402
from app.util import setup_logging                 # noqa: E402

CASES = [
    ("recording-short", "recording", "dark", 3.0, 0.55, ""),
    ("recording-pending", "recording", "dark", 7.0, 0.75,
     "きょうの打ち合わせは"),
    ("recording-long", "recording", "dark", 42.0, 0.4,
     "きょうの打ち合わせは午前十時から会議室で行います。資料は前の日までに"),
    ("transcribing", "transcribing", "dark", 0.0, 0.0, ""),
    ("done", "done", "dark", 0.0, 0.0, ""),
]


# ---------------------------------------------------------------- PNG


def write_png(path: Path, w: int, h: int, rgba: bytes) -> None:
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += rgba[y * w * 4:(y + 1) * w * 4]

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (struct.pack(">I", len(data)) + tag + data
                + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

    path.write_bytes(b"\x89PNG\r\n\x1a\n"
                     + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                     + chunk(b"IDAT", zlib.compress(bytes(raw), 9))
                     + chunk(b"IEND", b""))


# ---------------------------------------------------------------- 本体


def main() -> int:
    out_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "logs" / "shots"
    out_dir.mkdir(parents=True, exist_ok=True)
    setup_logging("INFO")

    made = []
    for theme_name in ("dark", "light"):
        bar = ov.Overlay()
        bar.configure(theme_name=theme_name, position="bottom", size="medium",
                      margin_px=16, enabled=True)
        if not ov._start_gdiplus():
            print("GDI+ を始められませんでした")
            return 1
        for font_name in ov.FONTS:
            import ctypes as _c
            family = _c.c_void_p()
            if ov.gdiplus.GdipCreateFontFamilyFromName(
                    font_name, None, _c.byref(family)) == 0:
                bar._font_family = family
                break
        for name, state, _t, elapsed, level, pending in CASES:
            message = "入力しました" if state == "done" else ""
            bar.set_state(state, elapsed=elapsed, level=level,
                          pending=pending, message=message)
            shot = bar.snapshot()
            if shot is None:
                print(f"  失敗 {name}")
                continue
            w, h, rgba = shot
            path = out_dir / f"overlay-{name}-{theme_name}.png"
            write_png(path, w, h, rgba)
            made.append(path)
            print(f"  {path.name}  {w}x{h}")

    print(f"\n{len(made)} 枚を {out_dir} に保存しました")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
