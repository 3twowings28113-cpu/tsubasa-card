r"""録音中の帯の 3 案を、状態ごとに画像にして並べる。

画面を撮らない（**画面がロックされていても通る**）。帯が描いた中身を
そのまま PNG にする。キーも音も使わない。

案
  pill  ピル   ……横長のカプセル 1 本。いちばん場所を取らない
  wave  波のバー……横いっぱいの波。マイクが拾えているのが分かる
  card  カード ……話している言葉をいちばん大きく見せる（既定）

状態
  listening  聞いている
  long       文字が多いとき
  working    文字にしている
  stopped    止まりました

    python tools\overlay_options.py
    python tools\overlay_options.py logs\shots\overlay-options
"""

from __future__ import annotations

import ctypes
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import overlay as ov                      # noqa: E402
from app.util import setup_logging                 # noqa: E402
from tools.overlay_shots import write_png          # noqa: E402

HINT = "Ctrl + Space で止める　・　Esc で取り消し"

# (名前, 状態, 経過秒, 声の大きさ, 未確定の文字, お知らせ)
CASES = [
    ("1-listening", "recording", 4.0, 0.62, "あしたの打ち合わせは", ""),
    ("2-long", "recording", 73.0, 0.44,
     "あしたの打ち合わせは午前10時から会議室でやります。資料は前の日までに"
     "共有しておいてください", ""),
    ("3-working", "transcribing", 0.0, 0.0, "", ""),
    ("4-stopped", "done", 0.0, 0.0, "", "静かなので止めました"),
]


def make(design: str, theme_name: str, size: str = "medium") -> ov.Overlay:
    bar = ov.Overlay()
    bar.configure(theme_name=theme_name, position="bottom", size=size,
                  margin_px=16, enabled=True, design=design,
                  hint_text=HINT, show_hint=True)
    # 動きは止めて撮る（画像なので、出入りの途中だと薄くなる）
    bar._animate = False
    for font_name in ov.FONTS:
        family = ctypes.c_void_p()
        if ov.gdiplus.GdipCreateFontFamilyFromName(
                font_name, None, ctypes.byref(family)) == 0:
            bar._font_family = family
            break
    return bar


def main() -> int:
    out_dir = (Path(sys.argv[1]) if len(sys.argv) > 1
               else ROOT / "logs" / "shots" / "overlay-options")
    out_dir.mkdir(parents=True, exist_ok=True)
    setup_logging("INFO")
    if not ov._start_gdiplus():
        print("GDI+ を始められませんでした")
        return 1

    made = 0
    for design in ov.DESIGNS:
        print(f"\n■ {design}")
        for theme_name in ("light", "dark"):
            bar = make(design, theme_name)
            try:
                for name, state, elapsed, level, pending, message in CASES:
                    # 波を落ち着かせる（動きの途中で撮らない）
                    for _ in range(14):
                        bar._pump_wave(
                            len(bar._wave) or 30, level,
                            state == "recording")
                    bar.set_state(state, elapsed=elapsed, level=level,
                                  pending=pending, message=message)
                    for _ in range(10):
                        shot = bar.snapshot()
                    if shot is None:
                        print(f"    失敗 {design} {name} {theme_name}")
                        continue
                    w, h, rgba = shot
                    path = out_dir / f"{design}-{name}-{theme_name}.png"
                    write_png(path, w, h, rgba)
                    made += 1
                    print(f"    {path.name}  {w}x{h}")
            finally:
                if bar._font_family:
                    ov.gdiplus.GdipDeleteFontFamily(bar._font_family)
                    bar._font_family = None

    # 大きさ 3 段階も 1 枚ずつ（既定の案で）
    print(f"\n■ 大きさ（{ov.DESIGN_DEFAULT}）")
    for size in ("small", "medium", "large"):
        bar = make(ov.DESIGN_DEFAULT, "light", size)
        try:
            for _ in range(14):
                bar._pump_wave(len(bar._wave) or 30, 0.6, True)
            bar.set_state("recording", elapsed=4.0, level=0.6,
                          pending="あしたの打ち合わせは")
            shot = bar.snapshot()
            if shot is None:
                continue
            w, h, rgba = shot
            path = out_dir / f"size-{size}-light.png"
            write_png(path, w, h, rgba)
            made += 1
            print(f"    {path.name}  {w}x{h}")
        finally:
            if bar._font_family:
                ov.gdiplus.GdipDeleteFontFamily(bar._font_family)
                bar._font_family = None

    # 録音中の色（overlay_color）も 1 枚ずつ（波のバーで、ライト／ダーク）
    print("\n■ 録音中の色")
    for theme_name in ("light", "dark"):
        for colour in list(ov.RECORD_COLOURS) + ["accent"]:
            bar = make("wave", theme_name)
            bar.record_colour = colour
            try:
                for _ in range(14):
                    bar._pump_wave(len(bar._wave) or 30, 0.6, True)
                bar.set_state("recording", elapsed=4.0, level=0.6,
                              pending="あしたの打ち合わせは")
                shot = bar.snapshot()
                if shot is None:
                    continue
                w, h, rgba = shot
                path = out_dir / f"colour-{colour}-{theme_name}.png"
                write_png(path, w, h, rgba)
                made += 1
                print(f"    {path.name}  {w}x{h}")
            finally:
                if bar._font_family:
                    ov.gdiplus.GdipDeleteFontFamily(bar._font_family)
                    bar._font_family = None

    print(f"\n{made} 枚を {out_dir} に保存しました")
    return 0 if made else 1


if __name__ == "__main__":
    raise SystemExit(main())
