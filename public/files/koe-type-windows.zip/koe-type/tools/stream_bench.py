r"""「話しながら」と「文ごと」の、遅れと文字誤り率をくらべる。

合成音声をマイクから来たことにして実時間で流し込み、
それぞれのやり方で**いつ・どの文字が入力されたか**を記録する。
スピーカーもマイクも使わない。キーも送らない。

  python tools\stream_bench.py [間の長さ(ms)]
"""

from __future__ import annotations

import json
import sys
import time
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from app import catalog, engines                        # noqa: E402
from app.audio import CHUNK_MS, SAMPLE_RATE             # noqa: E402
from app.configstore import Config                      # noqa: E402
from app.streaming import Agreement, remainder          # noqa: E402
from app.textproc import Dictionary, is_noise, tidy     # noqa: E402
from app.util import ensure_dirs, setup_logging         # noqa: E402
from app.vad import SegmentCutter                       # noqa: E402

AUDIO = ROOT / "bench" / "audio"
CLIPS = ("p01", "p02", "p03", "p05")
TRUTH = {
    "p01": "明日の打ち合わせは午前十時から会議室で行います。",
    "p02": "今日の日付と見出しの部分は黒文字にしてほしい。",
    "p03": "自動でうまいこと調整されるようにできないの。",
    "p05": "この機能は来週のリリースに間に合わせたいと考えています。",
}


def read_pcm(name: str, tight: bool = False) -> bytes:
    with wave.open(str(AUDIO / f"{name}.wav")) as w:
        assert w.getframerate() == SAMPLE_RATE
        pcm = w.readframes(w.getnframes())
    if not tight:
        return pcm
    # 前後の無音を削って、息つぎのない話し方を作る
    import array
    import math
    a = array.array("h")
    a.frombytes(pcm)
    frame = SAMPLE_RATE * 20 // 1000
    loud = [i for i in range(0, len(a) - frame, frame)
            if math.sqrt(sum(float(x) * x for x in a[i:i + frame]) / frame) > 300]
    if not loud:
        return pcm
    return a[loud[0]:loud[-1] + frame].tobytes()


def normalise(s: str) -> str:
    import re
    return re.sub(r"[\s、。，．,.!?！？「」『』・…ー]", "", s).lower()


def cer(ref: str, hyp: str) -> float:
    r, h = normalise(ref), normalise(hyp)
    if not r:
        return 0.0
    prev = list(range(len(h) + 1))
    for i, rc in enumerate(r, 1):
        cur = [i]
        for j, hc in enumerate(h, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (rc != hc)))
        prev = cur
    return prev[-1] / len(r)


class Harness:
    """コントローラのうち、音→文字の部分だけを取り出したもの。"""

    def __init__(self, cfg: Config, engine, mode: str) -> None:
        self.cfg, self.engine, self.mode = cfg, engine, mode
        self.dictionary = Dictionary()
        self.cutter = SegmentCutter(
            SAMPLE_RATE, pause_ms=cfg.int_("pause_ms"),
            min_speech_ms=cfg.int_("min_speech_ms"),
            max_segment_ms=cfg.int_("max_segment_ms"),
            preroll_ms=cfg.int_("preroll_ms"), tail_ms=cfg.int_("tail_ms"),
            sensitivity=cfg.int_("vad_sensitivity") / 10.0,
            floor=float(cfg.int_("vad_floor")))
        self.agreement = Agreement()
        self.typed: list[tuple[float, str]] = []     # (時刻, 入った文字)
        self.rounds = 0
        self.engine_time = 0.0
        self.t0 = 0.0

    # ------------------------------------------------------------------

    def _clean(self, raw: str) -> str:
        opts = dict(punctuation=self.cfg.str_("punctuation_density", "normal") != "none",
                    fillers=self.cfg.bool_("remove_fillers"),
                    halfwidth=self.cfg.bool_("halfwidth_numbers"))
        return tidy(self.dictionary.apply(tidy(raw, **opts)), **opts)

    def _transcribe(self, pcm: bytes) -> str:
        wav = engines.temp_wav()
        try:
            engines.write_wav(wav, pcm)
            started = time.perf_counter()
            raw = self.engine.transcribe(wav)
            self.engine_time += time.perf_counter() - started
            self.rounds += 1
        finally:
            wav.unlink(missing_ok=True)
        return self._clean(raw)

    def _emit(self, text: str) -> None:
        if text:
            self.typed.append((time.perf_counter() - self.t0, text))

    # ------------------------------------------------------------------

    def run(self, pcm: bytes) -> None:
        """実時間で流し込む。"""
        self.t0 = time.perf_counter()
        step = SAMPLE_RATE * 2 * CHUNK_MS // 1000
        interval = self.cfg.int_("stream_interval_ms", 600) / 1000.0
        next_round = interval
        for i in range(0, len(pcm), step):
            target = self.t0 + (i / (SAMPLE_RATE * 2))
            sleep = target - time.perf_counter()
            if sleep > 0:
                time.sleep(sleep)
            for seg in self.cutter.feed(pcm[i:i + step]):
                self._finish_segment(seg, self.agreement.take())
            if self.mode == "stream":
                now = time.perf_counter() - self.t0
                if now >= next_round:
                    took = self._stream_round()
                    next_round = (time.perf_counter() - self.t0) \
                        + max(interval, took * 1.15)
        # 止めたとき
        for seg in self.cutter.flush():
            self._finish_segment(seg, self.agreement.take())

    def _stream_round(self) -> float:
        buf = self.cutter.buffered()
        if len(buf) < SAMPLE_RATE * 2 * 4 // 10:
            return 0.0
        started = time.perf_counter()
        text = self._transcribe(buf)
        self._emit(self.agreement.update(text))
        return time.perf_counter() - started

    def _finish_segment(self, pcm: bytes, typed: str) -> None:
        text = self._transcribe(pcm)
        if not text or is_noise(text):
            return
        if typed:
            text = remainder(typed, text)
        self._emit(text)

    # ------------------------------------------------------------------

    @property
    def result(self) -> str:
        return "".join(t for _, t in self.typed)


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    tight = "--tight" in sys.argv
    gap_ms = int(args[0]) if args else 300
    ensure_dirs()
    setup_logging("WARNING")
    cfg = Config()
    model = cfg.str_("model", catalog.DEFAULT_MODEL)
    if catalog.missing_assets(model):
        print(f"モデル {model} が足りません。python -m app.fetch {model}")
        return 2
    engine = engines.build(model, cfg.str_("language", "ja"))

    gap = bytes(SAMPLE_RATE * 2 * gap_ms // 1000)
    pcm = b"".join(read_pcm(c, tight) + gap for c in CLIPS)
    truth = "".join(TRUTH[c] for c in CLIPS)
    speech_secs = len(pcm) / (SAMPLE_RATE * 2)

    print(f"\n音声: {len(CLIPS)} 文 / 合計 {speech_secs:.1f} 秒 / "
          f"文の間は {gap_ms} ミリ秒")
    print(f"モデル: {model} / 区切りとみなす無音: {cfg.int_('pause_ms')} ミリ秒\n")

    # 1 回目はモデルの読み込みで遅いので捨てる
    warm = engines.temp_wav()
    try:
        engines.write_wav(warm, bytes(SAMPLE_RATE))
        engine.transcribe(warm)
    finally:
        warm.unlink(missing_ok=True)

    rows = {}
    for mode, label in (("stream", "話しながら"), ("phrase", "文ごと")):
        harness = Harness(cfg, engine, mode)
        harness.run(pcm)
        first = harness.typed[0][0] if harness.typed else float("nan")
        last = harness.typed[-1][0] if harness.typed else float("nan")
        rows[mode] = {
            "label": label,
            "first": first,
            "tail": last - speech_secs,
            "rounds": harness.rounds,
            "engine": harness.engine_time,
            "cer": cer(truth, harness.result) * 100,
            "text": harness.result,
            "chunks": [(round(t, 2), s) for t, s in harness.typed],
        }
        print(f"── {label} ──")
        print(f"  最初の文字が出るまで : {first:5.2f} 秒（話し始めから）")
        print(f"  話し終わってから全部 : {last - speech_secs:5.2f} 秒")
        print(f"  文字起こしの回数     : {harness.rounds} 回 "
              f"（合計 {harness.engine_time:.1f} 秒）")
        print(f"  文字誤り率           : {rows[mode]['cer']:5.2f}%")
        print(f"  入った順: " + " | ".join(
            f"{t:.1f}s {s}" for t, s in harness.typed[:8]))
        print(f"  結果: {harness.result}\n")

    print("正解: " + truth)
    out = ROOT / "logs" / "stream_bench.json"
    out.write_text(json.dumps({"gap_ms": gap_ms, "speech": speech_secs,
                               "modes": rows}, ensure_ascii=False, indent=1),
                   "utf-8")
    print(f"\n詳しい記録: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
