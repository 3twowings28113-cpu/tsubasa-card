@echo off
rem koe-type installer - double-click this file
rem Use the full path to powershell.exe: on PCs whose PATH does not
rem include the WindowsPowerShell folder, a bare "powershell" fails
rem with "not recognized" and setup never starts (seen 2026-11-09).
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell"
"%PS%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
pause
