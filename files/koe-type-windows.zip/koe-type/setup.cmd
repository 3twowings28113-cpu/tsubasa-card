@echo off
rem koe-type installer - double-click this file
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
pause
