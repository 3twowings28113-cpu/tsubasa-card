#!/bin/bash
# koe-type Mac Lite のインストール（1回だけ実行する）。
#
# やること:
#   1. Apple Silicon か、python3（Command Line Tools）があるかを確認
#   2. ~/koe-type-mac/{bin,models} に speech 本体とモデル2つを
#      ダウンロードして、サイズと SHA256 で照合
#   3. パッケージ内の app/ と mac/ を ~/koe-type-mac/ へ配置
#   4. ダブルクリック起動用 KoeTypeMac.command を作る
#
# ダウンロードは途中再開できる（curl -C -）。照合に失敗したファイルは
# 入れ直すので、途中で止まってもこのスクリプトをもう一度実行すればよい。

set -u

HOME_DIR="$HOME/koe-type-mac"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

SPEECH_ZIP="speech-0.10.1-macos-arm64-metal.zip"
SPEECH_ZIP_URL="https://github.com/nyosegawa/speech.cpp/releases/download/v0.10.1/$SPEECH_ZIP"
SPEECH_ZIP_SHA="ff24f6f58c9d2dedb01caa88ba043ae845c76eff228e4cbfae5de749174404c1"
SPEECH_BIN_SIZE=11588712

HAAS_FILE="Haas-616M-ja-v1.0-Q8_0.gguf"
HAAS_URL="https://huggingface.co/sakasegawa/Haas-ja-v1.0-GGUF/resolve/main/$HAAS_FILE"
HAAS_SIZE=656381472
HAAS_SHA="cd5f60b2f1c411404b83fca4a65e3ce30a26d9e951b6a346529e65f22758afeb"

VAD_FILE="silero-vad-309K-v6.2-F32.gguf"
VAD_URL="https://huggingface.co/sakasegawa/silero-vad-GGUF/resolve/main/$VAD_FILE"
VAD_SIZE=1238624
VAD_SHA="2fc312514e5fc4fa4ffd02b25c76a4853fa4130e8fb9777d01502183b01238cb"

say() { printf '%s\n' "$*"; }

fail() {
  say ""
  say "止まりました: $*"
  say "直し方が分からなければ、この画面の内容をそのまま翼へ送ってください。"
  exit 1
}

file_size() {
  if [ -f "$1" ]; then stat -f %z "$1"; else echo 0; fi
}

file_sha() {
  shasum -a 256 "$1" | awk '{print $1}'
}

# download URL DEST SIZE SHA : 照合まで済んだファイルだけを残す
download() {
  url="$1"; dest="$2"; want_size="$3"; want_sha="$4"
  if [ "$(file_size "$dest")" = "$want_size" ]; then
    if [ "$(file_sha "$dest")" = "$want_sha" ]; then
      say "  既にあります（照合 OK）: $(basename "$dest")"
      return 0
    fi
    say "  照合が合わないので入れ直します: $(basename "$dest")"
    rm -f "$dest"
  fi
  say "  ダウンロード中: $(basename "$dest")（約 $((want_size / 1048576)) MB）"
  curl -fL -C - --retry 3 -o "$dest" "$url" \
    || fail "ダウンロードに失敗しました: $url（通信状態を確認して、もう一度このスクリプトを実行してください）"
  if [ "$(file_size "$dest")" != "$want_size" ]; then
    rm -f "$dest"
    fail "サイズが合いませんでした: $(basename "$dest")（もう一度実行すると続きから入れ直します）"
  fi
  if [ "$(file_sha "$dest")" != "$want_sha" ]; then
    rm -f "$dest"
    fail "照合（SHA256）が合いませんでした: $(basename "$dest")"
  fi
  say "  照合 OK: $(basename "$dest")"
}

say "koe-type Mac Lite のインストールを始めます"
say ""

# --- 1. 機種と python3 の確認 -------------------------------------------

if [ "$(uname -m)" != "arm64" ]; then
  fail "この Mac は対象外です。koe-type Mac Lite は Apple Silicon（M1 以降）の Mac 専用で、Intel Mac 向けの部品が用意できません。"
fi
say "[OK] Apple Silicon の Mac です"

if ! xcode-select -p >/dev/null 2>&1; then
  say ""
  say "python3 を使うための道具（Command Line Tools）がまだ入っていません。"
  say "次のコマンドをこのターミナルで実行して、出てきた画面で"
  say "「インストール」を押してください（10分ほどかかります）:"
  say ""
  say "    xcode-select --install"
  say ""
  say "終わったら、もう一度この install.sh を実行してください。"
  exit 1
fi
if ! python3 -c "import sys" >/dev/null 2>&1; then
  fail "python3 が動かせませんでした（Command Line Tools の状態を確認してください）"
fi
say "[OK] python3: $(python3 --version 2>&1)"

# --- 2. 部品のダウンロード ----------------------------------------------

mkdir -p "$HOME_DIR/bin" "$HOME_DIR/models" "$HOME_DIR/logs" \
  "$HOME_DIR/data" "$HOME_DIR/.dl"

if [ "$(file_size "$HOME_DIR/bin/speech")" = "$SPEECH_BIN_SIZE" ]; then
  say "[OK] speech 本体は既にあります"
else
  say "speech 本体を入れます"
  download "$SPEECH_ZIP_URL" "$HOME_DIR/.dl/$SPEECH_ZIP" 6087757 \
    "$SPEECH_ZIP_SHA"
  unzip -o -q "$HOME_DIR/.dl/$SPEECH_ZIP" -d "$HOME_DIR/bin" \
    || fail "speech の展開に失敗しました"
  chmod +x "$HOME_DIR/bin/speech"
  # zip 内の libspeech.dylib はシンボリックリンク。展開で通常ファイルに
  # 化ける環境があるので、実体へのリンクに直す（実体がある場合だけ）。
  if [ -f "$HOME_DIR/bin/libspeech.4.dylib" ]; then
    ln -sf libspeech.4.dylib "$HOME_DIR/bin/libspeech.dylib"
  fi
  # ダウンロード由来の隔離属性が付いていたら外す（実行ブロック回避）
  xattr -dr com.apple.quarantine "$HOME_DIR/bin" 2>/dev/null || true
  if [ "$(file_size "$HOME_DIR/bin/speech")" != "$SPEECH_BIN_SIZE" ]; then
    fail "speech 本体の展開結果が想定と違います"
  fi
  say "[OK] speech 本体を入れました"
fi

say "モデルを入れます（初回は数分かかります）"
download "$HAAS_URL" "$HOME_DIR/models/$HAAS_FILE" "$HAAS_SIZE" "$HAAS_SHA"
download "$VAD_URL" "$HOME_DIR/models/$VAD_FILE" "$VAD_SIZE" "$VAD_SHA"

# --- 3. プログラムの配置 -------------------------------------------------

cp -R "$SCRIPT_DIR/app" "$HOME_DIR/" || fail "app の配置に失敗しました"
cp -R "$SCRIPT_DIR/mac" "$HOME_DIR/" || fail "mac の配置に失敗しました"
find "$HOME_DIR/app" "$HOME_DIR/mac" -name __pycache__ -type d \
  -exec rm -rf {} + 2>/dev/null || true
say "[OK] プログラムを $HOME_DIR に置きました"

if [ ! -f "$HOME_DIR/dictionary.txt" ] \
  && [ -f "$SCRIPT_DIR/dictionary.sample.txt" ]; then
  cp "$SCRIPT_DIR/dictionary.sample.txt" "$HOME_DIR/dictionary.txt"
  say "[OK] 辞書の見本を dictionary.txt として置きました"
fi

# --- 4. 起動用ファイル ----------------------------------------------------

cat > "$HOME_DIR/KoeTypeMac.command" <<'EOF'
#!/bin/bash
# koe-type Mac Lite の起動（ダブルクリック用）
export KOE_TYPE_HOME="$HOME/koe-type-mac"
cd "$HOME/koe-type-mac"
exec /usr/bin/env python3 "$HOME/koe-type-mac/mac/koetype_mac.py"
EOF
chmod +x "$HOME_DIR/KoeTypeMac.command"
say "[OK] 起動用ファイル KoeTypeMac.command を作りました"

say ""
say "=================================================="
say "インストールは終わりました。次の手順に進んでください"
say "=================================================="
say ""
say "1. 権限を2つ許可する（どちらも「ターミナル」に対する許可です）"
say "   ・マイク: 初めて起動した時にダイアログが出たら「許可」を押す"
say "   ・アクセシビリティ: 「システム設定」→「プライバシーと"
say "     セキュリティ」→「アクセシビリティ」で「ターミナル」を"
say "     オンにする（一覧に無ければ ＋ から追加）"
say ""
say "2. 起動する"
say "   フォルダ $HOME_DIR の中の KoeTypeMac.command を"
say "   ダブルクリックする（ターミナルの画面が開いて起動します）"
say ""
say "3. 使う"
say "   Ctrl+Option+Space を押すと入力モードが オン になります。"
say "   喋ると、文がカーソル位置に入ります。もう一度押すと オフ。"
say "   終わりにする時は、ターミナルの画面で Ctrl+C を押します。"
say ""
say "困ったら、次のコマンドの出力を全部コピーして翼へ送ってください:"
say "   python3 ~/koe-type-mac/mac/koetype_mac.py --selftest"
