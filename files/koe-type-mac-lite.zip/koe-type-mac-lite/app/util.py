"""パス解決・ゆるい JSON 読み込み・ログの共通部分。"""

from __future__ import annotations

import json
import logging
import logging.handlers
import os
import re
import sys
import threading
from pathlib import Path
from typing import Any

VERSION = "1.4.0"

ROOT = Path(__file__).resolve().parent.parent

# 設定・辞書・履歴・ログの置き場所。`KOE_TYPE_HOME` で別の場所に移せる。
# テストはここを一時フォルダに向けることで、**利用者のデータに触らない**。
# モデルとエンジン（大きいバイナリ）は共有したいので ROOT 側に残す。
HOME = Path(os.environ.get("KOE_TYPE_HOME") or ROOT)

CONFIG_PATH = HOME / "config.json"
DICT_PATH = HOME / "dictionary.txt"
SAMPLE_DICT_PATH = ROOT / "dictionary.sample.txt"
LOG_DIR = HOME / "logs"
DATA_DIR = HOME / "data"
BIN_DIR = Path(os.environ.get("KOE_TYPE_ENGINE_DIR") or (ROOT / "engines"))
MODEL_DIR = Path(os.environ.get("KOE_TYPE_MODEL_DIR") or (ROOT / "models"))

_COMMENT = re.compile(r'(?m)(?<!\\)//.*?$|/\*.*?\*/', re.S)
_TRAILING_COMMA = re.compile(r',(\s*[}\]])')


def loads_tolerant(text: str) -> Any:
    """`//` コメントと末尾カンマを許す JSON 読み込み。

    文字列リテラルの中の `//` を壊さないよう、まず文字列を退避する。
    （昔の config.json にはコメントが入っているので、その互換のため残してある）
    """
    stash: list[str] = []

    def hide(m: re.Match[str]) -> str:
        stash.append(m.group(0))
        return f"\x00{len(stash) - 1}\x00"

    text = re.sub(r'"(?:\\.|[^"\\])*"', hide, text)
    text = _COMMENT.sub("", text)
    text = _TRAILING_COMMA.sub(r"\1", text)
    text = re.sub(r"\x00(\d+)\x00", lambda m: stash[int(m.group(1))], text)
    return json.loads(text)


def ensure_dirs() -> None:
    for path in (LOG_DIR, DATA_DIR, BIN_DIR, MODEL_DIR):
        path.mkdir(parents=True, exist_ok=True)


def ensure_dictionary() -> None:
    """初回起動時に見本から辞書を作る（利用者の辞書は上書きしない）。"""
    if DICT_PATH.exists():
        return
    try:
        if SAMPLE_DICT_PATH.exists():
            DICT_PATH.write_text(SAMPLE_DICT_PATH.read_text("utf-8"), "utf-8")
        else:
            DICT_PATH.write_text("# 誤認識=正しい表記\n", "utf-8")
        logging.getLogger(__name__).info("辞書を作りました: %s", DICT_PATH)
    except OSError:
        logging.getLogger(__name__).exception("辞書を作れませんでした")


class _SafeRotatingHandler(logging.handlers.RotatingFileHandler):
    """ファイルを回せなくても、書き続ける。

    ★Windows では、ほかのプロセスが開いているファイルは名前を変えられない。
    見張り役が同じログを開いていたので、1MB を超えた瞬間から回すのに
    失敗し続け、**それ以降のログが 1 行も残らなかった**（2026-10-06）。
    いまは見張り役を別のファイルにしたが、念のため、回せなかったときは
    そのまま書き続け、200KB 増えるまで回すのを待つ。
    """

    _retry_at = 0

    def shouldRollover(self, record) -> int:  # noqa: ANN001, N802
        if self._retry_at and self.stream is not None:
            try:
                if self.stream.tell() < self._retry_at:
                    return 0
            except (OSError, ValueError):
                return 0
        return super().shouldRollover(record)

    def doRollover(self) -> None:  # noqa: N802
        try:
            super().doRollover()
            self._retry_at = 0
        except OSError:
            if self.stream is None:
                self.stream = self._open()
            try:
                self._retry_at = self.stream.tell() + 200_000
            except (OSError, ValueError):
                self._retry_at = self.maxBytes + 200_000


def setup_logging(level: str = "INFO", name: str = "koe-type.log") -> None:
    """ログの書き先を決める。name はプロセスごとに分ける。

    同じファイルを 2 つのプロセスで開くと、Windows では回せなくなる
    （見張り役は guardian.log に書く）。
    """
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(getattr(logging, str(level).upper(), logging.INFO))
    for h in list(root.handlers):
        root.removeHandler(h)
    handler = _SafeRotatingHandler(
        LOG_DIR / name, maxBytes=1_000_000, backupCount=3,
        encoding="utf-8",
    )
    handler.setFormatter(logging.Formatter(
        "%(asctime)s %(levelname)-7s [%(threadName)s] %(name)s: %(message)s"))
    root.addHandler(handler)

    def hook(exc_type, exc, tb):  # noqa: ANN001
        logging.critical("未捕捉の例外", exc_info=(exc_type, exc, tb))

    sys.excepthook = hook
    threading.excepthook = lambda a: logging.critical(  # type: ignore[assignment]
        "スレッドで未捕捉の例外", exc_info=(a.exc_type, a.exc_value, a.exc_traceback))


def set_log_level(level: str) -> None:
    logging.getLogger().setLevel(getattr(logging, str(level).upper(), logging.INFO))


def guard(fn):
    """例外でアプリ全体が落ちないようにするデコレータ。"""

    def wrapper(*a, **kw):  # noqa: ANN002, ANN003
        try:
            return fn(*a, **kw)
        except Exception:
            logging.exception("%s で例外", getattr(fn, "__name__", fn))
            return None

    wrapper.__name__ = getattr(fn, "__name__", "wrapped")
    return wrapper
