"""macOS の全体ホットキー（Carbon の RegisterEventHotKey の薄いラッパ）。

なぜ Carbon か。全体ホットキーを受ける macOS の公式手段は今も Carbon の
RegisterEventHotKey で、追加ライブラリも特別な権限も要らない。
（NSEvent の全体監視はアクセシビリティ権限が要り、Lite の割り切りに
合わない。権限が要るのは貼り付けのキー送信側だけに寄せる。）

なぜ遅延ロードか。このモジュールはテストのため Linux / Windows でも
import される。Carbon を触るのは register() を呼んだ時だけにし、
import しただけでは何も読み込まない。

定数は Carbon HIToolbox の公開ヘッダ（Events.h 系）の値:
  kEventClassKeyboard = 'keyb' = 0x6B657962、kEventHotKeyPressed = 5
  修飾キーマスク: controlKey = 0x1000、optionKey = 0x0800、
  shiftKey = 0x0200、cmdKey = 0x0100
  仮想キーコード kVK_Space = 0x31（49）
  kEventParamDirectObject = '----' = 0x2D2D2D2D
  typeEventHotKeyID = 'hkid' = 0x686B6964
"""

from __future__ import annotations

import ctypes
import logging
import sys
from typing import Callable

log = logging.getLogger(__name__)

# 修飾キーのマスク（RegisterEventHotKey に渡す旧来の修飾ビット）
CONTROL_KEY = 0x1000
OPTION_KEY = 0x0800
SHIFT_KEY = 0x0200
CMD_KEY = 0x0100

# 仮想キーコード（kVK_*）
VK_SPACE = 0x31

_EVENT_CLASS_KEYBOARD = 0x6B657962  # 'keyb'
_EVENT_HOTKEY_PRESSED = 5
_EVENT_PARAM_DIRECT_OBJECT = 0x2D2D2D2D  # '----'
_TYPE_EVENT_HOTKEY_ID = 0x686B6964  # 'hkid'
_HOTKEY_SIGNATURE = 0x6B747970  # 'ktyp'
_HOTKEY_ID = 1

_CARBON_PATH = "/System/Library/Frameworks/Carbon.framework/Carbon"


class HotKeyError(Exception):
    """ホットキーを登録できなかった理由を持つ。"""


class _EventTypeSpec(ctypes.Structure):
    _fields_ = [("eventClass", ctypes.c_uint32),
                ("eventKind", ctypes.c_uint32)]


class _EventHotKeyID(ctypes.Structure):
    _fields_ = [("signature", ctypes.c_uint32), ("id", ctypes.c_uint32)]


# EventHandlerUPP: OSStatus (*)(EventHandlerCallRef, EventRef, void *)
_HandlerProc = ctypes.CFUNCTYPE(ctypes.c_int32, ctypes.c_void_p,
                                ctypes.c_void_p, ctypes.c_void_p)


class HotKey:
    """登録済みのホットキー。close() で解除する。

    コールバックや構造体への参照をここで持ち続ける。ctypes の関数
    ポインタは参照が切れると解放され、Carbon 側に残ったポインタが
    宙に浮いて落ちるため。
    """

    def __init__(self, carbon: ctypes.CDLL, hotkey_ref: ctypes.c_void_p,
                 handler_ref: ctypes.c_void_p,
                 handler: _HandlerProc,
                 spec: _EventTypeSpec) -> None:
        self._carbon = carbon
        self._hotkey_ref = hotkey_ref
        self._handler_ref = handler_ref
        self._handler = handler
        self._spec = spec
        self._closed = False

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._hotkey_ref:
            self._carbon.UnregisterEventHotKey(self._hotkey_ref)
        if self._handler_ref:
            self._carbon.RemoveEventHandler(self._handler_ref)


def register(key_code: int, modifiers: int,
             callback: Callable[[], None]) -> HotKey:
    """全体ホットキーを登録する。失敗したら HotKeyError（理由つき）。

    イベントはメインスレッドの CFRunLoop（または
    RunApplicationEventLoop）で配送される前提。呼び出し側は
    RunLoop を回し続けること。
    """
    if sys.platform != "darwin":
        raise HotKeyError(f"この OS では使えません: {sys.platform}")
    try:
        carbon = ctypes.CDLL(_CARBON_PATH)
    except OSError as exc:
        raise HotKeyError(f"Carbon を読み込めませんでした: {exc}") from exc

    carbon.GetApplicationEventTarget.restype = ctypes.c_void_p
    carbon.GetApplicationEventTarget.argtypes = []
    carbon.InstallEventHandler.restype = ctypes.c_int32
    carbon.InstallEventHandler.argtypes = [
        ctypes.c_void_p, _HandlerProc, ctypes.c_uint32,
        ctypes.POINTER(_EventTypeSpec), ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_void_p)]
    carbon.RegisterEventHotKey.restype = ctypes.c_int32
    carbon.RegisterEventHotKey.argtypes = [
        ctypes.c_uint32, ctypes.c_uint32, _EventHotKeyID,
        ctypes.c_void_p, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_void_p)]
    carbon.GetEventParameter.restype = ctypes.c_int32
    carbon.GetEventParameter.argtypes = [
        ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p,
        ctypes.c_uint32, ctypes.c_void_p, ctypes.c_void_p]
    carbon.UnregisterEventHotKey.restype = ctypes.c_int32
    carbon.UnregisterEventHotKey.argtypes = [ctypes.c_void_p]
    carbon.RemoveEventHandler.restype = ctypes.c_int32
    carbon.RemoveEventHandler.argtypes = [ctypes.c_void_p]

    target = carbon.GetApplicationEventTarget()
    if not target:
        raise HotKeyError("イベントターゲットを取得できませんでした")

    def _on_event(_call_ref: ctypes.c_void_p, event: ctypes.c_void_p,
                  _user: ctypes.c_void_p) -> int:
        # Carbon の中へ例外を持ち込まない（プロセスごと落ちるため）。
        # 失敗はログに残し、押下自体は落とさない。
        try:
            got = _EventHotKeyID()
            status = carbon.GetEventParameter(
                event, _EVENT_PARAM_DIRECT_OBJECT, _TYPE_EVENT_HOTKEY_ID,
                None, ctypes.sizeof(got), None, ctypes.byref(got))
            if status == 0 and got.id == _HOTKEY_ID:
                callback()
        except Exception:
            log.exception("ホットキーの処理で例外が出ました")
        return 0

    handler = _HandlerProc(_on_event)
    spec = _EventTypeSpec(_EVENT_CLASS_KEYBOARD, _EVENT_HOTKEY_PRESSED)
    handler_ref = ctypes.c_void_p()
    status = carbon.InstallEventHandler(
        target, handler, 1, ctypes.byref(spec), None,
        ctypes.byref(handler_ref))
    if status != 0:
        raise HotKeyError(
            f"イベントハンドラを付けられませんでした (OSStatus={status})")

    hotkey_ref = ctypes.c_void_p()
    hk_id = _EventHotKeyID(_HOTKEY_SIGNATURE, _HOTKEY_ID)
    status = carbon.RegisterEventHotKey(
        key_code, modifiers, hk_id, target, 0, ctypes.byref(hotkey_ref))
    if status != 0:
        carbon.RemoveEventHandler(handler_ref)
        raise HotKeyError(
            f"ホットキーを登録できませんでした (OSStatus={status})。"
            "他のアプリやシステムが同じキーを掴んでいる可能性があります")
    return HotKey(carbon, hotkey_ref, handler_ref, handler, spec)
