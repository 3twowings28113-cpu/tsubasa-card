#!/usr/bin/env python3
"""koe-type Mac Lite v1（Apple Silicon 専用）。

方式（docs/DECISIONS.md の 11-06 の行）:
  録音と認識は speech.cpp の `speech asr --live` に任せる。macOS の
  標準ライブラリだけでは Python からマイクを取る手段が無く、外部依存を
  足さない方針のため、録音を自前実装しない。--live は VAD で区切った
  発話ごとに OpenAI Realtime 形式の JSONL イベントを出すので、
  このコントローラは「確定イベントを受けて、Windows 版と同じ整形
  パイプライン（app/jatext 等）を通し、カーソルへ貼る」ことだけを担う。

割り切り（Lite）:
  ・貼り付けとキー送信はターミナル経由（pbcopy / osascript）なので、
    マイクとアクセシビリティの権限はターミナルに付く。
  ・armed の切り替えは Ctrl+Option+Space。disarmed の間の確定は捨てる
    （speech は止めない。止めると再読込が要り、切り替えが重くなるため）。
  ・Enter は押さない。送信は本人がする。
"""

from __future__ import annotations

import argparse
import ctypes
import json
import logging
import os
import platform
import queue
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable

# app モジュールは import された時点で util.HOME が KOE_TYPE_HOME から
# 決まる。だから環境変数の既定は、どの app モジュールよりも先に置く。
if not os.environ.get("KOE_TYPE_HOME"):
    os.environ["KOE_TYPE_HOME"] = str(Path.home() / "koe-type-mac")

_HERE = Path(__file__).resolve().parent
for _p in (str(_HERE), str(_HERE.parent)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import hotkey as carbon_hotkey  # noqa: E402

from app import jatext  # noqa: E402
from app.learnfix import LearnStore  # noqa: E402
from app.textproc import Dictionary, tidy  # noqa: E402

log = logging.getLogger("koetype_mac")

MAC_HOME = Path(os.environ["KOE_TYPE_HOME"])
SPEECH_BIN = MAC_HOME / "bin" / "speech"
HAAS_MODEL = MAC_HOME / "models" / "Haas-616M-ja-v1.0-Q8_0.gguf"
VAD_MODEL = MAC_HOME / "models" / "silero-vad-309K-v6.2-F32.gguf"
LOG_PATH = MAC_HOME / "logs" / "koetype-mac.log"
SPEECH_ERR_PATH = MAC_HOME / "logs" / "speech-stderr.log"

# install.sh が照合するのと同じ期待値（食い違ったら selftest で出す）
HAAS_SIZE = 656_381_472
VAD_SIZE = 1_238_624

# 既定のホットキー: Ctrl+Option+Space（Handy の Ctrl+L や
# Windows 版の Ctrl+Space とは重ねない）
HOTKEY_CODE = carbon_hotkey.VK_SPACE
HOTKEY_MODS = carbon_hotkey.CONTROL_KEY | carbon_hotkey.OPTION_KEY


# ---------------------------------------------------------------- イベント

_COMPLETED = "conversation.item.input_audio_transcription.completed"
_DELTA = "conversation.item.input_audio_transcription.delta"
_FAILED = "conversation.item.input_audio_transcription.failed"


def parse_event(line: str) -> tuple[str, str]:
    """JSONL の1行を (種類, 中身) にする。純粋関数（テスト対象）。

    種類: completed / delta / failed / speech / broken / ignore。
    壊れた行で落とさない（--live の標準出力には警告行が混ざりうるため、
    読めない行は broken として数えるだけにする）。
    """
    text = line.strip()
    if not text:
        return ("ignore", "")
    try:
        ev = json.loads(text)
    except ValueError:
        return ("broken", text[:120])
    if not isinstance(ev, dict):
        return ("broken", text[:120])
    kind = str(ev.get("type") or "")
    if kind == _COMPLETED:
        transcript = ev.get("transcript")
        if not isinstance(transcript, str):
            item = ev.get("item")
            if isinstance(item, dict):
                transcript = item.get("transcript")
        return ("completed", transcript if isinstance(transcript, str)
                else "")
    if kind == _DELTA:
        delta = ev.get("delta")
        return ("delta", delta if isinstance(delta, str) else "")
    if kind == _FAILED:
        err = ev.get("error")
        if isinstance(err, dict):
            msg = str(err.get("message") or err)
        else:
            msg = str(err or "不明なエラー")
        return ("failed", msg)
    if kind.startswith("input_audio_buffer."):
        return ("speech", kind)
    return ("ignore", kind)


# ---------------------------------------------------------------- 設定と整形

def build_keywords(hints: list[str]) -> str:
    """辞書のヒント一覧を speech の --keywords 用の文字列にする。

    渡し方はこの1か所に集約する。方針は Windows worker と同じで、
    表示形だけを改行で並べ、読みは付けない（Haas 側に読み推定がある
    ため）。CLI 側が `語=読み` 形式を必須とするかは未確認なので、
    問題が出たら直すのはここだけにしたい。
    """
    words: list[str] = []
    for hint in hints:
        word = hint.strip()
        if word and word not in words:
            words.append(word)
    return "\n".join(words)


def build_options(cfg: dict[str, Any],
                  learned_pairs: tuple[tuple[str, str], ...] = ()
                  ) -> jatext.Options:
    """整形の設定を組み立てる。キーは Windows 版 config.json と同じ。

    既定値は app/main.py の _ja_options のフォールバック（= Windows の
    実効既定）に揃える。ただし句読点だけは Mac Lite の既定を normal と
    する（DECISIONS 11-06。config.json に punctuation_density が
    あればそちらが優先）。
    """
    words = cfg.get("filler_words")
    return jatext.Options(
        punctuation=str(cfg.get("punctuation_density", "normal")),
        fullwidth_punct=bool(cfg.get("fullwidth_punct", True)),
        questions=str(cfg.get("question_marks", "never")),
        halfwidth_alnum=bool(cfg.get("halfwidth_numbers", True)),
        spacing=str(cfg.get("ja_en_spacing", "none")),
        arabic_numbers=bool(cfg.get("arabic_numbers", False)),
        fillers=bool(cfg.get("remove_fillers", True)),
        filler_words=(tuple(str(w) for w in words) if words
                      else jatext.DEFAULT_FILLERS),
        restatement=bool(cfg.get("fix_restatement", False)),
        full_stops=str(cfg.get("full_stops", "off")),
        tail_question=bool(cfg.get("voice_commands", True)),
        symbol_commands=cfg.get("symbol_commands",
                                jatext.DEFAULT_SYMBOL_COMMANDS),
        convert_spelled_alphabet=bool(
            cfg.get("convert_spelled_alphabet", True)),
        repair_mixed_loanwords=bool(
            cfg.get("repair_mixed_loanwords", True)),
        fix_homophones=bool(cfg.get("fix_homophones", True)),
        learned_pairs=learned_pairs,
    )


def load_config(home: Path) -> dict[str, Any]:
    """config.json があれば読む。壊れていても落とさず既定で動かす。"""
    path = home / "config.json"
    try:
        data = json.loads(path.read_text("utf-8"))
    except FileNotFoundError:
        return {}
    except (OSError, ValueError) as exc:
        log.warning("config.json を読めなかったので既定で動きます: %s", exc)
        return {}
    return data if isinstance(data, dict) else {}


def load_learned_pairs(home: Path,
                       cfg: dict[str, Any]) -> tuple[tuple[str, str], ...]:
    """「直す」で採用された学習ペア（あれば）。Lite では読むだけ。"""
    if not cfg.get("learn_fixes", True):
        return ()
    try:
        store = LearnStore(home / "data" / "learned_fixes.json")
        return store.pairs()
    except Exception as exc:  # 読めなくても本体は止めない
        log.warning("学習ペアを読めませんでした: %s", exc)
        return ()


def clean_text(raw: str, dictionary: Dictionary,
               options: jatext.Options) -> str:
    """生の認識結果を貼れる形にする。順番は Windows の _clean と同じ:
    最低限の片づけ → 辞書 → 日本語の整形。Lite では各区間が完結した
    発話なので final=True で整える。
    """
    text = tidy(raw, punctuation=True, fillers=False,
                halfwidth=options.halfwidth_alnum)
    text = dictionary.apply(text)
    return jatext.format_text(text, options, final=True)


# ---------------------------------------------------------------- 貼り付け

def paste_text(text: str) -> None:
    """クリップボード経由でカーソル位置へ貼る（ターミナル経由の実行）。

    元のクリップボードは退避して戻す。ただし戻せるのは pbpaste で
    テキストとして読めた範囲だけ、という Lite の割り切り。
    Enter は押さない（送信は本人がする）。
    """
    saved = subprocess.run(["pbpaste"], capture_output=True).stdout
    subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=True)
    subprocess.run(
        ["osascript", "-e",
         'tell application "System Events" to '
         'keystroke "v" using command down'],
        check=True)
    # 貼り付けが相手に届く前に戻すと本文が入らない。Windows 版の
    # clipboard_restore_ms(250) と同じ考えで少し待つ。
    time.sleep(0.35)
    subprocess.run(["pbcopy"], input=saved)


def play_pop() -> None:
    """フィードバック音。飾りなので、鳴らせなくても止まらない。"""
    try:
        subprocess.Popen(["afplay", "/System/Library/Sounds/Pop.aiff"],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
    except OSError:
        pass


# ---------------------------------------------------------------- 制御

SayFn = Callable[[str], None]


class Controller:
    """armed の管理と、確定イベントの処理（貼るかどうかは armed 次第）。

    貼り付け・通知・音は関数で差し替えられるようにしてあり、テストは
    偽の貼り付け関数で「何が貼られるはずだったか」を確かめる
    （実キー入力はしない、という AGENTS.md の決まり）。
    """

    def __init__(self, *, dictionary: Dictionary, options: jatext.Options,
                 paste_fn: Callable[[str], None] = paste_text,
                 say: SayFn | None = None,
                 sound_fn: Callable[[], None] | None = None,
                 always_on: bool = False) -> None:
        self._dictionary = dictionary
        self._options = options
        self._paste_fn = paste_fn
        self._say: SayFn = say if say is not None else (lambda msg: None)
        self._sound_fn = sound_fn
        self.armed = always_on
        self._lock = threading.Lock()

    def toggle(self) -> bool:
        with self._lock:
            self.armed = not self.armed
            armed = self.armed
        if armed:
            self._say("入力モード: オン（話すと文がカーソル位置に入ります）")
        else:
            self._say("入力モード: オフ")
        if self._sound_fn is not None:
            self._sound_fn()
        return armed

    def handle_line(self, line: str) -> str | None:
        """JSONL の1行を処理する。貼った文を返し、それ以外は None。"""
        kind, payload = parse_event(line)
        if kind == "completed":
            return self._on_completed(payload)
        if kind == "failed":
            self._say(f"聞き取りに失敗しました: {payload}")
            log.warning("transcription failed: %s", payload)
        elif kind == "broken":
            log.warning("読めない行を読み飛ばしました: %s", payload)
        return None

    def _on_completed(self, raw: str) -> str | None:
        if not self.armed:
            # disarmed の確定は捨てる。speech は止めない（止めると
            # モデルの再読込が要り、切り替えが重くなるため）。
            log.debug("オフの間の確定を捨てました: %s", raw[:40])
            return None
        # 辞書の保存は即反映（Windows 版と同じ約束）。mtime の確認だけ
        # なので毎回呼んでも軽い。
        self._dictionary.reload()
        text = clean_text(raw, self._dictionary, self._options)
        if not text:
            return None
        try:
            self._paste_fn(text)
        except Exception as exc:
            self._say(f"貼り付けに失敗しました: {exc}")
            log.exception("貼り付けに失敗しました")
            return None
        self._say(f"入れました: {text[:40]}")
        if self._sound_fn is not None:
            self._sound_fn()
        return text


class SpeechLive:
    """`speech asr --live` の子プロセスと、その標準出力の読み手。"""

    def __init__(self, cmd: list[str]) -> None:
        self._cmd = cmd
        self.lines: queue.Queue[str] = queue.Queue()
        self._proc: subprocess.Popen[str] | None = None
        self._err_file: Any = None

    def start(self) -> None:
        SPEECH_ERR_PATH.parent.mkdir(parents=True, exist_ok=True)
        self._err_file = open(SPEECH_ERR_PATH, "ab")
        self._proc = subprocess.Popen(
            self._cmd, stdout=subprocess.PIPE, stderr=self._err_file,
            text=True, bufsize=1)
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self) -> None:
        assert self._proc is not None and self._proc.stdout is not None
        for line in self._proc.stdout:
            self.lines.put(line)

    @property
    def exit_code(self) -> int | None:
        if self._proc is None:
            return None
        return self._proc.poll()

    def stop(self) -> None:
        if self._proc is None:
            return
        if self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        if self._err_file is not None:
            self._err_file.close()


def build_speech_cmd(keywords: str) -> list[str]:
    cmd = [str(SPEECH_BIN), "asr", str(HAAS_MODEL),
           "--vad", str(VAD_MODEL), "--live", "--format", "json"]
    if keywords:
        cmd += ["--keywords", keywords]
    return cmd


# ---------------------------------------------------------------- 実行

def _run_loop(tick: Callable[[], None], stop: threading.Event) -> None:
    """CFRunLoop を 0.2 秒刻みで回し、その合間に tick() を呼ぶ。

    CFRunLoopRun で通しに回すと Python のシグナルハンドラがいつまでも
    実行されず Ctrl-C が効かなくなる。RunInMode の短い刻みにすれば、
    Carbon ホットキーの配送もタイマー処理もシグナルも全部回る。
    """
    cf = ctypes.CDLL(
        "/System/Library/Frameworks/CoreFoundation.framework/"
        "CoreFoundation")
    cf.CFStringCreateWithCString.restype = ctypes.c_void_p
    cf.CFStringCreateWithCString.argtypes = [
        ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32]
    cf.CFRunLoopGetCurrent.restype = ctypes.c_void_p
    cf.CFRunLoopGetCurrent.argtypes = []
    cf.CFRunLoopRunInMode.restype = ctypes.c_int32
    cf.CFRunLoopRunInMode.argtypes = [
        ctypes.c_void_p, ctypes.c_double, ctypes.c_bool]
    mode = cf.CFStringCreateWithCString(
        None, b"kCFRunLoopDefaultMode", 0x08000100)  # UTF-8
    loop = cf.CFRunLoopGetCurrent()
    while not stop.is_set():
        cf.CFRunLoopRunInMode(mode, 0.2, False)
        tick()


def _stdin_toggle(controller: Controller, stop: threading.Event) -> None:
    """ホットキーが使えない時の代替: ターミナルで Enter のたびに切替。"""
    while not stop.is_set():
        try:
            line = sys.stdin.readline()
        except (OSError, ValueError):
            return
        if not line:  # EOF（入力が閉じられた）
            return
        controller.toggle()


def _setup_logging() -> None:
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=str(LOG_PATH), level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="koe-type Mac Lite")
    parser.add_argument("--selftest", action="store_true",
                        help="状態を点検してレポートを出す")
    parser.add_argument("--always-on", action="store_true",
                        help="ホットキーなしで常時 入力モード")
    args = parser.parse_args(argv)

    if args.selftest:
        return selftest()
    if sys.platform != "darwin":
        print("koe-type Mac Lite は macOS 専用です")
        return 2

    _setup_logging()

    def say(msg: str) -> None:
        print(msg, flush=True)
        log.info(msg)

    for path, label in ((SPEECH_BIN, "speech 本体"),
                        (HAAS_MODEL, "Haas モデル"),
                        (VAD_MODEL, "VAD モデル")):
        if not path.exists():
            say(f"{label} がありません: {path}")
            say("先に install.sh を実行してください")
            return 1

    cfg = load_config(MAC_HOME)
    dictionary = Dictionary(MAC_HOME / "dictionary.txt")
    options = build_options(cfg, load_learned_pairs(MAC_HOME, cfg))
    keywords = build_keywords(dictionary.hints)
    controller = Controller(dictionary=dictionary, options=options,
                            say=say, sound_fn=play_pop,
                            always_on=args.always_on)

    speech = SpeechLive(build_speech_cmd(keywords))
    try:
        speech.start()
    except OSError as exc:
        say(f"speech を起動できませんでした: {exc}")
        return 1
    say("koe-type Mac Lite を起動しました（マイクは常時聞いています）")

    stop = threading.Event()
    hot_key: carbon_hotkey.HotKey | None = None
    if args.always_on:
        say("入力モード: オン（常時）。"
            "止めるにはこのターミナルで Ctrl+C を押してください")
    else:
        try:
            hot_key = carbon_hotkey.register(
                HOTKEY_CODE, HOTKEY_MODS, controller.toggle)
            say("Ctrl+Option+Space で入力モードの オン/オフ を"
                "切り替えます。終了は Ctrl+C です")
        except carbon_hotkey.HotKeyError as exc:
            say(f"ホットキーを使えません（{exc}）")
            say("代わりに、このターミナルで Enter を押すたびに"
                " オン/オフ を切り替えます")
            threading.Thread(target=_stdin_toggle,
                             args=(controller, stop),
                             daemon=True).start()

    def _signal(_signum: int, _frame: Any) -> None:
        stop.set()

    signal.signal(signal.SIGINT, _signal)
    signal.signal(signal.SIGTERM, _signal)

    def tick() -> None:
        while True:
            try:
                line = speech.lines.get_nowait()
            except queue.Empty:
                break
            controller.handle_line(line)
        code = speech.exit_code
        if code is not None and not stop.is_set():
            say(f"speech が終了しました（コード {code}）。"
                f"詳しくは {SPEECH_ERR_PATH} を見てください")
            stop.set()

    try:
        _run_loop(tick, stop)
    finally:
        if hot_key is not None:
            hot_key.close()
        speech.stop()
        say("終了しました")
    return 0


# ---------------------------------------------------------------- 自己点検

def _file_state(path: Path, size: int | None) -> tuple[bool, str]:
    if not path.exists():
        return (False, f"ありません: {path}")
    actual = path.stat().st_size
    if size is not None and actual != size:
        return (False, f"サイズが違います（{actual} / 期待 {size}）:"
                       f" {path}")
    return (True, f"{actual} バイト: {path}")


def selftest() -> int:
    """状態を点検し、``` で囲った貼り返し用レポートを出す。"""
    rows: list[tuple[bool | None, str]] = []

    machine = platform.machine()
    rows.append((machine == "arm64",
                 f"機種: {machine}（Apple Silicon が対象です）"))
    rows.append((True, f"Python: {platform.python_version()}"))

    ok, msg = _file_state(SPEECH_BIN, None)
    rows.append((ok, f"speech 本体: {msg}"))
    if ok and os.access(SPEECH_BIN, os.X_OK):
        try:
            out = subprocess.run([str(SPEECH_BIN), "devices"],
                                 capture_output=True, text=True, timeout=30)
            first = (out.stdout.strip().splitlines() or ["（出力なし）"])[0]
            rows.append((out.returncode == 0, f"speech devices: {first}"))
        except (OSError, subprocess.TimeoutExpired) as exc:
            rows.append((False, f"speech devices を実行できません: {exc}"))
    else:
        rows.append((False, "speech devices: 本体がない/実行できないため"
                            "未確認"))

    ok, msg = _file_state(HAAS_MODEL, HAAS_SIZE)
    rows.append((ok, f"Haas モデル: {msg}"))
    ok, msg = _file_state(VAD_MODEL, VAD_SIZE)
    rows.append((ok, f"VAD モデル: {msg}"))

    dictionary = MAC_HOME / "dictionary.txt"
    if dictionary.exists():
        rows.append((True, f"辞書: あります: {dictionary}"))
    else:
        rows.append((None, "辞書: ありません（無くても動きます。"
                           "単語を覚えさせたい時は作ってください）"))

    ng = sum(1 for ok_, _ in rows if ok_ is False)
    lines = ["koe-type Mac Lite セルフテスト"]
    for ok_, msg in rows:
        mark = "OK" if ok_ else ("情報" if ok_ is None else "NG")
        lines.append(f"- [{mark}] {msg}")
    lines.append("結果: " + ("すべて OK です" if ng == 0
                             else f"NG が {ng} 件あります"))
    print("```")
    print("\n".join(lines))
    print("```")
    return 1 if ng else 0


if __name__ == "__main__":
    raise SystemExit(main())
